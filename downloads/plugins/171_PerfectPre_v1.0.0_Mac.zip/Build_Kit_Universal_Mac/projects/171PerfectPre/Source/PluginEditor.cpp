#include "PluginEditor.h"

AudioPluginAudioProcessorEditor::AudioPluginAudioProcessorEditor(AudioPluginAudioProcessor& p)
    : AudioProcessorEditor(&p),
      processorRef(p),
      guiEngine(*this, p.getAPVTS()),
      inputGainKnob("INPUT GAIN", plugin_171::KnobStyle::TeardropBronze, plugin_171::ScaleDialType::None),
      warmthKnob("WARMTH", plugin_171::KnobStyle::TeardropBronze, plugin_171::ScaleDialType::None),
      diodeDriveKnob("DIODE DRV", plugin_171::KnobStyle::NeveMarconiRed, plugin_171::ScaleDialType::None),
      preampMixKnob("MIX", plugin_171::KnobStyle::TeardropBronze, plugin_171::ScaleDialType::None),
      diodeToggle("", plugin_171::SwitchStyle::SquareConsoleSoloAmber),
      hpfKnob("HPF", plugin_171::KnobStyle::NeveMarconiBlue, plugin_171::ScaleDialType::None),
      lowDualKnob(plugin_171::RapidDualConcentricKnob::BandType::LowShelf),
      midDualKnob(plugin_171::RapidDualConcentricKnob::BandType::MidPeak),
      highGainKnob("HIGH SHELF", plugin_171::KnobStyle::TeardropBronze, plugin_171::ScaleDialType::None),
      eqToggle("", plugin_171::SwitchStyle::BoutiqueBrassToggle),
      sReductionKnob("S-REDUCTION", plugin_171::KnobStyle::TeardropBronze, plugin_171::ScaleDialType::None),
      deEsserFreqKnob("FREQ", plugin_171::KnobStyle::TeardropBronze, plugin_171::ScaleDialType::None),
      maleFemaleToggle("", plugin_171::SwitchStyle::SquareConsoleSoloAmber),
      deEsserToggle("ACTIVE", plugin_171::SwitchStyle::BoutiqueBrassToggle),
      deltaListenToggle("DELTA", plugin_171::SwitchStyle::BoutiqueBrassToggle),
      outGainKnob("OUTPUT TRIM", plugin_171::KnobStyle::TeardropBronze, plugin_171::ScaleDialType::None),
      ceilingToggle("", plugin_171::SwitchStyle::SquareConsoleSoloAmber),
      bypassButton("BYPASS")
{
    // 1. Carica gli asset di produzione da memoria
    auto loadMemoryImg = [](const char* data, int size) -> juce::Image {
        if (data == nullptr || size <= 0) return {};
        return juce::ImageCache::getFromMemory(data, size);
    };

    backplateWideImg      = loadMemoryImg(BinaryData::backplate_wide_png, BinaryData::backplate_wide_pngSize);
    backplateCutoutImg    = loadMemoryImg(BinaryData::backplate_cutout_png, BinaryData::backplate_cutout_pngSize);
    screenGlassOverlayImg = loadMemoryImg(BinaryData::screen_glass_overlay_png, BinaryData::screen_glass_overlay_pngSize);
    knobBronzeImg         = loadMemoryImg(BinaryData::knob_winged_bronze_png, BinaryData::knob_winged_bronze_pngSize);
    knobRedImg            = loadMemoryImg(BinaryData::knob_winged_red_png, BinaryData::knob_winged_red_pngSize);
    knobBlueImg           = loadMemoryImg(BinaryData::knob_winged_blue_png, BinaryData::knob_winged_blue_pngSize);
    knobSteelImg          = loadMemoryImg(BinaryData::knob_winged_steel_png, BinaryData::knob_winged_steel_pngSize);
    collarImg             = loadMemoryImg(BinaryData::collar_knurled_png, BinaryData::collar_knurled_pngSize);
    plateInputGainImg     = loadMemoryImg(BinaryData::plate_input_gain_png, BinaryData::plate_input_gain_pngSize);
    plateHpfImg           = loadMemoryImg(BinaryData::plate_hpf_png, BinaryData::plate_hpf_pngSize);
    plateLowShelfImg      = loadMemoryImg(BinaryData::plate_low_shelf_png, BinaryData::plate_low_shelf_pngSize);
    plateMidPeakImg       = loadMemoryImg(BinaryData::plate_mid_peak_png, BinaryData::plate_mid_peak_pngSize);
    plateHighShelfImg     = loadMemoryImg(BinaryData::plate_high_shelf_png, BinaryData::plate_high_shelf_pngSize);
    plateLowDualImg       = loadMemoryImg(BinaryData::plate_low_dual_png, BinaryData::plate_low_dual_pngSize);
    plateMidDualImg       = loadMemoryImg(BinaryData::plate_mid_dual_png, BinaryData::plate_mid_dual_pngSize);
    ringDualSelectorImg   = loadMemoryImg(BinaryData::ring_dual_selector_png, BinaryData::ring_dual_selector_pngSize);
    btnMaleFemaleOffImg   = loadMemoryImg(BinaryData::button_male_female_off_png, BinaryData::button_male_female_off_pngSize);
    btnMaleFemaleOnImg    = loadMemoryImg(BinaryData::button_male_female_on_png, BinaryData::button_male_female_on_pngSize);
    knobConcentricSilverImg = loadMemoryImg(BinaryData::knob_concentric_silver_png, BinaryData::knob_concentric_silver_pngSize);
    switchNeveEqOffImg    = loadMemoryImg(BinaryData::switch_neve_eq_off_png, BinaryData::switch_neve_eq_off_pngSize);
    switchNeveEqOnImg     = loadMemoryImg(BinaryData::switch_neve_eq_on_png, BinaryData::switch_neve_eq_on_pngSize);
    switchSplTactileOffImg = loadMemoryImg(BinaryData::switch_spl_tactile_off_png, BinaryData::switch_spl_tactile_off_pngSize);
    switchSplTactileOnImg = loadMemoryImg(BinaryData::switch_spl_tactile_on_png, BinaryData::switch_spl_tactile_on_pngSize);
    lampDiodeOffImg       = loadMemoryImg(BinaryData::lamp_diode_off_png, BinaryData::lamp_diode_off_pngSize);
    lampDiodeOnImg        = loadMemoryImg(BinaryData::lamp_diode_on_png, BinaryData::lamp_diode_on_pngSize);
    lampCeilingGreenImg   = loadMemoryImg(BinaryData::lamp_ceiling_green_png, BinaryData::lamp_ceiling_green_pngSize);
    lampCeilingRedImg     = loadMemoryImg(BinaryData::lamp_ceiling_red_png, BinaryData::lamp_ceiling_red_pngSize);
    logo171GoldImg        = loadMemoryImg(BinaryData::logo_171_gold_png, BinaryData::logo_171_gold_pngSize);
    badge171FullImg       = loadMemoryImg(BinaryData::badge_171_full_png, BinaryData::badge_171_full_pngSize);
    screwRackImg          = loadMemoryImg(BinaryData::screw_rack_png, BinaryData::screw_rack_pngSize);
    screenBezelHollowImg  = loadMemoryImg(BinaryData::screen_bezel_hollow_png, BinaryData::screen_bezel_hollow_pngSize);
    readoutFreqFrameImg   = loadMemoryImg(BinaryData::readout_freq_frame_png, BinaryData::readout_freq_frame_pngSize);
    lampJewelRubyOnImg    = loadMemoryImg(BinaryData::lamp_jewel_ruby_on_png, BinaryData::lamp_jewel_ruby_on_pngSize);
    lampJewelRubyOffImg   = loadMemoryImg(BinaryData::lamp_jewel_ruby_off_png, BinaryData::lamp_jewel_ruby_off_pngSize);
    switchDiodeOnImg      = loadMemoryImg(BinaryData::switch_diode_on_png, BinaryData::switch_diode_on_pngSize);
    switchDiodeOffImg     = loadMemoryImg(BinaryData::switch_diode_off_png, BinaryData::switch_diode_off_pngSize);
    switchCeilingOnImg    = loadMemoryImg(BinaryData::switch_ceiling_on_png, BinaryData::switch_ceiling_on_pngSize);
    switchCeilingOffImg   = loadMemoryImg(BinaryData::switch_ceiling_off_png, BinaryData::switch_ceiling_off_pngSize);
    plateWarmthImg        = loadMemoryImg(BinaryData::plate_warmth_png, BinaryData::plate_warmth_pngSize);
    plateDiodeDriveImg    = loadMemoryImg(BinaryData::plate_diode_drive_png, BinaryData::plate_diode_drive_pngSize);
    platePreampMixImg     = loadMemoryImg(BinaryData::plate_preamp_mix_png, BinaryData::plate_preamp_mix_pngSize);
    plateSReductionImg    = loadMemoryImg(BinaryData::plate_s_reduction_png, BinaryData::plate_s_reduction_pngSize);
    plateDeEsserFreqImg   = loadMemoryImg(BinaryData::plate_deesser_freq_png, BinaryData::plate_deesser_freq_pngSize);
    plateOutGainImg       = loadMemoryImg(BinaryData::plate_out_gain_png, BinaryData::plate_out_gain_pngSize);

    // 2. Dimensione finestra allargata e supporto completo al resizing con mantenimento proporzioni
    setResizable(true, true);
    setResizeLimits(960, 520, 1920, 1040);
    getConstrainer()->setFixedAspectRatio(1200.0 / 650.0);
    setSize(1200, 650);

    // Formattatori di testo ad altissima intelligibilità per tutte le serigrafie
    inputGainKnob.textFromValueFunction = [](double v) { return (v > 0.05 ? "+" : "") + juce::String(v, 1) + " dB"; };
    warmthKnob.textFromValueFunction    = [](double v) { return juce::String(std::round(v * 100.0)) + "%"; };
    diodeDriveKnob.textFromValueFunction= [](double v) { return juce::String(std::round(v * 100.0)) + "%"; };
    preampMixKnob.textFromValueFunction = [](double v) { return juce::String(std::round(v * 100.0)) + "% WET"; };
    
    hpfKnob.textFromValueFunction = [](double v) {
        int idx = (int)std::round(v);
        const char* const freqs[] = { "OFF", "50 Hz", "80 Hz", "160 Hz", "300 Hz" };
        return juce::String(freqs[juce::jlimit(0, 4, idx)]);
    };
    highGainKnob.textFromValueFunction  = [](double v) { return (v > 0.05 ? "+" : "") + juce::String(v, 1) + " dB"; };
    sReductionKnob.textFromValueFunction= [](double v) { return juce::String(v, 1); };
    deEsserFreqKnob.textFromValueFunction = [](double v) {
        return (v >= 1000.0 ? juce::String(v / 1000.0, 1) + " kHz" : juce::String(std::round(v)) + " Hz");
    };
    outGainKnob.textFromValueFunction   = [](double v) { return (v > 0.05 ? "+" : "") + juce::String(v, 1) + " dB"; };

    // 3. Configura le manopole con effetto LED attivo e scale rifinite
    inputGainKnob.setCustomImages(knobBronzeImg, plateInputGainImg);
    inputGainKnob.setKnobScaleRatio(0.56f);
    inputGainKnob.setShowLedTrack(true);
    addAndMakeVisible(inputGainKnob);

    warmthKnob.setCustomImages(knobBronzeImg, plateWarmthImg);
    warmthKnob.setKnobScaleRatio(0.56f);
    warmthKnob.setShowLedTrack(true);
    addAndMakeVisible(warmthKnob);

    diodeDriveKnob.setCustomImages(knobRedImg, plateDiodeDriveImg);
    diodeDriveKnob.setKnobScaleRatio(0.56f);
    diodeDriveKnob.setShowLedTrack(true);
    diodeDriveKnob.setLedColour(juce::Colour(0xffff2d55)); // Ruby glow
    addAndMakeVisible(diodeDriveKnob);

    preampMixKnob.setCustomImages(knobBronzeImg, platePreampMixImg);
    preampMixKnob.setKnobScaleRatio(0.56f);
    preampMixKnob.setShowLedTrack(true);
    addAndMakeVisible(preampMixKnob);

    diodeToggle.setCustomImages(switchDiodeOnImg, switchDiodeOffImg);
    addAndMakeVisible(diodeToggle);

    // Sezione 2: Neve 1073 EQ (Manopole Satina Acciaio Anodizzato Uniformi con Logo 171)
    hpfKnob.setCustomImages(knobSteelImg, plateHpfImg);
    hpfKnob.setKnobScaleRatio(0.56f);
    hpfKnob.setShowLedTrack(true);
    hpfKnob.setLedColour(juce::Colour(0xff38bdf8)); // Electric blue glow
    addAndMakeVisible(hpfKnob);

    highGainKnob.setCustomImages(knobSteelImg, plateHighShelfImg);
    highGainKnob.setKnobScaleRatio(0.56f);
    highGainKnob.setShowLedTrack(true);
    highGainKnob.setLedColour(juce::Colour(0xffffb300));
    addAndMakeVisible(highGainKnob);

    lowDualKnob.setCustomImages(knobConcentricSilverImg, ringDualSelectorImg, plateLowDualImg);
    lowDualKnob.setLedColour(juce::Colour(0xffffb300)); // Warm vintage gold glow
    addAndMakeVisible(lowDualKnob);

    midDualKnob.setCustomImages(knobConcentricSilverImg, ringDualSelectorImg, plateMidDualImg);
    midDualKnob.setLedColour(juce::Colour(0xffffb300)); // Warm vintage gold glow
    addAndMakeVisible(midDualKnob);

    eqToggle.setCustomImages(switchNeveEqOnImg, switchNeveEqOffImg);
    addAndMakeVisible(eqToggle);

    // Sezione 3: SPL Phase De-Esser (2 Schermi Attivi + Pannellino Frequenza)
    // Schermo 1: Input & Output Stereo Monitor
    ioMonitorScreen.bindLevels(
        [this]() { return processorRef.getInputPeak(); },
        [this]() { return processorRef.getInputRMS(); },
        [this]() { return processorRef.getOutputPeak(); },
        [this]() { return processorRef.getOutputRMS(); }
    );
    addAndMakeVisible(ioMonitorScreen);

    // Schermo 2: De-Esser Gain Reduction & Phase Telemetry
    deEssingScreen.bindData(
        [this]() { return processorRef.getDeEsserReductionDb(); },
        [this]() {
            if (auto* p = processorRef.getAPVTS().getRawParameterValue("deesser_freq"))
                return p->load(std::memory_order_relaxed);
            return 6800.0f;
        },
        [this]() {
            if (auto* p = processorRef.getAPVTS().getRawParameterValue("deesser_mode"))
                return p->load(std::memory_order_relaxed) > 0.5f;
            return false;
        }
    );
    addAndMakeVisible(deEssingScreen);

    // Pannellino Digitale Frequenza & Riduzione Sibilanti
    freqReadoutPanel.setFrameImage(readoutFreqFrameImg);
    freqReadoutPanel.bind(
        [this]() {
            if (auto* p = processorRef.getAPVTS().getRawParameterValue("deesser_freq"))
                return p->load(std::memory_order_relaxed);
            return 6800.0f;
        },
        [this]() {
            if (auto* p = processorRef.getAPVTS().getRawParameterValue("deesser_mode"))
                return p->load(std::memory_order_relaxed) > 0.5f;
            return false;
        },
        [this]() { return processorRef.getDeEsserReductionDb(); }
    );
    addAndMakeVisible(freqReadoutPanel);

    sReductionKnob.setCustomImages(knobSteelImg, plateSReductionImg);
    sReductionKnob.setKnobScaleRatio(0.56f);
    sReductionKnob.setShowLedTrack(true);
    sReductionKnob.setLedColour(juce::Colour(0xff00e5ff)); // Cyan De-Esser glow
    addAndMakeVisible(sReductionKnob);

    deEsserFreqKnob.setCustomImages(knobSteelImg, plateDeEsserFreqImg);
    deEsserFreqKnob.setKnobScaleRatio(0.56f);
    deEsserFreqKnob.setShowLedTrack(true);
    deEsserFreqKnob.setLedColour(juce::Colour(0xff00e5ff));
    addAndMakeVisible(deEsserFreqKnob);

    maleFemaleToggle.setCustomImages(btnMaleFemaleOnImg, btnMaleFemaleOffImg);
    addAndMakeVisible(maleFemaleToggle);

    deEsserToggle.setCustomImages(switchSplTactileOnImg, switchSplTactileOffImg);
    addAndMakeVisible(deEsserToggle);

    deltaListenToggle.setCustomImages(switchSplTactileOnImg, switchSplTactileOffImg);
    addAndMakeVisible(deltaListenToggle);

    // Sezione 4: Master Output & Safe Ceiling
    outGainKnob.setCustomImages(knobSteelImg, plateOutGainImg);
    outGainKnob.setKnobScaleRatio(0.56f);
    outGainKnob.setShowLedTrack(true);
    outGainKnob.setLedColour(juce::Colour(0xffffb300));
    addAndMakeVisible(outGainKnob);

    ceilingToggle.setCustomImages(switchCeilingOnImg, switchCeilingOffImg);
    addAndMakeVisible(ceilingToggle);

    addAndMakeVisible(bypassButton);

    // Selettori ComboBox con LookAndFeel Hardware 171 Studio
    flavorBox.setLookAndFeel(&customLookAndFeel);
    flavorBox.addItemList(juce::StringArray{ "01 | British Console Preamp",
                                             "02 | American Tube Class-A",
                                             "03 | Vintage Germanium Fuzz",
                                             "04 | Pure Clean Transistor" }, 1);
    flavorBox.setSelectedId(1, juce::dontSendNotification);
    flavorBox.addListener(this);
    addAndMakeVisible(flavorBox);

    presetBox.setLookAndFeel(&customLookAndFeel);
    const auto& presets = AudioPluginAudioProcessor::getFactoryPresets();
    for (int i = 0; i < (int)presets.size(); ++i)
        presetBox.addItem(presets[i].name, i + 1);
    presetBox.setSelectedId(1, juce::dontSendNotification);
    presetBox.addListener(this);
    addAndMakeVisible(presetBox);

    // Stepper Button Boutique dorati per preset (< e >)
    prevPresetBtn = std::make_unique<gui171::BoutiqueStepperButton>(gui171::BoutiqueStepperButton::Direction::Previous);
    prevPresetBtn->setOnClick([this]() {
        int cur = presetBox.getSelectedId() - 1;
        int num = processorRef.getNumPrograms();
        if (num > 0) {
            int prev = (cur - 1 + num) % num;
            presetBox.setSelectedId(prev + 1, juce::sendNotification);
        }
    });
    addAndMakeVisible(*prevPresetBtn);

    nextPresetBtn = std::make_unique<gui171::BoutiqueStepperButton>(gui171::BoutiqueStepperButton::Direction::Next);
    nextPresetBtn->setOnClick([this]() {
        int cur = presetBox.getSelectedId() - 1;
        int num = processorRef.getNumPrograms();
        if (num > 0) {
            int next = (cur + 1) % num;
            presetBox.setSelectedId(next + 1, juce::sendNotification);
        }
    });
    addAndMakeVisible(*nextPresetBtn);

    // 4. Collega APVTS Attachments
    auto& apvts = processorRef.getAPVTS();
    driveAttach             = std::make_unique<SliderAttachment>(apvts, "preamp_drive", inputGainKnob);
    flavorAttach            = std::make_unique<ComboBoxAttachment>(apvts, "preamp_flavor", flavorBox);
    warmthAttach            = std::make_unique<SliderAttachment>(apvts, "preamp_warmth", warmthKnob);
    mixAttach               = std::make_unique<SliderAttachment>(apvts, "preamp_mix", preampMixKnob);
    diodeEnableAttach       = std::make_unique<ButtonAttachment>(apvts, "diode_enable", diodeToggle);
    diodeDriveAttach        = std::make_unique<SliderAttachment>(apvts, "diode_drive", diodeDriveKnob);

    eqEnableAttach          = std::make_unique<ButtonAttachment>(apvts, "eq_enable", eqToggle);
    hpfAttach               = std::make_unique<SliderAttachment>(apvts, "eq_hpf", hpfKnob);
    lowFreqAttach           = std::make_unique<SliderAttachment>(apvts, "eq_low_freq", lowDualKnob.getFreqSlider());
    lowGainAttach           = std::make_unique<SliderAttachment>(apvts, "eq_low_gain", lowDualKnob.getGainSlider());
    midFreqAttach           = std::make_unique<SliderAttachment>(apvts, "eq_mid_freq", midDualKnob.getFreqSlider());
    midGainAttach           = std::make_unique<SliderAttachment>(apvts, "eq_mid_gain", midDualKnob.getGainSlider());
    highGainAttach          = std::make_unique<SliderAttachment>(apvts, "eq_high_gain", highGainKnob);

    deEsserEnableAttach     = std::make_unique<ButtonAttachment>(apvts, "deesser_enable", deEsserToggle);
    deEsserReductionAttach  = std::make_unique<SliderAttachment>(apvts, "deesser_reduction", sReductionKnob);
    deEsserModeAttach       = std::make_unique<ButtonAttachment>(apvts, "deesser_mode", maleFemaleToggle);
    deEsserFreqAttach       = std::make_unique<SliderAttachment>(apvts, "deesser_freq", deEsserFreqKnob);
    deEsserDeltaAttach      = std::make_unique<ButtonAttachment>(apvts, "deesser_delta", deltaListenToggle);

    outGainAttach           = std::make_unique<SliderAttachment>(apvts, "out_gain", outGainKnob);
    ceilingAttach           = std::make_unique<ButtonAttachment>(apvts, "safe_ceiling_enable", ceilingToggle);
    bypassAttach            = std::make_unique<ButtonAttachment>(apvts, "bypass", bypassButton);

    updatePreampTheme();
    startTimerHz(30);
}

AudioPluginAudioProcessorEditor::~AudioPluginAudioProcessorEditor()
{
    stopTimer();
    flavorBox.removeListener(this);
    presetBox.removeListener(this);
    flavorBox.setLookAndFeel(nullptr);
    presetBox.setLookAndFeel(nullptr);
}

void AudioPluginAudioProcessorEditor::updatePreampTheme()
{
    int flavorIdx = 0;
    if (auto* p = processorRef.getAPVTS().getRawParameterValue("preamp_flavor"))
        flavorIdx = (int)p->load(std::memory_order_relaxed);

    switch (flavorIdx)
    {
        case 0: // British Console -> Machined Golden Bronze 171 Chicken Knobs
            inputGainKnob.setCustomImages(knobBronzeImg, plateInputGainImg);
            inputGainKnob.setLedColour(juce::Colour(0xffffb300));
            warmthKnob.setCustomImages(knobBronzeImg, plateWarmthImg);
            warmthKnob.setLedColour(juce::Colour(0xffffb300));
            diodeDriveKnob.setCustomImages(knobBronzeImg, plateDiodeDriveImg);
            diodeDriveKnob.setLedColour(juce::Colour(0xffffb300));
            preampMixKnob.setCustomImages(knobBronzeImg, platePreampMixImg);
            preampMixKnob.setLedColour(juce::Colour(0xffffb300));
            break;
        case 1: // American Tube -> Radiant Crimson Red 171 Chicken Knobs
            inputGainKnob.setCustomImages(knobRedImg, plateInputGainImg);
            inputGainKnob.setLedColour(juce::Colour(0xffff2d55));
            warmthKnob.setCustomImages(knobRedImg, plateWarmthImg);
            warmthKnob.setLedColour(juce::Colour(0xffff2d55));
            diodeDriveKnob.setCustomImages(knobRedImg, plateDiodeDriveImg);
            diodeDriveKnob.setLedColour(juce::Colour(0xffff2d55));
            preampMixKnob.setCustomImages(knobRedImg, platePreampMixImg);
            preampMixKnob.setLedColour(juce::Colour(0xffff2d55));
            break;
        case 2: // Vintage Germanium -> Cobalt Blue 171 Chicken Knobs
            inputGainKnob.setCustomImages(knobBlueImg, plateInputGainImg);
            inputGainKnob.setLedColour(juce::Colour(0xff38bdf8));
            warmthKnob.setCustomImages(knobBlueImg, plateWarmthImg);
            warmthKnob.setLedColour(juce::Colour(0xff38bdf8));
            diodeDriveKnob.setCustomImages(knobBlueImg, plateDiodeDriveImg);
            diodeDriveKnob.setLedColour(juce::Colour(0xff38bdf8));
            preampMixKnob.setCustomImages(knobBlueImg, platePreampMixImg);
            preampMixKnob.setLedColour(juce::Colour(0xff38bdf8));
            break;
        case 3: // Pure Clean Transistor -> Machined Acciaio Chiaro (Light Steel) 171 Chicken Knobs
            inputGainKnob.setCustomImages(knobSteelImg, plateInputGainImg);
            inputGainKnob.setLedColour(juce::Colour(0xfff1f5f9)); // Crisp diamond-steel white glow
            warmthKnob.setCustomImages(knobSteelImg, plateWarmthImg);
            warmthKnob.setLedColour(juce::Colour(0xfff1f5f9));
            diodeDriveKnob.setCustomImages(knobSteelImg, plateDiodeDriveImg);
            diodeDriveKnob.setLedColour(juce::Colour(0xfff1f5f9));
            preampMixKnob.setCustomImages(knobSteelImg, platePreampMixImg);
            preampMixKnob.setLedColour(juce::Colour(0xfff1f5f9));
            break;
        default:
            break;
    }
}

void AudioPluginAudioProcessorEditor::paint(juce::Graphics& g)
{
    const auto bounds = getLocalBounds().toFloat();

    // 1. Disegna il telaio allargato ad alta risoluzione
    if (backplateWideImg.isValid())
    {
        g.drawImage(backplateWideImg, bounds, juce::RectanglePlacement::stretchToFit);
    }
    else if (backplateCutoutImg.isValid())
    {
        g.drawImage(backplateCutoutImg, bounds, juce::RectanglePlacement::stretchToFit);
    }
    else
    {
        g.fillAll(juce::Colour(0xff121316));
    }

    const float scaleX = (float)getWidth()  / 1200.0f;
    const float scaleY = (float)getHeight() / 650.0f;

    // 2. La texture backplateWideImg contiene già:
    // - Viti e alloggiamenti asolati da rack 19" sulle alette laterali
    // - Pinstripe e serigrafie delle sezioni incise in oro vintage
    // - Emblema satinato '171 PLUGIN INNOVATION' in basso a destra
    // - Stemma dorato 171 custom console nell'EQ
    // Non duplichiamo elementi per mantenere la serigrafia purissima e nitida.

    // 5. Spia Hardware Ruby Jewel Lamp nel Master Output (Switch puro On/Off senza aloni procedurali)
    {
        bool isBypassed = false;
        if (auto* p = processorRef.getAPVTS().getRawParameterValue("bypass"))
            isBypassed = p->load(std::memory_order_relaxed) > 0.5f;

        auto jewelRect = juce::Rectangle<float>(955.0f * scaleX, 404.0f * scaleY, 48.0f * scaleX, 48.0f * scaleY);

        if (!isBypassed && lampJewelRubyOnImg.isValid())
        {
            g.drawImage(lampJewelRubyOnImg, jewelRect, juce::RectanglePlacement::centred);
        }
        else if (lampJewelRubyOffImg.isValid())
        {
            g.drawImage(lampJewelRubyOffImg, jewelRect, juce::RectanglePlacement::centred);
        }
    }

    // 6. Spie Jewel Indicator sotto i baton switch del De-Esser (ACTIVE e DELTA)
    {
        bool isDeEsserActive = false;
        if (auto* p = processorRef.getAPVTS().getRawParameterValue("deesser_enable"))
            isDeEsserActive = p->load(std::memory_order_relaxed) > 0.5f;

        bool isDeltaActive = false;
        if (auto* p = processorRef.getAPVTS().getRawParameterValue("deesser_delta"))
            isDeltaActive = p->load(std::memory_order_relaxed) > 0.5f;

        auto activeJewelRect = juce::Rectangle<float>(663.0f * scaleX, 536.0f * scaleY, 20.0f * scaleX, 20.0f * scaleY);
        auto deltaJewelRect  = juce::Rectangle<float>(729.0f * scaleX, 536.0f * scaleY, 20.0f * scaleX, 20.0f * scaleY);

        if (isDeEsserActive && lampJewelRubyOnImg.isValid())
            g.drawImage(lampJewelRubyOnImg, activeJewelRect, juce::RectanglePlacement::centred);
        else if (lampJewelRubyOffImg.isValid())
            g.drawImage(lampJewelRubyOffImg, activeJewelRect, juce::RectanglePlacement::centred);

        if (isDeltaActive && lampJewelRubyOnImg.isValid())
            g.drawImage(lampJewelRubyOnImg, deltaJewelRect, juce::RectanglePlacement::centred);
        else if (lampJewelRubyOffImg.isValid())
            g.drawImage(lampJewelRubyOffImg, deltaJewelRect, juce::RectanglePlacement::centred);
    }

    // 7. Spia Jewel Indicator sotto il pulsante DIODE
    {
        bool isDiodeActive = false;
        if (auto* p = processorRef.getAPVTS().getRawParameterValue("diode_enable"))
            isDiodeActive = p->load(std::memory_order_relaxed) > 0.5f;

        auto diodeJewelRect = juce::Rectangle<float>(83.0f * scaleX, 506.0f * scaleY, 22.0f * scaleX, 22.0f * scaleY);

        if (isDiodeActive && lampJewelRubyOnImg.isValid())
            g.drawImage(lampJewelRubyOnImg, diodeJewelRect, juce::RectanglePlacement::centred);
        else if (lampJewelRubyOffImg.isValid())
            g.drawImage(lampJewelRubyOffImg, diodeJewelRect, juce::RectanglePlacement::centred);
    }

    // 8. Spia Jewel Indicator sotto il pulsante SAFE CEILING
    {
        bool isCeilingActive = false;
        if (auto* p = processorRef.getAPVTS().getRawParameterValue("safe_ceiling_enable"))
            isCeilingActive = p->load(std::memory_order_relaxed) > 0.5f;

        auto ceilingJewelRect = juce::Rectangle<float>(1036.0f * scaleX, 374.0f * scaleY, 22.0f * scaleX, 22.0f * scaleY);

        if (isCeilingActive && lampJewelRubyOnImg.isValid())
            g.drawImage(lampJewelRubyOnImg, ceilingJewelRect, juce::RectanglePlacement::centred);
        else if (lampJewelRubyOffImg.isValid())
            g.drawImage(lampJewelRubyOffImg, ceilingJewelRect, juce::RectanglePlacement::centred);
    }
}

void AudioPluginAudioProcessorEditor::paintOverChildren(juce::Graphics& g)
{
    const float scaleX = (float)getWidth()  / 1200.0f;
    const float scaleY = (float)getHeight() / 650.0f;
    auto S_float = [scaleX, scaleY](int x, int y, int w, int h) -> juce::Rectangle<float>
    {
        return { (float)x * scaleX, (float)y * scaleY, (float)w * scaleX, (float)h * scaleY };
    };

    // 1. Cornici Metalliche Smussate per Entrambi gli Schermi TFT De-Esser
    // Disegnate SOPRA i bordi dei monitor coprendo al 100% qualsiasi cornice del backplate sottostante!
    if (screenBezelHollowImg.isValid())
    {
        g.drawImage(screenBezelHollowImg, S_float(623, 53, 270, 144), juce::RectanglePlacement::stretchToFit);
        g.drawImage(screenBezelHollowImg, S_float(623, 173, 270, 144), juce::RectanglePlacement::stretchToFit);
    }

    // 2. Vetro protettivo antiriflesso con satinatura leggera
    if (screenGlassOverlayImg.isValid())
    {
        g.setOpacity(0.12f);
        g.drawImage(screenGlassOverlayImg, ioMonitorScreen.getBounds().toFloat(), juce::RectanglePlacement::stretchToFit);
        g.drawImage(screenGlassOverlayImg, deEssingScreen.getBounds().toFloat(), juce::RectanglePlacement::stretchToFit);
        g.setOpacity(1.0f);
    }

    // 3. Serigrafie ed Indicatori delle Manopole Preamp ed EQ (Console Studio Badges)
    auto drawIndicatorBadge = [&g, scaleX, scaleY](const juce::String& text, float cx, float cy, float w, float h)
    {
        auto r = juce::Rectangle<float>((cx - w * 0.5f) * scaleX,
                                        (cy - h * 0.5f) * scaleY,
                                        w * scaleX,
                                        h * scaleY);
        // Shadow sottile
        g.setColour(juce::Colour(0xaa000000));
        g.fillRoundedRectangle(r.translated(0.0f, 1.0f * scaleY), 3.0f * scaleX);

        // Background scuro stile badge metallico inciso
        g.setColour(juce::Colour(0xf20b0d11));
        g.fillRoundedRectangle(r, 3.0f * scaleX);

        // Cornice oro vintage
        g.setColour(juce::Colour(0xb0d4af37));
        g.drawRoundedRectangle(r, 3.0f * scaleX, 1.0f);

        // Testo inciso oro caldo satinato ad alta risoluzione (leggermente piu piccolo e rifinito)
        g.setFont(juce::FontOptions(9.0f * juce::jmin(scaleX, scaleY), juce::Font::bold));
        g.setColour(juce::Colour(0xee000000));
        g.drawText(text, r.translated(0.0f, 1.0f), juce::Justification::centred, false);

        g.setColour(juce::Colour(0xffebd299));
        g.drawText(text, r, juce::Justification::centred, false);
    };

    // Preamp Section Indicators - Perfettamente centrate negli spazi verticali
    drawIndicatorBadge("PREAMP GAIN",    155.0f, 259.0f, 88.0f, 13.5f);
    drawIndicatorBadge("WARMTH",          93.0f, 393.0f, 60.0f, 13.5f);
    drawIndicatorBadge("DRIVE",          217.0f, 389.0f, 52.0f, 13.0f);
    drawIndicatorBadge("MIX",            217.0f, 519.0f, 46.0f, 13.5f);
    drawIndicatorBadge("DIODE CLIP",      94.0f, 538.0f, 72.0f, 13.5f);

    // Inductor EQ Section Indicators - Perfettamente centrate negli spazi verticali
    drawIndicatorBadge("HIGH PASS",      394.0f, 192.0f, 70.0f, 13.0f);
    drawIndicatorBadge("HIGH SHELF 12k", 394.0f, 321.0f, 92.0f, 13.0f);
    drawIndicatorBadge("EQ ENGAGE",      536.0f, 368.0f, 74.0f, 13.5f);

    // Master Indicator - Perfettamente centrata nello spazio verticale
    drawIndicatorBadge("OUTPUT GAIN",   1050.0f, 265.0f, 84.0f, 13.5f);
}

void AudioPluginAudioProcessorEditor::resized()
{
    const float scaleX = (float)getWidth()  / 1200.0f;
    const float scaleY = (float)getHeight() / 650.0f;
    auto S = [scaleX, scaleY](int x, int y, int w, int h) -> juce::Rectangle<int>
    {
        return { juce::roundToInt(x * scaleX),
                 juce::roundToInt(y * scaleY),
                 juce::roundToInt(w * scaleX),
                 juce::roundToInt(h * scaleY) };
    };

    // Sezione 1: PREAMP & DIODES (x: 20 to 290) - Manopole ingrandite, uso pieno dell'altezza
    flavorBox.setBounds(S(45, 75, 220, 28));
    inputGainKnob.setBounds(S(86, 112, 138, 138));
    warmthKnob.setBounds(S(38, 268, 110, 114));
    diodeDriveKnob.setBounds(S(162, 268, 110, 114));
    diodeToggle.setBounds(S(46, 404, 96, 96));
    preampMixKnob.setBounds(S(162, 396, 110, 114));

    // Sezione 2: 3-BAND INDUCTOR EQ (x: 305 to 615) - Disposizione Verticale con Doppio Cerchio Ingrandito
    hpfKnob.setBounds(S(336, 70, 116, 116));
    highGainKnob.setBounds(S(336, 198, 116, 116));
    midDualKnob.setBounds(S(322, 328, 144, 144));
    lowDualKnob.setBounds(S(322, 480, 144, 144));
    eqToggle.setBounds(S(490, 290, 92, 68));

    // Sezione 3: DE-ESSER (x: 620 to 905) - Schermi TFT Incassati con Cornici Metalliche e Telemetria
    ioMonitorScreen.setBounds(S(655, 80, 206, 90));
    deEssingScreen.setBounds(S(655, 200, 206, 90));
    freqReadoutPanel.setBounds(S(642, 318, 236, 38));
    sReductionKnob.setBounds(S(645, 368, 108, 112));
    deEsserFreqKnob.setBounds(S(770, 368, 108, 112));
    deEsserToggle.setBounds(S(642, 478, 62, 54));
    deltaListenToggle.setBounds(S(708, 478, 62, 54));
    maleFemaleToggle.setBounds(S(770, 472, 116, 72));

    // Sezione 4: MASTER & SAFE CEILING (x: 915 to 1180) - Tasto Ceiling Ingrandito e Logo in Basso a Destra
    if (prevPresetBtn != nullptr) prevPresetBtn->setBounds(S(918, 75, 24, 28));
    presetBox.setBounds(S(946, 75, 204, 28));
    if (nextPresetBtn != nullptr) nextPresetBtn->setBounds(S(1154, 75, 24, 28));
    outGainKnob.setBounds(S(975, 118, 150, 150));
    ceilingToggle.setBounds(S(997, 270, 100, 100));
    bypassButton.setBounds(S(1014, 404, 114, 48));
}

void AudioPluginAudioProcessorEditor::timerCallback()
{
    latestReductionDb = processorRef.getDeEsserReductionDb();
    latestPeak        = processorRef.getOutputPeak();
    latestOutRMS      = processorRef.getOutputRMS();

    updatePreampTheme();
    freqReadoutPanel.repaint();

    const float scaleX = (float)getWidth()  / 1200.0f;
    const float scaleY = (float)getHeight() / 650.0f;
    repaint(juce::roundToInt(945 * scaleX), juce::roundToInt(395 * scaleY),
            juce::roundToInt(70 * scaleX), juce::roundToInt(70 * scaleY));  // Spia Master Ruby Jewel Lamp
    repaint(juce::roundToInt(650 * scaleX), juce::roundToInt(525 * scaleY),
            juce::roundToInt(115 * scaleX), juce::roundToInt(40 * scaleY)); // Spie De-Esser Active & Delta
    repaint(juce::roundToInt(75 * scaleX), juce::roundToInt(500 * scaleY),
            juce::roundToInt(40 * scaleX), juce::roundToInt(36 * scaleY));  // Spia Diode Jewel Lamp
    repaint(juce::roundToInt(1025 * scaleX), juce::roundToInt(368 * scaleY),
            juce::roundToInt(44 * scaleX), juce::roundToInt(36 * scaleY));  // Spia Safe Ceiling Jewel Lamp
}

void AudioPluginAudioProcessorEditor::comboBoxChanged(juce::ComboBox* box)
{
    if (box == &presetBox)
    {
        int pIdx = presetBox.getSelectedId() - 1;
        processorRef.setCurrentProgram(pIdx);
        updatePreampTheme();
    }
    else if (box == &flavorBox)
    {
        updatePreampTheme();
    }
}
