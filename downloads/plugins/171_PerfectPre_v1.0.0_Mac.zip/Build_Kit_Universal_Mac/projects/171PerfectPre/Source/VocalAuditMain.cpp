#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_audio_utils/juce_audio_utils.h>
#include "PluginProcessor.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include <iomanip>

struct VocalTakeInfo
{
    std::string artist;
    std::string path;
    std::string filename;
};

struct AuditTakeResult
{
    std::string artist;
    std::string filename;
    double sampleRate;
    int channels;
    double durationSeconds;
    float peakInDb;
    float peakOutDb;
    float truePeakOutDb;
    float rmsInDb;
    float rmsOutDb;
    float maxDeEsserReductionDb;
    float avgDeEsserReductionDb;
    float airBandPhaseCorrelation;
    float dcOffsetDb;
    int nanCount;
    int infCount;
    int denormalCount;
    bool passedAllChecks;
};

// 4x Over-sampled True-Peak calculation (ITU-R BS.1770-4 approximation)
float computeTruePeak(const juce::AudioBuffer<float>& buffer)
{
    float maxAbs = 0.0f;
    const int numChannels = buffer.getNumChannels();
    const int numSamples = buffer.getNumSamples();

    for (int ch = 0; ch < numChannels; ++ch)
    {
        const float* r = buffer.getReadPointer(ch);
        for (int i = 1; i < numSamples - 2; ++i)
        {
            float p0 = r[i - 1];
            float p1 = r[i];
            float p2 = r[i + 1];
            float p3 = r[i + 2];

            // 4 points interpolation (Cubic Hermite)
            for (float t = 0.0f; t < 1.0f; t += 0.25f)
            {
                float t2 = t * t;
                float t3 = t2 * t;
                float v = 0.5f * ((2.0f * p1) +
                                  (-p0 + p2) * t +
                                  (2.0f * p0 - 5.0f * p1 + 4.0f * p2 - p3) * t2 +
                                  (-p0 + 3.0f * p1 - 3.0f * p2 + p3) * t3);
                float a = std::abs(v);
                if (a > maxAbs) maxAbs = a;
            }
        }
    }
    return maxAbs > 1e-9f ? 20.0f * std::log10(maxAbs) : -140.0f;
}

// Latency-compensated correlation in air band (> 8 kHz) to verify pristine phase alignment and zero comb-filtering
float computeAirBandPhaseCorrelation(const juce::AudioBuffer<float>& dry, const juce::AudioBuffer<float>& wet, int latencySamples)
{
    int len = std::min(dry.getNumSamples(), wet.getNumSamples()) - latencySamples;
    if (len < 1024) return 1.0f;

    // 1-pole high-pass at ~8 kHz
    double alpha = 0.60;
    double sumDryWet = 0.0;
    double sumDrySq = 0.0;
    double sumWetSq = 0.0;

    double dHp = 0.0, wHp = 0.0;
    double prevD = 0.0, prevW = 0.0;

    const float* dPtr = dry.getReadPointer(0);
    const float* wPtr = wet.getReadPointer(0) + latencySamples;

    // Skip initial transient settling
    const int startSkip = std::min(1024, len / 4);

    for (int i = startSkip; i < len; ++i)
    {
        dHp = alpha * (dHp + dPtr[i] - prevD);
        wHp = alpha * (wHp + wPtr[i] - prevW);
        prevD = dPtr[i];
        prevW = wPtr[i];

        sumDryWet += dHp * wHp;
        sumDrySq += dHp * dHp;
        sumWetSq += wHp * wHp;
    }

    double denom = std::sqrt(sumDrySq * sumWetSq);
    if (denom < 1e-12) return 1.0f;
    return (float)(sumDryWet / denom);
}

int main()
{
    juce::ScopedJuceInitialiser_GUI juceInit;
    juce::AudioFormatManager formatManager;
    formatManager.registerBasicFormats();

    std::vector<VocalTakeInfo> takes = {
        {"IGOR", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\IGOR\2023 1\Media\05-241112_1551-02.wav)", "05-241112_1551-02.wav"},
        {"IGOR", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\IGOR\Media\01-250324_2208.wav)", "01-250324_2208.wav"},
        {"SKIETTO", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\SKIETTO\SKIETTO 1\Media\02-260324_1426.wav)", "02-260324_1426.wav"},
        {"SKIETTO", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\SKIETTO\SKIETTO2\Media\01-260806_1550-02.wav)", "01-260806_1550-02.wav"},
        {"RESLA", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\RESLA\GRANITA\Media\03-260715_1054-01.wav)", "03-260715_1054-01.wav"},
        {"RESLA", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\RESLA\FREESTYLE 1\Media\01-260715_0928.wav)", "01-260715_0928.wav"},
        {"DANKLE", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\DANKLE\Luglio 15-07-2023\02-230715_1908.wav)", "02-230715_1908.wav"},
        {"DANKLE", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\DANKLE\Fake & Love\02-230630_1821.wav)", "02-230630_1821.wav"},
        {"CH4PO", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\CH4PO\CAPO 10\Media\04-250520_1623.wav)", "04-250520_1623.wav"},
        {"CH4PO", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\CH4PO\CH4PO3\Media\02-250409_1702-02.wav)", "02-250409_1702-02.wav"},
        {"MAURITO", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\MAURITO\doonetsk\08-230312_1223-01.wav)", "08-230312_1223-01.wav"},
        {"MAURITO", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\MAURITO\Mauro - Annalisa\27-230422_1115-01.wav)", "27-230422_1115-01.wav"},
        {"LIL KROW", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\LIL KROW\LIL TRAP\Media\02-240326_1809.wav)", "02-240326_1809.wav"},
        {"LIL KROW", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\LIL KROW\CADAVERE.STEMS\Media\04-VOX 1 MAIN-231228_1624.wav)", "04-VOX 1 MAIN-231228_1624.wav"},
        {"PIOTRE", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\PIOTRE\Media\02-250920_1830-01.wav)", "02-250920_1830-01.wav"},
        {"PIOTRE", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\PIOTRE\Media\01-260605_1712.wav)", "01-260605_1712.wav"},
        {"ZAIKO", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\ZAIKO\ZAIKO 1\Media\03-250715_1210.wav)", "03-250715_1210.wav"},
        {"ZAIKO", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\ZAIKO\ZAIKO 1\Media\02-250715_1114.wav)", "02-250715_1114.wav"},
        {"YOUNG MURDA", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\YOUNG MURDA\Media\01-250821_1728-01.wav)", "01-250821_1728-01.wav"},
        {"YOUNG MURDA", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\YOUNG MURDA\Media\01-250821_1802-01.wav)", "01-250821_1802-01.wav"},
        {"LELE", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\LELE\FREELELE GIUGNO\Media\01-240615_1819.wav)", "01-240615_1819.wav"},
        {"LELE", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\LELE\FREESTYLE LELE\04-230606_1726.wav)", "04-230606_1726.wav"},
        {"ADRIANO", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\ADRIANO\ADRIANO MAURI\Media\02-240110_1148.wav)", "02-240110_1148.wav"},
        {"ADRIANO", R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\ADRIANO\Media\03-251018_1124-01.wav)", "03-251018_1124-01.wav"}
    };

    std::cout << "=======================================================================\n";
    std::cout << "       171 STUDIO - PERFECTPRE VOCAL REAL-WORLD SCIENTIFIC AUDIT        \n";
    std::cout << " Testing 24 Real Vocal Takes across 12 Artists from Reaper Archive    \n";
    std::cout << "=======================================================================\n\n";

    juce::File stemsDir(R"(C:\Users\171Studio\Desktop\171_PerfectPre_Audit_Stems)");
    stemsDir.createDirectory();

    std::vector<AuditTakeResult> results;
    int overallPassed = 0;

    for (size_t tIdx = 0; tIdx < takes.size(); ++tIdx)
    {
        const auto& take = takes[tIdx];
        juce::File audioFile(take.path);
        if (!audioFile.existsAsFile())
        {
            std::cout << "[ERROR] File not found: " << take.path << "\n";
            continue;
        }

        std::unique_ptr<juce::AudioFormatReader> reader(formatManager.createReaderFor(audioFile));
        if (reader == nullptr)
        {
            std::cout << "[ERROR] Could not decode WAV: " << take.path << "\n";
            continue;
        }

        double sr = reader->sampleRate;
        int numCh = (int)reader->numChannels;
        int totalSamples = (int)reader->lengthInSamples;

        // Process up to 10 seconds of high-energy vocal audio (e.g. from 2.0s mark)
        int startSample = (int)std::min((double)totalSamples * 0.1, sr * 2.0);
        int samplesToRead = (int)std::min((double)(totalSamples - startSample), sr * 10.0);
        if (samplesToRead <= 0)
        {
            startSample = 0;
            samplesToRead = std::min(totalSamples, (int)(sr * 10.0));
        }

        // Always process in stereo (mono vocal expanded to stereo)
        juce::AudioBuffer<float> inBuffer(2, samplesToRead);
        if (numCh == 1)
        {
            juce::AudioBuffer<float> monoBuf(1, samplesToRead);
            reader->read(&monoBuf, 0, samplesToRead, startSample, true, true);
            inBuffer.copyFrom(0, 0, monoBuf, 0, 0, samplesToRead);
            inBuffer.copyFrom(1, 0, monoBuf, 0, 0, samplesToRead);
        }
        else
        {
            reader->read(&inBuffer, 0, samplesToRead, startSample, true, true);
        }

        // Measure Input Peak and RMS
        float inPeakAbs = inBuffer.getMagnitude(0, samplesToRead);
        float inPeakDb = inPeakAbs > 1e-9f ? 20.0f * std::log10(inPeakAbs) : -140.0f;
        float inRmsDb = 20.0f * std::log10(std::max(1e-9f, inBuffer.getRMSLevel(0, 0, samplesToRead)));

        // Create dry buffer copy for phase coherence test
        juce::AudioBuffer<float> dryCopy(inBuffer);

        // Setup Processor
        AudioPluginAudioProcessor processor;
        processor.prepareToPlay(sr, 512);

        // Configure Vocal Chain Preset:
        // British Preamp + Warmth + Neve HPF 80Hz + Mid Peak 3.2k + SPL De-Esser Active + Safe Ceiling
        if (auto* p = processor.getAPVTS().getParameter("preamp_flavor")) p->setValueNotifyingHost(0.0f); // British
        if (auto* p = processor.getAPVTS().getParameter("preamp_drive"))   p->setValueNotifyingHost(0.55f); // +5 dB Drive
        if (auto* p = processor.getAPVTS().getParameter("preamp_warmth")) p->setValueNotifyingHost(0.42f);
        if (auto* p = processor.getAPVTS().getParameter("diode_enable"))  p->setValueNotifyingHost(1.0f);
        if (auto* p = processor.getAPVTS().getParameter("diode_drive"))   p->setValueNotifyingHost(0.20f);
        if (auto* p = processor.getAPVTS().getParameter("eq_enable"))     p->setValueNotifyingHost(1.0f);
        if (auto* p = processor.getAPVTS().getParameter("eq_hpf"))        p->setValueNotifyingHost(0.50f); // 80 Hz
        if (auto* p = processor.getAPVTS().getParameter("eq_mid_freq"))   p->setValueNotifyingHost(0.66f); // 3.2 kHz
        if (auto* p = processor.getAPVTS().getParameter("eq_mid_gain"))   p->setValueNotifyingHost(0.60f); // +3.5 dB
        if (auto* p = processor.getAPVTS().getParameter("eq_high_gain"))  p->setValueNotifyingHost(0.56f); // +2 dB
        if (auto* p = processor.getAPVTS().getParameter("deesser_enable"))p->setValueNotifyingHost(1.0f);
        if (auto* p = processor.getAPVTS().getParameter("deesser_freq"))  p->setValueNotifyingHost(0.42f); // ~6.5 kHz
        if (auto* p = processor.getAPVTS().getParameter("deesser_reduction")) p->setValueNotifyingHost(0.65f); // Active sibilance reduction
        if (auto* p = processor.getAPVTS().getParameter("safe_ceiling_enable")) p->setValueNotifyingHost(1.0f);

        // Block-by-block processing (512 samples)
        juce::AudioBuffer<float> outBuffer(inBuffer);
        const int blockSize = 512;
        int numBlocks = samplesToRead / blockSize;

        float maxReductionTracked = 0.0f;
        double sumReductionTracked = 0.0;
        int reductionSamples = 0;

        int nanCount = 0;
        int infCount = 0;
        int denormalCount = 0;
        double dcSumL = 0.0, dcSumR = 0.0;

        for (int b = 0; b < numBlocks; ++b)
        {
            int offset = b * blockSize;
            juce::AudioBuffer<float> block(outBuffer.getArrayOfWritePointers(), 2, offset, blockSize);
            juce::MidiBuffer midi;
            processor.processBlock(block, midi);

            float redDb = std::abs(processor.getDeEsserReductionDb());
            if (redDb > maxReductionTracked) maxReductionTracked = redDb;
            sumReductionTracked += redDb;
            reductionSamples++;

            for (int ch = 0; ch < 2; ++ch)
            {
                const float* samples = block.getReadPointer(ch);
                for (int i = 0; i < blockSize; ++i)
                {
                    float s = samples[i];
                    if (std::isnan(s)) nanCount++;
                    if (std::isinf(s)) infCount++;
                    if (s != 0.0f && std::abs(s) < 1e-30f) denormalCount++;
                    if (ch == 0) dcSumL += s; else dcSumR += s;
                }
            }
        }

        float outPeakAbs = outBuffer.getMagnitude(0, numBlocks * blockSize);
        float outPeakDb = outPeakAbs > 1e-9f ? 20.0f * std::log10(outPeakAbs) : -140.0f;
        float outRmsDb = 20.0f * std::log10(std::max(1e-9f, outBuffer.getRMSLevel(0, 0, numBlocks * blockSize)));

        float truePeakDb = computeTruePeak(outBuffer);
        int latency = processor.getLatencySamples();
        float airPhaseCorr = computeAirBandPhaseCorrelation(dryCopy, outBuffer, latency);
        float dcOffsetAbs = (float)std::max(std::abs(dcSumL), std::abs(dcSumR)) / (float)(numBlocks * blockSize);
        float dcOffsetDb = dcOffsetAbs > 1e-9f ? 20.0f * std::log10(dcOffsetAbs) : -140.0f;

        bool passed = (nanCount == 0 && infCount == 0 && denormalCount == 0 &&
                       truePeakDb <= 0.0f && dcOffsetDb < -80.0f);
        if (passed) overallPassed++;

        AuditTakeResult res;
        res.artist = take.artist;
        res.filename = take.filename;
        res.sampleRate = sr;
        res.channels = numCh;
        res.durationSeconds = (double)samplesToRead / sr;
        res.peakInDb = inPeakDb;
        res.peakOutDb = outPeakDb;
        res.truePeakOutDb = truePeakDb;
        res.rmsInDb = inRmsDb;
        res.rmsOutDb = outRmsDb;
        res.maxDeEsserReductionDb = maxReductionTracked;
        res.avgDeEsserReductionDb = reductionSamples > 0 ? (float)(sumReductionTracked / reductionSamples) : 0.0f;
        res.airBandPhaseCorrelation = airPhaseCorr;
        res.dcOffsetDb = dcOffsetDb;
        res.nanCount = nanCount;
        res.infCount = infCount;
        res.denormalCount = denormalCount;
        res.passedAllChecks = passed;
        results.push_back(res);

        std::cout << "[" << std::setw(2) << (tIdx + 1) << "/24] Artist: " << std::left << std::setw(12) << take.artist
                  << " | " << std::setw(28) << take.filename
                  << " | In: " << std::fixed << std::setprecision(1) << inPeakDb << " dB"
                  << " -> Out: " << outPeakDb << " dB"
                  << " | TruePeak: " << truePeakDb << " dBFS"
                  << " | DeEsser: -" << maxReductionTracked << " dB"
                  << " | AirPhase: " << std::setprecision(3) << airPhaseCorr
                  << " | Status: " << (passed ? "PASSED [OK]" : "FAILED [X]") << "\n";

        // Export representative processed 24-bit studio WAV for all 12 artists
        if (tIdx % 2 == 0)
        {
            juce::File outWavFile = stemsDir.getChildFile(take.artist + "_" + take.filename);
            outWavFile.deleteFile();
            std::unique_ptr<juce::FileOutputStream> fileStream(outWavFile.createOutputStream());
            if (fileStream != nullptr)
            {
                juce::WavAudioFormat wavFormat;
                std::unique_ptr<juce::AudioFormatWriter> writer(
                    wavFormat.createWriterFor(fileStream.get(), sr, 2, 24, {}, 0));
                if (writer != nullptr)
                {
                    fileStream.release(); // Writer took ownership
                    writer->writeFromAudioSampleBuffer(outBuffer, 0, numBlocks * blockSize);
                }
            }
        }
    }

    std::cout << "\n=======================================================================\n";
    std::cout << "AUDIT SUMMARY: " << overallPassed << " / " << takes.size() << " VOCAL TAKES PASSED 100% OF SCIENTIFIC AUDIT CHECKS!\n";
    std::cout << "=======================================================================\n\n";

    // Write results JSON file
    std::ofstream jf(R"(C:\Users\171Studio\.gemini\antigravity\brain\09083e63-7efb-4e38-b54a-484d18d4fb1f\vocal_audit_results.json)");
    jf << "{\n  \"total_takes\": " << takes.size() << ",\n";
    jf << "  \"passed_takes\": " << overallPassed << ",\n";
    jf << "  \"results\": [\n";
    for (size_t i = 0; i < results.size(); ++i)
    {
        const auto& r = results[i];
        jf << "    {\n";
        jf << "      \"artist\": \"" << r.artist << "\",\n";
        jf << "      \"filename\": \"" << r.filename << "\",\n";
        jf << "      \"sample_rate\": " << r.sampleRate << ",\n";
        jf << "      \"channels\": " << r.channels << ",\n";
        jf << "      \"duration_s\": " << std::fixed << std::setprecision(2) << r.durationSeconds << ",\n";
        jf << "      \"peak_in_db\": " << std::setprecision(2) << r.peakInDb << ",\n";
        jf << "      \"peak_out_db\": " << r.peakOutDb << ",\n";
        jf << "      \"true_peak_out_db\": " << r.truePeakOutDb << ",\n";
        jf << "      \"rms_in_db\": " << r.rmsInDb << ",\n";
        jf << "      \"rms_out_db\": " << r.rmsOutDb << ",\n";
        jf << "      \"max_deesser_reduction_db\": " << r.maxDeEsserReductionDb << ",\n";
        jf << "      \"avg_deesser_reduction_db\": " << r.avgDeEsserReductionDb << ",\n";
        jf << "      \"air_band_phase_correlation\": " << std::setprecision(4) << r.airBandPhaseCorrelation << ",\n";
        jf << "      \"dc_offset_db\": " << std::setprecision(1) << r.dcOffsetDb << ",\n";
        jf << "      \"nan_count\": " << r.nanCount << ",\n";
        jf << "      \"inf_count\": " << r.infCount << ",\n";
        jf << "      \"denormal_count\": " << r.denormalCount << ",\n";
        jf << "      \"passed\": " << (r.passedAllChecks ? "true" : "false") << "\n";
        jf << "    }" << (i + 1 < results.size() ? "," : "") << "\n";
    }
    jf << "  ]\n}\n";
    jf.close();

    return 0;
}
