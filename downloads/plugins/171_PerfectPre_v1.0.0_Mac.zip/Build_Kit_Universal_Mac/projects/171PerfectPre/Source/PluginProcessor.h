#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include <dsp171/Common.h>
#include <dsp171/Oversampler.h>
#include <dsp171/SafetyCeiling.h>
#include <dsp171/LockFreeFIFO.h>
#include "DSP/PreampMultiFlavor.h"
#include "DSP/Neve1073EQ.h"
#include "DSP/SPLPhaseDeEsser.h"

struct PluginPreset {
    const char* name;
    float preampDrive;
    int preampFlavor;
    float preampWarmth;
    bool diodeEnable;
    float diodeDrive;
    float preampMix;
    bool eqEnable;
    int eqHpf;
    int eqLowFreq;
    float eqLowGain;
    int eqMidFreq;
    float eqMidGain;
    float eqHighGain;
    bool deEsserEnable;
    float deEsserReduction;
    int deEsserMode;
    float deEsserFreq;
    float outGain;
};

class AudioPluginAudioProcessor : public juce::AudioProcessor {
public:
    AudioPluginAudioProcessor();
    ~AudioPluginAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;

    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "PerfectPre"; }

    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int index, const juce::String& newName) override;

    juce::AudioProcessorParameter* getBypassParameter() const override {
        return apvts.getParameter("bypass");
    }

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }
    dsp171::LockFreeVisualFIFO<512>& getVisualFIFO() noexcept { return visualFIFO; }

    float getDeEsserReductionDb() const noexcept { return latestDeEsserReductionDb.load(std::memory_order_relaxed); }
    float getOutputPeak() const noexcept { return latestOutputPeak.load(std::memory_order_relaxed); }
    float getInputPeak() const noexcept { return latestInputPeak.load(std::memory_order_relaxed); }
    float getInputRMS() const noexcept { return latestInputRMS.load(std::memory_order_relaxed); }
    float getOutputRMS() const noexcept { return latestOutputRMS.load(std::memory_order_relaxed); }

    static const std::vector<PluginPreset>& getFactoryPresets();

private:
    juce::AudioProcessorValueTreeState apvts;
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    static constexpr size_t MaxChannels = 2;

    // Stadi DSP indipendenti per ciascun canale
    std::array<dsp171::PreampMultiFlavor, MaxChannels> preampStages;
    std::array<dsp171::Neve1073EQ, MaxChannels> neveEQs;
    std::array<dsp171::SPLPhaseDeEsser, MaxChannels> splDeEssers;
    std::array<dsp171::TruePeakLimiter, MaxChannels> truePeakLimiters;

    // Buffer di ritardo per Master Bypass a fase allineata e zero distorsione di leakage
    // 16384 campioni supporta qualsiasi buffer DAW fino a 8192 campioni senza wrap-around
    static constexpr size_t DryDelayBufferSize = 16384;
    std::array<std::array<float, DryDelayBufferSize>, MaxChannels> dryDelayRingBuffer{};
    size_t dryDelayWriteIndex = 0;

    // Motore Oversampling 4x da Studio per lo stadio di distorsione armonica
    dsp171::Oversampler oversampler;

    // Telemetria verso la GUI
    dsp171::LockFreeVisualFIFO<512> visualFIFO;

    // Parametri APVTS atomici
    std::atomic<float>* preampDriveParam     = nullptr;
    std::atomic<float>* preampFlavorParam    = nullptr;
    std::atomic<float>* preampWarmthParam    = nullptr;
    std::atomic<float>* preampMixParam       = nullptr;
    std::atomic<float>* diodeEnableParam     = nullptr;
    std::atomic<float>* diodeDriveParam      = nullptr;

    std::atomic<float>* eqEnableParam        = nullptr;
    std::atomic<float>* eqHpfParam           = nullptr;
    std::atomic<float>* eqLowFreqParam       = nullptr;
    std::atomic<float>* eqLowGainParam       = nullptr;
    std::atomic<float>* eqMidFreqParam       = nullptr;
    std::atomic<float>* eqMidGainParam       = nullptr;
    std::atomic<float>* eqHighGainParam      = nullptr;

    std::atomic<float>* deEsserEnableParam   = nullptr;
    std::atomic<float>* deEsserReductionParam= nullptr;
    std::atomic<float>* deEsserModeParam     = nullptr;
    std::atomic<float>* deEsserFreqParam     = nullptr;
    std::atomic<float>* deEsserDeltaParam    = nullptr;

    std::atomic<float>* outGainParam           = nullptr;
    std::atomic<float>* safeCeilingEnableParam = nullptr;
    std::atomic<float>* bypassParam            = nullptr;

    // Interpolatori di parametri per evitare zipper-noise (20 ms)
    juce::SmoothedValue<float> smoothedDrive;
    juce::SmoothedValue<float> smoothedWarmth;
    juce::SmoothedValue<float> smoothedDiodeDrive;
    juce::SmoothedValue<float> smoothedPreampMix;
    juce::SmoothedValue<float> smoothedDeEsserReduction;
    juce::SmoothedValue<float> smoothedDeEsserFreq;
    juce::SmoothedValue<float> smoothedOutGain;
    juce::SmoothedValue<float> smoothedBypass;

    std::atomic<float> latestDeEsserReductionDb{0.0f};
    std::atomic<float> latestOutputPeak{0.0f};
    std::atomic<float> latestInputPeak{0.0f};
    std::atomic<float> latestInputRMS{0.0f};
    std::atomic<float> latestOutputRMS{0.0f};

    int currentProgramIndex = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AudioPluginAudioProcessor)
};
