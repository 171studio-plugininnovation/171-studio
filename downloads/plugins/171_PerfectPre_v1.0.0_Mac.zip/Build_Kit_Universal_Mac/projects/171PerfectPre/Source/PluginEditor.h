#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <dsp171/RapidGUI.h>
#include <dsp171/BoutiqueStepperButton.h>
#include "PluginProcessor.h"
#include "BinaryData.h"

class RapidDeEsserTelemetryPanel : public juce::Component
{
public:
    RapidDeEsserTelemetryPanel() { setOpaque(false); }

    void setFrameImage(const juce::Image& img) { frameImg = img; repaint(); }
    void bind(std::function<float()> freqProv, std::function<bool()> isFemaleProv, std::function<float()> grProv)
    {
        getFreq = freqProv;
        getIsFemale = isFemaleProv;
        getGr = grProv;
    }

    void paint(juce::Graphics& g) override
    {
        auto bounds = getLocalBounds().toFloat();
        if (frameImg.isValid())
        {
            g.drawImage(frameImg, bounds, juce::RectanglePlacement::stretchToFit);
        }
        else
        {
            g.setColour(juce::Colour(0xff0d1217));
            g.fillRoundedRectangle(bounds, 4.0f);
            g.setColour(juce::Colour(0xff1e3a4b));
            g.drawRoundedRectangle(bounds, 4.0f, 1.2f);
        }

        auto inner = bounds.reduced(26.0f, 8.0f);
        float freq = getFreq ? getFreq() : 6800.0f;
        bool isFemale = getIsFemale ? getIsFemale() : false;
        float gr = getGr ? getGr() : 0.0f;

        // Mode Indicator (Left)
        auto modeRect = inner.withWidth(inner.getWidth() * 0.44f);
        g.setColour(isFemale ? juce::Colour(0xffff4d6d) : juce::Colour(0xff38bdf8));
        g.setFont(juce::FontOptions(9.5f, juce::Font::bold));
        juce::String modeStr = isFemale ? "FEMALE (7.6k)" : "MALE (6.4k)";
        g.drawText(modeStr, modeRect, juce::Justification::centredLeft, false);

        // Target Freq & Live Reduction (Right, Bright Cyan)
        auto freqRect = inner.withTrimmedLeft(inner.getWidth() * 0.42f);
        g.setColour(juce::Colour(0xff00e5ff));
        g.setFont(juce::FontOptions(9.5f, juce::Font::bold));
        juce::String freqStr;
        if (freq >= 1000.0f)
            freqStr = "FC: " + juce::String(freq / 1000.0f, 2) + "k";
        else
            freqStr = "FC: " + juce::String(std::round(freq)) + "Hz";

        if (std::abs(gr) > 0.05f)
            freqStr += " | GR: " + juce::String(gr, 1) + " dB";

        g.drawText(freqStr, freqRect, juce::Justification::centredRight, false);
    }

private:
    juce::Image frameImg;
    std::function<float()> getFreq;
    std::function<bool()> getIsFemale;
    std::function<float()> getGr;
};

class Studio171LookAndFeel : public juce::LookAndFeel_V4
{
public:
    Studio171LookAndFeel()
    {
        setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff16181f));
        setColour(juce::ComboBox::textColourId, juce::Colour(0xfff1f5f9));
        setColour(juce::ComboBox::outlineColourId, juce::Colour(0xffc5a059));
        setColour(juce::ComboBox::arrowColourId, juce::Colour(0xffd4af37));

        setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xf40f1116));
        setColour(juce::PopupMenu::textColourId, juce::Colour(0xfff1f5f9));
        setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xff2a2418));
        setColour(juce::PopupMenu::highlightedTextColourId, juce::Colour(0xffffe082));
    }

    void drawComboBox(juce::Graphics& g, int width, int height, bool isButtonDown,
                      int buttonX, int buttonY, int buttonW, int buttonH, juce::ComboBox& box) override
    {
        juce::ignoreUnused(isButtonDown);
        auto bounds = juce::Rectangle<float>(0.0f, 0.0f, (float)width, (float)height).reduced(1.0f);

        // Drop shadow
        g.setColour(juce::Colours::black.withAlpha(0.45f));
        g.fillRoundedRectangle(bounds.translated(1.0f, 2.0f), 4.0f);

        // Metallic Body Gradient
        juce::ColourGradient grad(juce::Colour(0xff1f232b), bounds.getX(), bounds.getY(),
                                 juce::Colour(0xff101217), bounds.getX(), bounds.getBottom(), false);
        g.setGradientFill(grad);
        g.fillRoundedRectangle(bounds, 4.0f);

        // Satin Gold Beveled Rim
        g.setColour(box.hasKeyboardFocus(true) ? juce::Colour(0xffffe082) : juce::Colour(0xffc5a059));
        g.drawRoundedRectangle(bounds, 4.0f, 1.4f);

        // Inner specular highlight on top rim
        g.setColour(juce::Colour(0x33ffffff));
        g.drawHorizontalLine(juce::roundToInt(bounds.getY() + 1.0f), bounds.getX() + 4.0f, bounds.getRight() - 4.0f);

        // Vertical divider before arrow
        float divX = (float)buttonX;
        g.setColour(juce::Colour(0x33c5a059));
        g.drawVerticalLine(juce::roundToInt(divX), bounds.getY() + 4.0f, bounds.getBottom() - 4.0f);

        // Arrow (Metallic Gold Chevron)
        float arrowCx = buttonX + buttonW * 0.5f;
        float arrowCy = buttonY + buttonH * 0.5f;
        float arrowW = 8.0f;
        float arrowH = 5.0f;

        juce::Path arrow;
        arrow.startNewSubPath(arrowCx - arrowW * 0.5f, arrowCy - arrowH * 0.5f);
        arrow.lineTo(arrowCx, arrowCy + arrowH * 0.5f);
        arrow.lineTo(arrowCx + arrowW * 0.5f, arrowCy - arrowH * 0.5f);

        g.setColour(juce::Colour(0xffd4af37));
        g.strokePath(arrow, juce::PathStrokeType(2.0f, juce::PathStrokeType::mitered, juce::PathStrokeType::rounded));
    }

    juce::Font getComboBoxFont(juce::ComboBox&) override
    {
        return juce::FontOptions(11.5f, juce::Font::bold);
    }

    void positionComboBoxText(juce::ComboBox& box, juce::Label& label) override
    {
        label.setBounds(8, 1, box.getWidth() - 30, box.getHeight() - 2);
        label.setFont(getComboBoxFont(box));
    }
};

class AudioPluginAudioProcessorEditor : public juce::AudioProcessorEditor,
                                        public juce::Timer,
                                        public juce::ComboBox::Listener
{
public:
    explicit AudioPluginAudioProcessorEditor(AudioPluginAudioProcessor&);
    ~AudioPluginAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void paintOverChildren(juce::Graphics&) override;
    void resized() override;
    void timerCallback() override;
    void comboBoxChanged(juce::ComboBox*) override;
    void updatePreampTheme();

private:
    AudioPluginAudioProcessor& processorRef;

    // Motore Grafico 171
    plugin_171::RapidGUI guiEngine;

    // Immagini di produzione caricate da memoria (BinaryData)
    juce::Image backplateWideImg;
    juce::Image backplateCutoutImg;
    juce::Image screenGlassOverlayImg;
    juce::Image knobBronzeImg;
    juce::Image knobRedImg;
    juce::Image knobBlueImg;
    juce::Image knobSteelImg;
    juce::Image knobConcentricSilverImg;
    juce::Image collarImg;
    juce::Image plateInputGainImg;
    juce::Image plateHpfImg;
    juce::Image plateLowShelfImg;
    juce::Image plateMidPeakImg;
    juce::Image plateHighShelfImg;
    juce::Image plateLowDualImg;
    juce::Image plateMidDualImg;
    juce::Image ringDualSelectorImg;
    juce::Image badgeDeEsserImg;
    juce::Image btnMaleFemaleOffImg;
    juce::Image btnMaleFemaleOnImg;
    juce::Image switchNeveEqOffImg;
    juce::Image switchNeveEqOnImg;
    juce::Image switchSplTactileOffImg;
    juce::Image switchSplTactileOnImg;
    juce::Image lampDiodeOffImg;
    juce::Image lampDiodeOnImg;
    juce::Image lampCeilingGreenImg;
    juce::Image lampCeilingRedImg;
    juce::Image logo171GoldImg;
    juce::Image badge171FullImg;
    juce::Image screwRackImg;
    juce::Image screenBezelHollowImg;
    juce::Image readoutFreqFrameImg;
    juce::Image lampJewelRubyOnImg;
    juce::Image lampJewelRubyOffImg;
    juce::Image switchDiodeOnImg;
    juce::Image switchDiodeOffImg;
    juce::Image switchCeilingOnImg;
    juce::Image switchCeilingOffImg;
    juce::Image plateWarmthImg;
    juce::Image plateDiodeDriveImg;
    juce::Image platePreampMixImg;
    juce::Image plateSReductionImg;
    juce::Image plateDeEsserFreqImg;
    juce::Image plateOutGainImg;

    // LookAndFeel Personalizzato Console 171
    Studio171LookAndFeel customLookAndFeel;

    // Controlli Sezione 1: PREAMP & DIODES
    juce::ComboBox flavorBox;
    plugin_171::RapidKnob inputGainKnob;
    plugin_171::RapidKnob warmthKnob;
    plugin_171::RapidKnob diodeDriveKnob;
    plugin_171::RapidKnob preampMixKnob;
    plugin_171::RapidToggleSwitch diodeToggle;

    // Controlli Sezione 2: NEVE 1073 EQ
    plugin_171::RapidKnob hpfKnob;
    plugin_171::RapidDualConcentricKnob lowDualKnob;
    plugin_171::RapidDualConcentricKnob midDualKnob;
    plugin_171::RapidKnob highGainKnob;
    plugin_171::RapidToggleSwitch eqToggle;

    // Controlli Sezione 3: SPL PHASE DE-ESSER
    plugin_171::RapidIOMonitorScreen ioMonitorScreen;
    plugin_171::RapidDeEssingScreen deEssingScreen;
    RapidDeEsserTelemetryPanel freqReadoutPanel;
    plugin_171::RapidKnob sReductionKnob;
    plugin_171::RapidKnob deEsserFreqKnob;
    plugin_171::RapidToggleSwitch maleFemaleToggle;
    plugin_171::RapidToggleSwitch deEsserToggle;
    plugin_171::RapidToggleSwitch deltaListenToggle;

    // Controlli Sezione 4: MASTER & PRESETS
    juce::ComboBox presetBox;
    std::unique_ptr<gui171::BoutiqueStepperButton> prevPresetBtn;
    std::unique_ptr<gui171::BoutiqueStepperButton> nextPresetBtn;
    plugin_171::RapidKnob outGainKnob;
    plugin_171::RapidToggleSwitch ceilingToggle;
    plugin_171::RapidBypassButton bypassButton;

    // Telemetria in tempo reale
    float latestOutRMS = 0.0f;
    float latestPeak = 0.0f;
    float latestReductionDb = 0.0f;

    // APVTS Attachments
    using SliderAttachment   = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboBoxAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using ButtonAttachment   = juce::AudioProcessorValueTreeState::ButtonAttachment;

    std::unique_ptr<SliderAttachment>   driveAttach;
    std::unique_ptr<ComboBoxAttachment> flavorAttach;
    std::unique_ptr<SliderAttachment>   warmthAttach;
    std::unique_ptr<SliderAttachment>   mixAttach;
    std::unique_ptr<ButtonAttachment>   diodeEnableAttach;
    std::unique_ptr<SliderAttachment>   diodeDriveAttach;

    std::unique_ptr<ButtonAttachment>   eqEnableAttach;
    std::unique_ptr<SliderAttachment>   hpfAttach;
    std::unique_ptr<SliderAttachment>   lowFreqAttach;
    std::unique_ptr<SliderAttachment>   lowGainAttach;
    std::unique_ptr<SliderAttachment>   midFreqAttach;
    std::unique_ptr<SliderAttachment>   midGainAttach;
    std::unique_ptr<SliderAttachment>   highGainAttach;

    std::unique_ptr<ButtonAttachment>   deEsserEnableAttach;
    std::unique_ptr<SliderAttachment>   deEsserReductionAttach;
    std::unique_ptr<ButtonAttachment>   deEsserModeAttach;
    std::unique_ptr<SliderAttachment>   deEsserFreqAttach;
    std::unique_ptr<ButtonAttachment>   deEsserDeltaAttach;

    std::unique_ptr<SliderAttachment>   outGainAttach;
    std::unique_ptr<ButtonAttachment>   ceilingAttach;
    std::unique_ptr<ButtonAttachment>   bypassAttach;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AudioPluginAudioProcessorEditor)
};
