#include <juce_gui_basics/juce_gui_basics.h>
#include "PluginProcessor.h"
#include "PluginEditor.h"

int main()
{
    juce::ScopedJuceInitialiser_GUI juceInit;

    AudioPluginAudioProcessor processor;
    std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
    if (editor == nullptr)
        return 1;

    editor->setSize(1200, 650);

    // Set Safe Ceiling ON so amber studio console button glows in the render
    if (auto* p = processor.getAPVTS().getParameter("safe_ceiling_enable"))
        p->setValueNotifyingHost(1.0f);

    // Set Diode ON so yellow studio console button glows in the render
    if (auto* p = processor.getAPVTS().getParameter("diode_enable"))
        p->setValueNotifyingHost(1.0f);

    // Set British Console Preamp (Machined Satin Bronze 171 Chicken Knob)
    if (auto* p = processor.getAPVTS().getParameter("preamp_flavor"))
        p->setValueNotifyingHost(0.0f);

    // Set De-Esser Active ON so switch and jewel lamp light up
    if (auto* p = processor.getAPVTS().getParameter("deesser_enable"))
        p->setValueNotifyingHost(1.0f);

    // Set De-Esser parameters for telemetry display
    if (auto* p = processor.getAPVTS().getParameter("deesser_reduction"))
        p->setValueNotifyingHost(0.55f);
    if (auto* p = processor.getAPVTS().getParameter("deesser_freq"))
        p->setValueNotifyingHost(0.38f);

    // Set subtle EQ gain and frequency steps to show Neve concentric knobs in action
    if (auto* p = processor.getAPVTS().getParameter("eq_hpf"))
        p->setValueNotifyingHost(0.50f); // 80 Hz
    if (auto* p = processor.getAPVTS().getParameter("eq_low_gain"))
        p->setValueNotifyingHost(0.68f);
    if (auto* p = processor.getAPVTS().getParameter("eq_mid_gain"))
        p->setValueNotifyingHost(0.32f);
    if (auto* p = processor.getAPVTS().getParameter("eq_low_freq"))
        p->setValueNotifyingHost(0.50f); // Step 2 (60 Hz)
    if (auto* p = processor.getAPVTS().getParameter("eq_mid_freq"))
        p->setValueNotifyingHost(0.66f); // Step 4 (3.2 kHz)

    // Feed simulated audio into processBlock so IO Monitor and De-Esser Screens display live levels
    juce::AudioBuffer<float> testBuffer(2, 512);
    for (int ch = 0; ch < 2; ++ch) {
        float* w = testBuffer.getWritePointer(ch);
        for (int i = 0; i < 512; ++i) {
            w[i] = std::sin(i * 0.08f) * 0.45f + std::sin(i * 0.22f) * 0.25f; // ~ -7 dBFS signal
        }
    }
    juce::MidiBuffer midi;
    processor.processBlock(testBuffer, midi);

    // Give it a moment to layout
    editor->resized();

    // Render snapshot
    juce::Image snapshot = editor->createComponentSnapshot(editor->getLocalBounds());

    const char* paths[] = {
        R"(C:\Users\171Studio\.gemini\antigravity\scratch\171PerfectPre_Assets\perfectpre_gui_render.png)",
        R"(C:\Users\171Studio\.gemini\antigravity\brain\84ca9758-e2aa-471f-afaa-226d4b35b07b\171PerfectPre_Final_GUI.png)",
        R"(C:\Users\171Studio\Desktop\171PluginInnovation - PerfectPre\PerfectPre_GUI_Preview.png)"
    };

    for (auto* p : paths)
    {
        juce::File outFile(p);
        outFile.getParentDirectory().createDirectory();
        outFile.deleteFile();
        juce::FileOutputStream stream(outFile);
        if (stream.openedOk())
        {
            juce::PNGImageFormat png;
            png.writeImageToStream(snapshot, stream);
        }
    }

    // Now render Pure Clean Transistor flavor (Flavor 3: Light Satin Steel)
    if (auto* p = processor.getAPVTS().getParameter("preamp_flavor"))
        p->setValueNotifyingHost(1.0f); // In normalized 0..1, 3/3 = 1.0f

    if (auto* customEditor = dynamic_cast<AudioPluginAudioProcessorEditor*>(editor.get()))
        customEditor->updatePreampTheme();

    editor->resized();
    juce::Image snapshotClean = editor->createComponentSnapshot(editor->getLocalBounds());

    const char* cleanPaths[] = {
        R"(C:\Users\171Studio\.gemini\antigravity\brain\84ca9758-e2aa-471f-afaa-226d4b35b07b\perfectpre_clean_render.png)",
        R"(C:\Users\171Studio\.gemini\antigravity\scratch\171PerfectPre_Assets\perfectpre_clean_render.png)"
    };

    for (auto* p : cleanPaths)
    {
        juce::File outFile(p);
        outFile.getParentDirectory().createDirectory();
        outFile.deleteFile();
        juce::FileOutputStream stream(outFile);
        if (stream.openedOk())
        {
            juce::PNGImageFormat png;
            png.writeImageToStream(snapshotClean, stream);
        }
    }

    return 0;
}
