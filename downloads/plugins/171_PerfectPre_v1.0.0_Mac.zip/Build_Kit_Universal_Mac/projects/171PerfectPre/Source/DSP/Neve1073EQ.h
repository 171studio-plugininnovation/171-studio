#pragma once
#include <cmath>
#include <array>
#include <algorithm>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>

namespace dsp171 {

// =============================================================================
// Cytomic Zero-Delay Feedback State Variable Filter (ZDF SVF)
// Pure Andy Simper analytical formulation (Cytomic DSP Technical Papers).
// Exact analog-matched frequency and transient response for Bell, Low Shelf,
// High Shelf and High-Pass. Zero ringing, zero overshoot, zero denormals.
// =============================================================================
struct CytomicSVF {
    float s1 = 0.0f;
    float s2 = 0.0f;

    float a1 = 0.0f;
    float a2 = 0.0f;
    float a3 = 0.0f;
    float m0 = 1.0f;
    float m1 = 0.0f;
    float m2 = 0.0f;

    void reset() noexcept {
        s1 = 0.0f;
        s2 = 0.0f;
    }

    // Configure as Peaking Bell Filter (Cytomic exact symmetrical analog bell)
    void setBell(float fc, float gainDb, float Q, float sampleRate) noexcept {
        const float clampedFc = std::clamp(fc, 20.0f, sampleRate * 0.490f);
        const float g = std::tan(PI * clampedFc / sampleRate);
        const float A = std::pow(10.0f, gainDb / 40.0f);
        const float safeQ = std::clamp(Q, 0.40f, 2.50f);
        const float k = 1.0f / (safeQ * A);

        a1 = 1.0f / (1.0f + g * (g + k));
        a2 = g * a1;
        a3 = g * a2;

        m0 = 1.0f;
        m1 = k * (A * A - 1.0f);
        m2 = 0.0f;
    }

    // Configure as Low Shelf (Cytomic exact Butterworth low shelf, zero overshoot)
    void setLowShelf(float fc, float gainDb, float Q, float sampleRate) noexcept {
        const float clampedFc = std::clamp(fc, 10.0f, sampleRate * 0.490f);
        const float A = std::pow(10.0f, gainDb / 40.0f);
        const float g = std::tan(PI * clampedFc / sampleRate) / std::sqrt(A);
        const float safeQ = std::max(0.2f, Q);
        const float k = 1.0f / safeQ;

        a1 = 1.0f / (1.0f + g * (g + k));
        a2 = g * a1;
        a3 = g * a2;

        m0 = 1.0f;
        m1 = k * (A - 1.0f);
        m2 = A * A - 1.0f;
    }

    // Configure as High Shelf (Cytomic exact Butterworth high shelf, zero overshoot)
    void setHighShelf(float fc, float gainDb, float Q, float sampleRate) noexcept {
        const float clampedFc = std::clamp(fc, 100.0f, sampleRate * 0.490f);
        const float A = std::pow(10.0f, gainDb / 40.0f);
        const float g = std::tan(PI * clampedFc / sampleRate) * std::sqrt(A);
        const float safeQ = std::max(0.2f, Q);
        const float k = 1.0f / safeQ;

        a1 = 1.0f / (1.0f + g * (g + k));
        a2 = g * a1;
        a3 = g * a2;

        m0 = A * A;
        m1 = k * (1.0f - A) * A;
        m2 = 1.0f - A * A;
    }

    // Configure as 2nd-order High-Pass (Q = 1.0 for authentic Neve LC ladder shoulder)
    void setHPF(float fc, float Q, float sampleRate) noexcept {
        const float clampedFc = std::clamp(fc, 10.0f, sampleRate * 0.490f);
        const float g = std::tan(PI * clampedFc / sampleRate);
        const float safeQ = std::max(0.2f, Q);
        const float k = 1.0f / safeQ;

        a1 = 1.0f / (1.0f + g * (g + k));
        a2 = g * a1;
        a3 = g * a2;

        m0 = 1.0f;
        m1 = -k;
        m2 = -1.0f;
    }

    inline float process(float v0) noexcept {
        const float v1 = a1 * s1 + a2 * (v0 - s2);
        const float v2 = s2 + a2 * s1 + a3 * (v0 - s2);
        s1 = 2.0f * v1 - s1;
        s2 = 2.0f * v2 - s2;

        // Anti-denormal guard
        if (std::abs(s1) < 1.0e-25f) s1 = 0.0f;
        if (std::abs(s2) < 1.0e-25f) s2 = 0.0f;

        return m0 * v0 + m1 * v1 + m2 * v2;
    }
};

// 1-Pole ZDF High-Pass (completes the authentic 18 dB/oct 3-pole Neve HPF ladder)
struct ZDFOnePoleHP {
    float s = 0.0f;
    float g = 0.0f;

    void reset() noexcept {
        s = 0.0f;
    }

    void setCutoff(float fc, float sampleRate) noexcept {
        const float clampedFc = std::clamp(fc, 10.0f, sampleRate * 0.490f);
        g = std::tan(PI * clampedFc / sampleRate);
    }

    inline float process(float in) noexcept {
        const float hp = (in - s) / (1.0f + g);
        const float v = g * hp;
        s = v + (v + s);
        if (std::abs(s) < 1.0e-25f) s = 0.0f;
        return hp;
    }
};

// =============================================================================
// Authentic Neve 1073 Channel Equalizer (Rupert Neve Schematic EK20021/EK20022)
// - High Shelf 12 kHz: Silky Baxandall 12 kHz Air band
// - Mid Band: Tapped Ferrite Pot-Core RLC Tank (T1684) with Musical Proportional-Q (0.65 - 1.25)
// - Low Band: Deep Pillowy Inductor Baxandall Shelf (35, 60, 110, 220 Hz)
// - HPF: 18 dB/octave 3-Pole LC Ladder Filter with Analog Insertion Shoulder
// - Continuous 20 ms Parameter Smoothing (Zero Zipper Noise / Pops)
// =============================================================================
class Neve1073EQ {
public:
    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        smoothCoeff = 1.0f - std::exp(-1.0f / (0.020f * sr));
        reset();
    }

    void reset() noexcept {
        hpfSVF.reset();
        hpfPole.reset();
        lowShelfSVF.reset();
        midPeakSVF.reset();
        highShelfSVF.reset();

        lastHpfIdx = -1;
        lastLowFreqIdx = -1;
        curLowGainDb = 0.0f;
        lastMidFreqIdx = -1;
        curMidGainDb = 0.0f;
        curHighGainDb = 0.0f;
    }

    inline float processSample(float in, bool eqEnabled,
                               int hpfIdx, int lowFreqIdx, float targetLowGainDb,
                               int midFreqIdx, float targetMidGainDb, float targetHighGainDb) noexcept
    {
        // Continuous 20 ms parameter smoothing to eliminate zipper clicks
        curLowGainDb  += smoothCoeff * (targetLowGainDb  - curLowGainDb);
        curMidGainDb  += smoothCoeff * (targetMidGainDb  - curMidGainDb);
        curHighGainDb += smoothCoeff * (targetHighGainDb - curHighGainDb);

        if (!eqEnabled) return in;

        updateCoefficientsIfNeeded(hpfIdx, lowFreqIdx, curLowGainDb, midFreqIdx, curMidGainDb, curHighGainDb);

        float s = in;

        // 1. HPF 18 dB/octave (LC Ladder with subtle analog shoulder)
        if (hpfIdx > 0) {
            s = hpfPole.process(hpfSVF.process(s));
        }

        // 2. Low Shelf: Deep, pillowy, smooth analog shelf (Zero resonant boom)
        if (lowFreqIdx > 0 && std::abs(curLowGainDb) > 0.02f) {
            s = lowShelfSVF.process(s);
        }

        // 3. Mid Peak: Tapped Ferrite Pot-Core RLC Tank with gentle Proportional-Q (0.65 - 1.25)
        // Clean linear Cytomic formulation: zero harsh clipping, zero buzzing!
        if (midFreqIdx > 0 && std::abs(curMidGainDb) > 0.02f) {
            s = midPeakSVF.process(s);
        }

        // 4. High Shelf 12 kHz: Silky smooth air shelf
        if (std::abs(curHighGainDb) > 0.02f) {
            s = highShelfSVF.process(s);
        }

        return s;
    }

private:
    void updateCoefficientsIfNeeded(int hpfIdx, int lowFreqIdx, float lowGainDb,
                                    int midFreqIdx, float midGainDb, float highGainDb) noexcept
    {
        // 1. HPF (Off, 50, 80, 160, 300 Hz)
        if (hpfIdx != lastHpfIdx) {
            lastHpfIdx = hpfIdx;
            if (hpfIdx > 0) {
                constexpr std::array<float, 5> freqs = { 0.0f, 50.0f, 80.0f, 160.0f, 300.0f };
                const float fc = freqs[static_cast<size_t>(std::clamp(hpfIdx, 0, 4))];
                // Q = 0.95 gives the authentic gentle passive inductor insertion bump (+0.2 dB)
                hpfSVF.setHPF(fc, 0.95f, sr);
                hpfPole.setCutoff(fc, sr);
            } else {
                hpfSVF.reset();
                hpfPole.reset();
            }
        }

        // 2. Low Shelf (Off, 35, 60, 110, 220 Hz)
        if (lowFreqIdx != lastLowFreqIdx) {
            lastLowFreqIdx = lowFreqIdx;
            if (lowFreqIdx == 0) lowShelfSVF.reset();
        }
        if (lowFreqIdx > 0) {
            constexpr std::array<float, 5> lowFreqs = { 110.0f, 35.0f, 60.0f, 110.0f, 220.0f };
            const float lowFc = lowFreqs[static_cast<size_t>(std::clamp(lowFreqIdx, 0, 4))];
            // Q = 0.7071 (Butterworth maximally flat shelf - zero unnatural resonant overshoot)
            lowShelfSVF.setLowShelf(lowFc, lowGainDb, 0.7071f, sr);
        }

        // 3. Mid Peak (Off, 360, 700, 1600, 3200, 4800, 7200 Hz)
        if (midFreqIdx != lastMidFreqIdx) {
            lastMidFreqIdx = midFreqIdx;
            if (midFreqIdx == 0) midPeakSVF.reset();
        }
        if (midFreqIdx > 0) {
            constexpr std::array<float, 7> midFreqs = { 1600.0f, 360.0f, 700.0f, 1600.0f, 3200.0f, 4800.0f, 7200.0f };
            const float midFc = midFreqs[static_cast<size_t>(std::clamp(midFreqIdx, 0, 6))];
            // Authentic Neve Proportional-Q: starts very wide at 0.65 and gently tightens to 1.25 at full +18 dB
            // Eliminates the sharp whistling laser-beam resonance at 360 Hz & 3.2 kHz!
            const float qVal = 0.65f + 0.60f * (std::abs(midGainDb) / 18.0f);
            midPeakSVF.setBell(midFc, midGainDb, qVal, sr);
        }

        // 4. High Shelf 12 kHz: Fixed 12 kHz Baxandall Air Band
        // Q = 0.7071 for silky, pristine top end
        highShelfSVF.setHighShelf(12000.0f, highGainDb, 0.7071f, sr);
    }

    float sr = 44100.0f;
    float smoothCoeff = 0.0025f;
    float curLowGainDb = 0.0f;
    float curMidGainDb = 0.0f;
    float curHighGainDb = 0.0f;

    CytomicSVF hpfSVF;
    ZDFOnePoleHP hpfPole;
    CytomicSVF lowShelfSVF;
    CytomicSVF midPeakSVF;
    CytomicSVF highShelfSVF;

    int lastHpfIdx = -1;
    int lastLowFreqIdx = -1;
    int lastMidFreqIdx = -1;
};

} // namespace dsp171
