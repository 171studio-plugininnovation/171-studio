#pragma once
#include <cmath>
#include <algorithm>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include "Neve1073EQ.h"

namespace dsp171 {

enum class SPLDeEsserMode : int {
    Female = 0, // Natural female sibilance pocket (narrow focus Q=1.15, high reference)
    Male   = 1, // Deep male sibilance pocket (broad focus Q=0.75, chest reference)
    Custom = 2  // Fully continuous custom frequency tuning
};

// Normalized 0 dB Peak Zero-Delay Feedback Bandpass Filter
struct ZDFBandpassFilter {
    float s1 = 0.0f;
    float s2 = 0.0f;
    float a1 = 0.0f;
    float a2 = 0.0f;
    float a3 = 0.0f;
    float k  = 1.0f;

    void reset() noexcept {
        s1 = 0.0f;
        s2 = 0.0f;
    }

    void setParameters(float fc, float Q, float sampleRate) noexcept {
        const float clampedFc = std::clamp(fc, 20.0f, sampleRate * 0.490f);
        const float g = std::tan(PI * clampedFc / sampleRate);
        const float safeQ = std::max(0.2f, Q);
        k = 1.0f / safeQ;
        a1 = 1.0f / (1.0f + g * (g + k));
        a2 = g * a1;
        a3 = g * a2;
    }

    inline float process(float v0) noexcept {
        const float v1 = a1 * s1 + a2 * (v0 - s2);
        const float v2 = s2 + a2 * s1 + a3 * (v0 - s2);
        s1 = 2.0f * v1 - s1;
        s2 = 2.0f * v2 - s2;

        if (std::abs(s1) < 1.0e-25f) s1 = 0.0f;
        if (std::abs(s2) < 1.0e-25f) s2 = 0.0f;

        // Peak gain at fc is strictly 1.000 (0 dB)
        return k * v1;
    }
};

// =============================================================================
// Authentic SPL Differential Phase De-Esser (German Patent DE4110355A1 Modeling)
// - True Log-Domain Differential Sidechain with Absolute Sibilance Gate Floor
// - Prevents false-triggering and clamping on quiet phrases (e.g. -48 dBFS floor)
// - Phase-aligned differential cancellation without audible whistling or comb-notching
// - Full Cross-Coupled Stereo Linking (100% Phantom-Center Soundstage Integrity)
// - Dual-Stage Ballistics (0.6 ms Attack, 15 ms / 60 ms Program-Dependent Release)
// - Directly responsive continuous frequency tuning (4.5 kHz - 11.5 kHz)
// =============================================================================
class SPLPhaseDeEsser {
public:
    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);

        // Fast attack to catch initial sibilant consonant transient (0.6 ms)
        alphaAtt = 1.0f - std::exp(-1.0f / (0.0006f * sr));
        // Dual-stage release: fast component (15 ms) + smooth tail (60 ms)
        alphaRelFast = 1.0f - std::exp(-1.0f / (0.0150f * sr));
        alphaRelSlow = 1.0f - std::exp(-1.0f / (0.0600f * sr));

        // Presence reference band detector (1.0 ms attack, 25 ms release)
        alphaRefAtt = 1.0f - std::exp(-1.0f / (0.0010f * sr));
        alphaRefRel = 1.0f - std::exp(-1.0f / (0.0250f * sr));

        refSVF.setParameters(2400.0f, 0.70f, sr);
        sibSVF.setParameters(7000.0f, 0.90f, sr);

        reset();
    }

    void reset() noexcept {
        sibSVF.reset();
        refSVF.reset();
        sibEnv = 0.0f;
        refEnv = 0.0f;
        gainReduction = 0.0f;
        currentReductionDb = 0.0f;
        lastMode = static_cast<SPLDeEsserMode>(-1);
        lastFreq = -1.0f;
    }

    inline float computeCancelGain(float in, bool deEsserEnabled, float sReduction01,
                                   SPLDeEsserMode mode, float customFreqHz, float& outSibBand) noexcept
    {
        if (!deEsserEnabled || sReduction01 < 0.005f) {
            currentReductionDb = 0.0f;
            outSibBand = 0.0f;
            gainReduction = 0.0f;
            return 0.0f;
        }

        updateFilterIfNeeded(mode, customFreqHz);

        // 1. Isolate Sibilance Band with tuned ZDF filter
        outSibBand = sibSVF.process(in);

        // 2. Isolate Vocal Presence Reference Band
        const float refBand = refSVF.process(in);

        // 3. Peak / Envelope Detection
        const float absSib = std::abs(outSibBand);
        const float absRef = std::abs(refBand);

        if (absSib > sibEnv) {
            sibEnv += alphaAtt * (absSib - sibEnv);
        } else {
            const float alpha = (sibEnv > 0.05f) ? alphaRelFast : alphaRelSlow;
            sibEnv += alpha * (absSib - sibEnv);
        }

        if (absRef > refEnv) {
            refEnv += alphaRefAtt * (absRef - refEnv);
        } else {
            refEnv += alphaRefRel * (absRef - refEnv);
        }

        // 4. Differential Evaluation with Absolute Sibilance Gate Floor
        // Hardware Patent DE4110355A1: Inhibits cancellation if absolute sibilance is below -48 dBFS
        constexpr float sibilanceGateFloor = 0.00398f; // -48 dBFS
        constexpr float eps = 1.0e-5f;
        float targetCancel = 0.0f;

        if (sibEnv >= sibilanceGateFloor) {
            const float sibDb = 20.0f * std::log10(sibEnv + eps);
            const float refDb = 20.0f * std::log10(refEnv + eps);
            const float diffDb = sibDb - refDb;

            // Dynamic differential threshold:
            // At sReduction = 0.0: Thresh = -2 dB
            // At sReduction = 1.0: Thresh = -24 dB
            const float thresholdDb = -2.0f - (sReduction01 * 22.0f);
            constexpr float kneeWidthDb = 4.0f;

            float excessDb = 0.0f;
            if (diffDb > thresholdDb + (kneeWidthDb * 0.5f)) {
                excessDb = diffDb - thresholdDb;
            } else if (diffDb > thresholdDb - (kneeWidthDb * 0.5f)) {
                const float d = diffDb - (thresholdDb - kneeWidthDb * 0.5f);
                excessDb = (d * d) / (2.0f * kneeWidthDb);
            }

            if (excessDb > 0.0f) {
                // Musical maximum 14 dB cancellation to eliminate comb whistling
                const float cancelDb = std::min(14.0f, excessDb * 0.75f * (0.6f + sReduction01));
                targetCancel = 1.0f - std::pow(10.0f, -cancelDb / 20.0f);
            }
        }

        // Smooth gain reduction transitions
        if (targetCancel > gainReduction) {
            gainReduction += alphaAtt * (targetCancel - gainReduction);
        } else {
            gainReduction += alphaRelFast * (targetCancel - gainReduction);
        }

        gainReduction = std::clamp(gainReduction, 0.0f, 0.80f);
        currentReductionDb = (gainReduction > 0.001f) ? 20.0f * std::log10(1.0f - gainReduction) : 0.0f;

        return gainReduction;
    }

    inline float applyCancellation(float in, float sibBand, float cancelGain, bool deltaListen) noexcept {
        if (deltaListen) {
            return cancelGain * sibBand;
        }
        return in - (cancelGain * sibBand);
    }

    inline float processSample(float in, bool deEsserEnabled, float sReduction01,
                               SPLDeEsserMode mode, float customFreqHz, bool deltaListen) noexcept
    {
        float sibBand = 0.0f;
        const float cancelGain = computeCancelGain(in, deEsserEnabled, sReduction01, mode, customFreqHz, sibBand);
        return applyCancellation(in, sibBand, cancelGain, deltaListen);
    }

    static inline void processStereoPair(SPLPhaseDeEsser& left, SPLPhaseDeEsser& right,
                                         float inL, float inR, float& outL, float& outR,
                                         bool deEsserEnabled, float sReduction01,
                                         SPLDeEsserMode mode, float customFreqHz, bool deltaListen) noexcept
    {
        if (!deEsserEnabled || sReduction01 < 0.005f) {
            left.currentReductionDb = 0.0f;
            right.currentReductionDb = 0.0f;
            outL = inL;
            outR = inR;
            return;
        }

        left.updateFilterIfNeeded(mode, customFreqHz);
        right.updateFilterIfNeeded(mode, customFreqHz);

        // 1. Isolate Sibilance and Reference Bands
        const float sibL = left.sibSVF.process(inL);
        const float sibR = right.sibSVF.process(inR);

        const float refL = left.refSVF.process(inL);
        const float refR = right.refSVF.process(inR);

        // 2. Cross-Coupled Linked Envelope Detection
        const float absSib = std::max(std::abs(sibL), std::abs(sibR));
        const float absRef = std::max(std::abs(refL), std::abs(refR));

        if (absSib > left.sibEnv) {
            left.sibEnv += left.alphaAtt * (absSib - left.sibEnv);
        } else {
            const float alpha = (left.sibEnv > 0.05f) ? left.alphaRelFast : left.alphaRelSlow;
            left.sibEnv += alpha * (absSib - left.sibEnv);
        }
        right.sibEnv = left.sibEnv;

        if (absRef > left.refEnv) {
            left.refEnv += left.alphaRefAtt * (absRef - left.refEnv);
        } else {
            left.refEnv += left.alphaRefRel * (absRef - left.refEnv);
        }
        right.refEnv = left.refEnv;

        // 3. Differential Evaluation with Absolute Gate Floor
        constexpr float sibilanceGateFloor = 0.00398f; // -48 dBFS
        constexpr float eps = 1.0e-5f;
        float targetCancel = 0.0f;

        if (left.sibEnv >= sibilanceGateFloor) {
            const float sibDb = 20.0f * std::log10(left.sibEnv + eps);
            const float refDb = 20.0f * std::log10(left.refEnv + eps);
            const float diffDb = sibDb - refDb;

            const float thresholdDb = -2.0f - (sReduction01 * 22.0f);
            constexpr float kneeWidthDb = 4.0f;

            float excessDb = 0.0f;
            if (diffDb > thresholdDb + (kneeWidthDb * 0.5f)) {
                excessDb = diffDb - thresholdDb;
            } else if (diffDb > thresholdDb - (kneeWidthDb * 0.5f)) {
                const float d = diffDb - (thresholdDb - kneeWidthDb * 0.5f);
                excessDb = (d * d) / (2.0f * kneeWidthDb);
            }

            if (excessDb > 0.0f) {
                const float cancelDb = std::min(14.0f, excessDb * 0.75f * (0.6f + sReduction01));
                targetCancel = 1.0f - std::pow(10.0f, -cancelDb / 20.0f);
            }
        }

        if (targetCancel > left.gainReduction) {
            left.gainReduction += left.alphaAtt * (targetCancel - left.gainReduction);
        } else {
            left.gainReduction += left.alphaRelFast * (targetCancel - left.gainReduction);
        }

        left.gainReduction = std::clamp(left.gainReduction, 0.0f, 0.80f);
        right.gainReduction = left.gainReduction;

        const float reductionDb = (left.gainReduction > 0.001f) ? 20.0f * std::log10(1.0f - left.gainReduction) : 0.0f;
        left.currentReductionDb = reductionDb;
        right.currentReductionDb = reductionDb;

        outL = left.applyCancellation(inL, sibL, left.gainReduction, deltaListen);
        outR = right.applyCancellation(inR, sibR, left.gainReduction, deltaListen);
    }

    float getCurrentReductionDb() const noexcept { return currentReductionDb; }

private:
    void updateFilterIfNeeded(SPLDeEsserMode mode, float customFreqHz) noexcept {
        // ALWAYS honor the frequency knob!
        const float targetFreq = std::clamp(customFreqHz, 4000.0f, 11500.0f);

        float sibilanceQ = 0.90f;
        float refFreq = 2200.0f;
        float refQ = 0.70f;

        if (mode == SPLDeEsserMode::Female) {
            // Female mode: tighter focus on upper sibilants, higher vocal reference
            sibilanceQ = 1.15f;
            refFreq = 2800.0f;
            refQ = 0.75f;
        } else if (mode == SPLDeEsserMode::Male) {
            // Male mode: wider focus on deep sibilants, chest/formant reference
            sibilanceQ = 0.75f;
            refFreq = 1800.0f;
            refQ = 0.65f;
        }

        if (mode != lastMode || std::abs(targetFreq - lastFreq) > 3.0f) {
            lastMode = mode;
            lastFreq = targetFreq;
            sibSVF.setParameters(targetFreq, sibilanceQ, sr);
            refSVF.setParameters(refFreq, refQ, sr);
        }
    }

    float sr = 44100.0f;
    float alphaAtt = 0.05f;
    float alphaRelFast = 0.01f;
    float alphaRelSlow = 0.003f;
    float alphaRefAtt = 0.03f;
    float alphaRefRel = 0.004f;

    float sibEnv = 0.0f;
    float refEnv = 0.0f;
    float gainReduction = 0.0f;
    float currentReductionDb = 0.0f;

    SPLDeEsserMode lastMode = static_cast<SPLDeEsserMode>(-1);
    float lastFreq = -1.0f;

    ZDFBandpassFilter sibSVF;
    ZDFBandpassFilter refSVF;
};

} // namespace dsp171
