# 🎚️ DOSSIER TECNICO DI TRASPOSIZIONE — PERFECTPRE
### Multi-Flavor Console Preamplifier, Discrete EQ & Phase De-Esser per Apple macOS

**Progetto:** 171 PerfectPre (`v1.0.0`)  
**Architettura:** Universal Binary Fat (`arm64` Apple Silicon M1-M4 + `x86_64` Intel)  
**Deployment Target Minimo:** macOS 11.0 Big Sur  
**Approvato da:** Il Direttore  
**Coordinamento:** `dsp-hire-manager`, `sat-neve-specialist`, `sat-api-specialist` & `apple-macos-engineer`  

---

## 1. SPECIFICHE FORMATI & METADATI APPLE AUDIOUNIT

| Parametro | Valore Configurato | Specifiche per DAW macOS |
|---|---|---|
| **AudioUnit Type** | `kAudioUnitType_Effect` (`'aufx'`) | Inseribile come preamplificatore di canale in **Logic Pro** e GarageBand |
| **Manufacturer Code** | `'171P'` | Conforme alle specifiche Apple (include almeno una maiuscola) |
| **Plugin Code / Subtype** | `'171V'` | Identificativo univoco a 4 caratteri per scansione AU |
| **Target Formati Mac** | **AU (`.component`)**, **VST3 (`.vst3`)**, **Standalone (`.app`)** | AU per Logic Pro; VST3 per Ableton, Cubase, Studio One, Reaper, FL |
| **Sicurezza Gatekeeper** | Hardened Runtime attivo | Flag `--options runtime` + entitlements JIT e Unsigned Memory |

---

## 2. MODELLAZIONE DSP ANALOGICA SU APPLE SILICON (M1–M4)

PerfectPre racchiude il calore e il punch dei banchi analogici più famosi della storia:

1. **Preamp Multi-Flavor a 5 Modalità Selezionabili**:
   - **British Iron (Neve 1073)**: Trasformatore Marinair con enfasi $H_2/H_3$ calda e rotonda.
   - **American Punch (API 2520)**: Op-amp discreto ad alto slew-rate con punch percussivo.
   - **Tube Sheen (Avalon VT-737sp)**: Valvole doppio triodo 6922 con brillantezza aperta oltre i 10 kHz.
   - **Lundahl ISA (Focusrite ISA 110)**: Trasformatore in mu-metal ad alta trasparenza e dettaglio.
   - **Modern Tape (Studer A800)**: Isteresi magnetica su nastro da 2 pollici con morbida compressione HF.
2. **Neve 1073 Discrete EQ**:
   - Equalizzatore a induttanze passive con campana delle medie musicale e shelf delle alte a 12 kHz.
3. **SPL Phase De-Esser**:
   - Soppressione delle sibilanti tramite cancellazione di fase dinamica invertita, eliminando ogni opacità acustica.

---

## 3. INTERFACCIA RETINA A 60 FPS (BOUTIQUE LUXURY)

- **Targhette Serigrafate in Ottone Satinato**: Asset incisi in metallo spazzolato per ogni controllo (`plate_diode_drive.png`, `plate_preamp_mix.png`, `plate_s_reduction.png`).
- **Indicatori VU Meter Vintage**: Controllo istantaneo della saturazione e dei livelli I/O con precisione balistica a 60 FPS.
- **Rendering Asincrono Liquid Retina**: Perfetta risposta grafica senza sovraccaricare la GPU unificata Apple Silicon.

---

## 4. COMANDO DI COMPILAZIONE RAPIDA

```bash
# Esegui da terminale Mac:
./scripts/build_171perfectpre_mac.sh

# Validazione Apple auval per Logic Pro:
auval -v aufx 171V 171P
```
