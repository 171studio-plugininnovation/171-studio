#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <dsp171/ScopedDenormalDisabler.h>

const std::vector<PluginPreset>& AudioPluginAudioProcessor::getFactoryPresets() {
    static const std::vector<PluginPreset> presets = {
        // Name, Drive, Flavor, Warmth, DiodeOn, DiodeDrv, Mix, EqOn, HPF, LFreq, LGain, MFreq, MGain, HGain, DeEssOn, DeEssRed, DeEssMode, DeEssFreq, OutGain
        { "01 | British Golden Lead Vocal",    4.0f, 0, 0.40f, false, 0.0f, 1.0f, true, 2, 2,  1.5f, 4,  2.5f,  3.0f, true, 0.45f, 0, 7600.0f, -1.0f },
        { "02 | American Tube Sparkle Guitar", 6.5f, 1, 0.50f, false, 0.0f, 1.0f, true, 1, 3, -1.0f, 5,  3.0f,  4.5f, false, 0.0f, 1, 6400.0f, -2.0f },
        { "03 | Vintage Germanium Drum Punch", 8.0f, 2, 0.65f, true,  0.4f, 0.85f,true, 1, 2,  3.5f, 2, -2.0f,  2.0f, false, 0.0f, 1, 6400.0f, -3.0f },
        { "04 | Clean Master Console Polish",  1.5f, 3, 0.15f, false, 0.0f, 1.0f, true, 0, 1,  0.8f, 3,  0.5f,  1.5f, true, 0.20f, 0, 7600.0f, -0.2f },
        { "05 | Diode Crunch Rock Vocal",      9.0f, 0, 0.45f, true,  0.75f, 0.9f, true, 2, 3,  1.0f, 5,  4.0f,  2.0f, true, 0.60f, 1, 6400.0f, -4.5f },
        { "06 | Acoustic Guitar 12k Air Sheen",2.0f, 1, 0.25f, false, 0.0f, 1.0f, true, 2, 1, -2.0f, 3, -1.5f,  5.0f, true, 0.30f, 0, 8000.0f, -0.5f },
        { "07 | Sibilance Hunter (SPL Clamp)", 2.0f, 0, 0.20f, false, 0.0f, 1.0f, true, 1, 2,  0.0f, 4,  0.0f,  0.0f, true, 0.75f, 0, 7600.0f,  0.0f },
        { "08 | Heavy Transformer Bass",       7.5f, 0, 0.70f, true,  0.3f, 1.0f, true, 0, 2,  4.0f, 2,  1.5f, -1.0f, false, 0.0f, 1, 6400.0f, -3.0f }
    };
    return presets;
}

AudioPluginAudioProcessor::AudioPluginAudioProcessor()
    : AudioProcessor(BusesProperties()
                     .withInput("Input", juce::AudioChannelSet::stereo(), true)
                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "Parameters", createParameterLayout())
{
    preampDriveParam      = apvts.getRawParameterValue("preamp_drive");
    preampFlavorParam     = apvts.getRawParameterValue("preamp_flavor");
    preampWarmthParam     = apvts.getRawParameterValue("preamp_warmth");
    preampMixParam        = apvts.getRawParameterValue("preamp_mix");
    diodeEnableParam      = apvts.getRawParameterValue("diode_enable");
    diodeDriveParam       = apvts.getRawParameterValue("diode_drive");

    eqEnableParam         = apvts.getRawParameterValue("eq_enable");
    eqHpfParam            = apvts.getRawParameterValue("eq_hpf");
    eqLowFreqParam        = apvts.getRawParameterValue("eq_low_freq");
    eqLowGainParam        = apvts.getRawParameterValue("eq_low_gain");
    eqMidFreqParam        = apvts.getRawParameterValue("eq_mid_freq");
    eqMidGainParam        = apvts.getRawParameterValue("eq_mid_gain");
    eqHighGainParam       = apvts.getRawParameterValue("eq_high_gain");

    deEsserEnableParam    = apvts.getRawParameterValue("deesser_enable");
    deEsserReductionParam = apvts.getRawParameterValue("deesser_reduction");
    deEsserModeParam      = apvts.getRawParameterValue("deesser_mode");
    deEsserFreqParam      = apvts.getRawParameterValue("deesser_freq");
    deEsserDeltaParam     = apvts.getRawParameterValue("deesser_delta");

    outGainParam           = apvts.getRawParameterValue("out_gain");
    safeCeilingEnableParam = apvts.getRawParameterValue("safe_ceiling_enable");
    bypassParam            = apvts.getRawParameterValue("bypass");
    visualFIFO.reset();
}

AudioPluginAudioProcessor::~AudioPluginAudioProcessor() = default;

juce::AudioProcessorValueTreeState::ParameterLayout AudioPluginAudioProcessor::createParameterLayout() {
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // 1. PREAMP & DIODES
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"preamp_drive", 1}, "Preamp Drive",
        juce::NormalisableRange<float>(-18.0f, 24.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"preamp_flavor", 1}, "Preamp Flavor",
        juce::StringArray{"British Vintage (Neve)", "American Tube (6L6)", "Vintage Germanium", "Clean Studio"}, 0));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"preamp_warmth", 1}, "Warmth / Harmonics",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.35f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"preamp_mix", 1}, "Preamp Mix",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 1.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"diode_enable", 1}, "Diode Stage On/Off", false));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"diode_drive", 1}, "Diode Crunch",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.50f));

    // 2. NEVE 1073 EQ
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"eq_enable", 1}, "EQ In/Out", true));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"eq_hpf", 1}, "Neve HPF",
        juce::StringArray{"Off", "50 Hz", "80 Hz", "160 Hz", "300 Hz"}, 0));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"eq_low_freq", 1}, "Low Shelf Freq",
        juce::StringArray{"Off", "35 Hz", "60 Hz", "110 Hz", "220 Hz"}, 2));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"eq_low_gain", 1}, "Low Shelf Gain",
        juce::NormalisableRange<float>(-16.0f, 16.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"eq_mid_freq", 1}, "Mid Peak Freq",
        juce::StringArray{"Off", "360 Hz", "700 Hz", "1.6 kHz", "3.2 kHz", "4.8 kHz", "7.2 kHz"}, 4));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"eq_mid_gain", 1}, "Mid Peak Gain",
        juce::NormalisableRange<float>(-18.0f, 18.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"eq_high_gain", 1}, "High Shelf 12k Gain",
        juce::NormalisableRange<float>(-16.0f, 16.0f, 0.1f), 0.0f));

    // 3. SPL PHASE DE-ESSER
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"deesser_enable", 1}, "De-Esser In/Out", true));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"deesser_reduction", 1}, "S-Reduction",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.35f));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"deesser_mode", 1}, "De-Esser Mode",
        juce::StringArray{"Female (7.6k)", "Male (6.4k)", "Custom Tune"}, 0));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"deesser_freq", 1}, "Custom Tune Freq",
        juce::NormalisableRange<float>(5000.0f, 11000.0f, 10.0f, 0.5f), 7000.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"deesser_delta", 1}, "Delta Listen", false));

    // 4. MASTER
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"out_gain", 1}, "Output Trim",
        juce::NormalisableRange<float>(-18.0f, 18.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"safe_ceiling_enable", 1}, "Safe Ceiling On/Off", true));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"bypass", 1}, "Master Bypass", false));

    return { params.begin(), params.end() };
}

int AudioPluginAudioProcessor::getNumPrograms() {
    return static_cast<int>(getFactoryPresets().size());
}

int AudioPluginAudioProcessor::getCurrentProgram() {
    return currentProgramIndex;
}

void AudioPluginAudioProcessor::setCurrentProgram(int index) {
    const auto& presets = getFactoryPresets();
    if (index >= 0 && index < static_cast<int>(presets.size())) {
        currentProgramIndex = index;
        const auto& p = presets[static_cast<size_t>(index)];

        if (auto* param = apvts.getParameter("preamp_drive"))     param->setValueNotifyingHost(param->convertTo0to1(p.preampDrive));
        if (auto* param = apvts.getParameter("preamp_flavor"))    param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(p.preampFlavor)));
        if (auto* param = apvts.getParameter("preamp_warmth"))    param->setValueNotifyingHost(param->convertTo0to1(p.preampWarmth));
        if (auto* param = apvts.getParameter("diode_enable"))     param->setValueNotifyingHost(p.diodeEnable ? 1.0f : 0.0f);
        if (auto* param = apvts.getParameter("diode_drive"))      param->setValueNotifyingHost(param->convertTo0to1(p.diodeDrive));
        if (auto* param = apvts.getParameter("preamp_mix"))        param->setValueNotifyingHost(param->convertTo0to1(p.preampMix));

        if (auto* param = apvts.getParameter("eq_enable"))        param->setValueNotifyingHost(p.eqEnable ? 1.0f : 0.0f);
        if (auto* param = apvts.getParameter("eq_hpf"))           param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(p.eqHpf)));
        if (auto* param = apvts.getParameter("eq_low_freq"))      param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(p.eqLowFreq)));
        if (auto* param = apvts.getParameter("eq_low_gain"))      param->setValueNotifyingHost(param->convertTo0to1(p.eqLowGain));
        if (auto* param = apvts.getParameter("eq_mid_freq"))      param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(p.eqMidFreq)));
        if (auto* param = apvts.getParameter("eq_mid_gain"))      param->setValueNotifyingHost(param->convertTo0to1(p.eqMidGain));
        if (auto* param = apvts.getParameter("eq_high_gain"))     param->setValueNotifyingHost(param->convertTo0to1(p.eqHighGain));

        if (auto* param = apvts.getParameter("deesser_enable"))   param->setValueNotifyingHost(p.deEsserEnable ? 1.0f : 0.0f);
        if (auto* param = apvts.getParameter("deesser_reduction"))param->setValueNotifyingHost(param->convertTo0to1(p.deEsserReduction));
        if (auto* param = apvts.getParameter("deesser_mode"))     param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(p.deEsserMode)));
        if (auto* param = apvts.getParameter("deesser_freq"))     param->setValueNotifyingHost(param->convertTo0to1(p.deEsserFreq));

        if (auto* param = apvts.getParameter("out_gain"))             param->setValueNotifyingHost(param->convertTo0to1(p.outGain));
        if (auto* param = apvts.getParameter("safe_ceiling_enable")) param->setValueNotifyingHost(1.0f);
    }
}

const juce::String AudioPluginAudioProcessor::getProgramName(int index) {
    const auto& presets = getFactoryPresets();
    if (index >= 0 && index < static_cast<int>(presets.size())) {
        return presets[static_cast<size_t>(index)].name;
    }
    return {};
}

void AudioPluginAudioProcessor::changeProgramName(int, const juce::String&) {}

void AudioPluginAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock) {
    // Configurazione dell'Oversampling 4x per la sezione di non-linearità armonica
    const auto oversampleFactor = (sampleRate >= 88200.0)
        ? dsp171::Oversampler::Factor::x2
        : dsp171::Oversampler::Factor::x4;

    oversampler.prepare(MaxChannels, static_cast<size_t>(samplesPerBlock), sampleRate, oversampleFactor, false);

    const double multiplier = static_cast<double>(1 << static_cast<int>(oversampleFactor));
    const double effectiveRate = sampleRate * multiplier;

    for (size_t ch = 0; ch < MaxChannels; ++ch) {
        // Preamp preparato al sample rate oversampled per zero aliasing
        preampStages[ch].prepare(effectiveRate);
        // EQ, De-Esser e TruePeak preparati a frequenza base (massima precisione di fase e minimo carico CPU)
        neveEQs[ch].prepare(sampleRate);
        splDeEssers[ch].prepare(sampleRate);
        truePeakLimiters[ch].prepare(sampleRate);
        dryDelayRingBuffer[ch].fill(0.0f);
    }
    dryDelayWriteIndex = 0;
    visualFIFO.reset();

    // Smoothing parametri (20 ms di rampa anti-zipper)
    constexpr double rampTimeSec = 0.020;
    smoothedDrive.reset(effectiveRate, rampTimeSec);
    smoothedWarmth.reset(effectiveRate, rampTimeSec);
    smoothedDiodeDrive.reset(effectiveRate, rampTimeSec);
    smoothedPreampMix.reset(effectiveRate, rampTimeSec);

    smoothedDeEsserReduction.reset(sampleRate, rampTimeSec);
    smoothedDeEsserFreq.reset(sampleRate, rampTimeSec);
    smoothedOutGain.reset(sampleRate, rampTimeSec);
    smoothedBypass.reset(sampleRate, 0.015);

    // Notifica latenza alla DAW per compensazione automatica (Oversampler + Lookahead Limiter deterministico)
    const int totalLatency = oversampler.getLatencyInSamples() + static_cast<int>(dsp171::TruePeakLimiter::LookaheadLatency);
    setLatencySamples(totalLatency);
}

void AudioPluginAudioProcessor::releaseResources() {
    oversampler.reset();
    for (size_t ch = 0; ch < MaxChannels; ++ch) {
        preampStages[ch].reset();
        neveEQs[ch].reset();
        splDeEssers[ch].reset();
        truePeakLimiters[ch].reset();
        dryDelayRingBuffer[ch].fill(0.0f);
    }
    dryDelayWriteIndex = 0;
    visualFIFO.reset();
}

bool AudioPluginAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const {
    const auto& mainOut = layouts.getMainOutputChannelSet();
    const auto& mainIn  = layouts.getMainInputChannelSet();

    if (mainOut != juce::AudioChannelSet::mono() && mainOut != juce::AudioChannelSet::stereo())
        return false;

    return mainIn == mainOut || (mainIn == juce::AudioChannelSet::mono() && mainOut == juce::AudioChannelSet::stereo());
}

void AudioPluginAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) {
    dsp171::ScopedDenormalDisabler ftzGuard;

    const int numChannels = buffer.getNumChannels();
    const int numSamples  = buffer.getNumSamples();

    if (numChannels == 0 || numSamples == 0) return;

    // Misura livello di ingresso per la schermata di monitoraggio
    float inPeakLevel = 0.0f;
    float inEnergy = 0.0f;
    for (int ch = 0; ch < numChannels; ++ch)
    {
        const float* r = buffer.getReadPointer(ch);
        for (int s = 0; s < numSamples; ++s)
        {
            float a = std::abs(r[s]);
            if (a > inPeakLevel) inPeakLevel = a;
            inEnergy += r[s] * r[s];
        }
    }
    latestInputPeak.store(inPeakLevel, std::memory_order_relaxed);
    latestInputRMS.store(std::sqrt(inEnergy / (float)(numChannels * numSamples)), std::memory_order_relaxed);

    // Aggiornamento target parametri
    smoothedDrive.setTargetValue(preampDriveParam->load(std::memory_order_relaxed));
    smoothedWarmth.setTargetValue(preampWarmthParam->load(std::memory_order_relaxed));
    smoothedDiodeDrive.setTargetValue(diodeDriveParam->load(std::memory_order_relaxed));
    smoothedPreampMix.setTargetValue(preampMixParam->load(std::memory_order_relaxed));

    smoothedDeEsserReduction.setTargetValue(deEsserReductionParam->load(std::memory_order_relaxed));
    smoothedDeEsserFreq.setTargetValue(deEsserFreqParam->load(std::memory_order_relaxed));
    smoothedOutGain.setTargetValue(dsp171::fastDbToLinear(outGainParam->load(std::memory_order_relaxed)));
    smoothedBypass.setTargetValue(bypassParam->load(std::memory_order_relaxed) > 0.5f ? 1.0f : 0.0f);

    const auto flavor = static_cast<dsp171::PreampFlavor>(std::clamp(static_cast<int>(std::round(preampFlavorParam->load(std::memory_order_relaxed))), 0, 3));
    const bool diodeOn = diodeEnableParam->load(std::memory_order_relaxed) > 0.5f;

    const bool eqOn = eqEnableParam->load(std::memory_order_relaxed) > 0.5f;
    const int hpfIdx = std::clamp(static_cast<int>(std::round(eqHpfParam->load(std::memory_order_relaxed))), 0, 4);
    const int lowFreqIdx = std::clamp(static_cast<int>(std::round(eqLowFreqParam->load(std::memory_order_relaxed))), 0, 4);
    const float lowGain = eqLowGainParam->load(std::memory_order_relaxed);
    const int midFreqIdx = std::clamp(static_cast<int>(std::round(eqMidFreqParam->load(std::memory_order_relaxed))), 0, 6);
    const float midGain = eqMidGainParam->load(std::memory_order_relaxed);
    const float highGain = eqHighGainParam->load(std::memory_order_relaxed);

    const bool deEsserOn = deEsserEnableParam->load(std::memory_order_relaxed) > 0.5f;
    const auto deEsserMode = static_cast<dsp171::SPLDeEsserMode>(std::clamp(static_cast<int>(std::round(deEsserModeParam->load(std::memory_order_relaxed))), 0, 1));
    const bool deEsserDelta = deEsserDeltaParam->load(std::memory_order_relaxed) > 0.5f;
    const bool safeCeilingOn = safeCeilingEnableParam ? (safeCeilingEnableParam->load(std::memory_order_relaxed) > 0.5f) : true;

    // Campionamento ingressi per il display
    dsp171::VisualFrame frame;
    const int sampleDecimate = std::max(1, numSamples / static_cast<int>(dsp171::VisualFrame::FrameSamples));
    int frameWriteIdx = 0;
    float inSumSq = 0.0f;

    // Registrazione dell'ingresso pristino nel buffer di ritardo circolare (per true latency-compensated dry bypass)
    const size_t initialDryWriteIdx = dryDelayWriteIndex;
    for (int i = 0; i < numSamples; ++i) {
        const size_t pos = (initialDryWriteIdx + static_cast<size_t>(i)) % DryDelayBufferSize;
        for (int ch = 0; ch < numChannels; ++ch) {
            const size_t chIdx = static_cast<size_t>(ch < 2 ? ch : 0);
            dryDelayRingBuffer[chIdx][pos] = buffer.getSample(ch, i);
        }
    }
    dryDelayWriteIndex = (initialDryWriteIdx + static_cast<size_t>(numSamples)) % DryDelayBufferSize;

    for (int i = 0; i < numSamples; ++i) {
        const float inSample = buffer.getSample(0, i);
        inSumSq += inSample * inSample;
        if (i % sampleDecimate == 0 && frameWriteIdx < static_cast<int>(dsp171::VisualFrame::FrameSamples)) {
            frame.samplesIn[static_cast<size_t>(frameWriteIdx)] = inSample;
            frameWriteIdx++;
        }
    }

    // =========================================================================
    // 1. STADIO PREAMP & DIODI SOVRACAMPIONATO A 4x (Zero Aliasing)
    // =========================================================================
    oversampler.process(buffer, [&](juce::dsp::AudioBlock<float>& block, float /*rate*/) {
        const int oversampledSamples = static_cast<int>(block.getNumSamples());
        const int oversampledChannels = static_cast<int>(block.getNumChannels());

        for (int i = 0; i < oversampledSamples; ++i) {
            const float curDrive      = smoothedDrive.getNextValue();
            const float curWarmth     = smoothedWarmth.getNextValue();
            const float curDiodeDrive = smoothedDiodeDrive.getNextValue();
            const float curPreampMix  = smoothedPreampMix.getNextValue();

            for (int ch = 0; ch < oversampledChannels; ++ch) {
                const size_t chIdx = static_cast<size_t>(ch < 2 ? ch : 0);
                float* data = block.getChannelPointer(ch);
                data[i] = preampStages[chIdx].processSample(
                    data[i], curDrive, flavor, curWarmth, diodeOn, curDiodeDrive, curPreampMix);
            }
        }
    });

    // =========================================================================
    // 2. STADIO NEVE 1073 EQ + SPL DE-ESSER STEREO + TRUE-PEAK CEILING + MASTER BYPASS
    // =========================================================================
    std::array<float, MaxChannels> outSumSq{0.0f, 0.0f};
    std::array<float, MaxChannels> peakOut{0.0f, 0.0f};
    float maxDeEsserReductionDb = 0.0f;
    int outDecimateIdx = 0;

    const size_t totalLatency = static_cast<size_t>(oversampler.getLatencyInSamples()) + dsp171::TruePeakLimiter::LookaheadLatency;

    if (numChannels >= 2) {
        float* channelDataL = buffer.getWritePointer(0);
        float* channelDataR = buffer.getWritePointer(1);

        for (int i = 0; i < numSamples; ++i) {
            const float curReduction  = smoothedDeEsserReduction.getNextValue();
            const float curDeEsserFreq = smoothedDeEsserFreq.getNextValue();
            const float curOutGain    = smoothedOutGain.getNextValue();
            const float curBypass     = smoothedBypass.getNextValue();

            const size_t dryReadPos = (initialDryWriteIdx + static_cast<size_t>(i) + DryDelayBufferSize - totalLatency) % DryDelayBufferSize;
            const float pristineDryL = dryDelayRingBuffer[0][dryReadPos];
            const float pristineDryR = dryDelayRingBuffer[1][dryReadPos];

            // 2A. Equalizzatore Neve 1073 ZDF SVF (Zero heap, zero clicks, continua elaborazione)
            float sL = neveEQs[0].processSample(channelDataL[i], eqOn, hpfIdx, lowFreqIdx, lowGain, midFreqIdx, midGain, highGain);
            float sR = neveEQs[1].processSample(channelDataR[i], eqOn, hpfIdx, lowFreqIdx, lowGain, midFreqIdx, midGain, highGain);

            // 2B. SPL Phase De-Esser Coerente con Stereo-Link (Zero phantom-center yawing)
            float deEssL = sL;
            float deEssR = sR;
            dsp171::SPLPhaseDeEsser::processStereoPair(
                splDeEssers[0], splDeEssers[1], sL, sR, deEssL, deEssR,
                deEsserOn, curReduction, deEsserMode, curDeEsserFreq, deEsserDelta);

            const float reductionDb = splDeEssers[0].getCurrentReductionDb();
            if (reductionDb < maxDeEsserReductionDb) {
                maxDeEsserReductionDb = reductionDb;
            }

            // 2C. Guadagno Master Trim
            const float wetGainL = deEssL * curOutGain;
            const float wetGainR = deEssR * curOutGain;

            // 2D. True-Peak Lookahead Limiter ITU-R BS.1770 Polifase con Stereo Linking Totale
            float safeL = wetGainL;
            float safeR = wetGainR;
            if (safeCeilingOn) {
                dsp171::TruePeakLimiter::processStereoPair(
                    truePeakLimiters[0], truePeakLimiters[1], wetGainL, wetGainR, safeL, safeR, -0.05f);
            } else {
                // Mantenimento della latenza deterministica di 4 campioni per sincronizzazione host perfetta
                float delayedL = 0.0f;
                float delayedR = 0.0f;
                truePeakLimiters[0].computeTruePeak(wetGainL, delayedL);
                truePeakLimiters[1].computeTruePeak(wetGainR, delayedR);
                safeL = delayedL;
                safeR = delayedR;
            }

            // 2E. Pristine Latency-Compensated Master Bypass (Bit-exact IEEE-754 identity, zero bleed)
            float finalL;
            float finalR;
            if (curBypass >= 0.99999f) {
                finalL = pristineDryL;
                finalR = pristineDryR;
            } else if (curBypass <= 0.00001f) {
                finalL = safeL;
                finalR = safeR;
            } else {
                finalL = (safeL * (1.0f - curBypass)) + (pristineDryL * curBypass);
                finalR = (safeR * (1.0f - curBypass)) + (pristineDryR * curBypass);
            }

            channelDataL[i] = finalL;
            channelDataR[i] = finalR;

            const float absL = std::abs(finalL);
            const float absR = std::abs(finalR);
            outSumSq[0] += finalL * finalL;
            outSumSq[1] += finalR * finalR;
            if (absL > peakOut[0]) peakOut[0] = absL;
            if (absR > peakOut[1]) peakOut[1] = absR;

            if ((i % sampleDecimate == 0) && outDecimateIdx < static_cast<int>(dsp171::VisualFrame::FrameSamples)) {
                frame.samplesOut[static_cast<size_t>(outDecimateIdx)] = finalL;
                frame.samplesGR[static_cast<size_t>(outDecimateIdx)] = reductionDb;
                outDecimateIdx++;
            }
        }
    } else {
        float* channelDataL = buffer.getWritePointer(0);

        for (int i = 0; i < numSamples; ++i) {
            const float curReduction  = smoothedDeEsserReduction.getNextValue();
            const float curDeEsserFreq = smoothedDeEsserFreq.getNextValue();
            const float curOutGain    = smoothedOutGain.getNextValue();
            const float curBypass     = smoothedBypass.getNextValue();

            const size_t dryReadPos = (initialDryWriteIdx + static_cast<size_t>(i) + DryDelayBufferSize - totalLatency) % DryDelayBufferSize;
            const float pristineDry = dryDelayRingBuffer[0][dryReadPos];

            // 2A. Neve 1073 EQ ZDF SVF
            float s = neveEQs[0].processSample(channelDataL[i], eqOn, hpfIdx, lowFreqIdx, lowGain, midFreqIdx, midGain, highGain);

            // 2B. SPL Phase De-Esser Coerente
            s = splDeEssers[0].processSample(s, deEsserOn, curReduction, deEsserMode, curDeEsserFreq, deEsserDelta);

            const float reductionDb = splDeEssers[0].getCurrentReductionDb();
            if (reductionDb < maxDeEsserReductionDb) {
                maxDeEsserReductionDb = reductionDb;
            }

            // 2C. Guadagno Master Trim
            const float wetGain = s * curOutGain;

            // 2D. True-Peak Lookahead Limiter Polifase ITU-R BS.1770
            float safeSample = wetGain;
            if (safeCeilingOn) {
                safeSample = truePeakLimiters[0].processSample(wetGain, -0.05f);
            } else {
                float delayed = 0.0f;
                truePeakLimiters[0].computeTruePeak(wetGain, delayed);
                safeSample = delayed;
            }

            // 2E. Pristine Latency-Compensated Master Bypass (Bit-exact IEEE-754 identity, zero bleed)
            float finalSample;
            if (curBypass >= 0.99999f) {
                finalSample = pristineDry;
            } else if (curBypass <= 0.00001f) {
                finalSample = safeSample;
            } else {
                finalSample = (safeSample * (1.0f - curBypass)) + (pristineDry * curBypass);
            }

            channelDataL[i] = finalSample;

            const float absVal = std::abs(finalSample);
            outSumSq[0] += finalSample * finalSample;
            if (absVal > peakOut[0]) peakOut[0] = absVal;

            if ((i % sampleDecimate == 0) && outDecimateIdx < static_cast<int>(dsp171::VisualFrame::FrameSamples)) {
                frame.samplesOut[static_cast<size_t>(outDecimateIdx)] = finalSample;
                frame.samplesGR[static_cast<size_t>(outDecimateIdx)] = reductionDb;
                outDecimateIdx++;
            }
        }
    }

    frame.inRMS          = std::sqrt(inSumSq / static_cast<float>(numSamples));
    frame.outRMS_L       = std::sqrt(outSumSq[0] / static_cast<float>(numSamples));
    frame.outRMS_R       = numChannels > 1 ? std::sqrt(outSumSq[1] / static_cast<float>(numSamples)) : frame.outRMS_L;
    frame.peak_L         = peakOut[0];
    frame.peak_R         = numChannels > 1 ? peakOut[1] : frame.peak_L;
    frame.gainReduction_L= maxDeEsserReductionDb;
    frame.gainReduction_R = maxDeEsserReductionDb;

    latestOutputRMS.store((frame.outRMS_L + frame.outRMS_R) * 0.5f, std::memory_order_relaxed);
    latestDeEsserReductionDb.store(maxDeEsserReductionDb, std::memory_order_relaxed);
    latestOutputPeak.store(std::max(peakOut[0], numChannels > 1 ? peakOut[1] : peakOut[0]), std::memory_order_relaxed);

    visualFIFO.push(frame);
}

juce::AudioProcessorEditor* AudioPluginAudioProcessor::createEditor() {
    return new AudioPluginAudioProcessorEditor(*this);
}

void AudioPluginAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    auto state = apvts.copyState();
    state.setProperty("version", 1, nullptr);
    state.setProperty("currentPreset", currentProgramIndex, nullptr);
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void AudioPluginAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType())) {
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
        currentProgramIndex = apvts.state.getProperty("currentPreset", 0);
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new AudioPluginAudioProcessor();
}
