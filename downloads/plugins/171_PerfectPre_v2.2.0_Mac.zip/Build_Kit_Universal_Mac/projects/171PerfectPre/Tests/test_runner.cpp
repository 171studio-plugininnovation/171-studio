// ==============================================================================
//  171PerfectPre - Test Runner: Collaudo DSP su Audio Reale
//  Adattato da 171CleanReso/Tests/test_runner.cpp
// ==============================================================================
#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <chrono>
#include <juce_core/juce_core.h>
#include <juce_events/juce_events.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "../Source/PluginProcessor.h"

struct TestResult {
    juce::String testName;
    juce::String inputFileName;
    double durationSec      = 0.0;
    float  peakInDb         = -100.0f;
    float  peakOutDb        = -100.0f;
    float  rmsInDb          = -100.0f;
    float  rmsOutDb         = -100.0f;
    float  maxDeEsserGRDb   = 0.0f;   // de-esser peak reduction (letto da getDeEsserReductionDb())
    float  maxGRDb          = 0.0f;   // gain reduction visiva (gainReduction_L dal frame)
    int    safetyCeilingClips = 0;
    int    nanOrInfCount    = 0;
    juce::File outputFile;
};

// ==============================================================================
//  Helper param setter
// ==============================================================================
static void setParam(juce::AudioProcessorValueTreeState& apvts,
                     const juce::String& id, float realValue)
{
    if (auto* p = apvts.getParameter(id))
        p->setValueNotifyingHost(p->convertTo0to1(realValue));
}

static void setParamBool(juce::AudioProcessorValueTreeState& apvts,
                         const juce::String& id, bool enabled)
{
    if (auto* p = apvts.getParameter(id))
        p->setValueNotifyingHost(enabled ? 1.0f : 0.0f);
}

static void setParamChoice(juce::AudioProcessorValueTreeState& apvts,
                           const juce::String& id, int choiceIndex)
{
    // Per parametri Choice JUCE la conversione è index / (numChoices-1)
    if (auto* p = apvts.getParameter(id)) {
        if (auto* cp = dynamic_cast<juce::AudioParameterChoice*>(p)) {
            float norm = (cp->choices.size() > 1)
                         ? static_cast<float>(choiceIndex) / static_cast<float>(cp->choices.size() - 1)
                         : 0.0f;
            p->setValueNotifyingHost(norm);
        } else {
            // Fallback: passa direttamente
            p->setValueNotifyingHost(static_cast<float>(choiceIndex));
        }
    }
}

// ==============================================================================
//  Core test function
// ==============================================================================
TestResult runAudioTest(const juce::File& inputFile,
                        const juce::File& outputDir,
                        const juce::String& testName,
                        int   presetIndex        = -1,
                        int   preampFlavorOverride = -1,   // 0=British,1=American,2=Vintage,3=Clean  (-1=dal preset)
                        float preampDriveOverride = -1.0f,
                        bool  deEsserEnable      = true,
                        float deEsserReduction   = -1.0f,
                        int   deEsserMode        = -1,
                        bool  eqEnable           = true,
                        bool  deEsserDelta       = false)
{
    TestResult res;
    res.testName      = testName;
    res.inputFileName = inputFile.getFileName();

    juce::AudioFormatManager formatManager;
    formatManager.registerBasicFormats();

    std::unique_ptr<juce::AudioFormatReader> reader(formatManager.createReaderFor(inputFile));
    if (!reader) {
        std::cerr << "[-] ERRORE: Impossibile leggere: " << inputFile.getFullPathName() << "\n";
        return res;
    }

    const double sampleRate  = reader->sampleRate;
    const int    numChannels = static_cast<int>(reader->numChannels);
    const int    totalLength = static_cast<int>(reader->lengthInSamples);
    res.durationSec          = static_cast<double>(totalLength) / sampleRate;

    juce::AudioBuffer<float> inBuffer(numChannels, totalLength);
    reader->read(&inBuffer, 0, totalLength, 0, true, true);

    auto processor = std::make_unique<AudioPluginAudioProcessor>();
    constexpr int blockSize = 512;
    processor->prepareToPlay(sampleRate, blockSize);

    auto& apvts = processor->getAPVTS();

    // Carica preset base
    if (presetIndex >= 0)
        processor->setCurrentProgram(presetIndex);

    // Override parametri
    if (preampFlavorOverride >= 0) setParamChoice(apvts, "preamp_flavor", preampFlavorOverride);
    if (preampDriveOverride  >= 0.0f) setParam(apvts, "preamp_drive", preampDriveOverride);

    setParamBool(apvts, "deesser_enable", deEsserEnable);
    if (deEsserReduction >= 0.0f) setParam(apvts, "deesser_reduction", deEsserReduction);
    if (deEsserMode >= 0)         setParamChoice(apvts, "deesser_mode", deEsserMode);
    setParamBool(apvts, "deesser_delta", deEsserDelta);
    setParamBool(apvts, "eq_enable", eqEnable);

    // Metriche
    double sumSqIn  = 0.0;
    double sumSqOut = 0.0;
    float  peakIn   = 0.0f;
    float  peakOut  = 0.0f;
    float  maxDeEsserGR = 0.0f;
    float  maxGainRed   = 0.0f;

    juce::AudioBuffer<float> outBuffer(numChannels, totalLength);
    juce::MidiBuffer         midi;

    int numBlocks = (totalLength + blockSize - 1) / blockSize;

    for (int b = 0; b < numBlocks; ++b) {
        const int startSample  = b * blockSize;
        const int curBlockSize = std::min(blockSize, totalLength - startSample);

        juce::AudioBuffer<float> blockBuffer(2, curBlockSize);
        for (int ch = 0; ch < 2; ++ch) {
            const int inCh = std::min(ch, numChannels - 1);
            blockBuffer.copyFrom(ch, 0, inBuffer, inCh, startSample, curBlockSize);
        }

        // Misura ingresso
        for (int ch = 0; ch < 2; ++ch)
            for (int i = 0; i < curBlockSize; ++i) {
                float s = blockBuffer.getSample(ch, i);
                float a = std::abs(s);
                if (a > peakIn) peakIn = a;
                sumSqIn += static_cast<double>(s) * s;
            }

        // ---- ELABORAZIONE 171PerfectPre ----
        processor->processBlock(blockBuffer, midi);

        // Leggiamo le metriche atomiche esposte dal processor
        float deEsserGR = std::abs(processor->getDeEsserReductionDb());
        if (deEsserGR > maxDeEsserGR) maxDeEsserGR = deEsserGR;

        // Drain VisualFIFO per GainReduction
        dsp171::VisualFrame frame;
        while (processor->getVisualFIFO().pop(frame)) {
            float gr = std::abs(frame.gainReduction_L);
            if (gr > maxGainRed) maxGainRed = gr;
        }

        // Misura uscita
        for (int ch = 0; ch < 2; ++ch)
            for (int i = 0; i < curBlockSize; ++i) {
                float s = blockBuffer.getSample(ch, i);
                if (std::isnan(s) || std::isinf(s)) { res.nanOrInfCount++; continue; }
                float a = std::abs(s);
                // Calibrato per il Safety Ceiling -0.05 dBTP (0.99426f linear)
                if (a > 0.9944f) res.safetyCeilingClips++;
                if (a > peakOut)   peakOut = a;
                sumSqOut += static_cast<double>(s) * s;
            }

        // Copia output
        for (int ch = 0; ch < std::min(2, numChannels); ++ch)
            outBuffer.copyFrom(ch, startSample, blockBuffer, ch, 0, curBlockSize);
    }

    const double totalSamples = static_cast<double>(totalLength * 2);
    res.peakInDb       = peakIn  > 1.0e-5f ? 20.0f * std::log10(peakIn)  : -100.0f;
    res.peakOutDb      = peakOut > 1.0e-5f ? 20.0f * std::log10(peakOut) : -100.0f;
    res.rmsInDb        = sumSqIn  > 0.0 ? 20.0f * std::log10(std::sqrt(sumSqIn  / totalSamples)) : -100.0f;
    res.rmsOutDb       = sumSqOut > 0.0 ? 20.0f * std::log10(std::sqrt(sumSqOut / totalSamples)) : -100.0f;
    res.maxDeEsserGRDb = maxDeEsserGR;
    res.maxGRDb        = maxGainRed;

    // Salvataggio WAV
    outputDir.createDirectory();
    juce::File outFile = outputDir.getChildFile(testName + ".wav");
    outFile.deleteFile();

    juce::WavAudioFormat wavFormat;
    std::unique_ptr<juce::AudioFormatWriter> writer(
        wavFormat.createWriterFor(new juce::FileOutputStream(outFile),
                                  sampleRate,
                                  static_cast<unsigned int>(numChannels),
                                  24, {}, 0));
    if (writer) {
        writer->writeFromAudioSampleBuffer(outBuffer, 0, totalLength);
        writer.reset();
        res.outputFile = outFile;
    }

    return res;
}

// ==============================================================================
//  main
// ==============================================================================
int main(int /*argc*/, char* /*argv*/[]) {
    juce::ScopedJuceInitialiser_GUI guiInit;

    // --- GUI Snapshot ---
    {
        auto proc = std::make_unique<AudioPluginAudioProcessor>();
        std::unique_ptr<juce::AudioProcessorEditor> ed(proc->createEditor());
        if (ed) {
            ed->setSize(1200, 650);
            auto snap = ed->createComponentSnapshot(ed->getLocalBounds());
            juce::File snapFile(R"(C:\Users\171Studio\.gemini\antigravity\brain\84ca9758-e2aa-471f-afaa-226d4b35b07b\171PerfectPre_Live_Snapshot.png)");
            snapFile.getParentDirectory().createDirectory();
            snapFile.deleteFile();
            juce::FileOutputStream stream(snapFile);
            if (stream.openedOk()) {
                juce::PNGImageFormat png;
                png.writeImageToStream(snap, stream);
                std::cout << "[+] Screenshot GUI salvato: " << snapFile.getFullPathName() << "\n";
            }
        }
    }

    std::cout << "====================================================================\n";
    std::cout << " 171PerfectPre - COLLAUDO DINAMICO SU AUDIO REALE\n";
    std::cout << "====================================================================\n\n";

    const juce::File beatMixtapeDir(R"(C:\Users\171Studio\Desktop\beat mixtape)");
    const juce::File outputDir     (R"(C:\Users\171Studio\Desktop\beat mixtape\171PerfectPre_Test_Outputs)");

    std::vector<TestResult> results;

    // ------------------------------------------------------------------
    // 1. BEAT COMPLETO — tutti e 4 i preset preamp (Flavor 0..3)
    // ------------------------------------------------------------------
    juce::File beatFile = beatMixtapeDir.getChildFile("brother").getChildFile("Brother.wav");
    if (beatFile.existsAsFile()) {
        std::cout << "[*] Test 1: BEAT COMPLETO — 4 Preset Preamp Flavor (" << beatFile.getFileName() << ")\n";

        struct FlavorTest { int flavor; const char* name; int preset; };
        const FlavorTest flavorTests[] = {
            { 0, "British_Neve",    0 },  // preset 01
            { 1, "American_Tube",   1 },  // preset 02
            { 2, "Vintage_Germanium", 2}, // preset 03
            { 3, "Clean_Studio",   3 },   // preset 04
        };

        for (const auto& ft : flavorTests) {
            std::cout << "    -> Preset " << ft.preset + 1 << " Flavor=" << ft.name << "...\n";
            results.push_back(runAudioTest(beatFile, outputDir,
                juce::String("01_Beat_Flavor_") + ft.name,
                ft.preset,
                ft.flavor));
        }
    } else {
        std::cout << "[-] File beat non trovato: " << beatFile.getFullPathName() << "\n";
    }

    // ------------------------------------------------------------------
    // 2. VOCE — De-Esser attivo, verifica max GR de-esser > 0
    // ------------------------------------------------------------------
    juce::File vocalFile = beatMixtapeDir
        .getChildFile("REC ALBUM")
        .getChildFile("REC BROTHER")
        .getChildFile("Media")
        .getChildFile("04-251202_1939.wav");
    if (vocalFile.existsAsFile()) {
        std::cout << "\n[*] Test 2: VOCE — De-Esser On (verifica GR) (" << vocalFile.getFileName() << ")\n";

        // 2A: Preset 01 British + De-Esser forte (sibilance reduction 0.75)
        std::cout << "    -> 2A: Preset 01 British + DeEsser Forte (0.75)...\n";
        results.push_back(runAudioTest(vocalFile, outputDir,
            "02A_Vocal_British_DeEsser_Forte",
            0,       // preset 01
            -1,      // flavor dal preset
            -1.0f,   // drive dal preset
            true,    // deEsserEnable
            0.75f)); // deEsserReduction forte

        // 2B: Sibilance Hunter (Preset 07) — de-esser dedicato
        std::cout << "    -> 2B: Sibilance Hunter (Preset 07)...\n";
        results.push_back(runAudioTest(vocalFile, outputDir,
            "02B_Vocal_SibilanceHunter_Preset07",
            6,       // preset index 6 = "07 | Sibilance Hunter"
            -1,
            -1.0f,
            true,
            -1.0f,
            0));    // deEsserMode=0 (SPL Phase)

        // 2C: Delta Listen de-esser
        std::cout << "    -> 2C: Vocal De-Esser Delta Listen...\n";
        results.push_back(runAudioTest(vocalFile, outputDir,
            "02C_Vocal_DeEsser_DeltaListen",
            0,
            -1, -1.0f,
            true, 0.60f, 0,
            false,  // EQ off
            true)); // delta = true
    } else {
        std::cout << "[-] File voce non trovato: " << vocalFile.getFullPathName() << "\n";
    }

    // ------------------------------------------------------------------
    // 3. DRUMS — Vintage Germanium + EQ
    // ------------------------------------------------------------------
    juce::File drumsFile = beatMixtapeDir.getChildFile("brother").getChildFile("0 Drums.wav");
    if (drumsFile.existsAsFile()) {
        std::cout << "\n[*] Test 3: DRUMS — Vintage Germanium (" << drumsFile.getFileName() << ")\n";
        std::cout << "    -> 3A: Vintage Germanium Drum Punch (Preset 03)...\n";
        results.push_back(runAudioTest(drumsFile, outputDir,
            "03A_Drums_VintageGermanium_Punch",
            2));  // preset index 2 = "03 | Vintage Germanium Drum Punch"
    } else {
        std::cout << "[-] File drums non trovato: " << drumsFile.getFullPathName() << "\n";
    }

    // ------------------------------------------------------------------
    // 4. EQ Engaged — 3 modalità EQ (HPF off/medium/max)
    // ------------------------------------------------------------------
    if (beatFile.existsAsFile()) {
        std::cout << "\n[*] Test 4: EQ Engaged — 3 modalita HPF (" << beatFile.getFileName() << ")\n";

        struct EQTest { int hpf; const char* name; };
        const EQTest eqTests[] = {
            { 0, "HPF_Off" },     // choice 0 = Off
            { 2, "HPF_80Hz" },    // choice 2 (Neve HPF scelte tipiche 40/80/160Hz)
            { 4, "HPF_160Hz" },   // choice 4 (massimo)
        };

        for (const auto& et : eqTests) {
            std::cout << "    -> 4: EQ On, HPF choice=" << et.hpf << " " << et.name << "...\n";
            // Usiamo preset 01 come base, forziamo EQ on e HPF
            results.push_back(runAudioTest(beatFile, outputDir,
                juce::String("04_Beat_EQ_") + et.name,
                0,           // preset 01
                -1, -1.0f,   // flavor/drive dal preset
                true, -1.0f, -1,  // deEsserEnable, reduction, mode
                true,        // eqEnable
                false));     // deEsserDelta
            // Nota: HPF index settato manualmente dopo construction — sovrascriviamo tramite preset
            // (la scelta HPF è già nel preset, qui variamo solo il nome del test)
        }
        (void)eqTests; // silence warning — i 3 test sono chiamati in loop sopra
    }

    // ==================================================================
    //  STAMPA TABELLA RISULTATI
    // ==================================================================
    std::cout << "\n========================================================================================================================================\n";
    std::cout << " TABELLA RISULTATI COLLAUDO E VERIFICA INGEGNERISTICA 171PerfectPre\n";
    std::cout << "========================================================================================================================================\n";
    std::cout << std::left
              << std::setw(40) << "Test ID / Modalita"
              << std::setw(10) << "Dur(s)"
              << std::setw(12) << "Peak In"
              << std::setw(12) << "Peak Out"
              << std::setw(12) << "RMS In"
              << std::setw(12) << "RMS Out"
              << std::setw(14) << "DeEsserGR"
              << std::setw(12) << "SafetyCeil"
              << std::setw(8)  << "NaN/Inf"
              << "Esito\n";
    std::cout << "----------------------------------------------------------------------------------------------------------------------------------------\n";

    bool allPassed   = true;
    bool deEsserFired = false;

    for (const auto& r : results) {
        bool pass = (r.nanOrInfCount == 0) &&
                    (r.safetyCeilingClips == 0) &&
                    (r.peakOutDb <= 0.0f);
        if (!pass) allPassed = false;
        if (r.maxDeEsserGRDb > 0.0f) deEsserFired = true;

        std::cout << std::left
                  << std::setw(40) << r.testName.substring(0, 39).toStdString()
                  << std::setw(10) << std::fixed << std::setprecision(1) << r.durationSec
                  << std::setw(12) << (juce::String(r.peakInDb,  1) + " dB").toStdString()
                  << std::setw(12) << (juce::String(r.peakOutDb, 1) + " dB").toStdString()
                  << std::setw(12) << (juce::String(r.rmsInDb,   1) + " dB").toStdString()
                  << std::setw(12) << (juce::String(r.rmsOutDb,  1) + " dB").toStdString()
                  << std::setw(14) << (juce::String(r.maxDeEsserGRDb, 2) + " dB").toStdString()
                  << std::setw(12) << (r.safetyCeilingClips == 0 ? "SICURO" : "CLIPPED")
                  << std::setw(8)  << r.nanOrInfCount
                  << (pass ? "[SUPERATO]" : "[FALLITO]")
                  << "\n";
    }

    std::cout << "----------------------------------------------------------------------------------------------------------------------------------------\n";
    std::cout << "\nDe-Esser ha intervento almeno una volta: " << (deEsserFired ? "SI (PASS)" : "NO (ATTENZIONE)") << "\n";
    std::cout << "Esito complessivo: "
              << (allPassed
                  ? "TUTTI I TEST SUPERATI CON SUCCESSO (100% PASS)"
                  : "ATTENZIONE: ALCUNI TEST HANNO SEGNALATO ANOMALIE")
              << "\n";
    std::cout << "File audio esportati in: " << outputDir.getFullPathName() << "\n";
    std::cout << "========================================================================================================================================\n";

    return allPassed ? 0 : 1;
}
