// ==============================================================================
//  171PerfectPre - ADVERSARIAL DSP STRESS TEST HARNESS (C++20 Release x64)
//  Team 171 Studio Innovation - Senior Adversarial DSP Stress Tester
// ==============================================================================
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <array>
#include <cmath>
#include <chrono>
#include <cassert>
#include <atomic>
#include <random>
#include <numeric>
#include <algorithm>
#include <thread>

#include <juce_core/juce_core.h>
#include <juce_events/juce_events.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>

#include "../Source/PluginProcessor.h"
#include <dsp171/Common.h>
#include <dsp171/ScopedDenormalDisabler.h>
#include <dsp171/SafetyCeiling.h>
#include <dsp171/FastMath.h>
#include <dsp171/Oversampler.h>

// ==============================================================================
//  GLOBAL REAL-TIME HEAP ALLOCATION INTERCEPTOR
// ==============================================================================
static std::atomic<size_t> gAudioThreadAllocations{0};
static std::atomic<size_t> gAudioThreadDeallocations{0};
static thread_local bool   gTrapAudioThreadAllocations = false;

#if defined(_MSC_VER) || defined(__GNUC__) || defined(__clang__)
void* operator new(size_t size) {
    if (gTrapAudioThreadAllocations) {
        gAudioThreadAllocations.fetch_add(size, std::memory_order_relaxed);
    }
    void* p = std::malloc(size);
    if (!p) throw std::bad_alloc();
    return p;
}

void* operator new[](size_t size) {
    if (gTrapAudioThreadAllocations) {
        gAudioThreadAllocations.fetch_add(size, std::memory_order_relaxed);
    }
    void* p = std::malloc(size);
    if (!p) throw std::bad_alloc();
    return p;
}

void operator delete(void* p) noexcept {
    if (gTrapAudioThreadAllocations && p != nullptr) {
        gAudioThreadDeallocations.fetch_add(1, std::memory_order_relaxed);
    }
    std::free(p);
}

void operator delete[](void* p) noexcept {
    if (gTrapAudioThreadAllocations && p != nullptr) {
        gAudioThreadDeallocations.fetch_add(1, std::memory_order_relaxed);
    }
    std::free(p);
}

void operator delete(void* p, size_t) noexcept {
    if (gTrapAudioThreadAllocations && p != nullptr) {
        gAudioThreadDeallocations.fetch_add(1, std::memory_order_relaxed);
    }
    std::free(p);
}

void operator delete[](void* p, size_t) noexcept {
    if (gTrapAudioThreadAllocations && p != nullptr) {
        gAudioThreadDeallocations.fetch_add(1, std::memory_order_relaxed);
    }
    std::free(p);
}
#endif

// ==============================================================================
//  Sinc 16x Polyphase True-Peak Reconstructor (ITU-R BS.1770-4 Standard)
// ==============================================================================
class HighPrecisionTruePeakMeter {
public:
    static constexpr size_t OverSample = 16;
    static constexpr size_t TapsPerPhase = 12;
    static constexpr size_t TotalTaps = OverSample * TapsPerPhase;

    HighPrecisionTruePeakMeter() {
        // Genera filtro sinc con finestra Kaiser (beta = 8.5) per oltre 110 dB di attenuazione alias
        constexpr double beta = 8.5;
        auto besselI0 = [](double x) {
            double sum = 1.0;
            double term = 1.0;
            for (int k = 1; k < 50; ++k) {
                term *= (x / (2.0 * k)) * (x / (2.0 * k));
                sum += term;
                if (term < 1e-15 * sum) break;
            }
            return sum;
        };
        const double i0Beta = besselI0(beta);

        for (size_t phase = 0; phase < OverSample; ++phase) {
            for (size_t k = 0; k < TapsPerPhase; ++k) {
                double t = static_cast<double>(k) - static_cast<double>(TapsPerPhase) / 2.0 + static_cast<double>(phase) / static_cast<double>(OverSample);
                double sincVal = 1.0;
                if (std::abs(t) > 1e-7) {
                    sincVal = std::sin(dsp171::PI * t) / (dsp171::PI * t);
                }
                // Kaiser window
                double frac = 2.0 * (static_cast<double>(k) * OverSample + phase) / static_cast<double>(TotalTaps - 1) - 1.0;
                double wArg = beta * std::sqrt(std::max(0.0, 1.0 - frac * frac));
                double win = besselI0(wArg) / i0Beta;
                polyphaseTaps[phase][k] = static_cast<float>(sincVal * win);
            }
        }
        delayBuffer.fill(0.0f);
        writeIdx = 0;
    }

    void reset() {
        delayBuffer.fill(0.0f);
        writeIdx = 0;
    }

    float processSample(float in) {
        delayBuffer[writeIdx] = in;
        std::array<float, TapsPerPhase> history{};
        for (size_t k = 0; k < TapsPerPhase; ++k) {
            const size_t rIdx = (writeIdx + TapsPerPhase - k) % TapsPerPhase;
            history[k] = delayBuffer[rIdx];
        }
        writeIdx = (writeIdx + 1) % TapsPerPhase;

        float maxAbs = std::abs(in);
        for (size_t phase = 0; phase < OverSample; ++phase) {
            float sum = 0.0f;
            for (size_t k = 0; k < TapsPerPhase; ++k) {
                sum += history[k] * polyphaseTaps[phase][k];
            }
            maxAbs = std::max(maxAbs, std::abs(sum));
        }
        return maxAbs;
    }

private:
    std::array<std::array<float, TapsPerPhase>, OverSample> polyphaseTaps{};
    std::array<float, TapsPerPhase> delayBuffer{};
    size_t writeIdx = 0;
};

// ==============================================================================
//  Helper per formattazione e output
// ==============================================================================
static std::stringstream gReportStream;

static void logBoth(const std::string& msg) {
    std::cout << msg << std::flush;
    gReportStream << msg;
}

static inline float linToDb(float lin) {
    return lin > 1e-12f ? 20.0f * std::log10(lin) : -240.0f;
}

// ==============================================================================
//  TEST 1: MULTI-SAMPLE RATE AUDIT
//  44.1 kHz, 48 kHz, 88.2 kHz, 96 kHz, 192 kHz
// ==============================================================================
struct MultiSampleRateResult {
    double sampleRate;
    int latencySamples;
    int oversampleFactor;
    int nanCount;
    int infCount;
    int denormalCount;
    float peakInDb;
    float peakOutDb;
    float rmsOutDb;
    bool pass;
};

std::vector<MultiSampleRateResult> runMultiSampleRateAudit() {
    logBoth("\n================================================================================\n");
    logBoth(" [AUDIT 1] MULTI-SAMPLE RATE INTEGRITY (44.1k, 48k, 88.2k, 96k, 192k)\n");
    logBoth("================================================================================\n");

    const std::vector<double> rates = { 44100.0, 48000.0, 88200.0, 96000.0, 192000.0 };
    std::vector<MultiSampleRateResult> results;

    for (double sr : rates) {
        MultiSampleRateResult res{};
        res.sampleRate = sr;
        res.oversampleFactor = (sr >= 88200.0) ? 2 : 4;

        AudioPluginAudioProcessor processor;
        constexpr int blockSize = 512;
        processor.prepareToPlay(sr, blockSize);
        res.latencySamples = processor.getLatencySamples();

        // Preset 01 British Vintage con Neve EQ e SPL De-Esser attivi
        processor.setCurrentProgram(0);

        // Genera segnale di prova: mix di 80 Hz, 1 kHz, 8 kHz, 15 kHz + colpi impulsivi
        constexpr int numBlocks = 60;
        juce::AudioBuffer<float> buffer(2, blockSize);
        juce::MidiBuffer midi;

        float maxIn = 0.0f;
        float maxOut = 0.0f;
        double sumSqOut = 0.0;
        int totalSamples = numBlocks * blockSize * 2;

        for (int b = 0; b < numBlocks; ++b) {
            for (int i = 0; i < blockSize; ++i) {
                const int n = b * blockSize + i;
                const double t = static_cast<double>(n) / sr;
                float s = 0.25f * static_cast<float>(std::sin(2.0 * dsp171::PI * 85.0 * t))
                        + 0.25f * static_cast<float>(std::sin(2.0 * dsp171::PI * 1200.0 * t))
                        + 0.15f * static_cast<float>(std::sin(2.0 * dsp171::PI * 7600.0 * t))
                        + 0.10f * static_cast<float>(std::sin(2.0 * dsp171::PI * 16000.0 * t));
                if (n % 400 == 0) s += 0.8f; // Impulso per sollecitare i filtri ZDF

                buffer.setSample(0, i, s);
                buffer.setSample(1, i, s);
                maxIn = std::max(maxIn, std::abs(s));
            }

            processor.processBlock(buffer, midi);

            for (int ch = 0; ch < 2; ++ch) {
                const float* ptr = buffer.getReadPointer(ch);
                for (int i = 0; i < blockSize; ++i) {
                    float v = ptr[i];
                    if (std::isnan(v)) res.nanCount++;
                    if (std::isinf(v)) res.infCount++;
                    const float absV = std::abs(v);
                    if (absV > 0.0f && absV < 1.175494e-38f) res.denormalCount++;
                    maxOut = std::max(maxOut, absV);
                    sumSqOut += static_cast<double>(v) * v;
                }
            }
        }

        res.peakInDb = linToDb(maxIn);
        res.peakOutDb = linToDb(maxOut);
        res.rmsOutDb = linToDb(static_cast<float>(std::sqrt(sumSqOut / totalSamples)));
        res.pass = (res.nanCount == 0) && (res.infCount == 0) && (res.denormalCount == 0) && (res.peakOutDb <= -0.05f + 0.001f);

        std::stringstream ss;
        ss << "  Sample Rate: " << std::setw(6) << static_cast<int>(sr) << " Hz | OS: " << res.oversampleFactor
           << "x | Latency: " << std::setw(4) << res.latencySamples << " spls"
           << " | Peak Out: " << std::fixed << std::setprecision(3) << res.peakOutDb << " dBFS"
           << " | RMS Out: " << std::fixed << std::setprecision(2) << res.rmsOutDb << " dBFS"
           << " | NaNs: " << res.nanCount << " | Infs: " << res.infCount << " | Denormals: " << res.denormalCount
           << " -> [" << (res.pass ? "PASS" : "FAIL") << "]\n";
        logBoth(ss.str());

        results.push_back(res);
    }
    return results;
}

// ==============================================================================
//  TEST 2: PATHOLOGICAL & EXTREME INPUT STRESS TEST
//  Impulsi a +24 dBFS, gradini DC, rumore bianco +12 dBFS, denormali 1e-38
// ==============================================================================
struct PathologicalResult {
    std::string testCase;
    float peakInDb;
    float peakOutDb;
    float truePeakDb;
    int nanCount;
    int infCount;
    bool ceilingHeld;
    bool pass;
};

std::vector<PathologicalResult> runPathologicalStressTest() {
    logBoth("\n================================================================================\n");
    logBoth(" [AUDIT 2] PATHOLOGICAL INPUT SIGNALS STRESS TEST (+24 dBFS, DC, Noise, Denormals)\n");
    logBoth("================================================================================\n");

    const double sr = 48000.0;
    constexpr int blockSize = 512;
    std::vector<PathologicalResult> results;

    auto testSignal = [&](const std::string& name, auto generatorFn, int blocks = 50) {
        AudioPluginAudioProcessor processor;
        processor.prepareToPlay(sr, blockSize);
        // Drive al massimo +24 dB, Warmth 1.0, Diode attivo, EQ boost +16 dB
        auto& apvts = processor.getAPVTS();
        if (auto* p = apvts.getRawParameterValue("preamp_drive")) p->store(24.0f, std::memory_order_relaxed);
        if (auto* p = apvts.getRawParameterValue("preamp_warmth")) p->store(1.0f, std::memory_order_relaxed);
        if (auto* p = apvts.getRawParameterValue("diode_enable")) p->store(1.0f, std::memory_order_relaxed);
        if (auto* p = apvts.getRawParameterValue("diode_drive")) p->store(1.0f, std::memory_order_relaxed);
        if (auto* p = apvts.getRawParameterValue("eq_low_gain")) p->store(16.0f, std::memory_order_relaxed);
        if (auto* p = apvts.getRawParameterValue("eq_mid_gain")) p->store(18.0f, std::memory_order_relaxed);
        if (auto* p = apvts.getRawParameterValue("eq_high_gain")) p->store(16.0f, std::memory_order_relaxed);
        if (auto* p = apvts.getRawParameterValue("safe_ceiling_enable")) p->store(1.0f, std::memory_order_relaxed);

        HighPrecisionTruePeakMeter tpMeterL;
        HighPrecisionTruePeakMeter tpMeterR;

        PathologicalResult res{};
        res.testCase = name;
        float maxIn = 0.0f;
        float maxOut = 0.0f;
        float maxTp = 0.0f;

        juce::AudioBuffer<float> buffer(2, blockSize);
        juce::MidiBuffer midi;

        for (int b = 0; b < blocks; ++b) {
            for (int i = 0; i < blockSize; ++i) {
                const int n = b * blockSize + i;
                float sL = 0.0f, sR = 0.0f;
                generatorFn(n, sL, sR);
                buffer.setSample(0, i, sL);
                buffer.setSample(1, i, sR);
                maxIn = std::max(maxIn, std::max(std::abs(sL), std::abs(sR)));
            }

            processor.processBlock(buffer, midi);

            for (int i = 0; i < blockSize; ++i) {
                float vL = buffer.getSample(0, i);
                float vR = buffer.getSample(1, i);

                if (std::isnan(vL) || std::isnan(vR)) res.nanCount++;
                if (std::isinf(vL) || std::isinf(vR)) res.infCount++;

                maxOut = std::max(maxOut, std::max(std::abs(vL), std::abs(vR)));
                maxTp = std::max(maxTp, std::max(tpMeterL.processSample(vL), tpMeterR.processSample(vR)));
            }
        }

        res.peakInDb = linToDb(maxIn);
        res.peakOutDb = linToDb(maxOut);
        res.truePeakDb = linToDb(maxTp);
        // Ceiling target -0.05 dBTP (0.99426f linear)
        res.ceilingHeld = (res.peakOutDb <= -0.05f + 0.001f);
        res.pass = (res.nanCount == 0) && (res.infCount == 0) && res.ceilingHeld;

        std::stringstream ss;
        ss << "  " << std::left << std::setw(32) << res.testCase
           << " | In: " << std::right << std::setw(6) << std::fixed << std::setprecision(1) << res.peakInDb << " dBFS"
           << " | Out: " << std::setw(6) << std::fixed << std::setprecision(3) << res.peakOutDb << " dBFS"
           << " | True-Peak: " << std::setw(6) << std::fixed << std::setprecision(3) << res.truePeakDb << " dBTP"
           << " | NaNs: " << res.nanCount << " | Infs: " << res.infCount
           << " -> [" << (res.pass ? "PASS" : "FAIL") << "]\n";
        logBoth(ss.str());

        results.push_back(res);
    };

    // 2A: Impulsi a +24 dBFS (15.8489f linear)
    testSignal("Impulse Trains (+24 dBFS)", [](int n, float& l, float& r) {
        float val = (n % 128 == 0) ? 15.8489f : 0.0f;
        l = val; r = val;
    });

    // 2B: Impulsi Estremi a +40 dBFS (100.0f linear)
    testSignal("Extreme Spikes (+40 dBFS)", [](int n, float& l, float& r) {
        float val = (n % 256 == 0) ? ((n % 512 == 0) ? 100.0f : -100.0f) : 0.0f;
        l = val; r = val;
    });

    // 2C: Gradino DC Infinito (+10.0f per oltre 25000 campioni)
    testSignal("Infinite DC Step (+20 dBFS)", [](int /*n*/, float& l, float& r) {
        l = 10.0f; r = 10.0f;
    }, 60);

    // 2D: Treno Nyquist ad Alternanza Piena (+24 dBFS, -24 dBFS a fs/2)
    testSignal("Nyquist Flip-Flop (+24 dBFS)", [](int n, float& l, float& r) {
        float val = (n % 2 == 0) ? 15.8489f : -15.8489f;
        l = val; r = val;
    });

    // 2E: White Noise ad altissima dinamica (+12 dBFS uniform)
    std::mt19937 rng(1337);
    std::uniform_real_distribution<float> noiseDist(-4.0f, 4.0f); // +12 dBFS peak
    testSignal("White Noise Burst (+12 dBFS)", [&](int /*n*/, float& l, float& r) {
        l = noiseDist(rng);
        r = noiseDist(rng);
    }, 100);

    // 2F: Segnali Subnormali / Denormali Continui (1.0e-38f)
    testSignal("Subnormal Stream (1.0e-38f)", [](int /*n*/, float& l, float& r) {
        l = 1.0e-38f;
        r = 1.0e-38f;
    }, 100);

    return results;
}

// ==============================================================================
//  TEST 3: TWIN-TONE INTERMODULATION & ALIASING AUDIT (19 kHz + 20 kHz @ 44.1 kHz)
// ==============================================================================
struct TwinToneResult {
    float fund19kDb;
    float fund20kDb;
    float imd1kDb;
    float imd18kDb;
    float imd21kDb;
    float aliasedSpurMaxDb;
    float aliased4k1Db;
    float aliased5k1Db;
    float aliased6k1Db;
    float aliasingRejectionDb;
    bool pass;
};

TwinToneResult runTwinToneIntermodulationAudit() {
    logBoth("\n================================================================================\n");
    logBoth(" [AUDIT 3] TWIN-TONE INTERMODULATION & ALIASING (19 kHz + 20 kHz @ 44.1 kHz)\n");
    logBoth("================================================================================\n");

    const double sr = 44100.0;
    constexpr int N = 65536; // Risoluzione spettrale df = 44100 / 65536 = 0.6729 Hz
    constexpr int blockSize = 512;

    // Generazione del twin-tone 19 kHz + 20 kHz (-6.02 dBFS ciascuno, somma picco = 0 dBFS)
    std::vector<float> input(N);
    for (int i = 0; i < N; ++i) {
        const double t = static_cast<double>(i) / sr;
        input[i] = 0.5f * static_cast<float>(std::sin(2.0 * dsp171::PI * 19000.0 * t))
                 + 0.5f * static_cast<float>(std::sin(2.0 * dsp171::PI * 20000.0 * t));
    }

    // 3A: Elaborazione con 171PerfectPre (Oversampling 4x attivo sulla non-linearità)
    AudioPluginAudioProcessor processor;
    processor.prepareToPlay(sr, blockSize);
    auto& apvts = processor.getAPVTS();
    // Preamp British Vintage, Drive +6 dB, Warmth 0.50
    if (auto* p = apvts.getRawParameterValue("preamp_flavor")) p->store(0.0f, std::memory_order_relaxed);
    if (auto* p = apvts.getRawParameterValue("preamp_drive"))  p->store(6.0f, std::memory_order_relaxed);
    if (auto* p = apvts.getRawParameterValue("preamp_warmth")) p->store(0.50f, std::memory_order_relaxed);
    if (auto* p = apvts.getRawParameterValue("diode_enable"))  p->store(0.0f, std::memory_order_relaxed);
    if (auto* p = apvts.getRawParameterValue("eq_enable"))     p->store(0.0f, std::memory_order_relaxed);
    if (auto* p = apvts.getRawParameterValue("deesser_enable"))p->store(0.0f, std::memory_order_relaxed);
    if (auto* p = apvts.getRawParameterValue("safe_ceiling_enable")) p->store(0.0f, std::memory_order_relaxed); // disattivato per misurare puramente la non-linearità

    // Scaldiamo i filtri con un ciclo iniziale
    juce::AudioBuffer<float> warmupBuf(2, blockSize);
    juce::MidiBuffer midi;
    for (int b = 0; b < 10; ++b) processor.processBlock(warmupBuf, midi);

    std::vector<float> output4x(N);
    const int numBlocks = N / blockSize;
    for (int b = 0; b < numBlocks; ++b) {
        juce::AudioBuffer<float> blockBuf(2, blockSize);
        for (int i = 0; i < blockSize; ++i) {
            float s = input[b * blockSize + i];
            blockBuf.setSample(0, i, s);
            blockBuf.setSample(1, i, s);
        }
        processor.processBlock(blockBuf, midi);
        for (int i = 0; i < blockSize; ++i) {
            output4x[b * blockSize + i] = blockBuf.getSample(0, i);
        }
    }

    // 3B: Elaborazione di riferimento SENZA oversampling (1x nativo) per confronto diretto dell'aliasing
    dsp171::PreampMultiFlavor directPreamp;
    directPreamp.prepare(sr);
    std::vector<float> output1x(N);
    for (int i = 0; i < N; ++i) {
        output1x[i] = directPreamp.processSample(input[i], 6.0f, dsp171::PreampFlavor::BritishVintage, 0.50f, false, 0.0f, 1.0f);
    }

    // Finestra di Blackman-Harris 4-term a -92 dB sidelobe suppression
    std::vector<float> window(N);
    double winSum = 0.0;
    for (int i = 0; i < N; ++i) {
        const double a0 = 0.35875;
        const double a1 = 0.48829;
        const double a2 = 0.14128;
        const double a3 = 0.01168;
        const double frac = 2.0 * dsp171::PI * i / static_cast<double>(N - 1);
        double w = a0 - a1 * std::cos(frac) + a2 * std::cos(2.0 * frac) - a3 * std::cos(3.0 * frac);
        window[i] = static_cast<float>(w);
        winSum += w;
    }
    const float winNorm = static_cast<float>(2.0 / winSum);

    // Estrattore Goertzel per ampiezza a frequenza specifica (con finestra Blackman-Harris)
    auto measureMagAtFreq = [&](const std::vector<float>& sig, double targetFreq) -> float {
        const double k = targetFreq * N / sr;
        const double omega = 2.0 * dsp171::PI * k / N;
        const double cosine = std::cos(omega);
        const double sine = std::sin(omega);
        const double coeff = 2.0 * cosine;

        double q0 = 0.0, q1 = 0.0, q2 = 0.0;
        for (int i = 0; i < N; ++i) {
            double sample = sig[i] * window[i];
            q0 = coeff * q1 - q2 + sample;
            q2 = q1;
            q1 = q0;
        }
        double real = q1 - q2 * cosine;
        double imag = q2 * sine;
        double mag = std::sqrt(real * real + imag * imag) * winNorm;
        return static_cast<float>(mag);
    };

    // Misurazioni su segnale 4x Oversampled
    TwinToneResult res{};
    res.fund19kDb = linToDb(measureMagAtFreq(output4x, 19000.0));
    res.fund20kDb = linToDb(measureMagAtFreq(output4x, 20000.0));
    res.imd1kDb   = linToDb(measureMagAtFreq(output4x, 1000.0));
    res.imd18kDb  = linToDb(measureMagAtFreq(output4x, 18000.0));
    res.imd21kDb  = linToDb(measureMagAtFreq(output4x, 21000.0));

    // Aliased harmonics su 4x vs 1x
    // 2*f2 = 40000 -> aliases to 44100 - 40000 = 4100 Hz
    // f1+f2 = 39000 -> aliases to 44100 - 39000 = 5100 Hz
    // 2*f1 = 38000 -> aliases to 44100 - 38000 = 6100 Hz
    res.aliased4k1Db = linToDb(measureMagAtFreq(output4x, 4100.0));
    res.aliased5k1Db = linToDb(measureMagAtFreq(output4x, 5100.0));
    res.aliased6k1Db = linToDb(measureMagAtFreq(output4x, 6100.0));

    float aliased1x_4k1 = linToDb(measureMagAtFreq(output1x, 4100.0));
    float aliased1x_5k1 = linToDb(measureMagAtFreq(output1x, 5100.0));
    float aliased1x_6k1 = linToDb(measureMagAtFreq(output1x, 6100.0));
    float max1xAlias = std::max({ aliased1x_4k1, aliased1x_5k1, aliased1x_6k1 });
    float max4xAlias = std::max({ res.aliased4k1Db, res.aliased5k1Db, res.aliased6k1Db });

    res.aliasedSpurMaxDb = max4xAlias;
    res.aliasingRejectionDb = max1xAlias - max4xAlias;
    res.pass = (res.aliasedSpurMaxDb < -90.0f) && (res.aliasingRejectionDb > 50.0f);

    std::stringstream ss;
    ss << "  Fundamental 19.0 kHz : " << std::fixed << std::setprecision(2) << res.fund19kDb << " dBFS\n";
    ss << "  Fundamental 20.0 kHz : " << std::fixed << std::setprecision(2) << res.fund20kDb << " dBFS\n";
    ss << "  ----------------------------------------------------------------\n";
    ss << "  Physical Audio IMD2 (1.0 kHz = f2 - f1)        : " << std::fixed << std::setprecision(2) << res.imd1kDb << " dBFS (" << (res.imd1kDb - res.fund19kDb) << " dBr)\n";
    ss << "  Physical Audio IMD3 Lower (18.0 kHz = 2f1 - f2): " << std::fixed << std::setprecision(2) << res.imd18kDb << " dBFS (" << (res.imd18kDb - res.fund19kDb) << " dBr)\n";
    ss << "  Physical Audio IMD3 Upper (21.0 kHz = 2f2 - f1): " << std::fixed << std::setprecision(2) << res.imd21kDb << " dBFS (" << (res.imd21kDb - res.fund19kDb) << " dBr)\n";
    ss << "  ----------------------------------------------------------------\n";
    ss << "  Aliasing at 4.1 kHz (folded 2*f2)   | 1x: " << std::setw(6) << aliased1x_4k1 << " dBFS -> 4x OS: " << std::setw(6) << res.aliased4k1Db << " dBFS (Suppression: " << (aliased1x_4k1 - res.aliased4k1Db) << " dB)\n";
    ss << "  Aliasing at 5.1 kHz (folded f1+f2)  | 1x: " << std::setw(6) << aliased1x_5k1 << " dBFS -> 4x OS: " << std::setw(6) << res.aliased5k1Db << " dBFS (Suppression: " << (aliased1x_5k1 - res.aliased5k1Db) << " dB)\n";
    ss << "  Aliasing at 6.1 kHz (folded 2*f1)   | 1x: " << std::setw(6) << aliased1x_6k1 << " dBFS -> 4x OS: " << std::setw(6) << res.aliased6k1Db << " dBFS (Suppression: " << (aliased1x_6k1 - res.aliased6k1Db) << " dB)\n";
    ss << "  ----------------------------------------------------------------\n";
    ss << "  Max Residual Aliasing Floor in Audio Band: " << res.aliasedSpurMaxDb << " dBFS\n";
    ss << "  Total Oversampling Anti-Aliasing Rejection: " << res.aliasingRejectionDb << " dB\n";
    ss << "  -> [" << (res.pass ? "PASS - STUDIO REFERENCE ANTI-ALIASING" : "FAIL") << "]\n";
    logBoth(ss.str());

    return res;
}

// ==============================================================================
//  TEST 4: HARD REAL-TIME AUDIT - ZERO HEAP ALLOCATIONS UNDER WILD AUTOMATION
//  1000 consecutive blocks under simultaneous modulation of all APVTS params
// ==============================================================================
struct RealTimeAuditResult {
    int blocksTested;
    int samplesProcessed;
    size_t heapAllocationsAudioThread;
    size_t heapDeallocationsAudioThread;
    double totalExecutionTimeMs;
    double avgBlockTimeUs;
    bool pass;
};

RealTimeAuditResult runHardRealTimeAudit() {
    logBoth("\n================================================================================\n");
    logBoth(" [AUDIT 4] HARD REAL-TIME AUDIT: 1000 BLOCKS UNDER WILD PARAMETER MODULATION\n");
    logBoth("================================================================================\n");

    const double sr = 48000.0;
    constexpr int blockSize = 512;
    constexpr int totalBlocks = 1000;

    AudioPluginAudioProcessor processor;
    processor.prepareToPlay(sr, blockSize);

    auto& apvts = processor.getAPVTS();
    auto* driveRaw    = apvts.getRawParameterValue("preamp_drive");
    auto* flavorRaw   = apvts.getRawParameterValue("preamp_flavor");
    auto* warmthRaw   = apvts.getRawParameterValue("preamp_warmth");
    auto* mixRaw      = apvts.getRawParameterValue("preamp_mix");
    auto* diodeOnRaw  = apvts.getRawParameterValue("diode_enable");
    auto* diodeDrRaw  = apvts.getRawParameterValue("diode_drive");
    auto* eqOnRaw     = apvts.getRawParameterValue("eq_enable");
    auto* eqHpfRaw    = apvts.getRawParameterValue("eq_hpf");
    auto* eqLowFRaw   = apvts.getRawParameterValue("eq_low_freq");
    auto* eqLowGRaw   = apvts.getRawParameterValue("eq_low_gain");
    auto* eqMidFRaw   = apvts.getRawParameterValue("eq_mid_freq");
    auto* eqMidGRaw   = apvts.getRawParameterValue("eq_mid_gain");
    auto* eqHiGRaw    = apvts.getRawParameterValue("eq_high_gain");
    auto* deEssOnRaw  = apvts.getRawParameterValue("deesser_enable");
    auto* deEssRedRaw = apvts.getRawParameterValue("deesser_reduction");
    auto* deEssMdRaw  = apvts.getRawParameterValue("deesser_mode");
    auto* deEssFRaw   = apvts.getRawParameterValue("deesser_freq");
    auto* deEssDlRaw  = apvts.getRawParameterValue("deesser_delta");
    auto* outGainRaw  = apvts.getRawParameterValue("out_gain");
    auto* ceilOnRaw   = apvts.getRawParameterValue("safe_ceiling_enable");
    auto* bypassRaw   = apvts.getRawParameterValue("bypass");

    juce::AudioBuffer<float> buffer(2, blockSize);
    juce::MidiBuffer midi;

    // Riempie il buffer con segnale dinamico
    for (int i = 0; i < blockSize; ++i) {
        float val = 0.3f * std::sin(2.0 * dsp171::PI * 440.0 * i / sr);
        buffer.setSample(0, i, val);
        buffer.setSample(1, i, val);
    }

    // Warm-up per stabilizzare qualsiasi inizializzazione
    for (int b = 0; b < 20; ++b) {
        processor.processBlock(buffer, midi);
    }

    // ARMA LA TRAPPOLA GLOBALE DI ALLOCAZIONE HEAP
    gAudioThreadAllocations.store(0, std::memory_order_relaxed);
    gAudioThreadDeallocations.store(0, std::memory_order_relaxed);
    gTrapAudioThreadAllocations = true;

    auto startClock = std::chrono::high_resolution_clock::now();

    for (int b = 0; b < totalBlocks; ++b) {
        if (b < 5 || b % 100 == 0) {
            std::cout << "  [Audit 4] block " << b << "/" << totalBlocks 
                      << " (allocs=" << gAudioThreadAllocations.load() 
                      << " deallocs=" << gAudioThreadDeallocations.load() << ")" << std::endl;
        }
        // Ingresso audio dinamico fresco per ogni blocco
        for (int i = 0; i < blockSize; ++i) {
            float val = 0.25f * std::sin(2.0 * dsp171::PI * (220.0 + (b % 8) * 110.0) * i / sr);
            buffer.setSample(0, i, val);
            buffer.setSample(1, i, val);
        }
        // Modulazione selvaggia di TUTTI i 21 parametri contemporaneamente ad ogni blocco
        driveRaw->store(-18.0f + 42.0f * (0.5f + 0.5f * std::sin(b * 0.05f)), std::memory_order_relaxed);
        flavorRaw->store(static_cast<float>(b % 4), std::memory_order_relaxed);
        warmthRaw->store(0.5f + 0.5f * std::cos(b * 0.07f), std::memory_order_relaxed);
        mixRaw->store(0.5f + 0.5f * std::sin(b * 0.03f), std::memory_order_relaxed);
        diodeOnRaw->store((b % 5) == 0 ? 1.0f : 0.0f, std::memory_order_relaxed);
        diodeDrRaw->store(0.5f + 0.5f * std::sin(b * 0.09f), std::memory_order_relaxed);
        eqOnRaw->store((b % 7) == 0 ? 0.0f : 1.0f, std::memory_order_relaxed);
        eqHpfRaw->store(static_cast<float>(b % 5), std::memory_order_relaxed);
        eqLowFRaw->store(static_cast<float>(b % 5), std::memory_order_relaxed);
        eqLowGRaw->store(-16.0f + 32.0f * (0.5f + 0.5f * std::cos(b * 0.04f)), std::memory_order_relaxed);
        eqMidFRaw->store(static_cast<float>(b % 7), std::memory_order_relaxed);
        eqMidGRaw->store(-18.0f + 36.0f * (0.5f + 0.5f * std::sin(b * 0.06f)), std::memory_order_relaxed);
        eqHiGRaw->store(-16.0f + 32.0f * (0.5f + 0.5f * std::sin(b * 0.08f)), std::memory_order_relaxed);
        deEssOnRaw->store((b % 9) == 0 ? 0.0f : 1.0f, std::memory_order_relaxed);
        deEssRedRaw->store(0.5f + 0.5f * std::sin(b * 0.11f), std::memory_order_relaxed);
        deEssMdRaw->store(static_cast<float>(b % 3), std::memory_order_relaxed);
        deEssFRaw->store(5000.0f + 6000.0f * (0.5f + 0.5f * std::cos(b * 0.03f)), std::memory_order_relaxed);
        deEssDlRaw->store((b % 17) == 0 ? 1.0f : 0.0f, std::memory_order_relaxed);
        outGainRaw->store(-18.0f + 36.0f * (0.5f + 0.5f * std::cos(b * 0.05f)), std::memory_order_relaxed);
        ceilOnRaw->store((b % 2) == 0 ? 1.0f : 0.0f, std::memory_order_relaxed);
        bypassRaw->store((b % 23) == 0 ? 1.0f : 0.0f, std::memory_order_relaxed);

        processor.processBlock(buffer, midi);

        // Simula GUI pop concorrente dalla FIFO per svuotare periodicamente
        if (b % 4 == 0) {
            dsp171::VisualFrame frame;
            while (processor.getVisualFIFO().pop(frame)) {}
        }
    }

    auto endClock = std::chrono::high_resolution_clock::now();
    gTrapAudioThreadAllocations = false;

    std::chrono::duration<double, std::milli> elapsedMs = endClock - startClock;

    RealTimeAuditResult res{};
    res.blocksTested = totalBlocks;
    res.samplesProcessed = totalBlocks * blockSize;
    res.heapAllocationsAudioThread = gAudioThreadAllocations.load(std::memory_order_relaxed);
    res.heapDeallocationsAudioThread = gAudioThreadDeallocations.load(std::memory_order_relaxed);
    res.totalExecutionTimeMs = elapsedMs.count();
    res.avgBlockTimeUs = (res.totalExecutionTimeMs * 1000.0) / totalBlocks;
    res.pass = (res.heapAllocationsAudioThread == 0) && (res.heapDeallocationsAudioThread == 0);

    const double audioDurationSec = static_cast<double>(res.samplesProcessed) / sr;
    const double realTimeMultiplier = audioDurationSec / (res.totalExecutionTimeMs / 1000.0);

    std::stringstream ss;
    ss << "  Consecutive Blocks Processed : " << res.blocksTested << " (" << res.samplesProcessed << " samples, " << audioDurationSec << " s audio)\n";
    ss << "  APVTS Parameters Modulated   : 21 parameters simultaneous per-block sweep\n";
    ss << "  Audio Thread Allocations     : " << res.heapAllocationsAudioThread << " BYTES\n";
    ss << "  Audio Thread Deallocations   : " << res.heapDeallocationsAudioThread << " EVENTS\n";
    ss << "  Total Computation Time       : " << std::fixed << std::setprecision(2) << res.totalExecutionTimeMs << " ms\n";
    ss << "  Average Execution per Block  : " << std::fixed << std::setprecision(2) << res.avgBlockTimeUs << " us (Host Budget: 10666 us @ 512spls)\n";
    ss << "  Throughput Speedup           : " << std::fixed << std::setprecision(1) << realTimeMultiplier << "x Real-Time\n";
    ss << "  -> [" << (res.pass ? "PASS - STRICT ZERO HEAP HARD REAL-TIME CERTIFIED" : "FAIL - FORBIDDEN HEAP ACTIVITY DETECTED") << "]\n";
    logBoth(ss.str());

    return res;
}

// ==============================================================================
//  TEST 5: HARDWARE DENORMAL BENCHMARK (FTZ/DAZ SSE/AVX AUDIT)
// ==============================================================================
struct DenormalBenchmarkResult {
    double normalTimeMs;
    double subnormalTimeMs;
    double ratio;
    double normalThroughputMSamples;
    double subnormalThroughputMSamples;
    bool pass;
};

DenormalBenchmarkResult runDenormalBenchmark() {
    logBoth("\n================================================================================\n");
    logBoth(" [AUDIT 5] HARDWARE DENORMAL BENCHMARK: NORMAL VS SUBNORMAL (FTZ/DAZ)\n");
    logBoth("================================================================================\n");

    const double sr = 48000.0;
    constexpr int blockSize = 512;
    constexpr int totalBlocks = 500; // 256,000 campioni = 5.33 secondi di audio
    const int totalSamples = totalBlocks * blockSize;

    AudioPluginAudioProcessor processorNormal;
    processorNormal.prepareToPlay(sr, blockSize);
    processorNormal.setCurrentProgram(0);

    AudioPluginAudioProcessor processorSubnormal;
    processorSubnormal.prepareToPlay(sr, blockSize);
    processorSubnormal.setCurrentProgram(0);

    juce::AudioBuffer<float> bufNormal(2, blockSize);
    for (int i = 0; i < blockSize; ++i) {
        float s = 0.10f * std::sin(2.0 * dsp171::PI * 1000.0 * i / sr);
        bufNormal.setSample(0, i, s);
        bufNormal.setSample(1, i, s);
    }

    juce::AudioBuffer<float> bufSubnormal(2, blockSize);
    for (int i = 0; i < blockSize; ++i) {
        bufSubnormal.setSample(0, i, 1.0e-38f);
        bufSubnormal.setSample(1, i, 1.0e-38f);
    }
    juce::MidiBuffer midi;

    // 5A: Benchmark con Segnale Normale (-20 dBFS sine)
    auto startNormal = std::chrono::high_resolution_clock::now();
    for (int b = 0; b < totalBlocks; ++b) {
        processorNormal.processBlock(bufNormal, midi);
    }
    auto endNormal = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> normDuration = endNormal - startNormal;

    // 5B: Benchmark con Segnale Subnormale/Denormale (1.0e-38f) sotto protezione FTZ/DAZ
    auto startSub = std::chrono::high_resolution_clock::now();
    for (int b = 0; b < totalBlocks; ++b) {
        processorSubnormal.processBlock(bufSubnormal, midi);
    }
    auto endSub = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> subDuration = endSub - startSub;

    DenormalBenchmarkResult res{};
    res.normalTimeMs = normDuration.count();
    res.subnormalTimeMs = subDuration.count();
    res.ratio = res.subnormalTimeMs / res.normalTimeMs;
    res.normalThroughputMSamples = (static_cast<double>(totalSamples) / (res.normalTimeMs / 1000.0)) / 1e6;
    res.subnormalThroughputMSamples = (static_cast<double>(totalSamples) / (res.subnormalTimeMs / 1000.0)) / 1e6;
    // Nessun rallentamento da microcodice (ratio compreso tra 0.7x e 1.35x)
    res.pass = (res.ratio <= 1.35);

    std::stringstream ss;
    ss << "  Samples Processed Per Test : " << totalSamples << " stereo samples (" << (totalSamples / sr) << " s audio)\n";
    ss << "  Normal Signal Time         : " << std::fixed << std::setprecision(2) << res.normalTimeMs << " ms (" << res.normalThroughputMSamples << " MSamples/s)\n";
    ss << "  Subnormal (1e-38) Time     : " << std::fixed << std::setprecision(2) << res.subnormalTimeMs << " ms (" << res.subnormalThroughputMSamples << " MSamples/s)\n";
    ss << "  CPU Penalty Ratio          : " << std::fixed << std::setprecision(3) << res.ratio << "x (Stall Tolerance: < 1.35x, Non-FTZ can be > 50x)\n";
    ss << "  -> [" << (res.pass ? "PASS - ZERO HARDWARE DENORMAL PENALTY" : "FAIL - DENORMAL STALL DETECTED") << "]\n";
    logBoth(ss.str());

    return res;
}

// ==============================================================================
//  TEST 6: TRUE-PEAK LIMITER & CEILING SAFETY AUDIT (-0.05 dBTP)
// ==============================================================================
struct TruePeakAuditResult {
    std::string condition;
    float peakInDb;
    float peakOutSampleDb;
    float peakOutTruePeakDb;
    float truePeakCeilingTargetDb;
    int samplesExceedingTarget;
    bool pass;
};

std::vector<TruePeakAuditResult> runTruePeakSafetyAudit() {
    logBoth("\n================================================================================\n");
    logBoth(" [AUDIT 6] TRUE-PEAK LIMITER & CEILING SAFETY AUDIT (-0.05 dBTP CEILING)\n");
    logBoth("================================================================================\n");

    const double sr = 48000.0;
    constexpr int blockSize = 512;
    std::vector<TruePeakAuditResult> results;

    auto testTruePeak = [&](const std::string& label, auto synthFn) {
        AudioPluginAudioProcessor processor;
        processor.prepareToPlay(sr, blockSize);

        auto& apvts = processor.getAPVTS();
        // Safe Ceiling abilitato
        if (auto* p = apvts.getRawParameterValue("safe_ceiling_enable")) p->store(1.0f, std::memory_order_relaxed);

        HighPrecisionTruePeakMeter tpMeterL;
        HighPrecisionTruePeakMeter tpMeterR;

        TruePeakAuditResult res{};
        res.condition = label;
        res.truePeakCeilingTargetDb = -0.05f;

        float maxIn = 0.0f;
        float maxSampleOut = 0.0f;
        float maxTruePeakOut = 0.0f;
        int violations = 0;

        constexpr int numBlocks = 60;
        juce::AudioBuffer<float> buffer(2, blockSize);
        juce::MidiBuffer midi;

        for (int b = 0; b < numBlocks; ++b) {
            for (int i = 0; i < blockSize; ++i) {
                const int n = b * blockSize + i;
                float sL = 0.0f, sR = 0.0f;
                synthFn(n, sL, sR);
                buffer.setSample(0, i, sL);
                buffer.setSample(1, i, sR);
                maxIn = std::max(maxIn, std::max(std::abs(sL), std::abs(sR)));
            }

            processor.processBlock(buffer, midi);

            for (int i = 0; i < blockSize; ++i) {
                float vL = buffer.getSample(0, i);
                float vR = buffer.getSample(1, i);

                maxSampleOut = std::max(maxSampleOut, std::max(std::abs(vL), std::abs(vR)));
                float tpL = tpMeterL.processSample(vL);
                float tpR = tpMeterR.processSample(vR);
                float curTp = std::max(tpL, tpR);
                maxTruePeakOut = std::max(maxTruePeakOut, curTp);

                // Soglia di tolleranza numerica ITU-R BS.1770 (-0.05 dBTP = 0.99426f, soglia tolleranza 0.9944f)
                if (curTp > 0.99445f) {
                    violations++;
                }
            }
        }

        res.peakInDb = linToDb(maxIn);
        res.peakOutSampleDb = linToDb(maxSampleOut);
        res.peakOutTruePeakDb = linToDb(maxTruePeakOut);
        res.samplesExceedingTarget = violations;
        res.pass = (res.peakOutTruePeakDb <= -0.05f + 0.002f) && (violations == 0);

        std::stringstream ss;
        ss << "  " << std::left << std::setw(36) << res.condition
           << " | In: " << std::right << std::setw(6) << std::fixed << std::setprecision(1) << res.peakInDb << " dBFS"
           << " | Smp: " << std::setw(6) << std::fixed << std::setprecision(3) << res.peakOutSampleDb << " dBFS"
           << " | TP: " << std::setw(6) << std::fixed << std::setprecision(3) << res.peakOutTruePeakDb << " dBTP"
           << " | Violations: " << res.samplesExceedingTarget
           << " -> [" << (res.pass ? "PASS" : "FAIL") << "]\n";
        logBoth(ss.str());

        results.push_back(res);
    };

    // 6A: Intersample Over at Nyquist/4 (+0.99, +0.99, -0.99, -0.99 -> ISP > +2.9 dBFS)
    testTruePeak("Nyquist/4 Inter-Sample Overshoot", [](int n, float& l, float& r) {
        float val = (n % 4 == 0 || n % 4 == 1) ? 0.995f : -0.995f;
        l = val; r = val;
    });

    // 6B: Sfasamento frazionario 12 kHz a 48 kHz (+1.5 dBFS ISP)
    testTruePeak("Fractional Phase Sine (12 kHz)", [](int n, float& l, float& r) {
        double phi = 2.0 * dsp171::PI * 12000.0 * n / 48000.0 + (dsp171::PI * 0.25);
        float s = 0.99f * static_cast<float>(std::sin(phi));
        l = s; r = s;
    });

    // 6C: Intersample Stress con Boost Preamp (+12 dBFS)
    testTruePeak("Overdriven Preamp ISP (+12 dB Drive)", [](int n, float& l, float& r) {
        float s = 4.0f * static_cast<float>(std::sin(2.0 * dsp171::PI * 1000.0 * n / 48000.0));
        l = s; r = s;
    });

    return results;
}

// ==============================================================================
//  TEST 7: BIT-EXACT LATENCY-COMPENSATED DRY BYPASS TRANSPARENCY
// ==============================================================================
struct BypassAuditResult {
    int totalLatency;
    int samplesTested;
    float maxAbsDifference;
    double snrDb;
    bool bitExact;
};

BypassAuditResult runBypassTransparencyAudit() {
    logBoth("\n================================================================================\n");
    logBoth(" [AUDIT 7] BIT-EXACT LATENCY-COMPENSATED DRY BYPASS TRANSPARENCY\n");
    logBoth("================================================================================\n");

    const double sr = 48000.0;
    constexpr int blockSize = 512;
    AudioPluginAudioProcessor processor;
    processor.prepareToPlay(sr, blockSize);

    const int latency = processor.getLatencySamples();

    // Attivazione Master Bypass
    auto& apvts = processor.getAPVTS();
    if (auto* p = apvts.getRawParameterValue("bypass")) {
        p->store(1.0f, std::memory_order_relaxed);
    }

    constexpr int totalBlocks = 50;
    constexpr int totalSamples = totalBlocks * blockSize;

    std::vector<float> inputHistoryL(totalSamples);
    std::vector<float> inputHistoryR(totalSamples);
    std::mt19937 rng(42);
    std::uniform_real_distribution<float> dist(-0.8f, 0.8f);

    for (int i = 0; i < totalSamples; ++i) {
        inputHistoryL[i] = dist(rng);
        inputHistoryR[i] = dist(rng);
    }

    juce::AudioBuffer<float> buffer(2, blockSize);
    juce::MidiBuffer midi;

    // Esegui i primi 10 blocchi (5120 campioni) per far completare la rampa di smoothing di 15 ms
    for (int b = 0; b < 10; ++b) {
        for (int i = 0; i < blockSize; ++i) {
            int idx = b * blockSize + i;
            buffer.setSample(0, i, inputHistoryL[idx]);
            buffer.setSample(1, i, inputHistoryR[idx]);
        }
        processor.processBlock(buffer, midi);
    }

    // Ora verifichiamo la trasparenza bit-exact sui blocchi successivi
    float maxDelta = 0.0f;
    double sumSqDiff = 0.0;
    double sumSqSig = 0.0;
    int testedCount = 0;

    for (int b = 10; b < totalBlocks; ++b) {
        for (int i = 0; i < blockSize; ++i) {
            int idx = b * blockSize + i;
            buffer.setSample(0, i, inputHistoryL[idx]);
            buffer.setSample(1, i, inputHistoryR[idx]);
        }
        processor.processBlock(buffer, midi);

        for (int i = 0; i < blockSize; ++i) {
            int currentSample = b * blockSize + i;
            int delayedSample = currentSample - latency;
            if (delayedSample >= 0) {
                float expectedL = inputHistoryL[delayedSample];
                float actualL = buffer.getSample(0, i);
                float deltaL = std::abs(actualL - expectedL);

                float expectedR = inputHistoryR[delayedSample];
                float actualR = buffer.getSample(1, i);
                float deltaR = std::abs(actualR - expectedR);

                maxDelta = std::max({ maxDelta, deltaL, deltaR });
                sumSqDiff += static_cast<double>(deltaL) * deltaL + static_cast<double>(deltaR) * deltaR;
                sumSqSig  += static_cast<double>(expectedL) * expectedL + static_cast<double>(expectedR) * expectedR;
                testedCount += 2;
            }
        }
    }

    BypassAuditResult res{};
    res.totalLatency = latency;
    res.samplesTested = testedCount;
    res.maxAbsDifference = maxDelta;
    res.snrDb = (sumSqDiff > 1e-25) ? 10.0 * std::log10(sumSqSig / sumSqDiff) : 300.0;
    res.bitExact = (maxDelta == 0.0f);

    std::stringstream ss;
    ss << "  Plugin DAW Latency Reported : " << res.totalLatency << " samples\n";
    ss << "  Samples Compared in Bypass  : " << res.samplesTested << " samples\n";
    ss << "  Max Peak Difference (Error) : " << std::scientific << std::setprecision(6) << res.maxAbsDifference << " (Bit-Exact: 0.000000e+00)\n";
    ss << "  Signal-to-Error SNR         : " << std::fixed << std::setprecision(1) << res.snrDb << " dB (Bit-Exact = +INF / > 300 dB)\n";
    ss << "  -> [" << (res.bitExact ? "PASS - 100% BIT-EXACT ZERO LEAKAGE TRANSPARENCY" : "FAIL") << "]\n";
    logBoth(ss.str());

    return res;
}

// ==============================================================================
//  MAIN - ESECUZIONE COMPLETA E GENERAZIONE DEL REPORT FORENSE
// ==============================================================================
int main(int /*argc*/, char* /*argv*/[]) {
    juce::ScopedJuceInitialiser_GUI guiInit;

    auto timeNow = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    char timeStr[64];
    std::strftime(timeStr, sizeof(timeStr), "%Y-%m-%d %H:%M:%S", std::localtime(&timeNow));

    logBoth("################################################################################\n");
    logBoth("  171 STUDIO INNOVATION - ADVERSARIAL DSP STRESS TEST & METROLOGY REPORT\n");
    logBoth("  TARGET: 171PerfectPre v2.1.0 (Release x64 Native Clang/MSVC AVX2)\n");
    logBoth(std::string("  EXECUTION TIMESTAMP: ") + timeStr + "\n");
    logBoth("################################################################################\n");

    // Esecuzione di tutti gli audit
    auto msrResults = runMultiSampleRateAudit();
    auto pathResults = runPathologicalStressTest();
    auto ttResult   = runTwinToneIntermodulationAudit();
    auto rtResult   = runHardRealTimeAudit();
    auto denormResult = runDenormalBenchmark();
    auto tpResults  = runTruePeakSafetyAudit();
    auto bypassResult = runBypassTransparencyAudit();

    // Verifiche complessive
    bool allPass = true;
    for (const auto& r : msrResults)  if (!r.pass) allPass = false;
    for (const auto& r : pathResults) if (!r.pass) allPass = false;
    if (!ttResult.pass) allPass = false;
    if (!rtResult.pass) allPass = false;
    if (!denormResult.pass) allPass = false;
    for (const auto& r : tpResults)   if (!r.pass) allPass = false;
    if (!bypassResult.bitExact) allPass = false;

    logBoth("\n================================================================================\n");
    logBoth("  SUMMARY AUDIT VERDICT\n");
    logBoth("================================================================================\n");
    logBoth(std::string("  1. Multi-Sample Rate Audit       : ") + (allPass ? "PASS (44.1k - 192k 100% stable)" : "FAIL") + "\n");
    logBoth(std::string("  2. Pathological Input Immunity   : ") + (allPass ? "PASS (Zero NaNs/Infs, Ceiling Confined)" : "FAIL") + "\n");
    logBoth(std::string("  3. Aliasing & IMD Twin-Tone      : ") + (ttResult.pass ? "PASS (> 90 dB Aliasing Floor, IMD2/3 Preserved)" : "FAIL") + "\n");
    logBoth(std::string("  4. Hard Real-Time Zero Heap      : ") + (rtResult.pass ? "PASS (EXACTLY 0 HEAP ALLOCATIONS across 1000 blocks)" : "FAIL") + "\n");
    logBoth(std::string("  5. Hardware Denormal Benchmark   : ") + (denormResult.pass ? "PASS (FTZ/DAZ 1.0x Ratio, Zero Penalty)" : "FAIL") + "\n");
    logBoth(std::string("  6. True-Peak Limiter (-0.05 dBTP): ") + (allPass ? "PASS (0 Violations on Severe ISP)" : "FAIL") + "\n");
    logBoth(std::string("  7. Latency-Compensated Bypass    : ") + (bypassResult.bitExact ? "PASS (100% BIT-EXACT Identical)" : "FAIL") + "\n");
    logBoth("--------------------------------------------------------------------------------\n");
    logBoth(std::string("  OVERALL STRESS AUDIT VERDICT     : [") + (allPass ? "100% SUCCESS - PRODUCTION READY" : "FAILURE DETECTED") + "]\n");
    logBoth("================================================================================\n");

    // Scrivi il report su file
    const juce::File reportFile(R"(c:\Users\171Studio\Downloads\PLUGI SUITE 171 STUDIO INNOVATIO\projects\171PerfectPre\Tests\ADVERSARIAL_DSP_STRESS_REPORT.txt)");
    reportFile.deleteFile();
    juce::FileOutputStream stream(reportFile);
    if (stream.openedOk()) {
        stream.writeString(gReportStream.str());
        std::cout << "\n[+] Forensic Stress Test Report saved to: " << reportFile.getFullPathName() << "\n";
    } else {
        std::cerr << "\n[-] Error saving report to: " << reportFile.getFullPathName() << "\n";
    }

    return allPass ? 0 : 1;
}
