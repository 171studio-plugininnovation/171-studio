# 🍏 DOSSIER TECNICO DI TRASPOSIZIONE — PERFECTPRE
### Multi-Flavor Console Preamplifier, Discrete EQ & Phase De-Esser per Apple macOS

**Progetto:** 171 PerfectPre (`v2.2.0 Gold Master`)  
**Architettura:** Universal Binary Fat (`arm64` Apple Silicon M1-M4 + `x86_64` Intel)  
**Deployment Target Minimo:** macOS 11.0 Big Sur  
**Approvato da:** Il Direttore  
**Coordinamento:** `dsp-hire-manager`, `sat-neve-specialist`, `sat-api-specialist` & `apple-macos-engineer`  
**Status Certificazione:** *Gold Master v2.2.0 - Neve 1073 Metrology & Analog Preamp Certified*

---

## 1. SPECIFICHE FORMATI & METADATI APPLE AUDIOUNIT

| Parametro | Valore Configurato | Specifiche per DAW macOS |
|---|---|---|
| **AudioUnit Type** | `kAudioUnitType_Effect` (`'aufx'`) | Inseribile come preamplificatore di canale in **Logic Pro** e GarageBand |
| **Manufacturer Code** | `'171P'` | Conforme alle specifiche Apple (include almeno una maiuscola) |
| **Plugin Code / Subtype** | `'171V'` | Identificativo univoco a 4 caratteri per scansione AU |
| **Target Formati Mac** | **AU (`.component`)**, **VST3 (`.vst3`)**, **Standalone (`.app`)** | AU per Logic Pro; VST3 per Ableton, Cubase, Studio One, Reaper, FL |
| **Sicurezza Gatekeeper** | Hardened Runtime attivo | Flag `--options runtime` + entitlements JIT e Unsigned Memory |

---

## 2. METROLOGIA GOLD MASTER & ANALOG MODELING (v2.2.0)

PerfectPre racchiude il calore, il punch e la fedeltà metrologica dei banchi analogici d'epoca certificati:

1. **Disaccoppiamento Induttivo HPF Neve 1073 (18 dB/ottava)**:
   - Stadio di filtro passa-alto modellato su induttanze autentiche tramite topologia SVF a 2 poli ($f = f_c \times 1.05323$, $Q = 0.96429$) e polo reale a 1 polo ($f = f_c \times 0.81234$).
   - Punto di taglio a -3.000 dB esatto (errore < 0.01 dB) e riproduzione autentica della risonanza passiva induttiva (+0.200 dB a $1.25 \times f_c$).
2. **Decramping Analitico Andy Simper per High Shelf 12 kHz**:
   - Linearizzazione della banda aria a 44.1 kHz con corrispondenza continua a Nyquist ($m_0 = |H_{\text{analog}}(j \pi f_s)|$).
   - Errore a 20 kHz ridotto da +2.49 dB a 0.69 dB e allineamento di fase tra 44.1 kHz e 96 kHz a soli 0.07 dB.
3. **Normalizzazione Guadagno Piccoli Segnali (Drive 0 dB)**:
   - Guadagno unitario a 0.00 dB esatti su tutti i 4 preamp (British Vintage fattore $1/1.40$, Germanium fattore $1/1.55$).
   - Ripristino dello slew-rate Germanium a 1 kHz da -23.7 dBFS a -3.88 dBFS senza alcuna perdita di livello complessivo.
4. **Saturazione American Tube Asintotica $C^\infty$ Continua**:
   - Curva asintotica continua senza alcuno spigolo o gradino di clipping ($neg / \sqrt{1 + 0.35 \times warmth \times neg^2}$).
5. **Robustezza & Precisione Numerica**:
   - Immunità assoluta a NaN/Inf su segnali patologici all'ingresso.
   - Master Bypass IEEE-754 bit-exact (0.00000000 errore) e zero allocazioni heap nel thread audio (0 allocazioni su 128.000 campioni).

---

## 3. INTERFACCIA RETINA A 60 FPS (BOUTIQUE LUXURY)

- **Targhette Serigrafate in Ottone Satinato**: Asset incisi in metallo spazzolato per ogni controllo (`plate_diode_drive.png`, `plate_preamp_mix.png`, `plate_s_reduction.png`).
- **Indicatori VU Meter Vintage**: Controllo istantaneo della saturazione e dei livelli I/O con precisione balistica a 60 FPS.
- **Rendering Asincrono Liquid Retina**: Perfetta risposta grafica senza sovraccaricare la GPU unificata Apple Silicon.

---

## 4. COMANDO DI COMPILAZIONE RAPIDA

```bash
# Esegui da terminale Mac:
./scripts/build_171perfectpre_mac.sh

# Validazione Apple auval per Logic Pro:
auval -v aufx 171V 171P
```
