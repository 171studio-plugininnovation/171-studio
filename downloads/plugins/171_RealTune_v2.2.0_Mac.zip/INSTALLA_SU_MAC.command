#!/bin/bash
# ==============================================================================
# 🍏 171 STUDIO INNOVATIO — INSTALLATORE UFFICIALE macOS (Apple Silicon & Intel)
# Plugin: 171 RealTune (v2.2.0 Release Ufficiale)
# Architetture Supportate: ARM64 (M1/M2/M3/M4) + x86_64 (Intel)
# Formati: AudioUnit v2 (.component), VST3 (.vst3), Standalone App (.app)
# ==============================================================================

set -e
DIR="$(cd "$(dirname "$0")" && pwd)"

echo "======================================================================"
echo " 🍏 171 STUDIO INNOVATIO — INSTALLATORE UFFICIALE macOS"
echo " Plugin: 171 RealTune (v2.2.0)"
echo "======================================================================"
echo ""

USER_AU="$HOME/Library/Audio/Plug-Ins/Components"
USER_VST3="$HOME/Library/Audio/Plug-Ins/VST3"
USER_APP="/Applications/171 Studio"

mkdir -p "$USER_AU" "$USER_VST3" "$USER_APP"

# 1. Installazione AudioUnit (.component)
if [ -d "$DIR/171RealTune.component" ]; then
    echo "▶ Installazione AudioUnit v2 per Logic Pro / GarageBand..."
    rm -rf "$USER_AU/171RealTune.component"
    cp -R "$DIR/171RealTune.component" "$USER_AU/"
    echo "  ✔ Copiato in $USER_AU/171RealTune.component"
fi

# 2. Installazione VST3 (.vst3)
if [ -d "$DIR/171RealTune.vst3" ]; then
    echo "▶ Installazione VST3 per Ableton Live / FL Studio / Cubase / Studio One / Reaper..."
    rm -rf "$USER_VST3/171RealTune.vst3"
    cp -R "$DIR/171RealTune.vst3" "$USER_VST3/"
    echo "  ✔ Copiato in $USER_VST3/171RealTune.vst3"
fi

# 3. Installazione Standalone App (.app)
if [ -d "$DIR/171RealTune.app" ]; then
    echo "▶ Installazione Standalone App..."
    rm -rf "$USER_APP/171RealTune.app"
    cp -R "$DIR/171RealTune.app" "$USER_APP/"
    echo "  ✔ Copiato in $USER_APP/171RealTune.app"
fi

# 4. Risoluzione permessi Apple Gatekeeper (Quarantine bypass)
echo ""
echo "▶ Verifica sicurezza e sblocco Apple Gatekeeper..."
xattr -dr com.apple.quarantine "$USER_AU/171RealTune.component" 2>/dev/null || true
xattr -dr com.apple.quarantine "$USER_VST3/171RealTune.vst3" 2>/dev/null || true
xattr -dr com.apple.quarantine "$USER_APP/171RealTune.app" 2>/dev/null || true
echo "  ✔ Attributi quarantine rimossi con successo."

# 5. Opzione Compilazione Nativa da Sorgenti
if [ -f "$DIR/Build_Kit_Universal_Mac/build_mac.sh" ]; then
    echo ""
    echo "----------------------------------------------------------------------"
    echo "Vuoi anche ricompilare i sorgenti C++/DSP nativamente sul tuo Mac con Clang/Xcode?"
    read -p "Eseguire build nativa ottimizzata vDSP NEON adesso? [s/N]: " comp
    if [[ "$comp" =~ ^[sSyY]$ ]]; then
        cd "$DIR/Build_Kit_Universal_Mac"
        chmod +x build_mac.sh
        ./build_mac.sh --install
    fi
fi

echo ""
echo "======================================================================"
echo "🎉 INSTALLAZIONE COMPLETATA CON SUCCESSO!"
echo "Apri Apple Logic Pro, Ableton Live, FL Studio Mac o Studio One."
echo "Per verificare la registrazione AU in Logic Pro, digita nel Terminale:"
echo "    auval -v aufx 171R 171P"
echo "======================================================================"
echo "171 Studio Innovatio — Messina, Italia"
echo ""
read -p "Premi INVIO per terminare..."
