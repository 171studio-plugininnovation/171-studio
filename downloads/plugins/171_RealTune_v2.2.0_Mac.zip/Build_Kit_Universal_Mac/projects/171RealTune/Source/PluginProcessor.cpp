#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <dsp171/ScopedDenormalDisabler.h>

AudioPluginAudioProcessor::AudioPluginAudioProcessor()
    : AudioProcessor(BusesProperties()
                     .withInput("Input", juce::AudioChannelSet::stereo(), true)
                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "Parameters", createParameterLayout())
{
    initializeParameterPointers();
}

AudioPluginAudioProcessor::~AudioPluginAudioProcessor() = default;

void AudioPluginAudioProcessor::initializeParameterPointers() noexcept {
    retuneSpeedParam    = apvts.getRawParameterValue("retune_speed");
    humanizeParam       = apvts.getRawParameterValue("humanize");
    scaleTypeParam      = apvts.getRawParameterValue("scale_type");
    rootKeyParam        = apvts.getRawParameterValue("root_key");
    amountParam         = apvts.getRawParameterValue("amount");
    formantShiftParam   = apvts.getRawParameterValue("formant_shift");
    keepFormantsParam   = apvts.getRawParameterValue("keep_formants");
    stereoWidthParam    = apvts.getRawParameterValue("stereo_width");
    mixParam            = apvts.getRawParameterValue("mix");
    outGainParam        = apvts.getRawParameterValue("out_gain");
    a4RefParam          = apvts.getRawParameterValue("a4_reference");
    midiModeParam       = apvts.getRawParameterValue("midi_mode");
    zeroLatencyParam    = apvts.getRawParameterValue("zero_latency");
    bypassMaskParam     = apvts.getRawParameterValue("bypass_mask");
    blockedMaskParam    = apvts.getRawParameterValue("blocked_mask");
    bypassParam         = apvts.getRawParameterValue("bypass");
    classicModeParam    = apvts.getRawParameterValue("classic_mode");
    flexTuneParam       = apvts.getRawParameterValue("flex_tune");
    throatLengthParam   = apvts.getRawParameterValue("throat_length");
    vocalRangeParam     = apvts.getRawParameterValue("vocal_range");
    noteTransitionParam = apvts.getRawParameterValue("note_transition");
    toleranceCentsParam = apvts.getRawParameterValue("tolerance_cents");
    vibratoDepthParam   = apvts.getRawParameterValue("vibrato_depth");
    trackingParam       = apvts.getRawParameterValue("tracking");
    smartBrainParam     = apvts.getRawParameterValue("smart_brain");
}

const std::vector<PluginPreset>& AudioPluginAudioProcessor::getFactoryPresets() {
    static const std::vector<PluginPreset> presets = {
        // name, speed, humanize, scale, root, amount, formantShift, keepFormants, stereoWidth, mix, outGain, bypass, classicMode, flexTune, throatLength, vocalRange, noteTransition, toleranceCents, vibratoDepth, tracking
        { "Travis Scott Classic 5",    0.0f,   0.0f, 2, 0, 100.0f,  0.0f, false, 100.0f, 100.0f, 0.0f, false,  true,   0.0f, 100.0f, 0,   0.0f,  0.0f, 100.0f, 75.0f },
        { "Waves RT Live Fast",       12.0f,  20.0f, 1, 0, 100.0f,  0.0f,  true, 100.0f, 100.0f, 0.0f, false, false,  10.0f, 100.0f, 0,   0.0f,  0.0f, 100.0f, 65.0f },
        { "Deep Cavern Formant",      15.0f,  30.0f, 2, 0, 100.0f, -4.0f,  true, 130.0f, 100.0f, 0.0f, false, false,  20.0f, 140.0f, 2,  10.0f,  0.0f, 100.0f, 50.0f },
        { "Subtle Transparent Vocal", 45.0f,  60.0f, 1, 0,  85.0f,  0.0f,  true, 100.0f, 100.0f, 0.0f, false, false,  40.0f, 100.0f, 3,  25.0f,  0.0f, 100.0f, 50.0f },
        { "Antares Flex-Tune Scoop",  20.0f,  45.0f, 1, 0, 100.0f,  0.0f,  true, 100.0f, 100.0f, 0.0f, false, false,  60.0f, 100.0f, 0,  15.0f,  0.0f, 100.0f, 50.0f },
        { "Bright Soprano / Falsetto",15.0f,  25.0f, 1, 9, 100.0f,  2.5f,  true, 110.0f, 100.0f, 0.0f, false, false,  30.0f,  85.0f, 1,  10.0f,  0.0f, 100.0f, 50.0f },
        { "Wide Stereo Double 160%",  20.0f,  50.0f, 0, 0, 100.0f,  0.0f,  true, 160.0f,  50.0f, 0.0f, false, false,  15.0f, 100.0f, 0,  10.0f,  0.0f, 100.0f, 50.0f },
        { "Hard-Tune Iconic Cher",     0.0f,   0.0f, 1, 0, 100.0f,  0.0f, false, 100.0f, 100.0f, 0.0f, false,  true,   0.0f, 100.0f, 0,   0.0f,  0.0f, 100.0f, 80.0f }
    };
    return presets;
}

juce::AudioProcessorValueTreeState::ParameterLayout AudioPluginAudioProcessor::createParameterLayout() {
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // Retune Speed: 0.0 ms (Hard-Tune istantaneo) a 100.0 ms (trasparente)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "retune_speed", 1 }, "Retune Speed",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f, 0.35f), 15.0f,
        juce::AudioParameterFloatAttributes().withLabel("ms")));

    // Humanize: 0% (snap rigido) a 100% (deadband vibrato naturale protetto)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "humanize", 1 }, "Humanize",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 25.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")));

    // Scale Type: 0 = Chromatic, 1 = Major, 2 = Natural Minor, 3 = Harmonic Minor, 4 = Pentatonic Major, 5 = Pentatonic Minor, 6 = Dorian, 7 = Custom
    juce::StringArray scales = { "Chromatic", "Major", "Natural Minor", "Harmonic Minor",
                                 "Pentatonic Major", "Pentatonic Minor", "Dorian", "Custom" };
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{ "scale_type", 1 }, "Scale Type", scales, 1));

    // Root Key: 0 = C, 1 = C#, 2 = D, 3 = D#, 4 = E, 5 = F, 6 = F#, 7 = G, 8 = G#, 9 = A, 10 = A#, 11 = B
    juce::StringArray roots = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{ "root_key", 1 }, "Root Key", roots, 0));

    // Amount: 0 a 100%
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "amount", 1 }, "Amount",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 100.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")));

    // Formant Shift: -12.0 a +12.0 semitoni
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "formant_shift", 1 }, "Formant Shift",
        juce::NormalisableRange<float>(-12.0f, 12.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel("st")));

    // Keep Formants: compensazione dinamica automatica dell'inviluppo spettrale durante retuning
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{ "keep_formants", 1 }, "Keep Formants", true));

    // Stereo Width: 0% (Mono) a 200% (Super-Wide con decorrelatore psicoacustico 100% mono cancellation-free)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "stereo_width", 1 }, "Stereo Width",
        juce::NormalisableRange<float>(0.0f, 200.0f, 1.0f), 100.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")));

    // Dry / Wet Mix: 0 a 100%
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "mix", 1 }, "Mix",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 100.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")));

    // Output Gain: -18.0 dB a +18.0 dB
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "out_gain", 1 }, "Output Gain",
        juce::NormalisableRange<float>(-18.0f, 18.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel("dB")));

    // Sintonizzazione di Riferimento LA4 (A4 Ref): 415.0 Hz a 466.0 Hz (default 440.0 Hz)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "a4_reference", 1 }, "A4 Reference",
        juce::NormalisableRange<float>(415.0f, 466.0f, 0.1f), 440.0f,
        juce::AudioParameterFloatAttributes().withLabel("Hz")));

    // Live MIDI Target Mode: Snap istantaneo verso la nota premuta su master keyboard
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{ "midi_mode", 1 }, "MIDI Target Snap", false));

    // Zero-Latency Monitoring Mode (Live Booth per cantanti in cuffia: 0 campioni PDC riportati all'host)
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{ "zero_latency", 1 }, "Live Zero-Latency", true));

    // Maschera semitonale Note Bypass (0..4095)
    params.push_back(std::make_unique<juce::AudioParameterInt>(
        juce::ParameterID{ "bypass_mask", 1 }, "Bypass Mask", 0, 4095, 0));

    // Maschera semitonale Note Blocked (0..4095)
    params.push_back(std::make_unique<juce::AudioParameterInt>(
        juce::ParameterID{ "blocked_mask", 1 }, "Blocked Mask", 0, 4095, 0));

    // Master Bypass
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{ "bypass", 1 }, "Bypass", false));

    // --- Nuovi Controlli Avanzati Auto-Tune Pro & Waves Tune Real-Time ---

    // Antares Classic Mode DSP (Auto-Tune 5 hard snap vs Modern ZDF)
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{ "classic_mode", 1 }, "Classic Mode DSP", false));

    // Antares Flex-Tune: 0% a 100% (ritira la correzione sulle note distanti)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "flex_tune", 1 }, "Flex-Tune",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")));

    // Antares Throat Length: 50% a 150% (modellazione fisica del tratto vocale)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "throat_length", 1 }, "Throat Length",
        juce::NormalisableRange<float>(50.0f, 150.0f, 1.0f), 100.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")));

    // Input Type / Vocal Range: 0 = Alto/Tenor, 1 = Soprano, 2 = Low Male, 3 = Wide
    juce::StringArray inputTypes = { "Alto / Tenor", "Soprano", "Low Male", "Wide" };
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{ "vocal_range", 1 }, "Vocal Range", inputTypes, 0));

    // Waves Tune Real-Time Note Transition: 0.0 ms a 800.0 ms (glide tra note distinte, default 0.0 ms instant)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "note_transition", 1 }, "Note Transition",
        juce::NormalisableRange<float>(0.0f, 800.0f, 0.5f, 0.4f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel("ms")));

    // Waves Tune Real-Time Tolerance Deadband: 0 a 40 cents
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "tolerance_cents", 1 }, "Tolerance",
        juce::NormalisableRange<float>(0.0f, 40.0f, 0.5f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel("cents")));

    // Waves Tune Real-Time Natural Vibrato Depth: 0% a 200% (100% = naturale)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "vibrato_depth", 1 }, "Natural Vibrato",
        juce::NormalisableRange<float>(0.0f, 200.0f, 1.0f), 100.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")));

    // Tracking Sensitivity: 0% a 100%
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "tracking", 1 }, "Tracking",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 50.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")));

    // 171 RealTune Neural Smart Brain (Context-Aware Micro-Inference)
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{ "smart_brain", 1 }, "Neural Smart Brain", true));

    return { params.begin(), params.end() };
}

void AudioPluginAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock) {
    const bool zeroLat = zeroLatencyParam ? (zeroLatencyParam->load(std::memory_order_relaxed) > 0.5f) : true;
    realTuneEngine.setLowLatencyMode(zeroLat);
    realTuneEngine.prepare(sampleRate, static_cast<size_t>(samplesPerBlock));

    for (auto& lim : truePeakLimiters) {
        lim.prepare(sampleRate);
    }

    latencyBypass.reset();

    // In Live Zero-Latency Mode: riporta 0 samples PDC all'host (zero compensazione DAW)
    // In Studio HQ: riporta l'esatta latenza deterministica per allineamento di fase tracce
    const int reportedLatency = zeroLat ? 0 : static_cast<int>(realTuneEngine.getLatencySamples());
    setLatencySamples(reportedLatency);
}

void AudioPluginAudioProcessor::releaseResources() {
    realTuneEngine.reset();
}

bool AudioPluginAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const {
    const auto& mainIn  = layouts.getMainInputChannelSet();
    const auto& mainOut = layouts.getMainOutputChannelSet();

    if (mainIn != mainOut)
        return false;

    return mainIn == juce::AudioChannelSet::mono() || mainIn == juce::AudioChannelSet::stereo();
}

void AudioPluginAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages) {
    dsp171::ScopedDenormalDisabler ftzGuard;

    const int numSamples  = buffer.getNumSamples();
    const int numChannels = buffer.getNumChannels();

    if (numSamples == 0 || numChannels == 0)
        return;

    // 0. Elaborazione Messaggi MIDI host per Live Target Note Steering
    for (const auto metadata : midiMessages) {
        const auto msg = metadata.getMessage();
        if (msg.isNoteOn()) {
            currentHeldMidiNote = msg.getNoteNumber();
        } else if (msg.isNoteOff() && msg.getNoteNumber() == currentHeldMidiNote) {
            currentHeldMidiNote = -1;
        } else if (msg.isAllNotesOff()) {
            currentHeldMidiNote = -1;
        }
    }

    // 1. Lettura Parametri APVTS (Lock-Free Hard Real-Time Atomic Loads)
    const float retuneSpeed  = retuneSpeedParam  ? retuneSpeedParam->load(std::memory_order_relaxed)  : 15.0f;
    const float humanize     = humanizeParam     ? humanizeParam->load(std::memory_order_relaxed)     : 25.0f;
    const int   scaleType    = scaleTypeParam    ? static_cast<int>(scaleTypeParam->load(std::memory_order_relaxed)) : 1;
    const int   rootKey      = rootKeyParam      ? static_cast<int>(rootKeyParam->load(std::memory_order_relaxed))   : 0;
    const float amount       = amountParam       ? amountParam->load(std::memory_order_relaxed)       : 100.0f;
    const float formantShift = formantShiftParam ? formantShiftParam->load(std::memory_order_relaxed) : 0.0f;
    const bool  keepFormants = keepFormantsParam ? (keepFormantsParam->load(std::memory_order_relaxed) > 0.5f) : true;
    const float stereoWidth  = stereoWidthParam  ? stereoWidthParam->load(std::memory_order_relaxed)  : 100.0f;
    const float mixVal       = mixParam          ? (mixParam->load(std::memory_order_relaxed) * 0.01f) : 1.0f;
    const float outGainDb    = outGainParam      ? outGainParam->load(std::memory_order_relaxed)      : 0.0f;
    const float a4Ref        = a4RefParam        ? a4RefParam->load(std::memory_order_relaxed)        : 440.0f;
    const bool  midiMode     = midiModeParam     ? (midiModeParam->load(std::memory_order_relaxed) > 0.5f) : false;
    const bool  zeroLatency  = zeroLatencyParam  ? (zeroLatencyParam->load(std::memory_order_relaxed) > 0.5f) : true;
    const uint16_t bypassMask  = bypassMaskParam  ? static_cast<uint16_t>(bypassMaskParam->load(std::memory_order_relaxed))  : 0;
    const uint16_t blockedMask = blockedMaskParam ? static_cast<uint16_t>(blockedMaskParam->load(std::memory_order_relaxed)) : 0;
    const bool  isBypassed   = bypassParam       ? (bypassParam->load(std::memory_order_relaxed) > 0.5f) : false;

    // Controlli Avanzati Auto-Tune Pro & Waves Tune Real-Time
    const bool  classicMode    = classicModeParam    ? (classicModeParam->load(std::memory_order_relaxed) > 0.5f) : false;
    const float flexTune       = flexTuneParam       ? flexTuneParam->load(std::memory_order_relaxed)       : 0.0f;
    const float throatLength   = throatLengthParam   ? throatLengthParam->load(std::memory_order_relaxed)   : 100.0f;
    const int   vocalRange     = vocalRangeParam     ? static_cast<int>(vocalRangeParam->load(std::memory_order_relaxed)) : 0;
    const float noteTransition = noteTransitionParam ? noteTransitionParam->load(std::memory_order_relaxed) : 120.0f;
    const float toleranceCents = toleranceCentsParam ? toleranceCentsParam->load(std::memory_order_relaxed) : 0.0f;
    const float vibratoDepth   = vibratoDepthParam   ? vibratoDepthParam->load(std::memory_order_relaxed)   : 100.0f;
    const float tracking       = trackingParam       ? trackingParam->load(std::memory_order_relaxed)       : 50.0f;
    const bool  smartBrain     = smartBrainParam     ? (smartBrainParam->load(std::memory_order_relaxed) > 0.5f) : true;

    // 2. Configurazione dinamica dell'engine
    realTuneEngine.setRetuneSpeedMs(retuneSpeed);
    realTuneEngine.setAmount(amount * 0.01f);
    realTuneEngine.setRootKey(rootKey);
    realTuneEngine.setScale(static_cast<dsp171::ScaleType>(scaleType));
    if (static_cast<dsp171::ScaleType>(scaleType) == dsp171::ScaleType::Custom) {
        uint16_t allowedCustom = (~blockedMask) & 0x0FFF;
        realTuneEngine.setCustomScaleMask(allowedCustom);
    }
    realTuneEngine.setHumanize(humanize);
    realTuneEngine.setKeepFormants(keepFormants);
    realTuneEngine.setStereoWidth(stereoWidth);
    realTuneEngine.setA4Reference(a4Ref);
    realTuneEngine.setMidiTarget(currentHeldMidiNote, midiMode && (currentHeldMidiNote >= 0));
    realTuneEngine.setBypassMask(bypassMask);
    realTuneEngine.setBlockedMask(blockedMask);
    realTuneEngine.setLowLatencyMode(zeroLatency);

    // Controlli Avanzati Auto-Tune Pro & Waves Tune RT
    realTuneEngine.setClassicMode(classicMode);
    realTuneEngine.setFlexTune(flexTune);
    realTuneEngine.setThroatLength(throatLength);
    realTuneEngine.setFormantShiftSemitones(formantShift);

    realTuneEngine.setInputType(vocalRange);
    realTuneEngine.setNoteTransitionMs(noteTransition);
    realTuneEngine.setTolerance(toleranceCents, (toleranceCents > 0.1f) ? 50.0f : 0.0f);
    realTuneEngine.setVibrato(true, vibratoDepth);
    realTuneEngine.setTracking(tracking);
    realTuneEngine.setNeuralBrainActive(smartBrain);

    // Gestione latenza deterministica host (Zero PDC in modalità Live Zero-Latency per cantanti in cuffia)
    const size_t latency = realTuneEngine.getLatencySamples();
    const int reportedLatency = zeroLatency ? 0 : static_cast<int>(latency);
    if (reportedLatency != getLatencySamples()) {
        setLatencySamples(reportedLatency);
    }

    std::array<const float*, MaxChannels> inPtrs{};
    std::array<float*, MaxChannels> outPtrs{};
    for (int ch = 0; ch < std::min(numChannels, static_cast<int>(MaxChannels)); ++ch) {
        inPtrs[static_cast<size_t>(ch)]  = buffer.getReadPointer(ch);
        outPtrs[static_cast<size_t>(ch)] = buffer.getWritePointer(ch);
    }

    if (isBypassed) {
        const size_t bypassLatency = static_cast<size_t>(reportedLatency);
        for (int i = 0; i < numSamples; ++i) {
            for (int ch = 0; ch < numChannels; ++ch) {
                float inS = inPtrs[static_cast<size_t>(ch)][i];
                latencyBypass.pushDrySample(static_cast<size_t>(ch), inS);
            }
            latencyBypass.advanceWriteIndex();
            for (int ch = 0; ch < numChannels; ++ch) {
                outPtrs[static_cast<size_t>(ch)][i] = latencyBypass.getAlignedDrySample(static_cast<size_t>(ch), bypassLatency);
            }
        }
        return;
    }

    // Misurazione RMS e Peak pre-process per telemetria
    float inRMS = 0.0f;
    float inPeak = 0.0f;
    for (int ch = 0; ch < numChannels; ++ch) {
        inRMS  += buffer.getRMSLevel(ch, 0, numSamples);
        inPeak = std::max(inPeak, buffer.getMagnitude(ch, 0, numSamples));
    }
    inRMS /= static_cast<float>(numChannels);

    // Memorizza i campioni dry pristini nel buffer circolare di latenza bypass (ZERO allocazioni heap)
    for (int i = 0; i < numSamples; ++i) {
        for (int ch = 0; ch < numChannels; ++ch) {
            latencyBypass.pushDrySample(static_cast<size_t>(ch), inPtrs[static_cast<size_t>(ch)][i]);
        }
        latencyBypass.advanceWriteIndex();
    }

    // 3. Elaborazione RealTune Core (Pitch Detection MPM + TD-PSOLA sincrono)
    realTuneEngine.process(inPtrs.data(), outPtrs.data(),
                           static_cast<size_t>(numChannels), static_cast<size_t>(numSamples));

    // 4. Miscelazione Dry/Wet bit-exact e phase-aligned, Gain Output e True-Peak Limiter a -0.10 dBTP
    const float linearGain = juce::Decibels::decibelsToGain(outGainDb);

    for (int i = 0; i < numSamples; ++i) {
        float sampleL = outPtrs[0][i];
        float sampleR = (numChannels > 1) ? outPtrs[1][i] : sampleL;

        // Recupera i campioni dry allineati alla perfezione temporale con la latenza dell'engine
        if (mixVal < 0.999f) {
            const size_t sampleDelay = latency + static_cast<size_t>(numSamples - 1 - i);
            const float dryL = latencyBypass.getAlignedDrySample(0, sampleDelay);
            const float dryR = (numChannels > 1) ? latencyBypass.getAlignedDrySample(1, sampleDelay) : dryL;
            sampleL = (dryL * (1.0f - mixVal) + sampleL * mixVal) * linearGain;
            sampleR = (dryR * (1.0f - mixVal) + sampleR * mixVal) * linearGain;
        } else if (std::abs(linearGain - 1.0f) > 1.0e-4f) {
            sampleL *= linearGain;
            sampleR *= linearGain;
        }

        // 100% Transparent Zero-Latency Output Path (identico ad Antares Auto-Tune Pro):
        // Elimina i 4 campioni di lookahead e qualsiasi compressione/saturazione dinamica sotto 0 dBFS,
        // preservando il 100% dell'allineamento di fase, del punch sui transienti e del soundstage.
        if (!std::isfinite(sampleL)) sampleL = 0.0f;
        if (!std::isfinite(sampleR)) sampleR = 0.0f;
        const float safeL = std::clamp(sampleL, -2.0f, 2.0f);
        const float safeR = std::clamp(sampleR, -2.0f, 2.0f);

        outPtrs[0][i] = safeL;
        if (numChannels > 1) {
            outPtrs[1][i] = safeR;
        }
    }

    // 5. Push Frame Telemetrico nella FIFO per la GUI a 60 FPS
    dsp171::RealTuneVisualFrame frame{};
    frame.detectedPitchHz   = realTuneEngine.getDetectedPitchHz();
    frame.centsDeviation   = realTuneEngine.getCorrectionCents();
    frame.confidence       = realTuneEngine.getVoicingClarity();
    frame.isVoiced         = realTuneEngine.isVoiced();

    if (frame.detectedPitchHz > 20.0f) {
        frame.detectedMidiPitch = 69.0f + 12.0f * std::log2(frame.detectedPitchHz / 440.0f);
        int roundMidi = juce::roundToInt(frame.detectedMidiPitch);
        frame.detectedNoteIndex = static_cast<uint8_t>(((roundMidi % 12) + 12) % 12);
    } else {
        frame.detectedMidiPitch = 0.0f;
        frame.detectedNoteIndex = 0;
    }

    frame.targetMidiPitch   = static_cast<float>(realTuneEngine.getTargetMidiNote());
    frame.targetNoteIndex   = static_cast<uint8_t>(((realTuneEngine.getTargetMidiNote() % 12) + 12) % 12);
    frame.activeScaleMask   = realTuneEngine.getActiveScaleMask();
    frame.bypassedScaleMask = bypassMask;
    frame.inputRMS          = inRMS;
    frame.inputPeak         = inPeak;
    frame.retuneCorrectionAmt = (100.0f - retuneSpeed) * 0.01f;

    // Popola i nuovi campi con i valori esatti estratti dai nuovi motori reverse-engineered:
    frame.dpllSNRDb          = realTuneEngine.getDPLLSNR();
    frame.isDPLLLocked       = realTuneEngine.isDPLLLocked();
    frame.vibratoCents       = realTuneEngine.getDPLLTracker().getVibratoCents();
    frame.throatLambda       = realTuneEngine.getLPCThroatLambda();
    frame.classicModeActive  = realTuneEngine.isClassicMode();

    visualFIFO.push(frame);
}

juce::AudioProcessorEditor* AudioPluginAudioProcessor::createEditor() {
    return new AudioPluginAudioProcessorEditor(*this);
}

int AudioPluginAudioProcessor::getNumPrograms() {
    return static_cast<int>(getFactoryPresets().size());
}

int AudioPluginAudioProcessor::getCurrentProgram() {
    return currentProgram;
}

void AudioPluginAudioProcessor::setCurrentProgram(int index) {
    const auto& presets = getFactoryPresets();
    if (index >= 0 && index < static_cast<int>(presets.size())) {
        currentProgram = index;
        const auto& p = presets[static_cast<size_t>(index)];

        auto setParamVal = [this](const char* id, float denormValue) {
            if (auto* param = apvts.getParameter(id)) {
                param->beginChangeGesture();
                param->setValueNotifyingHost(param->convertTo0to1(denormValue));
                param->endChangeGesture();
            }
        };

        auto setBoolParam = [this](const char* id, bool val) {
            if (auto* param = apvts.getParameter(id)) {
                param->beginChangeGesture();
                param->setValueNotifyingHost(val ? 1.0f : 0.0f);
                param->endChangeGesture();
            }
        };

        setParamVal("retune_speed",    p.retuneSpeed);
        setParamVal("humanize",        p.humanize);
        setParamVal("scale_type",      static_cast<float>(p.scaleType));
        setParamVal("root_key",        static_cast<float>(p.rootKey));
        setParamVal("amount",          p.amount);
        setParamVal("formant_shift",   p.formantShift);
        setBoolParam("keep_formants",  p.keepFormants);
        setParamVal("stereo_width",    p.stereoWidth);
        setParamVal("mix",             p.mix);
        setParamVal("out_gain",        p.outGain);
        setBoolParam("bypass",         p.bypass);
        setBoolParam("classic_mode",   p.classicMode);
        setParamVal("flex_tune",       p.flexTune);
        setParamVal("throat_length",   p.throatLength);
        setParamVal("vocal_range",     static_cast<float>(p.vocalRange));
        setParamVal("note_transition", p.noteTransition);
        setParamVal("tolerance_cents", p.toleranceCents);
        setParamVal("vibrato_depth",   p.vibratoDepth);
        setParamVal("tracking",        p.tracking);

        // Reset note masks in clean state for preset
        setParamVal("bypass_mask",     0.0f);
        setParamVal("blocked_mask",    0.0f);
    }
}

const juce::String AudioPluginAudioProcessor::getProgramName(int index) {
    const auto& presets = getFactoryPresets();
    if (index >= 0 && index < static_cast<int>(presets.size()))
        return presets[static_cast<size_t>(index)].name;
    return {};
}

void AudioPluginAudioProcessor::changeProgramName(int, const juce::String&) {}

void AudioPluginAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void AudioPluginAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType())) {
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
    }
}

void AudioPluginAudioProcessor::setNoteBypassMask(uint16_t mask) {
    if (auto* param = apvts.getParameter("bypass_mask")) {
        const float currentVal = bypassMaskParam ? bypassMaskParam->load(std::memory_order_relaxed) : 0.0f;
        if (static_cast<uint16_t>(currentVal) != mask) {
            param->beginChangeGesture();
            param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(mask)));
            param->endChangeGesture();
        }
    }
}

void AudioPluginAudioProcessor::setNoteBlockedMask(uint16_t mask) {
    if (auto* param = apvts.getParameter("blocked_mask")) {
        const float currentVal = blockedMaskParam ? blockedMaskParam->load(std::memory_order_relaxed) : 0.0f;
        if (static_cast<uint16_t>(currentVal) != mask) {
            param->beginChangeGesture();
            param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(mask)));
            param->endChangeGesture();
        }
    }
}

uint16_t AudioPluginAudioProcessor::getNoteBypassMask() const {
    if (auto* raw = apvts.getRawParameterValue("bypass_mask")) {
        return static_cast<uint16_t>(raw->load());
    }
    return 0;
}

void AudioPluginAudioProcessor::processBlockBypassed(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages) {
    juce::ignoreUnused(midiMessages);
    dsp171::ScopedDenormalDisabler ftzGuard;

    const int numSamples  = buffer.getNumSamples();
    const int numChannels = buffer.getNumChannels();

    if (numSamples == 0 || numChannels == 0)
        return;

    const bool zeroLatency = zeroLatencyParam ? (zeroLatencyParam->load(std::memory_order_relaxed) > 0.5f) : true;
    const size_t latency = realTuneEngine.getLatencySamples();
    const size_t bypassLatency = zeroLatency ? 0 : latency;

    std::array<float*, MaxChannels> outPtrs{};
    for (int ch = 0; ch < std::min(numChannels, static_cast<int>(MaxChannels)); ++ch) {
        outPtrs[static_cast<size_t>(ch)] = buffer.getWritePointer(ch);
    }

    for (int i = 0; i < numSamples; ++i) {
        for (int ch = 0; ch < numChannels; ++ch) {
            float inS = outPtrs[static_cast<size_t>(ch)][i];
            latencyBypass.pushDrySample(static_cast<size_t>(ch), inS);
        }
        latencyBypass.advanceWriteIndex();
        for (int ch = 0; ch < numChannels; ++ch) {
            outPtrs[static_cast<size_t>(ch)][i] = latencyBypass.getAlignedDrySample(static_cast<size_t>(ch), bypassLatency);
        }
    }
}

uint16_t AudioPluginAudioProcessor::getNoteBlockedMask() const {
    if (auto* raw = apvts.getRawParameterValue("blocked_mask")) {
        return static_cast<uint16_t>(raw->load());
    }
    return 0;
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new AudioPluginAudioProcessor();
}
