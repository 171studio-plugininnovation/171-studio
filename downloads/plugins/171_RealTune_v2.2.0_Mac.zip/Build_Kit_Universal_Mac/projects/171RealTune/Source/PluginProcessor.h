#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include <dsp171/Common.h>
#include <dsp171/RealTuneEngine.h>
#include <dsp171/SafetyCeiling.h>
#include <dsp171/LatencyBypass.h>
#include <array>
#include <vector>
#include "GUI/RealTuneTelemetry.h"

struct PluginPreset {
    const char* name;
    float retuneSpeed;   // ms (0..100)
    float humanize;      // % (0..100)
    int scaleType;       // 0..7
    int rootKey;         // 0..11
    float amount;        // % (0..100)
    float formantShift;  // st (-12..+12)
    bool keepFormants;   // true / false (Melda Keep Formants)
    float stereoWidth;   // % (0..200) (Mid/Side psychoacoustic decorrelation)
    float mix;           // % (0..100)
    float outGain;       // dB (-18..+18)
    bool bypass;
    bool classicMode;    // Antares Classic Mode DSP (Auto-Tune 5 hard snap)
    float flexTune;      // % (0..100) (Antares Flex-Tune)
    float throatLength;  // % (50..150) (Antares Throat Length modeling)
    int vocalRange;      // 0 = Alto/Tenor, 1 = Soprano, 2 = Low Male, 3 = Wide
    float noteTransition; // ms (0..800) (Waves Tune RT glide)
    float toleranceCents; // cents (0..40) (Waves Tune RT deadband)
    float vibratoDepth;  // % (0..200) (Waves Tune RT 5.8 Hz natural vibrato)
    float tracking = 50.0f; // % (0..100) (Pitch tracking sensitivity)
};

class AudioPluginAudioProcessor : public juce::AudioProcessor {
public:
    AudioPluginAudioProcessor();
    ~AudioPluginAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;

    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    void processBlockBypassed(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "171RealTune"; }

    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int index, const juce::String& newName) override;

    juce::AudioProcessorParameter* getBypassParameter() const override {
        return apvts.getParameter("bypass");
    }

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }
    dsp171::RealTuneVisualFIFO& getVisualFIFO() noexcept { return visualFIFO; }
    const dsp171::RealTuneNeuralBrain& getNeuralBrain() const noexcept { return realTuneEngine.getNeuralBrain(); }

    void setNoteBypassMask(uint16_t mask);
    void setNoteBlockedMask(uint16_t mask);
    uint16_t getNoteBypassMask() const;
    uint16_t getNoteBlockedMask() const;

    static const std::vector<PluginPreset>& getFactoryPresets();

private:
    juce::AudioProcessorValueTreeState apvts;
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    dsp171::RealTuneEngine realTuneEngine;
    dsp171::RealTuneVisualFIFO visualFIFO;

    static constexpr size_t MaxChannels = 2;
    std::array<dsp171::TruePeakLimiter, MaxChannels> truePeakLimiters;
    dsp171::LatencyCompensatedBypass<MaxChannels, 8192> latencyBypass;

    int currentProgram = 0;
    int currentHeldMidiNote = -1;

    // Hard real-time cached APVTS atomic pointers (zero hash map lookups in processBlock)
    std::atomic<float>* retuneSpeedParam = nullptr;
    std::atomic<float>* humanizeParam = nullptr;
    std::atomic<float>* scaleTypeParam = nullptr;
    std::atomic<float>* rootKeyParam = nullptr;
    std::atomic<float>* amountParam = nullptr;
    std::atomic<float>* formantShiftParam = nullptr;
    std::atomic<float>* keepFormantsParam = nullptr;
    std::atomic<float>* stereoWidthParam = nullptr;
    std::atomic<float>* mixParam = nullptr;
    std::atomic<float>* outGainParam = nullptr;
    std::atomic<float>* a4RefParam = nullptr;
    std::atomic<float>* midiModeParam = nullptr;
    std::atomic<float>* zeroLatencyParam = nullptr;
    std::atomic<float>* bypassMaskParam = nullptr;
    std::atomic<float>* blockedMaskParam = nullptr;
    std::atomic<float>* bypassParam = nullptr;
    std::atomic<float>* classicModeParam = nullptr;
    std::atomic<float>* flexTuneParam = nullptr;
    std::atomic<float>* throatLengthParam = nullptr;
    std::atomic<float>* vocalRangeParam = nullptr;
    std::atomic<float>* noteTransitionParam = nullptr;
    std::atomic<float>* toleranceCentsParam = nullptr;
    std::atomic<float>* vibratoDepthParam = nullptr;
    std::atomic<float>* trackingParam = nullptr;
    std::atomic<float>* smartBrainParam = nullptr;

    void initializeParameterPointers() noexcept;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AudioPluginAudioProcessor)
};
