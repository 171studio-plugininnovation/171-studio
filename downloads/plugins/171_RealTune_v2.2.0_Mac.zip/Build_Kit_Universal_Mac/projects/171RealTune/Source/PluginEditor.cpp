#include "PluginProcessor.h"
#include "PluginEditor.h"

AudioPluginAudioProcessorEditor::AudioPluginAudioProcessorEditor(AudioPluginAudioProcessor& p)
    : AudioProcessorEditor(&p),
      processorRef(p),
      editorView(p.getVisualFIFO())
{
    // 1. Aggiungi la vista master come componente principale
    addAndMakeVisible(editorView);

    // 2. Collega i controlli APVTS tramite Attachment
    auto& apvts = processorRef.getAPVTS();

    retuneSpeedAttach    = std::make_unique<SliderAttachment>(apvts, "retune_speed",    editorView.getRetuneSpeedSlider());
    noteTransitionAttach = std::make_unique<SliderAttachment>(apvts, "note_transition", editorView.getNoteTransitionSlider());
    toleranceAttach      = std::make_unique<SliderAttachment>(apvts, "tolerance_cents", editorView.getToleranceSlider());
    flexTuneAttach       = std::make_unique<SliderAttachment>(apvts, "flex_tune",       editorView.getFlexTuneSlider());
    humanizeAttach       = std::make_unique<SliderAttachment>(apvts, "humanize",        editorView.getHumanizeSlider());

    formantAttach        = std::make_unique<SliderAttachment>(apvts, "formant_shift",   editorView.getFormantSlider());
    throatLengthAttach   = std::make_unique<SliderAttachment>(apvts, "throat_length",   editorView.getThroatLengthSlider());
    vibratoDepthAttach   = std::make_unique<SliderAttachment>(apvts, "vibrato_depth",   editorView.getVibratoDepthSlider());
    stereoWidthAttach    = std::make_unique<SliderAttachment>(apvts, "stereo_width",    editorView.getStereoWidthSlider());
    a4RefAttach          = std::make_unique<SliderAttachment>(apvts, "a4_reference",     editorView.getA4RefSlider());
    outGainAttach        = std::make_unique<SliderAttachment>(apvts, "out_gain",         editorView.getOutGainSlider());
    mixAttach            = std::make_unique<SliderAttachment>(apvts, "mix",              editorView.getMixSlider());

    vocalRangeAttach     = std::make_unique<ComboBoxAttachment>(apvts, "vocal_range",   editorView.getVocalRangeBox());
    rootKeyAttach        = std::make_unique<ComboBoxAttachment>(apvts, "root_key",      editorView.getRootBox());
    scaleTypeAttach      = std::make_unique<ComboBoxAttachment>(apvts, "scale_type",    editorView.getScaleBox());

    liveBoothAttach    = std::make_unique<ButtonAttachment>(apvts, "zero_latency",  editorView.getLiveBoothButton());
    midiTargetAttach   = std::make_unique<ButtonAttachment>(apvts, "midi_mode",     editorView.getMidiTargetButton());
    keepFormantsAttach = std::make_unique<ButtonAttachment>(apvts, "keep_formants", editorView.getKeepFormantsButton());
    classicModeAttach  = std::make_unique<ButtonAttachment>(apvts, "classic_mode",  editorView.getClassicModeButton());
    smartBrainAttach   = std::make_unique<ButtonAttachment>(apvts, "smart_brain",   editorView.getSmartBrainButton());

    // Connessione diretta della lampada gemma Ruby per Master Bypass
    auto* bypassParam = apvts.getParameter("bypass");
    if (bypassParam != nullptr) {
        editorView.getBypassJewel().setLit(bypassParam->getValue() > 0.5f);
        editorView.getBypassJewel().onClick = [bypassParam](bool newState) {
            bypassParam->setValueNotifyingHost(newState ? 1.0f : 0.0f);
        };
    }

    // Sincronizzazione automatica quando cambia la scala o tonica: azzera maschere residue sui preset
    editorView.onScaleOrRootChanged = [this](int scaleType, int rootKey) {
        juce::ignoreUnused(rootKey);
        if (scaleType != 8) { // Not Custom
            processorRef.setNoteBlockedMask(0);
            processorRef.setNoteBypassMask(0);
        }
    };

    // Connessione diretta tra la matrice note a 3 stati e il DSP Processor
    editorView.getKeyboardMatrix().onScaleChanged = [this](uint16_t active, uint16_t bypass, uint16_t blocked) {
        juce::ignoreUnused(active);
        processorRef.setNoteBypassMask(bypass);
        processorRef.setNoteBlockedMask(blocked);
        if (editorView.getScaleBox().getSelectedId() != 8) {
            if (auto* param = processorRef.getAPVTS().getParameter("scale_type")) {
                param->beginChangeGesture();
                param->setValueNotifyingHost(param->convertTo0to1(7.0f)); // 7.0f = Custom (choice 8)
                param->endChangeGesture();
            }
        }
    };

    // 3. Selettore Preset centrale nella testata
    presetComboBox.setLookAndFeel(&editorView.comboBoxLookAndFeel);
    const auto& presets = AudioPluginAudioProcessor::getFactoryPresets();
    for (size_t i = 0; i < presets.size(); ++i) {
        presetComboBox.addItem(presets[i].name, static_cast<int>(i + 1));
    }
    presetComboBox.setSelectedId(processorRef.getCurrentProgram() + 1, juce::dontSendNotification);
    presetComboBox.addListener(this);
    addAndMakeVisible(presetComboBox);

    // Stepper Button Boutique dorati per preset (< e >)
    prevPresetBtn = std::make_unique<gui171::BoutiqueStepperButton>(gui171::BoutiqueStepperButton::Direction::Previous);
    prevPresetBtn->setOnClick([this]() {
        int cur = presetComboBox.getSelectedId() - 1;
        int num = processorRef.getNumPrograms();
        if (num > 0) {
            int prev = (cur - 1 + num) % num;
            presetComboBox.setSelectedId(prev + 1, juce::sendNotification);
        }
    });
    addAndMakeVisible(*prevPresetBtn);

    nextPresetBtn = std::make_unique<gui171::BoutiqueStepperButton>(gui171::BoutiqueStepperButton::Direction::Next);
    nextPresetBtn->setOnClick([this]() {
        int cur = presetComboBox.getSelectedId() - 1;
        int num = processorRef.getNumPrograms();
        if (num > 0) {
            int next = (cur + 1) % num;
            presetComboBox.setSelectedId(next + 1, juce::sendNotification);
        }
    });
    addAndMakeVisible(*nextPresetBtn);

    processorRef.addListener(this);

    // ==============================================================================
    // CONFIGURAZIONE TOOLTIP WINDOW & GUIDA CONTESTUALE LUSSO 171 STUDIO
    // ==============================================================================
    setColour(juce::TooltipWindow::backgroundColourId, juce::Colour(0xFF12161F));
    setColour(juce::TooltipWindow::textColourId,       juce::Colour(0xFFFFE899));
    setColour(juce::TooltipWindow::outlineColourId,    juce::Colour(0xFF73562A));

    editorView.getRetuneSpeedSlider().setTooltip(
        "RETUNE SPEED (0.0 ms - 100.0 ms)\n"
        "Velocita di aggancio e trazione verso la scala di pitch assegnata.\n"
        "✦ CONSIGLIATI DA STUDIO 171:\n"
        "- Hard Tune Trap / Modern Autotune: 0.0 - 5.0 ms (effetto Cher / Travis Scott immediato);\n"
        "- Pop / Hyperpop: 10.0 - 18.0 ms (intonazione solida, micro-scivolate controllate);\n"
        "- Cantato Acustico / R&B: 25.0 - 40.0 ms (flessibilita naturale inudibile all'orecchio);\n"
        "- Voce Naturale / Trasparente: 50.0 - 75.0 ms (morbido livellamento senza artefatti robotici).");

    editorView.getNoteTransitionSlider().setTooltip(
        "NOTE TRANSITION (0.0 ms - 800.0 ms)\n"
        "Inerzia temporale e curva di transizione tra note contigue di scala.\n"
        "✦ CONSIGLIATI DA STUDIO 171:\n"
        "- Scalini Rigidi Hip-Hop / Drill: 10 - 40 ms;\n"
        "- Voce Pop Radiofonica: 80 - 140 ms;\n"
        "- Ballad Legata / Intima: 180 - 300 ms;\n"
        "- Canto Lirico / Jazz: 350 - 500 ms (mantiene intatto il portamento naturale).");

    editorView.getToleranceSlider().setTooltip(
        "TOLERANCE (0.0 - 40.0 Cents)\n"
        "Finestra di tolleranza microtonale in cui il motore non applica correzione.\n"
        "✦ CONSIGLIATI DA STUDIO 171:\n"
        "- Calibrazione Robotica / Trap: 0 cents (nessuna pieta, snap assoluto);\n"
        "- Modern Pop: 3 - 8 cents (stabilizza i tremolii ma tollera micro-flessioni);\n"
        "- R&B / Soul: 10 - 18 cents (consente note blues e pieghe emotive);\n"
        "- Coristi / Cori di Sfondo: 5 - 10 cents per compattare il cluster corale.");

    editorView.getFlexTuneSlider().setTooltip(
        "FLEX-TUNE (0% - 100%)\n"
        "Attrazione selettiva non-lineare verso la nota bersaglio.\n"
        "✦ CONSIGLIATI DA STUDIO 171:\n"
        "- Autotune Elettronico: 0% (trazione uniforme in tutta la scala);\n"
        "- Pop Moderno: 20 - 35% (liberta di fraseggio con centro nota centrato);\n"
        "- Cantautori / Pop Tradizionale: 40 - 65% (naturalezza estrema);\n"
        "- Performance Live Difficili: 10 - 20% (guida morbida senza bloccare la liberta).");

    editorView.getHumanizeSlider().setTooltip(
        "HUMANIZE (0% - 100%)\n"
        "Rilascio progressivo del retune durante le note lunghe tenute.\n"
        "✦ CONSIGLIATI DA STUDIO 171:\n"
        "- Trap / Drill Veloce: 0% (nessun allentamento sui sustain);\n"
        "- Pop / Dance: 20 - 35% (tiene il centro ma rilascia la fine della frase);\n"
        "- R&B / Slow Jam: 45 - 65% (esalta il vibrato finale e la setosita);\n"
        "- Lirica / Musical: 70 - 85% (massima fedelta espressiva).");

    editorView.getFormantSlider().setTooltip(
        "FORMANT SHIFT (-12.0 st a +12.0 st)\n"
        "Traslazione spettrale delle formanti della gola senza alterare il pitch.\n"
        "✦ CONSIGLIATI DA STUDIO 171:\n"
        "- Pitch Match Neutro: 0.0 semitoni;\n"
        "- Chipmunk / Hyperpop Vocal Chop: +2.0 a +5.0 st;\n"
        "- Deep Dark Trap / Monster Vocal: -2.5 a -6.0 st;\n"
        "- Femminilizzazione Voce Maschile: +1.2 a +2.0 st con Keep Formants.");

    editorView.getThroatLengthSlider().setTooltip(
        "THROAT LENGTH (50% - 150%)\n"
        "Modellazione fisica della lunghezza del tratto vocale e della laringe.\n"
        "✦ CONSIGLIATI DA STUDIO 171:\n"
        "- Lunghezza Naturale: 100%;\n"
        "- Voce Ariana / Brillante Pop: 85 - 92%;\n"
        "- Voce Calda / Baritonale Intima: 108 - 120%;\n"
        "- Special FX / Doppie Stereo: 80% su un canale, 120% sull'altro.");

    editorView.getVibratoDepthSlider().setTooltip(
        "NATURAL VIBRATO (0% - 200%)\n"
        "Controllo di ampiezza del vibrato acustico organico del cantante.\n"
        "✦ CONSIGLIATI DA STUDIO 171:\n"
        "- Trap / Robot Tune: 0 - 25% (voce piatta laser);\n"
        "- Pop Standard: 70 - 100% (mantiene il timbro autentico dell'artista);\n"
        "- Opera / Musical: 110 - 140% (esalta l'intensita emotiva);\n"
        "- Correzione Cantanti con Tremolio Eccessivo: 40 - 60%.");

    editorView.getStereoWidthSlider().setTooltip(
        "STEREO WIDTH (0% - 200%)\n"
        "Espansione stereofonica per doppie e cori con compatibilita mono.\n"
        "✦ CONSIGLIATI DA STUDIO 171:\n"
        "- Voce Lead Principale: 100% (o 0% per centro mono chirurgico);\n"
        "- Backing Vocals / Doppie LR: 130 - 170% (avvolgono la traccia);\n"
        "- Effetti Spaziali / Intro Drop: 180 - 200%;\n"
        "- Broadcast / Voiceover Radio: 100% (mono coerente).");

    editorView.getA4RefSlider().setTooltip(
        "A4 REFERENCE (415.0 Hz - 466.0 Hz)\n"
        "Calibrazione della frequenza fondamentale del La4 di riferimento.\n"
        "✦ CONSIGLIATI DA STUDIO 171:\n"
        "- Standard Internazionale ISO 16: 440.0 Hz;\n"
        "- Orchestrale Moderno / Europa Centrale: 442.0 Hz;\n"
        "- Accordatura Aurea / Olistica: 432.0 Hz;\n"
        "- Musica Antica / Barocco: 415.0 Hz.");

    editorView.getMixSlider().setTooltip(
        "CUE MIX (0% - 100%)\n"
        "Bilanciamento Dry/Wet tra segnale originale non processato e intonato.\n"
        "✦ CONSIGLIATI DA STUDIO 171:\n"
        "- Insert Voce Standard: 100% Wet;\n"
        "- Correzione Parallela Trasparente: 60 - 75% Wet;\n"
        "- Effetto Chorus Armonico / Doubler Naturale: 50% Wet;\n"
        "- Live Monitoring di Sicurezza: 80% Wet.");

    editorView.getOutGainSlider().setTooltip(
        "OUTPUT TRIM (-18.0 dB a +18.0 dB)\n"
        "Guadagno di uscita master con stadio analogico virtuale soft-ceiling.\n"
        "✦ CONSIGLIATI DA STUDIO 171:\n"
        "- Unity Gain: 0.0 dB;\n"
        "- Compensazione Formant Boost: -1.0 a -3.0 dB;\n"
        "- Headroom Catena Bus Voce: calibrare per picchi a -6.0 dBFS.");

    editorView.getLiveBoothButton().setTooltip(
        "LIVE BOOTH (0-LATENCY MONITORING)\n"
        "Attiva la modalita a latenza zero per monitoraggio in cuffia in cabina.\n"
        "Disattiva la compensazione lookahead e forza il buffer MPM immediato.");

    editorView.getMidiTargetButton().setTooltip(
        "MIDI TARGET TRACKING\n"
        "Abilita il controllo istantaneo del pitch tramite tastiera MIDI o traccia DAW.\n"
        "La voce segue in tempo reale gli accordi o le melodie suonate.");

    editorView.getKeepFormantsButton().setTooltip(
        "KEEP FORMANTS (Spettro Vocale)\n"
        "Preserva lo spettro acustico originale del cantante evitando l'effetto chipmunk\n"
        "durante traslazioni melodiche marcate.");

    editorView.getClassicModeButton().setTooltip(
        "CLASSIC V5 MODE\n"
        "Emula l'algoritmo spigoloso e iconico di fine anni '90 (Auto-Tune v5),\n"
        "caratterizzato da transizioni rapide a gradino e timbrica urbana.");

    editorView.getSmartBrainButton().setTooltip(
        "SMART BRAIN (Riconoscimento Neurale)\n"
        "Attiva il modulo neurale predittivo Studio 171 che sopprime salti d'ottava\n"
        "spuri, fruscii fonematici e instabilita di pitch su consonanti.");

    editorView.getVocalRangeBox().setTooltip(
        "VOCAL RANGE (Registro Esecutore)\n"
        "Limita la ricerca del pitch alla tessitura reale del cantante (Alto/Tenor,\n"
        "Soprano, Low Male, Wide) velocizzando il tracking ed eliminando errori.");

    editorView.getRootBox().setTooltip(
        "ROOT KEY (Tonica della Scala)\n"
        "Seleziona la nota fondamentale di riferimento (C, C#, D... B).");

    editorView.getScaleBox().setTooltip(
        "SCALE TYPE (Modo Musicale)\n"
        "Seleziona la scala di intonazione: Major, Minor, Harmonic, Pentatonic, Dorian,\n"
        "Chromatic o Custom (personalizzabile tramite i tasti piano sottostanti).");

    editorView.getBypassJewel().setTooltip(
        "MASTER BYPASS\n"
        "Disattiva istantaneamente il motore DSP garantendo passaggio a fase perfetta.");

    presetComboBox.setTooltip(
        "PRESET FACTORY & USER STUDIO 171\n"
        "Boutique Studio Presets calibrati per generi musicali e registri vocali.");


    // 4. Supporto completo Resizable Bar
    setResizable(true, true);
    setResizeLimits(944, 576, 2360, 1440);
    getConstrainer()->setFixedAspectRatio(1180.0 / 720.0);
    setSize(1180, 720);
}

AudioPluginAudioProcessorEditor::~AudioPluginAudioProcessorEditor() {
    processorRef.removeListener(this);
    presetComboBox.setLookAndFeel(nullptr);
    presetComboBox.removeListener(this);
}

void AudioPluginAudioProcessorEditor::audioProcessorChanged(juce::AudioProcessor*, const juce::AudioProcessor::ChangeDetails& details) {
    if (details.programChanged) {
        const int curProg = processorRef.getCurrentProgram();
        if (presetComboBox.getSelectedId() - 1 != curProg) {
            presetComboBox.setSelectedId(curProg + 1, juce::dontSendNotification);
        }
    }
}

void AudioPluginAudioProcessorEditor::comboBoxChanged(juce::ComboBox* box) {
    if (box == &presetComboBox) {
        const int selectedIdx = presetComboBox.getSelectedId() - 1;
        if (selectedIdx >= 0 && selectedIdx != processorRef.getCurrentProgram()) {
            processorRef.setCurrentProgram(selectedIdx);
            processorRef.updateHostDisplay(juce::AudioProcessor::ChangeDetails().withProgramChanged(true));
        }
    }
}

void AudioPluginAudioProcessorEditor::paint(juce::Graphics& g) {
    g.fillAll(juce::Colour(0xff0d0f13));
}

void AudioPluginAudioProcessorEditor::resized() {
    auto bounds = getLocalBounds();
    editorView.setBounds(bounds);

    // Posiziona il Preset ComboBox nella barra superiore rigorosamente centrato con 25px di clearance simmetrica tra Bypass e Lock
    const float scaleX = (float)getWidth()  / 1180.0f;
    const float scaleY = (float)getHeight() / 720.0f;
    if (prevPresetBtn != nullptr) {
        prevPresetBtn->setBounds(juce::roundToInt(299.0f * scaleX),
                                 juce::roundToInt(14.0f * scaleY),
                                 juce::roundToInt(20.0f * scaleX),
                                 juce::roundToInt(26.0f * scaleY));
    }
    presetComboBox.setBounds(juce::roundToInt(323.0f * scaleX),
                             juce::roundToInt(14.0f * scaleY),
                             juce::roundToInt(160.0f * scaleX),
                             juce::roundToInt(26.0f * scaleY));
    if (nextPresetBtn != nullptr) {
        nextPresetBtn->setBounds(juce::roundToInt(487.0f * scaleX),
                                 juce::roundToInt(14.0f * scaleY),
                                 juce::roundToInt(20.0f * scaleX),
                                 juce::roundToInt(26.0f * scaleY));
    }
}
