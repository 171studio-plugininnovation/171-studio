#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "RealTuneTelemetry.h"
#include "ScrollingPitchDisplay.h"
#include "CentDeviationGalvanometer.h"
#include "ScaleKeyboardMatrixComponent.h"
#include "RealTuneWingedKnob.h"
#include "RealTuneBoutiqueFader.h"
#include "JewelLampComponent.h"
#include "BoutiquePushButton.h"
#include "RealTuneLookAndFeel.h"
#include "ResizableHandleComponent.h"

namespace gui171 {

// ==============================================================================
// MASTER GUI EDITOR PER 171REALTUNE (JUCE 8 - 60 FPS BOUTIQUE CMF PIPELINE)
// MANOPOLE CHICKEN HEAD 171 PERFECTPRE, FADER SLIM & TELEMETRIA FOTOREALE
// RETROINGEGNERIA ANTARES AUTO-TUNE PRO & WAVES TUNE REAL-TIME
// ==============================================================================
class RealTuneEditorComponent : public juce::Component, public juce::Timer {
public:
    explicit RealTuneEditorComponent(dsp171::RealTuneVisualFIFO& fifoRef)
        : fifo(fifoRef),
          jewelBypass(JewelLampComponent::LampType::Ruby_Bypass, "BYPASS", true),
          jewelPitchLock(JewelLampComponent::LampType::Green_PitchLock, "LOCK", false),
          jewelDpllLock(JewelLampComponent::LampType::Cyan_DpllLock, "DPLL", false),
          jewelRetune(JewelLampComponent::LampType::Amber_Retune, "RETUNE", false),
          btnLiveBooth("BOOTH", "0-LAT", juce::Colour(0xff00f0ff)),
          btnMidiTarget("MIDI", "TARGET", juce::Colour(0xff00ffaa)),
          btnKeepFormants("FORMANT", "KEEP", juce::Colour(0xffffaa00)),
          btnClassicMode("MODE", "CLASSIC", juce::Colour(0xffff3355)),
          btnSmartBrain("SMART", "BRAIN", juce::Colour(0xff00e5ff))
    {
        // 0. Carica Logo 171 Studio da 171PerfectPre
        if (BinaryData::namedResourceListSize > 0) {
            logo171Img = juce::ImageCache::getFromMemory(BinaryData::logo_171_gold_png, BinaryData::logo_171_gold_pngSize);
        }

        // 1. Inizializzazione Display Centrale & Galvanometro & Keyboard Matrix
        addAndMakeVisible(pitchDisplay);
        addAndMakeVisible(centMeter);
        addAndMakeVisible(keyboardMatrix);

        // 2. Lampade Spia a Gioiello Vintage 171 Studio
        addAndMakeVisible(jewelBypass);
        addAndMakeVisible(jewelPitchLock);
        addAndMakeVisible(jewelDpllLock);
        addAndMakeVisible(jewelRetune);

        // 3. Tasti Console Boutique Retroilluminati
        addAndMakeVisible(btnLiveBooth);
        addAndMakeVisible(btnMidiTarget);
        addAndMakeVisible(btnKeepFormants);
        addAndMakeVisible(btnClassicMode);
        addAndMakeVisible(btnSmartBrain);

        // 4. Pod 1: PITCH ENGINE (Retune Speed, Note Transition, Tolerance, Flex-Tune, Humanize)
        knobRetuneSpeed = std::make_unique<RealTuneChickenKnobComponent>(
            "RETUNE SPEED",
            WingedChickenKnobLookAndFeel::KnobColor::CobaltBlue,
            RealTuneChickenKnobComponent::DisplayFormat::TimeMs);
        knobRetuneSpeed->slider.setRange(0.0, 100.0, 0.1);
        knobRetuneSpeed->slider.setSkewFactorFromMidPoint(15.0);
        knobRetuneSpeed->slider.setValue(15.0, juce::dontSendNotification);
        knobRetuneSpeed->updatePillText();
        addAndMakeVisible(*knobRetuneSpeed);

        knobNoteTransition = std::make_unique<RealTuneChickenKnobComponent>(
            "NOTE TRANSITION",
            WingedChickenKnobLookAndFeel::KnobColor::LightSteel,
            RealTuneChickenKnobComponent::DisplayFormat::TimeMs);
        knobNoteTransition->slider.setRange(0.0, 800.0, 0.5);
        knobNoteTransition->slider.setSkewFactorFromMidPoint(120.0);
        knobNoteTransition->slider.setValue(120.0, juce::dontSendNotification);
        knobNoteTransition->updatePillText();
        addAndMakeVisible(*knobNoteTransition);

        knobTolerance = std::make_unique<RealTuneChickenKnobComponent>(
            "TOLERANCE",
            WingedChickenKnobLookAndFeel::KnobColor::WarmBronze,
            RealTuneChickenKnobComponent::DisplayFormat::Cents);
        knobTolerance->slider.setRange(0.0, 40.0, 0.5);
        knobTolerance->slider.setValue(0.0, juce::dontSendNotification);
        knobTolerance->updatePillText();
        addAndMakeVisible(*knobTolerance);

        knobFlexTune = std::make_unique<RealTuneChickenKnobComponent>(
            "FLEX-TUNE",
            WingedChickenKnobLookAndFeel::KnobColor::CyanGlow,
            RealTuneChickenKnobComponent::DisplayFormat::Percentage);
        knobFlexTune->slider.setRange(0.0, 100.0, 1.0);
        knobFlexTune->slider.setValue(0.0, juce::dontSendNotification);
        knobFlexTune->updatePillText();
        addAndMakeVisible(*knobFlexTune);

        knobHumanize = std::make_unique<RealTuneChickenKnobComponent>(
            "HUMANIZE",
            WingedChickenKnobLookAndFeel::KnobColor::WarmBronze,
            RealTuneChickenKnobComponent::DisplayFormat::Percentage);
        knobHumanize->slider.setRange(0.0, 100.0, 1.0);
        knobHumanize->slider.setValue(25.0, juce::dontSendNotification);
        knobHumanize->updatePillText();
        addAndMakeVisible(*knobHumanize);

        // 5. Pod 2: FORMANT & SPACE (Formant Shift, Throat Length, Natural Vibrato, Stereo Width, A4 Ref)
        knobFormant = std::make_unique<RealTuneChickenKnobComponent>(
            "FORMANT SHIFT",
            WingedChickenKnobLookAndFeel::KnobColor::NeveRed,
            RealTuneChickenKnobComponent::DisplayFormat::Semitones);
        knobFormant->slider.setRange(-12.0, 12.0, 0.1);
        knobFormant->slider.setValue(0.0, juce::dontSendNotification);
        knobFormant->updatePillText();
        addAndMakeVisible(*knobFormant);

        knobThroatLength = std::make_unique<RealTuneChickenKnobComponent>(
            "THROAT LENGTH",
            WingedChickenKnobLookAndFeel::KnobColor::AmberOrange,
            RealTuneChickenKnobComponent::DisplayFormat::Percentage);
        knobThroatLength->slider.setRange(50.0, 150.0, 1.0);
        knobThroatLength->slider.setValue(100.0, juce::dontSendNotification);
        knobThroatLength->updatePillText();
        addAndMakeVisible(*knobThroatLength);

        knobVibratoDepth = std::make_unique<RealTuneChickenKnobComponent>(
            "NATURAL VIBRATO",
            WingedChickenKnobLookAndFeel::KnobColor::EmeraldJade,
            RealTuneChickenKnobComponent::DisplayFormat::Percentage);
        knobVibratoDepth->slider.setRange(0.0, 200.0, 1.0);
        knobVibratoDepth->slider.setValue(100.0, juce::dontSendNotification);
        knobVibratoDepth->updatePillText();
        addAndMakeVisible(*knobVibratoDepth);

        knobStereoWidth = std::make_unique<RealTuneChickenKnobComponent>(
            "STEREO WIDTH",
            WingedChickenKnobLookAndFeel::KnobColor::EmeraldJade,
            RealTuneChickenKnobComponent::DisplayFormat::Percentage);
        knobStereoWidth->slider.setRange(0.0, 200.0, 1.0);
        knobStereoWidth->slider.setValue(100.0, juce::dontSendNotification);
        knobStereoWidth->updatePillText();
        addAndMakeVisible(*knobStereoWidth);

        knobA4Ref = std::make_unique<RealTuneChickenKnobComponent>(
            "A4 REF",
            WingedChickenKnobLookAndFeel::KnobColor::LightSteel,
            RealTuneChickenKnobComponent::DisplayFormat::Hertz);
        knobA4Ref->slider.setRange(415.0, 466.0, 0.1);
        knobA4Ref->slider.setValue(440.0, juce::dontSendNotification);
        knobA4Ref->updatePillText();
        addAndMakeVisible(*knobA4Ref);

        // 6. Master Section: Manopola Chicken CUE MIX + Manopola Chicken Output Trim
        knobCueMix = std::make_unique<RealTuneChickenKnobComponent>(
            "CUE MIX",
            WingedChickenKnobLookAndFeel::KnobColor::WarmBronze,
            RealTuneChickenKnobComponent::DisplayFormat::Percentage);
        knobCueMix->slider.setRange(0.0, 100.0, 1.0);
        knobCueMix->slider.setValue(100.0, juce::dontSendNotification);
        knobCueMix->updatePillText();
        addAndMakeVisible(*knobCueMix);

        knobOutGain = std::make_unique<RealTuneChickenKnobComponent>(
            "OUTPUT TRIM",
            WingedChickenKnobLookAndFeel::KnobColor::OutputGold,
            RealTuneChickenKnobComponent::DisplayFormat::Decibels);
        knobOutGain->slider.setRange(-18.0, 18.0, 0.1);
        knobOutGain->slider.setValue(0.0, juce::dontSendNotification);
        knobOutGain->updatePillText();
        addAndMakeVisible(*knobOutGain);

        // 7. LookAndFeel personalizzato per i Selettori Vocal Range, Root Key e Scale Type
        vocalRangeBox.setLookAndFeel(&comboBoxLookAndFeel);
        vocalRangeBox.addItemList({ "Alto / Tenor", "Soprano", "Low Male", "Wide" }, 1);
        vocalRangeBox.setSelectedId(1, juce::dontSendNotification);
        addAndMakeVisible(vocalRangeBox);

        rootBox.setLookAndFeel(&comboBoxLookAndFeel);
        scaleBox.setLookAndFeel(&comboBoxLookAndFeel);
        setupScaleSelectors();

        // 8. Barra e Maniglia di ridimensionamento dinamico (Resizable Handle)
        addAndMakeVisible(resizeHandle);
        resizeHandle.onScaleChanged = [this](float) {
            resized();
        };

        // Dimensioni ideali Hardware Standard (1180x720)
        setSize(1180, 720);

        // Avvio rendering e pipeline telemetrica a 60 FPS
        startTimerHz(60);
    }

    ~RealTuneEditorComponent() override {
        stopTimer();
        vocalRangeBox.setLookAndFeel(nullptr);
        rootBox.setLookAndFeel(nullptr);
        scaleBox.setLookAndFeel(nullptr);
    }

    void timerCallback() override {
        pitchDisplay.updateTelemetry(fifo);

        if (pitchDisplay.latestFrame.confidence > 0.0f || pitchDisplay.latestFrame.isVoiced) {
            centMeter.updateTelemetry(pitchDisplay.latestFrame);
            keyboardMatrix.updateTelemetry(pitchDisplay.latestFrame);

            // Lampada verde PITCH LOCK: attiva se segnale vocale stabile
            bool isLocked = pitchDisplay.latestFrame.isVoiced && (pitchDisplay.latestFrame.confidence > 0.35f);
            jewelPitchLock.setLit(isLocked);

            // Lampada ciano DPLL LOCK: aggancio di fase ad altissima coerenza (confidence > 0.65f)
            bool isDpllLocked = pitchDisplay.latestFrame.isVoiced && (pitchDisplay.latestFrame.confidence > 0.65f);
            jewelDpllLock.setLit(isDpllLocked);

            // Lampada ambra RETUNE: attiva se c'è correzione di pitch in atto
            float deltaCents = std::abs(pitchDisplay.latestFrame.centsDeviation);
            float retuneActivity = (isLocked && deltaCents > 2.0f) ? std::min(1.0f, deltaCents / 25.0f) : 0.0f;
            jewelRetune.setBrightness(retuneActivity);
        } else {
            jewelPitchLock.setLit(false);
            jewelDpllLock.setLit(false);
            jewelRetune.setBrightness(0.0f);
        }

        jewelPitchLock.updateDecay(0.85f);
        jewelDpllLock.updateDecay(0.85f);
        jewelRetune.updateDecay(0.80f);
    }

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat();

        // 1. Chassis in alluminio anodizzato aerospaziale nero spazzolato (#121316 / #17181C)
        juce::ColourGradient chassisGrad(juce::Colour(0xff181a1f), bounds.getX(), bounds.getY(),
                                         juce::Colour(0xff0e1014), bounds.getX(), bounds.getBottom(), false);
        g.setGradientFill(chassisGrad);
        g.fillRoundedRectangle(bounds, 8.0f);

        // Micro-spazzolatura metallica orizzontale
        g.setColour(juce::Colour(0x06ffffff));
        for (float y = bounds.getY() + 2.0f; y < bounds.getBottom(); y += 2.0f) {
            g.drawHorizontalLine(juce::roundToInt(y), bounds.getX() + 2.0f, bounds.getRight() - 2.0f);
        }

        // 2. Bordi bisellati in ottone caldo / oro satinato (#D4AF37 / #AA7C11)
        juce::ColourGradient goldBezel(juce::Colour(0xffffe082), bounds.getX(), bounds.getY(),
                                      juce::Colour(0xff8c6e28), bounds.getRight(), bounds.getBottom(), false);
        g.setGradientFill(goldBezel);
        g.drawRoundedRectangle(bounds.reduced(1.0f), 7.0f, 1.5f);

        g.setColour(juce::Colour(0xff08090b));
        g.drawRoundedRectangle(bounds, 8.0f, 2.0f);

        // 3. Viti Phillips boutique nei 4 angoli
        drawCornerScrews(g, bounds);

        // 4. Header Bar con logo 171 Studio cesellato
        drawHeaderBar(g, bounds);

        // 5. Pod tematici PITCH ENGINE, FORMANT & SPACE e MASTER
        drawPodPanels(g);

        // 6. Serigrafie laser di fondo e didascalia inferiore
        drawFooterSerigraph(g, bounds);
    }

    void resized() override {
        auto area = getLocalBounds();

        // Maniglia di ridimensionamento in basso a destra
        resizeHandle.setBounds(area.getRight() - 24, area.getBottom() - 24, 24, 24);

        // Header superiore (54 px)
        auto headerArea = area.removeFromTop(54);
        positionHeaderControls(headerArea);

        // Margini interni del pannello
        auto contentArea = area.reduced(16, 12);

        // Split verticale: 48% Display superiore, 52% Sezione controlli inferiori
        int topHeight = juce::roundToInt(contentArea.getHeight() * 0.48f);
        auto topSection = contentArea.removeFromTop(topHeight);
        auto bottomSection = contentArea;

        // Top Section: CRT Pitch Oscilloscope (68%) e Cent Deviation Galvanometer (32%)
        int meterWidth = juce::roundToInt(topSection.getWidth() * 0.32f);
        centMeter.setBounds(topSection.removeFromRight(meterWidth).reduced(3, 2));
        pitchDisplay.setBounds(topSection.reduced(3, 2));

        // Bottom Section:
        // Left (27%): Piano Keyboard Matrix con tri-stato (Tune / Bypass / Block)
        // Right (17%): Master Section (Fader Verticale Slim Master Mix + Manopola Chicken Output Trim)
        // Center (56%): Due Pod tematici PITCH ENGINE & FORMANT & SPACE (5 manopole ciascuno)
        int keyboardWidth = juce::roundToInt(bottomSection.getWidth() * 0.27f);
        int masterWidth   = juce::roundToInt(bottomSection.getWidth() * 0.17f);

        keyboardMatrix.setBounds(bottomSection.removeFromLeft(keyboardWidth).reduced(3, 2));
        auto masterArea = bottomSection.removeFromRight(masterWidth).reduced(3, 2);
        masterBounds = masterArea;

        // Comparto Master (destra): Manopola CUE MIX in alto + Manopola OUTPUT TRIM in basso
        auto masterInner = masterArea.withTrimmedTop(16).reduced(2, 2);
        int halfH = masterInner.getHeight() / 2;
        auto topArea = masterInner.removeFromTop(halfH);
        if (knobCueMix)
            knobCueMix->setBounds(topArea.reduced(2, 2));
        if (knobOutGain)
            knobOutGain->setBounds(masterInner.reduced(2, 2));

        // Sezione centrale con i 2 Pods tematici
        auto podsArea = bottomSection.reduced(3, 2);
        int podGap = 6;
        int podHeight = (podsArea.getHeight() - podGap) / 2;

        pod1Bounds = podsArea.removeFromTop(podHeight);
        podsArea.removeFromTop(podGap);
        pod2Bounds = podsArea;

        // Pod 1 (PITCH ENGINE): RETUNE SPEED, NOTE TRANSITION, TOLERANCE, FLEX-TUNE, HUMANIZE
        auto p1Knobs = pod1Bounds.withTrimmedTop(16).reduced(4, 2);
        int colW1 = p1Knobs.getWidth() / 5;
        if (knobRetuneSpeed)    knobRetuneSpeed->setBounds(p1Knobs.removeFromLeft(colW1).reduced(2, 1));
        if (knobNoteTransition) knobNoteTransition->setBounds(p1Knobs.removeFromLeft(colW1).reduced(2, 1));
        if (knobTolerance)      knobTolerance->setBounds(p1Knobs.removeFromLeft(colW1).reduced(2, 1));
        if (knobFlexTune)       knobFlexTune->setBounds(p1Knobs.removeFromLeft(colW1).reduced(2, 1));
        if (knobHumanize)       knobHumanize->setBounds(p1Knobs.reduced(2, 1));

        // Pod 2 (FORMANT & SPACE): FORMANT SHIFT, THROAT LENGTH, NATURAL VIBRATO, STEREO WIDTH, A4 REF
        auto p2Knobs = pod2Bounds.withTrimmedTop(16).reduced(4, 2);
        int colW2 = p2Knobs.getWidth() / 5;
        if (knobFormant)      knobFormant->setBounds(p2Knobs.removeFromLeft(colW2).reduced(2, 1));
        if (knobThroatLength) knobThroatLength->setBounds(p2Knobs.removeFromLeft(colW2).reduced(2, 1));
        if (knobVibratoDepth) knobVibratoDepth->setBounds(p2Knobs.removeFromLeft(colW2).reduced(2, 1));
        if (knobStereoWidth)  knobStereoWidth->setBounds(p2Knobs.removeFromLeft(colW2).reduced(2, 1));
        if (knobA4Ref)        knobA4Ref->setBounds(p2Knobs.reduced(2, 1));
    }

private:
    void setupScaleSelectors() {
        // Root Note Selector
        rootBox.addItemList({ "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" }, 1);
        rootBox.setSelectedId(1, juce::dontSendNotification);
        addAndMakeVisible(rootBox);

        // Scale Type Selector
        scaleBox.addItemList({ "Chromatic", "Major", "Natural Minor", "Harmonic Minor",
                              "Pentatonic Major", "Pentatonic Minor", "Dorian", "Custom" }, 1);
        scaleBox.setSelectedId(2, juce::dontSendNotification); // Default C Major
        addAndMakeVisible(scaleBox);

        scaleBox.onChange = [this]() { applyScalePreset(); };
        rootBox.onChange  = [this]() { applyScalePreset(); };

        applyScalePreset();
    }

    void applyScalePreset() {
        int root = std::clamp(rootBox.getSelectedId() - 1, 0, 11);
        int scaleType = scaleBox.getSelectedId();

        if (scaleType == 8) {
            // Modalita' Custom: preserva la configurazione manuale della tastiera
            if (onScaleOrRootChanged) {
                onScaleOrRootChanged(scaleType, root);
            }
            return;
        }

        uint16_t intervals = 0x0FFF; // Chromatic
        switch (scaleType) {
            case 2: intervals = 0b101010110101; break; // Major: (0,2,4,5,7,9,11) [0x0AB5]
            case 3: intervals = 0b010110101101; break; // Natural Minor: (0,2,3,5,7,8,10) [0x05AD]
            case 4: intervals = 0b100110101101; break; // Harmonic Minor: (0,2,3,5,7,8,11) [0x09AD]
            case 5: intervals = 0b001010010101; break; // Pentatonic Major: (0,2,4,7,9) [0x0295]
            case 6: intervals = 0b010010101001; break; // Pentatonic Minor: (0,3,5,7,10) [0x04A9]
            case 7: intervals = 0b011010101101; break; // Dorian: (0,2,3,5,7,9,10) [0x06AD]
            default: intervals = 0x0FFF; break;
        }

        uint16_t rotatedMask = 0;
        for (int i = 0; i < 12; ++i) {
            if (intervals & (1 << i)) {
                int noteInScale = ((root + i) % 12 + 12) % 12;
                rotatedMask |= (1 << noteInScale);
            }
        }

        // sendNotification = false per prevenire chiamate re-entranti all'host durante cambio combo-box
        keyboardMatrix.setScalePreset(rotatedMask, 0, false);

        if (onScaleOrRootChanged) {
            onScaleOrRootChanged(scaleType, root);
        }
    }

    void positionHeaderControls(juce::Rectangle<int>& /*headerArea*/) {
        const float scaleX = (float)getWidth()  / 1180.0f;
        const float scaleY = (float)getHeight() / 720.0f;

        // Ruby Jewel Master Bypass
        jewelBypass.setBounds(juce::roundToInt(238.0f * scaleX),
                              juce::roundToInt(7.0f * scaleY),
                              juce::roundToInt(36.0f * scaleX),
                              juce::roundToInt(42.0f * scaleY));

        // Preset ComboBox e stepper buttons sono posizionati da AudioPluginAudioProcessorEditor a [296..508]

        // Status Jewel Lamps (LOCK, DPLL, RETUNE) distanziati con ampia clearance da preset
        jewelPitchLock.setBounds(juce::roundToInt(524.0f * scaleX),
                                 juce::roundToInt(7.0f * scaleY),
                                 juce::roundToInt(34.0f * scaleX),
                                 juce::roundToInt(42.0f * scaleY));

        jewelDpllLock.setBounds(juce::roundToInt(560.0f * scaleX),
                                juce::roundToInt(7.0f * scaleY),
                                juce::roundToInt(34.0f * scaleX),
                                juce::roundToInt(42.0f * scaleY));

        jewelRetune.setBounds(juce::roundToInt(596.0f * scaleX),
                              juce::roundToInt(7.0f * scaleY),
                              juce::roundToInt(34.0f * scaleX),
                              juce::roundToInt(42.0f * scaleY));

        // Boutique Toggles per Live Monitoring, MIDI Target Snap, Keep Formants, Auto-Tune Classic Mode & Smart Brain
        btnLiveBooth.setBounds(juce::roundToInt(638.0f * scaleX),
                               juce::roundToInt(10.0f * scaleY),
                               juce::roundToInt(40.0f * scaleX),
                               juce::roundToInt(34.0f * scaleY));

        btnMidiTarget.setBounds(juce::roundToInt(682.0f * scaleX),
                                juce::roundToInt(10.0f * scaleY),
                                juce::roundToInt(40.0f * scaleX),
                                juce::roundToInt(34.0f * scaleY));

        btnKeepFormants.setBounds(juce::roundToInt(726.0f * scaleX),
                                  juce::roundToInt(10.0f * scaleY),
                                  juce::roundToInt(40.0f * scaleX),
                                  juce::roundToInt(34.0f * scaleY));

        btnClassicMode.setBounds(juce::roundToInt(770.0f * scaleX),
                                 juce::roundToInt(10.0f * scaleY),
                                 juce::roundToInt(40.0f * scaleX),
                                 juce::roundToInt(34.0f * scaleY));

        btnSmartBrain.setBounds(juce::roundToInt(814.0f * scaleX),
                                juce::roundToInt(10.0f * scaleY),
                                juce::roundToInt(40.0f * scaleX),
                                juce::roundToInt(34.0f * scaleY));

        // Vocal Range, Key & Scale ComboBoxes all'estremità destra (nessuna sovrapposizione, clearance perfetta)
        vocalRangeBox.setBounds(juce::roundToInt(868.0f * scaleX),
                                juce::roundToInt(14.0f * scaleY),
                                juce::roundToInt(106.0f * scaleX),
                                juce::roundToInt(26.0f * scaleY));

        rootBox.setBounds(juce::roundToInt(980.0f * scaleX),
                          juce::roundToInt(14.0f * scaleY),
                          juce::roundToInt(44.0f * scaleX),
                          juce::roundToInt(26.0f * scaleY));

        scaleBox.setBounds(juce::roundToInt(1030.0f * scaleX),
                           juce::roundToInt(14.0f * scaleY),
                           juce::roundToInt(135.0f * scaleX),
                           juce::roundToInt(26.0f * scaleY));
    }

    void drawHeaderBar(juce::Graphics& g, const juce::Rectangle<float>& bounds) {
        // 1. Logo piccolo in alto a sinistra prima di 171 STUDIO (da 171PerfectPre)
        if (logo171Img.isValid()) {
            auto logoRect = juce::Rectangle<float>(20.0f, 13.0f, 21.0f, 25.0f);
            g.drawImage(logo171Img, logoRect, juce::RectanglePlacement::centred);
        }

        // 2. Serigrafia 171 STUDIO in oro satinato
        g.setFont(juce::FontOptions(14.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xffffe082)); // Oro satinato
        g.drawText("171 STUDIO", 46.0f, 15.0f, 92.0f, 20.0f, juce::Justification::left);

        // 3. REAL TUNE: "REAL" sempre BIANCO, "TUNE" sempre ORO
        g.setFont(juce::FontOptions(14.5f, juce::Font::bold));
        g.setColour(juce::Colours::white);
        g.drawText("REAL", 144.0f, 15.0f, 44.0f, 20.0f, juce::Justification::left);

        g.setColour(juce::Colour(0xffffe082)); // Oro satinato
        g.drawText("TUNE", 190.0f, 15.0f, 48.0f, 20.0f, juce::Justification::left);

        // Filetto orizzontale in ottone caldo sotto la testata
        juce::ColourGradient lineGrad(juce::Colour(0x60c5a059), bounds.getX() + 16.0f, 50.0f,
                                      juce::Colour(0x60ffe082), bounds.getRight() - 16.0f, 50.0f, false);
        g.setGradientFill(lineGrad);
        g.drawHorizontalLine(50, bounds.getX() + 16.0f, bounds.getRight() - 16.0f);
    }

    void drawPodPanels(juce::Graphics& g) {
        drawBoutiquePod(g, pod1Bounds.toFloat(), "PITCH ENGINE");
        drawBoutiquePod(g, pod2Bounds.toFloat(), "FORMANT & SPACE");
        drawBoutiquePod(g, masterBounds.toFloat(), "MASTER");
    }

    void drawBoutiquePod(juce::Graphics& g, const juce::Rectangle<float>& r, const juce::String& title) {
        if (r.isEmpty()) return;

        // Inset shadow
        g.setColour(juce::Colour(0x50000000));
        g.fillRoundedRectangle(r.translated(1.0f, 1.5f), 6.0f);

        // Dark gunmetal brushed background
        juce::ColourGradient grad(juce::Colour(0xff181a20), r.getX(), r.getY(),
                                  juce::Colour(0xff0d0f13), r.getX(), r.getBottom(), false);
        g.setGradientFill(grad);
        g.fillRoundedRectangle(r, 6.0f);

        // Chamfered brass bezel
        g.setColour(juce::Colour(0x40c5a059));
        g.drawRoundedRectangle(r, 6.0f, 1.0f);

        // Inner micro-bevel
        g.setColour(juce::Colour(0x15ffffff));
        g.drawRoundedRectangle(r.reduced(1.0f), 5.0f, 0.8f);

        // Header Title Badge
        if (title.isNotEmpty()) {
            float titleH = 14.0f;
            float titleY = r.getY() + 3.0f;
            g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
            g.setColour(juce::Colour(0xffffe082));

            juce::String badgeText = title;
            int textW = g.getCurrentFont().getStringWidth(badgeText) + 16;
            float midX = r.getCentreX();

            // Decorative brass hairlines on left and right
            g.setColour(juce::Colour(0x45c5a059));
            int lineY = juce::roundToInt(titleY + titleH * 0.5f);
            if (midX - (float)textW * 0.5f > r.getX() + 16.0f) {
                g.drawHorizontalLine(lineY, r.getX() + 12.0f, midX - (float)textW * 0.5f - 4.0f);
                g.drawHorizontalLine(lineY, midX + (float)textW * 0.5f + 4.0f, r.getRight() - 12.0f);
            }

            g.drawText(badgeText, juce::roundToInt(r.getX()), juce::roundToInt(titleY),
                       juce::roundToInt(r.getWidth()), juce::roundToInt(titleH), juce::Justification::centred);
        }
    }

    void drawFooterSerigraph(juce::Graphics& g, const juce::Rectangle<float>& bounds) {
        g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
        g.setColour(juce::Colour(0x60c5a059));
        g.drawText("ZERO-LATENCY PRECISION VOCAL TELEMETRY | RETRO-ENGINEERED AUTO-TUNE PRO & WAVES TUNE RT | 171 STUDIO CMF",
                   juce::roundToInt(bounds.getX() + 24.0f), juce::roundToInt(bounds.getBottom() - 15.0f),
                   juce::roundToInt(bounds.getWidth() - 80.0f), 12,
                   juce::Justification::left);
    }

    void drawCornerScrews(juce::Graphics& g, const juce::Rectangle<float>& bounds) {
        float offset = 12.0f;
        float r = 4.5f;
        const float corners[4][2] = {
            { bounds.getX() + offset, bounds.getY() + offset },
            { bounds.getRight() - offset, bounds.getY() + offset },
            { bounds.getX() + offset, bounds.getBottom() - offset },
            { bounds.getRight() - offset, bounds.getBottom() - offset }
        };

        for (const auto& c : corners) {
            float cx = c[0];
            float cy = c[1];

            g.setColour(juce::Colour(0x80000000));
            g.fillEllipse(cx - r + 1.0f, cy - r + 1.5f, r * 2.0f, r * 2.0f);

            juce::ColourGradient screwGrad(juce::Colour(0xff3a3e48), cx - 1.5f, cy - 1.5f,
                                          juce::Colour(0xff16171b), cx + 2.0f, cy + 2.0f, false);
            g.setGradientFill(screwGrad);
            g.fillEllipse(cx - r, cy - r, r * 2.0f, r * 2.0f);

            g.setColour(juce::Colour(0xff0d0e11));
            g.drawLine(cx - 2.5f, cy, cx + 2.5f, cy, 1.2f);
            g.drawLine(cx, cy - 2.5f, cx, cy + 2.5f, 1.2f);
        }
    }

public:
    // Accessori per APVTS Attachment
    juce::Slider& getRetuneSpeedSlider()    noexcept { return knobRetuneSpeed->slider; }
    juce::Slider& getNoteTransitionSlider() noexcept { return knobNoteTransition->slider; }
    juce::Slider& getToleranceSlider()      noexcept { return knobTolerance->slider; }
    juce::Slider& getFlexTuneSlider()       noexcept { return knobFlexTune->slider; }
    juce::Slider& getHumanizeSlider()       noexcept { return knobHumanize->slider; }

    juce::Slider& getFormantSlider()        noexcept { return knobFormant->slider; }
    juce::Slider& getThroatLengthSlider()   noexcept { return knobThroatLength->slider; }
    juce::Slider& getVibratoDepthSlider()   noexcept { return knobVibratoDepth->slider; }
    juce::Slider& getStereoWidthSlider()    noexcept { return knobStereoWidth->slider; }
    juce::Slider& getA4RefSlider()          noexcept { return knobA4Ref->slider; }

    juce::Slider& getOutGainSlider()        noexcept { return knobOutGain->slider; }
    juce::Slider& getMixSlider()            noexcept { return knobCueMix->slider; }

    juce::ComboBox& getVocalRangeBox()      noexcept { return vocalRangeBox; }
    juce::ComboBox& getRootBox()            noexcept { return rootBox; }
    juce::ComboBox& getScaleBox()           noexcept { return scaleBox; }

    JewelLampComponent& getBypassJewel()    noexcept { return jewelBypass; }
    JewelLampComponent& getPitchLockJewel() noexcept { return jewelPitchLock; }
    JewelLampComponent& getDpllJewel()      noexcept { return jewelDpllLock; }
    JewelLampComponent& getRetuneJewel()    noexcept { return jewelRetune; }

    BoutiquePushButton& getLiveBoothButton()    noexcept { return btnLiveBooth; }
    BoutiquePushButton& getMidiTargetButton()   noexcept { return btnMidiTarget; }
    BoutiquePushButton& getKeepFormantsButton() noexcept { return btnKeepFormants; }
    BoutiquePushButton& getClassicModeButton()  noexcept { return btnClassicMode; }
    BoutiquePushButton& getSmartBrainButton()   noexcept { return btnSmartBrain; }
    ScaleKeyboardMatrixComponent& getKeyboardMatrix() noexcept { return keyboardMatrix; }

    std::function<void(int scaleType, int rootKey)> onScaleOrRootChanged;

    dsp171::RealTuneVisualFIFO& fifo;

    // Sotto-componenti GUI
    ScrollingPitchDisplay         pitchDisplay;
    CentDeviationGalvanometer     centMeter;
    ScaleKeyboardMatrixComponent  keyboardMatrix;
    ResizableHandleComponent      resizeHandle;

    JewelLampComponent jewelBypass;
    JewelLampComponent jewelPitchLock;
    JewelLampComponent jewelDpllLock;
    JewelLampComponent jewelRetune;

    BoutiquePushButton btnLiveBooth;
    BoutiquePushButton btnMidiTarget;
    BoutiquePushButton btnKeepFormants;
    BoutiquePushButton btnClassicMode;
    BoutiquePushButton btnSmartBrain;

    // Pod 1 (PITCH ENGINE)
    std::unique_ptr<RealTuneChickenKnobComponent> knobRetuneSpeed;
    std::unique_ptr<RealTuneChickenKnobComponent> knobNoteTransition;
    std::unique_ptr<RealTuneChickenKnobComponent> knobTolerance;
    std::unique_ptr<RealTuneChickenKnobComponent> knobFlexTune;
    std::unique_ptr<RealTuneChickenKnobComponent> knobHumanize;

    // Pod 2 (FORMANT & SPACE)
    std::unique_ptr<RealTuneChickenKnobComponent> knobFormant;
    std::unique_ptr<RealTuneChickenKnobComponent> knobThroatLength;
    std::unique_ptr<RealTuneChickenKnobComponent> knobVibratoDepth;
    std::unique_ptr<RealTuneChickenKnobComponent> knobStereoWidth;
    std::unique_ptr<RealTuneChickenKnobComponent> knobA4Ref;

    // Master Section (Manopole Chicken rotative CUE MIX & OUTPUT TRIM)
    std::unique_ptr<RealTuneChickenKnobComponent> knobCueMix;
    std::unique_ptr<RealTuneChickenKnobComponent> knobOutGain;

    // Selectors
    juce::ComboBox vocalRangeBox;
    juce::ComboBox rootBox;
    juce::ComboBox scaleBox;
    Studio171ComboBoxLookAndFeel comboBoxLookAndFeel;
    juce::Image logo171Img;

    // Pod bounds
    juce::Rectangle<int> pod1Bounds;
    juce::Rectangle<int> pod2Bounds;
    juce::Rectangle<int> masterBounds;
};

} // namespace gui171
