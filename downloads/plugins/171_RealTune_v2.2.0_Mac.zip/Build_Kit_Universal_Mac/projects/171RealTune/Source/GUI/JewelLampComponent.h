#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <BinaryData.h>
#include <functional>

namespace gui171 {

// ==============================================================================
// VINTAGE BOUTIQUE FACETED JEWEL LAMP (Ruby / Emerald / Amber)
// ==============================================================================
class JewelLampComponent : public juce::Component, public juce::SettableTooltipClient {
public:
    enum class LampType {
        Ruby_Bypass,
        Green_PitchLock,
        Amber_Retune,
        Cyan_DpllLock
    };

    JewelLampComponent(LampType type, const juce::String& labelText, bool isInteractive = false)
        : lampType(type), label(labelText), interactive(isInteractive)
    {
        setOpaque(false);

        // Carica texture fotografica ad alta risoluzione da BinaryData
        switch (type) {
            case LampType::Ruby_Bypass:
                imgOn = juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_ruby_on_png, BinaryData::lamp_jewel_ruby_on_pngSize);
                glowColor = juce::Colour(0xffff283b);
                break;
            case LampType::Green_PitchLock:
                imgOn = juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_green_on_png, BinaryData::lamp_jewel_green_on_pngSize);
                glowColor = juce::Colour(0xff00ff88);
                break;
            case LampType::Amber_Retune:
                imgOn = juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_amber_on_png, BinaryData::lamp_jewel_amber_on_pngSize);
                glowColor = juce::Colour(0xffffa020);
                break;
            case LampType::Cyan_DpllLock:
                imgOn = juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_green_on_png, BinaryData::lamp_jewel_green_on_pngSize);
                glowColor = juce::Colour(0xff00e5ff); // Cyan / Blue Elettrico
                break;
        }
        imgOff = juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_dark_off_png, BinaryData::lamp_jewel_dark_off_pngSize);

        if (interactive)
            setMouseCursor(juce::MouseCursor::PointingHandCursor);
    }

    void setLit(bool shouldBeLit) {
        float newTarget = shouldBeLit ? 1.0f : 0.0f;
        if (targetBrightness != newTarget) {
            targetBrightness = newTarget;
            repaint();
        }
    }

    void setBrightness(float val) {
        float newTarget = juce::jlimit(0.0f, 1.0f, val);
        if (std::abs(targetBrightness - newTarget) > 0.005f) {
            targetBrightness = newTarget;
            repaint();
        }
    }

    bool isLit() const noexcept { return targetBrightness > 0.5f; }

    void updateDecay(float decayRate = 0.85f) {
        float prev = currentBrightness;
        currentBrightness += (targetBrightness - currentBrightness) * (1.0f - decayRate);
        // Repaint selettivo: ridisegna solo se l'intensità luminosa è cambiata percettibilmente
        if (std::abs(currentBrightness - prev) > 0.002f || (prev > 0.001f && currentBrightness <= 0.001f)) {
            repaint();
        }
    }

    std::function<void(bool newState)> onClick;

    void mouseDown(const juce::MouseEvent& e) override {
        if (interactive && e.mods.isLeftButtonDown()) {
            bool nextState = !(targetBrightness > 0.5f);
            setLit(nextState);
            if (onClick)
                onClick(nextState);
        }
    }

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat();
        if (bounds.isEmpty()) return;

        // Area suddivisa: lampada sopra, etichetta serigrafata sotto
        float labelH = 12.0f;
        auto lampArea = bounds.removeFromTop(bounds.getHeight() - labelH).reduced(2.0f);
        auto textRect = bounds;

        float lampSize = juce::jmin(lampArea.getWidth(), lampArea.getHeight());
        float cx = lampArea.getCentreX();
        float cy = lampArea.getCentreY();
        auto lampSquare = juce::Rectangle<float>(cx - lampSize * 0.5f, cy - lampSize * 0.5f, lampSize, lampSize);

        // 1. Ombra portata della ghiera in ottone
        g.setColour(juce::Colour(0x80000000));
        g.fillEllipse(lampSquare.translated(1.0f, 2.0f));

        // 2. Disegno gemma OFF (spenta/scura)
        if (imgOff.isValid()) {
            g.drawImage(imgOff, lampSquare, juce::RectanglePlacement::centred);
        }

        // 3. Sovrapposizione gemma ON con crossfade morbido per luminescenza a filamento
        float alpha = currentBrightness > 0.001f ? currentBrightness : targetBrightness;
        if (alpha > 0.02f && imgOn.isValid()) {
            // Alone radiale diffuso di luce dietro la ghiera
            juce::ColourGradient bloom(glowColor.withAlpha(0.42f * alpha), cx, cy,
                                       glowColor.withAlpha(0.0f), cx - lampSize * 0.85f, cy - lampSize * 0.85f, true);
            g.setGradientFill(bloom);
            g.fillEllipse(cx - lampSize * 0.8f, cy - lampSize * 0.8f, lampSize * 1.6f, lampSize * 1.6f);

            // Gemma ON illuminata
            g.setOpacity(alpha);
            if (lampType == LampType::Cyan_DpllLock) {
                g.drawImage(imgOn, lampSquare, juce::RectanglePlacement::centred);
                g.setColour(juce::Colour(0xff00e5ff));
                g.setOpacity(0.55f * alpha);
                g.fillEllipse(lampSquare.reduced(lampSquare.getWidth() * 0.16f));
                g.setColour(juce::Colours::white);
                g.setOpacity(0.40f * alpha);
                g.fillEllipse(lampSquare.reduced(lampSquare.getWidth() * 0.35f));
            } else {
                g.drawImage(imgOn, lampSquare, juce::RectanglePlacement::centred);
            }
            g.setOpacity(1.0f);
        }

        // 4. Etichetta incisa laser sotto la gemma
        if (label.isNotEmpty()) {
            g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
            // Colore oro satinato per labels
            g.setColour(alpha > 0.5f ? glowColor.interpolatedWith(juce::Colour(0xffffe082), 0.5f)
                                     : juce::Colour(0x99c5a059));
            g.drawText(label, textRect, juce::Justification::centred);
        }
    }

private:
    LampType lampType;
    juce::String label;
    bool interactive;
    float targetBrightness = 0.0f;
    float currentBrightness = 0.0f;
    juce::Image imgOn;
    juce::Image imgOff;
    juce::Colour glowColor;
};

} // namespace gui171
