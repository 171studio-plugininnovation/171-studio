#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <cassert>
#include <chrono>
#include <random>
#include <string>
#include <sstream>
#include <limits>

#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_formats/juce_audio_formats.h>

#include "PluginProcessor.h"
#include <dsp171/Common.h>
#include <dsp171/MusicalQuantizer.h>
#include <dsp171/RetuneFilter.h>
#include <dsp171/FormantProcessor.h>
#include <dsp171/FormantShaperZDF.h>
#include <dsp171/LPCVocalTract.h>
#include <dsp171/StereoWidthEnhancer.h>
#include <dsp171/RealTuneNeuralBrain.h>
#include <dsp171/RealTuneEngine.h>

using namespace dsp171;

// Helper print banner
static void printSection(const std::string& title) {
    std::cout << "\n======================================================================\n";
    std::cout << " [CIRCUIT AUDIT] " << title << "\n";
    std::cout << "======================================================================\n";
}

// =============================================================================
// AUDIT 1: Musical Quantizer, 8 Scales & 12-Bit Masks
// =============================================================================
bool auditMusicalQuantizerAndScales() {
    printSection("1. Musical Quantizer, 8 Scale Masks, Custom, Bypass & Blocked Masks");
    MusicalQuantizer quant;
    quant.setA4Reference(440.0f);

    bool allPassed = true;

    // 1.1 Verify bitmasks for the 8 primary scales
    struct ScaleSpec {
        ScaleType type;
        const char* name;
        uint16_t expectedMask;
        std::vector<int> expectedIntervals;
    };

    const std::vector<ScaleSpec> scales = {
        { ScaleType::Chromatic,        "Chromatic",         0x0FFF, {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11} },
        { ScaleType::Major,            "Major",             0x0AB5, {0, 2, 4, 5, 7, 9, 11} },
        { ScaleType::NaturalMinor,     "Natural Minor",     0x05AD, {0, 2, 3, 5, 7, 8, 10} },
        { ScaleType::HarmonicMinor,    "Harmonic Minor",    0x09AD, {0, 2, 3, 5, 7, 8, 11} },
        { ScaleType::MajorPentatonic,  "Major Pentatonic",  0x0295, {0, 2, 4, 7, 9} },
        { ScaleType::MinorPentatonic,  "Minor Pentatonic",  0x04A9, {0, 3, 5, 7, 10} },
        { ScaleType::Dorian,           "Dorian",            0x06AD, {0, 2, 3, 5, 7, 9, 10} },
        { ScaleType::Custom,           "Custom (Whole Tone)", 0x0555, {0, 2, 4, 6, 8, 10} }
    };

    std::cout << "[*] 1.1 Testing Scale Bitmasks and Active Note Degrees:\n";
    for (const auto& s : scales) {
        if (s.type == ScaleType::Custom) {
            quant.setCustomMask(s.expectedMask);
        }
        quant.setScale(s.type);
        quant.setRootKey(0); // C

        const uint16_t mask = quant.getActiveMask();
        const bool maskOk = (mask == s.expectedMask);
        std::cout << "    Scale: " << std::left << std::setw(20) << s.name
                  << " | Mask: 0x" << std::hex << std::uppercase << std::setw(4) << std::setfill('0') << mask
                  << std::dec << std::setfill(' ')
                  << " | Degrees: ";
        for (int deg : s.expectedIntervals) {
            std::cout << deg << " ";
            if (!quant.isPitchClassActive(deg)) {
                std::cout << "(FAIL: deg " << deg << " inactive!) ";
                allPassed = false;
            }
        }
        std::cout << (maskOk ? " [PASS]\n" : " [FAIL]\n");
        if (!maskOk) allPassed = false;
    }

    // 1.2 Transposition test across all 12 root keys
    std::cout << "\n[*] 1.2 Transposition across all 12 Root Keys (Major Scale):\n";
    quant.setScale(ScaleType::Major);
    for (int root = 0; root < 12; ++root) {
        quant.setRootKey(root);
        // Degree 0 (root) must be active
        if (!quant.isPitchClassActive(root)) {
            std::cout << "    FAIL: Root " << root << " not active!\n";
            allPassed = false;
        }
        // Degree 4 (major third: root + 4 semitones) must be active
        const int majorThird = (root + 4) % 12;
        if (!quant.isPitchClassActive(majorThird)) {
            std::cout << "    FAIL: Major third " << majorThird << " for root " << root << " not active!\n";
            allPassed = false;
        }
        // Degree 1 (minor second: root + 1 semitone) must NOT be active
        const int minorSecond = (root + 1) % 12;
        if (quant.isPitchClassActive(minorSecond)) {
            std::cout << "    FAIL: Minor second " << minorSecond << " for root " << root << " active in major!\n";
            allPassed = false;
        }
    }
    std::cout << "    All 12 roots transposed correctly with exact interval preservation. [PASS]\n";

    // 1.3 Custom Mask Empty Fallback Safety
    std::cout << "\n[*] 1.3 Custom Mask Fallback Safety (Zero mask -> Fallback Chromatic):\n";
    quant.setScale(ScaleType::Custom);
    quant.setCustomMask(0); // Empty mask
    const uint16_t fallbackMask = quant.getActiveMask();
    const bool fallbackOk = (fallbackMask == 0x0FFF);
    std::cout << "    Mask after 0x0000: 0x" << std::hex << fallbackMask << std::dec
              << (fallbackOk ? " [PASS: Safely reverted to Chromatic]\n" : " [FAIL]\n");
    if (!fallbackOk) allPassed = false;

    // 1.4 Bypass Mask Test
    std::cout << "\n[*] 1.4 Bypass Mask (Bit 0 = C in bypass, detuned C4 passes through):\n";
    quant.setScale(ScaleType::Major);
    quant.setRootKey(0); // C Major
    quant.setBypassMask(1 << 0); // Note C in bypass

    // C4 = 261.6256 Hz, detuned by +30 cents:
    const float detunedC4 = 261.6256f * std::pow(2.0f, 30.0f / 1200.0f);
    QuantizeResult resBypass = quant.quantize(detunedC4);
    const bool bypassOk = (std::abs(resBypass.pitchRatio - 1.0f) < 1e-4f) &&
                          (std::abs(resBypass.centsOffset) < 1e-4f) &&
                          (std::abs(resBypass.targetFreqHz - detunedC4) < 1e-3f) &&
                          resBypass.isValid;
    std::cout << "    Detuned C4 In: " << detunedC4 << " Hz | Out: " << resBypass.targetFreqHz
              << " Hz | Ratio: " << resBypass.pitchRatio << " | Cents: " << resBypass.centsOffset
              << (bypassOk ? " [PASS: Preserved intact]\n" : " [FAIL]\n");
    if (!bypassOk) allPassed = false;

    // D4 (MIDI 62) is not in bypass -> must be retuned
    const float detunedD4 = 293.6648f * std::pow(2.0f, 30.0f / 1200.0f);
    QuantizeResult resD4 = quant.quantize(detunedD4);
    const bool retuneOk = (std::abs(resD4.centsOffset - (-30.0f)) < 0.1f) &&
                          (std::abs(resD4.targetFreqHz - 293.6648f) < 0.1f);
    std::cout << "    Detuned D4 In: " << detunedD4 << " Hz | Out: " << resD4.targetFreqHz
              << " Hz | Ratio: " << resD4.pitchRatio << " | Cents: " << resD4.centsOffset
              << (retuneOk ? " [PASS: Retuned as expected]\n" : " [FAIL]\n");
    if (!retuneOk) allPassed = false;
    quant.setBypassMask(0); // Reset

    // 1.5 Blocked Mask Test
    std::cout << "\n[*] 1.5 Blocked Mask (In C Major, block note E4 = pitchClass 4):\n";
    quant.setBlockedMask(1 << 4); // Block note E
    // Input E4 (329.6276 Hz) -> should snap to D4 (62) or F4 (65), never E4 (64)
    QuantizeResult resBlocked = quant.quantize(329.6276f);
    const bool blockedOk = (resBlocked.targetMidiNote != 64) &&
                           (resBlocked.targetMidiNote == 62 || resBlocked.targetMidiNote == 65);
    std::cout << "    Input E4 (329.63 Hz, MIDI 64) -> Snapped to: "
              << MusicalQuantizer::getPitchClassName(resBlocked.notePitchClass)
              << resBlocked.octave << " (MIDI " << resBlocked.targetMidiNote << ")"
              << (blockedOk ? " [PASS: E4 avoided]\n" : " [FAIL]\n");
    if (!blockedOk) allPassed = false;

    // Block ALL 12 notes: must safely bypass
    quant.setBlockedMask(0x0FFF);
    QuantizeResult resAllBlocked = quant.quantize(440.0f);
    const bool allBlockedOk = (std::abs(resAllBlocked.pitchRatio - 1.0f) < 1e-4f) &&
                              (std::abs(resAllBlocked.centsOffset) < 1e-4f);
    std::cout << "    All 12 notes blocked -> Ratio: " << resAllBlocked.pitchRatio
              << (allBlockedOk ? " [PASS: Clean bypass without crash]\n" : " [FAIL]\n");
    if (!allBlockedOk) allPassed = false;
    quant.setBlockedMask(0); // Reset

    return allPassed;
}

// =============================================================================
// AUDIT 2: Reference A4 Calibration Precision (415 Hz to 466 Hz)
// =============================================================================
bool auditReferenceA4Precision() {
    printSection("2. Reference LA4 (A4 Tuning from 415 Hz to 466 Hz) Precision");
    MusicalQuantizer quant;
    quant.setScale(ScaleType::Chromatic);
    quant.setRootKey(0);

    bool allPassed = true;

    const std::vector<float> testA4Refs = { 415.0f, 432.0f, 440.0f, 442.0f, 466.0f };

    std::cout << std::left << std::setw(12) << "A4 Ref (Hz)"
              << std::setw(15) << "Input Freq"
              << std::setw(15) << "Target Freq"
              << std::setw(12) << "Target MIDI"
              << std::setw(12) << "Cents Err"
              << "Esito\n";
    std::cout << "----------------------------------------------------------------------\n";

    for (float a4 : testA4Refs) {
        quant.setA4Reference(a4);

        // Test Note A4
        QuantizeResult resA4 = quant.quantize(a4);
        const float errA4 = std::abs(resA4.targetFreqHz - a4);
        const bool passA4 = (resA4.targetMidiNote == 69) && (errA4 < 0.001f) && (std::abs(resA4.centsOffset) < 0.01f);

        std::cout << std::left << std::setw(12) << a4
                  << std::setw(15) << a4
                  << std::setw(15) << resA4.targetFreqHz
                  << std::setw(12) << resA4.targetMidiNote
                  << std::setw(12) << resA4.centsOffset
                  << (passA4 ? "[PASS]" : "[FAIL]") << "\n";
        if (!passA4) allPassed = false;

        // Test Middle C4 (9 semitones below A4: f = A4 * 2^(-9/12))
        const float idealC4 = a4 * std::pow(2.0f, -9.0f / 12.0f);
        QuantizeResult resC4 = quant.quantize(idealC4);
        const float errC4 = std::abs(resC4.targetFreqHz - idealC4);
        const bool passC4 = (resC4.targetMidiNote == 60) && (errC4 < 0.001f) && (std::abs(resC4.centsOffset) < 0.01f);

        std::cout << std::left << std::setw(12) << a4
                  << std::setw(15) << idealC4
                  << std::setw(15) << resC4.targetFreqHz
                  << std::setw(12) << resC4.targetMidiNote
                  << std::setw(12) << resC4.centsOffset
                  << (passC4 ? "[PASS]" : "[FAIL]") << "\n";
        if (!passC4) allPassed = false;
    }

    // Clamp limits test
    quant.setA4Reference(390.0f); // below 415
    const float clampedLow = quant.getA4Reference();
    const bool clampLowOk = (std::abs(clampedLow - 415.0f) < 1e-4f);

    quant.setA4Reference(520.0f); // above 466
    const float clampedHigh = quant.getA4Reference();
    const bool clampHighOk = (std::abs(clampedHigh - 466.0f) < 1e-4f);

    std::cout << "\n[*] Clamping range [415..466 Hz]:\n";
    std::cout << "    Input 390 Hz -> Clamped: " << clampedLow << " Hz "
              << (clampLowOk ? "[PASS]\n" : "[FAIL]\n");
    std::cout << "    Input 520 Hz -> Clamped: " << clampedHigh << " Hz "
              << (clampHighOk ? "[PASS]\n" : "[FAIL]\n");

    if (!clampLowOk || !clampHighOk) allPassed = false;
    quant.setA4Reference(440.0f);

    return allPassed;
}

// =============================================================================
// AUDIT 3: Retune Filter Ballistics, Quintic S-Curve, Flex-Tune & Humanize
// =============================================================================
bool auditRetuneFilterBallistics() {
    printSection("3. Retune Filter Ballistics, Quintic Smootherstep S-Curve, Flex-Tune & Humanize");
    RetuneFilter rf;
    const double sr = 48000.0;
    rf.prepare(sr);

    bool allPassed = true;

    // 3.1 Hard-Tune (0 ms instant snap)
    std::cout << "[*] 3.1 Hard-Tune (0 ms) Step Response:\n";
    rf.setRetuneSpeedMs(0.0f);
    rf.setAmount(1.0f);
    rf.setClassicMode(false);

    // Initial step: rawRatio = 1.25 (+386 cents)
    const float outHard0 = rf.processSample(1.25f, 386.3f, 64);
    const bool hardSnapOk = (std::abs(outHard0 - 1.25f) < 1e-5f);
    std::cout << "    Target Ratio: 1.250000 | Sample 0 Output: " << std::fixed << std::setprecision(6) << outHard0
              << (hardSnapOk ? " [PASS: Instant 0 ms snap]\n" : " [FAIL]\n");
    if (!hardSnapOk) allPassed = false;

    // 3.2 Mathematical Verification of Perlin Quintic Smootherstep S(u) = 6u^5 - 15u^4 + 10u^3
    std::cout << "\n[*] 3.2 Quintic Smootherstep S(u) Mathematical Properties:\n";
    auto S = [](float u) { return u * u * u * (u * (u * 6.0f - 15.0f) + 10.0f); };
    auto dS = [](float u) { return 30.0f * u * u * (u - 1.0f) * (u - 1.0f); }; // 30u^4 - 60u^3 + 30u^2
    auto d2S = [](float u) { return 60.0f * u * (2.0f * u * u - 3.0f * u + 1.0f); }; // 120u^3 - 180u^2 + 60u

    const bool s0 = (std::abs(S(0.0f) - 0.0f) < 1e-6f);
    const bool sMid = (std::abs(S(0.5f) - 0.5f) < 1e-6f);
    const bool s1 = (std::abs(S(1.0f) - 1.0f) < 1e-6f);
    const bool ds0 = (std::abs(dS(0.0f) - 0.0f) < 1e-6f);
    const bool ds1 = (std::abs(dS(1.0f) - 0.0f) < 1e-6f);
    const bool d2s0 = (std::abs(d2S(0.0f) - 0.0f) < 1e-6f);
    const bool d2s1 = (std::abs(d2S(1.0f) - 0.0f) < 1e-6f);

    std::cout << "    S(0)= " << S(0.0f) << " | S(0.5)= " << S(0.5f) << " | S(1)= " << S(1.0f)
              << " | S'(0)= " << dS(0.0f) << " | S'(1)= " << dS(1.0f)
              << " | S''(0)= " << d2S(0.0f) << " | S''(1)= " << d2S(1.0f) << "\n";
    const bool quinticMathOk = s0 && sMid && s1 && ds0 && ds1 && d2s0 && d2s1;
    std::cout << "    C^2 Continuity & Smooth Boundary Properties: "
              << (quinticMathOk ? "[PASS: Strict C^2 continuity]\n" : "[FAIL]\n");
    if (!quinticMathOk) allPassed = false;

    // 3.3 Modern Pop Note Transition Glide (20 ms = 960 samples)
    std::cout << "\n[*] 3.3 Note Transition Smootherstep Glide (20 ms = 960 samples @ 48 kHz):\n";
    rf.reset();
    rf.setRetuneSpeedMs(15.0f);
    rf.setNoteTransitionMs(20.0f);
    rf.setTolerance(0.0f, 0.0f);

    // Initial note MIDI 60 (C4, ratio = 1.0)
    for (int i = 0; i < 200; ++i) rf.processSample(1.0f, 0.0f, 60);

    // Note switch to MIDI 62 (D4, ratio = 2^(2/12) ~ 1.122462)
    const float targetRatio = std::pow(2.0f, 2.0f / 12.0f);
    std::vector<float> glideTraj;
    glideTraj.reserve(1200);

    for (int i = 0; i < 1200; ++i) {
        glideTraj.push_back(rf.processSample(targetRatio, 200.0f, 62));
    }

    const float startVal = glideTraj[0];
    const float midVal   = glideTraj[480]; // exactly halfway through 960 samples
    const float endVal   = glideTraj[960];
    const float settledVal = glideTraj[1199];

    std::cout << "    Glide: start(0)= " << startVal
              << " | mid(480)= " << midVal
              << " | end(960)= " << endVal
              << " | settled(1199)= " << settledVal << "\n";

    // Verify S-curve behavior: mid value is roughly halfway
    const float idealMid = 1.0f + 0.5f * (targetRatio - 1.0f);
    const bool glideOk = (startVal < 1.01f) &&
                         (std::abs(midVal - idealMid) < 0.02f) &&
                         (std::abs(settledVal - targetRatio) < 0.005f);
    std::cout << "    Smootherstep S-Curve Trajectory: " << (glideOk ? "[PASS]\n" : "[FAIL]\n");
    if (!glideOk) allPassed = false;

    // Verify derivative continuity: max sample-to-sample slope
    float maxDelta = 0.0f;
    for (size_t i = 1; i < glideTraj.size(); ++i) {
        maxDelta = std::max(maxDelta, std::abs(glideTraj[i] - glideTraj[i - 1]));
    }
    std::cout << "    Max sample-to-sample delta: " << maxDelta << " (strictly smooth, < 0.001) [PASS]\n";
    if (maxDelta > 0.001f) allPassed = false;

    // 3.4 Classic Mode DSP (Auto-Tune 5 hard snap on note transition)
    std::cout << "\n[*] 3.4 Classic Mode DSP (Auto-Tune 5 Hard Snap):\n";
    rf.reset();
    rf.setClassicMode(true);
    rf.setRetuneSpeedMs(15.0f);
    rf.setNoteTransitionMs(120.0f);

    for (int i = 0; i < 200; ++i) rf.processSample(1.0f, 0.0f, 60);

    // Switch to MIDI 62: must snap immediately on sample 0
    const float classicOut = rf.processSample(targetRatio, 200.0f, 62);
    const bool classicSnapOk = (std::abs(classicOut - targetRatio) < 1e-4f);
    std::cout << "    Classic Mode Note Switch Output: " << classicOut << " (Target: " << targetRatio << ") "
              << (classicSnapOk ? "[PASS: Instant note snap]\n" : "[FAIL]\n");
    if (!classicSnapOk) allPassed = false;
    rf.setClassicMode(false);

    // 3.5 Flex-Tune Verification
    std::cout << "\n[*] 3.5 Flex-Tune (100% Flex: relaxed correction away from note center):\n";
    rf.reset();
    rf.setRetuneSpeedMs(0.0f); // Instant to measure pure static modulation
    rf.setFlexTune(100.0f);

    // Deviation = 0 cents: blend = 1.0 -> full correction
    float r0 = rf.processSample(1.0f, 0.0f, 60);
    // Deviation = 25 cents: blend = 0.5 * (1 + cos(pi * 25/50)) = 0.5
    const float raw25 = std::pow(2.0f, 25.0f / 1200.0f);
    float r25 = rf.processSample(raw25, 25.0f, 60);
    // Expected effective cents = 25 * 0.5 = 12.5 cents -> ratio = 2^(12.5/1200)
    const float expectedR25 = std::pow(2.0f, 12.5f / 1200.0f);
    // Deviation = 50 cents: blend = 0.5 * (1 + cos(pi)) = 0.0 -> no correction (ratio = 1.0)
    const float raw50 = std::pow(2.0f, 50.0f / 1200.0f);
    float r50 = rf.processSample(raw50, 50.0f, 60);

    std::cout << "    Flex-Tune @ 0 cents:  Ratio " << r0 << " (Ideal 1.000000)\n";
    std::cout << "    Flex-Tune @ 25 cents: Ratio " << r25 << " (Ideal " << expectedR25 << ")\n";
    std::cout << "    Flex-Tune @ 50 cents: Ratio " << r50 << " (Ideal 1.000000 - completely relaxed)\n";

    const bool flexOk = (std::abs(r0 - 1.0f) < 1e-4f) &&
                        (std::abs(r25 - expectedR25) < 1e-3f) &&
                        (std::abs(r50 - 1.0f) < 1e-3f);
    std::cout << "    Flex-Tune Weighting Function: " << (flexOk ? "[PASS]\n" : "[FAIL]\n");
    if (!flexOk) allPassed = false;
    rf.setFlexTune(0.0f);

    // 3.6 Humanize Pitch Preservation (Must NEVER cause static pitch sag!)
    std::cout << "\n[*] 3.6 Humanize (Relaxation on sustained notes without pitch sag):\n";
    rf.reset();
    rf.setRetuneSpeedMs(15.0f);
    rf.setHumanize(50.0f);

    // Feed centered note (0 cents offset) for 1 second (48000 samples)
    float maxSag = 0.0f;
    for (int i = 0; i < 48000; ++i) {
        float r = rf.processSample(1.0f, 0.0f, 60);
        maxSag = std::max(maxSag, std::abs(r - 1.0f));
    }
    const bool sagFreeOk = (maxSag < 1e-5f);
    std::cout << "    Sustained Note (1.0s) Center Ratio Deviation: " << maxSag
              << (sagFreeOk ? " [PASS: Zero static pitch sag]\n" : " [FAIL: Inadmissible detuning!]\n");
    if (!sagFreeOk) allPassed = false;

    return allPassed;
}

// =============================================================================
// AUDIT 4: Waves Tune RT Deadband Tolerance & Natural Vibrato (~5.8 Hz)
// =============================================================================
bool auditNaturalVibratoAndDeadbandTolerance() {
    printSection("4. Natural Vibrato Tracking Engine (~5.8 Hz) & Waves Tune RT Deadband Tolerance");
    RetuneFilter rf;
    const double sr = 48000.0;
    rf.prepare(sr);

    bool allPassed = true;

    // 4.1 Waves Tune RT Deadband Tolerance (Cents)
    std::cout << "[*] 4.1 Waves Tune RT Tolerance Cents (Deadband):\n";
    rf.setRetuneSpeedMs(0.0f); // Instant for exact measurement
    rf.setTolerance(15.0f, 0.0f); // 15 cents deadband

    // Test A: Small deviation within deadband (+10 cents <= 15) -> must pass through untouched (target ratio = 1.0)
    const float raw10 = std::pow(2.0f, 10.0f / 1200.0f);
    const float out10 = rf.processSample(raw10, 10.0f, 60);
    const bool deadbandInsideOk = (std::abs(out10 - 1.0f) < 1e-4f);
    std::cout << "    Deviation +10 cents (within 15c deadband) -> Out Ratio: " << out10
              << (deadbandInsideOk ? " [PASS: Unaltered natural intonation]\n" : " [FAIL]\n");
    if (!deadbandInsideOk) allPassed = false;

    // Test B: Large deviation exceeding deadband (+35 cents > 15) -> corrected by excess (35 - 15 = 20 cents)
    const float raw35 = std::pow(2.0f, 35.0f / 1200.0f);
    const float out35 = rf.processSample(raw35, 35.0f, 60);
    const float expectedRatio20 = std::pow(2.0f, 20.0f / 1200.0f);
    const bool deadbandOutsideOk = (std::abs(out35 - expectedRatio20) < 1e-3f);
    std::cout << "    Deviation +35 cents (exceeds 15c deadband) -> Out Ratio: " << out35
              << " | Expected (excess 20c): " << expectedRatio20
              << (deadbandOutsideOk ? " [PASS: Smooth excess pull]\n" : " [FAIL]\n");
    if (!deadbandOutsideOk) allPassed = false;

    // 4.2 Waves Tune RT Time Tolerance (Hysteresis Timer before note change)
    std::cout << "\n[*] 4.2 Waves Tune RT Time Tolerance (50 ms hysteresis timer):\n";
    rf.reset();
    rf.setRetuneSpeedMs(15.0f);
    rf.setTolerance(10.0f, 50.0f); // 50 ms timer = 2400 samples

    // Sustain on note MIDI 60
    for (int i = 0; i < 500; ++i) rf.processSample(1.0f, 0.0f, 60);
    assert(rf.getActiveNoteMidi() == 60);

    // Briefly departure to MIDI 61 for 30 ms (1440 samples < 2400 samples)
    // The singer is now singing note 61 (rawRatio = 1.0, cents = 0 on note 61, 100 cents away from note 60)
    for (int i = 0; i < 1440; ++i) {
        rf.processSample(1.0f, 0.0f, 61);
    }
    const bool timeHoldOk = (rf.getActiveNoteMidi() == 60);
    std::cout << "    Note held during 30 ms transient departure (< 50 ms): Active MIDI "
              << rf.getActiveNoteMidi() << (timeHoldOk ? " [PASS: Prev note held]\n" : " [FAIL]\n");
    if (!timeHoldOk) allPassed = false;

    // Continue staying on MIDI 61 for another 1200 samples (total 2640 samples > 2400 samples): note switch confirmed!
    for (int i = 0; i < 1200; ++i) {
        rf.processSample(1.0f, 0.0f, 61);
    }
    const bool timeSwitchOk = (rf.getActiveNoteMidi() == 61);
    std::cout << "    Note confirmed after > 50 ms departure: Active MIDI "
              << rf.getActiveNoteMidi() << (timeSwitchOk ? " [PASS: Note transition confirmed]\n" : " [FAIL]\n");
    if (!timeSwitchOk) allPassed = false;
    rf.setTolerance(0.0f, 0.0f);

    // 4.3 Natural Vibrato Preservation (~5.8 Hz Bandpass Engine)
    std::cout << "\n[*] 4.3 Natural Vibrato Preservation (~5.8 Hz bandpass tracking):\n";
    rf.reset();
    rf.setRetuneSpeedMs(0.0f); // Hard-Tune (0 ms) mode to demonstrate clear vibrato preservation vs flattening
    rf.setVibrato(true, 100.0f); // 100% natural vibrato preservation

    // Simulate singer vocal vibrato at 5.8 Hz (+/- 25 cents modulation)
    const double vibFreq = 5.8;
    const float vibCentsAmp = 25.0f;
    std::vector<float> netVocalVib;
    netVocalVib.reserve(48000); // 1.0 second

    for (int i = 0; i < 48000; ++i) {
        const double t = static_cast<double>(i) / sr;
        const float voiceCents = vibCentsAmp * static_cast<float>(std::sin(2.0 * PI_D * vibFreq * t));
        const float correctionCents = -voiceCents; // Quantizer error pulling back to center
        const float rawRatio = std::pow(2.0f, correctionCents / 1200.0f);
        const float outRatio = rf.processSample(rawRatio, correctionCents, 60);
        if (i > 24000) { // steady state after bandpass warmup
            const float netCents = voiceCents + 1200.0f * std::log2(std::max(0.01f, outRatio));
            netVocalVib.push_back(netCents);
        }
    }

    // Measure peak-to-peak output swing
    float minVib = 1e6f, maxVib = -1e6f;
    for (float v : netVocalVib) {
        minVib = std::min(minVib, v);
        maxVib = std::max(maxVib, v);
    }
    const float preservedSwing = maxVib - minVib;
    std::cout << "    Input Vibrato Swing: 50.0 cents (+/-25c) | Preserved Vocal Swing: " << preservedSwing << " cents\n";

    // With 100% depth, the singer's natural vibrato is preserved on output (> 25 cents swing)
    const bool vibPreservedOk = (preservedSwing > 25.0f);
    std::cout << "    Natural Vibrato Preservation Engine: "
              << (vibPreservedOk ? "[PASS: Singer natural vibrato preserved]\n" : "[FAIL: Vibrato over-flattened]\n");
    if (!vibPreservedOk) allPassed = false;

    // Test with Vibrato Depth = 0% (Robotic Hard-Tune): vibrato must be flattened to 0!
    rf.reset();
    rf.setRetuneSpeedMs(0.0f);
    rf.setVibrato(false, 0.0f);
    std::vector<float> netVocalFlat;
    netVocalFlat.reserve(48000);

    for (int i = 0; i < 48000; ++i) {
        const double t = static_cast<double>(i) / sr;
        const float voiceCents = vibCentsAmp * static_cast<float>(std::sin(2.0 * PI_D * vibFreq * t));
        const float correctionCents = -voiceCents;
        const float rawRatio = std::pow(2.0f, correctionCents / 1200.0f);
        const float outRatio = rf.processSample(rawRatio, correctionCents, 60);
        if (i > 24000) {
            const float netCents = voiceCents + 1200.0f * std::log2(std::max(0.01f, outRatio));
            netVocalFlat.push_back(netCents);
        }
    }

    float minFlat = 1e6f, maxFlat = -1e6f;
    for (float v : netVocalFlat) {
        minFlat = std::min(minFlat, v);
        maxFlat = std::max(maxFlat, v);
    }
    const float flatSwing = maxFlat - minFlat;
    std::cout << "    Vibrato Off (0% - Robotic): Net Vocal Swing: " << flatSwing << " cents\n";
    const bool flatOk = (flatSwing < 1.0f); // In Hard-Tune with vibrato off, swing is 0.00 cents
    std::cout << "    Robotic Vibrato Elimination: "
              << (flatOk ? "[PASS: Flattened to robotic pitch]\n" : "[FAIL]\n");
    if (!flatOk) allPassed = false;

    return allPassed;
}

// =============================================================================
// AUDIT 5: Formant Shaper ZDF SVF & LPC Vocal Tract Throat Length Modeling
// =============================================================================
bool auditFormantShaperAndThroatLength() {
    printSection("5. Formant Shaper ZDF SVF, Keep Formants & LPC Throat Length Modeling");
    const double sr = 48000.0;
    bool allPassed = true;

    // 5.1 Melda-Style Keep Formants Inverse Tracking Formula: FormantShift_auto = -12 * log2(pitchRatio)
    std::cout << "[*] 5.1 Keep Formants Dynamic Tracking Mathematical Inversion:\n";
    FormantProcessor fp;
    fp.prepare(sr);
    fp.setKeepFormants(true);
    fp.setManualFormantShift(0.0f);

    struct FormantCase {
        float pitchRatio;
        float expectedAutoShift;
    };

    const std::vector<FormantCase> cases = {
        { 1.000000f,   0.0f },    // Unshifted
        { 1.059463f,  -1.0f },    // +1 semitone retune -> formants shift -1 st
        { 1.189207f,  -3.0f },    // +3 semitones retune -> formants shift -3 st
        { 1.414214f,  -6.0f },    // +6 semitones retune -> formants shift -6 st
        { 2.000000f, -12.0f },    // +1 octave retune -> formants shift -12 st
        { 0.500000f,  12.0f },    // -1 octave retune -> formants shift +12 st
        { 0.840896f,   3.0f }     // -3 semitones retune -> formants shift +3 st
    };

    for (const auto& c : cases) {
        fp.updateTracking(220.0f, c.pitchRatio, true);
        const float autoShift = fp.getAutoFormantShiftSemitones();
        const float effShift = fp.getEffectiveFormantShiftSemitones();
        const float err = std::abs(autoShift - c.expectedAutoShift);
        const bool caseOk = (err < 0.05f);

        std::cout << "    Pitch Ratio: " << std::fixed << std::setprecision(4) << c.pitchRatio
                  << " | Auto Shift: " << std::setw(6) << autoShift
                  << " st (Expected: " << std::setw(6) << c.expectedAutoShift << " st) "
                  << (caseOk ? "[PASS]\n" : "[FAIL]\n");
        if (!caseOk) allPassed = false;
    }

    // Combined manual shift + auto shift
    fp.setManualFormantShift(2.5f);
    fp.updateTracking(220.0f, 1.189207f, true); // auto = -3.0 st
    // effective target = 2.5 + (-3.0) = -0.5 st
    // Run samples for smoother
    for (int i = 0; i < 2000; ++i) fp.processSample(0.0f);
    const float combinedEff = fp.getEffectiveFormantShiftSemitones();
    const bool combinedOk = (std::abs(combinedEff - (-0.5f)) < 0.05f);
    std::cout << "    Superposition: Manual (+2.5 st) + Auto (-3.0 st) = " << combinedEff << " st (Expected: -0.5 st) "
              << (combinedOk ? "[PASS]\n" : "[FAIL]\n");
    if (!combinedOk) allPassed = false;

    // 5.2 ZDF SVF Bell 64-Bit Resonator Verification (Cytomic / Zavalishin)
    std::cout << "\n[*] 5.2 ZDF SVF Bell 64-Bit Filter Response and Stability:\n";
    ZDFSVFBell64 bell;

    // Test A: 0 dB Gain -> Bit-exact passthrough
    bell.setParameters(1000.0f, 2.0f, 0.0f, static_cast<float>(sr));
    float maxPassthroughErr = 0.0f;
    for (int i = 0; i < 1000; ++i) {
        const float inS = 0.8f * std::sin(2.0f * PI * 1000.0f * static_cast<float>(i) / 48000.0f);
        const float outS = bell.process(inS);
        maxPassthroughErr = std::max(maxPassthroughErr, std::abs(outS - inS));
    }
    const bool passthroughOk = (maxPassthroughErr < 1.0e-6f);
    std::cout << "    0 dB Gain Passthrough Error: " << maxPassthroughErr
              << (passthroughOk ? " [PASS: Bit-exact passthrough]\n" : " [FAIL]\n");
    if (!passthroughOk) allPassed = false;

    // Test B: +6.02 dB Gain @ 1000 Hz -> Exactly 2.00x amplitude gain
    bell.reset();
    bell.setParameters(1000.0f, 2.0f, 6.0206f, static_cast<float>(sr));
    float maxIn = 0.0f, maxOut = 0.0f;
    for (int i = 0; i < 4800; ++i) {
        const float inS = std::sin(2.0f * PI * 1000.0f * static_cast<float>(i) / 48000.0f);
        const float outS = bell.process(inS);
        if (i > 3800) {
            maxIn = std::max(maxIn, std::abs(inS));
            maxOut = std::max(maxOut, std::abs(outS));
        }
    }
    const float measuredBoost = maxOut / maxIn;
    const bool boostOk = (std::abs(measuredBoost - 2.0f) < 0.02f);
    std::cout << "    +6 dB Bell Gain @ fc: Measured Gain = " << measuredBoost << " (Ideal: 2.000) "
              << (boostOk ? "[PASS]\n" : "[FAIL]\n");
    if (!boostOk) allPassed = false;

    // Test C: -6.02 dB Gain @ 1000 Hz -> Exactly 0.50x amplitude gain
    bell.reset();
    bell.setParameters(1000.0f, 2.0f, -6.0206f, static_cast<float>(sr));
    maxIn = 0.0f; maxOut = 0.0f;
    for (int i = 0; i < 4800; ++i) {
        const float inS = std::sin(2.0f * PI * 1000.0f * static_cast<float>(i) / 48000.0f);
        const float outS = bell.process(inS);
        if (i > 3800) {
            maxIn = std::max(maxIn, std::abs(inS));
            maxOut = std::max(maxOut, std::abs(outS));
        }
    }
    const float measuredCut = maxOut / maxIn;
    const bool cutOk = (std::abs(measuredCut - 0.5f) < 0.02f);
    std::cout << "    -6 dB Bell Gain @ fc: Measured Gain = " << measuredCut << " (Ideal: 0.500) "
              << (cutOk ? "[PASS]\n" : "[FAIL]\n");
    if (!cutOk) allPassed = false;

    // 5.3 LPC Vocal Tract Throat Length Modeling (50% .. 150%)
    std::cout << "\n[*] 5.3 LPC Physical Modeling Throat Length Conformal Warping:\n";
    LPCVocalTract<20> lpc;
    lpc.prepare(sr, 20);

    struct ThroatCase {
        float lengthPercent;
        float expectedLambda;
    };

    const std::vector<ThroatCase> throatCases = {
        { 100.0f,  0.00000f }, // Neutral: alpha = 1.0 -> lambda = 0.0
        {  50.0f,  0.33333f }, // Shortened tract (child/female): alpha = 0.5 -> lambda = (1-0.5)/(1+0.5) = +0.3333
        {  80.0f,  0.11111f }, // Mild short: alpha = 0.8 -> (1-0.8)/(1+0.8) = +0.1111
        { 125.0f, -0.11111f }, // Mild long: alpha = 1.25 -> (1-1.25)/(1+1.25) = -0.1111
        { 150.0f, -0.20000f }  // Deep cavernous: alpha = 1.5 -> (1-1.5)/(1+1.5) = -0.2000
    };

    for (const auto& tc : throatCases) {
        lpc.setThroatLength(tc.lengthPercent);
        const float lambda = lpc.getLambda();
        const float err = std::abs(lambda - tc.expectedLambda);
        const bool tcOk = (err < 0.001f);

        std::cout << "    Throat Length: " << std::setw(5) << tc.lengthPercent << "% | Lambda: "
                  << std::setw(8) << lambda << " (Expected: " << std::setw(8) << tc.expectedLambda << ") "
                  << (tcOk ? "[PASS]\n" : "[FAIL]\n");
        if (!tcOk) allPassed = false;
    }

    // 5.4 LPC Deconvolution and Closed-Form ZDF Resynthesis Stability
    std::cout << "\n[*] 5.4 LPC Deconvolution & Closed-Form ZDF Resynthesis Stability:\n";
    lpc.reset();
    lpc.setThroatLength(125.0f); // Longer tract

    // Generate synthetic voiced signal (220 Hz fundamental with formants)
    std::vector<float> voiceSynth(2048);
    for (size_t i = 0; i < voiceSynth.size(); ++i) {
        const float t = static_cast<float>(i) / 48000.0f;
        voiceSynth[i] = 0.5f * std::sin(2.0f * PI * 220.0f * t)
                      + 0.3f * std::sin(2.0f * PI * 660.0f * t)
                      + 0.15f * std::sin(2.0f * PI * 1750.0f * t);
    }

    lpc.analyzeBlock(voiceSynth.data(), voiceSynth.size(), true);

    bool resynthStable = true;
    for (size_t i = 0; i < voiceSynth.size(); ++i) {
        const float res = lpc.deconvolveSample(voiceSynth[i]);
        const float syn = lpc.synthesizeSample(res);
        if (!std::isfinite(syn) || std::abs(syn) > 5.0f) {
            resynthStable = false;
            break;
        }
    }
    std::cout << "    LPC Deconvolution + ZDF Allpass Ladder Resynthesis: "
              << (resynthStable ? "[PASS: Stable & Finite]\n" : "[FAIL: Unstable!]\n");
    if (!resynthStable) allPassed = false;

    return allPassed;
}

// =============================================================================
// AUDIT 6: Mid/Side Stereo Width (0%..200%) & 100% Mono Compatibility
// =============================================================================
bool auditStereoWidthAndMonoCompatibility() {
    printSection("6. Stereo Width Mid/Side (0%..200%) & 100% Mono Cancellation-Free Proof");
    const double sr = 48000.0;
    StereoWidthEnhancer swe;
    swe.prepare(sr);

    bool allPassed = true;

    // Generate rich mono lead vocal signal (harmonics + transients)
    const size_t numSamples = 4800;
    std::vector<float> monoVocal(numSamples);
    for (size_t i = 0; i < numSamples; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(sr);
        monoVocal[i] = 0.50f * std::sin(2.0f * PI * 220.0f * t)
                     + 0.25f * std::sin(2.0f * PI * 440.0f * t)
                     + 0.15f * std::sin(2.0f * PI * 1200.0f * t)
                     + 0.10f * std::sin(2.0f * PI * 3500.0f * t);
    }

    const std::vector<float> testWidths = { 0.0f, 50.0f, 100.0f, 140.0f, 180.0f, 200.0f };

    std::cout << std::left << std::setw(15) << "Width Setting"
              << std::setw(18) << "Max Mono Diff"
              << std::setw(18) << "Side Energy (dBFS)"
              << "Esito Mono-Compatibility\n";
    std::cout << "----------------------------------------------------------------------\n";

    for (float width : testWidths) {
        swe.setWidth(width);
        swe.reset(); // Snaps currentWidth = targetWidth immediately!

        // Pre-run to settle filter states
        for (int i = 0; i < 500; ++i) {
            float dummyL, dummyR;
            swe.processSample(0.5f, 0.5f, dummyL, dummyR);
        }

        float maxMonoDiff = 0.0f;
        double sumSideSq = 0.0;

        for (size_t i = 0; i < numSamples; ++i) {
            const float in = monoVocal[i];
            float outL = 0.0f, outR = 0.0f;
            swe.processSample(in, in, outL, outR);

            // Sum Mono: M = 0.5 * (outL + outR)
            const float monoSum = 0.5f * (outL + outR);
            const float diff = std::abs(monoSum - in);
            maxMonoDiff = std::max(maxMonoDiff, diff);

            // Side: S = 0.5 * (outL - outR)
            const float side = 0.5f * (outL - outR);
            sumSideSq += side * side;
        }

        const float sideRms = static_cast<float>(std::sqrt(sumSideSq / numSamples));
        const float sideDb = (sideRms > 1e-6f) ? (20.0f * std::log10(sideRms)) : -120.0f;

        // Zero cancellation test: maxMonoDiff must be machine epsilon (~ 1e-6 for float32)
        const bool monoSafe = (maxMonoDiff < 1.0e-5f);

        std::cout << std::left << std::setw(15) << (std::to_string(static_cast<int>(width)) + "%")
                  << std::setw(18) << maxMonoDiff
                  << std::setw(18) << (std::to_string(sideDb).substr(0, 6) + " dB")
                  << (monoSafe ? "[PASS: 100% Phase Intact]" : "[FAIL: Phase Distortion!]") << "\n";

        if (!monoSafe) allPassed = false;

        // For width 0%, side must be 0
        if (width == 0.0f && sideDb > -100.0f) {
            std::cout << "    FAIL: Width 0% has non-zero side energy!\n";
            allPassed = false;
        }
        // For width 200%, side should be active on mono signal (psychoacoustic decorrelator active)
        if (width == 200.0f && sideDb < -40.0f) {
            std::cout << "    FAIL: Width 200% failed to generate decorrelated spatial side!\n";
            allPassed = false;
        }
    }

    return allPassed;
}

// =============================================================================
// AUDIT 7: Gain Staging, Dynamic Safety & Limiter Protection
// =============================================================================
bool auditGainStagingAndSafetyLimiter() {
    printSection("7. Full Channel Gain Staging, Safety Limiter & NaN/Inf Protection");
    const double sr = 48000.0;
    const int blockSize = 512;

    bool allPassed = true;

    AudioPluginAudioProcessor processor;
    processor.prepareToPlay(sr, blockSize);
    processor.setCurrentProgram(0); // Travis Scott Classic 5 (Hard-Tune 0 ms)

    // 7.1 Neutral Gain Staging Test (Pass clean -6 dBFS sine)
    std::cout << "[*] 7.1 Neutral Gain Staging (Out Gain 0 dB, Mix 100%):\n";
    if (auto* mixP = processor.getAPVTS().getParameter("mix")) {
        mixP->setValueNotifyingHost(1.0f); // 100%
    }
    if (auto* gainP = processor.getAPVTS().getParameter("out_gain")) {
        gainP->setValueNotifyingHost(gainP->convertTo0to1(0.0f)); // 0 dB
    }

    juce::AudioBuffer<float> buffer(2, blockSize);
    juce::MidiBuffer midi;

    // Fill with 440 Hz sine at -6 dBFS (amplitude 0.501187)
    const float inputAmp = 0.501187f;
    for (int i = 0; i < blockSize; ++i) {
        const float s = inputAmp * std::sin(2.0f * PI * 440.0f * static_cast<float>(i) / 48000.0f);
        buffer.setSample(0, i, s);
        buffer.setSample(1, i, s);
    }

    // Process multiple blocks to allow pitch detector lock
    for (int b = 0; b < 20; ++b) {
        for (int i = 0; i < blockSize; ++i) {
            const float s = inputAmp * std::sin(2.0f * PI * 440.0f * static_cast<float>(b * blockSize + i) / 48000.0f);
            buffer.setSample(0, i, s);
            buffer.setSample(1, i, s);
        }
        processor.processBlock(buffer, midi);
    }

    const float outPeak = buffer.getMagnitude(0, 0, blockSize);
    const float outPeakDb = juce::Decibels::gainToDecibels(outPeak);
    std::cout << "    Input Peak: -6.00 dBFS | Output Peak: " << outPeakDb << " dBFS\n";
    const bool gainStagingOk = (std::abs(outPeakDb - (-6.0f)) < 1.0f);
    std::cout << "    Gain Unity Transparency: " << (gainStagingOk ? "[PASS]\n" : "[FAIL]\n");
    if (!gainStagingOk) allPassed = false;

    // 7.2 Output Gain Control (-6 dB and +6 dB)
    std::cout << "\n[*] 7.2 APVTS Output Gain Parameter Scaling (+6 dB and -6 dB):\n";
    if (auto* gainP = processor.getAPVTS().getParameter("out_gain")) {
        // -6 dB
        gainP->setValueNotifyingHost(gainP->convertTo0to1(-6.0f));
        for (int i = 0; i < blockSize; ++i) {
            const float s = 0.5f * std::sin(2.0f * PI * 440.0f * static_cast<float>(i) / 48000.0f);
            buffer.setSample(0, i, s);
            buffer.setSample(1, i, s);
        }
        processor.processBlock(buffer, midi);
        const float peakMinus6 = buffer.getMagnitude(0, 0, blockSize);
        const float peakMinus6Db = juce::Decibels::gainToDecibels(peakMinus6);

        // +6 dB
        gainP->setValueNotifyingHost(gainP->convertTo0to1(6.0f));
        for (int i = 0; i < blockSize; ++i) {
            const float s = 0.25f * std::sin(2.0f * PI * 440.0f * static_cast<float>(i) / 48000.0f);
            buffer.setSample(0, i, s);
            buffer.setSample(1, i, s);
        }
        processor.processBlock(buffer, midi);
        const float peakPlus6 = buffer.getMagnitude(0, 0, blockSize);
        const float peakPlus6Db = juce::Decibels::gainToDecibels(peakPlus6);

        std::cout << "    -6 dB Setting -> Measured Peak: " << peakMinus6Db << " dBFS (Expected ~ -12 dBFS)\n";
        std::cout << "    +6 dB Setting -> Measured Peak: " << peakPlus6Db << " dBFS (Expected ~ -6 dBFS)\n";

        const bool outGainParamOk = (peakMinus6Db < -10.0f) && (peakPlus6Db > -8.0f);
        std::cout << "    Output Gain Parameter Tracking: " << (outGainParamOk ? "[PASS]\n" : "[FAIL]\n");
        if (!outGainParamOk) allPassed = false;
        gainP->setValueNotifyingHost(gainP->convertTo0to1(0.0f)); // Reset
    }

    // 7.3 Pathological Signals (NaN, Inf, Extreme Peak Clipping Limiter)
    std::cout << "\n[*] 7.3 Pathological Signal Safety & Limiter Protection:\n";
    int nanCount = 0;
    int infCount = 0;
    float maxAbsSample = 0.0f;

    // Block with NaNs and Infs injected
    buffer.clear();
    buffer.setSample(0, 10, std::numeric_limits<float>::quiet_NaN());
    buffer.setSample(1, 10, std::numeric_limits<float>::infinity());
    buffer.setSample(0, 20, -std::numeric_limits<float>::infinity());
    buffer.setSample(1, 50, +500.0f); // Massive +500.0 peak
    buffer.setSample(0, 50, -500.0f); // Massive -500.0 peak

    processor.processBlock(buffer, midi);

    for (int ch = 0; ch < 2; ++ch) {
        for (int i = 0; i < blockSize; ++i) {
            const float s = buffer.getSample(ch, i);
            if (std::isnan(s)) nanCount++;
            if (std::isinf(s)) infCount++;
            maxAbsSample = std::max(maxAbsSample, std::abs(s));
        }
    }

    std::cout << "    NaN Count: " << nanCount << " | Inf Count: " << infCount
              << " | Max Output Sample: " << maxAbsSample << "\n";

    // Output must be clamped within [-2.0, +2.0] and contain 0 NaNs or Infs
    const bool safetyOk = (nanCount == 0) && (infCount == 0) && (maxAbsSample <= 2.0001f);
    std::cout << "    Limiter & Clamping Safety Ceiling Protection: "
              << (safetyOk ? "[PASS: 100% NaN/Inf Free, Ceiled <= 2.0]\n" : "[FAIL]\n");
    if (!safetyOk) allPassed = false;

    // 7.4 Neural Brain Telemetry & Softmax Normalization
    std::cout << "\n[*] 7.4 RealTune Neural Brain Probability Distributions:\n";
    // Feed one block of audio so brain executes inference
    buffer.clear();
    for (int i = 0; i < blockSize; ++i) {
        const float s = 0.5f * std::sin(2.0f * PI * 440.0f * static_cast<float>(i) / 48000.0f);
        buffer.setSample(0, i, s);
        buffer.setSample(1, i, s);
    }
    processor.processBlock(buffer, midi);

    const auto& brain = processor.getNeuralBrain();
    RealTuneBrainTelemetry snap = brain.getTelemetrySnapshot();

    float sumRootProb = 0.0f;
    for (float p : snap.rootKeyProbabilities) sumRootProb += p;
    float sumScaleProb = 0.0f;
    for (float p : snap.scaleTypeProbabilities) sumScaleProb += p;

    std::cout << "    Inference Count: " << snap.inferenceCount
              << " | Last Inference Time: " << snap.lastInferenceTimeUs << " us"
              << " | Sum Root Prob: " << sumRootProb
              << " | Sum Scale Prob: " << sumScaleProb << "\n";
    const bool brainOk = (snap.inferenceCount > 0) && (std::abs(sumRootProb - 1.0f) < 0.02f) && (std::abs(sumScaleProb - 1.0f) < 0.02f);
    std::cout << "    Neural Softmax Probability Invariance: " << (brainOk ? "[PASS]\n" : "[FAIL]\n");
    if (!brainOk) allPassed = false;

    return allPassed;
}

// =============================================================================
// MAIN ENTRY POINT
// =============================================================================
int main() {
    std::cout << "======================================================================\n";
    std::cout << "  171RealTune - COMPREHENSIVE CIRCUIT DYNAMICS AUDIT & CERTIFICATION   \n";
    std::cout << "  Vocal Tuning, Musical Scales, Retune Ballistics & Formant Inspector \n";
    std::cout << "======================================================================\n";

    bool allTestsPassed = true;

    try {
        if (!auditMusicalQuantizerAndScales())         allTestsPassed = false;
        if (!auditReferenceA4Precision())             allTestsPassed = false;
        if (!auditRetuneFilterBallistics())           allTestsPassed = false;
        if (!auditNaturalVibratoAndDeadbandTolerance()) allTestsPassed = false;
        if (!auditFormantShaperAndThroatLength())     allTestsPassed = false;
        if (!auditStereoWidthAndMonoCompatibility())   allTestsPassed = false;
        if (!auditGainStagingAndSafetyLimiter())        allTestsPassed = false;

        std::cout << "\n======================================================================\n";
        std::cout << " AUDIT SUMMARY:\n";
        std::cout << "======================================================================\n";
        if (allTestsPassed) {
            std::cout << " >>> ALL 7 CIRCUIT DYNAMICS AUDITS CERTIFIED WITH 100% SUCCESS! <<<\n";
            std::cout << " Zero NaNs, Zero Phase Inversions, Zero Comb-Filtering, Exact Ballistics.\n";
            std::cout << "======================================================================\n";
            return 0;
        } else {
            std::cout << " [!] ONE OR MORE AUDIT CRITERIA FAILED - CHECK DETAILED LOG ABOVE.\n";
            std::cout << "======================================================================\n";
            return 1;
        }
    } catch (const std::exception& e) {
        std::cerr << "\n[CRITICAL EXCEPTION] " << e.what() << "\n";
        return 2;
    }
}
