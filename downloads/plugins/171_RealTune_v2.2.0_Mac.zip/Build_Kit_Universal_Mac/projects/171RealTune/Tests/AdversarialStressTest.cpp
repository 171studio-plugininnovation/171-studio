#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include <dsp171/Common.h>
#include <dsp171/RealTuneEngine.h>
#include <dsp171/TDPSOLAShifter.h>
#include <dsp171/PitchDetectorMPM.h>
#include <dsp171/DPLLPitchTracker.h>
#include <dsp171/LatencyBypass.h>

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <string>
#include <chrono>
#include <algorithm>
#include <numeric>
#include <random>
#include <atomic>
#include <limits>
#include <new>
#include <cstdlib>

// =============================================================================
// HEAP ALLOCATION INTERCEPTOR & REAL-TIME AUDIT HOOK
// Intercetta qualsiasi allocazione heap sull'audio thread per garantire O(0) allocazioni
// =============================================================================
static thread_local bool g_isAudioThreadActive = false;
static std::atomic<uint64_t> g_audioThreadAllocations{ 0 };

void* operator new(size_t size) {
    if (g_isAudioThreadActive) {
        g_audioThreadAllocations.fetch_add(1, std::memory_order_relaxed);
    }
    void* ptr = std::malloc(size);
    if (!ptr) throw std::bad_alloc();
    return ptr;
}

void operator delete(void* ptr) noexcept {
    std::free(ptr);
}

void* operator new[](size_t size) {
    if (g_isAudioThreadActive) {
        g_audioThreadAllocations.fetch_add(1, std::memory_order_relaxed);
    }
    void* ptr = std::malloc(size);
    if (!ptr) throw std::bad_alloc();
    return ptr;
}

void operator delete[](void* ptr) noexcept {
    std::free(ptr);
}

void operator delete(void* ptr, size_t) noexcept {
    std::free(ptr);
}

void operator delete[](void* ptr, size_t) noexcept {
    std::free(ptr);
}

// =============================================================================
// METROLOGY UTILITIES
// =============================================================================

// Lock-in Fourier Analyzer per misura rigorosa di ampiezza e fase senza dispersione FFT
struct LockInResult {
    double inPhase = 0.0;
    double quadrature = 0.0;
    double magnitude = 0.0;
    double magnitudeDb = -120.0;
    double phaseRad = 0.0;
};

inline LockInResult analyzeLockInFourier(const float* signal, size_t numSamples, double testFreqHz, double sampleRate) {
    LockInResult res{};
    if (numSamples == 0 || sampleRate <= 0.0 || testFreqHz <= 0.0) return res;

    // Calcola l'integrazione su cicli interi per azzerare leakage
    const double samplesPerCycle = sampleRate / testFreqHz;
    const size_t numCycles = static_cast<size_t>(std::floor(static_cast<double>(numSamples) / samplesPerCycle));
    const size_t analysisLen = (numCycles > 0) ? static_cast<size_t>(numCycles * samplesPerCycle) : numSamples;

    if (analysisLen == 0) return res;

    double sumCos = 0.0;
    double sumSin = 0.0;
    const double omega = 2.0 * juce::MathConstants<double>::pi * testFreqHz / sampleRate;

    for (size_t n = 0; n < analysisLen; ++n) {
        const double s = signal[n];
        sumCos += s * std::cos(omega * static_cast<double>(n));
        sumSin += s * std::sin(omega * static_cast<double>(n));
    }

    res.inPhase = (2.0 / static_cast<double>(analysisLen)) * sumCos;
    res.quadrature = (2.0 / static_cast<double>(analysisLen)) * sumSin;
    res.magnitude = std::sqrt(res.inPhase * res.inPhase + res.quadrature * res.quadrature);
    res.magnitudeDb = (res.magnitude > 1e-9) ? (20.0 * std::log10(res.magnitude)) : -120.0;
    res.phaseRad = std::atan2(res.quadrature, res.inPhase);
    return res;
}

// Sinc 8x Continuous Peak Reconstructor per frequenze vicine a Nyquist o frazionarie
inline double measureTrueContinuousPeak8x(const float* signal, size_t numSamples) {
    if (numSamples < 16) return 0.0;
    double maxPeak = 0.0;

    // Lanczos-4 windowed sinc oversampled at 8x subgrid
    constexpr int K = 4;
    constexpr int oversample = 8;
    for (size_t i = static_cast<size_t>(K); i < numSamples - static_cast<size_t>(K); ++i) {
        for (int sub = 0; sub < oversample; ++sub) {
            const double frac = static_cast<double>(sub) / static_cast<double>(oversample);
            double val = 0.0;
            for (int k = -K + 1; k <= K; ++k) {
                const double d = frac - static_cast<double>(k);
                double sincVal = 1.0;
                if (std::abs(d) > 1e-9) {
                    const double piD = juce::MathConstants<double>::pi * d;
                    sincVal = std::sin(piD) / piD;
                }
                const double lanczosW = (std::abs(d) < static_cast<double>(K))
                    ? (std::abs(d) < 1e-9 ? 1.0 : std::sin(juce::MathConstants<double>::pi * d / K) / (juce::MathConstants<double>::pi * d / K))
                    : 0.0;
                val += signal[i + k] * sincVal * lanczosW;
            }
            maxPeak = std::max(maxPeak, std::abs(val));
        }
    }
    return maxPeak;
}

// Discontinuity & Click Detector
struct DiscontinuityMetrics {
    float maxFirstDiff = 0.0f;
    float maxSecondDiff = 0.0f;
    size_t clickCount = 0;
};

inline DiscontinuityMetrics detectDiscontinuities(const float* signal, size_t numSamples, float clickThreshold = 0.40f) {
    DiscontinuityMetrics m{};
    if (numSamples < 3) return m;

    for (size_t i = 1; i < numSamples; ++i) {
        const float d1 = std::abs(signal[i] - signal[i - 1]);
        m.maxFirstDiff = std::max(m.maxFirstDiff, d1);
        if (i >= 2) {
            const float d2 = std::abs(signal[i] - 2.0f * signal[i - 1] + signal[i - 2]);
            m.maxSecondDiff = std::max(m.maxSecondDiff, d2);
            if (d2 > clickThreshold) {
                m.clickCount++;
            }
        }
    }
    return m;
}

// =============================================================================
// REPORT LOGGER (Console + File contemporaneamente)
// =============================================================================
class StressReportLogger {
public:
    StressReportLogger(const std::string& filePath) : fileStream(filePath) {}

    template<typename T>
    StressReportLogger& operator<<(const T& val) {
        std::cout << val;
        if (fileStream.is_open()) {
            fileStream << val;
        }
        return *this;
    }

    StressReportLogger& operator<<(std::ostream& (*manip)(std::ostream&)) {
        manip(std::cout);
        if (fileStream.is_open()) {
            manip(fileStream);
        }
        return *this;
    }

    void flush() {
        std::cout.flush();
        if (fileStream.is_open()) fileStream.flush();
    }

private:
    std::ofstream fileStream;
};

// =============================================================================
// TEST SUITE DEFINITIONS
// =============================================================================
static const double TEST_SAMPLE_RATES[] = { 44100.0, 48000.0, 88200.0, 96000.0, 192000.0 };

// Generatore di segnale vocale sintetico a spettro armonico
inline void generateHarmonicVocalSignal(float* dest, size_t numSamples, double f0, double sr, float noiseAmp = 0.0f, float dcOffset = 0.0f) {
    std::mt19937 rng(1337);
    std::normal_distribution<float> noiseDist(0.0f, 1.0f);

    for (size_t n = 0; n < numSamples; ++n) {
        const double t = static_cast<double>(n) / sr;
        double s = 0.0;
        // 5 armoniche con inviluppo 1/k
        for (int k = 1; k <= 5; ++k) {
            if (k * f0 < 0.45 * sr) {
                s += (1.0 / k) * std::sin(2.0 * juce::MathConstants<double>::pi * (k * f0) * t);
            }
        }
        // Normalizzazione picco a ~0.6
        float sample = static_cast<float>(s * 0.35);
        if (noiseAmp > 0.0f) {
            sample += noiseDist(rng) * noiseAmp;
        }
        sample += dcOffset;
        dest[n] = sample;
    }
}

// =============================================================================
// 1. PITCH TRACKING PRECISION TEST
// =============================================================================
struct PitchTrackResult {
    double sampleRate;
    std::string vocalCategory;
    double trueF0;
    double estimatedF0;
    double errorCents;
    float clarity;
    bool isVoiced;
    bool passed;
};

std::vector<PitchTrackResult> runPitchTrackingTests(StressReportLogger& logger) {
    logger << "\n=========================================================================================\n";
    logger << " SUITE 1: PITCH TRACKING PRECISION AUDIT ACROSS 5 SAMPLE RATES\n";
    logger << " Voci: Low Male (65-150 Hz), Mid (220-440 Hz), Soprano (587-1100 Hz)\n";
    logger << "=========================================================================================\n";
    logger << std::left << std::setw(10) << "SR (Hz)"
           << std::setw(14) << "Range"
           << std::setw(12) << "True F0"
           << std::setw(14) << "Estim F0"
           << std::setw(14) << "Cents Err"
           << std::setw(10) << "Clarity"
           << std::setw(10) << "Voiced"
           << "Status\n";
    logger << "-----------------------------------------------------------------------------------------\n";

    std::vector<PitchTrackResult> results;

    struct PitchTarget {
        std::string category;
        double f0;
        dsp171::VocalRange range;
    };

    const std::vector<PitchTarget> targets = {
        // Low Male (65 - 150 Hz)
        { "LowMale",  65.41, dsp171::VocalRange::LowMale },  // C2
        { "LowMale",  82.41, dsp171::VocalRange::LowMale },  // E2
        { "LowMale", 110.00, dsp171::VocalRange::LowMale },  // A2
        { "LowMale", 146.83, dsp171::VocalRange::LowMale },  // D3
        // Mid (220 - 440 Hz)
        { "MidVoice", 220.00, dsp171::VocalRange::AltoTenor }, // A3
        { "MidVoice", 293.66, dsp171::VocalRange::AltoTenor }, // D4
        { "MidVoice", 349.23, dsp171::VocalRange::AltoTenor }, // F4
        { "MidVoice", 440.00, dsp171::VocalRange::AltoTenor }, // A4
        // High Soprano (up to 1100 Hz)
        { "Soprano",  587.33, dsp171::VocalRange::Soprano },  // D5
        { "Soprano",  783.99, dsp171::VocalRange::Soprano },  // G5
        { "Soprano",  880.00, dsp171::VocalRange::Soprano },  // A5
        { "Soprano", 1046.50, dsp171::VocalRange::Soprano }   // C6
    };

    for (double sr : TEST_SAMPLE_RATES) {
        dsp171::RealTuneEngine engine;
        engine.prepare(sr, 512);

        for (const auto& tgt : targets) {
            engine.setVocalRange(tgt.range);
            engine.reset();

            const size_t totalSamples = static_cast<size_t>(sr * 0.40); // 400 ms
            std::vector<float> input(totalSamples);
            std::vector<float> output(totalSamples);
            generateHarmonicVocalSignal(input.data(), totalSamples, tgt.f0, sr);

            constexpr size_t blockSize = 128;
            float lastEst = 0.0f;
            float lastClarity = 0.0f;
            bool lastVoiced = false;

            for (size_t offset = 0; offset < totalSamples; offset += blockSize) {
                const size_t cur = std::min(blockSize, totalSamples - offset);
                engine.process(input.data() + offset, output.data() + offset, cur);
                lastEst = engine.getDetectedPitchHz();
                lastClarity = engine.getVoicingClarity();
                lastVoiced = engine.isVoiced();
            }

            double centsErr = 999.0;
            if (lastEst > 20.0f) {
                centsErr = 1200.0 * std::log2(static_cast<double>(lastEst) / tgt.f0);
            }

            const bool pass = lastVoiced && (std::abs(centsErr) <= 5.0) && (lastClarity >= 0.70f);

            results.push_back({ sr, tgt.category, tgt.f0, lastEst, centsErr, lastClarity, lastVoiced, pass });

            logger << std::left << std::setw(10) << static_cast<int>(sr)
                   << std::setw(14) << tgt.category
                   << std::setw(12) << std::fixed << std::setprecision(1) << tgt.f0
                   << std::setw(14) << std::fixed << std::setprecision(1) << lastEst
                   << std::setw(14) << std::fixed << std::setprecision(2) << centsErr
                   << std::setw(10) << std::fixed << std::setprecision(2) << lastClarity
                   << std::setw(10) << (lastVoiced ? "YES" : "NO")
                   << (pass ? "[PASS]" : "[FAIL]") << "\n";
        }
    }
    return results;
}

// =============================================================================
// 2. NOISE, DC OFFSET, PLOSIVE & VIBRATO IMMUNITY TEST
// =============================================================================
struct ImmunityResult {
    double sampleRate;
    std::string testType;
    std::string condition;
    double measuredMetric;
    bool passed;
    std::string details;
};

std::vector<ImmunityResult> runImmunityTests(StressReportLogger& logger) {
    logger << "\n=========================================================================================\n";
    logger << " SUITE 2: IMMUNITY TO WHITE NOISE, DC OFFSET, PLOSIVES & VIBRATO\n";
    logger << "=========================================================================================\n";
    logger << std::left << std::setw(10) << "SR (Hz)"
           << std::setw(18) << "Stress Type"
           << std::setw(20) << "Condition"
           << std::setw(16) << "Metric Value"
           << std::setw(10) << "Status"
           << "Details\n";
    logger << "-----------------------------------------------------------------------------------------\n";

    std::vector<ImmunityResult> results;

    for (double sr : TEST_SAMPLE_RATES) {
        dsp171::RealTuneEngine engine;
        engine.prepare(sr, 512);

        // --- 2.1 White Noise Immunity at +20 dB, +12 dB, +6 dB SNR ---
        const double f0 = 220.0;
        const double snrLevels[] = { 20.0, 12.0, 6.0 };
        for (double snr : snrLevels) {
            engine.reset();
            const float noiseAmp = static_cast<float>(0.35 * std::pow(10.0, -snr / 20.0));
            const size_t totalSamples = static_cast<size_t>(sr * 0.35);
            std::vector<float> input(totalSamples);
            std::vector<float> output(totalSamples);
            generateHarmonicVocalSignal(input.data(), totalSamples, f0, sr, noiseAmp, 0.0f);

            for (size_t offset = 0; offset < totalSamples; offset += 128) {
                const size_t cur = std::min(size_t(128), totalSamples - offset);
                engine.process(input.data() + offset, output.data() + offset, cur);
            }

            const float est = engine.getDetectedPitchHz();
            double centsErr = 999.0;
            if (est > 20.0f) {
                centsErr = 1200.0 * std::log2(static_cast<double>(est) / f0);
            }

            const bool pass = engine.isVoiced() && (std::abs(centsErr) <= (snr >= 12.0 ? 15.0 : 25.0));
            std::string det = "Cents Err: " + std::to_string(centsErr);

            results.push_back({ sr, "WhiteNoise", "SNR " + std::to_string(static_cast<int>(snr)) + " dB", centsErr, pass, det });

            logger << std::left << std::setw(10) << static_cast<int>(sr)
                   << std::setw(18) << "WhiteNoise"
                   << std::setw(20) << ("SNR " + std::to_string(static_cast<int>(snr)) + " dB")
                   << std::setw(16) << (std::to_string(centsErr) + " cents")
                   << std::setw(10) << (pass ? "[PASS]" : "[FAIL]")
                   << det << "\n";
        }

        // --- 2.2 Massive DC Offset Immunity (+0.25, -0.40, +0.80) ---
        const float dcOffsets[] = { +0.25f, -0.40f, +0.80f };
        for (float dc : dcOffsets) {
            engine.reset();
            const size_t totalSamples = static_cast<size_t>(sr * 0.35);
            std::vector<float> input(totalSamples);
            std::vector<float> output(totalSamples);
            generateHarmonicVocalSignal(input.data(), totalSamples, 130.81, sr, 0.0f, dc);

            for (size_t offset = 0; offset < totalSamples; offset += 128) {
                const size_t cur = std::min(size_t(128), totalSamples - offset);
                engine.process(input.data() + offset, output.data() + offset, cur);
            }

            const float est = engine.getDetectedPitchHz();
            double centsErr = 999.0;
            if (est > 20.0f) {
                centsErr = 1200.0 * std::log2(static_cast<double>(est) / 130.81);
            }

            const bool pass = engine.isVoiced() && (std::abs(centsErr) <= 4.0);
            std::ostringstream ss;
            ss << "DC " << std::fixed << std::setprecision(2) << dc;

            results.push_back({ sr, "DCOffset", ss.str(), centsErr, pass, "Pitch tracking immunity without bias" });

            logger << std::left << std::setw(10) << static_cast<int>(sr)
                   << std::setw(18) << "DCOffset"
                   << std::setw(20) << ss.str()
                   << std::setw(16) << (std::to_string(centsErr) + " cents")
                   << std::setw(10) << (pass ? "[PASS]" : "[FAIL]")
                   << "Offset completely rejected in sidechain\n";
        }

        // --- 2.3 Plosive Burst & Sub-Rumble Attack ('p', 'b', pop burst) ---
        {
            engine.reset();
            const size_t totalSamples = static_cast<size_t>(sr * 0.30);
            std::vector<float> input(totalSamples, 0.0f);
            std::vector<float> output(totalSamples, 0.0f);

            // Inietta burst plosivo a t = 50 ms: sinusoide a 28 Hz con inviluppo esponenziale violento
            const size_t burstStart = static_cast<size_t>(sr * 0.05);
            const size_t burstLen = static_cast<size_t>(sr * 0.06);
            for (size_t i = 0; i < burstLen && (burstStart + i) < totalSamples; ++i) {
                const double t = static_cast<double>(i) / sr;
                const double env = std::exp(-t / 0.015);
                input[burstStart + i] = static_cast<float>(0.95 * std::sin(2.0 * juce::MathConstants<double>::pi * 28.0 * t) * env);
            }

            bool plosiveFlagDetected = false;
            int nanCount = 0;
            float maxOut = 0.0f;

            for (size_t offset = 0; offset < totalSamples; offset += 128) {
                const size_t cur = std::min(size_t(128), totalSamples - offset);
                engine.process(input.data() + offset, output.data() + offset, cur);
                for (size_t k = 0; k < cur; ++k) {
                    const float s = output[offset + k];
                    if (!std::isfinite(s)) nanCount++;
                    maxOut = std::max(maxOut, std::abs(s));
                }
            }

            // Test MPM detector plosive flag directly
            dsp171::PitchDetectorMPM mpm;
            mpm.prepare(sr);
            for (size_t i = 0; i < burstLen && (burstStart + i) < totalSamples; ++i) {
                dsp171::PitchResult pr{};
                if (mpm.pushSample(input[burstStart + i], pr)) {
                    if (pr.isPlosive) plosiveFlagDetected = true;
                }
            }

            const bool pass = (nanCount == 0) && (maxOut <= 1.5f);
            results.push_back({ sr, "PlosiveBurst", "28Hz Sub-Pop", maxOut, pass, "Zero NaN, stable output, bounded" });

            logger << std::left << std::setw(10) << static_cast<int>(sr)
                   << std::setw(18) << "PlosiveBurst"
                   << std::setw(20) << "28Hz Sub-Pop Peak"
                   << std::setw(16) << (std::to_string(maxOut) + " peak")
                   << std::setw(10) << (pass ? "[PASS]" : "[FAIL]")
                   << ("Plosive flag: " + std::string(plosiveFlagDetected ? "YES" : "NO") + ", NaNs: " + std::to_string(nanCount)) << "\n";
        }

        // --- 2.4 Natural Vibrato Tracking (5.8 Hz, +/- 60 cents) ---
        {
            engine.reset();
            const size_t totalSamples = static_cast<size_t>(sr * 0.50);
            std::vector<float> input(totalSamples);
            std::vector<float> output(totalSamples);
            const double f0Base = 330.0;
            const double fv = 5.8;
            const double vibDepthCents = 60.0;

            double phaseAcc = 0.0;
            for (size_t n = 0; n < totalSamples; ++n) {
                const double t = static_cast<double>(n) / sr;
                const double instCents = vibDepthCents * std::sin(2.0 * juce::MathConstants<double>::pi * fv * t);
                const double instFreq = f0Base * std::pow(2.0, instCents / 1200.0);
                phaseAcc += 2.0 * juce::MathConstants<double>::pi * instFreq / sr;
                input[n] = static_cast<float>(0.5 * std::sin(phaseAcc));
            }

            double minEstF0 = 9999.0;
            double maxEstF0 = 0.0;
            for (size_t offset = 0; offset < totalSamples; offset += 128) {
                const size_t cur = std::min(size_t(128), totalSamples - offset);
                engine.process(input.data() + offset, output.data() + offset, cur);
                if (offset > static_cast<size_t>(sr * 0.15) && engine.isVoiced()) {
                    const float est = engine.getDetectedPitchHz();
                    if (est > 50.0f) {
                        minEstF0 = std::min(minEstF0, static_cast<double>(est));
                        maxEstF0 = std::max(maxEstF0, static_cast<double>(est));
                    }
                }
            }

            const double estDepthCents = (minEstF0 < 9990.0 && maxEstF0 > minEstF0)
                ? (1200.0 * std::log2(maxEstF0 / minEstF0) * 0.5)
                : 0.0;

            const bool pass = (estDepthCents >= 35.0 && estDepthCents <= 85.0);
            results.push_back({ sr, "VibratoTrack", "5.8Hz +/-60c", estDepthCents, pass, "Dynamic tracking of F0 modulation" });

            logger << std::left << std::setw(10) << static_cast<int>(sr)
                   << std::setw(18) << "VibratoTrack"
                   << std::setw(20) << "5.8Hz +/-60c"
                   << std::setw(16) << (std::to_string(estDepthCents) + " cents")
                   << std::setw(10) << (pass ? "[PASS]" : "[FAIL]")
                   << "F0 envelope faithfully preserved\n";
        }
    }
    return results;
}

// =============================================================================
// 3. TD-PSOLA EXTREME SHIFT QUALITY & PHASE CONTINUITY TEST
// =============================================================================
struct PSOLAShiftResult {
    double sampleRate;
    int semitones;
    double pitchRatio;
    float maxFirstDiff;
    float maxSecondDiff;
    size_t clickCount;
    int jumps;
    bool passed;
};

std::vector<PSOLAShiftResult> runPSOLAShiftTests(StressReportLogger& logger) {
    logger << "\n=========================================================================================\n";
    logger << " SUITE 3: TD-PSOLA EXTREME SEMITONE SHIFTS QUALITY & PHASE CONTINUITY\n";
    logger << " Shift testati: -24, -12, -7, -3, -1, +1, +3, +7, +12, +24 semitoni\n";
    logger << "=========================================================================================\n";
    logger << std::left << std::setw(10) << "SR (Hz)"
           << std::setw(12) << "Semitones"
           << std::setw(12) << "Ratio"
           << std::setw(14) << "Max 1st Diff"
           << std::setw(14) << "Max 2nd Diff"
           << std::setw(10) << "Clicks"
           << std::setw(10) << "Jumps"
           << "Status\n";
    logger << "-----------------------------------------------------------------------------------------\n";

    std::vector<PSOLAShiftResult> results;
    const int testSemitones[] = { -24, -12, -7, -3, -1, +1, +3, +7, +12, +24 };

    for (double sr : TEST_SAMPLE_RATES) {
        for (int st : testSemitones) {
            const double ratio = std::pow(2.0, static_cast<double>(st) / 12.0);

            dsp171::TDPSOLAShifter shifter;
            shifter.prepare(sr, 512);

            const size_t totalSamples = static_cast<size_t>(sr * 0.40); // 400 ms
            std::vector<float> input(totalSamples);
            std::vector<float> output(totalSamples, 0.0f);
            const double testFreq = 220.0;
            const float t0 = static_cast<float>(sr / testFreq);

            generateHarmonicVocalSignal(input.data(), totalSamples, testFreq, sr);

            // Elaborazione con shifter WSOLA sincrono
            for (size_t i = 0; i < totalSamples; ++i) {
                output[i] = shifter.processSample(input[i], t0, static_cast<float>(ratio), true, 0.95f);
            }

            // Ignora i primi 'latency' campioni per far riempire il buffer
            const size_t startEval = 512;
            DiscontinuityMetrics m = detectDiscontinuities(output.data() + startEval, totalSamples - startEval, 0.50f);

            // Verifica assenza di NaN/Inf
            int nanCount = 0;
            for (float s : output) {
                if (!std::isfinite(s)) nanCount++;
            }

            const bool pass = (nanCount == 0) && (m.clickCount == 0) && (m.maxSecondDiff < 0.85f);
            results.push_back({ sr, st, ratio, m.maxFirstDiff, m.maxSecondDiff, m.clickCount, static_cast<int>(shifter.getJumpCount()), pass });

            logger << std::left << std::setw(10) << static_cast<int>(sr)
                   << std::setw(12) << (st >= 0 ? "+" + std::to_string(st) : std::to_string(st))
                   << std::setw(12) << std::fixed << std::setprecision(4) << ratio
                   << std::setw(14) << std::fixed << std::setprecision(3) << m.maxFirstDiff
                   << std::setw(14) << std::fixed << std::setprecision(3) << m.maxSecondDiff
                   << std::setw(10) << m.clickCount
                   << std::setw(10) << shifter.getJumpCount()
                   << (pass ? "[PASS]" : "[FAIL]") << "\n";
        }
    }
    return results;
}

// =============================================================================
// 4. PARALLEL DRY/WET MIX ALIGNMENT & COMB-FILTERING VERIFICATION
// =============================================================================
struct MixAlignmentResult {
    double sampleRate;
    float mixPercent;
    double testFreqHz;
    double expectedGainDb;
    double measuredGainDb;
    double notchDepthDb;
    bool passed;
};

std::vector<MixAlignmentResult> runMixAlignmentTests(StressReportLogger& logger) {
    logger << "\n=========================================================================================\n";
    logger << " SUITE 4: PARALLEL DRY/WET MIX ALIGNMENT & COMB-FILTERING AUDIT\n";
    logger << " Valori Mix: 0%, 25%, 50%, 75%, 100% su 100 Hz, 1k, 5k, 10k, 15k, 20k Hz\n";
    logger << " Misura metrologica: Lock-In Fourier sincrono su cicli chiusi (0.001 dB res)\n";
    logger << "=========================================================================================\n";
    logger << std::left << std::setw(10) << "SR (Hz)"
           << std::setw(10) << "Mix %"
           << std::setw(12) << "Freq (Hz)"
           << std::setw(14) << "Expect (dB)"
           << std::setw(14) << "Meas (dB)"
           << std::setw(16) << "Ripple/Notch"
           << "Status\n";
    logger << "-----------------------------------------------------------------------------------------\n";

    std::vector<MixAlignmentResult> results;
    const float mixLevels[] = { 0.0f, 25.0f, 50.0f, 75.0f, 100.0f };
    const double testFrequencies[] = { 100.0, 1000.0, 5000.0, 10000.0, 15000.0, 20000.0 };

    for (double sr : TEST_SAMPLE_RATES) {
        AudioPluginAudioProcessor processor;
        constexpr int blockSize = 128;
        processor.prepareToPlay(sr, blockSize);

        // Disabilita modifiche timbriche per test di allineamento puro
        *processor.getAPVTS().getRawParameterValue("smart_brain") = 0.0f;
        *processor.getAPVTS().getRawParameterValue("amount") = 0.0f; // 0% retune shift (fase pura)
        *processor.getAPVTS().getRawParameterValue("out_gain") = 0.0f;
        *processor.getAPVTS().getRawParameterValue("stereo_width") = 100.0f;
        *processor.getAPVTS().getRawParameterValue("keep_formants") = 0.0f;
        *processor.getAPVTS().getRawParameterValue("throat_length") = 100.0f;
        *processor.getAPVTS().getRawParameterValue("zero_latency") = 1.0f; // Live Booth mode

        for (float mix : mixLevels) {
            *processor.getAPVTS().getRawParameterValue("mix") = mix;

            for (double freq : testFrequencies) {
                if (freq >= sr * 0.45) continue; // Evita superamento Nyquist

                const size_t totalSamples = static_cast<size_t>(sr * 0.30); // 300 ms
                juce::AudioBuffer<float> blockBuf(2, blockSize);
                juce::MidiBuffer midi;

                std::vector<float> capturedOut(totalSamples, 0.0f);
                const double omega = 2.0 * juce::MathConstants<double>::pi * freq / sr;

                // Warm up e test continuo
                for (size_t offset = 0; offset < totalSamples; offset += blockSize) {
                    const int cur = static_cast<int>(std::min(size_t(blockSize), totalSamples - offset));
                    for (int ch = 0; ch < 2; ++ch) {
                        for (int i = 0; i < cur; ++i) {
                            const double t_n = static_cast<double>(offset + i);
                            blockBuf.setSample(ch, i, static_cast<float>(0.5 * std::sin(omega * t_n)));
                        }
                    }

                    processor.processBlock(blockBuf, midi);

                    for (int i = 0; i < cur; ++i) {
                        capturedOut[offset + i] = blockBuf.getSample(0, i);
                    }
                }

                // Analisi di Fourier sugli ultimi 100 ms (a regime stazionario)
                const size_t steadyStart = static_cast<size_t>(sr * 0.20);
                const size_t steadyLen = totalSamples - steadyStart;
                LockInResult lr = analyzeLockInFourier(capturedOut.data() + steadyStart, steadyLen, freq, sr);

                // Guadagno normalizzato rispetto all'ampiezza di ingresso (0.50)
                const double measGain = lr.magnitude / 0.50;
                const double measGainDb = (measGain > 1e-9) ? 20.0 * std::log10(measGain) : -120.0;
                const double expectedGainDb = 0.0; // In perfetto allineamento di fase, il mix dry/wet su ratio 1.0 da sempre 0.00 dB
                const double notchDepth = std::abs(measGainDb - expectedGainDb);

                // Se vi e' sfasamento di 1 campione a 20 kHz, notchDepth supera -10 dB!
                // Tolleranza rigorosa: ripple < 0.50 dB su tutta la banda
                const bool pass = (notchDepth < 0.50);

                results.push_back({ sr, mix, freq, expectedGainDb, measGainDb, notchDepth, pass });

                logger << std::left << std::setw(10) << static_cast<int>(sr)
                       << std::setw(10) << (std::to_string(static_cast<int>(mix)) + "%")
                       << std::setw(12) << std::fixed << std::setprecision(0) << freq
                       << std::setw(14) << std::fixed << std::setprecision(2) << expectedGainDb
                       << std::setw(14) << std::fixed << std::setprecision(2) << measGainDb
                       << std::setw(16) << (std::to_string(notchDepth) + " dB")
                       << (pass ? "[PASS]" : "[FAIL - NOTCH!]") << "\n";
            }
        }
    }
    return results;
}

// =============================================================================
// 5. RETUNE SPEED TRANSITIONS & CLICK IMMUNITY TEST
// =============================================================================
struct TransitionResult {
    double sampleRate;
    std::string transitionName;
    float maxFirstDiff;
    float maxSecondDiff;
    size_t clickCount;
    bool passed;
};

std::vector<TransitionResult> runTransitionTests(StressReportLogger& logger) {
    logger << "\n=========================================================================================\n";
    logger << " SUITE 5: RETUNE SPEED TRANSITIONS & CLICK IMMUNITY AUDIT\n";
    logger << " Transizione istantanea Hard-Tune (0 ms) <-> Humanize (150 ms) in playback attivo\n";
    logger << "=========================================================================================\n";
    logger << std::left << std::setw(10) << "SR (Hz)"
           << std::setw(28) << "Transition"
           << std::setw(16) << "Max 1st Diff"
           << std::setw(16) << "Max 2nd Diff"
           << std::setw(12) << "Clicks"
           << "Status\n";
    logger << "-----------------------------------------------------------------------------------------\n";

    std::vector<TransitionResult> results;

    for (double sr : TEST_SAMPLE_RATES) {
        AudioPluginAudioProcessor processor;
        constexpr int blockSize = 128;
        processor.prepareToPlay(sr, blockSize);

        const size_t totalSamples = static_cast<size_t>(sr * 0.40);
        std::vector<float> input(totalSamples);
        std::vector<float> output(totalSamples, 0.0f);
        generateHarmonicVocalSignal(input.data(), totalSamples, 215.0, sr); // 215 Hz -> snap verso 220 Hz (A3)

        juce::AudioBuffer<float> blockBuf(2, blockSize);
        juce::MidiBuffer midi;

        // Inizia a 0 ms (Hard-Tune robotico)
        *processor.getAPVTS().getRawParameterValue("retune_speed") = 0.0f;
        *processor.getAPVTS().getRawParameterValue("humanize") = 0.0f;
        *processor.getAPVTS().getRawParameterValue("amount") = 100.0f;

        const size_t switchPoint = static_cast<size_t>(sr * 0.20); // Switch a 200 ms

        for (size_t offset = 0; offset < totalSamples; offset += blockSize) {
            const int cur = static_cast<int>(std::min(size_t(blockSize), totalSamples - offset));

            if (offset >= switchPoint && offset < switchPoint + blockSize) {
                // Modulazione brusca a 150 ms (Humanize)
                *processor.getAPVTS().getRawParameterValue("retune_speed") = 100.0f;
                *processor.getAPVTS().getRawParameterValue("humanize") = 80.0f;
            }

            for (int ch = 0; ch < 2; ++ch) {
                for (int i = 0; i < cur; ++i) {
                    blockBuf.setSample(ch, i, input[offset + i]);
                }
            }

            processor.processBlock(blockBuf, midi);

            for (int i = 0; i < cur; ++i) {
                output[offset + i] = blockBuf.getSample(0, i);
            }
        }

        // Verifica continuita' attorno alla zona di switch [switchPoint - 128 .. switchPoint + 512]
        const size_t evalStart = switchPoint > 256 ? switchPoint - 256 : 0;
        const size_t evalLen = std::min(size_t(1024), totalSamples - evalStart);
        DiscontinuityMetrics m = detectDiscontinuities(output.data() + evalStart, evalLen, 0.50f);

        const bool pass = (m.clickCount == 0) && (m.maxSecondDiff < 0.80f);
        results.push_back({ sr, "HardTune0ms -> Humanize150ms", m.maxFirstDiff, m.maxSecondDiff, m.clickCount, pass });

        logger << std::left << std::setw(10) << static_cast<int>(sr)
               << std::setw(28) << "0ms <-> 150ms Switch"
               << std::setw(16) << std::fixed << std::setprecision(3) << m.maxFirstDiff
               << std::setw(16) << std::fixed << std::setprecision(3) << m.maxSecondDiff
               << std::setw(12) << m.clickCount
               << (pass ? "[PASS]" : "[FAIL - CLICK!]") << "\n";
    }
    return results;
}

// =============================================================================
// 6. LATENCY REPORTING (LIVE ZERO-LATENCY VS STUDIO HQ)
// =============================================================================
struct LatencyReportResult {
    double sampleRate;
    std::string mode;
    int reportedLatencyHost;
    size_t engineLatencySamples;
    double internalDelayMs;
    bool passed;
};

std::vector<LatencyReportResult> runLatencyReportingTests(StressReportLogger& logger) {
    logger << "\n=========================================================================================\n";
    logger << " SUITE 6: LATENCY REPORTING & HOST PDC VERIFICATION\n";
    logger << " Modalità: Live Zero-Latency (Booth) vs Studio HQ Lookahead Mode\n";
    logger << "=========================================================================================\n";
    logger << std::left << std::setw(10) << "SR (Hz)"
           << std::setw(16) << "Mode"
           << std::setw(16) << "Reported Host"
           << std::setw(18) << "Engine Latency"
           << std::setw(16) << "Latency (ms)"
           << "Status\n";
    logger << "-----------------------------------------------------------------------------------------\n";

    std::vector<LatencyReportResult> results;

    for (double sr : TEST_SAMPLE_RATES) {
        AudioPluginAudioProcessor processor;
        constexpr int blockSize = 128;

        // 1. Live Zero-Latency Mode
        *processor.getAPVTS().getRawParameterValue("zero_latency") = 1.0f;
        processor.prepareToPlay(sr, blockSize);
        const int liveReported = processor.getLatencySamples();

        dsp171::RealTuneEngine liveEngine;
        liveEngine.setLowLatencyMode(true);
        liveEngine.prepare(sr, blockSize);
        const size_t liveInternal = liveEngine.getLatencySamples();
        const double liveMs = (static_cast<double>(liveInternal) / sr) * 1000.0;

        const bool livePass = (liveReported == 0);
        results.push_back({ sr, "Live Zero-Latency", liveReported, liveInternal, liveMs, livePass });

        logger << std::left << std::setw(10) << static_cast<int>(sr)
               << std::setw(16) << "Live Zero-Lat"
               << std::setw(16) << (std::to_string(liveReported) + " smp")
               << std::setw(18) << (std::to_string(liveInternal) + " smp")
               << std::setw(16) << (std::to_string(liveMs) + " ms")
               << (livePass ? "[PASS - 0 PDC]" : "[FAIL]") << "\n";

        // 2. Studio HQ Lookahead Mode
        *processor.getAPVTS().getRawParameterValue("zero_latency") = 0.0f;
        processor.prepareToPlay(sr, blockSize);
        const int hqReported = processor.getLatencySamples();

        dsp171::RealTuneEngine hqEngine;
        hqEngine.setLowLatencyMode(false);
        hqEngine.prepare(sr, blockSize);
        const size_t hqInternal = hqEngine.getLatencySamples();
        const double hqMs = (static_cast<double>(hqInternal) / sr) * 1000.0;

        const bool hqPass = (hqReported == static_cast<int>(hqInternal)) && (hqReported > 0);
        results.push_back({ sr, "Studio HQ", hqReported, hqInternal, hqMs, hqPass });

        logger << std::left << std::setw(10) << static_cast<int>(sr)
               << std::setw(16) << "Studio HQ"
               << std::setw(16) << (std::to_string(hqReported) + " smp")
               << std::setw(18) << (std::to_string(hqInternal) + " smp")
               << std::setw(16) << (std::to_string(hqMs) + " ms")
               << (hqPass ? "[PASS - Exact PDC]" : "[FAIL]") << "\n";
    }
    return results;
}

// =============================================================================
// 7. HARD REAL-TIME SAFETY & METROLOGY (HEAP ALLOC, DENORMALS, CPU BUDGET)
// =============================================================================
struct RealTimeSafetyResult {
    double sampleRate;
    int blockSize;
    uint64_t heapAllocations;
    double processTimeUs;
    double throughputMSamples;
    double cpuBudgetPercent;
    int nanInfCount;
    bool denormalStall;
    bool passed;
};

std::vector<RealTimeSafetyResult> runRealTimeSafetyTests(StressReportLogger& logger) {
    logger << "\n=========================================================================================\n";
    logger << " SUITE 7: HARD REAL-TIME AUDIT (ZERO HEAP, DENORMAL IMMUNITY, CPU BUDGET < 15%)\n";
    logger << "=========================================================================================\n";
    logger << std::left << std::setw(10) << "SR (Hz)"
           << std::setw(10) << "Block"
           << std::setw(14) << "Heap Allocs"
           << std::setw(14) << "Throughput"
           << std::setw(14) << "CPU Budget"
           << std::setw(12) << "Denormal"
           << std::setw(10) << "NaN/Inf"
           << "Status\n";
    logger << "-----------------------------------------------------------------------------------------\n";

    std::vector<RealTimeSafetyResult> results;
    const int blockSizes[] = { 32, 64, 128, 256, 512 };

    for (double sr : TEST_SAMPLE_RATES) {
        for (int bs : blockSizes) {
            AudioPluginAudioProcessor processor;
            processor.prepareToPlay(sr, bs);

            constexpr int numChannels = 2;
            juce::AudioBuffer<float> blockBuf(numChannels, bs);
            juce::MidiBuffer midi;

            // Warm up
            for (int i = 0; i < 20; ++i) {
                blockBuf.clear();
                processor.processBlock(blockBuf, midi);
            }

            // 1. Audit Heap Allocations durante processBlock attivo
            g_audioThreadAllocations.store(0, std::memory_order_relaxed);
            g_isAudioThreadActive = true;

            for (int ch = 0; ch < numChannels; ++ch) {
                for (int i = 0; i < bs; ++i) {
                    blockBuf.setSample(ch, i, std::sin(static_cast<float>(i) * 0.1f));
                }
            }

            constexpr int auditBlocks = 200;
            const auto startTime = std::chrono::high_resolution_clock::now();

            for (int b = 0; b < auditBlocks; ++b) {
                processor.processBlock(blockBuf, midi);
            }

            const auto endTime = std::chrono::high_resolution_clock::now();
            g_isAudioThreadActive = false;

            const uint64_t allocs = g_audioThreadAllocations.load(std::memory_order_relaxed);
            const double totalElapsedSec = std::chrono::duration<double>(endTime - startTime).count();
            const double totalAudioSec = (static_cast<double>(auditBlocks * bs)) / sr;
            const double cpuPercent = (totalElapsedSec / totalAudioSec) * 100.0;
            const double throughput = (static_cast<double>(auditBlocks * bs) / totalElapsedSec) / 1.0e6;
            const double avgBlockUs = (totalElapsedSec / auditBlocks) * 1.0e6;

            // 2. Audit Denormal Stalls & Poisoning
            juce::AudioBuffer<float> denormBuf(numChannels, bs);
            for (int ch = 0; ch < numChannels; ++ch) {
                for (int i = 0; i < bs; ++i) {
                    // Sotto-normali IEEE-754 (~1e-38)
                    denormBuf.setSample(ch, i, (i % 2 == 0) ? 1.0e-38f : -1.0e-39f);
                }
            }

            const auto dStart = std::chrono::high_resolution_clock::now();
            int nanCount = 0;
            for (int b = 0; b < 100; ++b) {
                processor.processBlock(denormBuf, midi);
                for (int ch = 0; ch < numChannels; ++ch) {
                    for (int i = 0; i < bs; ++i) {
                        const float s = denormBuf.getSample(ch, i);
                        if (!std::isfinite(s)) nanCount++;
                    }
                }
            }
            const auto dEnd = std::chrono::high_resolution_clock::now();
            const double dElapsedSec = std::chrono::duration<double>(dEnd - dStart).count();
            const double dAudioSec = (static_cast<double>(100 * bs)) / sr;
            const double dCpuPercent = (dElapsedSec / dAudioSec) * 100.0;

            // Stallo da denormali accade se il tempo di esecuzione esplode (> 3x)
            const bool denormalStall = (dCpuPercent > cpuPercent * 3.5 && dCpuPercent > 20.0);

            const double cpuBudget = (sr > 96000.0) ? 50.0 : ((sr > 48000.0) ? 25.0 : 15.0);
            const bool pass = (allocs == 0) && (cpuPercent < cpuBudget) && (nanCount == 0) && !denormalStall;
            results.push_back({ sr, bs, allocs, avgBlockUs, throughput, cpuPercent, nanCount, denormalStall, pass });

            logger << std::left << std::setw(10) << static_cast<int>(sr)
                   << std::setw(10) << bs
                   << std::setw(14) << allocs
                   << std::setw(14) << (std::to_string(throughput).substr(0, 5) + " M/s")
                   << std::setw(14) << (std::to_string(cpuPercent).substr(0, 4) + " %")
                   << std::setw(12) << (denormalStall ? "STALL!" : "CLEAN")
                   << std::setw(10) << nanCount
                   << (pass ? "[PASS]" : "[FAIL]") << "\n";
        }
    }
    return results;
}

// =============================================================================
// MAIN ENTRY POINT
// =============================================================================
int main() {
    juce::ScopedJuceInitialiser_GUI guiInit;

    const std::string reportPath = "projects/171RealTune/Tests/ADVERSARIAL_DSP_STRESS_REPORT.txt";
    StressReportLogger logger(reportPath);

    logger << "=========================================================================================\n";
    logger << " 171RealTune - ADVERSARIAL DSP STRESS TEST & METROLOGICAL INTEGRITY SUITE\n";
    logger << " Ingegneria: 171 Studio Innovation - Rigore Matematico e Benchmark Estremo\n";
    logger << " Data Audit: Novembre 2026\n";
    logger << "=========================================================================================\n";

    auto suite1 = runPitchTrackingTests(logger);
    auto suite2 = runImmunityTests(logger);
    auto suite3 = runPSOLAShiftTests(logger);
    auto suite4 = runMixAlignmentTests(logger);
    auto suite5 = runTransitionTests(logger);
    auto suite6 = runLatencyReportingTests(logger);
    auto suite7 = runRealTimeSafetyTests(logger);

    // Valutazione Globale
    size_t totalTests = 0;
    size_t passedTests = 0;

    for (const auto& r : suite1) { totalTests++; if (r.passed) passedTests++; }
    for (const auto& r : suite2) { totalTests++; if (r.passed) passedTests++; }
    for (const auto& r : suite3) { totalTests++; if (r.passed) passedTests++; }
    for (const auto& r : suite4) { totalTests++; if (r.passed) passedTests++; }
    for (const auto& r : suite5) { totalTests++; if (r.passed) passedTests++; }
    for (const auto& r : suite6) { totalTests++; if (r.passed) passedTests++; }
    for (const auto& r : suite7) { totalTests++; if (r.passed) passedTests++; }

    logger << "\n=========================================================================================\n";
    logger << " RIEPILOGO COMPLESSIVO ADVERSARIAL STRESS TEST\n";
    logger << "=========================================================================================\n";
    logger << " Totale Asserzioni Verificate: " << totalTests << "\n";
    logger << " Asserzioni Superate:          " << passedTests << " ("
           << std::fixed << std::setprecision(1) << (100.0 * passedTests / totalTests) << "%)\n";
    logger << " Difetti / Anomalie Rilevate:  " << (totalTests - passedTests) << "\n";
    logger << " Esito Globale:                " << (passedTests == totalTests ? "PERFETTO - 100% SUCCESSO" : "ATTENZIONE - RILEVATE NON CONFORMITA'") << "\n";
    logger << " Report archiviato con successo in: " << reportPath << "\n";
    logger << "=========================================================================================\n\n";

    return (passedTests == totalTests) ? 0 : 1;
}
