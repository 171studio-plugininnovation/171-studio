#pragma once

#include <cmath>
#include <algorithm>
#include <cstdint>
#include "Common.h"
#include "FastMath.h"
#include "ZDFSVF.h"

namespace dsp171 {

// =============================================================================
// VOCAL NOISE EXPANDER & GATE (Schmitt-Trigger Hysteresis & Anti-Chatter)
//
// Specialized Hard Real-Time C++20 Vocal Downward Expander & Gate.
// Solves vocal chain noise floor elevation, room ambience and headphone spill
// with ZERO transient truncation on initial consonants and ZERO tail chattering.
//
// Key Specifications:
// - Instant-Peak Rising Edge Detector (alpha = 1.0): 0 ms attack latency.
// - High-Pass Sidechain Filter (80 Hz 2-pole ZDF SVF): passes all vocal formants & consonants.
// - Smooth Continuous Downward Expander with Soft Knee (4 dB): transparent decay on tails.
// - True Schmitt-Trigger State Machine with 5 dB Hysteresis and 100 ms Hold.
// - Pre-Open Reset State: guarantees sample 0 of the track is 100% unmuted.
// =============================================================================

class VocalNoiseExpander {
public:
    enum class Mode : uint8_t {
        DownwardExpander = 0,
        HardGate
    };

    enum class ListenMode : uint8_t {
        Audio = 0,
        Sidechain,
        Delta
    };

    VocalNoiseExpander() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        fs = (sampleRate > 1000.0) ? sampleRate : 48000.0;
        invFs = 1.0 / fs;
        reset();
        updateFilterCoeffs();
        updateTimeConstants();
    }

    void reset() noexcept {
        detectorEnvL = 0.0f;
        detectorEnvR = 0.0f;
        gainEnvL = 1.0f;
        gainEnvR = 1.0f;
        currentGRL = 0.0f;
        currentGRR = 0.0f;
        holdCounterL = holdSamplesTarget;
        holdCounterR = holdSamplesTarget;

        // Inizializza lo stato come OPEN per garantire che il primo campione
        // all'inizio della traccia audio non venga mai troncato o mangiato!
        gateStateL = State::Open;
        gateStateR = State::Open;

        // Grace period (600 ms): alla partenza del playback/reset il gate
        // rimane 100% aperto e trasparente, impedendo qualsiasi troncamento
        // delle consonanti iniziali o del respiro d'attacco.
        graceSamplesL = static_cast<int>(0.02 * fs);
        graceSamplesR = static_cast<int>(0.02 * fs);

        scSVF_L.reset();
        scSVF_R.reset();
    }

    // --- Parameter Setters ---

    // Threshold in dBFS (-80.0 dB to 0.0 dB)
    void setThreshold(float threshDb) noexcept {
        thresholdDb = std::clamp(threshDb, -80.0f, 0.0f);
        updateThresholds();
    }

    // Hysteresis in dB (1.0 dB to 15.0 dB)
    void setHysteresis(float hystDb) noexcept {
        hysteresisDb = std::clamp(hystDb, 1.0f, 15.0f);
        updateThresholds();
    }

    // Range in dB (-80.0 dB to -3.0 dB) - maximum attenuation applied
    void setRange(float rangeDb) noexcept {
        rangeDbValue = std::clamp(rangeDb, -80.0f, -3.0f);
        floorLinear = std::pow(10.0f, rangeDbValue * 0.05f);
    }

    // Expansion Ratio (1.1:1 to 8.0:1)
    void setRatio(float r) noexcept {
        ratio = std::clamp(r, 1.1f, 8.0f);
    }

    // Attack time in milliseconds (0.05 ms to 20.0 ms)
    void setAttackMs(float ms) noexcept {
        attackMs = std::clamp(ms, 0.05f, 20.0f);
        updateTimeConstants();
    }

    // Hold time in milliseconds (10.0 ms to 500.0 ms)
    void setHoldMs(float ms) noexcept {
        holdMs = std::clamp(ms, 10.0f, 500.0f);
        updateTimeConstants();
    }

    // Release time in milliseconds (20.0 ms to 1500.0 ms)
    void setReleaseMs(float ms) noexcept {
        releaseMs = std::clamp(ms, 20.0f, 1500.0f);
        updateTimeConstants();
    }

    // Sidechain High-Pass Cutoff (40 Hz to 250 Hz)
    void setSidechainFilter(float lowCutHz, float highCutHz = 16000.0f) noexcept {
        (void)highCutHz;
        scLowCut = std::clamp(lowCutHz, 40.0f, 250.0f);
        updateFilterCoeffs();
    }

    void setMode(Mode m) noexcept { mode = m; }
    void setListenMode(ListenMode l) noexcept { listenMode = l; }

    // Telemetry
    [[nodiscard]] float getGainReductionL() const noexcept { return currentGRL; }
    [[nodiscard]] float getGainReductionR() const noexcept { return currentGRR; }

    // --- Audio Processing Block ---
    void process(float* const* channelData, int numChannels, int numSamples) noexcept {
        if (numChannels <= 0 || numSamples <= 0) return;

        float* left = channelData[0];
        float* right = (numChannels > 1) ? channelData[1] : nullptr;

        for (int i = 0; i < numSamples; ++i) {
            const float inL = std::isfinite(left[i]) ? left[i] : 0.0f;
            const float inR = right ? (std::isfinite(right[i]) ? right[i] : 0.0f) : inL;

            // 1. Sidechain Filtering (High-Pass 80 Hz per rimuovere sub-rumble preservando consonanti)
            const float scL = processSidechainFilterL(inL);
            const float scR = right ? processSidechainFilterR(inR) : scL;

            // 2. State-Machine & Envelope Following
            const float targetGainL = computeTargetGain(scL, detectorEnvL, gateStateL, holdCounterL, graceSamplesL);
            const float targetGainR = right ? computeTargetGain(scR, detectorEnvR, gateStateR, holdCounterR, graceSamplesR) : targetGainL;

            // 3. Smooth Gain Envelope Interpolation (Ultra-fast attack, smooth natural release)
            const float gainL = smoothGain(targetGainL, gainEnvL, gateStateL);
            const float gainR = right ? smoothGain(targetGainR, gainEnvR, gateStateR) : gainL;

            // Record telemetry (in dB)
            currentGRL = (gainL > 1e-5f) ? -20.0f * std::log10(gainL) : -rangeDbValue;
            currentGRR = (gainR > 1e-5f) ? -20.0f * std::log10(gainR) : -rangeDbValue;

            // 4. Output Generation based on Listen Mode
            const float outL = inL * gainL;
            const float outR = inR * gainR;

            switch (listenMode) {
                case ListenMode::Sidechain:
                    left[i] = scL;
                    if (right) right[i] = scR;
                    break;

                case ListenMode::Delta:
                    left[i] = inL - outL;
                    if (right) right[i] = inR - outR;
                    break;

                case ListenMode::Audio:
                default:
                    left[i] = outL;
                    if (right) right[i] = outR;
                    break;
            }
        }
    }

private:
    enum class State : uint8_t {
        Open = 0,
        Hold,
        Release,
        Closed
    };

    double fs = 48000.0;
    double invFs = 1.0 / 48000.0;

    float thresholdDb = -54.0f;
    float hysteresisDb = 8.0f;
    float threshOpenLinear = 0.001995f;   // -54 dBFS
    float threshCloseLinear = 0.000794f;  // -62 dBFS

    float rangeDbValue = -24.0f;
    float floorLinear = 0.0631f; // -24 dB
    float ratio = 3.5f;

    float attackMs = 0.05f;    // 50 us attack ultra-rapido (nessun taglio di consonanti)
    float holdMs = 50.0f;      // 50 ms hold anti-chatter per code vocali e riverberi
    float releaseMs = 120.0f;  // 450 ms rilascio organico musicale vocale

    float attackCoeff = 0.95f;
    float releaseCoeff = 0.999f;
    float detectorDecayCoeff = 0.00416f;
    int holdSamplesTarget = 12000;

    float scLowCut = 80.0f;

    Mode mode = Mode::DownwardExpander; // Default vocale trasparente: Downward Expander
    ListenMode listenMode = ListenMode::Audio;

    // Runtime state
    float detectorEnvL = 0.0f;
    float detectorEnvR = 0.0f;
    float gainEnvL = 1.0f;
    float gainEnvR = 1.0f;
    float currentGRL = 0.0f;
    float currentGRR = 0.0f;

    State gateStateL = State::Open;
    State gateStateR = State::Open;
    int holdCounterL = 2400;
    int holdCounterR = 2400;
    int graceSamplesL = 960;
    int graceSamplesR = 960;

    ZDFSVF64 scSVF_L;
    ZDFSVF64 scSVF_R;

    void updateThresholds() noexcept {
        threshOpenLinear = std::pow(10.0f, thresholdDb * 0.05f);
        threshCloseLinear = std::pow(10.0f, (thresholdDb - hysteresisDb) * 0.05f);
    }

    void updateTimeConstants() noexcept {
        attackCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (attackMs * 0.001 * fs)));
        releaseCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (releaseMs * 0.001 * fs)));
        holdSamplesTarget = static_cast<int>(holdMs * 0.001 * fs);
        // Envelope follower calibrato a 25 ms per seguire l'inviluppo della sillaba anziché i ripple di fase
        detectorDecayCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.010 * fs)));
    }

    void updateFilterCoeffs() noexcept {
        scSVF_L.setParameters(scLowCut, 0.707f, static_cast<float>(fs));
        scSVF_R.setParameters(scLowCut, 0.707f, static_cast<float>(fs));
    }

    inline float processSidechainFilterL(float x) noexcept {
        // High-pass filtering: elimina rumble e thumps sotto 80Hz, passa 100% dello spettro vocale
        return scSVF_L.process(x).hp;
    }

    inline float processSidechainFilterR(float x) noexcept {
        return scSVF_R.process(x).hp;
    }

    inline float computeTargetGain(float scSample, float& envFollower, State& state, int& holdCounter, int& graceSamples) noexcept {
        // 0. Grace period alla partenza del transport: trasparenza assoluta
        if (graceSamples > 0) {
            --graceSamples;
            state = State::Open;
            holdCounter = holdSamplesTarget;
            return 1.0f;
        }

        const float absVal = std::abs(scSample);

        // Peak detector a salita istantanea per intercettare transitori veloci (0 ms ritardo)
        if (absVal > envFollower) {
            envFollower = absVal;
        } else {
            envFollower += detectorDecayCoeff * (absVal - envFollower);
        }
        if (envFollower < 1.0e-25f) envFollower = 0.0f;

        // Schmitt-Trigger State Machine con isteresi solida anti-chattering (8 dB window)
        if (envFollower >= threshOpenLinear) {
            state = State::Open;
            holdCounter = holdSamplesTarget;
        } else if (state == State::Open) {
            if (envFollower < threshCloseLinear) {
                state = State::Hold;
                holdCounter = holdSamplesTarget;
            }
        } else if (state == State::Hold) {
            if (--holdCounter <= 0) {
                state = State::Release;
            }
        } else if (state == State::Release) {
            // Se il segnale risale sopra la soglia di apertura, riapre prontamente
            if (envFollower >= threshOpenLinear) {
                state = State::Open;
                holdCounter = holdSamplesTarget;
            }
        }

        // 1. Piena trasparenza (0 dB) durante Open e Hold
        if (state == State::Open || state == State::Hold) {
            return 1.0f;
        }

        // 2. Downward Expander Mode (Buttery-smooth & naturale su code di riverbero)
        if (mode == Mode::DownwardExpander) {
            if (envFollower >= threshOpenLinear) {
                return 1.0f;
            }
            const float levelDb = (envFollower > 1.0e-6f) ? (20.0f * std::log10(envFollower)) : -120.0f;
            const float delta = levelDb - thresholdDb;

            // Raccordo soft-knee quadratico C1-continuo al disotto della soglia (K = 8 dB):
            // Tra 0 dB e -8 dB sotto la soglia: roll-off quadratico con pendenza iniziale 0.
            // Sotto -8 dB: espansione lineare con pendenza (ratio - 1).
            // Questo garantisce ZERO discontinuità o scatti udibili sui decadimenti e code di riverbero.
            constexpr float knee = 8.0f;
            if (delta >= 0.0f) {
                return 1.0f;
            } else if (delta > -knee) {
                const float expDb = -((ratio - 1.0f) / (2.0f * knee)) * (delta * delta);
                const float targetDb = std::max(rangeDbValue, expDb);
                return std::pow(10.0f, targetDb * 0.05f);
            } else {
                const float expDb = (ratio - 1.0f) * (delta + knee * 0.5f);
                const float targetDb = std::max(rangeDbValue, expDb);
                return std::pow(10.0f, targetDb * 0.05f);
            }
        }

        // 3. Hard Gate Mode
        return floorLinear;
    }

    inline float smoothGain(float targetGain, float& currentGain, State& state) noexcept {
        if (targetGain > currentGain) {
            // Attacco ultra-rapido (100 us) per preservare intatte tutte le consonanti
            currentGain += attackCoeff * (targetGain - currentGain);
        } else {
            // Rilascio morbido e musicale su riverberi e code
            currentGain += releaseCoeff * (targetGain - currentGain);
            if (std::abs(currentGain - targetGain) < 0.001f && state == State::Release) {
                state = State::Closed;
            }
        }
        if (currentGain < 1.0e-25f) currentGain = 0.0f;
        return currentGain;
    }
};

} // namespace dsp171
