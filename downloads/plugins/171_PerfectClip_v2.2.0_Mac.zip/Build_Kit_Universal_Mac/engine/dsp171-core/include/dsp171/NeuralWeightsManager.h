#pragma once

#include <array>
#include <atomic>
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <fstream>
#include <dsp171/VocalCraftWeights.h>

namespace dsp171 {

// =============================================================================
// 171 Studio Innovatio - Neural Weights Manager
// Glitch-Free, Atomic Hot-Reloading of Neural Network Weights
// STRICT ZERO HEAP ALLOCATIONS in audio processing thread.
// =============================================================================

#pragma pack(push, 1)
struct BinaryWeightHeader {
    char magic[4];          // b"171W"
    uint32_t formatVersion; // 1
    char pluginId[16];
    char modelVersion[16];
    uint32_t paramCount;    // 3064
    float lossMetric;
    uint64_t timestampUtc;
    uint64_t totalSessions;
};
#pragma pack(pop)
static_assert(sizeof(BinaryWeightHeader) == 64, "BinaryWeightHeader must be exactly 64 bytes");

class VocalCraftWeightsManager {
public:
    VocalCraftWeightsManager() noexcept {
        resetToFactory();
    }

    // Audio-thread method: STRICT ZERO ALLOCATION, LOCK-FREE, WAIT-FREE
    inline const VocalCraftWeightSet* getActiveWeights() const noexcept {
        return activeWeights.load(std::memory_order_relaxed);
    }

    // Background/worker thread: Load OTA weights from memory buffer
    bool loadFromMemory(const uint8_t* data, size_t size) noexcept {
        if (!data || size < sizeof(BinaryWeightHeader) + (VocalCraftWeightSet::kTotalFloatCount * sizeof(float))) {
            return false;
        }

        const auto* header = reinterpret_cast<const BinaryWeightHeader*>(data);
        if (std::memcmp(header->magic, "171W", 4) != 0) {
            return false;
        }

        if (header->paramCount != VocalCraftWeightSet::kTotalFloatCount) {
            return false;
        }

        const float* payload = reinterpret_cast<const float*>(data + sizeof(BinaryWeightHeader));
        
        // Anti-poisoning check: scan incoming weights for NaN or Inf
        for (size_t i = 0; i < VocalCraftWeightSet::kTotalFloatCount; ++i) {
            if (std::isnan(payload[i]) || std::isinf(payload[i])) {
                return false;
            }
        }

        // Copy into double-buffered aligned slot
        std::memcpy(&hotReloadBuffer, payload, sizeof(VocalCraftWeightSet));
        
        // Copy version string
        char verBuf[17] = {0};
        std::memcpy(verBuf, header->modelVersion, 16);
        std::strncpy(currentVersion, verBuf, sizeof(currentVersion) - 1);
        currentVersion[sizeof(currentVersion) - 1] = '\0';
        currentLossMetric = header->lossMetric;

        // Atomic pointer swap to glitch-free hot weights
        activeWeights.store(&hotReloadBuffer, std::memory_order_release);
        isCustomModelLoaded.store(true, std::memory_order_release);
        hotReloadCounter.fetch_add(1, std::memory_order_relaxed);
        return true;
    }

    // Background/worker thread: Load OTA weights from local file path
    bool loadFromFile(const char* filePath) noexcept {
        if (!filePath) return false;
        std::ifstream file(filePath, std::ios::binary | std::ios::ate);
        if (!file.is_open()) return false;

        const std::streamsize size = file.tellg();
        if (size < static_cast<std::streamsize>(sizeof(BinaryWeightHeader) + (VocalCraftWeightSet::kTotalFloatCount * sizeof(float)))) {
            return false;
        }

        file.seekg(0, std::ios::beg);
        std::array<uint8_t, sizeof(BinaryWeightHeader) + sizeof(VocalCraftWeightSet) + 64> tempBuffer{};
        if (size > static_cast<std::streamsize>(tempBuffer.size())) return false;

        file.read(reinterpret_cast<char*>(tempBuffer.data()), size);
        if (!file) return false;

        return loadFromMemory(tempBuffer.data(), static_cast<size_t>(size));
    }

    // Revert to factory baked-in ROM weights
    void resetToFactory() noexcept {
        activeWeights.store(&vocalcraft_weights::kFactoryWeightSet, std::memory_order_release);
        isCustomModelLoaded.store(false, std::memory_order_release);
        std::strncpy(currentVersion, "v1.0.0-factory", sizeof(currentVersion) - 1);
        currentVersion[sizeof(currentVersion) - 1] = '\0';
        currentLossMetric = 0.0197f;
    }

    const char* getVersion() const noexcept {
        return currentVersion;
    }

    float getLossMetric() const noexcept {
        return currentLossMetric;
    }

    bool isCustomLoaded() const noexcept {
        return isCustomModelLoaded.load(std::memory_order_relaxed);
    }

    uint64_t getReloadCount() const noexcept {
        return hotReloadCounter.load(std::memory_order_relaxed);
    }

private:
    alignas(64) VocalCraftWeightSet hotReloadBuffer{};
    std::atomic<const VocalCraftWeightSet*> activeWeights{&vocalcraft_weights::kFactoryWeightSet};
    char currentVersion[32] = "v1.0.0-factory";
    float currentLossMetric = 0.0197f;
    std::atomic<bool> isCustomModelLoaded{false};
    std::atomic<uint64_t> hotReloadCounter{0};
};

} // namespace dsp171
