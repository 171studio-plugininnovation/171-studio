#pragma once
#include <cmath>
#include <algorithm>
#include <array>
#include <cstdint>
#include "Common.h"
#include "ZDFSVF.h"
#include "FastMath.h"

namespace dsp171 {

// =============================================================================
// NLSSummingDSP
// Emulatore di Sommatore Analogico Non-Lineare modellato su Waves NLS:
// - Console Spike: SSL 4000G di Mark "Spike" Stent (punchy, teso, transienti veloci, VCA bite)
// - Console Mike: EMI TG12345 Mk4 di Mike Hedges (calore vintage, valvole/germanio, 2nd & 3rd harmonic)
// - Console Nevo: Neve 5116 di Yoad Nevo (bassi profondi e rotondi, setoso, colla e saturazione ferro Marinair)
//
// Modalità:
// - Channel Mode (32 canali con micro-variazioni di tolleranza hardware per psychoacoustic 3D depth)
// - Buss Mode (Stadio amplificatore sommatore Master con saturazione di trasformatore)
//
// Controlli Chiave:
// - ConsoleType [Spike / Mike / Nevo]
// - ChannelIndex [1 .. 32] (per Channel Mode)
// - Drive [0.0 .. +12.0]: spinge il segnale nella saturazione e riduce l'headroom interno
// - Trim [-12.0 dB .. +12.0 dB]
// - Noise [On / Off]: emulazione del noise floor dei binari di alimentazione della console
// - Mix [0% .. 100%]
// =============================================================================
class NLSSummingDSP {
public:
    enum class ConsoleType : uint8_t {
        Spike = 0, // SSL 4000G
        Mike  = 1, // EMI TG12345
        Nevo  = 2  // Neve 5116
    };

    enum class ComponentMode : uint8_t {
        Channel = 0, // Traccia singola con variabilità tra 32 canali
        Buss    = 1  // Master Buss Summing
    };

    NLSSummingDSP() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        invSr = 1.0f / sr;
        
        hpFilterL.reset();
        hpFilterR.reset();
        lpFilterL.reset();
        lpFilterR.reset();
        
        fluxAlpha = 1.0f - std::exp(-2.0f * 3.14159265f * 8000.0f / sr);
        updateConsoleCharacteristics();
        reset();
    }

    void reset() noexcept {
        hpFilterL.reset();
        hpFilterR.reset();
        lpFilterL.reset();
        lpFilterR.reset();
        flux1_L = 0.0f; flux2_L = 0.0f;
        flux1_R = 0.0f; flux2_R = 0.0f;
        noiseSeed = 0x12345678;
    }

    // Selezione Console: Spike, Mike, Nevo
    void setConsole(ConsoleType type) noexcept {
        consoleType = type;
        updateConsoleCharacteristics();
    }
    [[nodiscard]] ConsoleType getConsole() const noexcept {
        return consoleType;
    }

    // Modalità Componente: Channel vs Buss
    void setMode(ComponentMode m) noexcept {
        mode = m;
        updateConsoleCharacteristics();
    }

    // Indice Canale (da 1 a 32) per simulare le tolleranze dei banchi fisici
    void setChannelIndex(int ch1To32) noexcept {
        channelIndex = std::clamp(ch1To32, 1, 32);
        updateConsoleCharacteristics();
    }

    // Drive: da 0.0 a +12.0 (aumenta armoniche e calore non-lineare)
    void setDrive(float drive0To12) noexcept {
        driveVal = std::clamp(drive0To12, 0.0f, 12.0f);
        updateDriveGains();
    }

    // Trim: da -12.0 dB a +12.0 dB
    void setTrimDb(float trimDb) noexcept {
        trimValDb = std::clamp(trimDb, -12.0f, 12.0f);
        trimGainLin = std::pow(10.0f, trimValDb * 0.05f);
    }

    // Noise On/Off
    void setNoise(bool enabled) noexcept {
        noiseEnabled = enabled;
    }

    // Mix Dry/Wet [0% .. 100%]
    void setMix(float mix0To100) noexcept {
        mix = std::clamp(mix0To100 * 0.01f, 0.0f, 1.0f);
    }

    // --- Processing Block Stereo Phase-Coherent ---
    void process(float* inOutL, float* inOutR, size_t numSamples) noexcept {
        if (!inOutL || !inOutR || numSamples == 0) return;

        for (size_t i = 0; i < numSamples; ++i) {
            const float dryL = inOutL[i];
            const float dryR = inOutR[i];

            // 1. Pre-Gain & Drive Stage
            float sL = dryL * driveGainLin;
            float sR = dryR * driveGainLin;

            // 2. Saturazione Armonica Non-Lineare (THD e Asimmetria del banco differenziata per console)
            sL = processNonLinearTHD(sL, flux1_L, flux2_L);
            sR = processNonLinearTHD(sR, flux1_R, flux2_R);

            // 3. Compensazione di Guadagno del Drive
            sL *= driveCompLin;
            sR *= driveCompLin;

            // 4. Filtraggio Trasformatore & Banda Passante Console
            sL = hpFilterL.process(sL).hp;
            sR = hpFilterR.process(sR).hp;
            sL = lpFilterL.process(sL).lp;
            sR = lpFilterR.process(sR).lp;

            // 5. Iniezione Noise Floor Modellato (gate-clamped per evitare amplificazione con EQ makeup)
            // FIX v3.1: il noise viene iniettato SOLO se il segnale supera -100 dBFS (~0.00001 lin),
            // altrimenti silenzio produce -107 dBFS di rumore che viene amplificato dal makeup EQ a -68 dBFS
            if (noiseEnabled) {
                const float sigPeak = std::max(std::abs(sL), std::abs(sR));
                if (sigPeak > 1.0e-5f) { // -100 dBFS gate threshold
                    sL += generateNoise() * noiseLevelLin;
                    sR += generateNoise() * noiseLevelLin;
                }
            }

            // 6. Output Trim
            float wetL = sL * trimGainLin;
            float wetR = sR * trimGainLin;

            // 7. Dry / Wet Mix
            inOutL[i] = (1.0f - mix) * dryL + mix * wetL;
            if (inOutR != inOutL) {
                inOutR[i] = (1.0f - mix) * dryR + mix * wetR;
            }
        }
    }

private:
    float processNonLinearTHD(float x, float& f1, float& f2) const noexcept {
        if (std::abs(x) < 1.0e-12f) return 0.0f;

        // Modello di flusso magnetico Faraday B = V / (N * A * omega):
        f1 += fluxAlpha * (x - f1);
        f2 += fluxAlpha * (f1 - f2);
        if (std::abs(f1) < 1.0e-25f) f1 = 0.0f;
        if (std::abs(f2) < 1.0e-25f) f2 = 0.0f;

        const float dNorm = driveVal * (1.0f / 12.0f);

        switch (consoleType) {
            case ConsoleType::Spike: {
                // SSL 4000G: VCA solid-state precisione, punchy, transienti rapidi e tesi.
                // 3a armonica dominante con leggera asimmetria di canale per apertura 3D
                const float k = (1.0f + 0.45f * dNorm) * thdDriveFactor;
                const float asym = (athdGain * 0.06f) * dNorm;
                const float xs = x + asym * (x * std::abs(x));
                return std::tanh(k * xs) / k;
            }

            case ConsoleType::Mike: {
                // EMI TG12345: Abbey Road calore vintage valvolare/germanio.
                // Ricche armoniche pari (2nd harmonic) + corpo denso
                const float k = (1.05f + 0.65f * dNorm) * thdDriveFactor;
                const float asym = (0.22f + athdGain * 0.08f) * (0.25f + 0.75f * dNorm);
                const float xs = x + asym * (x * x) / (1.0f + std::abs(x));
                const float sat = std::tanh(k * xs) / k;
                return sat + 0.035f * dNorm * (sat * sat);
            }

            case ConsoleType::Nevo:
            default: {
                // Neve 5116: Classe A discreto, trasformatore ferroso Marinair.
                // Bassi profondi, rotondità sui transienti, 2a e 3a armonica bilanciata
                const float k = (1.02f + 0.55f * dNorm) * thdDriveFactor;
                const float asym = (-0.16f + athdGain * 0.06f) * (0.25f + 0.75f * dNorm);
                const float xCore = f2;
                const float xs = x + asym * (xCore * std::abs(xCore)) / (1.0f + std::abs(xCore));
                return std::tanh(k * xs) / k;
            }
        }
    }

    float generateNoise() noexcept {
        // Generatore PRNG XorShift veloce a 32-bit (rumore analogico bianco/rosa)
        noiseSeed ^= (noiseSeed << 13);
        noiseSeed ^= (noiseSeed >> 17);
        noiseSeed ^= (noiseSeed << 5);
        return static_cast<float>(static_cast<int32_t>(noiseSeed)) * (1.0f / 2147483648.0f);
    }

    void updateDriveGains() noexcept {
        // Drive aumenta progressivamente la spinta armonica (+0 .. +12 dB)
        const float driveDb = driveVal;
        driveGainLin = std::pow(10.0f, driveDb * 0.05f);

        // Compensazione automatica precisa per mantenere il throughput a unity gain (+/-0.4 dB)
        // permettendo al drive di aggiungere calore e saturazione armonica senza stravolgere il mix
        const float compDb = -driveDb * 0.88f;
        driveCompLin = std::pow(10.0f, compDb * 0.05f);
    }

    void updateConsoleCharacteristics() noexcept {
        if (sr <= 0.0f) return;

        // Micro-tolleranza del canale specifico (1..32) per spatial widening 3D
        const float chOffset = (static_cast<float>(channelIndex - 16) / 16.0f);
        const float toleranceDb = (mode == ComponentMode::Channel) ? (chOffset * 0.35f) : 0.0f;

        switch (consoleType) {
            case ConsoleType::Spike: {
                // SSL 4000G: transienti veloci, VCA punchy, risposta tesa
                thdDriveFactor = 1.08f + (toleranceDb * 0.04f);
                athdGain = -0.15f + (chOffset * 0.05f);
                hpFreq = 25.0f; // Bassi tesi e asciutti
                lpFreq = std::min(24000.0f, sr * 0.49f);
                noiseDb = -107.8f;
                break;
            }
            case ConsoleType::Mike: {
                // EMI TG12345 Mk4: ricco calore valvolare/germanio, top-end setoso
                thdDriveFactor = 1.25f + (toleranceDb * 0.06f);
                athdGain = 0.28f + (chOffset * 0.06f);
                hpFreq = 20.0f;
                lpFreq = std::min(19500.0f, sr * 0.45f); // Morbido roll-off sulle altissime vintage
                noiseDb = -96.5f;
                break;
            }
            case ConsoleType::Nevo: {
                // Neve 5116: bassi estesi, trasformatore ferroso LO1166
                thdDriveFactor = 1.15f + (toleranceDb * 0.05f);
                athdGain = -0.22f + (chOffset * 0.04f);
                hpFreq = 16.0f; // Bassi profondissimi
                lpFreq = std::min(22000.0f, sr * 0.48f);
                noiseDb = -105.0f;
                break;
            }
        }

        // Filtri di banda passante analogici
        hpFilterL.setParameters(hpFreq, 0.707f, sr);
        hpFilterR.setParameters(hpFreq, 0.707f, sr);
        lpFilterL.setParameters(lpFreq, 0.707f, sr);
        lpFilterR.setParameters(lpFreq, 0.707f, sr);

        noiseLevelLin = std::pow(10.0f, noiseDb * 0.05f);
    }

    float sr{44100.0f};
    float invSr{1.0f / 44100.0f};

    ConsoleType consoleType{ConsoleType::Spike};
    ComponentMode mode{ComponentMode::Channel};
    int channelIndex{1};

    float driveVal{0.0f};
    float driveGainLin{1.0f};
    float driveCompLin{1.0f};
    float trimValDb{0.0f};
    float trimGainLin{1.0f};

    float thdDriveFactor{1.08f};
    float athdGain{-0.15f};
    float hpFreq{22.0f};
    float lpFreq{26000.0f};
    float noiseDb{-107.8f};
    float noiseLevelLin{0.0f};

    bool noiseEnabled{false};
    float mix{1.0f};
    uint32_t noiseSeed{0x12345678};

    float fluxAlpha{0.70f};
    float flux1_L{0.0f}, flux2_L{0.0f};
    float flux1_R{0.0f}, flux2_R{0.0f};

    ZDFSVF64 hpFilterL, hpFilterR;
    ZDFSVF64 lpFilterL, lpFilterR;
};

} // namespace dsp171
