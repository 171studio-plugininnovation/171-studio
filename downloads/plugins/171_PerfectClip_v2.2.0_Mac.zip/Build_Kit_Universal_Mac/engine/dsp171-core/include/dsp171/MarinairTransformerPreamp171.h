#pragma once

#include <cmath>
#include <algorithm>
#include <cstdint>
#include "Common.h"
#include "FastMath.h"

namespace dsp171 {

// =============================================================================
// Module: MarinairTransformerPreamp171
// Orchestrated by: Lead Analog Circuit & DSP Physicist (171 Studio Innovatio)
//
// Hardware-modeled from the 171 Studio Marinair LO1166 & British Class-A Stage:
// - Physical Faraday Law Core Flux: Phi(t) = (1/N) * Integral((V_in - backEMF) dt)
// - Single-Ended Class-A DC Quiescent Core Pre-Magnetization (B_0 > 0 due to BA283 4.2mA collector current)
// - Heavy LF non-linear saturation (<150 Hz) with pristine HF transparency (>3 kHz)
// - Secondary Winding Back-EMF Inductive Damping & Feedback
// - Monotonic C-inf saturation transfer curve (zero foldback, zero zipper noise)
// - Discrete Class-A BJT Gain Stage (BC184C / 2N3055 drive)
// =============================================================================

class MarinairTransformerPreamp171 {
public:
    MarinairTransformerPreamp171() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);

        // Core flux leaky integrator pole (~28 Hz)
        constexpr float fcCore = 28.0f;
        const float wCore = 2.0f * 3.14159265358979323846f * fcCore;
        gInt = std::clamp(wCore / sr, 0.0001f, 0.25f);

        // DC blocker at 5 Hz
        constexpr float fcDc = 5.0f;
        const float wDc = 2.0f * 3.14159265358979323846f * fcDc / sr;
        dcR = 1.0f - std::clamp(wDc, 0.0001f, 0.1f);

        reset();
    }

    void reset() noexcept {
        fluxState = 0.0f;
        backEmfState = 0.0f;
        dcX1 = 0.0f;
        dcY1 = 0.0f;
    }

    /**
     * @brief Configure parameters
     * @param inputDriveDb Input drive gain (0.0 to +30.0 dB)
     * @param coreWarmth010 Core saturation intensity (0.0 = linear, 10.0 = deep iron saturation)
     * @param outputGainDb Master output trim (-24.0 to +12.0 dB)
     */
    void setParameters(float inputDriveDb, float coreWarmth010 = 5.0f, float outputGainDb = 0.0f) noexcept {
        driveLin = std::pow(10.0f, std::clamp(inputDriveDb, 0.0f, 30.0f) / 20.0f);
        warmth = std::clamp(coreWarmth010, 0.0f, 10.0f);
        // BA283 single-ended Class-A 4.2mA collector quiescent DC bias flux density B_0
        b0Quiescent = 0.28f * (warmth / 10.0f);
        asymFactor = warmth * 0.035f;
        outGainLin = std::pow(10.0f, std::clamp(outputGainDb, -24.0f, 12.0f) / 20.0f);
    }

    inline float processSample(float inSample) noexcept {
        if (!std::isfinite(inSample)) return 0.0f;

        // 1. Discrete Class-A Transistor Preamp Gain & Soft Compression
        const float vIn = inSample * driveLin;
        const float bjtPreamp = std::tanh(vIn * 0.85f) * 1.18f;

        // 2. Faraday Core Flux Leaky Integration with Closed-Loop Back-EMF Feedback
        const float fluxInput = bjtPreamp - backEmfState * 0.28f;
        fluxState += gInt * (fluxInput - fluxState);
        FastMath::flushDenormals(fluxState);

        const float coreFlux = bjtPreamp + fluxState * 1.85f;

        // 3. Genuine Single-Ended Class-A Core Pre-Magnetization (B_0 > 0)
        // Authentic magnetic core flux saturation under single-ended quiescent bias:
        // B_tot = B_0 + coreFlux
        const float bTot = b0Quiescent + coreFlux;

        // Strictly monotonic magnetic core saturation curve:
        // S(B) = B / sqrt(1 + 0.20 * B^2)
        // With bias subtracted at quiescent point S(B_0), zero static DC offset is generated!
        constexpr float satK = 0.20f;
        const float satTot = bTot / std::sqrt(1.0f + satK * (bTot * bTot));
        const float satBias = b0Quiescent / std::sqrt(1.0f + satK * (b0Quiescent * b0Quiescent));
        const float inducedVoltage = satTot - satBias;

        // Strictly monotonic Class-A quadratic core asymmetry (f'(x) > 0 everywhere)
        const float asymCore = inducedVoltage + asymFactor * (inducedVoltage * std::abs(inducedVoltage)) / (1.0f + inducedVoltage * inducedVoltage);

        // 4. Secondary Winding Back-EMF & Inductive HF Output Reconstruction
        const float backEmf = (bjtPreamp - fluxState) * 0.45f;
        backEmfState = backEmf;
        FastMath::flushDenormals(backEmfState);

        const float vOut = asymCore + backEmf;

        // 5. Output DC Decoupling & Level Normalization
        constexpr float normFactor = 1.0f / 1.45f;
        const float rawDcOut = (vOut - dcX1) + dcR * dcY1;
        dcX1 = vOut;
        dcY1 = rawDcOut;
        FastMath::flushDenormals(dcX1);
        FastMath::flushDenormals(dcY1);

        const float acOut = rawDcOut * normFactor;

        return acOut * outGainLin;
    }

private:
    float sr = 44100.0f;
    float driveLin = 1.0f;
    float warmth = 5.0f;
    float b0Quiescent = 0.14f;
    float asymFactor = 0.175f;
    float outGainLin = 1.0f;

    float gInt = 0.004f;
    float fluxState = 0.0f;
    float backEmfState = 0.0f;

    float dcX1 = 0.0f;
    float dcY1 = 0.0f;
    float dcR = 0.9992f;
};

} // namespace dsp171
