#pragma once
#include <cmath>
#include <array>
#include <vector>
#include <algorithm>
#include <atomic>
#include <cstdint>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>

namespace dsp171 {

// =============================================================================
// 171 VocalCraft - High-Resolution Full-Spectrum Peak & Resonance Analyzer
//
// Performs 2048-point Blackman-Harris STFT analysis across the entire audible
// spectrum (20 Hz - 20,000 Hz).
// Identifies EVERY single local peak and resonance spike using parabolic
// sub-bin interpolation, tracking peak frequency, amplitude (dBFS), prominence
// (relative to local spectral baseline), and resonance bandwidth (Q factor).
// =============================================================================
class VocalCraftSpectralAnalyzer {
public:
    static constexpr size_t kFFTSize = 2048;
    static constexpr size_t kHalfFFT = kFFTSize / 2; // 1024 bins
    static constexpr size_t kMaxTrackedPeaks = 64;

    struct DetectedPeak {
        float frequencyHz = 0.0f;
        float magnitudeDb = -100.0f;
        float prominenceDb = 0.0f;
        float estimatedQ = 1.0f;
        bool  isActive = false;
    };

    VocalCraftSpectralAnalyzer() noexcept {
        initWindow();
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        binWidthHz = sr / static_cast<float>(kFFTSize);
        reset();
    }

    void reset() noexcept {
        fifoBuffer.fill(0.0f);
        fifoWriteIdx = 0;
        magSpectrumDb.fill(-100.0f);
        spectralBaselineDb.fill(-100.0f);
        trackedPeaksCount = 0;
        for (auto& p : detectedPeaks) {
            p = DetectedPeak{};
        }
    }

    // Audio thread: feed incoming samples into analysis FIFO
    inline void pushSample(float sample) noexcept {
        if (!std::isfinite(sample)) sample = 0.0f;
        fifoBuffer[fifoWriteIdx] = sample;
        fifoWriteIdx = (fifoWriteIdx + 1) % kFFTSize;
    }

    inline void pushBlock(const float* data, size_t numSamples) noexcept {
        if (!data || numSamples == 0) return;
        for (size_t i = 0; i < numSamples; ++i) {
            pushSample(data[i]);
        }
    }

    // Analyze full spectrum: scans all 1024 frequency bins and extracts every peak
    void analyzeSpectrum(float peakProminenceThresholdDb = 2.5f) noexcept {
        // 1. Copy windowed samples from circular FIFO
        size_t readIdx = fifoWriteIdx;
        for (size_t i = 0; i < kFFTSize; ++i) {
            realBuffer[i] = fifoBuffer[readIdx] * windowCoeffs[i];
            imagBuffer[i] = 0.0f;
            readIdx = (readIdx + 1) % kFFTSize;
        }

        // 2. Compute in-place Radix-2 FFT
        computeFFT(realBuffer.data(), imagBuffer.data(), kFFTSize);

        // 3. Compute magnitude spectrum in dBFS for all 1024 bins
        for (size_t k = 0; k < kHalfFFT; ++k) {
            const float re = realBuffer[k];
            const float im = imagBuffer[k];
            const float power = (re * re + im * im) * (4.0f / (kFFTSize * kFFTSize));
            const float mag = std::sqrt(std::max(1e-12f, power));
            magSpectrumDb[k] = 20.0f * std::log10(mag);
        }

        // 4. Compute Moving Spectral Baseline (Local spectral floor across frequency)
        // Moving window of +/- 8 bins (~170 Hz smoothing at 44.1k)
        constexpr int kRadius = 8;
        for (int k = 0; k < static_cast<int>(kHalfFFT); ++k) {
            float sumDb = 0.0f;
            int count = 0;
            for (int m = -kRadius; m <= kRadius; ++m) {
                int bin = k + m;
                if (bin >= 1 && bin < static_cast<int>(kHalfFFT)) {
                    sumDb += magSpectrumDb[static_cast<size_t>(bin)];
                    count++;
                }
            }
            spectralBaselineDb[static_cast<size_t>(k)] = (count > 0) ? (sumDb / static_cast<float>(count)) : -100.0f;
        }

        // 5. Exhaustive Peak Detection across ALL frequencies (from bin 2 to bin 1020)
        // Scans the entire 20 Hz - 20,000 Hz range without early truncation
        // Zero-heap stack buffer for candidates (real-time safe)
        std::array<DetectedPeak, 256> candidatePeaks{};
        size_t numCandidates = 0;

        for (size_t k = 2; k < kHalfFFT - 2; ++k) {
            const float yPrev = magSpectrumDb[k - 1];
            const float yCurr = magSpectrumDb[k];
            const float yNext = magSpectrumDb[k + 1];

            // Local maximum condition
            if (yCurr > yPrev && yCurr > yNext && yCurr > -75.0f) {
                const float baseline = spectralBaselineDb[k];
                const float prominence = yCurr - baseline;

                // If peak sticks out above the local vocal envelope
                if (prominence >= peakProminenceThresholdDb) {
                    // Parabolic sub-bin interpolation for precise frequency & magnitude
                    const float denom = (yPrev - 2.0f * yCurr + yNext);
                    float delta = 0.0f;
                    if (std::abs(denom) > 1e-6f) {
                        delta = 0.5f * (yPrev - yNext) / denom;
                        delta = std::clamp(delta, -0.5f, 0.5f);
                    }

                    const float exactBin = static_cast<float>(k) + delta;
                    const float exactFreq = exactBin * binWidthHz;
                    const float exactMagDb = yCurr - 0.25f * (yPrev - yNext) * delta;

                    // Estimate Q factor based on -3dB width around peak
                    float leftWidth = 1.0f;
                    float rightWidth = 1.0f;
                    while (k >= static_cast<size_t>(leftWidth + 1) && 
                           magSpectrumDb[k - static_cast<size_t>(leftWidth)] > (exactMagDb - 3.0f)) {
                        leftWidth += 1.0f;
                    }
                    while ((k + static_cast<size_t>(rightWidth)) < (kHalfFFT - 1) && 
                           magSpectrumDb[k + static_cast<size_t>(rightWidth)] > (exactMagDb - 3.0f)) {
                        rightWidth += 1.0f;
                    }
                    const float bwHz = std::max(binWidthHz, (leftWidth + rightWidth) * binWidthHz * 0.5f);
                    const float q = std::clamp(exactFreq / bwHz, 0.5f, 30.0f);

                    DetectedPeak peak;
                    peak.frequencyHz = exactFreq;
                    peak.magnitudeDb = exactMagDb;
                    peak.prominenceDb = prominence;
                    peak.estimatedQ = q;
                    peak.isActive = true;

                    if (numCandidates < candidatePeaks.size()) {
                        candidatePeaks[numCandidates++] = peak;
                    }
                }
            }
        }

        // Sort candidate peaks by prominence (strongest resonances first)
        std::sort(candidatePeaks.begin(), candidatePeaks.begin() + numCandidates, [](const DetectedPeak& a, const DetectedPeak& b) {
            return a.prominenceDb > b.prominenceDb;
        });

        // Retain the top kMaxTrackedPeaks
        trackedPeaksCount = std::min(numCandidates, kMaxTrackedPeaks);
        for (size_t i = 0; i < trackedPeaksCount; ++i) {
            detectedPeaks[i] = candidatePeaks[i];
        }

        // Sort selected peaks by frequency ascending for clean display/tracking
        std::sort(detectedPeaks.begin(), detectedPeaks.begin() + trackedPeaksCount, [](const DetectedPeak& a, const DetectedPeak& b) {
            return a.frequencyHz < b.frequencyHz;
        });
    }

    // Accessors
    size_t getNumDetectedPeaks() const noexcept { return trackedPeaksCount; }
    const std::array<DetectedPeak, kMaxTrackedPeaks>& getDetectedPeaks() const noexcept { return detectedPeaks; }
    const std::array<float, kHalfFFT>& getMagnitudeSpectrumDb() const noexcept { return magSpectrumDb; }
    const std::array<float, kHalfFFT>& getSpectralBaselineDb() const noexcept { return spectralBaselineDb; }

private:
    void initWindow() noexcept {
        // 4-term Blackman-Harris window (-92 dB sidelobes)
        constexpr float a0 = 0.35875f;
        constexpr float a1 = 0.48829f;
        constexpr float a2 = 0.14128f;
        constexpr float a3 = 0.01168f;

        for (size_t n = 0; n < kFFTSize; ++n) {
            const float angle = 2.0f * PI * static_cast<float>(n) / static_cast<float>(kFFTSize - 1);
            windowCoeffs[n] = a0 - a1 * std::cos(angle) + a2 * std::cos(2.0f * angle) - a3 * std::cos(3.0f * angle);
        }
    }

    static void computeFFT(float* real, float* imag, size_t n) noexcept {
        // Bit-reversal permutation
        size_t j = 0;
        for (size_t i = 0; i < n - 1; ++i) {
            if (i < j) {
                std::swap(real[i], real[j]);
                std::swap(imag[i], imag[j]);
            }
            size_t k = n >> 1;
            while (k <= j) {
                j -= k;
                k >>= 1;
            }
            j += k;
        }

        // Cooley-Tukey butterflies
        for (size_t len = 2; len <= n; len <<= 1) {
            const float angle = -2.0f * PI / static_cast<float>(len);
            const float wStepRe = std::cos(angle);
            const float wStepIm = std::sin(angle);

            for (size_t i = 0; i < n; i += len) {
                float wRe = 1.0f;
                float wIm = 0.0f;
                const size_t halfLen = len >> 1;

                for (size_t u = 0; u < halfLen; ++u) {
                    const size_t idxA = i + u;
                    const size_t idxB = idxA + halfLen;

                    const float tRe = wRe * real[idxB] - wIm * imag[idxB];
                    const float tIm = wRe * imag[idxB] + wIm * real[idxB];

                    real[idxB] = real[idxA] - tRe;
                    imag[idxB] = imag[idxA] - tIm;
                    real[idxA] += tRe;
                    imag[idxA] += tIm;

                    const float nextWRe = wRe * wStepRe - wIm * wStepIm;
                    const float nextWIm = wRe * wStepIm + wIm * wStepRe;
                    wRe = nextWRe;
                    wIm = nextWIm;
                }
            }
        }
    }

    float sr = 44100.0f;
    float binWidthHz = 21.533f;

    std::array<float, kFFTSize> windowCoeffs{};
    std::array<float, kFFTSize> fifoBuffer{};
    size_t fifoWriteIdx = 0;

    std::array<float, kFFTSize> realBuffer{};
    std::array<float, kFFTSize> imagBuffer{};

    std::array<float, kHalfFFT> magSpectrumDb{};
    std::array<float, kHalfFFT> spectralBaselineDb{};

    std::array<DetectedPeak, kMaxTrackedPeaks> detectedPeaks{};
    size_t trackedPeaksCount = 0;
};

} // namespace dsp171
