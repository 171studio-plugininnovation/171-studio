#pragma once

#include <array>
#include <atomic>
#include <cstdint>
#include <cstddef>
#include <cstring>

namespace dsp171 {

// =============================================================================
// 171 Studio Innovatio - Telemetry Collector
// Zero-Overhead, Hard Real-Time Lock-Free Circular Ring Buffer
// STRICT ZERO HEAP ALLOCATIONS in audio processing thread.
// =============================================================================

struct TelemetryRecord {
    uint64_t timestampUs{0};
    std::array<float, 16> features{};
    std::array<float, 8> userParameters{};
    float inferenceTimeUs{0.0f};
    int32_t styleIndex{0};
};

template <size_t Capacity = 512>
class TelemetryCollector {
public:
    static_assert((Capacity & (Capacity - 1)) == 0, "TelemetryCollector Capacity must be a power of two");
    static constexpr size_t kIndexMask = Capacity - 1;

    TelemetryCollector() noexcept {
        clear();
    }

    void clear() noexcept {
        writeHead.store(0, std::memory_order_relaxed);
        readHead.store(0, std::memory_order_relaxed);
        droppedCount.store(0, std::memory_order_relaxed);
    }

    // Audio-thread safe: STRICT ZERO HEAP, WAIT-FREE, O(1)
    bool pushFromAudioThread(const std::array<float, 16>& features,
                             const std::array<float, 8>& userParameters,
                             float inferenceTimeUs,
                             int32_t styleIndex,
                             uint64_t timestampUs) noexcept
    {
        const size_t currentWrite = writeHead.load(std::memory_order_relaxed);
        const size_t currentRead = readHead.load(std::memory_order_acquire);

        // If buffer is full, drop frame without ever blocking or allocating
        if ((currentWrite - currentRead) >= Capacity) {
            droppedCount.fetch_add(1, std::memory_order_relaxed);
            return false;
        }

        auto& slot = ringBuffer[currentWrite & kIndexMask];
        slot.timestampUs = timestampUs;
        slot.features = features;
        slot.userParameters = userParameters;
        slot.inferenceTimeUs = inferenceTimeUs;
        slot.styleIndex = styleIndex;

        writeHead.store(currentWrite + 1, std::memory_order_release);
        return true;
    }

    // Worker/GUI thread: pop up to maxCount records into target array
    size_t drainToBuffer(TelemetryRecord* outBuffer, size_t maxCount) noexcept {
        if (!outBuffer || maxCount == 0) return 0;

        size_t count = 0;
        size_t currentRead = readHead.load(std::memory_order_relaxed);
        const size_t currentWrite = writeHead.load(std::memory_order_acquire);

        while (currentRead < currentWrite && count < maxCount) {
            outBuffer[count++] = ringBuffer[currentRead & kIndexMask];
            currentRead++;
        }

        readHead.store(currentRead, std::memory_order_release);
        return count;
    }

    size_t available() const noexcept {
        const size_t w = writeHead.load(std::memory_order_acquire);
        const size_t r = readHead.load(std::memory_order_relaxed);
        return (w >= r) ? (w - r) : 0;
    }

    uint64_t getDroppedCount() const noexcept {
        return droppedCount.load(std::memory_order_relaxed);
    }

private:
    alignas(64) std::atomic<size_t> writeHead{0};
    alignas(64) std::atomic<size_t> readHead{0};
    alignas(64) std::atomic<uint64_t> droppedCount{0};
    std::array<TelemetryRecord, Capacity> ringBuffer{};
};

} // namespace dsp171
