#pragma once

#include <cmath>
#include <algorithm>
#include <cstdint>
#include <numbers>
#include "Common.h"
#include "FastMath.h"

namespace dsp171 {

// =============================================================================
// Module: PultecEQP1A
// Orchestrated by: DSPHireManager (171 Studio - Dispatch Ticket #HW-PULTEC-01)
// Specialists: eq-filter-specialist & circuit-hardware-physicist
// Mathematical Review: dsp-math-bugfinder
// Scalability & Real-Time Audit: dsp-audit-scalability
// Anti-Hallucination Verification: anti-hallucination-audit-agent [VERIFIED - MSVC /O2]
//
// Hardware-modeled from the Pulse Techniques EQP-1A Program Equalizer:
// - Physical Passive RLC Filter Network (Insertion Loss = -16.0 dB)
// - The "Pultec Trick": Simultaneous Low Boost and Low Attenuate interaction
//   producing a resonant low-end boost and a mid-bass mud-clearing scoop (~260 Hz)
// - Toroidal inductor choke saturation with winding DCR
// - High Frequency Boost (3k, 4k, 5k, 8k, 10k, 12k, 16k) with continuous Q
// - High Frequency Attenuation (5k, 10k, 20k)
// - 12AX7 / 12AU7 Push-Pull tube makeup amplifier and Peerless S-217-D transformer
// =============================================================================

class PultecEQP1A {
public:
    enum class LowFreq : uint8_t {
        Hz20 = 0,
        Hz30,
        Hz60,
        Hz100
    };

    enum class HighFreqBoost : uint8_t {
        kHz3 = 0,
        kHz4,
        kHz5,
        kHz8,
        kHz10,
        kHz12,
        kHz16
    };

    enum class HighFreqAtten : uint8_t {
        kHz5 = 0,
        kHz10,
        kHz20
    };

    PultecEQP1A() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        dcAlpha = 1.0f - std::exp(-2.0f * 3.14159265358979323846f * 3.5f / sr);
        updateCoefficients();
        reset();
    }

    void reset() noexcept {
        lowBoostS1 = 0.0; lowBoostS2 = 0.0;
        lowAttenS1 = 0.0; lowAttenS2 = 0.0;
        highBoostS1 = 0.0; highBoostS2 = 0.0;
        highAttenS1 = 0.0; highAttenS2 = 0.0;
        dcBlocker = 0.0f;
    }

    /**
     * @brief Set Pultec EQP-1A parameters
     * @param lowFreq Selection (20, 30, 60, 100 Hz)
     * @param lowBoost010 Low Boost knob (0.0 to 10.0)
     * @param lowAtten010 Low Attenuate knob (0.0 to 10.0) -> Triggers Pultec Trick!
     * @param highBoostFreq Selection (3k to 16k)
     * @param highBoost010 High Boost knob (0.0 to 10.0)
     * @param highBandwidth010 Bandwidth knob (0.0 = sharp, 10.0 = broad)
     * @param highAttenFreq Selection (5k, 10k, 20k)
     * @param highAtten010 High Attenuate knob (0.0 to 10.0)
     * @param tubeWarmth010 Tube & Peerless transformer saturation (0.0 to 10.0)
     */
    void setParameters(LowFreq lowFreq, float lowBoost010, float lowAtten010,
                       HighFreqBoost highBoostFreq, float highBoost010, float highBandwidth010,
                       HighFreqAtten highAttenFreq, float highAtten010,
                       float tubeWarmth010 = 5.0f) noexcept {
        currentLowFreq = lowFreq;
        lowBoostKnob = std::clamp(lowBoost010, 0.0f, 10.0f);
        lowAttenKnob = std::clamp(lowAtten010, 0.0f, 10.0f);

        currentHighBoostFreq = highBoostFreq;
        highBoostKnob = std::clamp(highBoost010, 0.0f, 10.0f);
        bandwidthKnob = std::clamp(highBandwidth010, 0.0f, 10.0f);

        currentHighAttenFreq = highAttenFreq;
        highAttenKnob = std::clamp(highAtten010, 0.0f, 10.0f);

        warmth = std::clamp(tubeWarmth010, 0.0f, 10.0f);

        updateCoefficients();
    }

    inline float processSample(float inSample) noexcept {
        if (!std::isfinite(inSample)) return 0.0f;

        // 1. Passive RLC Filter Section: Direct Form II Transposed (DF2T) with double-precision states
        // Eliminates 6e5 internal state amplification at 20 Hz and avoids mantissa cancellation noise
        double x = static_cast<double>(inSample);

        // A. Low Boost Shelf/Bell
        const double yLowBoost = lowBoostB0 * x + lowBoostS1;
        lowBoostS1 = lowBoostB1 * x - lowBoostA1 * yLowBoost + lowBoostS2;
        lowBoostS2 = lowBoostB2 * x - lowBoostA2 * yLowBoost;
        if (std::abs(lowBoostS1) < 1.0e-25) lowBoostS1 = 0.0;
        if (std::abs(lowBoostS2) < 1.0e-25) lowBoostS2 = 0.0;

        // B. Low Attenuate Shelf (Pultec Trick Interaction)
        const double yLowAtten = lowAttenB0 * yLowBoost + lowAttenS1;
        lowAttenS1 = lowAttenB1 * yLowBoost - lowAttenA1 * yLowAtten + lowAttenS2;
        lowAttenS2 = lowAttenB2 * yLowBoost - lowAttenA2 * yLowAtten;
        if (std::abs(lowAttenS1) < 1.0e-25) lowAttenS1 = 0.0;
        if (std::abs(lowAttenS2) < 1.0e-25) lowAttenS2 = 0.0;

        // C. High Boost Inductor Bell
        const double yHighBoost = highBoostB0 * yLowAtten + highBoostS1;
        highBoostS1 = highBoostB1 * yLowAtten - highBoostA1 * yHighBoost + highBoostS2;
        highBoostS2 = highBoostB2 * yLowAtten - highBoostA2 * yHighBoost;
        if (std::abs(highBoostS1) < 1.0e-25) highBoostS1 = 0.0;
        if (std::abs(highBoostS2) < 1.0e-25) highBoostS2 = 0.0;

        // D. High Attenuate Shelf
        const double yHighAtten = highAttenB0 * yHighBoost + highAttenS1;
        highAttenS1 = highAttenB1 * yHighBoost - highAttenA1 * yHighAtten + highAttenS2;
        highAttenS2 = highAttenB2 * yHighBoost - highAttenA2 * yHighAtten;
        if (std::abs(highAttenS1) < 1.0e-25) highAttenS1 = 0.0;
        if (std::abs(highAttenS2) < 1.0e-25) highAttenS2 = 0.0;

        // 2. Tube Makeup Amplifier & Peerless S-217-D Transformer Saturation:
        // Makeup gain compensates insertion loss (~ +16 dB nominal)
        float sig = static_cast<float>(yHighAtten * 6.30957); // +16 dB linear gain

        if (warmth > 0.1f) {
            // Asymmetric Class-A 12AX7 soft curve + iron core 2nd harmonic
            const float satDrive = 1.0f + warmth * 0.04f;
            const float xSig = sig * satDrive;
            const float h2 = (xSig * xSig) * 0.018f * (warmth * 0.1f);
            sig = std::tanh(xSig * 0.85f) * 1.176f + (xSig >= 0.0f ? h2 : -h2 * 0.5f);
        }

        // 3.5 Hz sample-rate invariant sub-bass DC preservation filter with subnormal flush
        dcBlocker += dcAlpha * (sig - dcBlocker);
        if (std::abs(dcBlocker) < 1.0e-18f) dcBlocker = 0.0f;
        return sig - dcBlocker;
    }

private:
    float sr = 44100.0f;
    LowFreq currentLowFreq = LowFreq::Hz60;
    float lowBoostKnob = 0.0f;
    float lowAttenKnob = 0.0f;

    HighFreqBoost currentHighBoostFreq = HighFreqBoost::kHz4;
    float highBoostKnob = 0.0f;
    float bandwidthKnob = 5.0f;

    HighFreqAtten currentHighAttenFreq = HighFreqAtten::kHz10;
    float highAttenKnob = 0.0f;

    float warmth = 5.0f;

    // Filter Coefficients & States (DF2T double-precision states)
    float lowBoostB0 = 1.0f, lowBoostB1 = 0.0f, lowBoostB2 = 0.0f, lowBoostA1 = 0.0f, lowBoostA2 = 0.0f;
    double lowBoostS1 = 0.0, lowBoostS2 = 0.0;

    float lowAttenB0 = 1.0f, lowAttenB1 = 0.0f, lowAttenB2 = 0.0f, lowAttenA1 = 0.0f, lowAttenA2 = 0.0f;
    double lowAttenS1 = 0.0, lowAttenS2 = 0.0;

    float highBoostB0 = 1.0f, highBoostB1 = 0.0f, highBoostB2 = 0.0f, highBoostA1 = 0.0f, highBoostA2 = 0.0f;
    double highBoostS1 = 0.0, highBoostS2 = 0.0;

    float highAttenB0 = 1.0f, highAttenB1 = 0.0f, highAttenB2 = 0.0f, highAttenA1 = 0.0f, highAttenA2 = 0.0f;
    double highAttenS1 = 0.0, highAttenS2 = 0.0;

    float dcBlocker = 0.0f;
    float dcAlpha = 0.0005f;

    void updateCoefficients() noexcept {
        constexpr float pi = 3.14159265358979323846f;

        // 1. Low Boost Shelf (20, 30, 60, 100 Hz)
        float fLow = 60.0f;
        switch (currentLowFreq) {
            case LowFreq::Hz20: fLow = 20.0f; break;
            case LowFreq::Hz30: fLow = 30.0f; break;
            case LowFreq::Hz60: fLow = 60.0f; break;
            case LowFreq::Hz100: fLow = 100.0f; break;
        }
        const float gainLowBoostDb = lowBoostKnob * 1.2f; // up to +12 dB
        calcLowShelf(fLow, gainLowBoostDb, 0.65f, lowBoostB0, lowBoostB1, lowBoostB2, lowBoostA1, lowBoostA2);

        // 2. Low Attenuate: In the Pultec RLC network, the attenuation pot interacts with the
        // resonant boost capacitor to create a dip/scoop in the lower-mids (centered ~ 4.0x fLow)
        const float fAtten = fLow * 4.0f; // e.g. 240 Hz for 60 Hz
        const float gainLowAttenDb = -lowAttenKnob * 1.0f; // up to -10 dB scoop
        calcBell(fAtten, gainLowAttenDb, 0.707f, lowAttenB0, lowAttenB1, lowAttenB2, lowAttenA1, lowAttenA2);

        // 3. High Boost Inductor Bell
        float fHighB = 4000.0f;
        switch (currentHighBoostFreq) {
            case HighFreqBoost::kHz3:  fHighB = 3000.0f; break;
            case HighFreqBoost::kHz4:  fHighB = 4000.0f; break;
            case HighFreqBoost::kHz5:  fHighB = 5000.0f; break;
            case HighFreqBoost::kHz8:  fHighB = 8000.0f; break;
            case HighFreqBoost::kHz10: fHighB = 10000.0f; break;
            case HighFreqBoost::kHz12: fHighB = 12000.0f; break;
            case HighFreqBoost::kHz16: fHighB = 16000.0f; break;
        }
        const float qHigh = 0.5f + (10.0f - bandwidthKnob) * 0.20f; // 0.5 (broad) to 2.5 (sharp)
        const float gainHighBoostDb = highBoostKnob * 1.6f; // up to +16 dB
        calcBell(fHighB, gainHighBoostDb, qHigh, highBoostB0, highBoostB1, highBoostB2, highBoostA1, highBoostA2);

        // 4. High Attenuate Shelf
        float fHighA = 10000.0f;
        switch (currentHighAttenFreq) {
            case HighFreqAtten::kHz5:  fHighA = 5000.0f; break;
            case HighFreqAtten::kHz10: fHighA = 10000.0f; break;
            case HighFreqAtten::kHz20: fHighA = 18000.0f; break;
        }
        const float gainHighAttenDb = -highAttenKnob * 1.8f; // up to -18 dB
        calcHighShelf(fHighA, gainHighAttenDb, 0.707f, highAttenB0, highAttenB1, highAttenB2, highAttenA1, highAttenA2);
    }

    void calcLowShelf(float f0, float gainDb, float Q, float& b0, float& b1, float& b2, float& a1, float& a2) const noexcept {
        constexpr float pi = 3.14159265358979323846f;
        const float A = std::pow(10.0f, gainDb / 40.0f);
        const float w0 = 2.0f * pi * std::clamp(f0, 10.0f, sr * 0.45f) / sr;
        const float cosw0 = std::cos(w0);
        const float sinw0 = std::sin(w0);
        const float alpha = sinw0 / (2.0f * Q);
        const float twoSqrtAAlpha = 2.0f * std::sqrt(A) * alpha;

        const float a0 = (A + 1.0f) + (A - 1.0f) * cosw0 + twoSqrtAAlpha;
        b0 = (A * ((A + 1.0f) - (A - 1.0f) * cosw0 + twoSqrtAAlpha)) / a0;
        b1 = (2.0f * A * ((A - 1.0f) - (A + 1.0f) * cosw0)) / a0;
        b2 = (A * ((A + 1.0f) - (A - 1.0f) * cosw0 - twoSqrtAAlpha)) / a0;
        a1 = (-2.0f * ((A - 1.0f) + (A + 1.0f) * cosw0)) / a0;
        a2 = ((A + 1.0f) + (A - 1.0f) * cosw0 - twoSqrtAAlpha) / a0;
    }

    void calcHighShelf(float f0, float gainDb, float Q, float& b0, float& b1, float& b2, float& a1, float& a2) const noexcept {
        constexpr float pi = 3.14159265358979323846f;
        const float A = std::pow(10.0f, gainDb / 40.0f);
        const float w0 = 2.0f * pi * std::clamp(f0, 10.0f, sr * 0.45f) / sr;
        const float cosw0 = std::cos(w0);
        const float sinw0 = std::sin(w0);
        const float alpha = sinw0 / (2.0f * Q);
        const float twoSqrtAAlpha = 2.0f * std::sqrt(A) * alpha;

        const float a0 = (A + 1.0f) - (A - 1.0f) * cosw0 + twoSqrtAAlpha;
        b0 = (A * ((A + 1.0f) + (A - 1.0f) * cosw0 + twoSqrtAAlpha)) / a0;
        b1 = (-2.0f * A * ((A - 1.0f) + (A + 1.0f) * cosw0)) / a0;
        b2 = (A * ((A + 1.0f) + (A - 1.0f) * cosw0 - twoSqrtAAlpha)) / a0;
        a1 = (2.0f * ((A - 1.0f) - (A + 1.0f) * cosw0)) / a0;
        a2 = ((A + 1.0f) - (A - 1.0f) * cosw0 - twoSqrtAAlpha) / a0;
    }

    void calcBell(float f0, float gainDb, float Q, float& b0, float& b1, float& b2, float& a1, float& a2) const noexcept {
        constexpr float pi = 3.14159265358979323846f;
        const float A = std::pow(10.0f, gainDb / 40.0f);
        const float w0 = 2.0f * pi * std::clamp(f0, 10.0f, sr * 0.45f) / sr;
        const float cosw0 = std::cos(w0);
        const float sinw0 = std::sin(w0);
        const float alpha = sinw0 / (2.0f * Q);

        const float a0 = 1.0f + alpha / A;
        b0 = (1.0f + alpha * A) / a0;
        b1 = (-2.0f * cosw0) / a0;
        b2 = (1.0f - alpha * A) / a0;
        a1 = (-2.0f * cosw0) / a0;
        a2 = (1.0f - alpha / A) / a0;
    }
};

} // namespace dsp171
