#pragma once
#include <cmath>
#include <algorithm>
#include <array>
#include <cstdint>
#include "Common.h"
#include "ZDFSVF.h"
#include "FastMath.h"
#include "APIThrustFilter.h"

namespace dsp171 {

// =============================================================================
// CLA2ACompressor
// Emulatore dell'amplificatore ottico di livello Teletronix LA-2A / Waves CLA-2A
// 
// Caratteristiche Modellistiche:
// 1. Cella Elettro-Ottica T4B con memoria chimica e rilascio a due stadi:
//    - Stadio 1: rapido rilascio iniziale (~60 ms per il primo 50% di GR)
//    - Stadio 2: lunga coda di rilascio dipendente dalla memoria (da 0.5s a 5s)
// 2. Commutatore Compress (Soft-Knee 3:1) vs Limit (Hard-Knee inf:1).
// 3. Filtro Hi-Freq di pre-enfasi in sidechain (controllo De-Esser / Frequency-Dependent).
// 4. Saturazione valvolare triodo 12AX7/12BH7 e non-linearità del trasformatore UTC A-10/A-24.
// 5. Rumore/ronzio analogico a 50Hz e 60Hz.
// 6. Mix parallelo Dry/Wet [0% .. 100%].
// =============================================================================
class CLA2ACompressor {
public:
    enum class T4BCellType : uint8_t {
        Silver_Late60s = 0,
        Gray_Early70s,
        Modern_Reissue,
        Gray_Mid60s = Gray_Early70s // Backward compatibility alias
    };

    void setCellType(T4BCellType type) noexcept { cellType = type; }
    void setThrustMode(APIThrustFilter::ThrustMode m) noexcept {
        thrustFilterL.setMode(m);
        thrustFilterR.setMode(m);
    }

    enum class Mode : uint8_t {
        Compress = 0, // Ratio ~ 3:1, soft knee progressivo
        Limit    = 1  // Ratio ~ inf:1, limitatore di picco
    };

    enum class AnalogHum : uint8_t {
        Off  = 0,
        Hum50Hz = 1,
        Hum60Hz = 2
    };

    CLA2ACompressor() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        invSr = 1.0f / sr;
        dt = invSr;

        hiFreqFilterL.reset();
        hiFreqFilterR.reset();
        thrustFilterL.prepare(sampleRate);
        thrustFilterR.prepare(sampleRate);
        updateHiFreqFilter();

        // Precalculated T4B opto coefficients (zero per-sample exp() overhead)
        coeffFastAtt = 1.0f - std::exp(-dt / 0.010f); // ~10 ms attack
        coeffFastRel = 1.0f - std::exp(-dt / 0.060f); // ~60 ms initial 50% recovery
        alphaTrapFill = 1.0f - std::exp(-dt / 0.800f); // 0.8s deep trap excitation fill
        alphaTrapEmpty = 1.0f - std::exp(-dt / 3.500f); // 3.5s deep trap empty

        reset();
    }

    void reset() noexcept {
        cellL = {};
        cellR = {};
        currentGRL_dB = 0.0f;
        currentGRR_dB = 0.0f;
        humPhase = 0.0f;
        hiFreqFilterL.reset();
        hiFreqFilterR.reset();
    }

    // Peak Reduction: da 0.0 a 100.0 (regola la sensibilità della cella ottica T4)
    void setPeakReduction(float pr0To100) noexcept {
        peakReduction = std::clamp(pr0To100, 0.0f, 100.0f);
        // Peak reduction mappa la soglia interna da -10 dBFS fino a -50 dBFS
        thresholdDb = -10.0f - (peakReduction * 0.40f);
    }

    // Gain: da 0.0 a 100.0 (amplificatore valvolare di make-up, fino a +40 dB)
    void setGain(float gain0To100) noexcept {
        gainKnob = std::clamp(gain0To100, 0.0f, 100.0f);
        makeupGainDb = gainKnob * 0.40f; // 0..40 dB
        makeupLin = std::pow(10.0f, makeupGainDb * 0.05f);
    }

    // Modalità Compress vs Limit
    void setMode(Mode m) noexcept {
        mode = m;
    }

    void setLimitMode(bool isLimit) noexcept {
        mode = isLimit ? Mode::Limit : Mode::Compress;
    }

    // Hi-Freq (Pre-Emphasis Sidechain): da 0.0 (Flat) a 100.0 (massima enfasi sulle alte)
    void setHiFreq(float hf0To100) noexcept {
        hiFreqAmount = std::clamp(hf0To100, 0.0f, 100.0f);
        updateHiFreqFilter();
    }

    // Analog Hum (Off, 50Hz, 60Hz)
    void setAnalogHum(AnalogHum hum) noexcept {
        analogHum = hum;
    }

    // Mix parallelo [0% .. 100%]
    void setMix(float mix0To100) noexcept {
        mix = std::clamp(mix0To100 * 0.01f, 0.0f, 1.0f);
    }

    // Telemetria Gain Reduction in dB (valori positivi per VU meter)
    [[nodiscard]] float getGainReductionL() const noexcept { return currentGRL_dB; }
    [[nodiscard]] float getGainReductionR() const noexcept { return currentGRR_dB; }

    // Elaborazione Stereo Phase-Locked
    void process(float* inOutL, float* inOutR, size_t numSamples) noexcept {
        if (!inOutL || !inOutR || numSamples == 0) return;

        for (size_t i = 0; i < numSamples; ++i) {
            const float dryL = inOutL[i];
            const float dryR = inOutR[i];

            // 1. Filtraggio Sidechain Hi-Freq (Pre-Emphasis)
            // A valori alti di HiFreq, le basse frequenze vengono attenuate in sidechain
            // rendendo il compressore sensibilissimo a sibilanti e alte frequenze
            float scL = dryL;
            float scR = dryR;
            if (hiFreqAmount > 0.5f) {
                scL = dryL - (hiFreqAmount * 0.008f) * hiFreqFilterL.process(dryL).lp;
                scR = dryR - (hiFreqAmount * 0.008f) * hiFreqFilterR.process(dryR).lp;
            }

            // 2. Rilevatore Ottico T4B con Accoppiamento Stereo (Phase-Locked)
            const float peakL = std::abs(scL);
            const float peakR = std::abs(scR);
            const float maxPeak = std::max(peakL, peakR);

            // Calcolo Gain Reduction target della cella T4
            const float grDbL = computeTargetGR(peakL);
            const float grDbR = computeTargetGR(peakR);
            const float grDbLinked = std::max(grDbL, grDbR);

            // Dinamica fotoresistiva T4 a doppio stadio con memoria di carica
            currentGRL_dB = updateT4Cell(cellL, grDbLinked);
            currentGRR_dB = updateT4Cell(cellR, grDbLinked);

            const float attenL = std::pow(10.0f, -currentGRL_dB * 0.05f);
            const float attenR = std::pow(10.0f, -currentGRR_dB * 0.05f);

            // 3. Attenuazione ottica applicata al segnale
            float wetL = dryL * attenL;
            float wetR = dryR * attenR;

            // 4. Stadio di guadagno valvolare 12AX7 con saturazione morbida triodo
            wetL *= makeupLin;
            wetR *= makeupLin;
            wetL = tubeSaturate(wetL);
            wetR = tubeSaturate(wetR);

            // 5. Iniezione Hum/Noise Analogico se abilitato
            if (analogHum != AnalogHum::Off) {
                const float humFreq = (analogHum == AnalogHum::Hum50Hz) ? 50.0f : 60.0f;
                humPhase += humFreq * invSr * 2.0f * 3.14159265f;
                if (humPhase > 2.0f * 3.14159265f) humPhase -= 2.0f * 3.14159265f;
                
                // Hum a -68 dBFS con armoniche a 100/120 Hz
                const float humSig = 0.00035f * (std::sin(humPhase) + 0.35f * std::sin(2.0f * humPhase));
                wetL += humSig;
                wetR += humSig;
            }

            // 6. Mix Parallelo Dry / Wet
            inOutL[i] = (1.0f - mix) * dryL + mix * wetL;
            inOutR[i] = (1.0f - mix) * dryR + mix * wetR;
        }
    }

private:
    struct T4Cell {
        float fastLuminescence{0.0f}; // Risposta luminescente rapida (~60 ms 50% recovery)
        float slowMemoryTrap{0.0f};   // Trappole lente nei cristalli di CdS
        float memoryIntegral{0.0f};   // Integrale storico dell'eccitazione luminescente
        float outputGR{0.0f};
    };

    float computeTargetGR(float peakAmp) const noexcept {
        if (peakAmp <= 1.0e-5f) return 0.0f;
        const float peakDb = 20.0f * std::log10(peakAmp);
        const float overDb = peakDb - thresholdDb;
        if (overDb <= 0.0f) return 0.0f;

        if (mode == Mode::Compress) {
            // Compress Mode: soft knee progressivo (Ratio ~ 3:1)
            const float kneeWidth = 10.0f;
            if (overDb < kneeWidth) {
                // Raccordo parabolico soft knee
                return (overDb * overDb) / (2.0f * kneeWidth) * (2.0f / 3.0f);
            } else {
                return (overDb - kneeWidth * 0.5f) * (2.0f / 3.0f);
            }
        } else {
            // Limit Mode: hard knee (Ratio ~ inf:1, limitatore di picco)
            return overDb * 0.95f;
        }
    }

    // Dinamica della cella T4B fotoresistiva:
    // Attack: ~10 ms
    // Release Stage 1: ~60 ms per il primo 50% di rilascio
    // Release Stage 2: fino a 0.5s - 4.5s dipendente dall'integrale storico di memoria
    float updateT4Cell(T4Cell& cell, float targetGR) const noexcept {
        const float coeffFast = (targetGR > cell.fastLuminescence) ? coeffFastAtt : coeffFastRel;
        cell.fastLuminescence += coeffFast * (targetGR - cell.fastLuminescence);

        // Integrale storico di carica delle trappole profonde (deep trap memory)
        if (targetGR > 0.01f) {
            cell.memoryIntegral += alphaTrapFill * (std::min(30.0f, targetGR) - cell.memoryIntegral);
        } else {
            cell.memoryIntegral += alphaTrapEmpty * (0.0f - cell.memoryIntegral);
        }

        // Parametri dinamici di rilascio calibrati per modello di cella T4B
        float baseSlowSec = 0.850f;
        float memScaleSec = 2.500f;
        float baseWeight = 0.35f;

        switch (cellType) {
            case T4BCellType::Silver_Late60s:
                baseSlowSec = 0.500f;
                memScaleSec = 1.500f;
                baseWeight = 0.30f;
                break;
            case T4BCellType::Gray_Early70s:
                baseSlowSec = 0.850f;
                memScaleSec = 3.200f;
                baseWeight = 0.40f;
                break;
            case T4BCellType::Modern_Reissue:
                baseSlowSec = 0.650f;
                memScaleSec = 2.000f;
                baseWeight = 0.35f;
                break;
        }

        const float normMem = std::clamp(cell.memoryIntegral / 15.0f, 0.0f, 1.0f);
        const float tauSlowSec = baseSlowSec + memScaleSec * normMem;
        const float coeffSlow = (targetGR > cell.slowMemoryTrap)
            ? (dt / 0.500f)
            : (dt / tauSlowSec);

        cell.slowMemoryTrap += coeffSlow * (targetGR - cell.slowMemoryTrap);

        FastMath::flushDenormals(cell.fastLuminescence);
        FastMath::flushDenormals(cell.slowMemoryTrap);
        FastMath::flushDenormals(cell.memoryIntegral);

        const float slowWeight = baseWeight + 0.25f * normMem;
        cell.outputGR = (1.0f - slowWeight) * cell.fastLuminescence + slowWeight * cell.slowMemoryTrap;
        if (cell.outputGR < 1.0e-4f) cell.outputGR = 0.0f;
        return cell.outputGR;
    }

    // Saturazione valvolare triodo 12AX7 con armoniche pari e ginocchio morbido
    static float tubeSaturate(float x) noexcept {
        // Stadio a triodo 12AX7 con pendenza lineare a piccoli segnali e saturazione morbida a piena scala
        const float bias = 0.035f;
        const float normX = x * 0.75f;
        const float xb = normX + bias;
        const float y = (std::tanh(xb) - std::tanh(bias)) * (1.0f / 0.75f);
        return y + 0.025f * (y * std::abs(y));
    }

    void updateHiFreqFilter() noexcept {
        // Filtro passa-basso a 1.2 kHz per sottrarre basse/medie dal sidechain
        hiFreqFilterL.setParameters(1200.0f, 0.707f, sr);
        hiFreqFilterR.setParameters(1200.0f, 0.707f, sr);
    }

    float sr{44100.0f};
    float invSr{1.0f / 44100.0f};
    float dt{1.0f / 44100.0f};

    float peakReduction{0.0f};
    float thresholdDb{-10.0f};
    float gainKnob{0.0f};
    float makeupGainDb{0.0f};
    float makeupLin{1.0f};

    Mode mode{Mode::Compress};
    float hiFreqAmount{0.0f};
    AnalogHum analogHum{AnalogHum::Off};
    float mix{1.0f};

    float currentGRL_dB{0.0f};
    float currentGRR_dB{0.0f};
    float humPhase{0.0f};

    T4Cell cellL;
    T4Cell cellR;
    ZDFSVF64 hiFreqFilterL;
    ZDFSVF64 hiFreqFilterR;
    T4BCellType cellType{T4BCellType::Silver_Late60s};
    APIThrustFilter thrustFilterL;
    APIThrustFilter thrustFilterR;

    float coeffFastAtt{0.002f};
    float coeffFastRel{0.0003f};
    float alphaTrapFill{0.00003f};
    float alphaTrapEmpty{0.000006f};
};

} // namespace dsp171
