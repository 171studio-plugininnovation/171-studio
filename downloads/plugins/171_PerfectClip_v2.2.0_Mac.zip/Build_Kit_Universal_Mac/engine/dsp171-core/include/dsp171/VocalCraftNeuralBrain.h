#pragma once

#include <cmath>
#include <array>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <numbers>

#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include <dsp171/ZDFSVF.h>
#include <dsp171/NeuralWeightsManager.h>
#include <dsp171/TelemetryCollector.h>

namespace dsp171 {

// =============================================================================
// 171 VocalCraft - Neural Brain (Deep Learning Audio Inference Engine)
// 171 Studio Innovatio - High Precision Zero-Allocation C++20 Header
//
// Real-Time Neural Architecture:
// 1. NeuralFeatureExtractor:
//    Extracts 16 real-time physical vocal & beat interaction features:
//    [0]  inputRmsDb                 (-90.0 to 0.0 dBFS)
//    [1]  crestFactor                (Peak / RMS ratio: 1.0 to 12.0)
//    [2]  spectralCentroidHz         (Audible brightness center of mass: 20 Hz - 20 kHz)
//    [3]  spectralFlux               (Inter-frame transient spectral burst rate: 0.0 - 10.0)
//    [4]  spectralFlatness           (Wiener entropy: tonality vs unvoiced noise: 0.0 - 1.0)
//    [5]  f1EnergyDb                 (Chest / Vowel Body: 250 - 750 Hz)
//    [6]  f2EnergyDb                 (Nasal / Intelligibility: 800 - 2200 Hz)
//    [7]  f3EnergyDb                 (Harshness / Vocal Ring: 2200 - 3800 Hz)
//    [8]  sibilantEnergyDb           (Sibilants: 4500 - 8000 Hz)
//    [9]  airEnergyDb                (Silk Sheen: 9000 - 18000 Hz)
//    [10] subRumbleEnergyDb          (Sub-rumble leakage: < 60 Hz)
//    [11] phonemeClass               (0 = silence, 1 = vowel, 2 = plosive, 3 = sibilant/fricative)
//    [12] beatMaskingCollisionDb     (Cross-spectral clash in intelligibility zone, 0 if no beat)
//    [13] beatRmsDb                  (Instrumental beat loudness, 0 if no beat)
//    [14] vocalToBeatDifferentialDb  (VBR: Vocal-to-Beat Ratio dB, 0 if no beat)
//    [15] styleIndex                 (0 = Hip-Hop, 1 = Pop, 2 = Trap, 3 = R&B)
//
// 2. NeuralInferenceEngine:
//    Ultra-fast 2-layer Recurrent Neural Brain with Boutique Pre-Trained Weights:
//    - Normalization: Zero-mean unit-variance acoustic feature scaling
//    - Layer 1: Dense 16 -> 32 with fast GELU / LeakyReLU activation
//    - Layer 2: Temporal Memory GRU cell (16 states) tracking phrasing & ballistics
//    - Layer 3: Output Projection 16 -> 8 with physical domain bounded sigmoid mappings:
//      [0] predictedCompRatio         (Target dynamic compression ratio: 1.2:1 to 12.0:1)
//      [1] dynamicConsonantPunch      (Consonant punch-through weight: 0.0 to 1.0)
//      [2] acousticResonanceMask      (Room resonance vs natural harmonic discriminator: 0.0 to 1.0)
//      [3] deesserThresholdOffsetDb   (Adaptive sibilance threshold trim: -12.0 to +6.0 dB)
//      [4] deesserDepthDb             (Target sibilance reduction depth: 0.0 to 14.0 dB)
//      [5] beatPocketCarveDb          (Optimal unmask frequency carve depth: 0.0 to 9.0 dB)
//      [6] airSheenBoostDb            (Mix-ready high frequency shelf target: 0.0 to 6.0 dB)
//      [7] dynamicFaderRideDb         (VBR micro-fader riding offset: -4.0 to +4.0 dB)
//
// 3. Thread-Safety & Performance:
//    - STRICT ZERO HEAP ALLOCATIONS in audio thread (prepare, process, infer).
//    - Real-time performance: runs in < 0.05 ms (50 microseconds) per block at 96 kHz.
//    - Lock-free, wait-free double-buffered Seqlock telemetry snapshots for 60 FPS GUI.
// =============================================================================

// --- Enumerations ---

enum VocalFeatureIndex : size_t {
    kFeatureInputRmsDb = 0,
    kFeatureCrestFactor = 1,
    kFeatureSpectralCentroidHz = 2,
    kFeatureSpectralFlux = 3,
    kFeatureSpectralFlatness = 4,
    kFeatureF1EnergyDb = 5,
    kFeatureF2EnergyDb = 6,
    kFeatureF3EnergyDb = 7,
    kFeatureSibilantEnergyDb = 8,
    kFeatureAirEnergyDb = 9,
    kFeatureSubRumbleEnergyDb = 10,
    kFeaturePhonemeClass = 11,
    kFeatureBeatMaskingCollisionDb = 12,
    kFeatureBeatRmsDb = 13,
    kFeatureVocalToBeatDifferentialDb = 14,
    kFeatureStyleIndex = 15,
    kNumFeatures = 16
};

enum NeuralPredictionIndex : size_t {
    kPredCompRatio = 0,
    kPredConsonantPunch = 1,
    kPredAcousticResonanceMask = 2,
    kPredDeesserThresholdOffsetDb = 3,
    kPredDeesserDepthDb = 4,
    kPredBeatPocketCarveDb = 5,
    kPredAirSheenBoostDb = 6,
    kPredDynamicFaderRideDb = 7,
    kNumPredictions = 8
};

enum PhonemeClass : int {
    kPhonemeSilence = 0,
    kPhonemeVowel = 1,
    kPhonemePlosive = 2,
    kPhonemeSibilantFricative = 3
};

enum VocalStyle : int {
    kStyleHipHop = 0,
    kStylePop = 1,
    kStyleTrap = 2,
    kStyleRnB = 3
};

// --- Telemetry Snapshot ---

struct NeuralBrainTelemetry {
    // 16 Extracted Physical Features
    std::array<float, kNumFeatures> features{};
    
    // 8 Neural Inferred Control Targets
    std::array<float, kNumPredictions> predictions{};

    // Named convenience feature fields
    float inputRmsDb = -90.0f;
    float crestFactor = 1.0f;
    float spectralCentroidHz = 1000.0f;
    float spectralFlux = 0.0f;
    float spectralFlatness = 0.0f;
    float f1EnergyDb = -90.0f;
    float f2EnergyDb = -90.0f;
    float f3EnergyDb = -90.0f;
    float sibilantEnergyDb = -90.0f;
    float airEnergyDb = -90.0f;
    float subRumbleEnergyDb = -90.0f;
    int   phonemeClass = 0;
    float beatMaskingCollisionDb = 0.0f;
    float beatRmsDb = 0.0f;
    float vocalToBeatDifferentialDb = 0.0f;
    int   styleIndex = 0;

    // Named convenience prediction fields
    float predictedCompRatio = 4.0f;
    float dynamicConsonantPunch = 0.0f;
    float acousticResonanceMask = 0.0f;
    float deesserThresholdOffsetDb = 0.0f;
    float deesserDepthDb = 0.0f;
    float beatPocketCarveDb = 0.0f;
    float airSheenBoostDb = 0.0f;
    float dynamicFaderRideDb = 0.0f;

    // Diagnostics & Performance metrics
    uint64_t inferenceCount = 0;
    float lastInferenceTimeUs = 0.0f;
    bool isCustomModel = false;
    float modelLoss = 0.0197f;
};

// --- Pre-Trained Boutique Neural Weights (included at top) ---

// =============================================================================
// NeuralFeatureExtractor
// High-resolution real-time physical feature extraction engine.
// Preallocated circular analysis buffers, Radix-2 512-point STFT, Cytomic ZDF
// SVF multi-formant filterbanks. 100% Zero-heap in audio execution.
// =============================================================================
class NeuralFeatureExtractor {
public:
    static constexpr size_t kFFTSize = 512;
    static constexpr size_t kHalfFFT = kFFTSize / 2; // 256 bins

    NeuralFeatureExtractor() noexcept {
        initWindow();
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        binWidthHz = sr / static_cast<float>(kFFTSize);

        // Vocal Formant Tracking Filters (Cytomic 64-bit ZDF SVF)
        // 0. Sub Rumble: < 60 Hz Lowpass (Q = 0.707)
        svfSubRumble.reset();
        svfSubRumble.setParameters(60.0f, 0.707f, sr);

        // 1. F1 Vowel Body / Chest: 250 - 750 Hz (Center = 450 Hz, Q = 0.9)
        svfF1.reset();
        svfF1.setParameters(450.0f, 0.90f, sr);

        // 2. F2 Nasal / Intelligibility: 800 - 2200 Hz (Center = 1350 Hz, Q = 0.95)
        svfF2.reset();
        svfF2.setParameters(1350.0f, 0.95f, sr);

        // 3. F3 Vocal Ring / Presence: 2200 - 3800 Hz (Center = 2900 Hz, Q = 1.8)
        svfF3.reset();
        svfF3.setParameters(2900.0f, 1.80f, sr);

        // 4. Sibilant Energy: 4500 - 8000 Hz (Center = 6000 Hz, Q = 1.7)
        svfSibilant.reset();
        svfSibilant.setParameters(6000.0f, 1.70f, sr);

        // 5. Air Sheen: 9000 - 18000 Hz (Center = 13000 Hz, Q = 1.4)
        svfAir.reset();
        svfAir.setParameters(13000.0f, 1.40f, sr);

        // Beat Sidechain Clash Tracking Filters (F1, F2, F3)
        svfBeatF1.reset();
        svfBeatF1.setParameters(450.0f, 0.90f, sr);
        svfBeatF2.reset();
        svfBeatF2.setParameters(1350.0f, 0.95f, sr);
        svfBeatF3.reset();
        svfBeatF3.setParameters(2900.0f, 1.80f, sr);

        // 15ms ballistics to eliminate waveform cycle ripple from crest calculation
        rmsSmoothCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.015 * sr)));

        reset();
    }

    void reset() noexcept {
        fifoBuffer.fill(0.0f);
        fifoWriteIdx = 0;
        prevMagSpectrum.fill(0.0f);

        svfSubRumble.reset();
        svfF1.reset();
        svfF2.reset();
        svfF3.reset();
        svfSibilant.reset();
        svfAir.reset();
        dcBlockX1 = 0.0;
        dcBlockY1 = 0.0;

        svfBeatF1.reset();
        svfBeatF2.reset();
        svfBeatF3.reset();

        smoothedVocalRms = 0.0001f;
        prevCentroid = 1000.0f;
        prevFlux = 0.0f;
        prevFlatness = 0.0f;
    }

    // Extract all 16 physical features from the incoming block
    void extractFeatures(const float* vocalL, const float* vocalR,
                         const float* beatL, const float* beatR,
                         int numSamples, int styleIndex,
                         std::array<float, kNumFeatures>& outFeatures) noexcept
    {
        if (numSamples <= 0 || vocalL == nullptr) {
            outFeatures.fill(0.0f);
            outFeatures[kFeatureInputRmsDb] = -90.0f;
            outFeatures[kFeatureCrestFactor] = 1.0f;
            outFeatures[kFeatureSpectralCentroidHz] = 1000.0f;
            outFeatures[kFeatureStyleIndex] = static_cast<float>(std::clamp(styleIndex, 0, 3));
            return;
        }

        const bool hasBeat = (beatL != nullptr);

        // ---------------------------------------------------------------------
        // 1. Time-Domain Accumulators & ZDF Formant Filterbank
        // ---------------------------------------------------------------------
        float sumSqVocal = 0.0f;
        float peakVocal = 0.0f;

        float sumSqSub = 0.0f;
        float sumSqF1 = 0.0f;
        float sumSqF2 = 0.0f;
        float sumSqF3 = 0.0f;
        float sumSqSib = 0.0f;
        float sumSqAir = 0.0f;

        float sumSqBeat = 0.0f;
        float sumSqBeatF1 = 0.0f;
        float sumSqBeatF2 = 0.0f;
        float sumSqBeatF3 = 0.0f;

        for (int i = 0; i < numSamples; ++i) {
            float vSample = vocalL[i];
            if (vocalR != nullptr)
                vSample = 0.5f * (vSample + vocalR[i]);

            if (!std::isfinite(vSample)) vSample = 0.0f;

            // DC Blocker filter
            const double inD = static_cast<double>(vSample);
            const double dcFiltered = inD - dcBlockX1 + 0.9995 * dcBlockY1;
            dcBlockX1 = inD;
            dcBlockY1 = dcFiltered;
            vSample = static_cast<float>(dcFiltered);

            // Push to circular FIFO for STFT
            fifoBuffer[fifoWriteIdx] = vSample;
            fifoWriteIdx = (fifoWriteIdx + 1) % kFFTSize;

            const float absV = std::abs(vSample);
            if (absV > peakVocal) peakVocal = absV;
            sumSqVocal += vSample * vSample;

            // Multi-formant ZDF SVF filtering
            const float subY = svfSubRumble.process(vSample).lp;
            sumSqSub += subY * subY;

            const float f1Y = svfF1.processBP(vSample);
            sumSqF1 += f1Y * f1Y;

            const float f2Y = svfF2.processBP(vSample);
            sumSqF2 += f2Y * f2Y;

            const float f3Y = svfF3.processBP(vSample);
            sumSqF3 += f3Y * f3Y;

            const float sibY = svfSibilant.processBP(vSample);
            sumSqSib += sibY * sibY;

            const float airY = svfAir.processBP(vSample);
            sumSqAir += airY * airY;

            // Beat Sidechain processing
            if (hasBeat) {
                float bSample = beatL[i];
                if (beatR != nullptr)
                    bSample = 0.5f * (bSample + beatR[i]);
                if (!std::isfinite(bSample)) bSample = 0.0f;

                sumSqBeat += bSample * bSample;
                const float bF1 = svfBeatF1.processBP(bSample);
                sumSqBeatF1 += bF1 * bF1;
                const float bF2 = svfBeatF2.processBP(bSample);
                sumSqBeatF2 += bF2 * bF2;
                const float bF3 = svfBeatF3.processBP(bSample);
                sumSqBeatF3 += bF3 * bF3;
            }
        }

        const float invN = 1.0f / static_cast<float>(numSamples);
        const float blockRms = std::sqrt(sumSqVocal * invN);

        // Smooth RMS over ~15ms window to eliminate low-frequency waveform cycle ripple
        const float blockCoeff = std::min(1.0f, rmsSmoothCoeff * static_cast<float>(numSamples));
        if (blockRms > smoothedVocalRms)
            smoothedVocalRms += (blockRms - smoothedVocalRms) * blockCoeff;
        else
            smoothedVocalRms += (blockRms - smoothedVocalRms) * (blockCoeff * 0.35f);

        const float effectiveRms = std::max(smoothedVocalRms, 1e-5f);
        const float vocalRmsDb = fastLinearToDb(effectiveRms);

        // [0] inputRmsDb (-90.0 to 0.0 dBFS)
        outFeatures[kFeatureInputRmsDb] = std::clamp(vocalRmsDb, -90.0f, 0.0f);

        // [1] crestFactor (Peak / RMS ratio: 1.0 to 12.0)
        const float crest = peakVocal / effectiveRms;
        outFeatures[kFeatureCrestFactor] = std::clamp(crest, 1.0f, 12.0f);

        // Formant Energies in dBFS
        auto toBandDb = [invN](float sumSq) noexcept -> float {
            const float bandRms = std::sqrt(sumSq * invN);
            return std::clamp(fastLinearToDb(bandRms), -90.0f, 0.0f);
        };

        // [5] f1EnergyDb (Chest / Vowel Body: 250 - 750 Hz)
        outFeatures[kFeatureF1EnergyDb] = toBandDb(sumSqF1);

        // [6] f2EnergyDb (Nasal / Intelligibility: 800 - 2200 Hz)
        outFeatures[kFeatureF2EnergyDb] = toBandDb(sumSqF2);

        // [7] f3EnergyDb (Harshness / Vocal Ring: 2200 - 3800 Hz)
        outFeatures[kFeatureF3EnergyDb] = toBandDb(sumSqF3);

        // [8] sibilantEnergyDb (Sibilants: 4500 - 8000 Hz)
        outFeatures[kFeatureSibilantEnergyDb] = toBandDb(sumSqSib);

        // [9] airEnergyDb (Silk: 9000 - 18000 Hz)
        outFeatures[kFeatureAirEnergyDb] = toBandDb(sumSqAir);

        // [10] subRumbleEnergyDb (< 60 Hz)
        outFeatures[kFeatureSubRumbleEnergyDb] = toBandDb(sumSqSub);

        // ---------------------------------------------------------------------
        // 2. High-Resolution 512-Point STFT Spectral Descriptors
        // ---------------------------------------------------------------------
        // Copy windowed circular buffer into real FFT buffer
        size_t readIdx = fifoWriteIdx;
        for (size_t n = 0; n < kFFTSize; ++n) {
            fftReal[n] = fifoBuffer[readIdx] * windowCoeffs[n];
            fftImag[n] = 0.0f;
            readIdx = (readIdx + 1) % kFFTSize;
        }

        // In-place Radix-2 FFT
        computeFFT(fftReal.data(), fftImag.data(), kFFTSize);

        // Compute magnitude spectrum
        float sumMagnitude = 0.0f;
        float weightedCentroidSum = 0.0f;
        float fluxAccumulator = 0.0f;

        float sumLogPower = 0.0f;
        float sumPower = 0.0f;
        constexpr float kEpsilonPower = 1e-12f;

        // Skip DC (bin 0) and evaluate bins up to 22 kHz (guards against ultrasonic noise at 96k/192k)
        const size_t maxCentroidBin = std::min(kHalfFFT, static_cast<size_t>(22000.0f / binWidthHz));
        for (size_t k = 1; k < kHalfFFT; ++k) {
            const float re = fftReal[k];
            const float im = fftImag[k];
            const float rawPower = (re * re + im * im) * (4.0f / (kFFTSize * kFFTSize));
            const float mag = std::sqrt(rawPower);

            if (k < maxCentroidBin) {
                sumMagnitude += mag;
                const float binFreq = static_cast<float>(k) * binWidthHz;
                weightedCentroidSum += binFreq * mag;
            }

            // Spectral Flux: half-wave rectified difference
            const float deltaMag = std::max(0.0f, mag - prevMagSpectrum[k]);
            fluxAccumulator += deltaMag;
            prevMagSpectrum[k] = mag;

            // Wiener Entropy (Spectral Flatness)
            const float effPower = rawPower + kEpsilonPower;
            sumLogPower += fastLog2(effPower) * 0.69314718f; // fast ln(power)
            sumPower += effPower;
        }

        // [2] spectralCentroidHz (20 Hz - 20 kHz)
        float centroid = (sumMagnitude > 1e-6f) ? (weightedCentroidSum / sumMagnitude) : 1000.0f;
        centroid = std::clamp(centroid, 20.0f, 20000.0f);
        outFeatures[kFeatureSpectralCentroidHz] = centroid;

        // [3] spectralFlux (transient burst rate: 0.0 to 10.0)
        float flux = (fluxAccumulator / static_cast<float>(kHalfFFT)) * 250.0f;
        flux = std::clamp(flux, 0.0f, 10.0f);
        outFeatures[kFeatureSpectralFlux] = flux;

        // [4] spectralFlatness (Wiener entropy: ratio of geometric mean to arithmetic mean)
        constexpr float invBins = 1.0f / static_cast<float>(kHalfFFT - 1);
        const float geometricMean = fastExp(sumLogPower * invBins);
        const float arithmeticMean = sumPower * invBins;
        float flatness = (arithmeticMean > 1e-10f) ? (geometricMean / arithmeticMean) : 0.0f;
        flatness = std::clamp(flatness, 0.0f, 1.0f);
        outFeatures[kFeatureSpectralFlatness] = flatness;

        // ---------------------------------------------------------------------
        // 3. Acoustic Phonetic Classification Rule Engine
        // ---------------------------------------------------------------------
        // 0 = silence, 1 = vowel, 2 = plosive, 3 = sibilant/fricative
        int phoneme = kPhonemeSilence;
        if (vocalRmsDb > -55.0f) {
            const float sibilantDiff = outFeatures[kFeatureSibilantEnergyDb] - outFeatures[kFeatureF1EnergyDb];
            
            // 1. Sibilant / Fricative: Dominant high-frequency energy and elevated centroid
            if (sibilantDiff > -6.0f && centroid > 4000.0f) {
                phoneme = kPhonemeSibilantFricative;
            }
            // 2. Plosive: Prominent transient burst or high crest factor in vocal body
            else if (crest > 2.8f || flux > 1.2f) {
                phoneme = kPhonemePlosive;
            }
            // Sustained vowel body: tonal body resonance
            else {
                phoneme = kPhonemeVowel;
            }
        }
        outFeatures[kFeaturePhonemeClass] = static_cast<float>(phoneme);

        // ---------------------------------------------------------------------
        // 4. Beat Sidechain Interaction Features
        // ---------------------------------------------------------------------
        if (hasBeat) {
            const float beatRms = std::sqrt(sumSqBeat * invN);
            const float beatRmsDb = (beatRms > 1e-4f) ? std::clamp(fastLinearToDb(beatRms), -90.0f, 0.0f) : -90.0f;

            if (beatRmsDb > -75.0f) {
                // [13] beatRmsDb
                outFeatures[kFeatureBeatRmsDb] = beatRmsDb;

                // [14] vocalToBeatDifferentialDb (VBR)
                const float vbr = vocalRmsDb - beatRmsDb;
                outFeatures[kFeatureVocalToBeatDifferentialDb] = std::clamp(vbr, -30.0f, 30.0f);

                // [12] beatMaskingCollisionDb (cross-spectral clash across F1, F2, F3)
                const float bF1Db = toBandDb(sumSqBeatF1);
                const float bF2Db = toBandDb(sumSqBeatF2);
                const float bF3Db = toBandDb(sumSqBeatF3);

                const float clashF1 = std::max(0.0f, bF1Db - outFeatures[kFeatureF1EnergyDb]);
                const float clashF2 = std::max(0.0f, bF2Db - outFeatures[kFeatureF2EnergyDb]);
                const float clashF3 = std::max(0.0f, bF3Db - outFeatures[kFeatureF3EnergyDb]);

                const float maxClash = std::max({ clashF1, clashF2, clashF3 });
                outFeatures[kFeatureBeatMaskingCollisionDb] = std::clamp(maxClash, 0.0f, 24.0f);
            } else {
                outFeatures[kFeatureBeatMaskingCollisionDb] = 0.0f;
                outFeatures[kFeatureBeatRmsDb] = 0.0f;
                outFeatures[kFeatureVocalToBeatDifferentialDb] = 0.0f;
            }
        } else {
            outFeatures[kFeatureBeatMaskingCollisionDb] = 0.0f;
            outFeatures[kFeatureBeatRmsDb] = 0.0f;
            outFeatures[kFeatureVocalToBeatDifferentialDb] = 0.0f;
        }

        // [15] styleIndex
        outFeatures[kFeatureStyleIndex] = static_cast<float>(std::clamp(styleIndex, 0, 3));
    }

private:
    void initWindow() noexcept {
        // Hann window: w[n] = 0.5 * (1 - cos(2*pi*n / (N-1)))
        for (size_t n = 0; n < kFFTSize; ++n) {
            const float angle = 2.0f * PI * static_cast<float>(n) / static_cast<float>(kFFTSize - 1);
            windowCoeffs[n] = 0.5f * (1.0f - std::cos(angle));
        }
    }

    // High performance in-place Radix-2 Cooley-Tukey FFT (zero heap)
    static void computeFFT(float* real, float* imag, size_t n) noexcept {
        // 1. Bit-reversal permutation
        size_t j = 0;
        for (size_t i = 0; i < n - 1; ++i) {
            if (i < j) {
                std::swap(real[i], real[j]);
                std::swap(imag[i], imag[j]);
            }
            size_t k = n >> 1;
            while (k <= j) {
                j -= k;
                k >>= 1;
            }
            j += k;
        }

        // 2. Butterfly computation
        for (size_t len = 2; len <= n; len <<= 1) {
            const float angle = -2.0f * PI / static_cast<float>(len);
            const float wStepRe = std::cos(angle);
            const float wStepIm = std::sin(angle);

            for (size_t i = 0; i < n; i += len) {
                float wRe = 1.0f;
                float wIm = 0.0f;
                const size_t halfLen = len >> 1;

                for (size_t u = 0; u < halfLen; ++u) {
                    const size_t idxA = i + u;
                    const size_t idxB = idxA + halfLen;

                    const float tRe = wRe * real[idxB] - wIm * imag[idxB];
                    const float tIm = wRe * imag[idxB] + wIm * real[idxB];

                    real[idxB] = real[idxA] - tRe;
                    imag[idxB] = imag[idxA] - tIm;
                    real[idxA] += tRe;
                    imag[idxA] += tIm;

                    const float nextWRe = wRe * wStepRe - wIm * wStepIm;
                    const float nextWIm = wRe * wStepIm + wIm * wStepRe;
                    wRe = nextWRe;
                    wIm = nextWIm;
                }
            }
        }
    }

    float sr = 44100.0f;
    float binWidthHz = 86.1328f;

    std::array<float, kFFTSize> windowCoeffs{};
    std::array<float, kFFTSize> fifoBuffer{};
    size_t fifoWriteIdx = 0;

    std::array<float, kFFTSize> fftReal{};
    std::array<float, kFFTSize> fftImag{};
    std::array<float, kHalfFFT> prevMagSpectrum{};

    // Vocal Filterbank
    ZDFSVF64 svfSubRumble;
    ZDFSVF64 svfF1;
    ZDFSVF64 svfF2;
    ZDFSVF64 svfF3;
    ZDFSVF64 svfSibilant;
    ZDFSVF64 svfAir;

    // Sub-acoustic DC Blocker (<15 Hz) to immunize neural feature extraction from mic/preamp DC bias
    double dcBlockX1 = 0.0;
    double dcBlockY1 = 0.0;

    // Beat Sidechain Filterbank
    ZDFSVF64 svfBeatF1;
    ZDFSVF64 svfBeatF2;
    ZDFSVF64 svfBeatF3;

    float smoothedVocalRms = 0.0001f;
    float rmsSmoothCoeff = 0.05f;
    float prevCentroid = 1000.0f;
    float prevFlux = 0.0f;
    float prevFlatness = 0.0f;
};

// =============================================================================
// NeuralInferenceEngine
// Ultra-fast 2-Layer Neural Brain (Dense 16->32 + GELU, GRU-16, Output 16->8).
// Bounded Sigmoidal Audio Range Mappings, Zero Heap Allocations.
// =============================================================================
class NeuralInferenceEngine {
public:
    static constexpr size_t kNumInputs = 16;
    static constexpr size_t kNumL1 = 32;
    static constexpr size_t kNumGruHidden = 16;
    static constexpr size_t kNumOutputs = 8;

    enum class ActivationType {
        FastGELU = 0,
        LeakyReLU
    };

    NeuralInferenceEngine() noexcept {
        reset();
    }

    void reset() noexcept {
        gruHiddenState.fill(0.0f);
        lastPredictions.fill(0.0f);
        // Default resting state for ratio
        lastPredictions[kPredCompRatio] = 4.0f;
    }

    void setActivationType(ActivationType type) noexcept {
        activation = type;
    }

    // Branchless Fast Sigmoid: 1 / (1 + exp(-x))
    static inline float fastSigmoid(float x) noexcept {
        if (x >= 16.0f) return 1.0f;
        if (x <= -16.0f) return 0.0f;
        return 1.0f / (1.0f + fastExp(-x));
    }

    // Branchless Fast GELU: 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))
    static inline float fastGELU(float x) noexcept {
        if (x <= -6.0f) return 0.0f;
        if (x >= 6.0f) return x;
        const float x3 = x * x * x;
        const float inner = 0.79788456f * (x + 0.044715f * x3);
        return 0.5f * x * (1.0f + fastTanh(inner));
    }

    // Fast LeakyReLU: x >= 0 ? x : 0.1 * x
    static inline float fastLeakyReLU(float x, float negativeSlope = 0.1f) noexcept {
        return (x >= 0.0f) ? x : (negativeSlope * x);
    }

    // Run full neural inference across Layer 1, GRU temporal cell, and Output Projection
    void infer(const std::array<float, kNumInputs>& features,
               std::array<float, kNumOutputs>& outPredictions,
               const VocalCraftWeightSet* weights = nullptr) noexcept
    {
        if (weights == nullptr) {
            weights = &vocalcraft_weights::kFactoryWeightSet;
        }

        // ---------------------------------------------------------------------
        // 0. Feature Normalization: (features - mean) * invScale
        // ---------------------------------------------------------------------
        std::array<float, kNumInputs> normX;
        for (size_t i = 0; i < kNumInputs; ++i) {
            normX[i] = (features[i] - weights->featureMeans[i]) * weights->featureInvScales[i];
        }

        // ---------------------------------------------------------------------
        // 1. Layer 1: Dense 16 -> 32 with fast GELU / LeakyReLU
        // ---------------------------------------------------------------------
        std::array<float, kNumL1> y1;
        for (size_t j = 0; j < kNumL1; ++j) {
            float sum = weights->layer1Bias[j];
            const auto& rowWeights = weights->layer1Weights[j];
            for (size_t i = 0; i < kNumInputs; ++i) {
                sum += rowWeights[i] * normX[i];
            }

            if (activation == ActivationType::FastGELU)
                y1[j] = fastGELU(sum);
            else
                y1[j] = fastLeakyReLU(sum, 0.1f);
        }

        // ---------------------------------------------------------------------
        // 2. Layer 2: Temporal Memory GRU Cell (16 States)
        // ---------------------------------------------------------------------
        // Reset gate: r = sigmoid(W_r * y1 + U_r * h_prev + b_r)
        std::array<float, kNumGruHidden> r;
        for (size_t j = 0; j < kNumGruHidden; ++j) {
            float sum = weights->gruBiasR[j];
            const auto& rowUr = weights->gruWeightsUr[j];
            for (size_t h = 0; h < kNumGruHidden; ++h) {
                sum += rowUr[h] * gruHiddenState[h];
            }
            const auto& rowWr = weights->gruWeightsWr[j];
            for (size_t k = 0; k < kNumL1; ++k) {
                sum += rowWr[k] * y1[k];
            }
            r[j] = fastSigmoid(sum);
        }

        // Update gate: z = sigmoid(W_z * y1 + U_z * h_prev + b_z)
        std::array<float, kNumGruHidden> z;
        for (size_t j = 0; j < kNumGruHidden; ++j) {
            float sum = weights->gruBiasZ[j];
            const auto& rowUz = weights->gruWeightsUz[j];
            for (size_t h = 0; h < kNumGruHidden; ++h) {
                sum += rowUz[h] * gruHiddenState[h];
            }
            const auto& rowWz = weights->gruWeightsWz[j];
            for (size_t k = 0; k < kNumL1; ++k) {
                sum += rowWz[k] * y1[k];
            }
            z[j] = fastSigmoid(sum);
        }

        // Precompute reset-gated hidden state: r_h = r * h_prev
        std::array<float, kNumGruHidden> resetHidden;
        for (size_t h = 0; h < kNumGruHidden; ++h) {
            resetHidden[h] = r[h] * gruHiddenState[h];
        }

        // Candidate hidden state: h_cand = tanh(W_h * y1 + U_h * (r * h_prev) + b_h)
        std::array<float, kNumGruHidden> hCand;
        for (size_t j = 0; j < kNumGruHidden; ++j) {
            float sum = weights->gruBiasH[j];
            const auto& rowUh = weights->gruWeightsUh[j];
            for (size_t h = 0; h < kNumGruHidden; ++h) {
                sum += rowUh[h] * resetHidden[h];
            }
            const auto& rowWh = weights->gruWeightsWh[j];
            for (size_t k = 0; k < kNumL1; ++k) {
                sum += rowWh[k] * y1[k];
            }
            hCand[j] = fastTanh(sum);
        }

        // New hidden state: h_t = (1 - z) * h_prev + z * h_cand
        // Guaranteed Lyapunov Contraction Mapping (||h_t||_inf <= 1.0)
        for (size_t j = 0; j < kNumGruHidden; ++j) {
            gruHiddenState[j] = (1.0f - z[j]) * gruHiddenState[j] + z[j] * hCand[j];
            if (std::abs(gruHiddenState[j]) < 1.0e-15f) {
                gruHiddenState[j] = 0.0f;
            } else {
                gruHiddenState[j] = std::clamp(gruHiddenState[j], -1.0f, 1.0f);
            }
        }

        // ---------------------------------------------------------------------
        // 3. Layer 3: Output Projection 16 -> 8
        // ---------------------------------------------------------------------
        std::array<float, kNumOutputs> u;
        for (size_t k = 0; k < kNumOutputs; ++k) {
            float sum = weights->outputBias[k];
            const auto& rowWout = weights->outputWeights[k];
            for (size_t j = 0; j < kNumGruHidden; ++j) {
                sum += rowWout[j] * gruHiddenState[j];
            }
            u[k] = sum;
        }

        // ---------------------------------------------------------------------
        // 4. Bounded Audio Mapping (Sigmoids scaled to physical studio domains)
        // ---------------------------------------------------------------------
        // [0] predictedCompRatio: target compression ratio [1.2, 12.0]
        outPredictions[kPredCompRatio] = 1.2f + 10.8f * fastSigmoid(u[kPredCompRatio]);

        // [1] dynamicConsonantPunch: consonant punch weight [0.0, 1.0]
        outPredictions[kPredConsonantPunch] = fastSigmoid(u[kPredConsonantPunch]);

        // [2] acousticResonanceMask: true room resonance discriminator [0.0, 1.0]
        outPredictions[kPredAcousticResonanceMask] = fastSigmoid(u[kPredAcousticResonanceMask]);

        // [3] deesserThresholdOffsetDb: adaptive sibilance trim [-12.0, +6.0] dB
        outPredictions[kPredDeesserThresholdOffsetDb] = -12.0f + 18.0f * fastSigmoid(u[kPredDeesserThresholdOffsetDb]);

        // [4] deesserDepthDb: target sibilance reduction depth [0.0, 14.0] dB
        outPredictions[kPredDeesserDepthDb] = 14.0f * fastSigmoid(u[kPredDeesserDepthDb]);

        // [5] beatPocketCarveDb: optimal unmask frequency carve depth [0.0, 9.0] dB
        outPredictions[kPredBeatPocketCarveDb] = 9.0f * fastSigmoid(u[kPredBeatPocketCarveDb]);

        // [6] airSheenBoostDb: mix-ready high frequency shelf target [0.0, 6.0] dB
        outPredictions[kPredAirSheenBoostDb] = 6.0f * fastSigmoid(u[kPredAirSheenBoostDb]);

        // [7] dynamicFaderRideDb: VBR micro-fader riding offset [-4.0, +4.0] dB
        outPredictions[kPredDynamicFaderRideDb] = -4.0f + 8.0f * fastSigmoid(u[kPredDynamicFaderRideDb]);

        // Silence protection: if input is digital silence (< -80 dBFS), decay adjustments smoothly to zero
        if (features[kFeatureInputRmsDb] < -80.0f) {
            outPredictions[kPredConsonantPunch] = 0.0f;
            outPredictions[kPredAcousticResonanceMask] = 0.0f;
            outPredictions[kPredDeesserDepthDb] = 0.0f;
            outPredictions[kPredBeatPocketCarveDb] = 0.0f;
            outPredictions[kPredDynamicFaderRideDb] = 0.0f;
        }

        // Beat sidechain protection: if beat is absent or silent, zero out pocket carve and fader ride
        if (features[kFeatureBeatRmsDb] <= -80.0f || features[kFeatureBeatMaskingCollisionDb] <= 0.001f) {
            outPredictions[kPredBeatPocketCarveDb] = 0.0f;
        }
        if (features[kFeatureBeatRmsDb] <= -80.0f) {
            outPredictions[kPredDynamicFaderRideDb] = 0.0f;
        }

        lastPredictions = outPredictions;
    }

    const std::array<float, kNumGruHidden>& getHiddenState() const noexcept {
        return gruHiddenState;
    }

private:
    ActivationType activation = ActivationType::FastGELU;
    std::array<float, kNumGruHidden> gruHiddenState{};
    std::array<float, kNumOutputs> lastPredictions{};
};

// =============================================================================
// VocalCraftNeuralBrain
// Top-Level Orchestrator combining NeuralFeatureExtractor and NeuralInferenceEngine.
// Provides prepare(), reset(), analyzeAndInfer(), and thread-safe lock-free
// telemetry snapshots for 60 FPS GUI visualizers.
// =============================================================================
class VocalCraftNeuralBrain {
public:
    VocalCraftNeuralBrain() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 0.0 ? sampleRate : 44100.0;
        featureExtractor.prepare(sr);
        inferenceEngine.reset();
        reset();
    }

    void reset() noexcept {
        featureExtractor.reset();
        inferenceEngine.reset();
        inferenceCount.store(0, std::memory_order_relaxed);
        lastInferenceTimeUs.store(0.0f, std::memory_order_relaxed);

        for (auto& f : atomicFeatures) f.store(0.0f, std::memory_order_relaxed);
        atomicFeatures[kFeatureInputRmsDb].store(-90.0f, std::memory_order_relaxed);
        atomicFeatures[kFeatureCrestFactor].store(1.0f, std::memory_order_relaxed);
        atomicFeatures[kFeatureSpectralCentroidHz].store(1000.0f, std::memory_order_relaxed);

        for (auto& p : atomicPredictions) p.store(0.0f, std::memory_order_relaxed);
        atomicPredictions[kPredCompRatio].store(4.0f, std::memory_order_relaxed);

        seqlock.store(0, std::memory_order_relaxed);
        telemetryBuffers[0] = NeuralBrainTelemetry{};
        telemetryBuffers[1] = NeuralBrainTelemetry{};
    }

    // Audio thread: Full stereo vocal analysis & neural inference with optional beat sidechain
    void analyzeAndInfer(const float* vocalL, const float* vocalR,
                         const float* beatL, const float* beatR,
                         int numSamples, int styleIndex = 0) noexcept
    {
        if (numSamples <= 0 || vocalL == nullptr)
            return;

        const auto startTime = std::chrono::high_resolution_clock::now();

        // 1. Extract 16 physical vocal and beat features
        std::array<float, kNumFeatures> features;
        featureExtractor.extractFeatures(vocalL, vocalR, beatL, beatR, numSamples, styleIndex, features);

        // 2. Run Neural Inference Engine (Layer 1 + GRU + Layer 3)
        std::array<float, kNumPredictions> predictions;
        const VocalCraftWeightSet* activeW = weightsManager.getActiveWeights();
        inferenceEngine.infer(features, predictions, activeW);

        const auto endTime = std::chrono::high_resolution_clock::now();
        const float elapsedUs = std::chrono::duration<float, std::micro>(endTime - startTime).count();

        // 3. Update Thread-Safe Atomics
        for (size_t i = 0; i < kNumFeatures; ++i) {
            atomicFeatures[i].store(features[i], std::memory_order_relaxed);
        }
        for (size_t i = 0; i < kNumPredictions; ++i) {
            atomicPredictions[i].store(predictions[i], std::memory_order_relaxed);
        }

        const uint64_t count = inferenceCount.fetch_add(1, std::memory_order_relaxed) + 1;
        lastInferenceTimeUs.store(elapsedUs, std::memory_order_relaxed);

        // 4. Update Seqlock Double-Buffered Telemetry Snapshot (Tear-Free GUI Reads)
        NeuralBrainTelemetry snap;
        snap.features = features;
        snap.predictions = predictions;
        snap.inputRmsDb = features[kFeatureInputRmsDb];
        snap.crestFactor = features[kFeatureCrestFactor];
        snap.spectralCentroidHz = features[kFeatureSpectralCentroidHz];
        snap.spectralFlux = features[kFeatureSpectralFlux];
        snap.spectralFlatness = features[kFeatureSpectralFlatness];
        snap.f1EnergyDb = features[kFeatureF1EnergyDb];
        snap.f2EnergyDb = features[kFeatureF2EnergyDb];
        snap.f3EnergyDb = features[kFeatureF3EnergyDb];
        snap.sibilantEnergyDb = features[kFeatureSibilantEnergyDb];
        snap.airEnergyDb = features[kFeatureAirEnergyDb];
        snap.subRumbleEnergyDb = features[kFeatureSubRumbleEnergyDb];
        snap.phonemeClass = static_cast<int>(features[kFeaturePhonemeClass]);
        snap.beatMaskingCollisionDb = features[kFeatureBeatMaskingCollisionDb];
        snap.beatRmsDb = features[kFeatureBeatRmsDb];
        snap.vocalToBeatDifferentialDb = features[kFeatureVocalToBeatDifferentialDb];
        snap.styleIndex = static_cast<int>(features[kFeatureStyleIndex]);

        snap.predictedCompRatio = predictions[kPredCompRatio];
        snap.dynamicConsonantPunch = predictions[kPredConsonantPunch];
        snap.acousticResonanceMask = predictions[kPredAcousticResonanceMask];
        snap.deesserThresholdOffsetDb = predictions[kPredDeesserThresholdOffsetDb];
        snap.deesserDepthDb = predictions[kPredDeesserDepthDb];
        snap.beatPocketCarveDb = predictions[kPredBeatPocketCarveDb];
        snap.airSheenBoostDb = predictions[kPredAirSheenBoostDb];
        snap.dynamicFaderRideDb = predictions[kPredDynamicFaderRideDb];
        snap.inferenceCount = count;
        snap.lastInferenceTimeUs = elapsedUs;
        snap.isCustomModel = weightsManager.isCustomLoaded();
        snap.modelLoss = weightsManager.getLossMetric();

        // 5. Telemetry Collection (Decimated 16x for audio thread safety & low overhead)
        if (features[kFeatureInputRmsDb] > -60.0f) {
            if (++telemetryDecimationCounter >= 16) {
                telemetryDecimationCounter = 0;
                std::array<float, 8> userParams = {
                    predictions[kPredCompRatio],
                    predictions[kPredConsonantPunch],
                    predictions[kPredAcousticResonanceMask],
                    predictions[kPredDeesserThresholdOffsetDb],
                    predictions[kPredDeesserDepthDb],
                    predictions[kPredBeatPocketCarveDb],
                    predictions[kPredAirSheenBoostDb],
                    predictions[kPredDynamicFaderRideDb]
                };
                telemetryCollector.pushFromAudioThread(
                    features,
                    userParams,
                    elapsedUs,
                    styleIndex,
                    count
                );
            }
        }

        // Seqlock write sequence
        const uint32_t seq = seqlock.load(std::memory_order_relaxed);
        seqlock.store(seq + 1, std::memory_order_release); // Odd = write in progress

        const size_t writeIdx = (seq >> 1) & 1;
        telemetryBuffers[writeIdx] = snap;

        seqlock.store(seq + 2, std::memory_order_release); // Even = stable
    }

    // Audio thread: Mono vocal overload
    void analyzeAndInfer(const float* vocalMono, const float* beatMono,
                         int numSamples, int styleIndex = 0) noexcept
    {
        analyzeAndInfer(vocalMono, nullptr, beatMono, nullptr, numSamples, styleIndex);
    }

    // GUI thread: Lock-free snapshot query (60 FPS tear-free)
    NeuralBrainTelemetry getTelemetrySnapshot() const noexcept {
        NeuralBrainTelemetry snapshot;
        uint32_t s1 = 0;
        uint32_t s2 = 0;
        int spins = 0;

        do {
            s1 = seqlock.load(std::memory_order_acquire);
            if (s1 & 1) { // Audio thread is writing, brief retry
                continue;
            }
            const size_t readIdx = ((s1 >> 1) > 0) ? (((s1 >> 1) - 1) & 1) : 0;
            snapshot = telemetryBuffers[readIdx];
            s2 = seqlock.load(std::memory_order_acquire);
        } while ((s1 != s2 || (s1 & 1)) && ++spins < 8);

        // Fallback: If contention persists, load from individual atomic values
        if (s1 != s2 || (s1 & 1)) {
            for (size_t i = 0; i < kNumFeatures; ++i)
                snapshot.features[i] = atomicFeatures[i].load(std::memory_order_relaxed);
            for (size_t i = 0; i < kNumPredictions; ++i)
                snapshot.predictions[i] = atomicPredictions[i].load(std::memory_order_relaxed);

            snapshot.inputRmsDb = snapshot.features[kFeatureInputRmsDb];
            snapshot.crestFactor = snapshot.features[kFeatureCrestFactor];
            snapshot.spectralCentroidHz = snapshot.features[kFeatureSpectralCentroidHz];
            snapshot.spectralFlux = snapshot.features[kFeatureSpectralFlux];
            snapshot.spectralFlatness = snapshot.features[kFeatureSpectralFlatness];
            snapshot.f1EnergyDb = snapshot.features[kFeatureF1EnergyDb];
            snapshot.f2EnergyDb = snapshot.features[kFeatureF2EnergyDb];
            snapshot.f3EnergyDb = snapshot.features[kFeatureF3EnergyDb];
            snapshot.sibilantEnergyDb = snapshot.features[kFeatureSibilantEnergyDb];
            snapshot.airEnergyDb = snapshot.features[kFeatureAirEnergyDb];
            snapshot.subRumbleEnergyDb = snapshot.features[kFeatureSubRumbleEnergyDb];
            snapshot.phonemeClass = static_cast<int>(snapshot.features[kFeaturePhonemeClass]);
            snapshot.beatMaskingCollisionDb = snapshot.features[kFeatureBeatMaskingCollisionDb];
            snapshot.beatRmsDb = snapshot.features[kFeatureBeatRmsDb];
            snapshot.vocalToBeatDifferentialDb = snapshot.features[kFeatureVocalToBeatDifferentialDb];
            snapshot.styleIndex = static_cast<int>(snapshot.features[kFeatureStyleIndex]);

            snapshot.predictedCompRatio = snapshot.predictions[kPredCompRatio];
            snapshot.dynamicConsonantPunch = snapshot.predictions[kPredConsonantPunch];
            snapshot.acousticResonanceMask = snapshot.predictions[kPredAcousticResonanceMask];
            snapshot.deesserThresholdOffsetDb = snapshot.predictions[kPredDeesserThresholdOffsetDb];
            snapshot.deesserDepthDb = snapshot.predictions[kPredDeesserDepthDb];
            snapshot.beatPocketCarveDb = snapshot.predictions[kPredBeatPocketCarveDb];
            snapshot.airSheenBoostDb = snapshot.predictions[kPredAirSheenBoostDb];
            snapshot.dynamicFaderRideDb = snapshot.predictions[kPredDynamicFaderRideDb];
            snapshot.inferenceCount = inferenceCount.load(std::memory_order_relaxed);
            snapshot.lastInferenceTimeUs = lastInferenceTimeUs.load(std::memory_order_relaxed);
        }

        return snapshot;
    }

    // Direct atomic queries for fast individual GUI widget polling
    float getFeature(VocalFeatureIndex idx) const noexcept {
        const size_t i = static_cast<size_t>(idx);
        return (i < kNumFeatures) ? atomicFeatures[i].load(std::memory_order_relaxed) : 0.0f;
    }

    float getPrediction(NeuralPredictionIndex idx) const noexcept {
        const size_t i = static_cast<size_t>(idx);
        return (i < kNumPredictions) ? atomicPredictions[i].load(std::memory_order_relaxed) : 0.0f;
    }

    float getPredictedCompRatio() const noexcept {
        return atomicPredictions[kPredCompRatio].load(std::memory_order_relaxed);
    }

    float getDynamicConsonantPunch() const noexcept {
        return atomicPredictions[kPredConsonantPunch].load(std::memory_order_relaxed);
    }

    float getAcousticResonanceMask() const noexcept {
        return atomicPredictions[kPredAcousticResonanceMask].load(std::memory_order_relaxed);
    }

    float getDeesserThresholdOffsetDb() const noexcept {
        return atomicPredictions[kPredDeesserThresholdOffsetDb].load(std::memory_order_relaxed);
    }

    float getDeesserDepthDb() const noexcept {
        return atomicPredictions[kPredDeesserDepthDb].load(std::memory_order_relaxed);
    }

    float getBeatPocketCarveDb() const noexcept {
        return atomicPredictions[kPredBeatPocketCarveDb].load(std::memory_order_relaxed);
    }

    float getAirSheenBoostDb() const noexcept {
        return atomicPredictions[kPredAirSheenBoostDb].load(std::memory_order_relaxed);
    }

    float getDynamicFaderRideDb() const noexcept {
        return atomicPredictions[kPredDynamicFaderRideDb].load(std::memory_order_relaxed);
    }

    int getPhonemeClass() const noexcept {
        return static_cast<int>(atomicFeatures[kFeaturePhonemeClass].load(std::memory_order_relaxed));
    }

    uint64_t getInferenceCount() const noexcept {
        return inferenceCount.load(std::memory_order_relaxed);
    }

    float getLastInferenceTimeUs() const noexcept {
        return lastInferenceTimeUs.load(std::memory_order_relaxed);
    }

    // Component accessors
    NeuralFeatureExtractor& getFeatureExtractor() noexcept { return featureExtractor; }
    const NeuralFeatureExtractor& getFeatureExtractor() const noexcept { return featureExtractor; }

    NeuralInferenceEngine& getInferenceEngine() noexcept { return inferenceEngine; }
    const NeuralInferenceEngine& getInferenceEngine() const noexcept { return inferenceEngine; }

    VocalCraftWeightsManager& getWeightsManager() noexcept { return weightsManager; }
    const VocalCraftWeightsManager& getWeightsManager() const noexcept { return weightsManager; }
    TelemetryCollector<512>& getTelemetryCollector() noexcept { return telemetryCollector; }
    const TelemetryCollector<512>& getTelemetryCollector() const noexcept { return telemetryCollector; }

private:
    double sr = 44100.0;
    VocalCraftWeightsManager weightsManager;
    TelemetryCollector<512> telemetryCollector;
    uint32_t telemetryDecimationCounter = 0;

    NeuralFeatureExtractor featureExtractor;
    NeuralInferenceEngine inferenceEngine;

    // GUI Telemetry Atomics
    std::array<std::atomic<float>, kNumFeatures> atomicFeatures;
    std::array<std::atomic<float>, kNumPredictions> atomicPredictions;
    std::atomic<uint64_t> inferenceCount{0};
    std::atomic<float> lastInferenceTimeUs{0.0f};

    // Double-buffered Seqlock snapshot buffers
    mutable std::atomic<uint32_t> seqlock{0};
    std::array<NeuralBrainTelemetry, 2> telemetryBuffers{};
};

} // namespace dsp171
