#pragma once

#include <cmath>
#include <algorithm>
#include <cstdint>
#include "Common.h"
#include "FastMath.h"
#include "SafetyCeiling.h"

namespace dsp171 {

// =============================================================================
// SMART LOUDNESS WORKFLOW & DELTA AUDITION ENGINE
//
// Designed under Agente 22 (smart-loudness-workflow-specialist).
//
// Key Features:
// 1. ITU-R BS.1770-4 / EBU R128 K-Weighted Momentary Loudness Tracker (400 ms window).
// 2. Smart Auto-Gain (Loudness Matching): Eliminates psychoacoustic volume bias
//    by automatically matching processed output loudness to input dry loudness.
// 3. Delta Audition Mode: Solos difference (y - x) to evaluate audio degradation or enhancement.
// 4. Output Safety Soft Ceiling (-0.09 dBFS Hermite smooth limiter).
//
// Hard real-time C++20, 0 latency, zero dynamic heap allocations.
// =============================================================================

class SmartLoudnessWorkflow {
public:
    SmartLoudnessWorkflow() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        fs = (sampleRate > 1000.0) ? sampleRate : 48000.0;
        invFs = 1.0 / fs;
        reset();
        updateKWeightingFilters();
        tpLimiterL.prepare(sampleRate);
        tpLimiterR.prepare(sampleRate);
    }

    void reset() noexcept {
        inShelfS1_L = 0.0; inShelfS2_L = 0.0;
        inHpfS1_L = 0.0; inHpfS2_L = 0.0;
        inShelfS1_R = 0.0; inShelfS2_R = 0.0;
        inHpfS1_R = 0.0; inHpfS2_R = 0.0;

        outShelfS1_L = 0.0; outShelfS2_L = 0.0;
        outHpfS1_L = 0.0; outHpfS2_L = 0.0;
        outShelfS1_R = 0.0; outShelfS2_R = 0.0;
        outHpfS1_R = 0.0; outHpfS2_R = 0.0;

        inPowerMom = 1e-7f;
        outPowerMom = 1e-7f;
        autoGainLinear = 1.0f;
        targetAutoGainLinear = 1.0f;
        tpLimiterL.reset();
        tpLimiterR.reset();
    }

    // --- Controls ---
    void setAutoGainEnabled(bool enable) noexcept { autoGainEnabled = enable; }
    void setDeltaListenEnabled(bool enable) noexcept { deltaListenEnabled = enable; }
    void setMasterTrim(float trimDb) noexcept {
        masterTrimDb = std::clamp(trimDb, -24.0f, 12.0f);
        manualTrimLinear = std::pow(10.0f, masterTrimDb * 0.05f);
    }

    // Telemetry
    [[nodiscard]] float getInputLUFS() const noexcept {
        return (inPowerMom > 1e-12f) ? -0.691f + 10.0f * std::log10(inPowerMom) : -70.0f;
    }

    [[nodiscard]] float getOutputLUFS() const noexcept {
        return (outPowerMom > 1e-12f) ? -0.691f + 10.0f * std::log10(outPowerMom) : -70.0f;
    }

    [[nodiscard]] float getAppliedAutoGainDb() const noexcept {
        return (autoGainLinear > 1e-5f) ? 20.0f * std::log10(autoGainLinear) : 0.0f;
    }

    // --- Loudness Analysis for Dry Input ---
    void analyzeInputBlock(const float* const* channelData, int numChannels, int numSamples) noexcept {
        if (numChannels <= 0 || numSamples <= 0) return;
        const float* left = channelData[0];
        const float* right = (numChannels > 1) ? channelData[1] : nullptr;

        const float alphaMom = static_cast<float>(1.0 - std::exp(-1.0 / (0.400 * fs))); // 400ms window

        for (int i = 0; i < numSamples; ++i) {
            float sL = filterKWeightingInL(left[i]);
            float sR = right ? filterKWeightingInR(right[i]) : sL;
            float p = 0.5f * (sL * sL + sR * sR);
            inPowerMom += alphaMom * (p - inPowerMom);
        }
    }

    // --- Final Master Processing Stage (Applying Auto-Gain, Delta, Safety Ceiling) ---
    void processMaster(float* const* channelData, const float* const* dryInputData,
                       int numChannels, int numSamples) noexcept {
        if (numChannels <= 0 || numSamples <= 0) return;

        float* left = channelData[0];
        float* right = (numChannels > 1) ? channelData[1] : nullptr;

        const float* dryL = dryInputData ? dryInputData[0] : nullptr;
        const float* dryR = (dryInputData && numChannels > 1) ? dryInputData[1] : dryL;

        const float alphaMom = static_cast<float>(1.0 - std::exp(-1.0 / (0.400 * fs)));

        // Update target auto-gain based on K-weighted momentary powers
        if (autoGainEnabled && inPowerMom > 1e-6f && outPowerMom > 1e-6f) {
            // Gain = sqrt(P_in / P_out)
            float ratio = std::sqrt(inPowerMom / (outPowerMom + 1e-8f));
            targetAutoGainLinear = std::clamp(ratio, 0.125f, 4.0f); // Limit within +/- 12 dB
        } else {
            targetAutoGainLinear = 1.0f;
        }

        const float ceilingThreshold = 0.9897f; // -0.09 dBFS

        for (int i = 0; i < numSamples; ++i) {
            // Smoothly interpolate auto-gain
            autoGainLinear += 0.005f * (targetAutoGainLinear - autoGainLinear);

            float totalGain = manualTrimLinear;
            if (autoGainEnabled) {
                totalGain *= autoGainLinear;
            }

            float wetL = left[i] * totalGain;
            float wetR = right ? (right[i] * totalGain) : wetL;

            // Track Output Loudness
            float sL = filterKWeightingOutL(wetL);
            float sR = right ? filterKWeightingOutR(wetR) : sL;
            float p = 0.5f * (sL * sL + sR * sR);
            outPowerMom += alphaMom * (p - outPowerMom);

            // Delta Audition Mode (solo wet - dry difference)
            if (deltaListenEnabled && dryL) {
                wetL = wetL - dryL[i];
                if (right && dryR) {
                    wetR = wetR - dryR[i];
                }
            }

            // Safety Hermite Soft Ceiling + Strict True-Peak Guard (-0.15 dBTP / -0.65 dBTP a 44.1k per compensare Gibbs sinc ringing)
            // Utilizzo del limiter stereo-linked per garantire totale coerenza dell'immagine vocale centrale
            const float tpCeilingDb = (fs <= 44100.0) ? -0.65f : -0.15f;
            const float softCeilLin = (fs <= 44100.0) ? 0.925f : 0.9880f;
            float safeL = applySafetyCeiling(wetL, softCeilLin);
            float safeR = right ? applySafetyCeiling(wetR, softCeilLin) : safeL;

            if (right) {
                TruePeakLimiter::processStereoPair(tpLimiterL, tpLimiterR, safeL, safeR, left[i], right[i], tpCeilingDb);
            } else {
                left[i] = tpLimiterL.processSample(safeL, tpCeilingDb);
            }
        }
    }

private:
    double fs = 48000.0;
    double invFs = 1.0 / 48000.0;

    bool autoGainEnabled = false;
    bool deltaListenEnabled = false;
    float masterTrimDb = 0.0f;
    float manualTrimLinear = 1.0f;

    float inPowerMom = 1e-7f;
    float outPowerMom = 1e-7f;
    float autoGainLinear = 1.0f;
    float targetAutoGainLinear = 1.0f;

    // ITU-R BS.1770 K-Weighting Filter Coeffs & States
    // Stage 1: High-Shelf (+4 dB @ 1.5 kHz)
    double shelfG = 0.1, shelfK = 1.414, shelfA = 1.5849;
    // Stage 2: High-Pass RLB (fc = 100 Hz, Q = 0.5)
    double hpfG = 0.01, hpfK = 2.0;

    double inShelfS1_L = 0.0, inShelfS2_L = 0.0;
    double inHpfS1_L = 0.0, inHpfS2_L = 0.0;
    double inShelfS1_R = 0.0, inShelfS2_R = 0.0;
    double inHpfS1_R = 0.0, inHpfS2_R = 0.0;

    double outShelfS1_L = 0.0, outShelfS2_L = 0.0;
    double outHpfS1_L = 0.0, outHpfS2_L = 0.0;
    double outShelfS1_R = 0.0, outShelfS2_R = 0.0;
    double outHpfS1_R = 0.0, outHpfS2_R = 0.0;

    void updateKWeightingFilters() noexcept {
        // High Shelf (+4 dB @ 1500 Hz)
        shelfA = std::pow(10.0, 4.0 * 0.025);
        double w0 = 2.0 * 3.14159265358979323846 * 1500.0;
        shelfG = std::tan(w0 * 0.5 * invFs) / std::sqrt(shelfA);
        shelfK = 1.0 / 0.7071;

        // High Pass RLB (100 Hz, Q = 0.5)
        double wHpf = 2.0 * 3.14159265358979323846 * 100.0;
        hpfG = std::tan(wHpf * 0.5 * invFs);
        hpfK = 1.0 / 0.5;
    }

    float filterKWeightingInL(float in) noexcept {
        double v0 = static_cast<double>(in);
        double d = 1.0 / (1.0 + shelfG * (shelfG + shelfK));
        double hp = (v0 - (shelfG + shelfK) * inShelfS1_L - inShelfS2_L) * d;
        double bp = shelfG * hp + inShelfS1_L;
        double lp = shelfG * bp + inShelfS2_L;
        inShelfS1_L = shelfG * hp + bp;
        inShelfS2_L = shelfG * bp + lp;
        double shelfOut = v0 + (shelfA * shelfA - 1.0) * (hp + (shelfK / shelfA) * bp);

        double dH = 1.0 / (1.0 + hpfG * (hpfG + hpfK));
        double hpH = (shelfOut - (hpfG + hpfK) * inHpfS1_L - inHpfS2_L) * dH;
        double bpH = hpfG * hpH + inHpfS1_L;
        double lpH = hpfG * bpH + inHpfS2_L;
        inHpfS1_L = hpfG * hpH + bpH;
        inHpfS2_L = hpfG * bpH + lpH;
        return static_cast<float>(hpH);
    }

    float filterKWeightingInR(float in) noexcept {
        double v0 = static_cast<double>(in);
        double d = 1.0 / (1.0 + shelfG * (shelfG + shelfK));
        double hp = (v0 - (shelfG + shelfK) * inShelfS1_R - inShelfS2_R) * d;
        double bp = shelfG * hp + inShelfS1_R;
        double lp = shelfG * bp + inShelfS2_R;
        inShelfS1_R = shelfG * hp + bp;
        inShelfS2_R = shelfG * bp + lp;
        double shelfOut = v0 + (shelfA * shelfA - 1.0) * (hp + (shelfK / shelfA) * bp);

        double dH = 1.0 / (1.0 + hpfG * (hpfG + hpfK));
        double hpH = (shelfOut - (hpfG + hpfK) * inHpfS1_R - inHpfS2_R) * dH;
        double bpH = hpfG * hpH + inHpfS1_R;
        double lpH = hpfG * bpH + inHpfS2_R;
        inHpfS1_R = hpfG * hpH + bpH;
        inHpfS2_R = hpfG * bpH + lpH;
        return static_cast<float>(hpH);
    }

    float filterKWeightingOutL(float in) noexcept {
        double v0 = static_cast<double>(in);
        double d = 1.0 / (1.0 + shelfG * (shelfG + shelfK));
        double hp = (v0 - (shelfG + shelfK) * outShelfS1_L - outShelfS2_L) * d;
        double bp = shelfG * hp + outShelfS1_L;
        double lp = shelfG * bp + outShelfS2_L;
        outShelfS1_L = shelfG * hp + bp;
        outShelfS2_L = shelfG * bp + lp;
        double shelfOut = v0 + (shelfA * shelfA - 1.0) * (hp + (shelfK / shelfA) * bp);

        double dH = 1.0 / (1.0 + hpfG * (hpfG + hpfK));
        double hpH = (shelfOut - (hpfG + hpfK) * outHpfS1_L - outHpfS2_L) * dH;
        double bpH = hpfG * hpH + outHpfS1_L;
        double lpH = hpfG * bpH + outHpfS2_L;
        outHpfS1_L = hpfG * hpH + bpH;
        outHpfS2_L = hpfG * bpH + lpH;
        return static_cast<float>(hpH);
    }

    float filterKWeightingOutR(float in) noexcept {
        double v0 = static_cast<double>(in);
        double d = 1.0 / (1.0 + shelfG * (shelfG + shelfK));
        double hp = (v0 - (shelfG + shelfK) * outShelfS1_R - outShelfS2_R) * d;
        double bp = shelfG * hp + outShelfS1_R;
        double lp = shelfG * bp + outShelfS2_R;
        outShelfS1_R = shelfG * hp + bp;
        outShelfS2_R = shelfG * bp + lp;
        double shelfOut = v0 + (shelfA * shelfA - 1.0) * (hp + (shelfK / shelfA) * bp);

        double dH = 1.0 / (1.0 + hpfG * (hpfG + hpfK));
        double hpH = (shelfOut - (hpfG + hpfK) * outHpfS1_R - outHpfS2_R) * dH;
        double bpH = hpfG * hpH + outHpfS1_R;
        double lpH = hpfG * bpH + outHpfS2_R;
        outHpfS1_R = hpfG * hpH + bpH;
        outHpfS2_R = hpfG * bpH + lpH;
        return static_cast<float>(hpH);
    }

    inline float applySafetyCeiling(float x, float ceiling = 0.9897f) const noexcept {
        const float absX = std::abs(x);
        // Soft knee trasparente a partire da -0.30 dBFS (0.966 lin) per non schiacciare i transienti vocali
        const float softKneeStart = ceiling * 0.966f;
        if (absX <= softKneeStart) return x;

        const float kneeWidth = ceiling - softKneeStart;
        const float excess = absX - softKneeStart;
        const float saturated = softKneeStart + kneeWidth * std::tanh(excess / kneeWidth);
        const float bounded = std::min(saturated, ceiling);
        return (x > 0.0f) ? bounded : -bounded;
    }

    TruePeakLimiter tpLimiterL;
    TruePeakLimiter tpLimiterR;
};

} // namespace dsp171
