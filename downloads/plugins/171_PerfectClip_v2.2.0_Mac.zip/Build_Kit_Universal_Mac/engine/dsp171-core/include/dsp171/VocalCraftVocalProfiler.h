#pragma once

#include <dsp171/VocalCraftAIVocalMatch.h>

namespace dsp171 {

// =============================================================================
// 171 Studio Innovatio - AI Vocal Profiler & Target Reconfiguration Alias
// 171 VocalCraft 3.0 "The Sovereign Vocal Engine" - Phase 4
// =============================================================================

using VocalCraftVocalProfiler = VocalCraftAIVocalMatch;

} // namespace dsp171
