#pragma once
#include <cmath>
#include <algorithm>

namespace dsp171 {

/**
 * @brief WavesSSLBusComp
 * Reverse-engineered from Waves SSL G-Master Bus Compressor.
 * Models the famous SSL 4000 G Console Quad VCA master buss compressor with
 * switchable ratios (2:1, 4:1, 10:1), program-dependent Auto-Release, and optional analog THD modeling.
 * Perfected with decibel-domain logarithmic VCA ballistics, precalculated coefficients, and DC-blocked saturation.
 */
class WavesSSLBusComp {
public:
    enum class Ratio {
        Ratio2_1,
        Ratio4_1,
        Ratio10_1
    };

    enum class ReleaseMode {
        Rel_100ms,
        Rel_200ms,
        Rel_400ms,
        Rel_800ms,
        Rel_1600ms,
        Rel_Auto
    };

    WavesSSLBusComp() noexcept 
        : m_sampleRate(44100.0f) {}

    void prepare(float sampleRate) noexcept {
        m_sampleRate = sampleRate;
        m_gainReductionDb = 0.0f;
        m_autoFastEnv = 0.0f;
        m_autoSlowEnv = 0.0f;
        m_sidechainHpL = 0.0f;
        m_sidechainHpR = 0.0f;
        m_dcL = 0.0f; m_dcR = 0.0f;
        m_dcX1L = 0.0f; m_dcX1R = 0.0f;
        updateCoefficients();
    }

    void setParameters(float thresholdDb = 0.0f, Ratio ratio = Ratio::Ratio4_1,
                       float attackMs = 30.0f, ReleaseMode release = ReleaseMode::Rel_Auto,
                       float makeupGainDb = 0.0f, bool analogOn = false, float sidechainHpfHz = 0.0f) noexcept {
        m_thresholdDb = std::clamp(thresholdDb, -15.0f, 15.0f);
        m_thresholdLinear = std::pow(10.0f, m_thresholdDb / 20.0f);
        m_ratioMode = ratio;
        switch (ratio) {
            case Ratio::Ratio2_1:  m_ratio = 2.0f; break;
            case Ratio::Ratio4_1:  m_ratio = 4.0f; break;
            case Ratio::Ratio10_1: m_ratio = 10.0f; break;
        }

        m_attackMs = std::clamp(attackMs, 0.1f, 30.0f);
        m_releaseMode = release;
        switch (release) {
            case ReleaseMode::Rel_100ms:  m_releaseMs = 100.0f; break;
            case ReleaseMode::Rel_200ms:  m_releaseMs = 200.0f; break;
            case ReleaseMode::Rel_400ms:  m_releaseMs = 400.0f; break;
            case ReleaseMode::Rel_800ms:  m_releaseMs = 800.0f; break;
            case ReleaseMode::Rel_1600ms: m_releaseMs = 1600.0f; break;
            case ReleaseMode::Rel_Auto:   m_releaseMs = 100.0f; break; // dynamically modulated
        }

        m_makeupGain = std::pow(10.0f, std::clamp(makeupGainDb, 0.0f, 30.0f) / 20.0f);
        m_analogOn = analogOn;
        m_scHpfHz = sidechainHpfHz;
        updateCoefficients();
    }

    inline void process(float inL, float inR, float& outL, float& outR) noexcept {
        // 1. Sidechain high-pass filtering (optional 0 - 185 Hz bass punch protect)
        float detL = inL;
        float detR = inR;
        if (m_scHpfHz > 10.0f) {
            m_sidechainHpL += m_scAlphaHP * (detL - m_sidechainHpL);
            m_sidechainHpR += m_scAlphaHP * (detR - m_sidechainHpR);
            detL -= m_sidechainHpL;
            detR -= m_sidechainHpR;
        }

        // 2. VCA Stereo Peak Rectifier
        float maxDet = std::max(std::fabs(detL), std::fabs(detR));
        float detDb = 20.0f * std::log10(std::max(maxDet, 1e-5f));

        // 3. SSL Soft-Knee Compression Transfer Function
        float overDb = detDb - m_thresholdDb;
        float targetGrDb = 0.0f;

        const float kneeWidthDb = 4.0f;
        if (overDb > (kneeWidthDb * 0.5f)) {
            targetGrDb = overDb * (1.0f - 1.0f / m_ratio);
        } else if (overDb > -(kneeWidthDb * 0.5f)) {
            // Quadratic polynomial soft knee
            float x = overDb + (kneeWidthDb * 0.5f);
            targetGrDb = (x * x / (2.0f * kneeWidthDb)) * (1.0f - 1.0f / m_ratio);
        }

        // 4. Ballistics in dB Domain (True logarithmic DBX/THAT VCA exponential behavior)
        float effectiveRelCoeff = m_fixedReleaseCoeff;
        if (m_releaseMode == ReleaseMode::Rel_Auto) {
            // Dual-time constant Auto-Release:
            // Fast attack on transients (10 ms), slow release for sustained low crest (250 ms)
            m_autoFastEnv += m_autoAlphaFast * (maxDet - m_autoFastEnv);
            m_autoSlowEnv += m_autoAlphaSlow * (maxDet - m_autoSlowEnv);

            float crestRatio = std::clamp((m_autoFastEnv - m_autoSlowEnv) / (m_autoFastEnv + 1e-4f), 0.0f, 1.0f);
            effectiveRelCoeff = m_relAlphaFast * crestRatio + m_relAlphaSlow * (1.0f - crestRatio);
        }

        if (targetGrDb > m_gainReductionDb) {
            m_gainReductionDb += m_attackCoeff * (targetGrDb - m_gainReductionDb);
        } else {
            m_gainReductionDb += effectiveRelCoeff * (targetGrDb - m_gainReductionDb);
        }

        float currentGainLinear = std::pow(10.0f, -m_gainReductionDb / 20.0f);

        // 5. Apply Gain Reduction & Make-up Gain
        float compL = inL * currentGainLinear * m_makeupGain;
        float compR = inR * currentGainLinear * m_makeupGain;

        // 6. Analog Modeling: SSL VCA Transformer Non-Linear Saturation with DC protection
        if (m_analogOn) {
            // Asymmetric soft saturation + subtle 2nd/3rd harmonics with parity preservation
            const float asymL = 0.015f * (compL * std::abs(compL)) / (1.0f + 0.25f * compL * compL);
            const float asymR = 0.015f * (compR * std::abs(compR)) / (1.0f + 0.25f * compR * compR);
            float satL = std::tanh(compL * 1.02f) + asymL;
            float satR = std::tanh(compR * 1.02f) + asymR;

            // 5 Hz DC-blocking filter (y[n] = x[n] - x[n-1] + R*y[n-1])
            const float R = 0.9993f;
            m_dcL = satL - m_dcX1L + R * m_dcL;
            m_dcR = satR - m_dcX1R + R * m_dcR;
            m_dcX1L = satL;
            m_dcX1R = satR;

            compL = m_dcL;
            compR = m_dcR;
        }

        outL = compL;
        outR = compR;
    }

    void processBlock(float* left, float* right, int numSamples) noexcept {
        for (int i = 0; i < numSamples; ++i) {
            process(left[i], right[i], left[i], right[i]);
        }
    }

    [[nodiscard]] float getGainReductionDb() const noexcept {
        return m_gainReductionDb;
    }

private:
    float m_sampleRate{44100.0f};
    float m_thresholdDb{0.0f};
    float m_thresholdLinear{1.0f};
    Ratio m_ratioMode{Ratio::Ratio4_1};
    float m_ratio{4.0f};
    float m_attackMs{30.0f};
    ReleaseMode m_releaseMode{ReleaseMode::Rel_Auto};
    float m_releaseMs{100.0f};
    float m_makeupGain{1.0f};
    bool m_analogOn{false};
    float m_scHpfHz{0.0f};

    float m_gainReductionDb{0.0f};
    float m_autoFastEnv{0.0f};
    float m_autoSlowEnv{0.0f};
    float m_sidechainHpL{0.0f};
    float m_sidechainHpR{0.0f};

    // Precomputed coefficients (zero std::exp inside per-sample processing)
    float m_scAlphaHP{0.0f};
    float m_attackCoeff{0.0f};
    float m_fixedReleaseCoeff{0.0f};
    float m_autoAlphaFast{0.0f};
    float m_autoAlphaSlow{0.0f};
    float m_relAlphaFast{0.0f};
    float m_relAlphaSlow{0.0f};

    // DC Blocker states for analog saturation
    float m_dcL{0.0f}, m_dcR{0.0f};
    float m_dcX1L{0.0f}, m_dcX1R{0.0f};

    void updateCoefficients() noexcept {
        if (m_scHpfHz > 10.0f) {
            m_scAlphaHP = m_scHpfHz / (m_scHpfHz + m_sampleRate / 6.2831853f);
        } else {
            m_scAlphaHP = 0.0f;
        }

        m_attackCoeff = 1.0f - std::exp(-1.0f / ((m_attackMs * 0.001f) * m_sampleRate));
        m_fixedReleaseCoeff = 1.0f - std::exp(-1.0f / ((m_releaseMs * 0.001f) * m_sampleRate));
        m_autoAlphaFast = 1.0f - std::exp(-1.0f / (0.010f * m_sampleRate));
        m_autoAlphaSlow = 1.0f - std::exp(-1.0f / (0.250f * m_sampleRate));
        m_relAlphaFast = 1.0f - std::exp(-1.0f / (0.050f * m_sampleRate));  // 50 ms
        m_relAlphaSlow = 1.0f - std::exp(-1.0f / (1.200f * m_sampleRate));  // 1200 ms
    }
};

} // namespace dsp171
