#pragma once
#include <cmath>
#include <array>
#include <algorithm>
#include <cstdint>
#include <string_view>
#include "Common.h"
#include "VocalCleanFilter.h"
#include "DCBlocker.h"
#include "ZDFTiltFilter.h"
#include "PitchDetectorMPM.h"
#include "GlottalClosureDetector.h"
#include "MusicalQuantizer.h"
#include "RetuneFilter.h"
#include "TDPSOLAShifter.h"
#include "FormantProcessor.h"
#include "StereoWidthEnhancer.h"
#include "DPLLPitchTracker.h"
#include "LPCVocalTract.h"
#include "RealTuneNeuralBrain.h"

namespace dsp171 {

// =============================================================================
// RealTuneEngine
// Motore DSP unificato di intonazione vocale real-time a bassissima latenza deterministica
//
// Architettura di produzione per dsp171-core:
// 1. Modulo Pitch Detection MPM/NSDF a zero allocazioni dinamiche nel process thread.
// 2. Quantizzazione musicale intelligente (Scale/Key) con sintonizzazione A4 variabile.
// 3. Filtro Retune Speed variabile con inseguimento continuo a due velocità
//    (sustain tracking e glide inter-note) senza stalli o congelamenti al 10%.
// 4. Core Pitch Shifter Dual-Head Synchronous WSOLA a latenza deterministica costante,
//    zero drift temporale, zero click ai confini del buffer e phase-lock stereo assoluto.
// 5. Compensazione automatica spettrale delle formanti (Keep Formants) ZDF SVF a 64-bit.
// =============================================================================
class RealTuneEngine {
public:
    static constexpr size_t MAX_BLOCK_SIZE = 2048;

    RealTuneEngine() noexcept {
        reset();
    }

    void prepare(double sampleRate, size_t maxBlockSize = 512) noexcept {
        (void)maxBlockSize;
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        
        // Inizializza i sotto-moduli con hop ottimizzato proporzionale al sample rate (~2.67 ms a 48k, ~3.5 ms a 96k/192k)
        const size_t hop = (sr <= 48000.0f) ? 128 : static_cast<size_t>(std::clamp(std::round(sr * 0.00350f), 128.0f, 672.0f));
        const size_t win = (sr > 96000.0f) ? 1024 : ((sr > 48000.0f) ? 896 : 768);
        pitchDetector.prepare(sampleRate, win, hop);
        dpllTracker.prepare(sampleRate, pitchDetector.getVocalRange());
        lpcVocalTractL.prepare(sampleRate, 20);
        lpcVocalTractR.prepare(sampleRate, 20);
        retuneFilter.prepare(sampleRate);
        vocalCleanFilterL.prepare(sampleRate, 55.0f);
        vocalCleanFilterR.prepare(sampleRate, 55.0f);
        formantProcessorL.prepare(sampleRate);
        formantProcessorR.prepare(sampleRate);
        widthEnhancer.prepare(sampleRate);
        
        // Calcola la finestra di hangover/debounce per la stabilizzazione della vocalizzazione (~40 ms)
        maxHangoverFrames = static_cast<uint32_t>(std::round(0.040f * sr / static_cast<float>(hop)));
        neuralBrain.prepare(sr);
        
        updateLatencyConfig();
        reset();
    }

    void reset() noexcept {
        pitchDetector.reset();
        dpllTracker.reset();
        lpcVocalTractL.reset();
        lpcVocalTractR.reset();
        retuneFilter.reset();
        vocalCleanFilterL.reset();
        vocalCleanFilterR.reset();
        formantProcessorL.reset();
        formantProcessorR.reset();
        widthEnhancer.reset();
        shifter.reset();
        neuralBrain.reset();

        currentPitchHz = 0.0f;
        targetPitchHz = 0.0f;
        correctionCents = 0.0f;
        voicingClarity = 0.0f;
        isSignalVoiced = false;
        targetMidiNote = 69;
        formantShiftSemitones = 0.0f;
        keepFormants = true;
        hangoverFramesLeft = 0;

        smoothedT0 = sr * 0.010f;
        targetT0 = sr * 0.010f;
        prevMonoSample = 0.0f;
        zcrSmoothed = 0.0f;

        setKeepFormants(keepFormants);
        setFormantShiftSemitones(formantShiftSemitones);
    }

    // --- Parametri di controllo ---

    // Imposta la scala musicale (Chromatic, Major, Minor, Pentatonic, ecc.)
    void setScale(ScaleType scale) noexcept {
        quantizer.setScale(scale);
    }

    // Imposta la tonica (Root Key): 0 = C, 1 = C#, 2 = D, ..., 11 = B
    void setRootKey(int rootKey) noexcept {
        quantizer.setRootKey(rootKey);
    }

    // Velocità di retuning in millisecondi [0.0 ms .. 800.0 ms]
    // 0.0 ms = Hard-Tune istantaneo, 15-25 ms = pop moderno, 80-120 ms = trasparente
    void setRetuneSpeedMs(float speedMs) noexcept {
        userRetuneSpeedMs = speedMs;
        retuneFilter.setRetuneSpeedMs(speedMs);
    }

    // Note Transition (glide tra note diverse) [0.1 .. 800 ms] (Waves Tune RT)
    void setNoteTransitionMs(float transMs) noexcept {
        retuneFilter.setNoteTransitionMs(transMs);
    }

    // Tolerance (Deadband Cents [0..40] e Time [0..300 ms]) (Waves Tune RT)
    void setTolerance(float cents, float timeMs) noexcept {
        retuneFilter.setTolerance(cents, timeMs);
    }

    // Natural Vibrato Preservation Engine (Waves Tune RT)
    void setVibrato(bool enabled, float depthPercent = 100.0f) noexcept {
        retuneFilter.setVibrato(enabled, depthPercent);
    }

    // Correction Limit in cents [50 .. 600 cents] (Waves Tune RT)
    void setCorrectionLimitCents(float limitCents) noexcept {
        retuneFilter.setCorrectionLimitCents(limitCents);
    }

    // --- Controlli Antares Auto-Tune Pro ---

    // Classic Mode DSP (Auto-Tune 5): snap aggressivo istantaneo
    void setClassicMode(bool enabled) noexcept {
        retuneFilter.setClassicMode(enabled);
        const auto mode = enabled ? LPCResynthesisMode::Classic : LPCResynthesisMode::Modern;
        lpcVocalTractL.setResynthesisMode(mode);
        lpcVocalTractR.setResynthesisMode(mode);
    }

    [[nodiscard]] bool isClassicMode() const noexcept {
        return retuneFilter.isClassicMode();
    }

    // Flex-Tune [0% .. 100%]: ritira la correzione fuori dalla zona centrale della nota
    void setFlexTune(float flexPercent) noexcept {
        retuneFilter.setFlexTune(flexPercent);
        lpcVocalTractL.setFlexTune(flexPercent);
        lpcVocalTractR.setFlexTune(flexPercent);
    }

    [[nodiscard]] float getFlexTune() const noexcept {
        return retuneFilter.getFlexTune();
    }

    // Throat Length [50% .. 150%]: modellazione fisica della lunghezza del tratto vocale LPC
    void setThroatLength(float throatPercent) noexcept {
        throatPercent = std::clamp(throatPercent, 50.0f, 150.0f);
        lpcVocalTractL.setThroatLength(throatPercent);
        lpcVocalTractR.setThroatLength(throatPercent);
    }

    // Tracking [0% .. 100%]: sensibilità del pitch detector su voci complesse/rumorose
    void setTracking(float trackingPercent) noexcept {
        trackingPercent = std::clamp(trackingPercent, 0.0f, 100.0f);
        const float vThresh = 0.85f - (trackingPercent * 0.01f) * 0.45f;
        setVoicingThreshold(vThresh);
    }

    // Input Type / Vocal Range (Auto-Tune Pro & Waves Tune RT)
    void setVocalRange(VocalRange range) noexcept {
        pitchDetector.setVocalRange(range);
        dpllTracker.setVocalRange(range);
        float cleanCutoff = 55.0f;
        switch (range) {
            case VocalRange::AltoTenor: cleanCutoff = 65.0f; break;
            case VocalRange::Soprano:   cleanCutoff = 85.0f; break;
            case VocalRange::LowMale:   cleanCutoff = 45.0f; break;
            case VocalRange::Wide:
            default:                    cleanCutoff = 40.0f; break;
        }
        vocalCleanFilterL.setCutoff(cleanCutoff);
        vocalCleanFilterR.setCutoff(cleanCutoff);
    }

    void setInputType(int inputType) noexcept {
        setVocalRange(static_cast<VocalRange>(std::clamp(inputType, 0, 3)));
    }

    [[nodiscard]] VocalRange getVocalRange() const noexcept {
        return pitchDetector.getVocalRange();
    }

    // Profondità della correzione [0.0 = Dry naturale, 1.0 = 100% intonato]
    void setAmount(float amount) noexcept {
        retuneFilter.setAmount(amount);
    }

    void setDepth(float depth) noexcept {
        setAmount(depth);
    }

    [[nodiscard]] float getDepth() const noexcept {
        return retuneFilter.getDepth();
    }

    // Humanize: Protezione del vibrato naturale [0% .. 100%]
    void setHumanize(float humanizePercent) noexcept {
        retuneFilter.setHumanize(humanizePercent);
        lpcVocalTractL.setHumanize(humanizePercent);
        lpcVocalTractR.setHumanize(humanizePercent);
    }

    // Formant Shift in semitoni [-12.0 st .. +12.0 st]
    void setFormantShiftSemitones(float semitones) noexcept {
        formantShiftSemitones = std::clamp(semitones, -12.0f, 12.0f);
        formantProcessorL.setFormantShiftSemitones(formantShiftSemitones);
        formantProcessorR.setFormantShiftSemitones(formantShiftSemitones);
    }

    // Keep Formants: compensazione automatica dello spostamento delle formanti durante retuning
    void setKeepFormants(bool enabled) noexcept {
        keepFormants = enabled;
        formantProcessorL.setKeepFormants(enabled);
        formantProcessorR.setKeepFormants(enabled);
    }

    [[nodiscard]] bool isKeepFormantsEnabled() const noexcept {
        return keepFormants;
    }

    // Larghezza Stereo Mid/Side con decorrelatore psicoacustico [0% .. 200%]
    void setStereoWidth(float widthPercent) noexcept {
        widthEnhancer.setWidth(widthPercent);
    }

    [[nodiscard]] float getStereoWidth() const noexcept {
        return widthEnhancer.getWidth();
    }

    // Frequenza di riferimento del LA4 [415.0 Hz .. 466.0 Hz] (default 440.0 Hz)
    void setA4Reference(float a4Hz) noexcept {
        quantizer.setA4Reference(a4Hz);
    }

    // Modalità Live MIDI Target Note (da master keyboard o traccia DAW)
    void setMidiTarget(int note, bool active) noexcept {
        quantizer.setTargetMidiNote(note, active);
    }

    // Maschera semitonale per note in Bypass (pitch immutato a ratio 1.0)
    void setBypassMask(uint16_t mask) noexcept {
        quantizer.setBypassMask(mask);
    }

    // Maschera semitonale per note Bloccate/Proibite (escluse dallo snap)
    void setBlockedMask(uint16_t mask) noexcept {
        quantizer.setBlockedMask(mask);
    }

    // Modalità Live Booth a Bassa Latenza (throughput impercettibile < 3.5 ms)
    void setLowLatencyMode(bool enabled) noexcept {
        if (lowLatencyMode != enabled) {
            lowLatencyMode = enabled;
            updateLatencyConfig();
        }
    }

    [[nodiscard]] bool isLowLatencyMode() const noexcept {
        return lowLatencyMode;
    }

    void updateLatencyConfig() noexcept {
        // Modalità Live Zero-Latency: lookahead deterministico interno calibrato (512 campioni ~11.6 ms @ 44.1k / 10.6 ms @ 48k)
        // Garantisce che il buffer interno sia sempre ampiamente superiore a T0_max (fino a 70 Hz ~ 630 campioni)
        // evitando tassativamente loop di salti e crossfade continui a riposo.
        // All'host DAW viene sempre riportata latenza 0 PDC in modalita' zero-latency.
        // Modalità Studio HQ: 1024 campioni (~21.3 ms @ 48 kHz)
        const size_t latencySamples = lowLatencyMode
            ? static_cast<size_t>(std::clamp(std::round(sr * 0.0116f), 512.0f, 768.0f))
            : static_cast<size_t>(std::clamp(std::round(sr * 0.0213f), 768.0f, 1024.0f));
        shifter.prepare(sr, latencySamples);
    }

    // Maschera semitonale personalizzata a 12 bit (usata quando ScaleType == Custom)
    void setCustomScaleMask(uint16_t mask) noexcept {
        quantizer.setCustomMask(mask);
    }

    // Soglia di periodicità minima per considerare il segnale vocalizzato (Voiced)
    void setVoicingThreshold(float thresh) noexcept {
        pitchDetector.setVoicingThreshold(thresh);
        shifter.setVoicingThreshold(thresh);
    }

    // --- Elaborazione Audio in tempo reale (Zero allocazioni) ---

    // Elaborazione Mono
    void process(const float* input, float* output, size_t numSamples) noexcept {
        const float* inputs[1] = { input };
        float* outputs[1] = { output };
        process(inputs, outputs, 1, numSamples);
    }

    // Elaborazione Stereo o Multicanale Phase-Coherent
    void process(const float* const* inputs, float* const* outputs, size_t numChannels, size_t numSamples) noexcept {
        if (numSamples == 0 || inputs == nullptr || outputs == nullptr || numChannels == 0) {
            return;
        }

        const float* inL = inputs[0];
        const float* inR = (numChannels > 1 && inputs[1] != nullptr) ? inputs[1] : inputs[0];
        float* outL = outputs[0];
        float* outR = (numChannels > 1 && outputs[1] != nullptr) ? outputs[1] : nullptr;

        // Neural Smart Brain 4-Target Inference (Sub-25 microsecond execution)
        if (neuralBrainActive) {
            neuralBrain.analyzeAndInfer(inL, inR, static_cast<int>(numSamples), currentPitchHz, voicingClarity, targetPitchHz);
            if (!isClassicMode() && userRetuneSpeedMs > 0.05f) {
                const float neuralSpeed = neuralBrain.getAdaptiveRetuneSpeedMs();
                const float effSpeed = std::clamp(userRetuneSpeedMs * (neuralSpeed / 15.0f), 0.5f, 400.0f);
                retuneFilter.setRetuneSpeedMs(effSpeed);
            }
        }

        for (size_t i = 0; i < numSamples; ++i) {
            float sL = inL[i];
            float sR = inR[i];

            // 0. Sanificazione e immunità assoluta a campioni invalidi (NaN, Inf, Denormals)
            if (!std::isfinite(sL)) sL = 0.0f;
            if (!std::isfinite(sR)) sR = 0.0f;
            if (std::abs(sL) < 1.0e-25f) sL = 0.0f;
            if (std::abs(sR) < 1.0e-25f) sR = 0.0f;

            // 1. SIDECHAIN PITCH TRACKING: Filtraggio Vocal Clean passa-alto a 55 Hz (ZDF SVF Butterworth 2° ordine)
            // Rigorosamente confinato nel percorso sidechain del detector di pitch per abbattere rumble,
            // DC termica e pop plosivi ('p', 'b', 't') senza toccare minimamente il segnale audio principale.
            // Il Master Audio Path (sL, sR) rimane 100% puro, a fase lineare e a banda piena (0 Hz - 24 kHz),
            // conservando tutto il calore, il corpo e la risposta nei transienti (come in Auto-Tune Pro 2026).
            const float scCleanL = vocalCleanFilterL.processSample(sL);
            const float scCleanR = vocalCleanFilterR.processSample(sR);
            const float sMonoClean = 0.5f * (scCleanL + scCleanR);

            // Rilevamento ZCR per telemetria/analisi
            const bool zeroCross = (sMonoClean * prevMonoSample < 0.0f);
            prevMonoSample = sMonoClean;
            const float zcrAlpha = std::clamp(1.0f - std::exp(-1.0f / (0.0015f * sr)), 0.005f, 0.2f);
            zcrSmoothed += zcrAlpha * ((zeroCross ? 1.0f : 0.0f) - zcrSmoothed);

            // 2. Aggiorna il pitch detector MPM e DPLL sul segnale DC-free pulito in sidechain
            dpllTracker.processSample(sMonoClean);
            PitchResult pr{};
            const bool newPitchFrame = pitchDetector.pushSample(sMonoClean, pr);

            if (newPitchFrame) {
                voicingClarity = pr.clarity;
                const bool wasVoiced = isSignalVoiced;
                const bool rawVoiced = pr.isVoiced && !pr.isPlosive;

                if (rawVoiced && pr.frequencyHz > 20.0f) {
                    hangoverFramesLeft = maxHangoverFrames;
                    currentPitchHz = pr.frequencyHz;
                    isSignalVoiced = true;
                } else if (pr.isPlosive) {
                    // Drop immediato di hangover su plosive e pop microfonici:
                    // Impedisce allo shifter WSOLA di estendere o duplicare il tonfo subacustico
                    hangoverFramesLeft = 0;
                    isSignalVoiced = false;
                    currentPitchHz = 0.0f;
                } else if (hangoverFramesLeft > 0) {
                    --hangoverFramesLeft;
                    // Debounce Hangover (~40 ms): mantiene lo stato voiced e conserva l'ultimo pitch valido
                    // eliminando completamente tremolo/flutter a 11 Hz su vocal fry o cali istantanei di chiarezza
                    isSignalVoiced = true;
                } else {
                    isSignalVoiced = false;
                    currentPitchHz = 0.0f;
                }

                if (isSignalVoiced && currentPitchHz > 20.0f) {
                    // Sincronizza la frequenza centrale del DPLL tracker con l'analisi MPM ad alta confidenza
                    dpllTracker.setCoarseFrequency(currentPitchHz);

                    // 3. Quantizzazione musicale intelligente
                    const QuantizeResult qr = quantizer.quantize(currentPitchHz);
                    targetPitchHz = qr.targetFreqHz;
                    correctionCents = qr.centsOffset;
                    targetMidiNote = qr.targetMidiNote;
                    targetPitchRatio = qr.pitchRatio;
                    targetT0 = sr / currentPitchHz;

                    if (!wasVoiced) {
                        // Onset istantaneo: nessuna rampa da 10 ms (100 Hz)!
                        smoothedT0 = targetT0;
                    }
                } else {
                    targetPitchRatio = 1.0f;
                    targetPitchHz = 0.0f;
                    correctionCents = 0.0f;
                    // Mantieni targetT0 invariato durante pause brevi invece di resettare a 10 ms
                }
            }

            // 4. Filtro di Retune Speed variabile continuo a due velocità
            const float smoothedRatio = retuneFilter.processSample(targetPitchRatio, correctionCents, targetMidiNote);

            // Smussamento continuo del periodo T0 per eliminare discontinuità a gradino (~3 ms tau)
            const float alphaT0 = std::clamp(1.0f - std::exp(-1.0f / (0.003f * sr)), 0.005f, 0.1f);
            smoothedT0 += alphaT0 * (targetT0 - smoothedT0);

            // Aggiorna la compensazione dinamica delle formanti (Keep Formants) e Formant Tracking F1/F2
            formantProcessorL.updateTracking(currentPitchHz, smoothedRatio, isSignalVoiced);
            if (outR != nullptr) {
                formantProcessorR.updateTracking(currentPitchHz, smoothedRatio, isSignalVoiced);
            }

            // 5. Sintesi Dual-Head Synchronous WSOLA con segnale audio PRISTINO (Phase-Linear & Full-Bandwidth)
            float shiftedL = 0.0f;
            float shiftedR = 0.0f;
            shifter.processStereo(sL, sR, shiftedL, shiftedR, smoothedT0, smoothedRatio, isSignalVoiced, voicingClarity);

            // Classic Mode (Auto-Tune 5): snap di fase sincronizzato sui confini d'epoca glottica (GCI)
            if (isClassicMode() && shifter.hasGlottalEpoch()) {
                lpcVocalTractL.triggerGlottalEpochSnap();
                if (outR != nullptr) {
                    lpcVocalTractR.triggerGlottalEpochSnap();
                }
            }

            // 6. Modellazione fisica delle formanti del tratto vocale LPC (Allpass Ladder ZDF)
            // Decoupled: LPC gestisce la sola lunghezza fisica del tratto vocale (Throat Length != 100%)
            const bool hasLPCWarp = (std::abs(lpcVocalTractL.getLambda()) > 0.005f);
            // Trasparenza assoluta (Waves Tune Real-Time standard):
            // Il processore formanti interviene solo se vi e' uno shift manuale impostato dall'utente
            // oppure se il pitch shift cumulativo supera la soglia di sensibilità acustica (0.40 st)
            const bool hasFormantShift = (std::abs(formantShiftSemitones) > 0.05f) ||
                                         (formantProcessorL.isKeepFormantsEnabled() && std::abs(formantProcessorL.getEffectiveFormantShift()) > 0.40f);

            lpcVocalTractL.pushSampleForAnalysis(sL, isSignalVoiced);
            if (outR != nullptr) {
                lpcVocalTractR.pushSampleForAnalysis(sR, isSignalVoiced);
            }

            if (hasLPCWarp && isSignalVoiced) {
                const float resL = lpcVocalTractL.deconvolveSample(shiftedL);
                shiftedL = lpcVocalTractL.synthesizeSample(resL);
                if (outR != nullptr) {
                    const float resR = lpcVocalTractR.deconvolveSample(shiftedR);
                    shiftedR = lpcVocalTractR.synthesizeSample(resR);
                }
            }

            if (hasFormantShift) {
                shiftedL = formantProcessorL.processSample(shiftedL);
                if (outR != nullptr) {
                    shiftedR = formantProcessorR.processSample(shiftedR);
                }
            }

            // 7. Elaborazione Stereo Width (0% .. 200%) con matrice Mid/Side
            if (outR != nullptr) {
                widthEnhancer.processSample(shiftedL, shiftedR, shiftedL, shiftedR);
            }

            outL[i] = shiftedL;
            if (outR != nullptr) {
                outR[i] = shiftedR;
            }
        }
    }

    // --- Telemetria per GUI / Monitoraggio ---

    [[nodiscard]] float getDetectedPitchHz() const noexcept { return currentPitchHz; }
    [[nodiscard]] float getTargetPitchHz() const noexcept { return targetPitchHz; }
    [[nodiscard]] float getCorrectionCents() const noexcept { return correctionCents; }
    [[nodiscard]] float getRetuneSpeedMs() const noexcept { return retuneFilter.getRetuneSpeedMs(); }
    [[nodiscard]] float getNoteTransitionMs() const noexcept { return retuneFilter.getNoteTransitionMs(); }
    [[nodiscard]] float getVoicingClarity() const noexcept { return voicingClarity; }
    [[nodiscard]] bool isVoiced() const noexcept { return isSignalVoiced; }
    [[nodiscard]] int getTargetMidiNote() const noexcept { return targetMidiNote; }
    [[nodiscard]] float getFormantShiftSemitones() const noexcept { return formantShiftSemitones; }
    [[nodiscard]] float getEffectiveFormantShiftSemitones() const noexcept { return formantProcessorL.getEffectiveFormantShift(); }
    [[nodiscard]] float getAutoFormantShiftSemitones() const noexcept { return formantProcessorL.getAutoFormantShift(); }
    [[nodiscard]] float getFormantF1Hz() const noexcept { return formantProcessorL.getTargetF1Hz(); }
    [[nodiscard]] float getFormantF2Hz() const noexcept { return formantProcessorL.getTargetF2Hz(); }

    [[nodiscard]] std::string_view getTargetNoteName() const noexcept {
        const uint8_t pc = static_cast<uint8_t>(((targetMidiNote % 12) + 12) % 12);
        return MusicalQuantizer::getPitchClassName(pc);
    }

    [[nodiscard]] uint16_t getActiveScaleMask() const noexcept {
        return quantizer.getActiveMask();
    }

    [[nodiscard]] size_t getLatencySamples() const noexcept {
        return shifter.getLatencySamples();
    }
    [[nodiscard]] uint32_t getShifterJumpCount() const noexcept {
        return shifter.getJumpCount();
    }

    // --- Telemetria DPLL & LPC Vocal Tract ---
    [[nodiscard]] const DPLLPitchTracker& getDPLLTracker() const noexcept { return dpllTracker; }
    [[nodiscard]] const LPCVocalTract<20>& getLPCVocalTract() const noexcept { return lpcVocalTractL; }
    [[nodiscard]] float getDPLLPitchHz() const noexcept { return dpllTracker.getEstimatedF0(); }
    [[nodiscard]] float getDPLLSNR() const noexcept { return dpllTracker.getSNR(); }
    [[nodiscard]] bool isDPLLLocked() const noexcept { return dpllTracker.isLocked(); }
    [[nodiscard]] float getLPCThroatLambda() const noexcept { return lpcVocalTractL.getLambda(); }
    [[nodiscard]] float getLPCResidualGain() const noexcept { return lpcVocalTractL.getResidualGain(); }

private:
    float sr = 48000.0f;

    PitchDetectorMPM pitchDetector;
    DPLLPitchTracker dpllTracker;
    LPCVocalTract<20> lpcVocalTractL;
    LPCVocalTract<20> lpcVocalTractR;
    MusicalQuantizer quantizer;
    RetuneFilter retuneFilter;
    VocalCleanFilter vocalCleanFilterL;
    VocalCleanFilter vocalCleanFilterR;
    FormantProcessor formantProcessorL;
    FormantProcessor formantProcessorR;
    StereoWidthEnhancer widthEnhancer;
    TDPSOLAShifter shifter;

    float currentPitchHz = 0.0f;
    float targetPitchHz = 0.0f;
    float correctionCents = 0.0f;
    float voicingClarity = 0.0f;
    bool isSignalVoiced = false;
    int targetMidiNote = 69;
    float targetPitchRatio = 1.0f;
    float formantShiftSemitones = 0.0f;
    bool keepFormants = true;
    float prevMonoSample = 0.0f;
    float zcrSmoothed = 0.0f;
    bool lowLatencyMode = true;
    uint32_t maxHangoverFrames = 15;
    uint32_t hangoverFramesLeft = 0;

    float smoothedT0 = 480.0f;
    float targetT0 = 480.0f;
    float userRetuneSpeedMs = 15.0f;

    // 171 RealTune Neural Smart Brain Engine
    RealTuneNeuralBrain neuralBrain;
    bool neuralBrainActive = true;

public:
    void setNeuralBrainActive(bool active) noexcept { neuralBrainActive = active; }
    [[nodiscard]] bool isNeuralBrainActive() const noexcept { return neuralBrainActive; }
    [[nodiscard]] const RealTuneNeuralBrain& getNeuralBrain() const noexcept { return neuralBrain; }
    [[nodiscard]] RealTuneNeuralBrain& getNeuralBrain() noexcept { return neuralBrain; }
};

} // namespace dsp171
