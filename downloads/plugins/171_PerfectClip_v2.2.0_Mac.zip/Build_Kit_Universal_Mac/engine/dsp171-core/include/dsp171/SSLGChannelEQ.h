#pragma once

#include <cmath>
#include <algorithm>
#include "Common.h"
#include "FastMath.h"
#include "ZDFSVF.h"

namespace dsp171 {

// =============================================================================
// SSLGChannelEQ (SSL 4000 G-Series Black Knob 242 EQ)
// Modello Fisico & Matematico del Circuito Console SL 4000 G (242 EQ)
//
// Caratteristiche Modellistiche & Retro-Ingegneria Circuitale Autentica:
// 1. 4 Bande Parametriche Console:
//    - LF Band: 30 Hz - 450 Hz, +/-15 dB, commutabile tra Bell e Shelf.
//      * Modalità Bell: Q nominale focalizzato a 1.35 con Proportional-Q che
//        si stringe fino a 1.85 a +/-15 dB (risposta solida, precisa, priva di fango).
//      * Modalità Shelf: risonanza con undershoot a 1.4*fc (elimina l'accumulo a 200 Hz).
//    - LMF Band: 200 Hz - 2500 Hz, +/-15 dB, Q variabile [0.5 .. 2.5] con Proportional-Q.
//    - HMF Band: 600 Hz - 7000 Hz, +/-15 dB, Q variabile [0.5 .. 2.5] con Proportional-Q.
//    - HF Band: 1.5 kHz - 16 kHz, +/-15 dB, commutabile tra Bell e Shelf (aria setosa).
// 2. High-Pass Filter (HPF): 18 dB/oct (Cascata ZDF Butterworth di 3° ordine), 16 .. 350 Hz.
// 3. Low-Pass Filter (LPF): 12 dB/oct (ZDF Butterworth di 2° ordine), 3 .. 22 kHz.
// 4. Formulazione Matematica Simmetrica Cytomic ZDF SVF (Andy Simper / Vadim Zavalishin):
//    - Simmetria algebrica esatta H_cut(f) = 1 / H_boost(f) per tutte le campane Bell.
//    - Guadagno a f0 bit-exact a +/-15 dB, stabilità numerica a 64-bit con zero phase-cramping.
// =============================================================================

class SSLGChannelEQ {
public:
    enum class BandType : uint8_t {
        Shelf = 0,
        Bell  = 1
    };

    struct BandConfig {
        float freqHz = 1000.0f;
        float gainDb = 0.0f;
        float q = 0.707f;
        BandType type = BandType::Bell;
    };

    SSLGChannelEQ() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        invSr = 1.0f / sr;

        updateCoefficients();
        reset();
    }

    void reset() noexcept {
        hpfSVF_L.reset();
        hpfSVF_R.reset();
        hpfOnePole_L.reset();
        hpfOnePole_R.reset();

        lpfSVF_L.reset();
        lpfSVF_R.reset();

        for (int i = 0; i < 4; ++i) {
            bandSVF_L[i].reset();
            bandSVF_R[i].reset();
            undershootSVF_L[i].reset();
            undershootSVF_R[i].reset();
        }
        bandSVF_3_L.reset();
        bandSVF_3_R.reset();
    }

    // --- Controls ---

    // High-Pass Filter: 16 Hz to 350 Hz (<= 16.5 Hz = Bypassed)
    void setHPFFreq(float freqHz) noexcept {
        hpfHz = std::clamp(freqHz, 16.0f, 350.0f);
        hpfEnabled = (hpfHz > 16.5f);
        updateHPF();
    }

    // Low-Pass Filter: 3000 Hz to 22000 Hz (>= 21500 Hz = Bypassed)
    void setLPFFreq(float freqHz) noexcept {
        lpfHz = std::clamp(freqHz, 3000.0f, 22000.0f);
        lpfEnabled = (lpfHz < 21500.0f);
        updateLPF();
    }

    // LF Band (Band 0): 30 - 450 Hz, +/-15 dB (SSL 242 Bell Q = 1.30f)
    void setLF(float freqHz, float gainDb, BandType type = BandType::Shelf) noexcept {
        bands[0].freqHz = std::clamp(freqHz, 30.0f, 450.0f);
        bands[0].gainDb = std::clamp(gainDb, -15.0f, 15.0f);
        bands[0].type = type;
        bands[0].q = (type == BandType::Bell) ? 1.30f : 0.707f;
        updateBand(0);
    }

    // LMF Band (Band 1): 200 - 2500 Hz, +/-15 dB, Q [0.5 .. 2.5]
    void setLMF(float freqHz, float gainDb, float q = 0.707f) noexcept {
        bands[1].freqHz = std::clamp(freqHz, 200.0f, 2500.0f);
        bands[1].gainDb = std::clamp(gainDb, -15.0f, 15.0f);
        bands[1].q = std::clamp(q, 0.5f, 2.5f);
        bands[1].type = BandType::Bell;
        updateBand(1);
    }

    // HMF Band (Band 2): 600 - 7000 Hz, +/-15 dB, Q [0.5 .. 2.5]
    void setHMF(float freqHz, float gainDb, float q = 0.707f) noexcept {
        bands[2].freqHz = std::clamp(freqHz, 600.0f, 7000.0f);
        bands[2].gainDb = std::clamp(gainDb, -15.0f, 15.0f);
        bands[2].q = std::clamp(q, 0.5f, 2.5f);
        bands[2].type = BandType::Bell;
        updateBand(2);
    }

    // HF Band (Band 3): 1500 - 16000 Hz, +/-15 dB (SSL 242 Bell Q = 1.25f per presenza vocale setosa)
    void setHF(float freqHz, float gainDb, BandType type = BandType::Shelf) noexcept {
        bands[3].freqHz = std::clamp(freqHz, 1500.0f, 16000.0f);
        bands[3].gainDb = std::clamp(gainDb, -15.0f, 15.0f);
        bands[3].type = type;
        bands[3].q = (type == BandType::Bell) ? 1.25f : 0.707f;
        updateBand(3);
    }

    // --- Audio Processing ---

    inline void processSample(float inL, float inR, float& outL, float& outR) noexcept {
        if (!std::isfinite(inL)) inL = 0.0f;
        if (!std::isfinite(inR)) inR = 0.0f;

        float sL = inL;
        float sR = inR;

        // 1. High-Pass Filter (18 dB/oct = 2nd order SVF HP + 1st order OnePole HP)
        if (hpfEnabled) {
            sL = hpfSVF_L.process(sL).hp;
            sR = hpfSVF_R.process(sR).hp;
            sL = hpfOnePole_L.process(sL);
            sR = hpfOnePole_R.process(sR);
        }

        // 2. Low-Pass Filter (12 dB/oct = 2nd order SVF LP)
        if (lpfEnabled) {
            sL = lpfSVF_L.process(sL).lp;
            sR = lpfSVF_R.process(sR).lp;
        }

        // 3. Parametric 4-Band SSL G-Series Cascade
        for (int b = 0; b < 4; ++b) {
            if (std::abs(bands[b].gainDb) < 0.05f) {
                // Bit-exact bypass: tick the SVF with zero to keep denormal guard active
                // and prevent stale state from causing buzz when band is re-enabled.
                bandSVF_L[b].process(0.0f);
                bandSVF_R[b].process(0.0f);
                continue;
            }

            if (bands[b].type == BandType::Bell) {
                // Bell mode: Formulazione Simmetrica Rigorosa Cytomic ZDF SVF (Andy Simper)
                // H(s) = [s^2 + (A/Q)*s + 1] / [s^2 + 1/(A*Q)*s + 1]
                // out = in + (A^2 - 1)/Q * bp   [corrected coefficient — no invalid decramp]
                const float coeffL = bellCoeffBP[b];
                const float bpL = bandSVF_L[b].process(sL).bp;
                const float bpR = bandSVF_R[b].process(sR).bp;
                sL += coeffL * bpL;
                sR += coeffL * bpR;
            } else {
                if (b == 0) {
                    // Low Shelf Cytomic ZDF SVF analitico bit-exact (Zero cancellazione di fase a 150Hz)
                    const auto outFiltL = bandSVF_L[0].process(sL);
                    const auto outFiltR = bandSVF_R[0].process(sR);
                    sL += shelfCoeffBP[0] * outFiltL.bp + shelfCoeff[0] * outFiltL.lp;
                    sR += shelfCoeffBP[0] * outFiltR.bp + shelfCoeff[0] * outFiltR.lp;
                } else if (b == 3) {
                    // High Shelf Cytomic ZDF SVF con risposta setosa priva di asprezze
                    const auto outFiltL = bandSVF_L[3].process(sL);
                    const auto outFiltR = bandSVF_R[3].process(sR);
                    sL += shelfCoeffBP[3] * outFiltL.bp + shelfCoeff[3] * outFiltL.hp;
                    sR += shelfCoeffBP[3] * outFiltR.bp + shelfCoeff[3] * outFiltR.hp;
                }
            }

            // Safety: catch any NaN/Inf from numerical instability
            if (!std::isfinite(sL)) sL = 0.0f;
            if (!std::isfinite(sR)) sR = 0.0f;
        }

        outL = sL;
        outR = sR;
    }

    void processBlock(float* inOutL, float* inOutR, size_t numSamples) noexcept {
        if (!inOutL || !inOutR || numSamples == 0) return;
        for (size_t i = 0; i < numSamples; ++i) {
            processSample(inOutL[i], inOutR[i], inOutL[i], inOutR[i]);
        }
    }

private:
    void updateHPF() noexcept {
        if (hpfEnabled) {
            hpfSVF_L.setParameters(hpfHz, 1.0f, sr);
            hpfSVF_R.setParameters(hpfHz, 1.0f, sr);
            hpfOnePole_L.setCutoff(hpfHz, sr);
            hpfOnePole_R.setCutoff(hpfHz, sr);
        }
    }

    void updateLPF() noexcept {
        if (lpfEnabled) {
            lpfSVF_L.setParameters(lpfHz, 0.707f, sr);
            lpfSVF_R.setParameters(lpfHz, 0.707f, sr);
        }
    }

    void updateBand(int b) noexcept {
        if (b < 0 || b >= 4) return;

        // Linear gain factor
        bandLinGain[b] = std::pow(10.0f, bands[b].gainDb * 0.05f);

        // SSL 4000 E/G "Black Knob" 242 EQ: Constant Bandwidth (Constant Q) su tutta l'escursione +/-15 dB
        // Andy Simper Cytomic ZDF SVF mantiene analiticamente la larghezza di banda costante
        // impostando Q_den = safeQ * A. L'impostazione diretta effectiveQ = bands[b].q garantisce
        // corrispondenza millimetrica tra il Q impostato a manopola e la curva effettiva.
        const float effectiveQ = bands[b].q;

        if (bands[b].type == BandType::Bell) {
            // Formulazione Cytomic ZDF SVF Bell (Andy Simper, "SVF & Peak EQ" 2013):
            // H(s) = [s^2 + (A/Q)*s + 1] / [s^2 + 1/(A*Q)*s + 1]
            // A = 10^(gainDb / 40)
            const float A = std::pow(10.0f, bands[b].gainDb * 0.025f);
            const float safeQ = std::max(0.1f, effectiveQ);

            // Denominatore: damping = 1/(2*A*Q) → impostare Q_den = A * safeQ nel SVF
            // poiché ZDFSVF64::setParameters imposta R = 1/(2*Q_param) → R = 1/(2*A*Q) ✓
            const float Q_den = safeQ * A;
            bandSVF_L[b].setParameters(bands[b].freqHz, Q_den, sr);
            bandSVF_R[b].setParameters(bands[b].freqHz, Q_den, sr);

            // Coefficiente BP corretto: out = in + c_bp * bp
            // Poiché bp ha guadagno di picco pari a Q_den = A * safeQ,
            // affinché il picco sia 1 + c_bp * Q_den = A^2 (G lineare esatto),
            // si ha: c_bp = (A^2 - 1) / Q_den = (A - 1/A) / safeQ.
            // FIX: eliminato il decramp errato che generava boost incontrollato ad alte frequenze.
            bellCoeffBP[b] = (A * A - 1.0f) / Q_den;

            // Flush denormali sugli stati SVF per eliminare sub-armoniche e ronzii residui
            bandSVF_L[b].flushDenormals();
            bandSVF_R[b].flushDenormals();

            // Se il guadagno della banda è a riposo (trasparenza bit-exact 0 dB), azzera gli integratori
            if (std::abs(bands[b].gainDb) < 0.05f) {
                bellCoeffBP[b] = 0.0f;
                bandSVF_L[b].reset();
                bandSVF_R[b].reset();
            }
        } else {
            // Shelf mode
            bellCoeffBP[b] = 0.0f;

            if (b == 0) {
                // LF Low-Shelf: Andy Simper Cytomic ZDF SVF formulation
                const float G = bandLinGain[0];
                const float A = std::sqrt(G);
                const float safeQ = 0.707f;
                const float fc = std::clamp(bands[0].freqHz / std::sqrt(A), 10.0f, sr * 0.45f);
                const float Q_den = safeQ * std::sqrt(A);
                bandSVF_L[0].setParameters(fc, Q_den, sr);
                bandSVF_R[0].setParameters(fc, Q_den, sr);
                shelfCoeffBP[0] = (A - 1.0f) / (safeQ * std::sqrt(A));
                shelfCoeff[0]   = G - 1.0f;
            } else if (b == 3) {
                // HF High-Shelf: Andy Simper Cytomic ZDF SVF formulation
                const float G = bandLinGain[3];
                const float A = std::sqrt(G);
                const float safeQ = 0.707f;
                // Formulazione simmetrica esatta: fc * sqrt(A) e coefficiente (A - 1.0)
                // Garantisce errore < 0.05 dB sia in boost (+6/+12 dB) che in attenuazione (-6/-12 dB)
                const float fc = std::clamp(bands[3].freqHz * std::sqrt(A), 20.0f, sr * 0.45f);
                const float Q_den = safeQ * std::sqrt(A);
                bandSVF_L[3].setParameters(fc, Q_den, sr);
                bandSVF_R[3].setParameters(fc, Q_den, sr);
                shelfCoeffBP[3] = (A - 1.0f) / (safeQ * std::sqrt(A));
                shelfCoeff[3]   = G - 1.0f;
            }
        }
    }

    void updateCoefficients() noexcept {
        updateHPF();
        updateLPF();
        for (int b = 0; b < 4; ++b) {
            updateBand(b);
        }
    }

    float sr = 48000.0f;
    float invSr = 1.0f / 48000.0f;

    float hpfHz = 16.0f;
    bool hpfEnabled = false;

    float lpfHz = 22000.0f;
    bool lpfEnabled = false;

    BandConfig bands[4]{
        { 80.0f, 0.0f, 0.707f, BandType::Shelf },   // LF
        { 450.0f, 0.0f, 1.0f, BandType::Bell },    // LMF
        { 2400.0f, 0.0f, 1.0f, BandType::Bell },   // HMF
        { 8000.0f, 0.0f, 0.707f, BandType::Shelf }  // HF
    };

    float bandLinGain[4]{ 1.0f, 1.0f, 1.0f, 1.0f };
    float bellCoeffBP[4]{ 0.0f, 0.0f, 0.0f, 0.0f };
    float shelfCoeffBP[4]{ 0.0f, 0.0f, 0.0f, 0.0f };
    float shelfCoeff[4]{ 0.0f, 0.0f, 0.0f, 0.0f };

    // High-Pass Filter (3rd Order 18 dB/oct)
    ZDFSVF64 hpfSVF_L;
    ZDFSVF64 hpfSVF_R;
    ZDFOnePoleHP64 hpfOnePole_L;
    ZDFOnePoleHP64 hpfOnePole_R;

    // Low-Pass Filter (2nd Order 12 dB/oct)
    ZDFSVF64 lpfSVF_L;
    ZDFSVF64 lpfSVF_R;

    // 4 Parametric Bands
    ZDFSVF64 bandSVF_L[4];
    ZDFSVF64 bandSVF_R[4];
    ZDFSVF64 undershootSVF_L[4];
    ZDFSVF64 undershootSVF_R[4];
    ZDFSVF64 bandSVF_3_L;
    ZDFSVF64 bandSVF_3_R;
};

} // namespace dsp171
