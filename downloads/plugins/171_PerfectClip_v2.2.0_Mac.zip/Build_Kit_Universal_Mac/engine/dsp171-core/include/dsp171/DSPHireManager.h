#pragma once

#include <string>
#include <sstream>
#include <array>
#include <string_view>
#include <cstdint>
#include <cstdio>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// DSP 171 HIRE MANAGER & ARCHITECTURAL DISPATCH ENGINE
//
// In-Engine "In Call" Hire Manager orchestrating 18 specialized autonomous
// agents across analog saturation, non-linear dynamics, vocal pitch tracking,
// MIDI 2.0/MPE, analytical mathematical physics, spatial audio & boutique GUI.
//
// Every DSP module instantiation, circuit topology selection, or real-time
// compilation unit can query DSPHireManager to establish the exact responsible
// domain engineer, algorithmic requirements, reviewer, and QA audit protocol.
// =============================================================================

enum class DomainTask : uint8_t {
    SaturationAnalog = 0,
    CompressionDynamics,
    PitchTrackingCorrection,
    MidiHarmonizationMPE,
    AnalyticalMathPhysics,
    SpatialAudioMastering,
    AudioEngineCore,
    BoutiqueGUI,
    CrossPlatformHost,
    SilkscreenTypography,
    PluginBoutiqueBranding,
    GuiReverseEngineering,
    AssetAtlasOptimization,
    SpatialReverbPhysical,
    DynamicDuckingSidechain,
    VintageConverterColor,
    MidSideMonoMaker,
    TransientMultiBandShaping,
    SubHarmonicSynthesis,
    ClipperDigitalHard,
    ClipperAnalogConverter,
    TransientDetailPreservation,
    TruePeakISPGovernor,
    ClipperReverseEngineering,
    CRTDeltaVisualizer,
    AcousticSpaceContinuumDynamics,
    SmartVocalCraft,
    VocalBeatSpectralUnmasking,
    MixReadyVocalMastery
};

enum class HardwareTarget : uint8_t {
    Neve_1073_1081 = 0,
    API_2520_2500,
    Avalon_VT737sp,
    Focusrite_ISA110_430,
    Studer_A800_Ampex_ATR102,
    Culture_Vulture,
    Clean_Precision_ADAA,
    Lavry_Gold_ADC122,
    Silicon_Germanium_Diode,
    Tube_Triode_ClassA,
    Custom_Hybrid
};

enum class CompressionTopology : uint8_t {
    Optical_T4B = 0,
    FET_1176,
    VCA_BusMaster,
    VariMu_DeltaTube,
    DiodeBridge_33609
};

enum class LatencyTolerance : uint8_t {
    ZeroLatencyLive_0ms = 0,
    LowLatencyTracking_Sub1ms,
    StandardMixing_Sub5ms,
    MasteringLookahead_Allowed
};

enum class MathModelPrecision : uint8_t {
    ADAA2_AntiAliased = 0,
    WDF_WaveDigitalFilter,
    RK4_ExplicitImplicit,
    ZDF_StateVariable,
    VolterraSeries
};

enum class TargetPlatform : uint8_t {
    UniversalCrossPlatform = 0,
    Windows_AVX2,
    macOS_AppleSilicon_NEON
};

struct DevelopmentVariables {
    DomainTask task = DomainTask::SaturationAnalog;
    HardwareTarget hardwareTarget = HardwareTarget::Neve_1073_1081;
    CompressionTopology compressionTopology = CompressionTopology::Optical_T4B;
    LatencyTolerance latencyTolerance = LatencyTolerance::ZeroLatencyLive_0ms;
    MathModelPrecision mathPrecision = MathModelPrecision::ADAA2_AntiAliased;
    TargetPlatform platform = TargetPlatform::UniversalCrossPlatform;
    uint32_t oversampleFactor = 4;        // 1x, 2x, 4x, 8x, 16x
    float cpuBudgetPercent = 0.5f;        // Target CPU budget per block (%)
    float targetH2HarmonicRatio = 0.40f;  // Even-order harmonic target
    float targetH3HarmonicRatio = 0.20f;  // Odd-order harmonic target
    bool preserveFormants = true;
    bool requireITUBS1770Compliance = false;
};

struct AgentAssignment {
    std::string_view agentId;
    std::string_view agentTitle;
    std::string_view systemPromptKey;
    std::string_view primaryResponsibility;
};

struct DispatchDecision {
    AgentAssignment primaryAgent;
    AgentAssignment reviewerAgent;
    AgentAssignment qaAuditorAgent;
    std::string_view recommendedCPlusPlusClass;
    std::string_view coreAlgorithmDescription;
    std::string_view safetyDirectives;
    std::string_view validationHarness;
    uint32_t estimatedLatencySamples = 0;
    uint32_t recommendedOversampling = 1;

    std::string toFormattedJson() const {
        std::ostringstream ss;
        ss << "{\n"
           << "  \"primary_agent\": {\n"
           << "    \"id\": \"" << primaryAgent.agentId << "\",\n"
           << "    \"title\": \"" << primaryAgent.agentTitle << "\",\n"
           << "    \"role\": \"" << primaryAgent.primaryResponsibility << "\"\n"
           << "  },\n"
           << "  \"reviewer_agent\": {\n"
           << "    \"id\": \"" << reviewerAgent.agentId << "\",\n"
           << "    \"title\": \"" << reviewerAgent.agentTitle << "\"\n"
           << "  },\n"
           << "  \"qa_auditor_agent\": {\n"
           << "    \"id\": \"" << qaAuditorAgent.agentId << "\"\n"
           << "  },\n"
           << "  \"implementation\": {\n"
           << "    \"recommended_class\": \"" << recommendedCPlusPlusClass << "\",\n"
           << "    \"core_algorithm\": \"" << coreAlgorithmDescription << "\",\n"
           << "    \"safety_directives\": \"" << safetyDirectives << "\",\n"
           << "    \"validation_harness\": \"" << validationHarness << "\",\n"
           << "    \"latency_samples\": " << estimatedLatencySamples << ",\n"
           << "    \"oversampling\": " << recommendedOversampling << "\n"
           << "  }\n"
           << "}";
        return ss.str();
    }

    std::string toMarkdownTicket() const {
        std::ostringstream ss;
        ss << "### [171 DSP HIRE MANAGER] Dispatch Ticket\n"
           << "- **Primary Specialist**: `" << primaryAgent.agentId << "` (" << primaryAgent.agentTitle << ")\n"
           << "  - *Duty*: " << primaryAgent.primaryResponsibility << "\n"
           << "- **Technical Reviewer**: `" << reviewerAgent.agentId << "` (" << reviewerAgent.agentTitle << ")\n"
           << "- **QA Auditor**: `" << qaAuditorAgent.agentId << "`\n"
           << "- **C++ Module**: `" << recommendedCPlusPlusClass << "`\n"
           << "- **Mathematical Topology**: " << coreAlgorithmDescription << "\n"
           << "- **Safety Protocol**: " << safetyDirectives << "\n"
           << "- **Test Harness**: `" << validationHarness << "`\n"
           << "- **Latency**: " << estimatedLatencySamples << " samples | **Oversampling**: " << recommendedOversampling << "x\n";
        return ss.str();
    }
};

class DSPHireManager {
public:
    // Core Agent Roster Metadata
    static constexpr AgentAssignment AGENT_MATH_BUGFINDER = {
        "dsp-math-bugfinder",
        "Bug Finder & Math-Physics Auditor",
        "dsp-math-bugfinder",
        "Singularity inspection, L'Hopital limit checks, zero-division prevention, ADAA stability"
    };

    static constexpr AgentAssignment AGENT_VST3_HOST = {
        "vst3-host-engineer",
        "VST3 SDK & Host Architecture Lead",
        "vst3-host-engineer",
        "Steinberg VST3 SDK compliance, Steinberg Validator, Reaper/Ableton/Cubase host compatibility"
    };

    static constexpr AgentAssignment AGENT_WINDOWS_SIMD = {
        "windows-systems-engineer",
        "Windows Systems & SIMD Optimization Specialist",
        "windows-systems-engineer",
        "AVX2/AVX-512 vectorization, MSVC LTCG, cache locality, low-overhead Windows memory management"
    };

    static constexpr AgentAssignment AGENT_APPLE_MACOS = {
        "apple-macos-engineer",
        "Apple macOS Cross-Platform Engineer",
        "apple-macos-engineer",
        "ARM64 NEON vectorization, Apple Silicon M1-M4 tuning, vDSP Accelerate, AUv2/VST3 Universal Binaries"
    };

    static constexpr AgentAssignment AGENT_BOUTIQUE_GUI = {
        "boutique-gui-specialist",
        "Boutique & Consumer GUI Specialist",
        "boutique-gui-specialist",
        "60 FPS luxury boutique interface rendering, zero heap allocations in paint(), cached vector paths"
    };

    static constexpr AgentAssignment AGENT_DSP_CORE = {
        "dsp-core-builder",
        "DSP Core & Circuit Modeling Engineer",
        "dsp-core-builder",
        "C++20 real-time audio components, filter topologies, oversampling polyphase half-band filters"
    };

    static constexpr AgentAssignment AGENT_DSP_AUDIT = {
        "dsp-audit-scalability",
        "DSP Audit, Scalability & QA Lead",
        "dsp-audit-scalability",
        "Null testing (-120 dBFS+), automated spectral analysis, thread safety, stress bench QA"
    };

    static constexpr AgentAssignment AGENT_COMP_OPTICAL = {
        "comp-optical-universal",
        "Universal Compressor Domain Specialist",
        "comp-optical-universal",
        "Optical T4B dual-stage decay, FET 1176 ultra-fast attack, VCA feedforward, Vari-Mu remote cutoff"
    };

    static constexpr AgentAssignment AGENT_SAT_NEVE = {
        "sat-neve-specialist",
        "Neve Console & Transformer Specialist",
        "sat-neve-specialist",
        "Neve 1073/1081 discrete Class-A, Marinair/Carnhill iron core flux saturation, even/odd harmonic balance"
    };

    static constexpr AgentAssignment AGENT_SAT_API = {
        "sat-api-specialist",
        "API 2520 & Proportional-Q Specialist",
        "sat-api-specialist",
        "API 2520 discrete op-amp slew limiting, 2503 transformer punch, proportional Q inductive curves"
    };

    static constexpr AgentAssignment AGENT_SAT_AVALON = {
        "sat-avalon-specialist",
        "Avalon VT-737sp Class-A Tube Specialist",
        "sat-avalon-specialist",
        "Avalon VT-737sp high-voltage Class-A dual-triodes (6922/12AX7), ultra-airy high frequency tube sheen"
    };

    static constexpr AgentAssignment AGENT_SAT_FOCUSRITE = {
        "sat-focusrite-specialist",
        "Focusrite ISA & Lundahl Specialist",
        "sat-focusrite-specialist",
        "Rupert Neve ISA 110/430 console circuit, Lundahl LL1538 mu-metal transformer, variable impedance loading"
    };

    static constexpr AgentAssignment AGENT_SAT_TAPE = {
        "sat-tape-modern-specialist",
        "Magnetic Tape & Extreme Saturation Specialist",
        "sat-tape-modern-specialist",
        "Studer A800, Ampex ATR-102 Jiles-Atherton hysteresis, tape head bump, Thermionic Culture Vulture pentode"
    };

    static constexpr AgentAssignment AGENT_PITCH_TUNE = {
        "pitch-tune-specialist",
        "Vocal Pitch & Tracking Specialist",
        "pitch-tune-specialist",
        "Zero-latency DPLL tracking, YIN/MPM, pitch-synchronous overlap-add (PSOLA), formant preservation"
    };

    static constexpr AgentAssignment AGENT_MIDI_HARMONY = {
        "midi-harmony-specialist",
        "MIDI 2.0 & Harmonizer Specialist",
        "midi-harmony-specialist",
        "MIDI 2.0 UMP, MPE per-note expression, diatonic multi-voice allocation, chromagram chord detection"
    };

    static constexpr AgentAssignment AGENT_MATH_PHYSICIST = {
        "analytical-math-physicist",
        "Chief Theoretical Physicist & Mathematician",
        "analytical-math-physicist",
        "Wave Digital Filters (WDF), Lambert W non-linear root solving, Runge-Kutta 4, Volterra series kernels"
    };

    static constexpr AgentAssignment AGENT_SPATIAL_MASTERING = {
        "spatial-mastering-engineer",
        "Spatial Audio & Mastering Engineer",
        "spatial-mastering-engineer",
        "ITU-R BS.1770-4 True Peak Limiter, 4x/8x inter-sample peak detection, Dolby Atmos 7.1.4 bed/object FDN"
    };

    static constexpr AgentAssignment AGENT_HIRE_MANAGER = {
        "dsp-hire-manager",
        "DSP Hire & Architectural Dispatch Manager",
        "dsp-hire-manager",
        "Continuous ecosystem talent hiring, development variable analysis, cross-agent orchestration"
    };

    // --- Newly Inducted Specialized Agents for Modern Vocal Strip Dominance ---
    static constexpr AgentAssignment AGENT_VOCAL_GATE = {
        "vocal-gate-expander-specialist",
        "Vocal Dynamics Gate & Expander Lead",
        "vocal-gate-expander-specialist",
        "Hysteresis Schmitt-trigger gate, soft vocal expander, sidechain bandpass detection, zero chattering"
    };

    static constexpr AgentAssignment AGENT_VOCAL_DOUBLER = {
        "vocal-spatial-doubler-specialist",
        "Vocal Doubler & Micro-Pitch Detune Lead",
        "vocal-spatial-doubler-specialist",
        "Sub-sample fractional Hermite delay, decorrelated micro-pitch detuning (+/- 9 cent), 100% mono compatibility"
    };

    static constexpr AgentAssignment AGENT_FFT_SPECTRAL = {
        "fft-spectral-visualizer-specialist",
        "Real-Time FFT & Spectral GR Visualizer Lead",
        "fft-spectral-visualizer-specialist",
        "60 FPS 2048-point Blackman-Harris real-time FFT, interactive EQ curve node overlay, spectral gain reduction rendering"
    };

    static constexpr AgentAssignment AGENT_SMART_LOUDNESS = {
        "smart-loudness-workflow-specialist",
        "Smart Loudness Matching & Delta Audition Lead",
        "smart-loudness-workflow-specialist",
        "ITU-R BS.1770 / EBU R128 momentary loudness normalization, delta audition subtraction matrix (y - x), A/B snapshots"
    };

    static constexpr AgentAssignment AGENT_MAAG_AIR = {
        "maag-air-resonance-specialist",
        "Air Band & Dynamic Vocal Resonance Specialist",
        "maag-air-resonance-specialist",
        "Maag Audio EQ4 Air Band 2.5k-40kHz sub-sample peaking shelf, dynamic notch resonance tamer, de-harshing"
    };

    // --- GUI Art & Visual Engineering Team (Agents 24 - 27) ---
    static constexpr AgentAssignment AGENT_GUI_ART_DIRECTOR = {
        "gui-art-director",
        "Art Director / Visual Identity Lead",
        "gui-art-director",
        "Bay color palettes, visual hierarchy, dual VU meter aesthetics, 171 suite visual coherence, Visual Style Guide"
    };

    static constexpr AgentAssignment AGENT_GUI_ARTWORKER = {
        "gui-artworker",
        "Artworker / Layout Compositor",
        "gui-artworker",
        "Pixel-perfect PNG asset positioning, definitive 4-bay blueprint coordinates (X/Y/W/H), 1x/2x Retina slicing"
    };

    static constexpr AgentAssignment AGENT_AI_IMAGE_PROMPT = {
        "ai-image-prompt-specialist",
        "AI Image Prompt Engineer",
        "ai-image-prompt-specialist",
        "Professional Midjourney v6 / Flux.1 prompts for metal faceplates, custom dials, PBR finishes, 5000K lighting"
    };

    static constexpr AgentAssignment AGENT_JUCE_GUI_IMPLEMENTER = {
        "juce-gui-implementer",
        "JUCE C++ GUI Implementer",
        "juce-gui-implementer",
        "Custom JUCE assemblies (VocalDualVUMeterAssembly.h), zero heap in paint(), < 1.5ms/frame at 60 FPS, ImageCache"
    };

    // --- GUI Reengineering, Silkscreen & Boutique Branding Guild (Agents 28 - 33) ---
    static constexpr AgentAssignment AGENT_GRAPHIC_DESIGNER = {
        "graphic-designer",
        "Senior Hardware Graphic Designer & PBR Materials",
        "graphic-designer",
        "CNC brushed metal finishes, volumetric shadows, PBR micro-bevels, 105 deg ambient occlusion"
    };

    static constexpr AgentAssignment AGENT_GUI_MATHEMATICIAN = {
        "gui-mathematician",
        "GUI Physics & Non-Linear Curve Mathematician",
        "gui-mathematician",
        "IEC 60268-17 needle ballistics, zero-heap Bezier splines, Pade approximants for polar rotation, audio tapers"
    };

    static constexpr AgentAssignment AGENT_SILKSCREEN_TYPOGRAPHY = {
        "silkscreen-typography-specialist",
        "Silkscreen & Studio Typography Specialist",
        "silkscreen-typography-specialist",
        "DIN 1451/Helvetica studio typography, baked-enamel color contrast, zero-collision exclusion zones"
    };

    static constexpr AgentAssignment AGENT_PLUGIN_BOUTIQUER = {
        "plugin-boutiquer",
        "Chief Boutique Packaging, Reengineering & Branding",
        "plugin-boutiquer",
        "Official 171 Studio branding, library asset reengineering, luxury hardware aesthetics"
    };

    static constexpr AgentAssignment AGENT_GUI_REVERSE_ENGINEER = {
        "gui-reverse-engineering-specialist",
        "GUI Deconstruction & Industrial Architecture",
        "gui-reverse-engineering-specialist",
        "Waves/UAD/Plugin Alliance GUI deconstruction, bay layout ratios, vector/raster layer separation"
    };

    static constexpr AgentAssignment AGENT_ASSET_ATLAS_OPTIMIZER = {
        "asset-atlas-optimizer",
        "Asset Atlas & BinaryData Memory Optimizer",
        "asset-atlas-optimizer",
        "Lossless 24-bit+8-bit alpha PNG packing, BinaryData generation, SIMD alignment, zero-latency RAM"
    };

    // --- 171PerfectClip Specialized Task Force (Agents 34 - 40) ---
    static constexpr AgentAssignment AGENT_CLIPPER_DIGITAL_HARD = {
        "clipper-digital-hard-specialist",
        "Senior Digital Hard-Clipping Lead",
        "clipper-digital-hard-specialist",
        "Bit-exact ADAA-2 piecewise hard clipping, polyphase oversampling up to 32x, zero-latency phase options"
    };

    static constexpr AgentAssignment AGENT_CLIPPER_ANALOG_CONVERTER = {
        "clipper-analog-converter-specialist",
        "Analog Saturation & Converter Circuit Modeler",
        "clipper-analog-converter-specialist",
        "Lavry Gold 122-96 ADC soft saturation, Shockley diode knee, Class-A triode warmth with H2/H3 balance"
    };

    static constexpr AgentAssignment AGENT_TRANSIENT_DETAIL_PRESERVATION = {
        "transient-detail-preservation-specialist",
        "Chief Psychoacoustic & Transient Engineer",
        "transient-detail-preservation-specialist",
        "TransDetail orthogonal carrier/detail decomposition, anti-IMD masking, high-frequency air contouring"
    };

    static constexpr AgentAssignment AGENT_ISP_TRUEPEAK_LIMITER = {
        "isp-truepeak-limiter-specialist",
        "Inter-Sample Peak & True Peak Governor Lead",
        "isp-truepeak-limiter-specialist",
        "ITU-R BS.1770-4 inter-sample peak detection, Whittaker-Shannon sinc reconstruction, true-peak safety ceiling"
    };

    static constexpr AgentAssignment AGENT_CLIPPER_REVERSE_ENGINEER = {
        "clipper-reverse-engineer",
        "Forensic VST Deconstruction Specialist",
        "clipper-reverse-engineer",
        "StandardCLIP, Gold Clip, Saturate, Flatline 2 and KClip 3 reverse engineering, transfer curve null testing"
    };

    static constexpr AgentAssignment AGENT_DSP_SCIENTIFIC_RESEARCHER = {
        "dsp-scientific-researcher",
        "Academic Research & Mathematical Physics Lead",
        "dsp-scientific-researcher",
        "DAFx/IEEE antiderivative derivations, continuous Taylor expansions, zero-division proof verification"
    };

    static constexpr AgentAssignment AGENT_GUI_OSCILLOSCOPE_VISUALIZER = {
        "gui-oscilloscope-visualizer-specialist",
        "Boutique Visualizer & CRT Scope Engineer",
        "gui-oscilloscope-visualizer-specialist",
        "60 FPS CRT vector oscilloscope, real-time waveform AC display, visual Delta highlight of clipped peaks"
    };

    static constexpr AgentAssignment AGENT_ACOUSTIC_WAVE_PHYSICIST = {
        "acoustic-wave-physicist-mathematician",
        "Acoustic Wave Physicist & Continuum Mechanics Theorist",
        "acoustic-wave-physicist-mathematician",
        "Burgers PDE acoustic wave steepening in air, Lorentz jerk limit, cochlear basilar membrane hydrodynamics, Joule heating ODE"
    };

    // --- 171VocalCraft Specialized Task Force (Agents 41 - 47) ---
    static constexpr AgentAssignment AGENT_AI_VOCAL_SPECTRAL = {
        "ai-vocal-spectral-engineer",
        "AI Vocal Spectral & Neutralization Lead",
        "ai-vocal-spectral-engineer",
        "Continuous real-time spectral tracking, acoustic neutralization, anti-boxiness, de-harsh and psychoacoustic flattening"
    };

    static constexpr AgentAssignment AGENT_AI_TRANSIENT_PHONEME = {
        "ai-transient-phoneme-detector",
        "AI Transient & Phoneme Detector Lead",
        "ai-transient-phoneme-detector",
        "Real-time consonant vs vowel classification, High-Frequency Spectral Flux & Zero-Crossing rate for punch-through"
    };

    static constexpr AgentAssignment AGENT_SMART_GAIN_STAGER = {
        "smart-gain-staging-calibrator",
        "Smart Vocal Gain Stager & Calibrator Lead",
        "smart-gain-staging-calibrator",
        "ITU-R BS.1770 / RMS automatic input calibration to -18 dBFS with clickless cross-ramping and lock"
    };

    static constexpr AgentAssignment AGENT_HIPHOP_VOCAL = {
        "hiphop-vocal-architect",
        "Chief Hip-Hop & Rap Vocal Dynamics Specialist",
        "hiphop-vocal-architect",
        "Consonant Punch-Through architecture, fast dynamic attack on syllable transients, aggressive sustain leveling"
    };

    static constexpr AgentAssignment AGENT_POP_VOCAL = {
        "pop-vocal-polisher",
        "Modern Pop & Commercial Vocal Polisher",
        "pop-vocal-polisher",
        "Silky in-your-face leveling, dual-stage Opto+FET dynamics, musical breath preservation with zero pumping"
    };

    static constexpr AgentAssignment AGENT_TRAP_VOCAL = {
        "trap-urban-specialist",
        "Trap, Drill & Modern Urban Dynamics Lead",
        "trap-urban-specialist",
        "High-density crest factor reduction, sidechain sub-bass decoupling, laser-focused auto-tune vocal presence"
    };

    static constexpr AgentAssignment AGENT_RNB_VOCAL = {
        "rnb-soul-specialist",
        "R&B, Soul & Dynamic Vocal Nuance Specialist",
        "rnb-soul-specialist",
        "Dynamic breathing envelope, warm mid-range preservation, delicate falsetto-to-chest transitions"
    };

    static constexpr AgentAssignment AGENT_AI_BEAT_UNMASKER = {
        "ai-beat-spectral-unmasker",
        "AI Beat Spectral Unmasker & Pocket Carver Specialist",
        "ai-beat-spectral-unmasker",
        "Real-time sidechain instrumental analysis, cross-spectral coherence tracking, frequency collision detection and dynamic auto-pocket unmasking"
    };

    static constexpr AgentAssignment AGENT_MIX_READY_PRODUCER = {
        "mix-ready-vocal-producer",
        "Mix-Ready Vocal Production Lead & Downstream FX Primer",
        "mix-ready-vocal-producer",
        "Mix-ready vocal chain preparation, downstream drive/saturation priming (dynamic de-essing), and reverb air sheen"
    };

    // =========================================================================
    // Core Dispatch Logic
    // Evaluates development variables and assigns the optimal engineering team.
    // =========================================================================
    static DispatchDecision dispatch(const DevelopmentVariables& vars) noexcept {
        DispatchDecision d;
        d.qaAuditorAgent = AGENT_DSP_AUDIT;

        // Determine secondary technical reviewer based on platform and math complexity
        if (vars.platform == TargetPlatform::macOS_AppleSilicon_NEON) {
            d.reviewerAgent = AGENT_APPLE_MACOS;
        } else if (vars.platform == TargetPlatform::Windows_AVX2) {
            d.reviewerAgent = AGENT_WINDOWS_SIMD;
        } else if (vars.mathPrecision == MathModelPrecision::WDF_WaveDigitalFilter ||
                   vars.mathPrecision == MathModelPrecision::RK4_ExplicitImplicit ||
                   vars.mathPrecision == MathModelPrecision::VolterraSeries) {
            d.reviewerAgent = AGENT_MATH_PHYSICIST;
        } else {
            d.reviewerAgent = AGENT_MATH_BUGFINDER;
        }

        switch (vars.task) {
            case DomainTask::SaturationAnalog: {
                d.recommendedOversampling = (vars.oversampleFactor > 0) ? vars.oversampleFactor : 4;
                switch (vars.hardwareTarget) {
                    case HardwareTarget::Neve_1073_1081:
                        d.primaryAgent = AGENT_SAT_NEVE;
                        d.recommendedCPlusPlusClass = "dsp171::TransformerSaturator / dsp171::NevePreampStrip";
                        d.coreAlgorithmDescription = "BA283 single-ended Class-A preamp with dynamic bias sag, Marinair LO1166 Faraday core flux hysteresis (< 50 Hz), and asymmetric resonant inductor EQ curves";
                        d.safetyDirectives = "Apply DCBlocker on output (10 Hz), ensure core flux pole fcCore is clamped in [10 Hz, 40 Hz], verify inductor ZDF Q stability";
                        d.validationHarness = "test_decapitator_and_tune.cpp / harmonic_spectrum_audit.py";
                        break;
                    case HardwareTarget::API_2520_2500:
                        d.primaryAgent = AGENT_SAT_API;
                        d.recommendedCPlusPlusClass = "dsp171::APIDiscreteSaturator / dsp171::APIVisionStrip";
                        d.coreAlgorithmDescription = "API 2520 discrete op-amp with 15 V/us slew-rate limiting, AP2503 steel transformer H3 saturation, and Proportional-Q auto-bandwidth filter topology";
                        d.safetyDirectives = "Slew-rate limiter state must have anti-windup clamping to supply rails (+/- 15V); Proportional-Q bandwidth bounded in [0.4, 3.2]";
                        d.validationHarness = "test_transient_punch.cpp / api_thd_audit.py";
                        break;
                    case HardwareTarget::Avalon_VT737sp:
                        d.primaryAgent = AGENT_SAT_AVALON;
                        d.recommendedCPlusPlusClass = "dsp171::AvalonTubeSaturator / dsp171::AvalonStrip";
                        d.coreAlgorithmDescription = "High-voltage Class-A dual-triode (6922/12AX7, 150V+ plate) Child-Langmuir quadratic H2 warmth with 32 kHz passive LC ultra-air sheen shelving filter";
                        d.safetyDirectives = "Grid current conduction threshold check; Taylor expansion stability; air shelving gain bounded to +12 dB";
                        d.validationHarness = "test_tube_harmonics.cpp / avalon_air_sheen_audit.py";
                        break;
                    case HardwareTarget::Focusrite_ISA110_430:
                        d.primaryAgent = AGENT_SAT_FOCUSRITE;
                        d.recommendedCPlusPlusClass = "dsp171::FocusriteISAPreamp";
                        d.coreAlgorithmDescription = "Rupert Neve ISA 110 wideband topology with Lundahl LL1538 mu-metal transformer impedance network";
                        d.safetyDirectives = "Variable Z input loading damping filter must maintain unconditional BIBO stability";
                        d.validationHarness = "test_isa_impedance.cpp / focusrite_frequency_response_audit.py";
                        break;
                    case HardwareTarget::Studer_A800_Ampex_ATR102:
                        d.primaryAgent = AGENT_SAT_TAPE;
                        d.recommendedCPlusPlusClass = "dsp171::TapeHysteresisDSP / dsp171::TapeMachineStrip";
                        d.coreAlgorithmDescription = "Jiles-Atherton differential magnetic hysteresis M(H), 7.5/15/30 IPS tape speed, NAB/CCIR EQ, low-frequency head bump resonance (55 Hz @ 15 IPS, 100 Hz @ 30 IPS), sinc repro gap loss, tape formulation calibration (250, 456, GP9, ATR) and wow/flutter mechanical transport";
                        d.safetyDirectives = "Magnetization state M(H) bounded to saturation magnetization Ms; head bump filter unconditionally BIBO stable; fractional Hermite delay line for wow/flutter bounded in +/- 2.5 ms without audio buffer underruns";
                        d.validationHarness = "test_tape_compression.cpp / tape_hysteresis_audit.py";
                        break;
                    case HardwareTarget::Culture_Vulture:
                        d.primaryAgent = AGENT_SAT_TAPE;
                        d.recommendedCPlusPlusClass = "dsp171::CultureVultureDSP / dsp171::DecapitatorDSP(StyleT/StyleP)";
                        d.coreAlgorithmDescription = "Thermionic dual pentode 6AS6 with switchable Triode (dominant H2) and Pentode (H3/H5) modes, screen grid Vg2 starvation bias circuit, pre/post emphasis tilt filters, and push-pull output transformer saturation";
                        d.safetyDirectives = "Screen grid starvation parameter Vg2 clamped in [15V, 120V] to eliminate zero-crossing infinite slope singularity; anti-runaway headroom limiter on +20 dB Punish boost; DCBlocker at 10 Hz";
                        d.validationHarness = "test_culture_vulture.cpp / thd_distribution_audit.py";
                        break;
                    default:
                        d.primaryAgent = AGENT_MATH_BUGFINDER;
                        d.recommendedCPlusPlusClass = "dsp171::ADAA2Clipper";
                        d.coreAlgorithmDescription = "Antialiased ADAA-2 Diode Clipper with analytic Taylor limit expansion";
                        d.safetyDirectives = "Enforce Taylor expansion when |x2 - x1| < 1e-5 to eliminate 0/0 floating-point singularity";
                        d.validationHarness = "test_crossfade_math.cpp / test_full_suite.cpp";
                        break;
                }
                break;
            }

            case DomainTask::CompressionDynamics: {
                d.primaryAgent = AGENT_COMP_OPTICAL;
                d.recommendedOversampling = 1;
                switch (vars.compressionTopology) {
                    case CompressionTopology::Optical_T4B:
                        d.recommendedCPlusPlusClass = "dsp171::CLA2ACompressor";
                        d.coreAlgorithmDescription = "Dual-stage photoresistor decay with memory trap hysteresis, T4B Vintage selector (Classic Waves vs UAD Silver Late 60s vs UAD Gray Mid 60s), and 12AX7 tube makeup gain";
                        d.safetyDirectives = "Slow photoconductive memory state & luminescent trap clamped >= 0.0f; denormal flush at < 1e-5f; zero-latency bufferless execution (0 samples)";
                        d.validationHarness = "optical_compressor_audit.py / test_full_suite.cpp";
                        d.estimatedLatencySamples = 0;
                        break;
                    case CompressionTopology::FET_1176:
                        d.recommendedCPlusPlusClass = "dsp171::CLA76Compressor";
                        d.coreAlgorithmDescription = "Ultra-fast FET feedback attenuation (20 to 1000 microseconds attack), Rev A Bluestripe vs Rev E Blackface differentiation, and All-Buttons In British Mode with collapsed bias";
                        d.safetyDirectives = "Zero-delay feedback peak rectifier with non-negative GR clamp, denormal flush at < 1e-5f, strictly zero latency (0 samples)";
                        d.validationHarness = "optical_compressor_audit.py / test_full_suite.cpp";
                        d.estimatedLatencySamples = 0;
                        break;
                    case CompressionTopology::VCA_BusMaster:
                        d.recommendedCPlusPlusClass = "dsp171::VCABusCompressor";
                        d.coreAlgorithmDescription = "Feedforward VCA logarithmic decibel detector with programmatic auto-release";
                        d.safetyDirectives = "Log/Exp envelope converter must clamp below -120 dBFS to prevent -infinity float";
                        d.validationHarness = "test_vca_bus.cpp / bus_compressor_audit.py";
                        d.estimatedLatencySamples = 0;
                        break;
                    case CompressionTopology::VariMu_DeltaTube:
                        d.recommendedCPlusPlusClass = "dsp171::VariMuCompressor";
                        d.coreAlgorithmDescription = "Fairchild 670 variable-mu remote-cutoff tube grid bias gain reduction with interstage transformers";
                        d.safetyDirectives = "Grid bias voltage must be bounded to cutoff threshold (-40V)";
                        d.validationHarness = "test_vari_mu.cpp / fairchild_audit.py";
                        d.estimatedLatencySamples = 0;
                        break;
                    case CompressionTopology::DiodeBridge_33609:
                        d.recommendedCPlusPlusClass = "dsp171::DiodeBridgeCompressor";
                        d.coreAlgorithmDescription = "Neve 2254/33609 quad diode bridge attenuator with high-frequency sidechain pre-emphasis";
                        d.safetyDirectives = "Diode conduction model requires balanced AC coupling to prevent DC control voltage thump";
                        d.validationHarness = "test_diode_bridge.cpp / neve_33609_audit.py";
                        d.estimatedLatencySamples = 0;
                        break;
                }
                break;
            }

            case DomainTask::PitchTrackingCorrection: {
                d.primaryAgent = AGENT_PITCH_TUNE;
                d.reviewerAgent = AGENT_MATH_BUGFINDER;
                if (vars.latencyTolerance == LatencyTolerance::ZeroLatencyLive_0ms) {
                    d.recommendedCPlusPlusClass = "dsp171::DPLLPitchTracker & dsp171::RealTuneEngine";
                    d.coreAlgorithmDescription = "Sub-millisecond Digital Phase-Locked Loop (DPLL) with instant glottal closure tracking";
                    d.safetyDirectives = "Lock-free ringbuffer FIFO for parameter handoff; denormal protection in loop filter integrator";
                    d.validationHarness = "test_dpll_and_lpc.cpp / test_realtune.cpp";
                    d.estimatedLatencySamples = 0;
                } else {
                    d.recommendedCPlusPlusClass = "dsp171::PitchDetectorMPM & dsp171::TDPSOLAShifter";
                    d.coreAlgorithmDescription = "McLeod Pitch Method (MPM) cross-correlation with Pitch Synchronous OverLap-Add (PSOLA)";
                    d.safetyDirectives = "Ensure peak correlation threshold > 0.85 before triggering pitch jump; avoid phase jumps";
                    d.validationHarness = "test_pitch_sync_shifter.cpp / test_reformed_formants.cpp";
                    d.estimatedLatencySamples = 128;
                }
                break;
            }

            case DomainTask::MidiHarmonizationMPE: {
                d.primaryAgent = AGENT_MIDI_HARMONY;
                d.reviewerAgent = AGENT_VST3_HOST;
                d.recommendedCPlusPlusClass = "dsp171::MusicalQuantizer & dsp171::MidiVoiceAllocator";
                d.coreAlgorithmDescription = "MIDI 2.0 Universal Packet processor with MPE voice management and diatonic modal harmonization";
                d.safetyDirectives = "Thread-safe lock-free MIDI FIFO; zero memory allocation inside audio/midi render block";
                d.validationHarness = "test_musical_quantizer.cpp / midi_voice_audit.py";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::AnalyticalMathPhysics: {
                d.primaryAgent = AGENT_MATH_PHYSICIST;
                d.reviewerAgent = AGENT_MATH_BUGFINDER;
                d.recommendedCPlusPlusClass = "dsp171::WDFCircuitSolver / dsp171::RK4StateSpace";
                d.coreAlgorithmDescription = "Wave Digital Filter adaptor tree with Wright Omega / Lambert W non-linear root solver";
                d.safetyDirectives = "Rigorous Lyapunov stability boundary check; verify spectral radius of state transition matrix < 1";
                d.validationHarness = "test_wdf_solver.cpp / math_convergence_audit.py";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::SpatialAudioMastering: {
                d.primaryAgent = AGENT_SPATIAL_MASTERING;
                d.reviewerAgent = AGENT_DSP_AUDIT;
                d.recommendedCPlusPlusClass = "dsp171::SafetyCeiling & dsp171::TruePeakLimiterBS1770";
                d.coreAlgorithmDescription = "ITU-R BS.1770-4 4x/8x polyphase oversampling true peak detection with lookahead limiter and TPDF dither";
                d.safetyDirectives = "Lookahead circular buffer delay compensation must be reported bit-accurately to VST3 host latency";
                d.validationHarness = "test_safety_ceiling.cpp / itu_bs1770_compliance_audit.py";
                d.estimatedLatencySamples = 128;
                d.recommendedOversampling = 4;
                break;
            }

            case DomainTask::BoutiqueGUI: {
                d.primaryAgent = AGENT_BOUTIQUE_GUI;
                d.reviewerAgent = AGENT_WINDOWS_SIMD;
                d.recommendedCPlusPlusClass = "dsp171::gui::RapidGUI & dsp171::gui::DualScreenVisualizer";
                d.coreAlgorithmDescription = "Zero-heap-allocation 60 FPS vector rendering with cached background bitmaps and CRT phosphor shaders";
                d.safetyDirectives = "Strictly ZERO juce::Path::addLineTo() or new/malloc in paint(); all paths pre-allocated in resized()";
                d.validationHarness = "gui_frame_rate_profiler.py / Reaper 60fps monitor";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::SilkscreenTypography: {
                d.primaryAgent = AGENT_SILKSCREEN_TYPOGRAPHY;
                d.reviewerAgent = AGENT_PLUGIN_BOUTIQUER;
                d.recommendedCPlusPlusClass = "gui171::SilkscreenEngine & gui171::TypographyGrid";
                d.coreAlgorithmDescription = "DIN 1451 Mittelschrift & studio enamel serigraphy with sub-pixel sub-raster rendering and strict 14px anti-collision exclusion zones";
                d.safetyDirectives = "Zero static text in faceplate bitmaps; all functional labels rendered vectorially; check label bounding boxes for collision";
                d.validationHarness = "snapshot_typography_audit.py / 171EasyVoice_Snapshot.exe";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::PluginBoutiqueBranding: {
                d.primaryAgent = AGENT_PLUGIN_BOUTIQUER;
                d.reviewerAgent = AGENT_GRAPHIC_DESIGNER;
                d.recommendedCPlusPlusClass = "gui171::BoutiqueBrandManager & gui171::HardwareChassis";
                d.coreAlgorithmDescription = "Official 171 Studio luxury skeuomorphic branding, brass badge inlay, CNC beveling, and library asset reengineering";
                d.safetyDirectives = "Strict 171 Studio branding badge placement; CNC ambient occlusion at 105 deg; 60 FPS zero-heap rendering";
                d.validationHarness = "asset_library_branding_audit.py / test_boutique_branding.cpp";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::GuiReverseEngineering: {
                d.primaryAgent = AGENT_GUI_REVERSE_ENGINEER;
                d.reviewerAgent = AGENT_GUI_MATHEMATICIAN;
                d.recommendedCPlusPlusClass = "gui171::IndustrialLayoutDeconstructor";
                d.coreAlgorithmDescription = "Black-box layout triangulation across Waves WGUI, UAD LUNA, and Brainworx PA-Toolbar for bay ratios and tactile ergonomics";
                d.safetyDirectives = "Ensure complete separation between static metal background and dynamic controls; verify 60 FPS zero heap in paint()";
                d.validationHarness = "reverse_engineering_layout_verifier.py";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::AssetAtlasOptimization: {
                d.primaryAgent = AGENT_ASSET_ATLAS_OPTIMIZER;
                d.reviewerAgent = AGENT_WINDOWS_SIMD;
                d.recommendedCPlusPlusClass = "gui171::BinaryDataAtlas & gui171::ImageCacheSIMD";
                d.coreAlgorithmDescription = "Lossless 24-bit+8-bit alpha texture packing, CMake BinaryData compilation, SIMD memory alignment, and zero-latency RAM access";
                d.safetyDirectives = "Total VST3 binary size under 10 MB; ensure all images in BinaryData have valid PNG headers and cache keys";
                d.validationHarness = "binary_data_size_audit.py / CMakeLists.txt verify";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::SpatialReverbPhysical: {
                d.primaryAgent = AGENT_SPATIAL_MASTERING;
                d.reviewerAgent = AGENT_MATH_PHYSICIST;
                d.recommendedCPlusPlusClass = "dsp171::ReverbFDN16 & dsp171::SchroederDiffuser & dsp171::PlateDispersionFilter & dsp171::HarmonicShimmer";
                d.coreAlgorithmDescription = "16-channel orthogonal Householder FDN with coprime delay lines, quadrature pointer modulation, Schroeder golden-ratio diffusers, EMT 140 bending wave dispersion, and dual-head shimmer";
                d.safetyDirectives = "Unconditional energy preservation with Householder unitary matrix; fastTanh loop soft-clipping; zero heap allocations";
                d.validationHarness = "test_enriched_dsp_suite.cpp";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::DynamicDuckingSidechain: {
                d.primaryAgent = AGENT_COMP_OPTICAL;
                d.reviewerAgent = AGENT_SPATIAL_MASTERING;
                d.recommendedCPlusPlusClass = "dsp171::SmartDuckingVCA";
                d.coreAlgorithmDescription = "Fast RMS/Peak logarithmic envelope follower with threshold, depth, decoupled attack/release, and internal dry or external aux sidechain gating";
                d.safetyDirectives = "Log/Exp envelope converter clamped above -120 dBFS; 1-pole anti-zipper VCA smoothing";
                d.validationHarness = "test_enriched_dsp_suite.cpp";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::VintageConverterColor: {
                d.primaryAgent = AGENT_SAT_NEVE;
                d.reviewerAgent = AGENT_MATH_BUGFINDER;
                d.recommendedCPlusPlusClass = "dsp171::VintageColorUnit";
                d.coreAlgorithmDescription = "1970s decimation with 12-bit mantissa quantizer and 4-pole Butterworth reconstruction vs 1980s 16-bit pre/de-emphasis vs NOW 32-bit floating point";
                d.safetyDirectives = "ZDF SVF 64-bit filters; sample hold anti-denormal flush; zero allocation";
                d.validationHarness = "test_enriched_dsp_suite.cpp";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::MidSideMonoMaker: {
                d.primaryAgent = AGENT_SPATIAL_MASTERING;
                d.reviewerAgent = AGENT_DSP_CORE;
                d.recommendedCPlusPlusClass = "dsp171::MonoMakerMS";
                d.coreAlgorithmDescription = "TrueSpace Mid/Side matrix with 2-pole ZDF SVF highpass strictly on Side channel (20-400 Hz) and continuous stereo width scaling";
                d.safetyDirectives = "Constant-power M/S encoding (1/sqrt(2)); zero phase cancellation in mono downmix";
                d.validationHarness = "test_enriched_dsp_suite.cpp";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::TransientMultiBandShaping: {
                d.primaryAgent = AGENT_COMP_OPTICAL;
                d.reviewerAgent = AGENT_MATH_PHYSICIST;
                d.qaAuditorAgent = AGENT_MATH_BUGFINDER;
                d.recommendedCPlusPlusClass = "dsp171::PunchCraftEngine / dsp171::DifferentialTransientDetector";
                d.coreAlgorithmDescription = "Level-independent Differential Envelope Technology (D.E.T.) with 3-band 24 dB/oct Linkwitz-Riley ZDF SVF crossover and transient/sustain dual multipliers";
                d.safetyDirectives = "Enforce flat magnitude summation across crossover; prevent infinite gain boost with ADAA soft-clipper at -0.1 dBFS";
                d.validationHarness = "PunchCraftTestMain.cpp";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::SubHarmonicSynthesis: {
                d.primaryAgent = AGENT_MATH_PHYSICIST;
                d.reviewerAgent = AGENT_MATH_BUGFINDER;
                d.qaAuditorAgent = AGENT_DSP_AUDIT;
                d.recommendedCPlusPlusClass = "dsp171::SubHarmonicSynthesizer";
                d.coreAlgorithmDescription = "Hysteresis Schmitt-trigger zero-crossing octave divider (f0/2) with continuous cosine wavefolder and dynamic transient envelope follower";
                d.safetyDirectives = "Freeze sub-oscillation on silent pauses (threshold 1e-4); zero DC offset";
                d.validationHarness = "PunchCraftTestMain.cpp";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::ClipperDigitalHard: {
                d.primaryAgent = AGENT_CLIPPER_DIGITAL_HARD;
                d.reviewerAgent = AGENT_DSP_SCIENTIFIC_RESEARCHER;
                d.qaAuditorAgent = AGENT_DSP_AUDIT;
                d.recommendedCPlusPlusClass = "dsp171::ADAA2HardClipper";
                d.coreAlgorithmDescription = "Analytical 2nd-order ADAA piecewise hard-clipper with continuous antiderivatives F1, F2 and L'Hopital/Taylor limit fallback";
                d.safetyDirectives = "Taylor expansion tolerance eps=1e-5 to guarantee non-zero denominator; clamp output to threshold; NaN/Inf guard";
                d.validationHarness = "verify_adaa2_hardclipper.cpp";
                d.recommendedOversampling = (vars.oversampleFactor > 0) ? vars.oversampleFactor : 4;
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::ClipperAnalogConverter: {
                d.primaryAgent = AGENT_CLIPPER_ANALOG_CONVERTER;
                d.reviewerAgent = AGENT_SAT_NEVE;
                d.qaAuditorAgent = AGENT_DSP_AUDIT;
                d.recommendedCPlusPlusClass = "dsp171::PerfectClipEngine";
                d.coreAlgorithmDescription = "Lavry Gold ADC 122-96 soft-knee diode conduction f(x)=x/sqrt(1+x^2) and Class-A triode warmth with controllable H2/H3 harmonic morphing";
                d.safetyDirectives = "Dynamic equal-loudness calibration; DC-blocker on output; smooth parameter ramping";
                d.validationHarness = "verify_analog_clipper.cpp";
                d.recommendedOversampling = (vars.oversampleFactor > 0) ? vars.oversampleFactor : 4;
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::TransientDetailPreservation: {
                d.primaryAgent = AGENT_TRANSIENT_DETAIL_PRESERVATION;
                d.reviewerAgent = AGENT_MATH_PHYSICIST;
                d.qaAuditorAgent = AGENT_DSP_AUDIT;
                d.recommendedCPlusPlusClass = "dsp171::TransDetailMatrix";
                d.coreAlgorithmDescription = "Zero-latency orthogonal carrier/detail Linkwitz-Riley decomposition with psychoacoustic dynamic masking and high-frequency alchemy contour";
                d.safetyDirectives = "Enforce orthogonal reconstruction: Carrier + Detail = Input; prevent IMD splatter with Bark critical band gain weighting";
                d.validationHarness = "verify_transdetail_matrix.cpp";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::TruePeakISPGovernor: {
                d.primaryAgent = AGENT_ISP_TRUEPEAK_LIMITER;
                d.reviewerAgent = AGENT_SPATIAL_MASTERING;
                d.qaAuditorAgent = AGENT_DSP_AUDIT;
                d.recommendedCPlusPlusClass = "dsp171::TruePeakLimiterBS1770";
                d.coreAlgorithmDescription = "ITU-R BS.1770-4 compliant 4x/8x inter-sample peak detector with lookahead delay buffer and safety ceiling governor";
                d.safetyDirectives = "Strict safety ceiling adherence <= -0.1 dBTP; subnormal flush; zero overshoot under inter-sample reconstruction";
                d.validationHarness = "verify_truepeak_isp.cpp";
                d.estimatedLatencySamples = 64;
                break;
            }

            case DomainTask::ClipperReverseEngineering: {
                d.primaryAgent = AGENT_CLIPPER_REVERSE_ENGINEER;
                d.reviewerAgent = AGENT_DSP_SCIENTIFIC_RESEARCHER;
                d.qaAuditorAgent = AGENT_DSP_AUDIT;
                d.recommendedCPlusPlusClass = "dsp171::ClipperForensicAnalyzer";
                d.coreAlgorithmDescription = "Black-box transfer curve null-test, aliasing floor harmonic analysis, and dynamic response profiling across StandardCLIP, Gold Clip, Saturate, Flatline 2 and KClip 3";
                d.safetyDirectives = "Strict isolation of proprietary binary code; clean-room mathematical reimplementation from first principles";
                d.validationHarness = "benchmark_clipper_suite.py";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::CRTDeltaVisualizer: {
                d.primaryAgent = AGENT_GUI_OSCILLOSCOPE_VISUALIZER;
                d.reviewerAgent = AGENT_BOUTIQUE_GUI;
                d.qaAuditorAgent = AGENT_DSP_AUDIT;
                d.recommendedCPlusPlusClass = "dsp171::PerfectClipCRTVisualizer";
                d.coreAlgorithmDescription = "60 FPS lock-free triple-buffered bipolar CRT vector oscilloscope with real-time amber phosphor highlight on clipped delta peaks and Tektronix reticle";
                d.safetyDirectives = "Zero mutexes and zero heap allocations on the audio processing thread; decoupled 60 Hz timer UI polling";
                d.validationHarness = "test_crt_scope_fps.cpp";
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::AcousticSpaceContinuumDynamics: {
                d.primaryAgent = AGENT_ACOUSTIC_WAVE_PHYSICIST;
                d.reviewerAgent = AGENT_DSP_SCIENTIFIC_RESEARCHER;
                d.qaAuditorAgent = AGENT_DSP_AUDIT;
                d.recommendedCPlusPlusClass = "dsp171::AcousticThermalDiodeClipper";
                d.coreAlgorithmDescription = "C2 quintic continuous transition corridor eliminating acoustic shockwaves in air and infinite transducer jerk, coupled with 35 ms dynamic Joule heating thermal sag and discrete JFET H2 @ -52 dBFS";
                d.safetyDirectives = "Exact exponential integration on thermal state; midpoint Taylor expansion for d0 -> 0; L'Hopital limit for dTot -> 0";
                d.validationHarness = "verify_171perfectclip.cpp";
                d.recommendedOversampling = 1;
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::SmartVocalCraft: {
                d.primaryAgent = AGENT_HIPHOP_VOCAL;
                d.reviewerAgent = AGENT_AI_TRANSIENT_PHONEME;
                d.qaAuditorAgent = AGENT_SMART_GAIN_STAGER;
                d.recommendedCPlusPlusClass = "dsp171::VocalCraftEngine";
                d.coreAlgorithmDescription = "End-to-End Smart Vocal Chain: (1) ITU-R BS.1770 Auto-Gain Staging (-18 dBFS), (2) Minimum-Phase Adaptive Spectral Linearizer, (3) AI Phoneme/Consonant Punch-Through Detector, (4) Style-Conditioned Dynamic Compressor (Hip-Hop/Pop/Trap/RnB), (5) Real-Time Loudness Auto-Makeup";
                d.safetyDirectives = "Denormal flushing; bounds checking on spectral envelope; seamless clickless gain staging ramp; consonant detector smoothing";
                d.validationHarness = "verify_171vocalcraft.cpp";
                d.recommendedOversampling = 1;
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::VocalBeatSpectralUnmasking: {
                d.primaryAgent = AGENT_AI_BEAT_UNMASKER;
                d.reviewerAgent = AGENT_AI_VOCAL_SPECTRAL;
                d.qaAuditorAgent = AGENT_MIX_READY_PRODUCER;
                d.recommendedCPlusPlusClass = "dsp171::VocalCraftBeatUnmasker";
                d.coreAlgorithmDescription = "Auxiliary sidechain stereo beat analysis across 64 critical bands, real-time cross-spectral masking ratio M[b], dynamic pocket carving, and collision neutralization";
                d.safetyDirectives = "Zero latency; lock-free sidechain buffer ingestion; bounded dynamic EQ boost/cut ([-6dB, +4dB])";
                d.validationHarness = "verify_171vocalcraft.cpp / adversarial_audit_171vocalcraft.cpp";
                d.recommendedOversampling = 1;
                d.estimatedLatencySamples = 0;
                break;
            }

            case DomainTask::MixReadyVocalMastery: {
                d.primaryAgent = AGENT_MIX_READY_PRODUCER;
                d.reviewerAgent = AGENT_AI_BEAT_UNMASKER;
                d.qaAuditorAgent = AGENT_DSP_AUDIT;
                d.recommendedCPlusPlusClass = "dsp171::VocalCraftBeatUnmasker & dsp171::VocalCraftEngine";
                d.coreAlgorithmDescription = "Downstream creative FX preparation: Smart dynamic de-essing (6.8 kHz) for pre-saturation conditioning + 12 kHz air sheen for spatial diffusion";
                d.safetyDirectives = "Pre-saturation sibilance protection; smooth Baxandall shelf; denormal immunity";
                d.validationHarness = "verify_171vocalcraft.cpp";
                d.recommendedOversampling = 1;
                d.estimatedLatencySamples = 0;
                break;
            }

            default: {
                d.primaryAgent = AGENT_DSP_CORE;
                d.reviewerAgent = AGENT_MATH_BUGFINDER;
                d.recommendedCPlusPlusClass = "dsp171::CoreAudioBlock";
                d.coreAlgorithmDescription = "C++20 SIMD real-time audio block processing";
                d.safetyDirectives = "Denormal flushing (FTZ/DAZ), bounds checks on all array accesses";
                d.validationHarness = "test_full_suite.cpp";
                break;
            }
        }

        return d;
    }

    // =========================================================================
    // Quick Helper Dispatches for In-Engine Calling
    // =========================================================================
    static DispatchDecision dispatchSaturation(HardwareTarget machine, uint32_t oversampling = 4, TargetPlatform platform = TargetPlatform::UniversalCrossPlatform) noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::SaturationAnalog;
        v.hardwareTarget = machine;
        v.oversampleFactor = oversampling;
        v.platform = platform;
        return dispatch(v);
    }

    static DispatchDecision dispatchCompression(CompressionTopology topology, LatencyTolerance latency = LatencyTolerance::ZeroLatencyLive_0ms) noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::CompressionDynamics;
        v.compressionTopology = topology;
        v.latencyTolerance = latency;
        return dispatch(v);
    }

    static DispatchDecision dispatchPitchTune(bool liveZeroLatency = true, bool preserveFormants = true) noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::PitchTrackingCorrection;
        v.latencyTolerance = liveZeroLatency ? LatencyTolerance::ZeroLatencyLive_0ms : LatencyTolerance::StandardMixing_Sub5ms;
        v.preserveFormants = preserveFormants;
        return dispatch(v);
    }

    static DispatchDecision dispatchMidiHarmony(bool /*mpeEnabled*/ = true) noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::MidiHarmonizationMPE;
        return dispatch(v);
    }

    static DispatchDecision dispatchMasteringSpatial(bool /*atmos714*/ = false, bool truePeak4x = true) noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::SpatialAudioMastering;
        v.requireITUBS1770Compliance = true;
        v.oversampleFactor = truePeak4x ? 4 : 8;
        return dispatch(v);
    }

    static DispatchDecision dispatchAnalyticalMath(MathModelPrecision precision) noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::AnalyticalMathPhysics;
        v.mathPrecision = precision;
        return dispatch(v);
    }

    static DispatchDecision dispatchSilkscreen() noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::SilkscreenTypography;
        return dispatch(v);
    }

    static DispatchDecision dispatchBoutiqueBranding() noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::PluginBoutiqueBranding;
        return dispatch(v);
    }

    static DispatchDecision dispatchGuiReverseEngineering() noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::GuiReverseEngineering;
        return dispatch(v);
    }

    static DispatchDecision dispatchAssetAtlas() noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::AssetAtlasOptimization;
        return dispatch(v);
    }

    static DispatchDecision dispatchSpatialReverb() noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::SpatialReverbPhysical;
        return dispatch(v);
    }

    static DispatchDecision dispatchDynamicDucking() noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::DynamicDuckingSidechain;
        return dispatch(v);
    }

    static DispatchDecision dispatchVintageColor() noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::VintageConverterColor;
        return dispatch(v);
    }

    static DispatchDecision dispatchMonoMaker() noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::MidSideMonoMaker;
        return dispatch(v);
    }

    static DispatchDecision dispatchTransientShaping() noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::TransientMultiBandShaping;
        return dispatch(v);
    }

    static DispatchDecision dispatchSubHarmonics() noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::SubHarmonicSynthesis;
        return dispatch(v);
    }

    static DispatchDecision dispatchClipperDigital(uint32_t oversampling = 4) noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::ClipperDigitalHard;
        v.oversampleFactor = oversampling;
        return dispatch(v);
    }

    static DispatchDecision dispatchClipperAnalog(HardwareTarget target = HardwareTarget::Lavry_Gold_ADC122, uint32_t oversampling = 4) noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::ClipperAnalogConverter;
        v.hardwareTarget = target;
        v.oversampleFactor = oversampling;
        return dispatch(v);
    }

    static DispatchDecision dispatchTransientDetail() noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::TransientDetailPreservation;
        return dispatch(v);
    }

    static DispatchDecision dispatchTruePeakISP(bool lookahead64 = true) noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::TruePeakISPGovernor;
        v.requireITUBS1770Compliance = true;
        v.latencyTolerance = lookahead64 ? LatencyTolerance::LowLatencyTracking_Sub1ms : LatencyTolerance::ZeroLatencyLive_0ms;
        return dispatch(v);
    }

    static DispatchDecision dispatchClipperReverseEngineering() noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::ClipperReverseEngineering;
        return dispatch(v);
    }

    static DispatchDecision dispatchCRTDeltaVisualizer() noexcept {
        DevelopmentVariables v;
        v.task = DomainTask::CRTDeltaVisualizer;
        return dispatch(v);
    }

    // Print ticket directly to stdout / host debugger
    static void logDispatchDecision(const DispatchDecision& decision) noexcept {
        std::printf("\n======================================================\n");
        std::printf("[DSP 171 HIRE MANAGER] AGENT ASSIGNMENT:\n");
        std::printf("  Primary Agent:   %s (%s)\n", decision.primaryAgent.agentId.data(), decision.primaryAgent.agentTitle.data());
        std::printf("  Reviewer:        %s\n", decision.reviewerAgent.agentId.data());
        std::printf("  QA Auditor:      %s\n", decision.qaAuditorAgent.agentId.data());
        std::printf("  Recommended C++: %s\n", decision.recommendedCPlusPlusClass.data());
        std::printf("  Topology:        %s\n", decision.coreAlgorithmDescription.data());
        std::printf("  Safety:          %s\n", decision.safetyDirectives.data());
        std::printf("  Harness:         %s\n", decision.validationHarness.data());
        std::printf("======================================================\n\n");
    }
};

} // namespace dsp171
