#pragma once

#include <cmath>
#include <algorithm>
#include <cstdint>
#include <array>
#include "Common.h"
#include "DCBlocker.h"
#include "FastMath.h"
#include "ZDFSVF.h"
#include "ZDFTiltFilter.h"

namespace dsp171 {

// =============================================================================
// Module: PerfectPreHardwareEngine171
// Orchestrated by: Lead Analog Circuit & DSP Physicist (171 Studio Innovatio)
//
// Complete Physical Channel Strip modeled from 171 Studio Hardware:
// 1. 4-Character Preamp:
//    - 01: British Vintage (Neve 1073 Class-A BJT cascade + LO1166 Iron, B_0 > 0)
//    - 02: American Tube (12AX7 Class-A Triode with Miller HF softening & B+ Sag)
//    - 03: Vintage Germanium (Point-contact 1N34A / AC128 early soft knee)
//    - 04: Clean Studio (Transparent wire-with-gain)
// 2. Independent Asymmetric Diode Clipper:
//    - Germanium & Schottky diode clipping with Ruby Jewel lamp telemetry
// 3. Concentric Neve 1073 EQ:
//    - 5-Frequency HPF (Off, 50, 80, 160, 300 Hz)
//    - Concentric Low Shelf (35, 60, 110, 220 Hz +/-16 dB)
//    - Concentric Mid Peak (360, 700, 1600, 3200, 4800, 7200 Hz +/-18 dB)
//    - High Shelf fixed at 12 kHz (+/-16 dB)
// 4. SPL Differential Phase De-Esser:
//    - 180-degree differential phase cancellation (Male 6 kHz / Female 7 kHz)
// 5. Safe Ceiling Brickwall Limiter (-0.09 dBFS)
// =============================================================================

enum class PreampCharacter : uint8_t {
    BritishVintage = 0,
    AmericanTube   = 1,
    VintageGermanium = 2,
    CleanStudio    = 3
};

class PerfectPreHardwareEngine171 {
public:
    PerfectPreHardwareEngine171() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);

        dcBlocker.prepare(sampleRate, 10.0f);
        tiltFilter.prepare(sampleRate);

        // Filters
        hpfFilter.setParameters(50.0f, 0.707f, sr);
        lowShelfFilter.setParameters(110.0f, 0.707f, sr);
        midPeakFilter.setParameters(1600.0f, 1.414f, sr);
        highShelfFilter.setParameters(12000.0f, 0.707f, sr);
        deessBandpass.setParameters(6500.0f, 2.5f, sr);

        // Dynamic Cathode Bias, Grid Sag & B+ Sag (12AX7 Class-A American Tube)
        alphaTubeCathodeAtt = 1.0f - std::exp(-1.0f / (0.010f * sr));
        alphaTubeCathodeRel = 1.0f - std::exp(-1.0f / (0.045f * sr));
        alphaTubeGridAtt = 1.0f - std::exp(-1.0f / (0.0015f * sr));
        alphaTubeGridRel = 1.0f - std::exp(-1.0f / (0.085f * sr));
        alphaTubeBPlusAtt = 1.0f - std::exp(-1.0f / (0.035f * sr));
        alphaTubeBPlusRel = 1.0f - std::exp(-1.0f / (0.220f * sr));

        // Air Sheen pole at 16 kHz for 32 kHz shelf
        constexpr float fcAir = 16000.0f;
        airAlpha = std::clamp(2.0f * PI * fcAir / sr, 0.01f, 0.95f);

        reset();
    }

    void reset() noexcept {
        dcBlocker.reset();
        tiltFilter.reset();
        hpfFilter.reset();
        lowShelfFilter.reset();
        midPeakFilter.reset();
        highShelfFilter.reset();
        deessBandpass.reset();
        airState = 0.0f;
        jewelLampEnergy = 0.0f;
        deesserReductionDb = 0.0f;
        tubeCathodeBias = 0.0f;
        tubeGridSag = 0.0f;
        tubeMillerState = 0.0f;
        tubeBPlusSag = 0.0f;
    }

    // --- Preamp Parameters ---
    void setPreamp(PreampCharacter character, float driveDb) noexcept {
        currentCharacter = character;
        driveGainLin = std::pow(10.0f, std::clamp(driveDb, 0.0f, 36.0f) / 20.0f);
    }

    // --- Diode Clipper Parameters ---
    void setDiodeStage(bool enabled, float driveDb = 0.0f) noexcept {
        diodeStageActive = enabled;
        diodeDriveLin = std::pow(10.0f, std::clamp(driveDb, 0.0f, 24.0f) / 20.0f);
    }

    // --- EQ Neve 1073 Parameters ---
    void setHPF(float freqHz) noexcept {
        hpfFreqHz = freqHz;
        if (hpfFreqHz > 20.0f) {
            hpfFilter.setParameters(hpfFreqHz, 0.707f, sr);
        }
    }

    void setLowShelf(float freqHz, float gainDb) noexcept {
        lowShelfFreqHz = std::clamp(freqHz, 35.0f, 220.0f);
        lowShelfGainLin = std::pow(10.0f, std::clamp(gainDb, -16.0f, 16.0f) / 20.0f);
        lowShelfFilter.setParameters(lowShelfFreqHz, 0.707f, sr);
    }

    void setMidPeak(float freqHz, float gainDb) noexcept {
        midPeakFreqHz = std::clamp(freqHz, 360.0f, 7200.0f);
        midPeakGainLin = std::pow(10.0f, std::clamp(gainDb, -18.0f, 18.0f) / 20.0f);
        midPeakFilter.setParameters(midPeakFreqHz, 1.414f, sr);
    }

    void setHighShelf(float gainDb) noexcept {
        highShelfGainLin = std::pow(10.0f, std::clamp(gainDb, -16.0f, 16.0f) / 20.0f);
    }

    void setAirSheen(float airDb) noexcept {
        airGainLin = std::pow(10.0f, std::clamp(airDb, 0.0f, 12.0f) / 20.0f);
    }

    // --- De-Esser Parameters ---
    void setDeEsser(bool enabled, float thresholdDb = -18.0f, bool femaleVoice = false) noexcept {
        deesserActive = enabled;
        deesserThreshLin = std::pow(10.0f, std::clamp(thresholdDb, -40.0f, 0.0f) / 20.0f);
        const float deessFreq = femaleVoice ? 7000.0f : 6000.0f;
        deessBandpass.setParameters(deessFreq, 2.5f, sr);
    }

    // --- Master Output & Safe Ceiling ---
    void setOutputGainDb(float gainDb) noexcept {
        outputGainLin = std::pow(10.0f, std::clamp(gainDb, -24.0f, 12.0f) / 20.0f);
    }

    [[nodiscard]] float getJewelLampEnergy() const noexcept { return jewelLampEnergy; }
    [[nodiscard]] float getDeEsserReductionDb() const noexcept { return deesserReductionDb; }
    [[nodiscard]] float getTubeBPlusSag() const noexcept { return tubeBPlusSag; }

    inline float processSample(float inSample) noexcept {
        if (!std::isfinite(inSample)) return 0.0f;

        // -----------------------------------------------------------------
        // 1. Stage 1: Preamp Waveshaping (4 Hardware Characters)
        // -----------------------------------------------------------------
        const float x = inSample * driveGainLin;
        float preampOut = 0.0f;

        switch (currentCharacter) {
            case PreampCharacter::BritishVintage: {
                // Neve 1073: Single-ended Class-A BJT cascade + Marinair LO1166 DC core pre-magnetization (B_0 > 0)
                constexpr float b0 = 0.22f;
                const float bTot = b0 + x;
                const float satTot = bTot / std::sqrt(1.0f + 0.20f * (bTot * bTot));
                const float satB0 = b0 / std::sqrt(1.0f + 0.20f * (b0 * b0));
                const float induced = satTot - satB0;
                preampOut = induced + 0.05f * (induced * std::abs(induced)) / (1.0f + induced * induced);
                break;
            }
            case PreampCharacter::AmericanTube: {
                // 12AX7 Class-A Triode Child-Langmuir law with dynamic cathode bias shift & grid sag
                const float vGkNominal = x - tubeCathodeBias - tubeGridSag;
                const float cathodeSurge = (vGkNominal > 0.0f) ? (0.28f * vGkNominal + 0.10f * (vGkNominal * vGkNominal)) : 0.0f;
                if (cathodeSurge > tubeCathodeBias) {
                    tubeCathodeBias += alphaTubeCathodeAtt * (cathodeSurge - tubeCathodeBias);
                } else {
                    tubeCathodeBias += alphaTubeCathodeRel * (cathodeSurge - tubeCathodeBias);
                }

                if (vGkNominal > 0.65f) {
                    const float iGrid = 0.35f * (vGkNominal - 0.65f);
                    tubeGridSag += alphaTubeGridAtt * (iGrid - tubeGridSag);
                } else {
                    tubeGridSag += alphaTubeGridRel * (0.0f - tubeGridSag);
                }

                FastMath::flushDenormals(tubeCathodeBias);
                FastMath::flushDenormals(tubeGridSag);

                const float vEff = x - tubeCathodeBias - tubeGridSag;

                // Dynamic B+ Power Rail Sag:
                const float iPlate = (vEff > 0.0f) ? (0.26f * vEff + 0.10f * (vEff * vEff)) : (0.03f * std::abs(vEff));
                const float targetSag = std::clamp(iPlate * 0.22f, 0.0f, 0.35f);
                if (targetSag > tubeBPlusSag) {
                    tubeBPlusSag += alphaTubeBPlusAtt * (targetSag - tubeBPlusSag);
                } else {
                    tubeBPlusSag += alphaTubeBPlusRel * (0.0f - tubeBPlusSag);
                }
                FastMath::flushDenormals(tubeBPlusSag);

                const float vBPlusEff = 1.0f - 0.25f * tubeBPlusSag;

                if (vEff >= 0.0f) {
                    preampOut = vEff / (1.0f + 0.22f * vEff + 0.03f * (vEff * vEff));
                } else {
                    preampOut = vEff / (1.0f + 0.10f * (-vEff));
                }

                // Headroom modulated by B+ power rail dynamic sag
                preampOut *= vBPlusEff;

                // Dynamic Miller Capacitance HF Roll-off (transconductance-dependent HF softening)
                const float fcMiller = 30000.0f / (1.0f + 0.85f * std::max(0.0f, vEff));
                const float alphaMiller = std::clamp(2.0f * 3.14159265f * fcMiller / sr, 0.05f, 0.95f);
                tubeMillerState += alphaMiller * (preampOut - tubeMillerState);
                FastMath::flushDenormals(tubeMillerState);
                preampOut = tubeMillerState;
                break;
            }
            case PreampCharacter::VintageGermanium: {
                // 1N34A Point-contact Germanium with C-inf smooth origin
                const float xCurved = x + 0.16f * (x * x) / (1.0f + std::abs(x));
                preampOut = xCurved / std::sqrt(1.0f + 0.70f * xCurved * xCurved);
                break;
            }
            case PreampCharacter::CleanStudio: {
                // Transparent high-headroom wire-with-gain
                preampOut = std::clamp(x, -1.8f, 1.8f);
                break;
            }
        }

        // -----------------------------------------------------------------
        // 2. Stage 2: Independent Asymmetric Diode Clipper & Jewel Lamp
        // -----------------------------------------------------------------
        float diodeOut = preampOut;
        if (diodeStageActive) {
            const float xDiode = preampOut * diodeDriveLin;
            // Asymmetric Schottky BAT41 + Germanio 1N34A conduction
            const float posClip = (xDiode >= 0.0f) ? std::tanh(xDiode * 1.25f) : -std::tanh(-xDiode * 0.95f) * 0.90f;
            diodeOut = posClip;

            // Optical Ruby Jewel Lamp Telemetry (energy integration)
            const float excess = std::max(0.0f, std::abs(xDiode) - 0.75f);
            jewelLampEnergy += 0.02f * (excess - jewelLampEnergy);
        } else {
            jewelLampEnergy *= 0.98f;
        }

        // -----------------------------------------------------------------
        // 3. Stage 3: Concentric Neve 1073 Equalizer
        // -----------------------------------------------------------------
        float eqSignal = diodeOut;

        // A. High-Pass Filter (HPF)
        if (hpfFreqHz > 20.0f) {
            eqSignal = hpfFilter.process(eqSignal).hp;
        }

        // B. Low Shelf
        if (std::abs(lowShelfGainLin - 1.0f) > 0.01f) {
            const float lp = lowShelfFilter.process(eqSignal).lp;
            eqSignal = (eqSignal - lp) + lp * lowShelfGainLin;
        }

        // C. Mid Peak (Inductor Presence)
        if (std::abs(midPeakGainLin - 1.0f) > 0.01f) {
            const float bp = midPeakFilter.process(eqSignal).bp;
            eqSignal = eqSignal + bp * (midPeakGainLin - 1.0f);
        }

        // D. High Shelf (12 kHz)
        if (std::abs(highShelfGainLin - 1.0f) > 0.01f) {
            const float hp = highShelfFilter.process(eqSignal).hp;
            eqSignal = (eqSignal - hp) + hp * highShelfGainLin;
        }

        // E. Air Sheen (32 kHz)
        if (airGainLin > 1.01f) {
            airState += airAlpha * (eqSignal - airState);
            FastMath::flushDenormals(airState);
            eqSignal = airState + (eqSignal - airState) * airGainLin;
        }

        // -----------------------------------------------------------------
        // 4. Stage 4: SPL Differential Phase De-Esser
        // -----------------------------------------------------------------
        float deessedSignal = eqSignal;
        if (deesserActive) {
            // Extract sibilance band
            const float sibilance = deessBandpass.process(eqSignal).bp;
            const float sibEnergy = std::abs(sibilance);

            if (sibEnergy > deesserThreshLin) {
                // Excess sibilant energy injected in 180-deg opposite phase
                const float excessRatio = (sibEnergy - deesserThreshLin) / (sibEnergy + 1.0e-5f);
                deessedSignal = eqSignal - sibilance * std::min(1.0f, excessRatio * 1.5f);
                deesserReductionDb = -20.0f * std::log10(1.0f + excessRatio);
            } else {
                deesserReductionDb = 0.0f;
            }
        } else {
            deesserReductionDb = 0.0f;
        }

        // -----------------------------------------------------------------
        // 5. Stage 5: Output Gain & Brickwall Safe Ceiling (-0.09 dBFS)
        // -----------------------------------------------------------------
        const float trimmed = deessedSignal * outputGainLin;
        const float acClean = dcBlocker.processSample(trimmed);

        // Safe Ceiling: strict limit at -0.09 dBFS (linear ~0.9897)
        constexpr float kCeiling = 0.9897f;
        float safeOut = acClean;
        if (std::abs(acClean) > kCeiling) {
            safeOut = (acClean > 0.0f) ? (kCeiling + 0.01f * std::tanh(acClean - kCeiling))
                                       : (-kCeiling - 0.01f * std::tanh(-acClean - kCeiling));
        }

        return safeOut;
    }

private:
    float sr = 44100.0f;

    PreampCharacter currentCharacter = PreampCharacter::BritishVintage;
    float driveGainLin = 1.0f;

    bool diodeStageActive = false;
    float diodeDriveLin = 1.0f;
    float jewelLampEnergy = 0.0f;

    float hpfFreqHz = 0.0f;
    float lowShelfFreqHz = 110.0f;
    float lowShelfGainLin = 1.0f;
    float midPeakFreqHz = 1600.0f;
    float midPeakGainLin = 1.0f;
    float highShelfGainLin = 1.0f;
    float airGainLin = 1.0f;
    float airAlpha = 0.5f;
    float airState = 0.0f;

    bool deesserActive = false;
    float deesserThreshLin = 0.125f;
    float deesserReductionDb = 0.0f;

    float outputGainLin = 1.0f;

    // American Tube Dynamic Cathode Bias, Grid Sag & B+ Sag
    float tubeCathodeBias = 0.0f;
    float tubeGridSag = 0.0f;
    float tubeMillerState = 0.0f;
    float tubeBPlusSag = 0.0f;
    float alphaTubeCathodeAtt = 0.002f;
    float alphaTubeCathodeRel = 0.0004f;
    float alphaTubeGridAtt = 0.015f;
    float alphaTubeGridRel = 0.0003f;
    float alphaTubeBPlusAtt = 0.002f;
    float alphaTubeBPlusRel = 0.0003f;

    DCBlocker dcBlocker;
    ZDFTiltFilter tiltFilter;
    ZDFSVF64 hpfFilter;
    ZDFSVF64 lowShelfFilter;
    ZDFSVF64 midPeakFilter;
    ZDFSVF64 highShelfFilter;
    ZDFSVF64 deessBandpass;
};

} // namespace dsp171
