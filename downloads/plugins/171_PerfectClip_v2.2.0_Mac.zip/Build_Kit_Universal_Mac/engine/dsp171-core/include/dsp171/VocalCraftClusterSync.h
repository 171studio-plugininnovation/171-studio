#pragma once

#include <cmath>
#include <algorithm>
#include <atomic>
#include <array>
#include <cstdint>
#include <cassert>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include <dsp171/ZDFSVF.h>

namespace dsp171 {

// =============================================================================
// 171 Studio Innovatio - Multi-Track Vocal Cluster Synchronizer
// 171 VocalCraft 3.0 "The Sovereign Vocal Engine" - Phase 3
//
// Key Mathematical & Architectural Foundations:
// 1. Lock-Free / Wait-Free Inter-Track Shared Memory Bus (SWMR Architecture):
//    - Real-time in-process communication between up to 8 cluster channels.
//    - Cache-line aligned (alignas(64)) Single-Writer Multi-Reader (SWMR)
//      atomic double-buffering.
//    - Zero mutexes, zero spinlocks, zero heap allocations, zero OS kernel traps.
//    - Wait-free O(1) reads guarantee that Satellite tracks are never stalled by
//      Lead thread scheduling or asymmetric DAW buffer processing.
//
// 2. Cytomic Zero-Delay Feedback (ZDF) SVF Dynamic Peaking Pocketing Filter:
//    - Discretization via trapezoidal integration with frequency pre-warping:
//      g = tan(pi * fc / fs),  k = 1 / Q,  h = 1 / (1 + g*(g + k))
//    - Linear state updates with instantaneous feedback:
//      v1[n] = h * (g * (v0[n] - s2[n]) + s1[n])
//      v2[n] = s2[n] + g * v1[n]
//      s1[n+1] = 2*v1[n] - s1[n],  s2[n+1] = 2*v2[n] - s2[n]
//    - Peaking output: y[n] = v0[n] + (A[n] - 1) * k * v1[n]
//      where A[n] = 10^(G_dB[n] / 20) dynamically modulates the presence cut
//      [0.0 dB, -8.0 dB] without altering filter stability or unit-circle pole locations.
//    - Center frequency fc dynamically tracks Lead formant barycenter F2/F3
//      (1.2 kHz - 3.2 kHz, nominal 2.2 kHz) with Q = 1.0 - 1.4.
//    - Asymmetric anti-pumping ballistics: fast attack (tau_atk = 4 ms) to instantly
//      clear space upon Lead phoneme onset; smooth release (tau_rel = 40 - 120 ms,
//      nominal 80 ms) for resting transparency.
//
// 3. Auto-Tighten Anti-Flam Transient Shaper:
//    - High-frequency (> 4 kHz) consonant transient detection on Satellite tracks.
//    - Coincidence comparison with Lead vocal onset within a 15 ms perceptual flam window:
//      Delta_t = |P_sat - P_lead,onset| / fs
//    - If Delta_t <= 15 ms, attenuates Satellite transient attack proportionally to
//      (1.0 - Delta_t / 15 ms) * clusterTighten (up to -12 dB HF damping).
//    - Leaves harmonic vowel body (< 4 kHz) 100% untouched, eliminating audible flamming
//      while preserving acoustic double warmth and width.
// =============================================================================

// =============================================================================
// Telemetry & Cluster Enums
// =============================================================================
enum class ClusterRole : uint32_t {
    Disabled  = 0,
    Lead      = 1,
    Satellite = 2
};

enum class VocalPhonemeClass : uint32_t {
    Silence   = 0,
    Vowel     = 1,
    Consonant = 2,
    Sibilant  = 3
};

// =============================================================================
// Shared Lock-Free Broadcast Payload (Exactly 64 Bytes = 1 L1 Cache Line)
// =============================================================================
struct alignas(64) VocalClusterLeadTelemetry {
    uint64_t sampleTimestamp     = 0;       // DAW timeline sample index (8 bytes, offset 0)
    uint64_t lastOnsetSample     = 0;       // DAW sample timestamp of last Lead onset (8 bytes, offset 8)
    double   sampleRate          = 48000.0; // Sample rate in Hz (8 bytes, offset 16)
    float    rmsDb               = -90.0f;  // Instantaneous RMS (-90 to 0 dBFS) (4 bytes, offset 24)
    float    formantF1Hz         = 500.0f;  // Formant F1 centroid (200-800 Hz) (4 bytes, offset 28)
    float    formantF2Hz         = 1800.0f; // Formant F2 centroid (800-2400 Hz) (4 bytes, offset 32)
    float    formantF3Hz         = 2800.0f; // Formant F3 centroid (2400-3800 Hz) (4 bytes, offset 36)
    float    consonantActivity   = 0.0f;    // Consonant transient intensity [0.0, 1.0] (4 bytes, offset 40)
    float    sibilanceEnergyDb   = -90.0f;  // Sibilance band energy (5.5 - 9.0 kHz) (4 bytes, offset 44)
    uint32_t activePhoneme       = 0;       // VocalPhonemeClass (4 bytes, offset 48)
    uint32_t clusterGroupId      = 1;       // Vocal Cluster Group ID (1..4) (4 bytes, offset 52)
    uint32_t activeLeadInstanceId= 0;       // Unique ID of publishing Lead instance (4 bytes, offset 56)
    uint32_t reserved            = 0;       // Exact padding to 64 bytes (4 bytes, offset 60)
};

static_assert(sizeof(VocalClusterLeadTelemetry) == 64, 
    "VocalClusterLeadTelemetry must be exactly 64 bytes (1 L1 cache line) to prevent false sharing and torn reads!");

// =============================================================================
// Wait-Free Single-Writer Multi-Reader (SWMR) Atomic Double Buffer Channel
// =============================================================================
struct alignas(64) ClusterChannel {
    std::atomic<uint32_t> writeIndex{ 0 };
    std::atomic<uint32_t> reserved{ 0 };
    std::atomic<uint64_t> writeSequence{ 0 };
    uint8_t pad0[48]{}; // Isolate atomic indices from data payload across cache lines

    alignas(64) std::array<VocalClusterLeadTelemetry, 2> buffers{};

    void writePayload(const VocalClusterLeadTelemetry& payload) noexcept {
        const uint32_t current = writeIndex.load(std::memory_order_relaxed);
        const uint32_t next = 1 - current;
        buffers[next] = payload;
        // Release ordering ensures payload data is visible to all cores before writeIndex flips
        writeIndex.store(next, std::memory_order_release);
        writeSequence.fetch_add(1, std::memory_order_release);
    }

    VocalClusterLeadTelemetry readPayload() const noexcept {
        // Acquire ordering ensures we read the buffer that was completely committed
        const uint32_t idx = writeIndex.load(std::memory_order_acquire);
        return buffers[idx];
    }
};

// =============================================================================
// Global Static Vocal Cluster Registry (In-Process Inter-Track Bus)
// =============================================================================
class VocalClusterRegistry {
public:
    static constexpr size_t kMaxChannels = 8;

    static ClusterChannel& getChannel(int channelId) noexcept {
        const int idx = std::clamp(channelId - 1, 0, static_cast<int>(kMaxChannels - 1));
        return sChannels[idx];
    }

    static void resetAll() noexcept {
        for (auto& ch : sChannels) {
            ch.writeIndex.store(0, std::memory_order_relaxed);
            ch.writeSequence.store(0, std::memory_order_relaxed);
            ch.buffers[0] = VocalClusterLeadTelemetry{};
            ch.buffers[1] = VocalClusterLeadTelemetry{};
        }
    }

private:
    static inline std::array<ClusterChannel, kMaxChannels> sChannels{};
};

// =============================================================================
// Cytomic Zero-Delay Feedback (ZDF) Stereo Peaking Bell Filter
// =============================================================================
class ZDFPeakingBellFilter {
public:
    void prepare(double sampleRate) noexcept {
        sr = (sampleRate > 8000.0) ? sampleRate : 48000.0;
        invSr = 1.0 / sr;
        updateTuning(currentFc, currentQ);
        reset();
    }

    void reset() noexcept {
        s1L = 0.0f; s2L = 0.0f;
        s1R = 0.0f; s2R = 0.0f;
        lastTunedFc = -1.0f;
        lastTunedQ = -1.0f;
    }

    void updateTuning(float fc, float Q) noexcept {
        if (std::abs(fc - lastTunedFc) < 0.2f && std::abs(Q - lastTunedQ) < 0.005f) {
            return;
        }
        lastTunedFc = fc;
        lastTunedQ = Q;
        currentFc = std::clamp(fc, 20.0f, static_cast<float>(sr * 0.45));
        currentQ = std::max(0.1f, Q);
        const float w0 = 3.14159265358979323846f * currentFc * static_cast<float>(invSr);
        g = std::tan(w0);
        k = 1.0f / currentQ;
        h = 1.0f / (1.0f + g * (g + k));
    }

    // Process mono sample with dynamic linear amplitude gain A = 10^(gainDb / 20)
    inline float processSample(float in, float gainLinear, float& s1, float& s2) noexcept {
        const float v0 = in;
        const float v1 = h * (g * (v0 - s2) + s1);
        const float v2 = s2 + g * v1;

        s1 = 2.0f * v1 - s1;
        s2 = 2.0f * v2 - s2;

        // Branchless anti-denormal hardware flushing
        s1 += 1.0e-30f; s1 -= 1.0e-30f;
        s2 += 1.0e-30f; s2 -= 1.0e-30f;

        // Peaking output: y = v0 + (gainLinear - 1.0) * k * v1
        return v0 + (gainLinear - 1.0f) * k * v1;
    }

    inline void processStereo(float& left, float& right, float gainLinear) noexcept {
        left = processSample(left, gainLinear, s1L, s2L);
        right = processSample(right, gainLinear, s1R, s2R);
    }

    float getCenterFrequency() const noexcept { return currentFc; }
    float getQ() const noexcept { return currentQ; }

private:
    double sr = 48000.0;
    double invSr = 1.0 / 48000.0;
    float currentFc = 2200.0f;
    float currentQ = 1.4f;
    float lastTunedFc = -1.0f;
    float lastTunedQ = -1.0f;
    float g = 0.0f;
    float k = 1.0f;
    float h = 0.0f;
    float s1L = 0.0f, s2L = 0.0f;
    float s1R = 0.0f, s2R = 0.0f;
};

// High-speed single-precision 2nd-order ZDF SVF for phoneme & transient detection
struct ZDFSVF32Fast {
    float g = 0.0f;
    float R = 0.7071f;
    float h = 0.0f;
    float s1 = 0.0f;
    float s2 = 0.0f;

    void setParameters(float fc, float Q, float sampleRate) noexcept {
        const float clampedFc = std::clamp(fc, 10.0f, sampleRate * 0.49f);
        g = std::tan(3.14159265f * clampedFc / sampleRate);
        const float safeQ = std::max(0.1f, Q);
        R = 1.0f / (2.0f * safeQ);
        h = 1.0f / (1.0f + 2.0f * R * g + g * g);
    }

    void reset() noexcept {
        s1 = 0.0f;
        s2 = 0.0f;
    }

    inline float processHP(float in) noexcept {
        const float hp = (in - (2.0f * R + g) * s1 - s2) * h;
        const float v1 = g * hp;
        const float bp = v1 + s1;
        s1 = v1 + bp;
        const float v2 = g * bp;
        s2 = v2 + (v2 + s2);
        return hp;
    }
};

// =============================================================================
// Auto-Tighten Anti-Flam Transient Shaper
// Suppresses secondary consonant flam attacks within a 15 ms tolerance window
// =============================================================================
class AutoTightenAntiFlamShaper {
public:
    void prepare(double sampleRate) noexcept {
        sr = (sampleRate > 8000.0) ? sampleRate : 48000.0;
        invSr = 1.0 / sr;

        // 2nd-order ZDF SVF High-pass filter tuned at 4.5 kHz for robust consonant transient extraction
        hpfDetect.setParameters(4500.0f, 0.7071f, static_cast<float>(sr));

        // Monotonic Cytomic ZDF High-Shelf filter with fc = 3500 Hz
        const float fc = 3500.0f;
        const float w0 = 3.14159265358979323846f * fc * static_cast<float>(invSr);
        gc = std::tan(w0);
        inv1pGc = 1.0f / (1.0f + gc);

        // Attack 1.5 ms, Release 25 ms for transient envelope suppression
        envAttackCoeff  = static_cast<float>(1.0 - std::exp(-1.0 / (0.0015 * sr)));
        envReleaseCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.0250 * sr)));

        // Fast energy smoothing (1.0 ms) and slow reference (15.0 ms)
        fastSmoothCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.0010 * sr)));
        slowSmoothCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.0150 * sr)));

        reset();
    }

    void reset() noexcept {
        hpfDetect.reset();
        sL = 0.0f;
        sR = 0.0f;
        fastEnergy = 0.0f;
        slowEnergy = 0.0f;
        prevHfMag = 0.0f;
        suppressionEnv = 0.0f;
        holdCounter = 0;
        lastOnsetSample = 0;
    }

    // Process stereo sample pair: attenuates colliding HF transient if within 15 ms of Lead onset
    inline void processStereo(float& left, float& right, uint64_t samplePosition,
                             uint64_t leadOnsetSample, float leadConsonantActivity,
                             float tightenAmount) noexcept {
        // ZDF 1-pole high-pass extraction: v = (x - s) / (1 + gc)
        const float vL = (left - sL) * inv1pGc;
        const float vR = (right - sR) * inv1pGc;

        // State updates
        sL += 2.0f * gc * vL;
        sR += 2.0f * gc * vR;

        // Branchless anti-denormal hardware flushing
        sL += 1.0e-30f; sL -= 1.0e-30f;
        sR += 1.0e-30f; sR -= 1.0e-30f;

        if (tightenAmount <= 0.001f) return;

        // Robust 2nd-order 4.5 kHz detection isolates percussive consonants and rejects vowel fundamental
        const float monoIn = 0.5f * (left + right);
        const float hpSample = hpfDetect.processHP(monoIn);
        const float hfMag = std::abs(hpSample);

        // Instantaneous attack flux for zero-latency transient capture
        const float rawDelta = std::max(0.0f, hfMag - prevHfMag);
        prevHfMag = hfMag;

        // 2. High-frequency energy flux detector
        fastEnergy += fastSmoothCoeff * (hfMag - fastEnergy);
        slowEnergy += slowSmoothCoeff * (hfMag - slowEnergy);

        const float energyFlux = std::max(0.0f, fastEnergy - slowEnergy);
        const bool isOnset = (rawDelta > 0.03f) || ((energyFlux > 0.015f) && (fastEnergy > 1.5f * slowEnergy + 0.005f));

        if (isOnset && holdCounter == 0) {
            lastOnsetSample = samplePosition;
            // Coincidence check with Lead onset
            if (leadOnsetSample > 0 && leadConsonantActivity > 0.05f) {
                const int64_t deltaSamples = (samplePosition >= leadOnsetSample)
                    ? static_cast<int64_t>(samplePosition - leadOnsetSample)
                    : static_cast<int64_t>(leadOnsetSample - samplePosition);
                
                const double deltaMs = static_cast<double>(deltaSamples) * invSr * 1000.0;

                // Flamming window: 1.0 ms <= deltaMs <= 15.0 ms
                if (deltaMs >= 1.0 && deltaMs <= 15.0) {
                    const float proximity = 1.0f - static_cast<float>(deltaMs / 15.0);
                    // Proximity weighting: strong suppression across flam window, tapering smoothly near 15 ms
                    const float flamSuppressionTarget = std::clamp(proximity * 1.4f, 0.0f, 1.0f) * std::clamp(tightenAmount, 0.0f, 1.0f);
                    suppressionEnv = std::max(suppressionEnv, flamSuppressionTarget);
                    holdCounter = static_cast<int>(std::round(0.012 * sr)); // 12 ms hold
                }
            }
        }

        if (holdCounter > 0) {
            --holdCounter;
        } else {
            suppressionEnv += envReleaseCoeff * (0.0f - suppressionEnv);
        }

        // Apply monotonic ZDF High-Shelf transient attenuation:
        // y = x + (g_hf - 1) * v, where g_hf down to 0.25 (-12 dB) on HF consonant
        if (suppressionEnv > 0.001f) {
            const float hfGain = 1.0f - suppressionEnv * 0.75f;
            left  += (hfGain - 1.0f) * vL;
            right += (hfGain - 1.0f) * vR;
        }
    }

    float getSuppressionDb() const noexcept {
        if (suppressionEnv <= 0.001f) return 0.0f;
        const float hfGain = 1.0f - suppressionEnv * 0.75f;
        return gainToDb(hfGain);
    }

private:
    double sr = 48000.0;
    double invSr = 1.0 / 48000.0;
    ZDFSVF32Fast hpfDetect{};
    float gc = 0.0f;
    float inv1pGc = 1.0f;
    float sL = 0.0f;
    float sR = 0.0f;
    float fastSmoothCoeff = 0.0f;
    float slowSmoothCoeff = 0.0f;
    float envAttackCoeff = 0.0f;
    float envReleaseCoeff = 0.0f;
    float fastEnergy = 0.0f;
    float slowEnergy = 0.0f;
    float prevHfMag = 0.0f;
    float suppressionEnv = 0.0f;
    int   holdCounter = 0;
    uint64_t lastOnsetSample = 0;
};

// =============================================================================
// Lead Vocal Feature Analyzer (Extracts Telemetry for Broadcasting)
// =============================================================================
class LeadVocalAnalyzer {
public:
    void prepare(double sampleRate) noexcept {
        sr = (sampleRate > 8000.0) ? sampleRate : 48000.0;
        invSr = 1.0 / sr;

        // Bandpass 1.8 kHz (Q=0.8) for presence formant F2 estimation
        bpPresence.setParameters(1800.0f, 0.8f, static_cast<float>(sr));
        // Bandpass 2.8 kHz (Q=1.0) for singer's formant F3 estimation
        bpRing.setParameters(2800.0f, 1.0f, static_cast<float>(sr));
        // Highpass 4.5 kHz for consonant and sibilance tracking
        hpfConsonant.setParameters(4500.0f, 0.7071f, static_cast<float>(sr));

        fastCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.0020 * sr))); // 2 ms
        slowCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.0200 * sr))); // 20 ms

        reset();
    }

    void reset() noexcept {
        bpPresence.reset();
        bpRing.reset();
        hpfConsonant.reset();
        presenceEnergy = 0.0f;
        ringEnergy = 0.0f;
        consonantEnergy = 0.0f;
        hfSlowEnergy = 0.0f;
        prevAbsHf = 0.0f;
        lastOnsetSample = 0;
    }

    VocalClusterLeadTelemetry analyzeBlock(const float* left, const float* right, int numSamples,
                                          uint64_t samplePosition, uint32_t instanceId,
                                          uint32_t clusterGroupId) noexcept {
        VocalClusterLeadTelemetry telem;
        telem.sampleTimestamp = samplePosition;
        telem.sampleRate = sr;
        telem.clusterGroupId = clusterGroupId;
        telem.activeLeadInstanceId = instanceId;

        if (numSamples <= 0 || left == nullptr) {
            telem.lastOnsetSample = lastOnsetSample;
            return telem;
        }

        float sumSq = 0.0f;
        float presSumSq = 0.0f;
        float ringSumSq = 0.0f;
        float sibSumSq = 0.0f;
        float maxConsonantAct = 0.0f;

        for (int i = 0; i < numSamples; ++i) {
            const float sL = left[i];
            const float sR = (right != nullptr) ? right[i] : sL;
            const float mono = 0.5f * (sL + sR);
            sumSq += mono * mono;

            // Formant bandpass tracking
            const float vPres = bpPresence.processBP(mono);
            presSumSq += vPres * vPres;

            const float vRing = bpRing.processBP(mono);
            ringSumSq += vRing * vRing;

            // HF consonant tracking
            const auto outHf = hpfConsonant.process(mono);
            const float hfSample = outHf.hp;
            const float absHf = std::abs(hfSample);
            sibSumSq += hfSample * hfSample;

            const float rawDelta = std::max(0.0f, absHf - prevAbsHf);
            prevAbsHf = absHf;

            consonantEnergy += fastCoeff * (absHf - consonantEnergy);
            hfSlowEnergy += slowCoeff * (absHf - hfSlowEnergy);

            const float flux = std::max(0.0f, consonantEnergy - hfSlowEnergy);
            if ((rawDelta > 0.04f || flux > 0.02f) && absHf > 0.01f) {
                if (maxConsonantAct == 0.0f) {
                    lastOnsetSample = samplePosition + static_cast<uint64_t>(i);
                }
                const float act = std::clamp(std::max(rawDelta, flux) * 10.0f, 0.0f, 1.0f);
                maxConsonantAct = std::max(maxConsonantAct, act);
            }
        }

        const float invN = 1.0f / static_cast<float>(numSamples);
        const float rmsLinear = std::sqrt(std::max(0.0f, sumSq * invN));
        telem.rmsDb = gainToDb(rmsLinear);

        const float presLinear = std::sqrt(std::max(0.0f, presSumSq * invN));
        const float ringLinear = std::sqrt(std::max(0.0f, ringSumSq * invN));
        const float sibLinear  = std::sqrt(std::max(0.0f, sibSumSq * invN));
        telem.sibilanceEnergyDb = gainToDb(sibLinear);

        // Formant centroid estimation
        telem.formantF1Hz = 500.0f; // Baseline throat resonance
        const float totalFormantEnergy = presLinear + ringLinear + 1.0e-6f;
        const float presRatio = presLinear / totalFormantEnergy;
        const float ringRatio = ringLinear / totalFormantEnergy;

        telem.formantF2Hz = 1400.0f + presRatio * 1000.0f; // 1400 - 2400 Hz
        telem.formantF3Hz = 2400.0f + ringRatio * 1000.0f; // 2400 - 3400 Hz

        telem.consonantActivity = maxConsonantAct;
        telem.lastOnsetSample = lastOnsetSample;

        // Phoneme classification
        if (telem.rmsDb < -50.0f) {
            telem.activePhoneme = static_cast<uint32_t>(VocalPhonemeClass::Silence);
        } else if (telem.sibilanceEnergyDb > -30.0f && maxConsonantAct > 0.3f) {
            telem.activePhoneme = static_cast<uint32_t>(VocalPhonemeClass::Sibilant);
        } else if (maxConsonantAct > 0.25f) {
            telem.activePhoneme = static_cast<uint32_t>(VocalPhonemeClass::Consonant);
        } else {
            telem.activePhoneme = static_cast<uint32_t>(VocalPhonemeClass::Vowel);
        }

        return telem;
    }

private:
    double sr = 48000.0;
    double invSr = 1.0 / 48000.0;
    ZDFSVF64 bpPresence{};
    ZDFSVF64 bpRing{};
    ZDFSVF64 hpfConsonant{};
    float fastCoeff = 0.0f;
    float slowCoeff = 0.0f;
    float presenceEnergy = 0.0f;
    float ringEnergy = 0.0f;
    float consonantEnergy = 0.0f;
    float hfSlowEnergy = 0.0f;
    float prevAbsHf = 0.0f;
    uint64_t lastOnsetSample = 0;
};

// =============================================================================
// VocalCraftClusterSync Engine Class
// =============================================================================
class VocalCraftClusterSync {
public:
    struct Telemetry {
        ClusterRole role = ClusterRole::Disabled;
        int   clusterChannel = 1;
        int   clusterGroupId = 1;
        bool  isLeadActive = false;
        float leadRmsDb = -90.0f;
        float leadPresenceCentroidHz = 2200.0f;
        float currentPocketCutDb = 0.0f;
        float tightenReductionDb = 0.0f;
        uint64_t syncSampleDelta = 0;
    };

    VocalCraftClusterSync() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = (sampleRate > 8000.0) ? sampleRate : 48000.0;
        invSr = 1.0 / sr;

        pocketFilter.prepare(sr);
        antiFlamShaper.prepare(sr);
        leadAnalyzer.prepare(sr);

        // Sub-block processing interval: 16 samples
        constexpr double kSubBlockDt = 16.0;
        // Fast attack: 4 ms
        pocketAttackCoeff  = static_cast<float>(1.0 - std::exp(-kSubBlockDt / (0.0040 * sr)));
        // Smooth release: 80 ms (anti-pumping)
        pocketReleaseCoeff = static_cast<float>(1.0 - std::exp(-kSubBlockDt / (0.0800 * sr)));
        // Formant tracking smoothing: 30 ms
        formantSmoothCoeff = static_cast<float>(1.0 - std::exp(-kSubBlockDt / (0.0300 * sr)));

        reset();
    }

    void prepare(float sampleRate) noexcept {
        prepare(static_cast<double>(sampleRate));
    }

    void reset() noexcept {
        pocketFilter.reset();
        antiFlamShaper.reset();
        leadAnalyzer.reset();

        currentPocketGainDb = 0.0f;
        currentPocketGainLinear = 1.0f;
        currentFc = 2200.0f;
        smoothedLeadRms = -90.0f;
        lastLeadOnsetSample = 0;
        cachedLeadConsonantAct = 0.0f;
        leadActiveFlag = false;

        atomicRole.store(static_cast<uint32_t>(currentRole), std::memory_order_relaxed);
        atomicLeadRmsDb.store(-90.0f, std::memory_order_relaxed);
        atomicPocketCutDb.store(0.0f, std::memory_order_relaxed);
        atomicTightenDb.store(0.0f, std::memory_order_relaxed);
        atomicPocketFcHz.store(2200.0f, std::memory_order_relaxed);
    }

    // --- Control Parameters API ---
    void setRole(ClusterRole role) noexcept {
        currentRole = role;
        atomicRole.store(static_cast<uint32_t>(role), std::memory_order_relaxed);
    }

    void setClusterChannel(int channelId) noexcept {
        clusterChannelId = std::clamp(channelId, 1, 8);
    }

    void setClusterGroupId(int groupId) noexcept {
        clusterGroupId = std::clamp(groupId, 1, 4);
    }

    void setPocketDepthDb(float depthDb) noexcept {
        // Range: 0.0 dB to -8.0 dB (nominal default -3.5 dB)
        targetPocketDepthDb = std::clamp(depthDb, -8.0f, 0.0f);
    }

    void setPocketQ(float q) noexcept {
        targetPocketQ = std::clamp(q, 0.5f, 2.5f);
        pocketFilter.updateTuning(currentFc, targetPocketQ);
    }

    void setClusterTighten(float tighten0To1) noexcept {
        clusterTighten = std::clamp(tighten0To1, 0.0f, 1.0f);
    }

    void setInstanceId(uint32_t id) noexcept {
        instanceId = (id != 0) ? id : 171;
    }

    // Direct access to internal Pocket Filter for isolated unit testing
    ZDFPeakingBellFilter& getPocketFilter() noexcept {
        return pocketFilter;
    }

    // Direct access to internal Anti-Flam Shaper for isolated unit testing
    AutoTightenAntiFlamShaper& getAntiFlamShaper() noexcept {
        return antiFlamShaper;
    }

    // --- Core Processing Block ---
    void processStereo(float* left, float* right, int numSamples, uint64_t samplePosition) noexcept {
        if (numSamples <= 0 || left == nullptr) return;

        if (currentRole == ClusterRole::Disabled) {
            atomicPocketCutDb.store(0.0f, std::memory_order_relaxed);
            atomicTightenDb.store(0.0f, std::memory_order_relaxed);
            return;
        }

        // =====================================================================
        // ROLE 1: LEAD (Master Broadcast Role)
        // =====================================================================
        if (currentRole == ClusterRole::Lead) {
            VocalClusterLeadTelemetry telem = leadAnalyzer.analyzeBlock(
                left, right, numSamples, samplePosition, instanceId, clusterGroupId);

            // Publish telemetry to designated cluster channel via SWMR atomic double-buffer
            auto& channel = VocalClusterRegistry::getChannel(clusterChannelId);
            channel.writePayload(telem);

            atomicLeadRmsDb.store(telem.rmsDb, std::memory_order_relaxed);
            atomicPocketCutDb.store(0.0f, std::memory_order_relaxed);
            atomicTightenDb.store(0.0f, std::memory_order_relaxed);
            atomicPocketFcHz.store(telem.formantF2Hz * 0.6f + telem.formantF3Hz * 0.4f, std::memory_order_relaxed);
            return;
        }

        // =====================================================================
        // ROLE 2: SATELLITE (Follower / Harmony / Double / Ad-Lib Role)
        // =====================================================================
        if (currentRole == ClusterRole::Satellite) {
            // Wait-Free read of Lead broadcast payload
            const auto& channel = VocalClusterRegistry::getChannel(clusterChannelId);
            const VocalClusterLeadTelemetry telem = channel.readPayload();

            // Timeline validation: Lead active if registered within a reasonable timeline window
            const bool isSameGroup = (telem.clusterGroupId == clusterGroupId);
            const bool isLeadPresent = (telem.activeLeadInstanceId != 0) && isSameGroup;

            // Target pocketing cut is activated only when Lead vocal is singing (RMS > -45 dBFS)
            float targetCutDb = 0.0f;
            float targetFc = 2200.0f;

            if (isLeadPresent && telem.rmsDb > -45.0f) {
                leadActiveFlag = true;
                // Proportional activation between -45 dBFS (onset) and -18 dBFS (full voice)
                const float activity = std::clamp((telem.rmsDb - (-45.0f)) / ((-18.0f) - (-45.0f)), 0.0f, 1.0f);
                targetCutDb = activity * targetPocketDepthDb; // e.g. activity * -3.5 dB

                // Target center frequency tracks Lead formant barycenter F2/F3
                targetFc = std::clamp(telem.formantF2Hz * 0.6f + telem.formantF3Hz * 0.4f, 1200.0f, 3200.0f);
                lastLeadOnsetSample = telem.lastOnsetSample;
                cachedLeadConsonantAct = telem.consonantActivity;
            } else {
                leadActiveFlag = false;
                targetCutDb = 0.0f;
                // Gently return to 2.2 kHz default
                targetFc = 2200.0f;
            }

            // Smooth pocket cut depth with asymmetric ballistics:
            // Attack (4 ms) to instantly create pocket; Release (80 ms) for anti-pumping transparency
            const float cutCoeff = (targetCutDb < currentPocketGainDb) ? pocketAttackCoeff : pocketReleaseCoeff;
            
            // Sub-block processing (every 16 samples) for ultra-efficient coefficient interpolation
            constexpr int kSubBlock = 16;
            const int numSubBlocks = numSamples / kSubBlock;
            const int remainder = numSamples % kSubBlock;

            if (right != nullptr) {
                int sampleIdx = 0;
                for (int sb = 0; sb < numSubBlocks; ++sb) {
                    currentPocketGainDb += cutCoeff * (targetCutDb - currentPocketGainDb);
                    currentPocketGainLinear = dbToGain(currentPocketGainDb);

                    currentFc += formantSmoothCoeff * (targetFc - currentFc);
                    pocketFilter.updateTuning(currentFc, targetPocketQ);

                    for (int i = 0; i < kSubBlock; ++i, ++sampleIdx) {
                        const uint64_t currentTimelineSample = samplePosition + static_cast<uint64_t>(sampleIdx);
                        antiFlamShaper.processStereo(left[sampleIdx], right[sampleIdx],
                                                    currentTimelineSample, lastLeadOnsetSample,
                                                    cachedLeadConsonantAct, clusterTighten);
                        pocketFilter.processStereo(left[sampleIdx], right[sampleIdx], currentPocketGainLinear);
                    }
                }

                if (remainder > 0) {
                    currentPocketGainDb += cutCoeff * (targetCutDb - currentPocketGainDb);
                    currentPocketGainLinear = dbToGain(currentPocketGainDb);
                    pocketFilter.updateTuning(currentFc, targetPocketQ);

                    for (int i = 0; i < remainder; ++i, ++sampleIdx) {
                        const uint64_t currentTimelineSample = samplePosition + static_cast<uint64_t>(sampleIdx);
                        antiFlamShaper.processStereo(left[sampleIdx], right[sampleIdx],
                                                    currentTimelineSample, lastLeadOnsetSample,
                                                    cachedLeadConsonantAct, clusterTighten);
                        pocketFilter.processStereo(left[sampleIdx], right[sampleIdx], currentPocketGainLinear);
                    }
                }
            } else {
                int sampleIdx = 0;
                for (int sb = 0; sb < numSubBlocks; ++sb) {
                    currentPocketGainDb += cutCoeff * (targetCutDb - currentPocketGainDb);
                    currentPocketGainLinear = dbToGain(currentPocketGainDb);

                    currentFc += formantSmoothCoeff * (targetFc - currentFc);
                    pocketFilter.updateTuning(currentFc, targetPocketQ);

                    for (int i = 0; i < kSubBlock; ++i, ++sampleIdx) {
                        const uint64_t currentTimelineSample = samplePosition + static_cast<uint64_t>(sampleIdx);
                        float dummyR = left[sampleIdx];
                        antiFlamShaper.processStereo(left[sampleIdx], dummyR,
                                                    currentTimelineSample, lastLeadOnsetSample,
                                                    cachedLeadConsonantAct, clusterTighten);
                        pocketFilter.processStereo(left[sampleIdx], dummyR, currentPocketGainLinear);
                    }
                }

                if (remainder > 0) {
                    currentPocketGainDb += cutCoeff * (targetCutDb - currentPocketGainDb);
                    currentPocketGainLinear = dbToGain(currentPocketGainDb);
                    pocketFilter.updateTuning(currentFc, targetPocketQ);

                    for (int i = 0; i < remainder; ++i, ++sampleIdx) {
                        const uint64_t currentTimelineSample = samplePosition + static_cast<uint64_t>(sampleIdx);
                        float dummyR = left[sampleIdx];
                        antiFlamShaper.processStereo(left[sampleIdx], dummyR,
                                                    currentTimelineSample, lastLeadOnsetSample,
                                                    cachedLeadConsonantAct, clusterTighten);
                        pocketFilter.processStereo(left[sampleIdx], dummyR, currentPocketGainLinear);
                    }
                }
            }

            atomicLeadRmsDb.store(telem.rmsDb, std::memory_order_relaxed);
            atomicPocketCutDb.store(currentPocketGainDb, std::memory_order_relaxed);
            atomicTightenDb.store(antiFlamShaper.getSuppressionDb(), std::memory_order_relaxed);
            atomicPocketFcHz.store(currentFc, std::memory_order_relaxed);
        }
    }

    void processSample(float& left, float& right, uint64_t samplePosition) noexcept {
        float l = left;
        float r = right;
        processStereo(&l, &r, 1, samplePosition);
        left = l;
        right = r;
    }

    Telemetry getTelemetry() const noexcept {
        Telemetry t;
        t.role = static_cast<ClusterRole>(atomicRole.load(std::memory_order_relaxed));
        t.clusterChannel = clusterChannelId;
        t.clusterGroupId = clusterGroupId;
        t.isLeadActive = leadActiveFlag;
        t.leadRmsDb = atomicLeadRmsDb.load(std::memory_order_relaxed);
        t.leadPresenceCentroidHz = atomicPocketFcHz.load(std::memory_order_relaxed);
        t.currentPocketCutDb = atomicPocketCutDb.load(std::memory_order_relaxed);
        t.tightenReductionDb = atomicTightenDb.load(std::memory_order_relaxed);
        return t;
    }

    inline Telemetry getTelemetrySnapshot() const noexcept {
        return getTelemetry();
    }

private:
    double sr = 48000.0;
    double invSr = 1.0 / 48000.0;

    ClusterRole currentRole = ClusterRole::Disabled;
    int clusterChannelId = 1;
    int clusterGroupId = 1;
    uint32_t instanceId = 171;

    // Pocketing parameters
    float targetPocketDepthDb = -3.5f; // Mix-ready default -3.5 dB
    float targetPocketQ = 1.4f;       // Nominal presence bandwidth Q
    float clusterTighten = 0.70f;     // Anti-flam intensity [0.0, 1.0]

    // State variables
    float currentPocketGainDb = 0.0f;
    float currentPocketGainLinear = 1.0f;
    float currentFc = 2200.0f;
    float pocketAttackCoeff = 0.0f;
    float pocketReleaseCoeff = 0.0f;
    float formantSmoothCoeff = 0.0f;

    // Follower state tracking
    float smoothedLeadRms = -90.0f;
    uint64_t lastLeadOnsetSample = 0;
    float cachedLeadConsonantAct = 0.0f;
    bool leadActiveFlag = false;

    // Sub-modules
    ZDFPeakingBellFilter pocketFilter{};
    AutoTightenAntiFlamShaper antiFlamShaper{};
    LeadVocalAnalyzer leadAnalyzer{};

    // Lock-free atomic telemetry
    std::atomic<uint32_t> atomicRole{ 0 };
    std::atomic<float> atomicLeadRmsDb{ -90.0f };
    std::atomic<float> atomicPocketCutDb{ 0.0f };
    std::atomic<float> atomicTightenDb{ 0.0f };
    std::atomic<float> atomicPocketFcHz{ 2200.0f };
};

} // namespace dsp171
