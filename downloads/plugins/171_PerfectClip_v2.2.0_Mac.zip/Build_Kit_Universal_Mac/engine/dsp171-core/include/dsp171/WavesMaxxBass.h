#pragma once
#include <cmath>
#include <algorithm>

namespace dsp171 {

/**
 * @brief WavesMaxxBass
 * Reverse-engineered from Waves MaxxBass / Renaissance Bass.
 * Uses the psychoacoustic "missing fundamental" phenomenon to extend perceived bass response
 * on small speakers, headphones, or club systems. Isolates sub-bass and synthesizes carefully
 * tuned 2nd, 3rd, and 4th harmonics while optionally high-passing the fundamental.
 */
class WavesMaxxBass {
public:
    WavesMaxxBass() noexcept 
        : m_sampleRate(44100.0f), m_freq(80.0f) {}

    void prepare(float sampleRate) noexcept {
        m_sampleRate = sampleRate;
        resetFilters();
        m_harmEnvL = 0.0f;
        m_harmEnvR = 0.0f;
        updateFilters();
    }

    void setParameters(float freqHz = 80.0f, float originalBassDb = 0.0f, 
                       float maxxBassDb = 3.0f, int highPassOrder = 1,
                       float decayDb = -12.0f, float responseMs = 15.0f) noexcept {
        m_freq = std::clamp(freqHz, 32.0f, 256.0f);
        m_origBassGain = (originalBassDb <= -40.0f) ? 0.0f : std::pow(10.0f, originalBassDb / 20.0f);
        m_maxxBassGain = (maxxBassDb <= -40.0f) ? 0.0f : std::pow(10.0f, maxxBassDb / 20.0f);
        m_highPassOrder = std::clamp(highPassOrder, 0, 2);
        m_decay = std::pow(10.0f, std::clamp(decayDb, -24.0f, -9.0f) / 20.0f);
        m_responseMs = std::clamp(responseMs, 10.0f, 30.0f);
        updateFilters();
    }

    inline void process(float inL, float inR, float& outL, float& outR) noexcept {
        // 1. Separate sub-bass below m_freq from mid/high using Linkwitz-Riley LR4 crossover
        float lowL = m_lpL2.process(m_lpL1.process(inL));
        float lowR = m_lpR2.process(m_lpR1.process(inR));
        float midHighL = m_hpL2.process(m_hpL1.process(inL));
        float midHighR = m_hpR2.process(m_hpR1.process(inR));

        // 2. Synthesize Harmonics (2nd, 3rd, 4th) from the low-pass signal
        float harmL = generateHarmonics(lowL);
        float harmR = generateHarmonics(lowR);

        // 2B. DC Blocker on generated harmonics (removes even-harmonic DC bias)
        m_dcL += 0.005f * (harmL - m_dcL);
        m_dcR += 0.005f * (harmR - m_dcR);
        harmL -= m_dcL;
        harmR -= m_dcR;

        // 3. Bandpass filter the generated harmonics to fit speaker reproduction (100 Hz to 600 Hz)
        harmL = m_bpL2.process(m_bpL1.process(harmL));
        harmR = m_bpR2.process(m_bpR1.process(harmR));

        // 4. Dynamic Leveling of Harmonics (Attack/Decay envelope)
        harmL = applyHarmonicDynamics(harmL, m_harmEnvL);
        harmR = applyHarmonicDynamics(harmR, m_harmEnvR);

        // 5. High-Pass the original sub-bass (if enabled) to save speaker excursion
        float filteredOrigL = lowL;
        float filteredOrigR = lowR;
        if (m_highPassOrder == 1) {
            filteredOrigL = m_subHpL1.process(lowL);
            filteredOrigR = m_subHpR1.process(lowR);
        } else if (m_highPassOrder == 2) {
            filteredOrigL = m_subHpL2.process(m_subHpL1.process(lowL));
            filteredOrigR = m_subHpR2.process(m_subHpR1.process(lowR));
        }

        // 6. Recombine: Highs + Scaled Original Bass + MaxxBass Harmonics
        outL = midHighL + (filteredOrigL * m_origBassGain) + (harmL * m_maxxBassGain);
        outR = midHighR + (filteredOrigR * m_origBassGain) + (harmR * m_maxxBassGain);
    }

    void processBlock(float* left, float* right, int numSamples) noexcept {
        for (int i = 0; i < numSamples; ++i) {
            process(left[i], right[i], left[i], right[i]);
        }
    }

    void processBlock(const float* inL, const float* inR, float* outL, float* outR, int numSamples) noexcept {
        for (int i = 0; i < numSamples; ++i) {
            process(inL[i], inR[i], outL[i], outR[i]);
        }
    }

private:
    float m_sampleRate;
    float m_freq;
    float m_origBassGain{1.0f};
    float m_maxxBassGain{1.41f};
    int m_highPassOrder{1};
    float m_decay{0.25f};
    float m_responseMs{15.0f};

    struct Biquad {
        float b0{1}, b1{0}, b2{0}, a1{0}, a2{0};
        float z1{0}, z2{0};
        inline float process(float in) noexcept {
            float out = b0 * in + z1;
            z1 = b1 * in - a1 * out + z2;
            z2 = b2 * in - a2 * out;
            return out;
        }
        void reset() noexcept { z1 = 0.0f; z2 = 0.0f; }
    };

    Biquad m_lpL1, m_lpL2, m_lpR1, m_lpR2;
    Biquad m_hpL1, m_hpL2, m_hpR1, m_hpR2;
    Biquad m_subHpL1, m_subHpL2, m_subHpR1, m_subHpR2;
    Biquad m_bpL1, m_bpL2, m_bpR1, m_bpR2;
    float m_harmEnvL{0.0f};
    float m_harmEnvR{0.0f};
    float m_dcL{0.0f};
    float m_dcR{0.0f};

    void resetFilters() noexcept {
        m_lpL1.reset(); m_lpL2.reset(); m_lpR1.reset(); m_lpR2.reset();
        m_hpL1.reset(); m_hpL2.reset(); m_hpR1.reset(); m_hpR2.reset();
        m_subHpL1.reset(); m_subHpL2.reset(); m_subHpR1.reset(); m_subHpR2.reset();
        m_bpL1.reset(); m_bpL2.reset(); m_bpR1.reset(); m_bpR2.reset();
        m_dcL = 0.0f;
        m_dcR = 0.0f;
    }

    void updateFilters() noexcept {
        // Lowpass at m_freq
        float omega = 2.0f * 3.14159265f * m_freq / m_sampleRate;
        float alpha = std::sin(omega) * 0.7071f;
        float cosW = std::cos(omega);
        float a0 = 1.0f + alpha;

        float lpB0 = ((1.0f - cosW) * 0.5f) / a0;
        float lpB1 = (1.0f - cosW) / a0;
        float lpB2 = ((1.0f - cosW) * 0.5f) / a0;
        float a1 = (-2.0f * cosW) / a0;
        float a2 = (1.0f - alpha) / a0;

        auto applyCoeffs = [=](Biquad& b, float b0, float b1, float b2) {
            b.b0 = b0; b.b1 = b1; b.b2 = b2; b.a1 = a1; b.a2 = a2;
        };

        applyCoeffs(m_lpL1, lpB0, lpB1, lpB2);
        applyCoeffs(m_lpL2, lpB0, lpB1, lpB2);
        applyCoeffs(m_lpR1, lpB0, lpB1, lpB2);
        applyCoeffs(m_lpR2, lpB0, lpB1, lpB2);

        // Highpass at m_freq
        float hpB0 = ((1.0f + cosW) * 0.5f) / a0;
        float hpB1 = -(1.0f + cosW) / a0;
        float hpB2 = ((1.0f + cosW) * 0.5f) / a0;
        applyCoeffs(m_hpL1, hpB0, hpB1, hpB2);
        applyCoeffs(m_hpL2, hpB0, hpB1, hpB2);
        applyCoeffs(m_hpR1, hpB0, hpB1, hpB2);
        applyCoeffs(m_hpR2, hpB0, hpB1, hpB2);
        applyCoeffs(m_subHpL1, hpB0, hpB1, hpB2);
        applyCoeffs(m_subHpL2, hpB0, hpB1, hpB2);
        applyCoeffs(m_subHpR1, hpB0, hpB1, hpB2);
        applyCoeffs(m_subHpR2, hpB0, hpB1, hpB2);

        // Bandpass for harmonics: centered at 2.5 * m_freq (e.g. 200 Hz), Q=1.0
        float bpFreq = std::clamp(m_freq * 2.5f, 80.0f, 600.0f);
        float omegaBP = 2.0f * 3.14159265f * bpFreq / m_sampleRate;
        float alphaBP = std::sin(omegaBP) * 0.5f;
        float a0BP = 1.0f + alphaBP;
        float bpB0 = alphaBP / a0BP;
        float bpB1 = 0.0f;
        float bpB2 = -alphaBP / a0BP;
        float a1BP = (-2.0f * std::cos(omegaBP)) / a0BP;
        float a2BP = (1.0f - alphaBP) / a0BP;

        auto applyBP = [=](Biquad& b) {
            b.b0 = bpB0; b.b1 = bpB1; b.b2 = bpB2; b.a1 = a1BP; b.a2 = a2BP;
        };
        applyBP(m_bpL1); applyBP(m_bpL2);
        applyBP(m_bpR1); applyBP(m_bpR2);
    }

    inline float generateHarmonics(float x) noexcept {
        // Asymmetric diode rectification + polynomial saturation
        float x2 = x * x;
        float x3 = x2 * x;
        float x4 = x2 * x2;
        // 2nd harmonic (even, warmth) + 3rd harmonic (odd, edge) + 4th harmonic (sparkle)
        return 0.6f * x2 + 0.3f * x3 + 0.15f * x4;
    }

    inline float applyHarmonicDynamics(float harm, float& env) noexcept {
        float absHarm = std::fabs(harm);
        float alphaAtt = 1.0f - std::exp(-1.0f / ((m_responseMs * 0.001f) * m_sampleRate));
        float alphaRel = 1.0f - std::exp(-1.0f / (0.080f * m_sampleRate));
        if (absHarm > env) env += alphaAtt * (absHarm - env);
        else env += alphaRel * (absHarm - env);

        // Soft compression of harmonics
        float gain = 1.0f / (1.0f + env * (1.0f - m_decay) * 2.0f);
        return harm * gain;
    }
};

} // namespace dsp171
