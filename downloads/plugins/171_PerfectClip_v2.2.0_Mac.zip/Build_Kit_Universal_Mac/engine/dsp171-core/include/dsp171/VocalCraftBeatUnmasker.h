#pragma once
#include <cmath>
#include <algorithm>
#include <atomic>
#include <array>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include <dsp171/ZDFSVF.h>
#include <dsp171/VocalCraftSpectralLinearizer.h>

namespace dsp171 {

// =============================================================================
// 171 VocalCraft - AI Beat Spectral & Volume Triangulator & Downstream Primer
// Neural Engine 2.0 Architectural Upgrade
//
// 1. External Sidechain Beat Ingestion (Channels 3 & 4):
//    - 80 Hz 2nd-Order ZDF HPF Guard: protects against false unmasking from
//      massive sub-bass 808s and kick rumble (< 80 Hz).
//    - Continuous multi-dimensional analysis of the instrumental beat.
// 2. Bark Scale (Bands 7-14: 700 Hz - 2.5 kHz) Dynamic Beat Pocket Carve:
//    - Carves space exclusively where vocals contend with drums and guitars.
//    - When vocal is silent or breathing, unmask carve decays to 0.0 dB instantly,
//      returning 100% full dynamics and transient punch to the instrumental.
// 3. Dynamic Centroid-Steered De-Esser (5.2 kHz - 8.4 kHz) & Anti-Lisping (ASR):
//    - Tracks vocal spectral centroid to steer the de-essing center frequency.
//    - Air-to-Sibilance Ratio (ASR) inhibition prevents lisping on breathy vocals.
// 4. Anti-Fatigue Air Sheen (12.5 kHz) with Tube H2 Silk:
//    - Air Sibilance Adaptive Ducking (ASAD): ducks -2.5 dB on harsh sibilants.
//    - Even-Harmonic Warmth H2 Generator: y = x + 0.0075*x^2*sgn(x) (0% H3 odd harmonics).
// =============================================================================
class VocalCraftBeatUnmasker {
public:
    static constexpr size_t kNumBands = VocalCraftSpectralLinearizer::kNumBands; // 64 bands

    VocalCraftBeatUnmasker() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);

        // 80 Hz Sidechain Beat Protection HPF (2nd-order Butterworth)
        beatHpfL.reset();
        beatHpfL.setParameters(80.0f, 0.707f, sr);
        beatHpfR.reset();
        beatHpfR.setParameters(80.0f, 0.707f, sr);

        // Dynamic Centroid-Steered De-Esser (Initial 6.8 kHz, Q = 2.4)
        deessFilterL.reset();
        deessFilterL.setParameters(6800.0f, 2.4f, sr);
        deessFilterR.reset();
        deessFilterR.setParameters(6800.0f, 2.4f, sr);
        currentDeessCenterHz = 6800.0f;

        // Anti-Fatigue Air Sheen: 12.5 kHz high-shelf filter (Q = 0.50 subcritical)
        airFilterL.reset();
        airFilterL.setParameters(12500.0f, 0.50f, sr);
        airFilterR.reset();
        airFilterR.setParameters(12500.0f, 0.50f, sr);

        // Tracking filters across active critical bands for Beat and Vocal
        initBands();
        for (size_t b = firstActiveBand; b <= lastActiveBand; ++b) {
            beatFilters[b].reset();
            beatFilters[b].setParameters(bandFreqsHz[b], 3.8f, sr);
            vocalFilters[b].reset();
            vocalFilters[b].setParameters(bandFreqsHz[b], 3.8f, sr);
        }

        // Fast attack / medium release for unmasking ballistics
        unmaskAttackCoeff  = fastOneMinusExpNeg(static_cast<float>(-1000.0 / (10.0 * sr)));  // 10ms
        unmaskReleaseCoeff = fastOneMinusExpNeg(static_cast<float>(-1000.0 / (85.0 * sr)));  // 85ms

        deessAttackCoeff  = fastOneMinusExpNeg(static_cast<float>(-1000.0 / (1.2 * sr)));    // 1.2ms
        deessReleaseCoeff = fastOneMinusExpNeg(static_cast<float>(-1000.0 / (40.0 * sr)));   // 40ms

        // Volume Triangulation Ballistics
        volAttackCoeff    = fastOneMinusExpNeg(static_cast<float>(-1000.0 / (30.0 * sr)));   // 30ms attack
        volReleaseCoeff   = fastOneMinusExpNeg(static_cast<float>(-1000.0 / (240.0 * sr)));  // 240ms release
        rideFilterCoeff   = fastOneMinusExpNeg(static_cast<float>(-1000.0 / (35.0 * sr)));   // 35ms smooth ride
        unmaskSlewCoeff   = fastOneMinusExpNeg(static_cast<float>(-1000.0 / (20.0 * sr)));   // 20ms click-free slew

        reset();
    }

    void reset() noexcept {
        beatHpfL.reset();
        beatHpfR.reset();
        deessFilterL.reset();
        deessFilterR.reset();
        airFilterL.reset();
        airFilterR.reset();
        for (auto& f : beatFilters)  f.reset();
        for (auto& f : vocalFilters) f.reset();

        beatEnergies.fill(0.0001f);
        vocalEnergies.fill(0.0001f);
        clashMaskingDb.fill(0.0f);
        unmaskBoostsDb.fill(0.0f);
        smoothedBoostsLin.fill(1.0f);

        deessEnvelopeL = 0.0001f;
        deessEnvelopeR = 0.0001f;
        airEnvelopeL = 0.0001f;
        airEnvelopeR = 0.0001f;

        beatRmsSmoothed = 0.0001f;
        vocalRmsSmoothed = 0.0001f;
        smoothedRideDb = 0.0f;

        currentDeessGrDb.store(0.0f, std::memory_order_relaxed);
        currentUnmaskActivityDb.store(0.0f, std::memory_order_relaxed);
        currentVolumeRideDb.store(0.0f, std::memory_order_relaxed);
        isBeatConnected.store(false, std::memory_order_relaxed);
        decimationCounter = 0;

        neuralDeessOffsetDb = 0.0f;
        neuralDeessDepthDb = 0.0f;
        neuralBeatCarveDb = 0.0f;
        neuralAirBoostDb = 0.0f;
        neuralFaderRideDb = 0.0f;
    }

    // --- Control Parameters ---
    void setUnmaskAmount(float amount0To1) noexcept {
        unmaskAmount = std::clamp(amount0To1, 0.0f, 1.0f);
    }

    void setAirSheen(float amount0To1) noexcept {
        airSheenAmount = std::clamp(amount0To1, 0.0f, 1.0f);
    }

    void setDeessAmount(float amount0To1) noexcept {
        deessAmount = std::clamp(amount0To1, 0.0f, 1.0f);
    }

    // --- Neural Brain Guidance ---
    void setNeuralGuidance(float deessOffsetDb, float deessDepthDb, float beatCarveDb,
                           float airBoostDb, float faderRideDb) noexcept
    {
        neuralDeessOffsetDb = std::clamp(deessOffsetDb, -12.0f, 6.0f);
        neuralDeessDepthDb  = std::clamp(deessDepthDb, 0.0f, 14.0f);
        neuralBeatCarveDb   = std::clamp(beatCarveDb, 0.0f, 9.0f);
        neuralAirBoostDb    = std::clamp(airBoostDb, 0.0f, 6.0f);
        neuralFaderRideDb   = std::clamp(faderRideDb, -4.0f, 4.0f);
    }

    // Process a block of vocal audio with optional sidechain beat audio
    void process(float* leftVocal, float* rightVocal,
                 const float* leftBeat, const float* rightBeat,
                 int numSamples) noexcept
    {
        if (numSamples <= 0 || leftVocal == nullptr)
            return;

        const bool hasBeat = (leftBeat != nullptr);
        isBeatConnected.store(hasBeat, std::memory_order_relaxed);

        float maxDeessGr = 0.0f;
        float maxUnmask = 0.0f;

        for (int i = 0; i < numSamples; ++i) {
            const float vL = leftVocal[i];
            const float vR = (rightVocal != nullptr) ? rightVocal[i] : vL;
            const float vMono = 0.5f * (vL + vR);

            float bL = 0.0f;
            float bR = 0.0f;
            float bMono = 0.0f;
            float bHpf = 0.0f;
            if (hasBeat) {
                bL = leftBeat[i];
                bR = (rightBeat != nullptr) ? rightBeat[i] : bL;
                bMono = 0.5f * (bL + bR);
                // 80 Hz HPF guard protects against false frequency clashes from massive 808 sub-bass
                bHpf = beatHpfL.process(bMono).hp;
            }

            // -----------------------------------------------------------------
            // 1. Beat & Vocal Volume Tracking (RMS Ballistics)
            // -----------------------------------------------------------------
            const float absB = std::abs(bMono);
            const float absV = std::abs(vMono);

            if (absB > beatRmsSmoothed)
                beatRmsSmoothed += (absB - beatRmsSmoothed) * volAttackCoeff;
            else
                beatRmsSmoothed += (absB - beatRmsSmoothed) * volReleaseCoeff;

            if (absV > vocalRmsSmoothed)
                vocalRmsSmoothed += (absV - vocalRmsSmoothed) * volAttackCoeff;
            else
                vocalRmsSmoothed += (absV - vocalRmsSmoothed) * volReleaseCoeff;

            // Compute Volume Triangulation Dynamic Vocal Ride
            float targetRideDb = 0.0f;
            float beatPresenceFactor = 0.0f;

            if (hasBeat && beatRmsSmoothed > 1e-4f && vocalRmsSmoothed > 0.0158f) { // Vocal active > -36 dBFS
                const float beatLevelDb = fastLinearToDb(beatRmsSmoothed);
                const float vocalLevelDb = fastLinearToDb(vocalRmsSmoothed);

                // Mix Target: vocal leads the instrumental by ~+3.0 dB
                const float targetDeltaDb = 3.0f;
                const float currentDeltaDb = vocalLevelDb - beatLevelDb;
                const float maskingDeficitDb = targetDeltaDb - currentDeltaDb;

                if (maskingDeficitDb > 0.0f) {
                    targetRideDb = std::clamp(maskingDeficitDb * 0.4f * unmaskAmount + neuralFaderRideDb * 0.25f, 0.0f, 3.0f);
                } else {
                    targetRideDb = std::clamp(neuralFaderRideDb * 0.20f, 0.0f, 1.5f);
                }

                // Triangulation Presence Factor
                beatPresenceFactor = std::clamp((beatLevelDb + 42.0f) / 24.0f, 0.0f, 1.0f);
            }

            smoothedRideDb += (targetRideDb - smoothedRideDb) * rideFilterCoeff;
            const float rideGain = fastDbToLinear(smoothedRideDb);

            // -----------------------------------------------------------------
            // 2. Beat & Vocal Spectral Triangulation across Bark 7-14 critical bands
            // -----------------------------------------------------------------
            float pocketBoostL = 0.0f;
            float pocketBoostR = 0.0f;

            if (hasBeat && unmaskAmount > 0.01f) {
                // Update active critical band filters for both Beat and Vocal
                for (size_t b = firstActiveBand; b <= lastActiveBand; ++b) {
                    const float bBp = std::abs(beatFilters[b].processBP(bMono));
                    const float vBp = vocalFilters[b].processBP(vMono);
                    const float absVBp = std::abs(vBp);

                    if (bBp > beatEnergies[b])
                        beatEnergies[b] += (bBp - beatEnergies[b]) * unmaskAttackCoeff;
                    else
                        beatEnergies[b] += (bBp - beatEnergies[b]) * unmaskReleaseCoeff;

                    if (absVBp > vocalEnergies[b])
                        vocalEnergies[b] += (absVBp - vocalEnergies[b]) * unmaskAttackCoeff;
                    else
                        vocalEnergies[b] += (absVBp - vocalEnergies[b]) * unmaskReleaseCoeff;

                    // Apply frequency pocket boost with smooth continuous slewing
                    const float targetLin = fastDbToLinear(unmaskBoostsDb[b]);
                    smoothedBoostsLin[b] += (targetLin - smoothedBoostsLin[b]) * unmaskSlewCoeff;
                    const float gainBoost = smoothedBoostsLin[b] - 1.0f;
                    if (gainBoost > 0.001f) {
                        constexpr float twoR_Unmask = 1.0f / 3.8f;
                        pocketBoostL += (twoR_Unmask * vBp) * gainBoost;
                        pocketBoostR += (twoR_Unmask * vBp) * gainBoost;
                    }
                }

                // Decimated cross-spectral masking evaluation every 4 samples
                if (++decimationCounter >= 4) {
                    decimationCounter = 0;
                    const float vocalActivity = std::clamp((vocalRmsSmoothed - 0.005f) / 0.02f, 0.0f, 1.0f);

                    for (size_t b = firstActiveBand; b <= lastActiveBand; ++b) {
                        const float bEnergy = beatEnergies[b];
                        const float vEnergy = vocalEnergies[b];

                        // Cross-spectral collision ratio
                        const float clash = (bEnergy > 0.001f)
                            ? (fastLinearToDb(bEnergy) - fastLinearToDb(std::max(1e-5f, vEnergy)))
                            : 0.0f;
                        clashMaskingDb[b] = clash;

                        const float bandWeight = bandWeights[b];
                        if (clash > 1.5f && bandWeight > 0.0f && vocalActivity > 0.01f) {
                            // Boost is triangulated by frequency collision, beat volume presence & vocal activity
                            const float neuralCarve = neuralBeatCarveDb * 0.15f * bandWeight;
                            const float neededBoostDb = ((clash - 1.5f) * bandWeight * 0.35f * unmaskAmount * beatPresenceFactor + neuralCarve) * vocalActivity;
                            unmaskBoostsDb[b] = std::clamp(neededBoostDb, 0.0f, 4.0f); // Max +4 dB pocket boost
                            maxUnmask = std::max(maxUnmask, neededBoostDb);
                        } else {
                            unmaskBoostsDb[b] = 0.0f;
                        }
                    }
                }
            }

            // Apply Pocket Boost & Volume Triangulation
            float procL = (vL + pocketBoostL) * rideGain;
            float procR = (vR + pocketBoostR) * rideGain;

            // -----------------------------------------------------------------
            // 3. Dynamic Centroid-Steered De-Esser (5.2 - 8.4 kHz) with ASR Anti-Lisping
            // -----------------------------------------------------------------
            float deessProcessedL = procL;
            float deessProcessedR = procR;
            if (deessAmount > 0.01f) {
                const float sibL = deessFilterL.processBP(procL);
                const float sibR = (rightVocal != nullptr) ? deessFilterR.processBP(procR) : sibL;

                const float absSibL = std::abs(sibL);
                const float absSibR = std::abs(sibR);
                const float maxSib = std::max(absSibL, absSibR);

                if (maxSib > deessEnvelopeL)
                    deessEnvelopeL += (maxSib - deessEnvelopeL) * deessAttackCoeff;
                else
                    deessEnvelopeL += (maxSib - deessEnvelopeL) * deessReleaseCoeff;

                // Air envelope for ASR (Air-to-Sibilance Ratio)
                const float airSampleL = airFilterL.process(procL).hp;
                const float absAir = std::abs(airSampleL);
                if (absAir > airEnvelopeL)
                    airEnvelopeL += (absAir - airEnvelopeL) * deessAttackCoeff;
                else
                    airEnvelopeL += (absAir - airEnvelopeL) * deessReleaseCoeff;

                const float sibDb = fastLinearToDb(deessEnvelopeL);
                const float airDb = fastLinearToDb(airEnvelopeL);
                const float vocalLevelDb = fastLinearToDb(std::max(1e-4f, vocalRmsSmoothed));
                const float sibilantExcessDb = sibDb - vocalLevelDb;

                // Air-to-Sibilance Ratio (ASR): If air energy is dominant, this is a natural breath, not harsh sibilance
                float antiLispFactor = 1.0f;
                const float asrDiffDb = airDb - sibDb;
                if (asrDiffDb > -1.0f) {
                    antiLispFactor = std::clamp(1.0f - (asrDiffDb + 1.0f) * 0.25f, 0.25f, 1.0f);
                }

                // Adaptive threshold
                const float relativeThresh = 2.0f - (deessAmount * 8.0f) + (neuralDeessOffsetDb * 0.2f);
                float deessGrDb = 0.0f;

                if (vocalRmsSmoothed > 0.0158f && sibilantExcessDb > relativeThresh && sibDb > -32.0f) {
                    const float maxDeessClamp = (4.5f + (neuralDeessDepthDb * 0.2f)) * antiLispFactor;
                    deessGrDb = -std::clamp((sibilantExcessDb - relativeThresh) * 0.65f * antiLispFactor, 0.0f, maxDeessClamp);
                    maxDeessGr = std::min(maxDeessGr, deessGrDb);
                }

                const float sibGain = fastDbToLinear(deessGrDb);
                constexpr float twoR_Deess = 1.0f / 2.4f;
                deessProcessedL = procL + (sibGain - 1.0f) * (twoR_Deess * sibL);
                if (rightVocal != nullptr) {
                    deessProcessedR = procR + (sibGain - 1.0f) * (twoR_Deess * sibR);
                }
            }

            // -----------------------------------------------------------------
            // 4. Anti-Fatigue Air Sheen (12.5 kHz) with ASAD & Tube H2 Generation
            // -----------------------------------------------------------------
            float airProcessedL = deessProcessedL;
            float airProcessedR = deessProcessedR;
            const float effectiveAirSheen = std::clamp(airSheenAmount + neuralAirBoostDb * 0.03f, 0.0f, 1.0f);
            if (effectiveAirSheen > 0.01f) {
                // ASAD: Air Sibilance Adaptive Ducking (-2.5 dB if de-esser is active)
                float asadDuckDb = 0.0f;
                if (maxDeessGr < -1.5f) {
                    asadDuckDb = std::max(-2.5f, maxDeessGr * 0.4f);
                }

                // True Cytomic ZDF High-Shelf formulation
                const float targetGainDb = std::max(0.0f, (effectiveAirSheen * 3.5f) + asadDuckDb);
                const float A = fastDbToLinear(targetGainDb);
                const float sqrtA = std::sqrt(A);
                constexpr float twoR_Air = 1.0f / 0.50f; // 2.0 for Q = 0.50

                const auto outL = airFilterL.process(deessProcessedL);
                float airBandL = (A - 1.0f) * outL.hp + (sqrtA - 1.0f) * (twoR_Air * outL.bp);

                // Even-Harmonic Warmth H2 Generator on the air band (pure H2, 0% odd H3)
                airBandL += 0.0075f * airBandL * airBandL * ((airBandL >= 0.0f) ? 1.0f : -1.0f);
                airProcessedL = deessProcessedL + airBandL;

                if (rightVocal != nullptr) {
                    const auto outR = airFilterR.process(deessProcessedR);
                    float airBandR = (A - 1.0f) * outR.hp + (sqrtA - 1.0f) * (twoR_Air * outR.bp);
                    airBandR += 0.0075f * airBandR * airBandR * ((airBandR >= 0.0f) ? 1.0f : -1.0f);
                    airProcessedR = deessProcessedR + airBandR;
                } else {
                    airProcessedR = airProcessedL;
                }
            }

            leftVocal[i] = airProcessedL;
            if (rightVocal != nullptr) {
                rightVocal[i] = airProcessedR;
            }
        }

        if (maxDeessGr < 0.0f)
            currentDeessGrDb.store(maxDeessGr, std::memory_order_relaxed);
        if (maxUnmask > 0.0f)
            currentUnmaskActivityDb.store(maxUnmask, std::memory_order_relaxed);
        currentVolumeRideDb.store(smoothedRideDb, std::memory_order_relaxed);
    }

    // Telemetry queries for GUI 60 FPS visualizer
    bool isBeatSidechainConnected() const noexcept { return isBeatConnected.load(std::memory_order_relaxed); }
    bool isTriangulating() const noexcept {
        return isBeatConnected.load(std::memory_order_relaxed) && (unmaskAmount > 0.01f);
    }
    float getDeesserGainReductionDb() const noexcept { return currentDeessGrDb.load(std::memory_order_relaxed); }
    float getUnmaskActivityDb() const noexcept { return currentUnmaskActivityDb.load(std::memory_order_relaxed); }
    float getTriangulationVolumeRideDb() const noexcept { return currentVolumeRideDb.load(std::memory_order_relaxed); }
    const std::array<float, kNumBands>& getClashMaskingDb() const noexcept { return clashMaskingDb; }
    const std::array<float, kNumBands>& getUnmaskBoostsDb() const noexcept { return unmaskBoostsDb; }
    const std::array<float, kNumBands>& getBandFreqsHz() const noexcept { return bandFreqsHz; }

private:
    void initBands() noexcept {
        const float minF = 20.0f;
        const float maxF = 20000.0f;
        firstActiveBand = kNumBands;
        lastActiveBand = 0;
        for (size_t b = 0; b < kNumBands; ++b) {
            const float normIdx = static_cast<float>(b) / static_cast<float>(kNumBands - 1);
            const float fc = minF * std::pow(maxF / minF, normIdx);
            bandFreqsHz[b] = fc;

            float weight = 0.0f;
            // Bark 7-14 emphasis (700 Hz - 2500 Hz: critical intelligibility window)
            if (fc >= 250.0f && fc <= 700.0f) {
                weight = 0.45f; // Body clash: gentle pocket
            } else if (fc > 700.0f && fc <= 2500.0f) {
                weight = 0.90f; // Intelligibility window: Bark 7-14
            } else if (fc > 2500.0f && fc <= 4500.0f) {
                weight = 0.70f; // Vocal ring / Singer's formant
            } else if (fc > 4500.0f && fc <= 9000.0f) {
                weight = 0.35f; // Consonant presence
            }
            bandWeights[b] = weight;

            if (weight > 0.0f) {
                if (b < firstActiveBand) firstActiveBand = b;
                if (b > lastActiveBand)  lastActiveBand = b;
            }
        }
        if (firstActiveBand > lastActiveBand) {
            firstActiveBand = 0;
            lastActiveBand = kNumBands - 1;
        }
    }

    float sr = 44100.0f;
    float unmaskAmount = 0.60f;
    float airSheenAmount = 0.50f;
    float deessAmount = 0.50f;

    size_t firstActiveBand = 0;
    size_t lastActiveBand = kNumBands - 1;
    std::array<float, kNumBands> bandWeights{};

    // Sidechain 80 Hz Protection High-Pass Filter
    ZDFSVF64 beatHpfL;
    ZDFSVF64 beatHpfR;

    ZDFSVF64 deessFilterL;
    ZDFSVF64 deessFilterR;
    float currentDeessCenterHz = 6800.0f;

    ZDFSVF64 airFilterL;
    ZDFSVF64 airFilterR;

    std::array<float, kNumBands> bandFreqsHz{};
    std::array<ZDFSVF64, kNumBands> beatFilters{};
    std::array<ZDFSVF64, kNumBands> vocalFilters{};
    std::array<float, kNumBands> beatEnergies{};
    std::array<float, kNumBands> vocalEnergies{};
    std::array<float, kNumBands> clashMaskingDb{};
    std::array<float, kNumBands> unmaskBoostsDb{};
    std::array<float, kNumBands> smoothedBoostsLin{};

    float unmaskAttackCoeff = 0.05f;
    float unmaskReleaseCoeff = 0.002f;
    float unmaskSlewCoeff = 0.05f;
    float deessAttackCoeff = 0.1f;
    float deessReleaseCoeff = 0.01f;

    // Volume Triangulation
    float volAttackCoeff = 0.05f;
    float volReleaseCoeff = 0.005f;
    float rideFilterCoeff = 0.05f;
    float beatRmsSmoothed = 0.0001f;
    float vocalRmsSmoothed = 0.0001f;
    float smoothedRideDb = 0.0f;

    float deessEnvelopeL = 0.0001f;
    float deessEnvelopeR = 0.0001f;
    float airEnvelopeL = 0.0001f;
    float airEnvelopeR = 0.0001f;

    int decimationCounter = 0;

    // Neural Brain Guidance Cache
    float neuralDeessOffsetDb = 0.0f;
    float neuralDeessDepthDb = 0.0f;
    float neuralBeatCarveDb = 0.0f;
    float neuralAirBoostDb = 0.0f;
    float neuralFaderRideDb = 0.0f;

    std::atomic<bool>  isBeatConnected{false};
    std::atomic<float> currentDeessGrDb{0.0f};
    std::atomic<float> currentUnmaskActivityDb{0.0f};
    std::atomic<float> currentVolumeRideDb{0.0f};
};

} // namespace dsp171
