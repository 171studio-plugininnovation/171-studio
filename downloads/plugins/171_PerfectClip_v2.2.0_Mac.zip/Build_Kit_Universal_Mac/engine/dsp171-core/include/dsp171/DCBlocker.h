#pragma once
#ifndef DSP171_DC_BLOCKER_H
#define DSP171_DC_BLOCKER_H

#include <cmath>
#include "Common.h"

namespace dsp171 {

// Filtro passa-alto DC-Blocker (default 10 Hz) con rampa di decadimento pulita
class DCBlocker {
public:
    void prepare(double sampleRate, float cutoffHz = 10.0f) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        setCutoff(cutoffHz);
        reset();
    }

    void setCutoff(float cutoffHz) noexcept {
        // r = exp(-2 * pi * fc / sr) - exact mathematical pole
        rDC = static_cast<float>(std::exp(-2.0 * 3.14159265358979323846 * static_cast<double>(cutoffHz) / static_cast<double>(sr)));
    }

    void reset() noexcept {
        x1 = 0.0;
        y1 = 0.0;
    }

    float getRDC() const noexcept { return rDC; }
    double getY1() const noexcept { return y1; }
    double getX1() const noexcept { return x1; }

    inline float processSample(float in) noexcept {
        if (!std::isfinite(in)) {
            x1 = 0.0;
            y1 = 0.0;
            return 0.0f;
        }
        // 64-bit accumulation with zero cancellation noise and hardware denormal immunity
        const double inD = static_cast<double>(in);
        const double out = (inD - x1) + static_cast<double>(rDC) * y1;
        x1 = inD;
        y1 = (std::abs(out) < 1.0e-20) ? 0.0 : out;
        return static_cast<float>(out);
    }

private:
    float sr = 44100.0f;
    float rDC = 0.995f;
    double x1 = 0.0;
    double y1 = 0.0;
};

} // namespace dsp171

#endif // DSP171_DC_BLOCKER_H
