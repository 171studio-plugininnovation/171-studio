#pragma once

#include <cmath>
#include <algorithm>
#include "Common.h"
#include "FastMath.h"
#include "ZDFSVF.h"

namespace dsp171 {

// =============================================================================
// RenaissanceDeEsser (R-DeEsser)
// Inspired by: Waves Renaissance DeEsser
// Crafted for: 171EasyVoice Vocal Channel Strip
//
// Features:
// 1. Dual Processing Modes:
//    - Split-Band: Complementary phase-exact crossover ducking only the sibilant
//      band (leaving the warm vocal body 100% bit-exact and untouched).
//    - Wideband: Transparent broad-spectrum ducking triggered by HF energy.
// 2. Dual Sidechain Detection Filters:
//    - Bell Mode: Focused 2nd-order bandpass isolating harsh resonances (4-9 kHz).
//    - HighPass Mode: 12 dB/oct high-pass sidechain capturing broad high sibilance.
// 3. Dynamic Controls:
//    - Frequency: 1000 Hz to 12000 Hz.
//    - Threshold: -48.0 dBFS to 0.0 dBFS.
//    - Range: 0.0 dB to -24.0 dB maximum gain reduction limit (prevents lisping).
//    - Fast ballistic peak rectifier (1 ms attack, ~25 ms release).
// 4. Listen Modes:
//    - Normal (Processed Vocal Output)
//    - Sidechain (Monitor the detection signal)
//    - Sibilance Delta (Hear exclusively the removed sibilant bursts)
// 5. Hard real-time safe (zero heap allocations, C++20, noexcept).
// =============================================================================

class RenaissanceDeEsser {
public:
    enum class DeEsserMode : uint8_t {
        SplitBand = 0, // Crossover splitting (attenuates only sibilance)
        Wideband  = 1  // Attenuates entire signal broad-band
    };

    enum class SidechainType : uint8_t {
        Bell     = 0, // Focused resonant bell bandpass
        HighPass = 1  // 12 dB/oct high-pass filter
    };

    enum class ListenMode : uint8_t {
        Audio          = 0, // Normal vocal output
        Sidechain      = 1, // Monitor sidechain filter output
        SibilanceDelta = 2  // Monitor only the removed sibilants
    };

    RenaissanceDeEsser() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        invSr = 1.0f / sr;

        // Ballistic time constants: 0.8 ms attack, 28 ms release
        attackCoeff = 1.0f - std::exp(-1.0f / (0.0008f * sr));
        releaseCoeff = 1.0f - std::exp(-1.0f / (0.028f * sr));

        updateFilters();
        reset();
    }

    void reset() noexcept {
        scFilterL.reset();
        scFilterR.reset();
        splitFilterL.reset();
        splitFilterR.reset();

        envelopeL = 0.0f;
        envelopeR = 0.0f;
        currentGrDbL = 0.0f;
        currentGrDbR = 0.0f;
    }

    // --- Parameter Setters ---

    void setMode(DeEsserMode mode) noexcept {
        currentMode = mode;
    }

    void setSidechainType(SidechainType type) noexcept {
        scType = type;
        updateFilters();
    }

    void setListenMode(ListenMode mode) noexcept {
        currentListen = mode;
    }

    // Frequency: 1000 Hz to 12000 Hz (default ~5800 Hz)
    void setFrequency(float freqHz) noexcept {
        frequencyHz = std::clamp(freqHz, 1000.0f, 12000.0f);
        updateFilters();
    }

    // Threshold: -48.0 dBFS to 0.0 dBFS
    void setThresholdDb(float threshDb) noexcept {
        thresholdDb = std::clamp(threshDb, -48.0f, 0.0f);
    }

    // Range: 0.0 dB to -24.0 dB (maximum allowed attenuation limit)
    void setRangeDb(float rangeDb) noexcept {
        // rangeDb can be passed as negative (-24..0) or positive (0..24)
        const float mag = std::abs(rangeDb);
        maxAttenDb = std::clamp(mag, 0.0f, 24.0f);
    }

    // Telemetry: Gain Reduction in dB (valori positivi per display VU meter)
    [[nodiscard]] float getGainReductionL() const noexcept { return currentGrDbL; }
    [[nodiscard]] float getGainReductionR() const noexcept { return currentGrDbR; }

    // --- Audio Processing Loop ---

    inline void processSample(float inL, float inR, float& outL, float& outR) noexcept {
        // Guard non-finite inputs
        if (!std::isfinite(inL)) inL = 0.0f;
        if (!std::isfinite(inR)) inR = 0.0f;

        // 1. Filtraggio Sidechain (Rilevamento delle sibilanti)
        auto scOutL = scFilterL.process(inL);
        auto scOutR = scFilterR.process(inR);

        const float scSigL = (scType == SidechainType::Bell) ? scOutL.bp : scOutL.hp;
        const float scSigR = (scType == SidechainType::Bell) ? scOutR.bp : scOutR.hp;

        // Se in modalità Sidechain Listen, restituisce direttamente il segnale analizzato
        if (currentListen == ListenMode::Sidechain) {
            outL = scSigL;
            outR = scSigR;
            return;
        }

        // 2. Rilevatore di Inviluppo Balistico a Picco Phase-Locked
        const float peakL = std::abs(scSigL);
        const float peakR = std::abs(scSigR);
        const float maxPeak = std::max(peakL, peakR);

        // Converti in dB con soglia anti-denormal a -120 dBFS
        const float maxPeakDb = (maxPeak > 1.0e-6f) ? (20.0f * std::log10(maxPeak)) : -120.0f;

        // Calcolo dell'eccesso sopra la soglia (Over-threshold)
        float targetGrDb = 0.0f;
        if (maxPeakDb > thresholdDb) {
            // Slope 2:1 per una compressione sibilante morbida e naturale
            const float overDb = maxPeakDb - thresholdDb;
            targetGrDb = std::min(maxAttenDb, overDb * 1.5f);
        }

        // Lisciamento dell'inviluppo di Gain Reduction (Attacco rapido, rilascio naturale)
        if (targetGrDb > envelopeL) {
            envelopeL += attackCoeff * (targetGrDb - envelopeL);
        } else {
            envelopeL += releaseCoeff * (targetGrDb - envelopeL);
        }

        if (std::abs(envelopeL) < 1.0e-5f) envelopeL = 0.0f;
        envelopeR = envelopeL; // Phase-locked stereo

        currentGrDbL = envelopeL;
        currentGrDbR = envelopeR;

        // Guadagno lineare di attenuazione [0.0 .. 1.0]
        const float attenGainLin = std::pow(10.0f, -envelopeL * 0.05f);

        // 3. Applicazione del Gain Reduction (Split-Band vs Wideband)
        if (currentMode == DeEsserMode::Wideband) {
            // In Wideband, l'intero segnale viene attenuato proporzionalmente
            const float sibilanceDeltaL = inL * (1.0f - attenGainLin);
            const float sibilanceDeltaR = inR * (1.0f - attenGainLin);

            if (currentListen == ListenMode::SibilanceDelta) {
                outL = sibilanceDeltaL;
                outR = sibilanceDeltaR;
            } else {
                outL = inL * attenGainLin;
                outR = inR * attenGainLin;
            }
        } else {
            // In Split-Band, crossover Linkwitz-Riley LR2 allpass-complimentary (Q = 0.50)
            // H_allpass(s) = H_lp(s) - H_hp(s) = (1 - s^2)/(s+1)^2 = (1-s)/(1+s), |H| = 1.0000 (0.00 dB)
            // H_lp e -H_hp sono in fase (-90°) al crossover: eliminato boost fasico di +0.56 dB
            auto bandL = splitFilterL.process(inL);
            auto bandR = splitFilterR.process(inR);

            const float flatAllPassL = bandL.lp - bandL.hp;
            const float flatAllPassR = bandR.lp - bandR.hp;
            const float sibilantBandL = -bandL.hp;
            const float sibilantBandR = -bandR.hp;

            const float sibilanceDeltaL = sibilantBandL * (1.0f - attenGainLin);
            const float sibilanceDeltaR = sibilantBandR * (1.0f - attenGainLin);

            if (currentListen == ListenMode::SibilanceDelta) {
                outL = sibilanceDeltaL;
                outR = sibilanceDeltaR;
            } else {
                outL = flatAllPassL - sibilanceDeltaL;
                outR = flatAllPassR - sibilanceDeltaR;
            }
        }
    }

    void processBlock(float* inOutL, float* inOutR, size_t numSamples) noexcept {
        if (!inOutL || !inOutR || numSamples == 0) return;
        for (size_t i = 0; i < numSamples; ++i) {
            processSample(inOutL[i], inOutR[i], inOutL[i], inOutR[i]);
        }
    }

private:
    void updateFilters() noexcept {
        // Filtro di Sidechain (Q = 1.8 per Bell focalizzata, Q = 0.707 per HP)
        const float scQ = (scType == SidechainType::Bell) ? 1.8f : 0.707f;
        scFilterL.setParameters(frequencyHz, scQ, sr);
        scFilterR.setParameters(frequencyHz, scQ, sr);

        // Filtro di Crossover Split-Band (Q = 0.707 Butterworth per preservare la fase)
        splitFilterL.setParameters(frequencyHz, 0.50f, sr);
        splitFilterR.setParameters(frequencyHz, 0.50f, sr);
    }

    float sr = 48000.0f;
    float invSr = 1.0f / 48000.0f;

    DeEsserMode currentMode = DeEsserMode::SplitBand;
    SidechainType scType = SidechainType::Bell;
    ListenMode currentListen = ListenMode::Audio;

    float frequencyHz = 5800.0f;
    float thresholdDb = -20.0f;
    float maxAttenDb = 12.0f;

    float attackCoeff = 0.05f;
    float releaseCoeff = 0.002f;

    float envelopeL = 0.0f;
    float envelopeR = 0.0f;
    float currentGrDbL = 0.0f;
    float currentGrDbR = 0.0f;

    // Zero-Delay Feedback State Variable Filters a 64-bit
    ZDFSVF64 scFilterL;
    ZDFSVF64 scFilterR;
    ZDFSVF64 splitFilterL;
    ZDFSVF64 splitFilterR;
};

} // namespace dsp171
