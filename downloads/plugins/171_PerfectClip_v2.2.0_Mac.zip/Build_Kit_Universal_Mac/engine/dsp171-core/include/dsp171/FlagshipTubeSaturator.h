#pragma once

#include <cmath>
#include <algorithm>
#include <cstdint>
#include "Common.h"
#include "FastMath.h"

namespace dsp171 {

// =============================================================================
// Module: FlagshipTubeSaturator171
// Orchestrated by: Lead Analog Circuit & DSP Physicist (171 Studio Innovatio)
//
// Hardware-modeled from the 171 Studio Flagship Analog Board:
// - Stage 1: 12AX7 / ECC83 Class-A Dual Triode (Ra=100k, B1+=250V, Rk=1.5k, Ck=22uF)
// - Dynamic Miller Capacitance HF Softening (transconductance gm(t)-dependent)
// - Dynamic B+ Power Rail Sag (plate current surge pulling down reservoir voltage)
// - Stage 2: 6AS6 Miniature Dual-Control Pentode (Ra2=68k, B2+=123V)
// - Active Starvation Buffer (Vg2 sweepable from 15V to 120V)
// - Triode Mode (H2 dominant) / Pentode Mode (H3/H5 dominant) / Starve Gating Fuzz
// - Passive 32 kHz Avalon Air Sheen Network
// =============================================================================

enum class FlagshipTubeMode : uint8_t {
    Triode = 0, // 6AS6 screen tied to plate: warm, rich 2nd harmonic (H2)
    Pentode     // 6AS6 independent screen: crisp, biting odd harmonics (H3/H5) + Starve
};

class FlagshipTubeSaturator171 {
public:
    FlagshipTubeSaturator171() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        
        // 5 Hz DC blocker pole
        constexpr float fcDc = 5.0f;
        const float omegaDc = 2.0f * 3.14159265358979323846f * fcDc / sr;
        dcR = 1.0f - std::clamp(omegaDc, 0.0001f, 0.1f);

        // Dynamic cathode bias constants (R_k = 1.5k || C_k = 22uF, tau ~ 45 ms decay, 10 ms charge)
        alphaCathodeAtt = 1.0f - std::exp(-1.0f / (0.010f * sr));
        alphaCathodeRel = 1.0f - std::exp(-1.0f / (0.045f * sr));

        // Grid-leak forward conduction sag (tau_att ~ 1.5 ms, tau_rel ~ 85 ms)
        alphaGridAtt = 1.0f - std::exp(-1.0f / (0.0015f * sr));
        alphaGridRel = 1.0f - std::exp(-1.0f / (0.085f * sr));

        // High-voltage B+ power supply sag (tau_att ~ 25 ms, tau_rel ~ 140 ms smooth exponential return)
        alphaBPlusAtt = 1.0f - std::exp(-1.0f / (0.025f * sr));
        alphaBPlusRel = 1.0f - std::exp(-1.0f / (0.140f * sr));

        // High-voltage B+ power supply sag (tau_att ~ 25 ms, tau_rel ~ 140 ms smooth exponential return)
        alphaBPlusAtt = 1.0f - std::exp(-1.0f / (0.025f * sr));
        alphaBPlusRel = 1.0f - std::exp(-1.0f / (0.140f * sr));

        // Dynamic B+ power rail sag constants (tau_att ~ 35 ms, tau_rel ~ 220 ms)
        alphaBPlusAtt = 1.0f - std::exp(-1.0f / (0.035f * sr));
        alphaBPlusRel = 1.0f - std::exp(-1.0f / (0.220f * sr));

        // Avalon Air Sheen pole (~16 kHz base for 32 kHz shelf transition)
        constexpr float fcAir = 16000.0f;
        airAlpha = std::clamp(2.0f * 3.14159265358979323846f * fcAir / sr, 0.01f, 0.95f);

        reset();
    }

    void reset() noexcept {
        dcX1 = 0.0f;
        dcY1 = 0.0f;
        airState = 0.0f;
        cathodeBiasState = 0.0f;
        gridSagState = 0.0f;
        millerState = 0.0f;
        bPlusSagState = 0.0f;
        bPlusSagState = 0.0f;
    }

    /**
     * @brief Configure parameters
     * @param mode Triode or Pentode
     * @param driveDb Input drive in dB (0.0 to +30.0 dB)
     * @param starveNorm01 Starvation level: 0.0 = 120V (clean nominal), 1.0 = 15V (extreme starve fuzz)
     * @param airDb High Air Sheen boost (0.0 to +12.0 dB)
     * @param outputGainDb Master output trim (-24.0 to +12.0 dB)
     */
    void setParameters(FlagshipTubeMode mode, float driveDb, float starveNorm01, float airDb = 0.0f, float outputGainDb = 0.0f) noexcept {
        currentMode = mode;
        driveGainLin = std::pow(10.0f, std::clamp(driveDb, 0.0f, 30.0f) / 20.0f);
        starveAmount = std::clamp(starveNorm01, 0.0f, 1.0f);
        // Effective Vg2: 120V down to 15V
        vg2Volts = 120.0f - starveAmount * 105.0f;
        screenFactor = std::clamp(vg2Volts / 120.0f, 0.05f, 1.0f);
        
        airGainLin = std::pow(10.0f, std::clamp(airDb, 0.0f, 12.0f) / 20.0f);
        outGainLin = std::pow(10.0f, std::clamp(outputGainDb, -24.0f, 12.0f) / 20.0f);
    }

    [[nodiscard]] float getBPlusSag() const noexcept {
        return bPlusSagState;
    }

    inline float processSample(float inSample) noexcept {
        if (!std::isfinite(inSample)) return 0.0f;

        // -------------------------------------------------------------
        // 1. Stage 1: 12AX7 Class-A Triode Preamp with Dynamic Bias Shift
        // -------------------------------------------------------------
        const float x1 = inSample * driveGainLin;

        // Dynamic Cathode Auto-Bias Shift & Duty-Cycle Modulation:
        // Surge in current on positive swings charges C_k across R_k || C_k.
        // Cathode potential rises, causing subsequent cycles to cold-clip with duty-cycle bloom.
        const float vGkNominal = x1 - cathodeBiasState - gridSagState;
        const float cathodeCurrentSurge = (vGkNominal > 0.0f) ? (0.28f * vGkNominal + 0.10f * (vGkNominal * vGkNominal)) : 0.0f;
        if (cathodeCurrentSurge > cathodeBiasState) {
            cathodeBiasState += alphaCathodeAtt * (cathodeCurrentSurge - cathodeBiasState);
        } else {
            cathodeBiasState += alphaCathodeRel * (cathodeCurrentSurge - cathodeBiasState);
        }

        // Grid-leak forward conduction (Vgk > 0.65V forward diode conduction onto grid coupling cap)
        if (vGkNominal > 0.65f) {
            const float gridCurrent = 0.35f * (vGkNominal - 0.65f);
            gridSagState += alphaGridAtt * (gridCurrent - gridSagState);
        } else {
            gridSagState += alphaGridRel * (0.0f - gridSagState);
        }

        FastMath::flushDenormals(cathodeBiasState);
        FastMath::flushDenormals(gridSagState);

        // Effective grid-to-cathode driving voltage (shifts negative under overdrive -> cold clipping)
        const float vEff = x1 - cathodeBiasState - gridSagState;

        // Dynamic B+ Power Rail Sag:
        // Plate current surges under heavy drive, pulling down B+ power rail voltage
        const float iPlate = (vEff > 0.0f) ? (0.28f * vEff + 0.12f * (vEff * vEff)) : (0.04f * std::abs(vEff));
        const float targetBPlusSag = std::clamp(iPlate * 0.25f, 0.0f, 0.40f);
        if (targetBPlusSag > bPlusSagState) {
            bPlusSagState += alphaBPlusAtt * (targetBPlusSag - bPlusSagState);
        } else {
            bPlusSagState += alphaBPlusRel * (0.0f - bPlusSagState);
        }
        FastMath::flushDenormals(bPlusSagState);

        // Effective rail headroom factor (nominal 1.0, sags down to ~0.72 under sustained overdrive)
        const float vBPlusEff = 1.0f - 0.28f * bPlusSagState;

        float stg1Out;
        if (vEff >= 0.0f) {
            // Positive grid swing: soft compression knee with warm 2nd harmonic curvature
            constexpr float kPos = 0.22f;
            stg1Out = vEff / (1.0f + kPos * vEff);
        } else {
            // Negative grid swing: extended high-voltage headroom with cold cutoff knee
            constexpr float kNeg = 0.10f;
            stg1Out = vEff / (1.0f + kNeg * (-vEff));
        }

        // Headroom modulated by B+ power rail dynamic sag
        stg1Out *= vBPlusEff;

        // Dynamic Miller Capacitance HF Roll-off (C_Miller = C_ga * (1 + |Av(t)|)):
        // Transconductance gm increases under positive drive, lowering cutoff and softening harsh peaks
        const float fcMiller = 30000.0f / (1.0f + 0.85f * std::max(0.0f, vEff));
        const float alphaMiller = std::clamp(2.0f * 3.14159265f * fcMiller / sr, 0.05f, 0.95f);
        millerState += alphaMiller * (stg1Out - millerState);
        FastMath::flushDenormals(millerState);
        stg1Out = millerState;

        // -------------------------------------------------------------
        // 2. Stage 2: 6AS6 Miniature Pentode with Starvation
        // -------------------------------------------------------------
        float stg2Out = 0.0f;
        const float s = screenFactor;

        if (currentMode == FlagshipTubeMode::Triode) {
            // Triode Mode: 6AS6 screen tied to plate (rich H2, smooth saturation)
            const float xt = stg1Out * 0.95f;
            constexpr float asym = 0.28f;
            const float safeX = std::max(-1.8f, xt);
            const float curvedX = safeX + asym * (safeX * safeX);
            stg2Out = std::tanh(curvedX * 1.20f);
        } else {
            // Pentode Mode with Starvation
            const float xp = stg1Out * (1.0f + 0.6f * (1.0f - s));

            if (s > 0.65f) {
                // Nominal to moderate pentode (s in 0.65 .. 1.0)
                const float asym = 0.12f * (1.0f - s);
                const float xAsym = xp + asym * (1.0f - std::exp(-std::abs(xp))) * (xp >= 0.0f ? 1.0f : -0.7f);
                stg2Out = 0.75f * std::tanh(1.50f * xAsym) + 0.25f * std::tanh(3.20f * xAsym);
            } else {
                // Starvation Mode (s in 0.05 .. 0.65): Screen Grid Vg2 collapsed (<35V)
                // Asymmetric variable-threshold gating distortion with Hermite C1 continuity
                const float thresh = 0.08f * (1.0f - s) + 0.02f;
                const float deadzoneGain = 0.25f * s;
                const float threshVal = thresh * deadzoneGain;
                constexpr float delta = 0.04f;

                const float absX = std::abs(xp);
                if (absX > thresh + delta) {
                    const float over = absX - thresh;
                    const float sat = threshVal + std::tanh(over * (3.0f + 4.0f * (1.0f - s))) * (1.0f - threshVal);
                    stg2Out = (xp >= 0.0f) ? sat : -sat * 0.92f;
                } else if (absX > thresh - delta) {
                    // Smooth Hermite cubic blend
                    const float t = (absX - (thresh - delta)) / (2.0f * delta);
                    const float y0 = (thresh - delta) * deadzoneGain;
                    const float y1 = threshVal + std::tanh(delta * (3.0f + 4.0f * (1.0f - s))) * (1.0f - threshVal);
                    const float h00 = (1.0f + 2.0f * t) * (1.0f - t) * (1.0f - t);
                    const float h01 = t * t * (3.0f - 2.0f * t);
                    const float blended = h00 * y0 + h01 * y1;
                    stg2Out = (xp >= 0.0f) ? blended : -blended * 0.92f;
                } else {
                    stg2Out = xp * deadzoneGain;
                }
            }
        }

        // Dynamic B+ Power Supply Sag Simulation (C_psu = 47uF, R_psu = 3.3k, tau_rel ~ 140 ms)
        // High plate current draw discharges the B+ reservoir; recovery follows smooth C-inf exponential
        const float plateCurrent = 0.20f * std::abs(stg1Out) + 0.25f * std::abs(stg2Out);
        if (plateCurrent > bPlusSagState) {
            bPlusSagState += alphaBPlusAtt * (plateCurrent - bPlusSagState);
        } else {
            bPlusSagState += alphaBPlusRel * (0.0f - bPlusSagState);
        }
        FastMath::flushDenormals(bPlusSagState);
        const float bPlusHeadroom = 1.0f - 0.20f * bPlusSagState;
        stg2Out *= bPlusHeadroom;

        // -------------------------------------------------------------
        // Dynamic B+ Power Supply Sag (Plate Current Loading Filter Cap):
        // -------------------------------------------------------------
        const float currentDraw = std::abs(stg2Out);
        if (currentDraw > bPlusSagState) {
            bPlusSagState += alphaBPlusAtt * (currentDraw - bPlusSagState);
        } else {
            bPlusSagState += alphaBPlusRel * (currentDraw - bPlusSagState);
        }
        if (std::abs(bPlusSagState) < 1.0e-25f) bPlusSagState = 0.0f;
        
        // Modulate stage dynamic headroom with smooth C-inf organic sag
        const float sagFactor = 1.0f / (1.0f + 0.12f * bPlusSagState);
        stg2Out *= sagFactor;

        // -------------------------------------------------------------
        // 3. Stage 3: Avalon 32 kHz Air Sheen Network
        // -------------------------------------------------------------
        float airOut = stg2Out;
        if (airGainLin > 1.01f) {
            airState += airAlpha * (stg2Out - airState);
            FastMath::flushDenormals(airState);
            airOut = airState + (stg2Out - airState) * airGainLin;
        }

        // -------------------------------------------------------------
        // 4. Output DC Decoupling & Gain Trim
        // -------------------------------------------------------------
        const float dcOut = airOut - dcX1 + dcR * dcY1;
        dcX1 = airOut;
        dcY1 = dcOut;
        FastMath::flushDenormals(dcX1);
        FastMath::flushDenormals(dcY1);

        return dcOut * outGainLin;
    }

private:
    float sr = 44100.0f;
    FlagshipTubeMode currentMode = FlagshipTubeMode::Pentode;
    
    float driveGainLin = 1.0f;
    float starveAmount = 0.0f;
    float vg2Volts = 120.0f;
    float screenFactor = 1.0f;
    float airGainLin = 1.0f;
    float outGainLin = 1.0f;

    // Filters
    float dcX1 = 0.0f;
    float dcY1 = 0.0f;
    float dcR = 0.9992f;

    float airAlpha = 0.5f;
    float airState = 0.0f;

    // Dynamic Cathode Bias, Grid Sag & B+ Sag
    float cathodeBiasState = 0.0f;
    float gridSagState = 0.0f;
    float millerState = 0.0f;
    float bPlusSagState = 0.0f;

    float alphaCathodeAtt = 0.002f;
    float alphaCathodeRel = 0.0005f;
    float alphaGridAtt = 0.015f;
    float alphaGridRel = 0.0003f;
    float alphaBPlusAtt = 0.002f;
    float alphaBPlusRel = 0.0003f;
};

using FlagshipTubeSaturator = FlagshipTubeSaturator171;

} // namespace dsp171
