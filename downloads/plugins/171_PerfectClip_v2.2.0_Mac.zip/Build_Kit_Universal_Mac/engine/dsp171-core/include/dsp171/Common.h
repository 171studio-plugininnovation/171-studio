#pragma once
#include <cmath>
#include <algorithm>
#include <numbers>

namespace dsp171 {

// Costanti matematiche standard
inline constexpr float PI = 3.14159265358979323846f;
inline constexpr double PI_D = 3.14159265358979323846;

// Protezione denormali e zeri
inline constexpr float DENORMAL_EPSILON = 1.0e-15f;

// Conversione veloce dB -> lineare con clamp di sicurezza (-144 dB a +60 dB)
inline float dbToGain(float dB) noexcept {
    if (!std::isfinite(dB) || dB <= -144.0f) return 0.0f;
    if (dB >= 60.0f) return 1000.0f;
    return std::pow(10.0f, dB * 0.05f);
}

// Conversione veloce lineare -> dB con continuità C0 a -144 dBFS (dinamica studio mastering 24-bit)
inline float gainToDb(float gain) noexcept {
    if (!std::isfinite(gain) || gain <= 6.3095734e-8f) return -144.0f;
    return 20.0f * std::log10(gain);
}

// Approssimazione razionale veloce di tanh(x) di Pade per hot loops DSP (errore relativo ~2.1% tra -3 e +3)
// Calcolo di precisione analitica di tanh(x) C-infinito continuo privo di discontinuità armoniche
inline float fastTanh(float x) noexcept {
    return std::tanh(x);
}

} // namespace dsp171
