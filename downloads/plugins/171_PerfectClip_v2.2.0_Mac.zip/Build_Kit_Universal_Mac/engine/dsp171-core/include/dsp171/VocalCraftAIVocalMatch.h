#pragma once

#include <cmath>
#include <algorithm>
#include <atomic>
#include <array>
#include <cstdint>
#include <cassert>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include <dsp171/ZDFSVF.h>

namespace dsp171 {

// =============================================================================
// 171 Studio Innovatio - AI Vocal Match Profiler & Target Reconfiguration Matrix
// 171 VocalCraft 3.0 "The Sovereign Vocal Engine" - Phase 4
//
// Key Mathematical & Algorithmic Foundations:
// 1. Online Welford Algorithm with Zero Dynamic Allocations:
//    - Streaming running calculation of sample mean mu_n, variance sigma_n^2,
//      continuous RMS, peak, and dynamic Crest Factor C_n = x_peak / RMS.
//    - Accumulates energy bands across 20 Hz - 20 kHz:
//      * Sub (20 - 90 Hz): Sub-rumble, plosives, proximity effect.
//      * Low-Mid (200 - 800 Hz): Chest resonance and Formant F1.
//      * Formant Mid (800 - 2400 Hz): Vowel articulation and Formant F2.
//      * Presence (2400 - 3800 Hz): Epilaryngeal singer's formant F3.
//      * Sibilance (5500 - 9000 Hz): Fricatives and sibilants.
//      * Air (10 - 20 kHz): Sheen, breath, and open top-end.
//
// 2. Regularized Mahalanobis Distance Classifier:
//    - 8-Dimensional feature vector:
//      x = [x1: SubRatio, x2: F1_Hz, x3: F2_Hz, x4: F3_Hz,
//           x5: AirRatio, x6: CrestDb, x7: SibRatio, x8: Flatness]^T
//    - Regularized Mahalanobis distance to 6 studio target acoustic profiles:
//      D_M^2(x, mu_k) = sum_{j=1}^8 (x_j - mu_{k,j})^2 / (sigma_{k,j}^2 + lambda)
//      with lambda = 1e-4 for guaranteed unconditional positive-definiteness.
//    - Softmax probability ensemble:
//      w_k = exp(-gamma * D_M^2) / sum_j exp(-gamma * D_M^2),  gamma = 0.5
//
// 3. Continuous 50 ms Slew-Rate Limiter (Anti-Click Transitions):
//    - C^1-smooth exponential slew on all DSP control parameters:
//      P[n] = P[n-1] + alpha_slew * (P_target - P[n-1]),  tau_slew = 50 ms
//    - Eliminates audible clicks, pops, or limiter pumping when applying match.
//
// 4. 2D Circular Phonetic Radar Barycentric Projection:
//    - Normalized coordinate mapping (x_phon, y_phon) in [-1, 1] x [-1, 1]:
//      x_phon = w_Sibilant - w_Consonant
//      y_phon = w_Vowel - w_Pause
//    - Closed-form polar representation (r, theta) for 60 FPS PBR CRT displays.
// =============================================================================

// The 6 Reference Studio Target Vocal Profiles
enum class TargetVocalProfile : uint32_t {
    BillboardTrapLead  = 0,
    TrapDrillLead      = 0, // Semantic alias

    DrillAggressive    = 1,

    HyperpopCrystalAir = 2,
    PopRadioPristine   = 2, // Semantic alias

    MelodicRnB         = 3,
    RnBSilkModern      = 3, // Semantic alias

    Warm70sSoul        = 4,
    VintageTubeRock    = 4, // Semantic alias
    AcousticSongwriter = 4, // Semantic alias

    PodcastBroadcast   = 5,
    BroadcastVoice     = 5  // Semantic alias
};

// 8-Dimensional Extracted Acoustic Feature Vector
struct AcousticFeatures8D {
    float subRatio = 0.015f;  // x1: Sub-Rumble Ratio (20 - 90 Hz vs Total) [0.0, 1.0]
    union { float formantF1Hz = 480.0f; float formantF1; };  // x2: Formant Centroid F1 (200 - 800 Hz)
    union { float formantF2Hz = 1750.0f; float formantF2; }; // x3: Formant Centroid F2 (800 - 2400 Hz)
    union { float formantF3Hz = 3400.0f; float formantF3; }; // x4: Formant Centroid F3 (2400 - 3800 Hz)
    union { float airSheenRatio = 0.180f; float airRatio; }; // x5: Air Sheen Energy Ratio (10 - 18 kHz) [0.0, 1.0]
    union { float dynamicCrestDb = 3.80f; float crestFactorNorm; }; // x6: Dynamic Crest Factor in dB [2.0, 14.0 dB]
    float sibilanceRatio = 0.160f;  // x7: High-Frequency Sibilance Ratio (5.5 - 9.0 kHz) [0.0, 1.0]
    union { float spectralFlatness = 0.220f; float harmonicityIndex; }; // x8: Spectral Flatness / Harmonicity Index [0.0, 1.0]

    // Backward compatibility helper
    float subRatioNorm() const noexcept { return subRatio; }
};

// Target DSP Control Parameters
struct VocalMatchParameters {
    float hpfSubCutoffHz      = 70.0f;   // High-pass filter cutoff [20.0, 120.0] Hz
    float linearizerDepth     = 0.65f;   // 64-band spectral linearizer depth [0.0, 1.0]
    float linearizerResoMask  = 0.85f;   // Formant resonance mask sensitivity [0.0, 1.0]
    float compRatio           = 7.0f;    // Dynamic compressor ratio [1.5:1, 12.0:1]
    float compAttackMs        = 10.0f;   // Dynamic compressor attack [1.0, 50.0] ms
    float compReleaseMs       = 45.0f;   // Dynamic compressor release [20.0, 500.0] ms
    int   hardwareMojoModel   = 1;       // 0: Modern Pure, 1: 1073 Iron, 2: Blue FET 1176, 3: Tube CL1B
    float hardwareMojoDriveDb = 7.5f;    // Hardware saturation drive [0.0, 18.0] dB
    float hilbertStereoSpread = 0.18f;   // Mono-safe Hilbert side gain [0.0, 1.0]
    float hilbertSideHpfHz    = 250.0f;  // Side channel mono-recovery HPF cutoff [80.0, 400.0] Hz
    float deessCenterFreqHz   = 6400.0f; // Sibilance center frequency [4000.0, 10000.0] Hz
    float deessDepthDb        = -7.5f;   // Pre-drive de-esser max attenuation [-15.0, 0.0] dB
    float airSheenBoostDb     = 4.0f;    // 12 kHz air sheen boost [-4.0, +8.0] dB
    float plosiveAnnihilatorDb= 6.5f;    // Smart plosive suppression boost [0.0, 12.0] dB
    float neuralDeBreatherDb  = -8.5f;   // Neural de-breather threshold cut [-14.0, 0.0] dB
    float adaaClipperCeilingDb= -0.12f;  // ADAA-2 clipper safety threshold [-1.0, 0.0] dBFS
    float targetLufs          = -10.5f;  // Perceptual loudness anchor [-18.0, -7.0] LUFS

    // Normalized / General Purpose Aliases
    float compAmount          = 0.60f;
    float consonantPunchDb    = 0.0f;
    float airSheen            = 0.50f;
    float deessAmount         = 0.50f;
    float clipperDrive        = 0.30f;
    float plosiveSuppression  = 0.80f;
    float deBreatherAmount    = 0.60f;
    float mojoDrive           = 0.35f;
    float hilbertWidth        = 1.20f;
};

// 2D Circular Phonetic Radar Barycentric Coordinates
struct PhoneticRadarCoords {
    float x = 0.0f;      // x = w_Sibilant - w_Consonant in [-1.0, 1.0]
    float y = 0.0f;      // y = w_Vowel - w_Pause in [-1.0, 1.0]
    float radius = 0.0f; // r = sqrt(x^2 + y^2) in [0.0, 1.0]
    float angle = 0.0f;  // theta = atan2(y, x) in [-pi, pi]
};

// =============================================================================
// Class VocalCraftAIVocalMatch
// =============================================================================
class VocalCraftAIVocalMatch {
public:
    static constexpr size_t kNumTargets = 6;
    static constexpr size_t kNumFeatures = 8;
    static constexpr float  kLambda = 1.0e-4f; // Regularization factor for positive definiteness

    VocalCraftAIVocalMatch() noexcept {
        initTargetDatabase();
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = (sampleRate > 8000.0) ? sampleRate : 48000.0;
        invSr = 1.0 / sr;

        // Bandpass / High-pass filterbank for 8-D feature extraction
        lpfSub.setParameters(90.0f, 0.7071f, static_cast<float>(sr));      // 20 - 90 Hz
        bpLow.setParameters(400.0f, 0.7071f, static_cast<float>(sr));      // 200 - 800 Hz (F1)
        bpMid.setParameters(1600.0f, 0.6f, static_cast<float>(sr));        // 800 - 2400 Hz (F2)
        bpPresence.setParameters(3100.0f, 0.7f, static_cast<float>(sr));   // 2400 - 3800 Hz (F3)
        bpSib.setParameters(6800.0f, 0.7071f, static_cast<float>(sr));     // 5500 - 9000 Hz
        hpfAir.setParameters(10000.0f, 0.7071f, static_cast<float>(sr));   // 10 - 20 kHz

        // 50 ms Slew Rate Limiter: alpha = 1 - exp(-1 / (fs * 0.050))
        slewCoeff50ms = static_cast<float>(1.0 - std::exp(-1.0 / (0.0500 * sr)));
        // 30 ms Phonetic Radar Smoothing
        radarSmoothCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.0300 * sr)));

        targetCalibrationSamples = static_cast<uint64_t>(std::round(3.0 * sr)); // 3.0 seconds

        reset();
    }

    void reset() noexcept {
        lpfSub.reset();
        bpLow.reset();
        bpMid.reset();
        bpPresence.reset();
        bpSib.reset();
        hpfAir.reset();

        // Reset Welford statistical accumulators
        welfordCount = 0;
        welfordMean = 0.0;
        welfordM2 = 0.0;
        welfordPeak = 0.0f;
        sumEnergyTotal = 0.0;
        sumEnergySub = 0.0;
        sumEnergyLow = 0.0;
        sumEnergyMid = 0.0;
        sumEnergyPres = 0.0;
        sumEnergySib = 0.0;
        sumEnergyAir = 0.0;

        isListeningFlag = false;
        isProfileReadyFlag = false;
        calibrationProgress = 0.0f;
        analyzedSampleCount = 0;

        smoothedRadarX = 0.0f;
        smoothedRadarY = 0.0f;

        currentParams = defaultParams;
        targetParams = defaultParams;
    }

    // --- Control API ---
    void startListening(TargetVocalProfile targetProfile = TargetVocalProfile::BillboardTrapLead) noexcept {
        selectedTarget = targetProfile;
        isListeningFlag = true;
        isProfileReadyFlag = false;
        calibrationProgress = 0.0f;
        analyzedSampleCount = 0;

        // Reset Welford accumulators for fresh 3-second window
        welfordCount = 0;
        welfordMean = 0.0;
        welfordM2 = 0.0;
        welfordPeak = 0.0f;
        sumEnergyTotal = 0.0;
        sumEnergySub = 0.0;
        sumEnergyLow = 0.0;
        sumEnergyMid = 0.0;
        sumEnergyPres = 0.0;
        sumEnergySib = 0.0;
        sumEnergyAir = 0.0;
    }

    void cancelListening() noexcept {
        isListeningFlag = false;
        calibrationProgress = 0.0f;
    }

    bool isListening() const noexcept {
        return isListeningFlag;
    }

    bool isProfileReady() const noexcept {
        return isProfileReadyFlag;
    }

    float getCalibrationProgress() const noexcept {
        return calibrationProgress;
    }

    TargetVocalProfile getSelectedTarget() const noexcept {
        return selectedTarget;
    }

    TargetVocalProfile getDetectedProfile() const noexcept {
        return detectedProfile;
    }

    AcousticFeatures8D getExtractedFeatures() const noexcept {
        return latestFeatures;
    }

    // --- Real-Time Block Processing ---
    void processBlock(const float* left, const float* right, int numSamples) noexcept {
        if (numSamples <= 0 || left == nullptr) return;

        // 1. Feature Extraction & Welford Accumulation during listening window
        if (isListeningFlag) {
            for (int i = 0; i < numSamples; ++i) {
                const float sL = left[i];
                const float sR = (right != nullptr) ? right[i] : sL;
                const float mono = 0.5f * (sL + sR);
                const float absMono = std::abs(mono);

                // Welford's algorithm for numerically stable mean and variance
                ++welfordCount;
                const double delta = static_cast<double>(mono) - welfordMean;
                welfordMean += delta / static_cast<double>(welfordCount);
                const double delta2 = static_cast<double>(mono) - welfordMean;
                welfordM2 += delta * delta2;

                welfordPeak = std::max(welfordPeak, absMono);

                // Energy band decomposition
                const double monoSq = static_cast<double>(mono) * mono;
                sumEnergyTotal += monoSq;

                const float vSub = lpfSub.processBP(mono);
                sumEnergySub += static_cast<double>(vSub) * vSub;

                const float vLow = bpLow.processBP(mono);
                sumEnergyLow += static_cast<double>(vLow) * vLow;

                const float vMid = bpMid.processBP(mono);
                sumEnergyMid += static_cast<double>(vMid) * vMid;

                const float vPres = bpPresence.processBP(mono);
                sumEnergyPres += static_cast<double>(vPres) * vPres;

                const float vSib = bpSib.processBP(mono);
                sumEnergySib += static_cast<double>(vSib) * vSib;

                const auto outAir = hpfAir.process(mono);
                const float vAir = outAir.hp;
                sumEnergyAir += static_cast<double>(vAir) * vAir;
            }

            analyzedSampleCount += static_cast<uint64_t>(numSamples);
            calibrationProgress = std::clamp(
                static_cast<float>(analyzedSampleCount) / static_cast<float>(targetCalibrationSamples),
                0.0f, 1.0f);

            // Reached completion of 3-second window: compute match parameters!
            if (analyzedSampleCount >= targetCalibrationSamples) {
                finalizeProfiling();
            }
        }

        // 2. Real-Time Instantaneous Phonetic Radar Tracking
        computePhoneticRadar(left, right, numSamples);

        // 3. Continuous 50 ms Slew-Rate Limiter (Interpolates smoothly toward target parameters)
        applySlewRateLimiter(numSamples);
    }

    // Access current slew-smoothed parameters for driving downstream DSP
    const VocalMatchParameters& getCurrentParameters() const noexcept {
        return currentParams;
    }

    PhoneticRadarCoords getPhoneticRadar() const noexcept {
        PhoneticRadarCoords coords;
        coords.x = smoothedRadarX;
        coords.y = smoothedRadarY;
        coords.radius = std::sqrt(std::min(1.0f, coords.x * coords.x + coords.y * coords.y));
        coords.angle = std::atan2(coords.y, coords.x);
        return coords;
    }

    // Expose Mahalanobis distance calculation for unit testing & metrological validation
    float computeMahalanobisDistance(const AcousticFeatures8D& feats, TargetVocalProfile target) const noexcept {
        const size_t k = static_cast<size_t>(target);
        if (k >= kNumTargets) return 0.0f;

        const auto& mean = targetMeans[k];
        const auto& varInv = targetVarianceInv[k];

        const float featArr[kNumFeatures] = {
            feats.subRatio,
            feats.formantF1Hz,
            feats.formantF2Hz,
            feats.formantF3Hz,
            feats.airSheenRatio,
            feats.dynamicCrestDb,
            feats.sibilanceRatio,
            feats.spectralFlatness
        };

        float distSq = 0.0f;
        for (size_t j = 0; j < kNumFeatures; ++j) {
            const float diff = featArr[j] - mean[j];
            distSq += diff * diff * varInv[j];
        }
        return distSq;
    }

    TargetVocalProfile classifyAcousticFeatures(const AcousticFeatures8D& feats) const noexcept {
        float minDistance = 1.0e12f;
        TargetVocalProfile bestProfile = TargetVocalProfile::BillboardTrapLead;

        for (size_t k = 0; k < kNumTargets; ++k) {
            const float d = computeMahalanobisDistance(feats, static_cast<TargetVocalProfile>(k));
            if (d < minDistance) {
                minDistance = d;
                bestProfile = static_cast<TargetVocalProfile>(k);
            }
        }
        return bestProfile;
    }

    // Public setter for target profile to trigger instant re-profiling
    void setTargetProfile(TargetVocalProfile profile) noexcept {
        selectedTarget = profile;
        targetParams = targetPresets[static_cast<size_t>(selectedTarget)];
    }

    // Directly set target parameters (useful for unit tests and instant override)
    void setTargetParameters(const VocalMatchParameters& params) noexcept {
        targetParams = params;
    }

    void setCurrentParametersImmediate(const VocalMatchParameters& params) noexcept {
        currentParams = params;
        targetParams = params;
    }

private:
    void initTargetDatabase() noexcept {
        // =========================================================================
        // Metrological Target Vectors mu_k and Variance Inverses 1 / (sigma^2 + lambda)
        // From METROLOGIA_ACUSTICA_FASE4_AI_PROFILER_6_TARGET.md
        // Features: [Sub, F1_Hz, F2_Hz, F3_Hz, Air, CrestDb, Sib, Flatness]
        // =========================================================================

        // TARGET 0: Modern Billboard Trap Lead
        // mu_0: [0.015, 480.0, 1750.0, 3400.0, 0.180, 3.80, 0.160, 0.220]
        // sigmas: [0.005, 45.0, 90.0, 120.0, 0.030, 0.50, 0.025, 0.040]
        targetMeans[0] = { 0.015f, 480.0f, 1750.0f, 3400.0f, 0.180f, 3.80f, 0.160f, 0.220f };
        setVarianceInverses(0, { 0.005f, 45.0f, 90.0f, 120.0f, 0.030f, 0.50f, 0.025f, 0.040f });

        // TARGET 1: Drill Aggressive & Raw
        // mu_1: [0.035, 320.0, 1450.0, 3100.0, 0.090, 4.50, 0.120, 0.280]
        // sigmas: [0.008, 40.0, 85.0, 110.0, 0.020, 0.60, 0.020, 0.050]
        targetMeans[1] = { 0.035f, 320.0f, 1450.0f, 3100.0f, 0.090f, 4.50f, 0.120f, 0.280f };
        setVarianceInverses(1, { 0.008f, 40.0f, 85.0f, 110.0f, 0.020f, 0.60f, 0.020f, 0.050f });

        // TARGET 2: Hyperpop Crystal Air
        // mu_2: [0.005, 620.0, 2150.0, 3600.0, 0.320, 2.90, 0.210, 0.380]
        // sigmas: [0.002, 50.0, 100.0, 130.0, 0.040, 0.40, 0.030, 0.060]
        targetMeans[2] = { 0.005f, 620.0f, 2150.0f, 3600.0f, 0.320f, 2.90f, 0.210f, 0.380f };
        setVarianceInverses(2, { 0.002f, 50.0f, 100.0f, 130.0f, 0.040f, 0.40f, 0.030f, 0.060f });

        // TARGET 3: Melodic R&B Intimacy
        // mu_3: [0.025, 380.0, 1550.0, 2850.0, 0.150, 7.80, 0.095, 0.120]
        // sigmas: [0.006, 35.0, 70.0, 90.0, 0.025, 0.80, 0.015, 0.025]
        targetMeans[3] = { 0.025f, 380.0f, 1550.0f, 2850.0f, 0.150f, 7.80f, 0.095f, 0.120f };
        setVarianceInverses(3, { 0.006f, 35.0f, 70.0f, 90.0f, 0.025f, 0.80f, 0.015f, 0.025f });

        // TARGET 4: Warm 70s Soul Vocal
        // mu_4: [0.030, 340.0, 1350.0, 2700.0, 0.045, 6.60, 0.075, 0.140]
        // sigmas: [0.007, 35.0, 75.0, 95.0, 0.012, 0.70, 0.015, 0.030]
        targetMeans[4] = { 0.030f, 340.0f, 1350.0f, 2700.0f, 0.045f, 6.60f, 0.075f, 0.140f };
        setVarianceInverses(4, { 0.007f, 35.0f, 75.0f, 95.0f, 0.012f, 0.70f, 0.015f, 0.030f });

        // TARGET 5: Podcast / Voiceover Broadcast
        // mu_5: [0.010, 290.0, 1600.0, 3250.0, 0.080, 4.80, 0.110, 0.210]
        // sigmas: [0.003, 30.0, 65.0, 80.0, 0.018, 0.50, 0.018, 0.035]
        targetMeans[5] = { 0.010f, 290.0f, 1600.0f, 3250.0f, 0.080f, 4.80f, 0.110f, 0.210f };
        setVarianceInverses(5, { 0.003f, 30.0f, 65.0f, 80.0f, 0.018f, 0.50f, 0.018f, 0.035f });

        // =========================================================================
        // Target Reference DSP Control Configurations
        // =========================================================================

        // 0: Billboard Trap
        targetPresets[0] = {
            70.0f, 0.65f, 0.85f, 7.0f, 10.0f, 45.0f, 1, 7.5f, 0.18f, 250.0f,
            6400.0f, -7.5f, 4.0f, 6.5f, -8.5f, -0.12f, -10.5f,
            0.75f, 2.5f, 0.75f, 0.65f, 0.50f, 0.85f, 0.70f, 0.45f, 1.18f
        };

        // 1: Drill Aggressive
        targetPresets[1] = {
            58.0f, 0.45f, 0.60f, 5.0f, 5.0f, 35.0f, 2, 9.5f, 0.08f, 300.0f,
            5800.0f, -6.0f, 1.8f, 6.5f, -6.5f, -0.08f, -9.5f,
            0.85f, 4.0f, 0.45f, 0.55f, 0.65f, 0.90f, 0.50f, 0.60f, 1.08f
        };

        // 2: Hyperpop Crystal Air
        targetPresets[2] = {
            100.0f, 0.80f, 0.95f, 10.0f, 3.0f, 25.0f, 0, 3.0f, 0.55f, 180.0f,
            7600.0f, -8.5f, 6.5f, 4.5f, -10.0f, -0.05f, -8.0f,
            0.90f, 1.0f, 0.90f, 0.85f, 0.40f, 0.70f, 0.85f, 0.20f, 1.55f
        };

        // 3: Melodic R&B
        targetPresets[3] = {
            42.0f, 0.35f, 0.40f, 2.8f, 25.0f, 180.0f, 3, 4.0f, 0.32f, 160.0f,
            6800.0f, -4.5f, 3.0f, 4.5f, -5.5f, -0.25f, -14.0f,
            0.50f, 0.5f, 0.60f, 0.40f, 0.25f, 0.60f, 0.45f, 0.30f, 1.32f
        };

        // 4: Warm 70s Soul
        targetPresets[4] = {
            48.0f, 0.25f, 0.30f, 3.5f, 20.0f, 320.0f, 1, 7.0f, 0.05f, 200.0f,
            6200.0f, -3.0f, -2.5f, 6.5f, -4.0f, -0.30f, -15.0f,
            0.55f, 0.0f, 0.30f, 0.35f, 0.35f, 0.70f, 0.35f, 0.45f, 1.05f
        };

        // 5: Podcast / Broadcast
        targetPresets[5] = {
            75.0f, 0.55f, 0.75f, 4.2f, 12.0f, 85.0f, 0, 2.0f, 0.00f, 200.0f,
            5800.0f, -6.5f, 1.5f, 7.0f, -9.0f, -0.50f, -16.0f,
            0.70f, 3.0f, 0.40f, 0.60f, 0.15f, 0.95f, 0.80f, 0.10f, 1.00f
        };

        defaultParams = targetPresets[0]; // Anchor on Modern Trap
        currentParams = defaultParams;
        targetParams = defaultParams;
    }

    void setVarianceInverses(size_t targetIndex, const std::array<float, kNumFeatures>& sigmas) noexcept {
        for (size_t j = 0; j < kNumFeatures; ++j) {
            const float s = sigmas[j];
            // Regularization with lambda = 1e-4 prevents any singularity or division by zero
            targetVarianceInv[targetIndex][j] = 1.0f / (s * s + kLambda);
        }
    }

    void finalizeProfiling() noexcept {
        isListeningFlag = false;
        isProfileReadyFlag = true;

        if (welfordCount == 0 || sumEnergyTotal <= 1.0e-9) {
            targetParams = targetPresets[static_cast<size_t>(selectedTarget)];
            detectedProfile = selectedTarget;
            return;
        }

        const double invTotal = 1.0 / (sumEnergyTotal + 1.0e-9);
        const float subRatio = static_cast<float>(std::clamp(sumEnergySub * invTotal, 0.0, 1.0));
        const float lowRatio = static_cast<float>(std::clamp(sumEnergyLow * invTotal, 0.0, 1.0));
        const float midRatio = static_cast<float>(std::clamp(sumEnergyMid * invTotal, 0.0, 1.0));
        const float presRatio = static_cast<float>(std::clamp(sumEnergyPres * invTotal, 0.0, 1.0));
        const float sibRatio = static_cast<float>(std::clamp(sumEnergySib * invTotal, 0.0, 1.0));
        const float airRatio = static_cast<float>(std::clamp(sumEnergyAir * invTotal, 0.0, 1.0));

        // RMS & Crest Factor in dB
        const double rmsLinear = std::sqrt(sumEnergyTotal / static_cast<double>(welfordCount));
        const float crestLinear = static_cast<float>(welfordPeak / std::max(1.0e-6, rmsLinear));
        const float crestDb = std::clamp(gainToDb(crestLinear), 2.0f, 14.0f);

        // Formant centroids estimation in Hz
        const float f1 = 200.0f + 600.0f * (midRatio / (lowRatio + midRatio + 1.0e-6f));
        const float f2 = 800.0f + 1600.0f * (midRatio / (midRatio + presRatio + 1.0e-6f));
        const float f3 = 2400.0f + 1400.0f * (presRatio / (presRatio + airRatio + 1.0e-6f));

        // Spectral Flatness / Wiener entropy approximation from variance vs mean energy
        const double variance = (welfordCount > 1) ? (welfordM2 / (welfordCount - 1)) : 0.0;
        const float flatness = std::clamp(static_cast<float>(variance / (rmsLinear * rmsLinear + 1.0e-6)), 0.05f, 0.95f);

        latestFeatures.subRatio = subRatio;
        latestFeatures.formantF1Hz = f1;
        latestFeatures.formantF2Hz = f2;
        latestFeatures.formantF3Hz = f3;
        latestFeatures.airSheenRatio = airRatio;
        latestFeatures.dynamicCrestDb = crestDb;
        latestFeatures.sibilanceRatio = sibRatio;
        latestFeatures.spectralFlatness = flatness;

        // Classify the incoming voice
        detectedProfile = classifyAcousticFeatures(latestFeatures);

        // Softmax ensemble weights across the 6 targets
        // w_k = exp(-0.5 * D_M^2) / sum exp(-0.5 * D_M^2)
        float dists[kNumTargets];
        float maxNegDist = -1.0e9f;
        for (size_t k = 0; k < kNumTargets; ++k) {
            dists[k] = computeMahalanobisDistance(latestFeatures, static_cast<TargetVocalProfile>(k));
            maxNegDist = std::max(maxNegDist, -0.5f * dists[k]);
        }

        float sumExp = 0.0f;
        float weights[kNumTargets];
        for (size_t k = 0; k < kNumTargets; ++k) {
            weights[k] = std::exp(-0.5f * dists[k] - maxNegDist);
            sumExp += weights[k];
        }
        const float invSumExp = 1.0f / (sumExp + 1.0e-6f);
        for (size_t k = 0; k < kNumTargets; ++k) {
            weights[k] *= invSumExp;
        }

        // Anchor on selected target and blend fine adaptions
        const auto& base = targetPresets[static_cast<size_t>(selectedTarget)];
        targetParams = base;

        // Adaptive fine trims based on extracted acoustic deficiency:
        // 1. Dynamic Crest adjustment: if singer's crest factor is higher than target, increase compRatio
        const float targetCrest = targetMeans[static_cast<size_t>(selectedTarget)][5];
        const float crestDelta = crestDb - targetCrest;
        targetParams.compRatio = std::clamp(base.compRatio + crestDelta * 0.35f, 1.5f, 12.0f);

        // 2. Air Sheen deficiency boost: if air ratio is low, lift airSheenBoostDb
        const float targetAir = targetMeans[static_cast<size_t>(selectedTarget)][4];
        const float airDelta = targetAir - airRatio;
        targetParams.airSheenBoostDb = std::clamp(base.airSheenBoostDb + airDelta * 12.0f, -4.0f, +8.0f);

        // 3. Sibilance excess de-essing
        targetParams.deessDepthDb = std::clamp(base.deessDepthDb - (sibRatio - 0.15f) * 15.0f, -15.0f, 0.0f);

        // 4. Sub-rumble HPF trim
        targetParams.hpfSubCutoffHz = std::clamp(base.hpfSubCutoffHz + (subRatio - 0.02f) * 600.0f, 30.0f, 120.0f);
    }

    void computePhoneticRadar(const float* left, const float* right, int numSamples) noexcept {
        float instEnergy = 0.0f;
        float sibEnergy = 0.0f;
        float presEnergy = 0.0f;

        for (int i = 0; i < numSamples; ++i) {
            const float sL = left[i];
            const float sR = (right != nullptr) ? right[i] : sL;
            const float mono = 0.5f * (sL + sR);
            instEnergy += mono * mono;

            const float vSib = bpSib.processBP(mono);
            sibEnergy += vSib * vSib;

            const float vPres = bpPresence.processBP(mono);
            presEnergy += vPres * vPres;
        }

        const float invN = 1.0f / static_cast<float>(numSamples);
        const float rms = std::sqrt(instEnergy * invN);
        const float rmsDb = gainToDb(rms);

        // Normalized 4-D Phonetic Weights:
        // w_Vowel (Voice), w_Consonant (Punch), w_Sibilant (Fricative), w_Pause (Silence)
        float wV = 0.0f, wC = 0.0f, wS = 0.0f, wP = 0.0f;

        if (rmsDb < -48.0f) {
            wP = 1.0f; // Silence / pause
        } else {
            const float sibRatio = std::sqrt(sibEnergy * invN) / (rms + 1.0e-6f);
            const float presRatio = std::sqrt(presEnergy * invN) / (rms + 1.0e-6f);

            if (sibRatio > 0.45f) {
                wS = std::clamp(sibRatio, 0.5f, 1.0f);
                wV = 1.0f - wS;
            } else if (presRatio > 0.50f) {
                wC = std::clamp(presRatio, 0.5f, 1.0f);
                wV = 1.0f - wC;
            } else {
                wV = 0.90f;
                wC = 0.10f;
            }
        }

        // Barycentric Radar Projection:
        // x_phon = w_Sibilant - w_Consonant  [-1, +1]
        // y_phon = w_Vowel - w_Pause         [-1, +1]
        const float targetX = wS - wC;
        const float targetY = wV - wP;

        // Block-rate invariant smoothing for tau = 30 ms
        const float blockRadarCoeff = 1.0f - std::exp(-static_cast<float>(numSamples) / (0.0300f * static_cast<float>(sr)));
        smoothedRadarX += blockRadarCoeff * (targetX - smoothedRadarX);
        smoothedRadarY += blockRadarCoeff * (targetY - smoothedRadarY);
    }

    void applySlewRateLimiter(int numSamples) noexcept {
        // Continuous C^1 exponential slew: beta = 1 - (1 - alpha)^numSamples
        const float decayFactor = std::pow(1.0f - slewCoeff50ms, static_cast<float>(numSamples));
        const float beta = 1.0f - decayFactor;

        currentParams.hpfSubCutoffHz      += beta * (targetParams.hpfSubCutoffHz - currentParams.hpfSubCutoffHz);
        currentParams.linearizerDepth     += beta * (targetParams.linearizerDepth - currentParams.linearizerDepth);
        currentParams.linearizerResoMask  += beta * (targetParams.linearizerResoMask - currentParams.linearizerResoMask);
        currentParams.compRatio           += beta * (targetParams.compRatio - currentParams.compRatio);
        currentParams.compAttackMs        += beta * (targetParams.compAttackMs - currentParams.compAttackMs);
        currentParams.compReleaseMs       += beta * (targetParams.compReleaseMs - currentParams.compReleaseMs);
        currentParams.hardwareMojoDriveDb += beta * (targetParams.hardwareMojoDriveDb - currentParams.hardwareMojoDriveDb);
        currentParams.hilbertStereoSpread += beta * (targetParams.hilbertStereoSpread - currentParams.hilbertStereoSpread);
        currentParams.hilbertSideHpfHz    += beta * (targetParams.hilbertSideHpfHz - currentParams.hilbertSideHpfHz);
        currentParams.deessCenterFreqHz   += beta * (targetParams.deessCenterFreqHz - currentParams.deessCenterFreqHz);
        currentParams.deessDepthDb        += beta * (targetParams.deessDepthDb - currentParams.deessDepthDb);
        currentParams.airSheenBoostDb     += beta * (targetParams.airSheenBoostDb - currentParams.airSheenBoostDb);
        currentParams.plosiveAnnihilatorDb+= beta * (targetParams.plosiveAnnihilatorDb - currentParams.plosiveAnnihilatorDb);
        currentParams.neuralDeBreatherDb  += beta * (targetParams.neuralDeBreatherDb - currentParams.neuralDeBreatherDb);
        currentParams.adaaClipperCeilingDb+= beta * (targetParams.adaaClipperCeilingDb - currentParams.adaaClipperCeilingDb);
        currentParams.targetLufs          += beta * (targetParams.targetLufs - currentParams.targetLufs);

        // General purpose / normalized aliases
        currentParams.compAmount          += beta * (targetParams.compAmount - currentParams.compAmount);
        currentParams.consonantPunchDb    += beta * (targetParams.consonantPunchDb - currentParams.consonantPunchDb);
        currentParams.airSheen            += beta * (targetParams.airSheen - currentParams.airSheen);
        currentParams.deessAmount         += beta * (targetParams.deessAmount - currentParams.deessAmount);
        currentParams.clipperDrive        += beta * (targetParams.clipperDrive - currentParams.clipperDrive);
        currentParams.plosiveSuppression  += beta * (targetParams.plosiveSuppression - currentParams.plosiveSuppression);
        currentParams.deBreatherAmount    += beta * (targetParams.deBreatherAmount - currentParams.deBreatherAmount);
        currentParams.mojoDrive           += beta * (targetParams.mojoDrive - currentParams.mojoDrive);
        currentParams.hilbertWidth        += beta * (targetParams.hilbertWidth - currentParams.hilbertWidth);

        // Discrete model switch
        currentParams.hardwareMojoModel = targetParams.hardwareMojoModel;
    }

private:
    double sr = 48000.0;
    double invSr = 1.0 / 48000.0;

    // Filters for feature extraction
    ZDFSVF64 lpfSub{};
    ZDFSVF64 bpLow{};
    ZDFSVF64 bpMid{};
    ZDFSVF64 bpPresence{};
    ZDFSVF64 bpSib{};
    ZDFSVF64 hpfAir{};

    // Slew rate coefficients
    float slewCoeff50ms = 0.0f;
    float radarSmoothCoeff = 0.0f;

    // Calibration state
    bool isListeningFlag = false;
    bool isProfileReadyFlag = false;
    float calibrationProgress = 0.0f;
    uint64_t analyzedSampleCount = 0;
    uint64_t targetCalibrationSamples = 144000;
    TargetVocalProfile selectedTarget = TargetVocalProfile::BillboardTrapLead;
    TargetVocalProfile detectedProfile = TargetVocalProfile::BillboardTrapLead;

    // Welford running statistics
    uint64_t welfordCount = 0;
    double   welfordMean = 0.0;
    double   welfordM2 = 0.0;
    float    welfordPeak = 0.0f;
    double   sumEnergyTotal = 0.0;
    double   sumEnergySub = 0.0;
    double   sumEnergyLow = 0.0;
    double   sumEnergyMid = 0.0;
    double   sumEnergyPres = 0.0;
    double   sumEnergySib = 0.0;
    double   sumEnergyAir = 0.0;

    // 2D Radar Smoothed Coordinates
    float smoothedRadarX = 0.0f;
    float smoothedRadarY = 0.0f;

    // Extracted Features
    AcousticFeatures8D latestFeatures{};

    // Target Database: 6 profiles x 8 features
    std::array<std::array<float, kNumFeatures>, kNumTargets> targetMeans{};
    std::array<std::array<float, kNumFeatures>, kNumTargets> targetVarianceInv{};
    std::array<VocalMatchParameters, kNumTargets> targetPresets{};

    VocalMatchParameters defaultParams{};
    VocalMatchParameters currentParams{};
    VocalMatchParameters targetParams{};
};

} // namespace dsp171
