#pragma once

#include <cmath>
#include <algorithm>
#include "Common.h"
#include "DCBlocker.h"
#include "FastMath.h"

namespace dsp171 {

// =============================================================================
// Module: AvalonTubeSaturator
// Orchestrated by: Lead Analog Circuit & DSP Physicist (171 Studio Innovatio)
//
// Physical simulation of the Avalon VT-737sp high-voltage Class-A vacuum tube:
// 1. Dual Triodes (6922 / 12AX7) with High-Voltage Class-A Topology (B+ >= 150V Plate):
//    - Authentic Child-Langmuir law non-linear plate current equation: Ip ~ (Vp/mu + Vg)^1.5
//    - Dominant musical second harmonic (H2) warmth without harsh odd harmonics.
//    - Soft grid-leak current conduction for Vgk > 0 eliminating digital harshness.
//    - Dynamic Miller capacitance effect (transconductance gm-dependent HF softening).
//    - Dynamic B+ power rail sag under heavy drive (natural headroom breathing).
// 2. High-Voltage Headroom:
//    - Ultra-wide dynamic range, soft triode compression knee, C1-continuous at origin.
// 3. Avalon 32 kHz Air Sheen Network:
//    - Gentle passive shelving boost lifting high air presence from 10 kHz to 32 kHz.
// =============================================================================

class AvalonTubeSaturator {
public:
    AvalonTubeSaturator() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        dcBlocker.prepare(sampleRate, 10.0f);

        // Air filter pole (~16 kHz base for 32 kHz shelf transition)
        constexpr float fcAir = 16000.0f;
        airAlpha = std::clamp(2.0f * PI * fcAir / sr, 0.01f, 0.95f);

        // Dynamic Cathode Bias Shift (R_k || C_k network, tau_charge ~ 8 ms, tau_decay ~ 50 ms)
        alphaCathodeAtt = 1.0f - std::exp(-1.0f / (0.008f * sr));
        alphaCathodeRel = 1.0f - std::exp(-1.0f / (0.050f * sr));

        // Grid-leak coupling capacitor sag (tau_charge ~ 1.2 ms, tau_decay ~ 110 ms)
        alphaGridAtt = 1.0f - std::exp(-1.0f / (0.0012f * sr));
        alphaGridRel = 1.0f - std::exp(-1.0f / (0.1100f * sr));

        // Dynamic B+ power rail sag constants (tau_att ~ 35 ms, tau_rel ~ 220 ms)
        alphaBPlusAtt = 1.0f - std::exp(-1.0f / (0.035f * sr));
        alphaBPlusRel = 1.0f - std::exp(-1.0f / (0.220f * sr));

        reset();
    }

    void reset() noexcept {
        dcBlocker.reset();
        airState = 0.0f;
        gridCapState = 0.0f;
        cathodeBiasState = 0.0f;
        millerState = 0.0f;
        bPlusSagState = 0.0f;
    }

    [[nodiscard]] float getBPlusSag() const noexcept {
        return bPlusSagState;
    }

    // Process a single sample through high-voltage Class-A triode
    inline float processSample(float in, float driveDb, float warmth01 = 0.5f, float airDb = 0.0f) noexcept {
        if (!std::isfinite(in)) return 0.0f;

        const float driveGain = dbToGain(driveDb);
        const float x = in * driveGain;

        // 1. Dual-Triode Class-A Plate Non-Linearity (Physical Child-Langmuir & Koren Curve)
        // With dynamic cathode auto-bias shift & grid conduction sag:
        const float w = std::clamp(warmth01, 0.0f, 1.0f);
        
        // Effective instantaneous grid-to-cathode operating voltage:
        const float vOperating = x - cathodeBiasState - gridCapState;

        // Physical cathode current surge charging R_k || C_k:
        const float cathodeSurge = (vOperating > 0.0f) ? (0.26f * vOperating + 0.10f * w * (vOperating * vOperating)) : 0.0f;
        if (cathodeSurge > cathodeBiasState) {
            cathodeBiasState += alphaCathodeAtt * (cathodeSurge - cathodeBiasState);
        } else {
            cathodeBiasState += alphaCathodeRel * (cathodeSurge - cathodeBiasState);
        }

        // Grid-leak diode conduction when swinging positive beyond forward barrier (~0.65V):
        if (vOperating > 0.65f) {
            const float iGrid = 0.32f * (vOperating - 0.65f);
            gridCapState += alphaGridAtt * (iGrid - gridCapState);
        } else {
            gridCapState += alphaGridRel * (0.0f - gridCapState);
        }

        FastMath::flushDenormals(cathodeBiasState);
        FastMath::flushDenormals(gridCapState);

        // Effective tube drive with cold-clipping bias shift:
        float vGrid = x - cathodeBiasState - gridCapState;
        if (vGrid > 0.70f) {
            // Grid-leak diode conduction: soft logarithmic flattening
            vGrid = 0.70f + 0.35f * std::tanh((vGrid - 0.70f) * 1.4f);
        }

        // Dynamic B+ Power Rail Sag:
        // Plate current surges under heavy drive, pulling down B+ rail voltage
        const float iPlate = (vGrid > 0.0f) ? (0.25f * vGrid + 0.10f * w * (vGrid * vGrid)) : (0.03f * std::abs(vGrid));
        const float targetBPlusSag = std::clamp(iPlate * 0.22f, 0.0f, 0.35f);
        if (targetBPlusSag > bPlusSagState) {
            bPlusSagState += alphaBPlusAtt * (targetBPlusSag - bPlusSagState);
        } else {
            bPlusSagState += alphaBPlusRel * (0.0f - bPlusSagState);
        }
        FastMath::flushDenormals(bPlusSagState);

        // Effective rail headroom factor
        const float vBPlusEff = 1.0f - 0.25f * bPlusSagState;

        float tubeOut;
        if (vGrid >= 0.0f) {
            // Positive grid swing: Child-Langmuir 3/2 power curve compression knee (dominant H2)
            const float kPos = 0.18f + 0.14f * w;
            tubeOut = vGrid / (1.0f + kPos * vGrid + 0.04f * w * (vGrid * vGrid));
        } else {
            // Negative plate swing: extended high-voltage headroom with cold cutoff knee
            const float kNeg = 0.16f + 0.08f * w;
            const float absV = -vGrid;
            tubeOut = vGrid / (1.0f + kNeg * absV + 0.02f * (absV * absV));
        }

        // Headroom modulated by B+ power rail dynamic sag
        tubeOut *= vBPlusEff;

        // Dynamic Miller Capacitance HF Roll-off (C_Miller = C_ga * (1 + |Av(t)|)):
        // Transconductance gm increases under positive drive, dynamically softening harsh transients
        const float fcMiller = 32000.0f / (1.0f + 0.85f * std::max(0.0f, vGrid));
        const float alphaMiller = std::clamp(2.0f * PI * fcMiller / sr, 0.05f, 0.95f);
        millerState += alphaMiller * (tubeOut - millerState);
        FastMath::flushDenormals(millerState);
        tubeOut = millerState;

        // 2. Avalon 32 kHz Air Sheen Filter
        float out = tubeOut;
        if (airDb > 0.01f) {
            const float airGain = dbToGain(airDb);
            airState += airAlpha * (tubeOut - airState);
            FastMath::flushDenormals(airState);
            out = airState + (tubeOut - airState) * airGain;
        }

        // 3. Output DC Decoupling
        return dcBlocker.processSample(out);
    }

private:
    float sr = 44100.0f;
    float airAlpha = 0.5f;
    float airState = 0.0f;
    float gridCapState = 0.0f;
    float cathodeBiasState = 0.0f;
    float alphaCathodeAtt = 0.002f;
    float alphaCathodeRel = 0.0004f;
    float alphaGridAtt = 0.015f;
    float alphaGridRel = 0.0002f;
    float millerState = 0.0f;
    float bPlusSagState = 0.0f;
    float alphaBPlusAtt = 0.002f;
    float alphaBPlusRel = 0.0003f;
    DCBlocker dcBlocker;
};

} // namespace dsp171
