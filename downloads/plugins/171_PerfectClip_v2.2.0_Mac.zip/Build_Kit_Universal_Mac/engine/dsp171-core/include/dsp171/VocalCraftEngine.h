#pragma once
#include <cmath>
#include <algorithm>
#include <atomic>
#include <array>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include <dsp171/SafetyCeiling.h>
#include <dsp171/VocalCraftGainStager.h>
#include <dsp171/VocalCraftSpectralAnalyzer.h>
#include <dsp171/VocalCraftSpectralLinearizer.h>
#include <dsp171/VocalCraftConsonantDetector.h>
#include <dsp171/VocalCraftAdaptiveCompressor.h>
#include <dsp171/VocalCraftBeatUnmasker.h>
#include <dsp171/VocalCraftClipper.h>
#include <dsp171/VocalCraftLoudnessCompensator.h>
#include <dsp171/VocalCraftNeuralBrain.h>
#include <dsp171/VocalCraftPlosiveAnnihilator.h>
#include <dsp171/VocalCraftDeBreather.h>
#include <dsp171/VocalCraftHardwareColoration.h>
#include <dsp171/VocalCraftHilbertStereo.h>
#include <dsp171/VocalCraftClusterSync.h>
#include <dsp171/VocalCraftAIVocalMatch.h>
#include <dsp171/VocalCraftSpectralHeatmap.h>

namespace dsp171 {

// =============================================================================
// 171 VocalCraft - Unified Real-Time DSP Engine
//
// End-to-end intelligent vocal channel:
// 1. Smart Gain Stager (ITU-R BS.1770 / RMS Auto-Calibrator to -18 dBFS)
// 2. Full-Spectrum 2048-Point Peak & Resonance Analyzer
// 3. 64-Band Adaptive Spectral Linearizer (Flattening toward Ideal Studio Target)
// 4. AI Phoneme & Consonant Punch-Through Detector (Lyric articulation protection)
// 5. Style-Conditioned Adaptive Dynamic Compressor (Hip-Hop, Pop, Trap, R&B)
// 6. Perceptual Real-Time Auto-Makeup Gain (Loudness-Matched Output)
// 7. AI Beat Triangulator: Frequency & Volume Dynamic Pocket Carving + Vocal Riding
// 8. Mix-Ready Downstream Primer: Pre-Drive De-Esser & 12 kHz Air Sheen
// 9. Mastering-Grade ADAA-2 Vocal Soft Clipper (Micro-transient shaving & RMS punch)
// 10. Analog Safety Brickwall Ceiling (-0.09 dBFS)
// =============================================================================
class VocalCraftEngine {
public:
    struct Telemetry {
        float inputRmsDb = -90.0f;
        float outputRmsDb = -90.0f;
        float gainReductionDb = 0.0f;
        float consonantActivity = 0.0f;
        float autoTrimDb = 0.0f;
        float autoMakeupDb = 0.0f;
        bool  isCalibrating = false;
        bool  isLocked = false;

        // Exhaustive Full-Spectrum Analysis Data for 60 FPS Visualizer
        int activePeakCount = 0;
        size_t numTrackedPeaks = 0;
        std::array<VocalCraftSpectralAnalyzer::DetectedPeak, 16> trackedPeaks{};
        std::array<float, VocalCraftSpectralLinearizer::kNumBands> bandReductionsDb{};
        std::array<float, VocalCraftSpectralLinearizer::kNumBands> bandCenterFreqs{};
        std::array<float, VocalCraftSpectralLinearizer::kNumBands> bandTargetNeutralDb{};

        // Beat Sidechain, Triangulation & Mix-Ready Downstream Primer Telemetry
        bool  isBeatSidechainConnected = false;
        bool  isTriangulating = false;
        float triangulationVolumeRideDb = 0.0f;
        float deesserGainReductionDb = 0.0f;
        float unmaskActivityDb = 0.0f;
        std::array<float, VocalCraftSpectralLinearizer::kNumBands> clashMaskingDb{};
        std::array<float, VocalCraftSpectralLinearizer::kNumBands> unmaskBoostsDb{};

        // Mastering-Grade Vocal Soft Clipper Telemetry
        float clipperGainReductionDb = 0.0f;

        // Predictive Lookahead & Host PDC Telemetry
        bool  isLookaheadActive = false;
        int   latencySamples = 0;

        // 171 VocalCraft Neural Brain Deep Learning Telemetry
        bool  isNeuralBrainActive = false;
        int   neuralPhonemeClass = 0;
        float neuralPredictedRatio = 4.0f;
        float neuralConsonantPunch = 0.0f;
        float neuralResonanceMask = 0.0f;
        float neuralDeessDepthDb = 0.0f;
        float neuralBeatCarveDb = 0.0f;
        float neuralAirSheenBoostDb = 0.0f;
        float neuralDynamicFaderRideDb = 0.0f;
        float neuralInferenceTimeUs = 0.0f;
        uint64_t neuralInferenceCount = 0;

        // Phase 1 Micro-Acoustics & Biological Cleaning Telemetry
        float plosiveBlastActivity = 0.0f;
        float plosiveCutoffHz = 28.0f;
        float plosiveAttenDb = 0.0f;
        float debreatherConfidence = 0.0f;
        float debreatherGain = 1.0f;
        float debreatherAttenDb = 0.0f;

        // Phase 2 Hardware Mojo & Mono-Safe Hilbert Stereo Telemetry
        int   mojoActiveModel = 0;
        float mojoDriveDb = 0.0f;
        float mojoThdPercent = 0.0f;
        float hilbertStereoWidth = 1.0f;
        float hilbertCorrelation = 1.0f;
        float hilbertMonoNullResidualDb = -140.0f;

        // Phase 3 Multi-Track Vocal Cluster Telemetry
        int   clusterRole = 0;
        int   clusterChannel = 1;
        bool  clusterLeadActive = false;
        float clusterLeadRmsDb = -90.0f;
        float clusterPocketCutDb = 0.0f;
        float clusterTightenReductionDb = 0.0f;
        float clusterPocketFcHz = 2200.0f;

        // Phase 4 AI Vocal Match & Curves Equator 3D Heatmap Telemetry
        bool  vocalMatchListening = false;
        bool  vocalMatchReady = false;
        float vocalMatchProgress = 0.0f;
        int   vocalMatchTarget = 0;
        int   vocalMatchDetected = 0;
        float radarX = 0.0f;
        float radarY = 0.0f;
        float radarRadius = 0.0f;
        float radarAngle = 0.0f;
        uint64_t heatmapFramesTotal = 0;
    };

    void prepare(double sampleRate, int maxBlockSize) noexcept {
        sr = sampleRate > 0.0 ? sampleRate : 44100.0;
        blockSize = maxBlockSize > 0 ? maxBlockSize : 512;

        gainStager.prepare(sr);
        spectralAnalyzer.prepare(sr);
        linearizerL.prepare(sr);
        linearizerR.prepare(sr);
        consonantDetector.prepare(sr);
        compressor.prepare(sr);
        beatUnmasker.prepare(sr);
        clipper.prepare(sr);
        loudnessCompL.prepare(sr);
        loudnessCompR.prepare(sr);
        neuralBrain.prepare(sr);
        plosiveAnnihilator.prepare(static_cast<float>(sr));
        deBreather.prepare(static_cast<float>(sr));
        hardwareColoration.prepare(sr);
        hilbertStereo.prepare(sr);
        clusterSync.prepare(sr);
        vocalMatch.prepare(sr);
        spectralHeatmap.prepare(sr);

        lookaheadSamples = isStudioMixMode ? static_cast<int>(std::round(sr * 0.005)) : 0;
        lookaheadRingL.fill(0.0f);
        lookaheadRingR.fill(0.0f);
        lookaheadWritePos = 0;

        reset();
    }

    void reset() noexcept {
        gainStager.reset();
        spectralAnalyzer.reset();
        linearizerL.reset();
        linearizerR.reset();
        consonantDetector.reset();
        compressor.reset();
        beatUnmasker.reset();
        clipper.reset();
        loudnessCompL.reset();
        loudnessCompR.reset();
        neuralBrain.reset();
        plosiveAnnihilator.reset();
        deBreather.reset();
        hardwareColoration.reset();
        hilbertStereo.reset();
        clusterSync.reset();
        vocalMatch.reset();
        spectralHeatmap.reset();

        lookaheadRingL.fill(0.0f);
        lookaheadRingR.fill(0.0f);
        lookaheadWritePos = 0;

        inRmsSmoothed = 0.0001f;
        outRmsSmoothed = 0.0001f;
    }

    // --- Control API ---
    void setLookaheadMode(bool studioMixMode) noexcept {
        isStudioMixMode = studioMixMode;
        lookaheadSamples = studioMixMode ? static_cast<int>(std::round(sr * 0.005)) : 0;
    }

    [[nodiscard]] bool isLookaheadMode() const noexcept {
        return isStudioMixMode;
    }

    [[nodiscard]] int getLatencySamples() const noexcept {
        return lookaheadSamples;
    }
    void setStyle(int styleIndex) noexcept {
        currentStyleIndex = std::clamp(styleIndex, 0, 3);
        auto style = static_cast<VocalCraftAdaptiveCompressor::Style>(currentStyleIndex);
        compressor.setStyle(style);
        consonantDetector.setStyle(currentStyleIndex);
    }

    void setCompressionAmount(float amount0To1) noexcept {
        compressor.setCompressionAmount(amount0To1);
    }

    void setLinearizerDepth(float depth0To1) noexcept {
        linearizerL.setLinearizerDepth(depth0To1);
        linearizerR.setLinearizerDepth(depth0To1);
    }

    void setConsonantPunch(float trimDb) noexcept {
        compressor.setConsonantPunchOverride(trimDb);
    }

    void setUnmaskAmount(float amount0To1) noexcept {
        beatUnmasker.setUnmaskAmount(amount0To1);
    }

    void setAirSheen(float amount0To1) noexcept {
        beatUnmasker.setAirSheen(amount0To1);
    }

    void setDeessAmount(float amount0To1) noexcept {
        beatUnmasker.setDeessAmount(amount0To1);
    }

    void setClipperDrive(float amount0To1) noexcept {
        clipper.setClipperDrive(amount0To1);
    }

    void triggerCalibration() noexcept {
        gainStager.startCalibration();
    }

    void setManualTrimDb(float trimDb) noexcept {
        gainStager.setManualTrimDb(trimDb);
    }

    void setAutoMakeupEnabled(bool enabled) noexcept {
        loudnessCompL.setAutoMakeupEnabled(enabled);
        loudnessCompR.setAutoMakeupEnabled(enabled);
    }

    void setPlosiveParameters(float amount, float sensitivityDb = 0.0f, bool enabled = true) noexcept {
        plosiveAnnihilator.setParameters(amount, sensitivityDb, enabled);
    }

    void setPlosiveListenDelta(bool listen) noexcept {
        plosiveAnnihilator.setListenDelta(listen);
    }

    void setDeBreatherParameters(float amount, float reductionDb = -7.5f, bool enabled = true) noexcept {
        deBreather.setParameters(amount, reductionDb, enabled);
    }

    void setDeBreatherListenDelta(bool listen) noexcept {
        deBreather.setListenDelta(listen);
    }

    void setHardwareMojoModel(int modelIdx) noexcept {
        hardwareColoration.setModel(static_cast<VocalCraftHardwareColoration::MojoModel>(std::clamp(modelIdx, 0, 3)));
    }

    void setHardwareMojoDrive(float drive0To1) noexcept {
        hardwareColoration.setDrive(drive0To1);
    }

    void setHardwareMojoMix(float mix0To1) noexcept {
        hardwareColoration.setMix(mix0To1);
    }

    void setHilbertStereoWidth(float width0To2) noexcept {
        hilbertStereo.setWidth(width0To2);
    }

    void setHilbertSideHpf(float sideHpfHz) noexcept {
        hilbertStereo.setSideHpf(sideHpfHz);
    }

    // Phase 3 Multi-Track Vocal Cluster Control API
    void setClusterRole(ClusterRole role) noexcept { clusterSync.setRole(role); }
    void setClusterChannel(int ch) noexcept { clusterSync.setClusterChannel(ch); }
    void setClusterGroupId(int grp) noexcept { clusterSync.setClusterGroupId(grp); }
    void setClusterPocketDepthDb(float depthDb) noexcept { clusterSync.setPocketDepthDb(depthDb); }
    void setClusterTighten(float tighten0To1) noexcept { clusterSync.setClusterTighten(tighten0To1); }
    void setTimelineSamplePosition(uint64_t samplePos) noexcept { currentDawTimelineSample = samplePos; }
    VocalCraftClusterSync& getClusterSync() noexcept { return clusterSync; }
    const VocalCraftClusterSync& getClusterSync() const noexcept { return clusterSync; }

    // Phase 4 AI Vocal Match & Curves Equator 3D Heatmap Control API
    void startVocalMatch(TargetVocalProfile target = TargetVocalProfile::BillboardTrapLead) noexcept {
        vocalMatch.startListening(target);
        isVocalMatchActive = true;
    }
    void cancelVocalMatch() noexcept {
        vocalMatch.cancelListening();
    }
    bool isVocalMatchListening() const noexcept {
        return vocalMatch.isListening();
    }
    bool isVocalMatchReady() const noexcept {
        return vocalMatch.isProfileReady();
    }
    float getVocalMatchProgress() const noexcept {
        return vocalMatch.getCalibrationProgress();
    }
    TargetVocalProfile getSelectedVocalTarget() const noexcept {
        return vocalMatch.getSelectedTarget();
    }
    TargetVocalProfile getDetectedVocalProfile() const noexcept {
        return vocalMatch.getDetectedProfile();
    }
    PhoneticRadarCoords getPhoneticRadar() const noexcept {
        return vocalMatch.getPhoneticRadar();
    }
    const VocalCraftSpectralHeatmap& getSpectralHeatmap() const noexcept {
        return spectralHeatmap;
    }
    void getSpectralHeatmapSnapshot(float outMatrix[32][64]) const noexcept {
        spectralHeatmap.getWaterfallSnapshot(outMatrix);
    }
    VocalCraftAIVocalMatch& getVocalMatch() noexcept {
        return vocalMatch;
    }
    const VocalCraftAIVocalMatch& getVocalMatch() const noexcept {
        return vocalMatch;
    }

    void setBypass(bool bypass) noexcept {
        isBypassed = bypass;
    }

    // --- Audio Block Processing with External Sidechain Beat Ingestion ---
    void processWithBeat(float* const* channelData, int numChannels,
                         const float* const* beatData, int beatChannels,
                         int numSamples) noexcept
    {
        if (numSamples <= 0 || channelData == nullptr || numChannels <= 0)
            return;

        float* left = channelData[0];
        float* right = (numChannels > 1 && channelData[1] != nullptr) ? channelData[1] : nullptr;

        const float* beatL = (beatData != nullptr && beatChannels > 0) ? beatData[0] : nullptr;
        const float* beatR = (beatData != nullptr && beatChannels > 1) ? beatData[1] : beatL;

        if (isBypassed) return;

        // 0. Stage 0: Neural Brain Analysis & Real-Time Deep Learning Inference (< 0.05 ms latency)
        neuralBrain.analyzeAndInfer(left, right, beatL, beatR, numSamples, currentStyleIndex);

        // 0a. Stage 0a: Phase 4 AI Vocal Match Feature Extraction & Parameter Slew
        vocalMatch.processBlock(left, right, numSamples);
        if (isVocalMatchActive) {
            const auto& vp = vocalMatch.getCurrentParameters();
            linearizerL.setLinearizerDepth(vp.linearizerDepth);
            if (right != nullptr) linearizerR.setLinearizerDepth(vp.linearizerDepth);
            hardwareColoration.setModel(static_cast<VocalCraftHardwareColoration::MojoModel>(vp.hardwareMojoModel));
            hardwareColoration.setDriveDb(vp.hardwareMojoDriveDb);
            hilbertStereo.setWidth(vp.hilbertStereoSpread);
            hilbertStereo.setSideHpf(vp.hilbertSideHpfHz);
        }

        const float neuralRatio = neuralBrain.getPredictedCompRatio();
        const float neuralPunch = neuralBrain.getDynamicConsonantPunch();
        const float neuralResoMask = neuralBrain.getAcousticResonanceMask();
        const float neuralDeessOffsetDb = neuralBrain.getDeesserThresholdOffsetDb();
        const float neuralDeessDepthDb = neuralBrain.getDeesserDepthDb();
        const float neuralBeatCarveDb = neuralBrain.getBeatPocketCarveDb();
        const float neuralAirBoostDb = neuralBrain.getAirSheenBoostDb();
        const float neuralFaderRideDb = neuralBrain.getDynamicFaderRideDb();

        // Feed intelligent neural guidance into downstream DSP modules
        linearizerL.setResonanceMask(neuralResoMask);
        if (right != nullptr)
            linearizerR.setResonanceMask(neuralResoMask);

        compressor.setNeuralRatio(neuralRatio);

        beatUnmasker.setNeuralGuidance(neuralDeessOffsetDb, neuralDeessDepthDb,
                                      neuralBeatCarveDb, neuralAirBoostDb, neuralFaderRideDb);

        // 1. Stage 1: Automatic Gain Staging (Input Calibration to -18 dBFS)
        if (right != nullptr) {
            gainStager.processStereo(left, right, numSamples);
        } else {
            gainStager.process(left, numSamples);
        }

        // Push input into Full-Spectrum 2048-Point Peak Analyzer FIFO
        spectralAnalyzer.pushBlock(left, static_cast<size_t>(numSamples));

        // Predictive Lookahead Circular Delay Buffer (Studio Mastering / Mix Mode)
        if (lookaheadSamples > 0) {
            if (right != nullptr) {
                for (int i = 0; i < numSamples; ++i) {
                    float sL = left[i];
                    float sR = right[i];
                    if (std::abs(sL) < 1.0e-25f) sL = 0.0f;
                    if (std::abs(sR) < 1.0e-25f) sR = 0.0f;

                    lookaheadRingL[lookaheadWritePos] = sL;
                    lookaheadRingR[lookaheadWritePos] = sR;

                    const size_t readPos = (lookaheadWritePos + kLookaheadCapacity - static_cast<size_t>(lookaheadSamples)) & kLookaheadMask;
                    left[i]  = lookaheadRingL[readPos];
                    right[i] = lookaheadRingR[readPos];

                    lookaheadWritePos = (lookaheadWritePos + 1) & kLookaheadMask;
                }
            } else {
                for (int i = 0; i < numSamples; ++i) {
                    float sL = left[i];
                    if (std::abs(sL) < 1.0e-25f) sL = 0.0f;

                    lookaheadRingL[lookaheadWritePos] = sL;

                    const size_t readPos = (lookaheadWritePos + kLookaheadCapacity - static_cast<size_t>(lookaheadSamples)) & kLookaheadMask;
                    left[i] = lookaheadRingL[readPos];

                    lookaheadWritePos = (lookaheadWritePos + 1) & kLookaheadMask;
                }
            }
        }

        // 1b. Stage 1b: Smart Plosive Annihilator (Sub-120 Hz Dynamic Boom Annihilation)
        if (right != nullptr) {
            for (int i = 0; i < numSamples; ++i) {
                plosiveAnnihilator.processStereo(left[i], right[i]);
            }
        } else {
            for (int i = 0; i < numSamples; ++i) {
                left[i] = plosiveAnnihilator.processSample(left[i]);
            }
        }

        // 1c. Stage 1c: Neural De-Breather Organico (C1 Inhalation Breath Attenuation)
        if (right != nullptr) {
            for (int i = 0; i < numSamples; ++i) {
                deBreather.processStereo(left[i], right[i]);
            }
        } else {
            for (int i = 0; i < numSamples; ++i) {
                left[i] = deBreather.processSample(left[i]);
            }
        }

        float blockInEnergy = 0.0f;
        float blockOutEnergy = 0.0f;

        if (right != nullptr) {
            for (int i = 0; i < numSamples; ++i) {
                const float rawL = left[i];
                const float rawR = right[i];
                const float monoIn = 0.5f * (rawL + rawR);
                blockInEnergy += monoIn * monoIn;

                // 2. Stage 2: 64-Band Full-Spectrum Adaptive Linearizer (Neutralization EQ)
                float linL = linearizerL.processSample(rawL);
                float linR = linearizerR.processSample(rawR);
                const float monoLin = 0.5f * (linL + linR);

                // 3. Stage 3: AI Consonant & Phoneme Transient Detector
                const float rawConsonant = consonantDetector.processSample(monoLin);
                const float consonantWeight = std::clamp(rawConsonant + 0.35f * neuralPunch, 0.0f, 1.0f);

                // 4. Stage 4: Style-Conditioned Adaptive Compressor (Consonant Punch-Through)
                float compL = linL;
                float compR = linR;
                compressor.processStereo(compL, compR, consonantWeight);

                // 5. Stage 5: Perceptual Auto-Makeup Gain (Loudness Matching)
                left[i] = loudnessCompL.processSample(linL, compL);
                right[i] = loudnessCompR.processSample(linR, compR);
            }
        } else {
            for (int i = 0; i < numSamples; ++i) {
                const float rawL = left[i];
                blockInEnergy += rawL * rawL;

                float linL = linearizerL.processSample(rawL);
                const float rawConsonant = consonantDetector.processSample(linL);
                const float consonantWeight = std::clamp(rawConsonant + 0.35f * neuralPunch, 0.0f, 1.0f);

                float compL = compressor.processSample(linL, consonantWeight);
                left[i] = loudnessCompL.processSample(linL, compL);
            }
        }

        // 6. Stage 6 & 7: AI Beat Triangulation (Dynamic Frequency Pocket + Dynamic Volume Riding)
        // & Mix-Ready Downstream Primer (Pre-Drive De-Esser & 12 kHz Air Sheen)
        beatUnmasker.process(left, right, beatL, beatR, numSamples);

        // 7a. Stage 7a: Multi-Track Vocal Cluster Synchronizer (Lead Broadcast / Satellite Pocketing & Anti-Flam)
        clusterSync.processStereo(left, right, numSamples, currentDawTimelineSample);
        currentDawTimelineSample += static_cast<uint64_t>(numSamples);

        // 7b. Stage 7b: Hardware Mojo Coloration Engine (Neve 1073 Iron, 1176 Blue FET, CL1B Tube, Modern Pure)
        if (right != nullptr) {
            for (int i = 0; i < numSamples; ++i) {
                hardwareColoration.processStereo(left[i], right[i]);
            }
        } else {
            for (int i = 0; i < numSamples; ++i) {
                left[i] = hardwareColoration.processSample(left[i]);
            }
        }

        // 7c. Stage 7c: Mono-Safe Hilbert Stereo Dimensionalizer (100% Mono Null Safe, Sub 160 Hz Protection)
        if (right != nullptr) {
            for (int i = 0; i < numSamples; ++i) {
                hilbertStereo.processStereo(left[i], right[i]);
            }
        } else {
            for (int i = 0; i < numSamples; ++i) {
                float rDummy = left[i];
                hilbertStereo.processStereo(left[i], rDummy);
            }
        }

        // 8 & 9. Stage 8 & 9: Mastering-Grade Vocal ADAA-2 Soft Clipper & Analog Safety Brickwall Ceiling
        if (right != nullptr) {
            for (int i = 0; i < numSamples; ++i) {
                clipper.processStereo(left[i], right[i]);
                left[i] = applySafetyCeiling(left[i]);
                right[i] = applySafetyCeiling(right[i]);
                const float monoOut = 0.5f * (left[i] + right[i]);
                blockOutEnergy += monoOut * monoOut;
            }
        } else {
            for (int i = 0; i < numSamples; ++i) {
                left[i] = clipper.processSample(left[i]);
                left[i] = applySafetyCeiling(left[i]);
                blockOutEnergy += left[i] * left[i];
            }
        }

        // Smooth RMS calculation
        const float inRmsBlock = std::sqrt(blockInEnergy / static_cast<float>(numSamples));
        const float outRmsBlock = std::sqrt(blockOutEnergy / static_cast<float>(numSamples));
        inRmsSmoothed += (inRmsBlock - inRmsSmoothed) * 0.15f;
        outRmsSmoothed += (outRmsBlock - outRmsSmoothed) * 0.15f;

        // Push 64-band resonance reduction & beat unmasking to Curves Equator 3D Heatmap
        const auto linReductions = linearizerL.getBandReductionsDb();
        const auto unmaskBoosts = beatUnmasker.getUnmaskBoostsDb();
        spectralHeatmap.pushResonanceFrame(linReductions.data(), unmaskBoosts.data());
    }

    void process(float* const* channelData, int numChannels, int numSamples) noexcept {
        processWithBeat(channelData, numChannels, nullptr, 0, numSamples);
    }

    // Lock-free atomic GUI telemetry retrieval
    Telemetry getTelemetrySnapshot() const noexcept {
        // Trigger 2048-point peak analysis on demand (GUI thread 60 Hz) rather than audio thread
        spectralAnalyzer.analyzeSpectrum(2.5f);

        Telemetry t;
        t.inputRmsDb = 20.0f * std::log10(std::max(1e-5f, inRmsSmoothed));
        t.outputRmsDb = 20.0f * std::log10(std::max(1e-5f, outRmsSmoothed));
        t.gainReductionDb = compressor.getGainReductionDb();
        t.consonantActivity = consonantDetector.getConsonantActivity();
        t.autoTrimDb = gainStager.getCurrentTrimDb();
        t.autoMakeupDb = loudnessCompL.getAutoMakeupDb();
        t.isCalibrating = gainStager.isCalibrating();
        t.isLocked = gainStager.isLocked();

        // Full-spectrum telemetry
        t.activePeakCount = linearizerL.getActivePeakCount();
        t.bandReductionsDb = linearizerL.getBandReductionsDb();

        const auto& configs = linearizerL.getBandConfigs();
        for (size_t b = 0; b < VocalCraftSpectralLinearizer::kNumBands; ++b) {
            t.bandCenterFreqs[b] = configs[b].centerFreqHz;
            t.bandTargetNeutralDb[b] = configs[b].targetNeutralDb;
        }

        const size_t totalPeaks = spectralAnalyzer.getNumDetectedPeaks();
        const auto& detected = spectralAnalyzer.getDetectedPeaks();
        t.numTrackedPeaks = std::min(static_cast<size_t>(16), totalPeaks);
        for (size_t i = 0; i < t.numTrackedPeaks; ++i) {
            t.trackedPeaks[i] = detected[i];
        }

        // Beat Sidechain, Triangulation & Mix-Ready Telemetry
        t.isBeatSidechainConnected = beatUnmasker.isBeatSidechainConnected();
        t.isTriangulating = beatUnmasker.isTriangulating();
        t.triangulationVolumeRideDb = beatUnmasker.getTriangulationVolumeRideDb();
        t.deesserGainReductionDb = beatUnmasker.getDeesserGainReductionDb();
        t.unmaskActivityDb = beatUnmasker.getUnmaskActivityDb();
        t.clashMaskingDb = beatUnmasker.getClashMaskingDb();
        t.unmaskBoostsDb = beatUnmasker.getUnmaskBoostsDb();

        // Vocal Soft Clipper Telemetry
        t.clipperGainReductionDb = clipper.getGainReductionDb();

        // Predictive Lookahead & Host PDC Telemetry
        t.isLookaheadActive = (lookaheadSamples > 0);
        t.latencySamples = lookaheadSamples;

        // 171 VocalCraft Neural Brain Deep Learning Telemetry Snapshot
        const auto nSnap = neuralBrain.getTelemetrySnapshot();
        t.isNeuralBrainActive = (nSnap.inferenceCount > 0);
        t.neuralPhonemeClass = nSnap.phonemeClass;
        t.neuralPredictedRatio = nSnap.predictedCompRatio;
        t.neuralConsonantPunch = nSnap.dynamicConsonantPunch;
        t.neuralResonanceMask = nSnap.acousticResonanceMask;
        t.neuralDeessDepthDb = nSnap.deesserDepthDb;
        t.neuralBeatCarveDb = nSnap.beatPocketCarveDb;
        t.neuralAirSheenBoostDb = nSnap.airSheenBoostDb;
        t.neuralDynamicFaderRideDb = nSnap.dynamicFaderRideDb;
        t.neuralInferenceTimeUs = nSnap.lastInferenceTimeUs;
        t.neuralInferenceCount = nSnap.inferenceCount;

        // Phase 1 Micro-Acoustics & Biological Cleaning Telemetry
        t.plosiveBlastActivity = plosiveAnnihilator.getBlastActivity();
        t.plosiveCutoffHz = plosiveAnnihilator.getCurrentCutoff();
        t.plosiveAttenDb = plosiveAnnihilator.getLastAttenDb();
        t.debreatherConfidence = deBreather.getBreathConfidence();
        t.debreatherGain = deBreather.getCurrentGain();
        t.debreatherAttenDb = deBreather.getLastAttenDb();

        // Phase 2 Hardware Mojo & Mono-Safe Hilbert Stereo Telemetry
        const auto mojoSnap = hardwareColoration.getTelemetrySnapshot();
        t.mojoActiveModel = static_cast<int>(mojoSnap.activeModel);
        t.mojoDriveDb = mojoSnap.driveDb;
        t.mojoThdPercent = mojoSnap.thdPercent;

        const auto hilbertSnap = hilbertStereo.getTelemetrySnapshot();
        t.hilbertStereoWidth = hilbertSnap.stereoWidth;
        t.hilbertCorrelation = hilbertSnap.correlation;
        t.hilbertMonoNullResidualDb = hilbertSnap.monoNullResidualDb;

        // Phase 3 Multi-Track Vocal Cluster Telemetry
        const auto clusterSnap = clusterSync.getTelemetry();
        t.clusterRole = static_cast<int>(clusterSnap.role);
        t.clusterChannel = clusterSnap.clusterChannel;
        t.clusterLeadActive = clusterSnap.isLeadActive;
        t.clusterLeadRmsDb = clusterSnap.leadRmsDb;
        t.clusterPocketCutDb = clusterSnap.currentPocketCutDb;
        t.clusterTightenReductionDb = clusterSnap.tightenReductionDb;
        t.clusterPocketFcHz = clusterSnap.leadPresenceCentroidHz;

        // Phase 4 AI Vocal Match & Curves Equator 3D Heatmap Telemetry Snapshot
        t.vocalMatchListening = vocalMatch.isListening();
        t.vocalMatchReady = vocalMatch.isProfileReady();
        t.vocalMatchProgress = vocalMatch.getCalibrationProgress();
        t.vocalMatchTarget = static_cast<int>(vocalMatch.getSelectedTarget());
        t.vocalMatchDetected = static_cast<int>(vocalMatch.getDetectedProfile());
        const auto radar = vocalMatch.getPhoneticRadar();
        t.radarX = radar.x;
        t.radarY = radar.y;
        t.radarRadius = radar.radius;
        t.radarAngle = radar.angle;
        t.heatmapFramesTotal = spectralHeatmap.getTotalFramesPushed();

        return t;
    }

    VocalCraftNeuralBrain& getNeuralBrain() noexcept { return neuralBrain; }
    const VocalCraftNeuralBrain& getNeuralBrain() const noexcept { return neuralBrain; }

private:
    double sr = 44100.0;
    int blockSize = 512;
    bool isBypassed = false;
    int currentStyleIndex = 0;

    float inRmsSmoothed = 0.0001f;
    float outRmsSmoothed = 0.0001f;

    VocalCraftGainStager          gainStager;
    mutable VocalCraftSpectralAnalyzer spectralAnalyzer;
    VocalCraftNeuralBrain         neuralBrain;
    VocalCraftPlosiveAnnihilator  plosiveAnnihilator;
    VocalCraftDeBreather          deBreather;
    VocalCraftHardwareColoration  hardwareColoration;
    VocalCraftHilbertStereo       hilbertStereo;
    VocalCraftClusterSync         clusterSync;
    uint64_t                      currentDawTimelineSample = 0;
    VocalCraftSpectralLinearizer  linearizerL;
    VocalCraftSpectralLinearizer  linearizerR;
    VocalCraftConsonantDetector   consonantDetector;
    VocalCraftAdaptiveCompressor  compressor;
    VocalCraftBeatUnmasker        beatUnmasker;
    VocalCraftClipper             clipper;
    VocalCraftLoudnessCompensator loudnessCompL;
    VocalCraftLoudnessCompensator loudnessCompR;

    // Phase 4 AI Vocal Match & Curves Equator 3D Heatmap
    VocalCraftAIVocalMatch        vocalMatch;
    VocalCraftSpectralHeatmap     spectralHeatmap;
    bool                          isVocalMatchActive = false;

    // 5 ms Circular Predictive Lookahead Ring-Buffer
    static constexpr size_t kLookaheadCapacity = 2048;
    static constexpr size_t kLookaheadMask = kLookaheadCapacity - 1;
    std::array<float, kLookaheadCapacity> lookaheadRingL{};
    std::array<float, kLookaheadCapacity> lookaheadRingR{};
    size_t lookaheadWritePos = 0;
    int lookaheadSamples = 0;
    bool isStudioMixMode = false;
};

} // namespace dsp171
