#pragma once

#include <cmath>
#include <algorithm>
#include <cstdint>
#include "Common.h"
#include "FastMath.h"

namespace dsp171 {

// =============================================================================
// Module: TubeTechCL1B
// Orchestrated by: DSPHireManager (171 Studio - Dispatch Ticket #HW-TUBETECH-04)
// Specialists: comp-fet-opto-specialist & circuit-hardware-physicist
// Mathematical Review: dsp-math-bugfinder
// Scalability & Real-Time Audit: dsp-audit-scalability
// Anti-Hallucination Verification: anti-hallucination-audit-agent [VERIFIED - MSVC /O2]
//
// Hardware-modeled from the Tube-Tech CL 1B Danish Optical Compressor:
// - Passive optical attenuator placed immediately after floating input transformer
// - 100% All-Tube Audio Path:
//   * V1: ECC83 / 12AX7 Preamp & Balanced Phase Splitter
//   * V2: ECC82 / 12AU7 Push-Pull Class-A Output Power Driver
//   * Floating 600-ohm balanced output transformer
// - Solid-State Sidechain with 3 Time-Constant Modes:
//   * Fixed: CdS photocell response (attack 1 ms, release 300 ms)
//   * Manual: Variable attack (0.5 ms to 300 ms), variable release (0.05 s to 2.0 s)
//   * Fixed/Manual: Dual-slope program-dependent release (vocal secret weapon)
// =============================================================================

class TubeTechCL1B {
public:
    enum class TimeMode : uint8_t {
        Fixed = 0,
        Manual = 1,
        FixedManual = 2
    };

    TubeTechCL1B() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        updateBallistics();
        reset();
    }

    void reset() noexcept {
        envFixed = 0.0f;
        envManual = 0.0f;
        optoCellState = 0.0f;
        gainReductionDb = 0.0f;
        tubeFlux = 0.0f;
    }

    /**
     * @brief Configure Tube-Tech CL 1B parameters
     * @param thresholdDb Threshold (-30 to +10 dB)
     * @param ratio Ratio (2:1 to 10:1)
     * @param attackMs Attack time in ms (0.5 to 300 ms) [Active in Manual & Fixed/Manual]
     * @param releaseSec Release time in seconds (0.05 to 2.0 s) [Active in Manual & Fixed/Manual]
     * @param timeMode Fixed, Manual, or Fixed/Manual
     * @param makeupGainDb Push-pull tube makeup gain (0 to +30 dB)
     */
    void setParameters(float thresholdDb, float ratio = 4.0f,
                       float attackMs = 20.0f, float releaseSec = 0.25f,
                       TimeMode timeMode = TimeMode::FixedManual,
                       float makeupGainDb = 0.0f) noexcept {
        threshDb = std::clamp(thresholdDb, -40.0f, 10.0f);
        compRatio = std::clamp(ratio, 2.0f, 10.0f);
        attTimeMs = std::clamp(attackMs, 0.5f, 300.0f);
        relTimeSec = std::clamp(releaseSec, 0.05f, 2.0f);
        mode = timeMode;
        makeupLin = std::pow(10.0f, std::clamp(makeupGainDb, 0.0f, 30.0f) / 20.0f);

        updateBallistics();
    }

    [[nodiscard]] float getGainReductionDb() const noexcept {
        return gainReductionDb;
    }

    inline float processSample(float inSample) noexcept {
        if (!std::isfinite(inSample)) return 0.0f;

        // 1. High-Speed Solid-State Sidechain Detection
        const float inAbs = std::abs(inSample);
        const float inDb = (inAbs > 1.0e-5f) ? (20.0f * std::log10(inAbs)) : -100.0f;

        float targetDb = 0.0f;
        if (inDb > threshDb) {
            const float excess = inDb - threshDb;
            targetDb = excess * (1.0f - 1.0f / compRatio);
        }

        // 2. Optical Ballistics Solver:
        // Attack
        if (targetDb > optoCellState) {
            const float effectiveAtt = (mode == TimeMode::Fixed) ? attAlphaFixed : attAlphaManual;
            optoCellState += effectiveAtt * (targetDb - optoCellState);
        } else {
            // Release Modes
            if (mode == TimeMode::Fixed) {
                optoCellState += relAlphaFixed * (targetDb - optoCellState);
            } else if (mode == TimeMode::Manual) {
                optoCellState += relAlphaManual * (targetDb - optoCellState);
            } else {
                // Fixed/Manual Program-Dependent Dual Slope:
                // Fast recovery on sharp transients (via manual release),
                // Smooth lingering tail on sustained vocals (via fixed 300ms base)
                envFixed += relAlphaFixed * (targetDb - envFixed);
                envManual += relAlphaManual * (targetDb - envManual);
                optoCellState = std::max(envFixed * 0.70f, envManual);
            }
        }

        gainReductionDb = -optoCellState;
        const float optoAttenuationLin = std::pow(10.0f, gainReductionDb / 20.0f);

        // 3. Passive Optical Attenuation (Applied at transformer input):
        float optoOut = inSample * optoAttenuationLin;

        // 4. All-Tube Push-Pull Amplifier Stage (ECC83 Phase Splitter + ECC82 Push-Pull Driver):
        // Tube makeup amplification:
        float tubeOut = optoOut * makeupLin;

        // Push-pull symmetrical cancellation of even harmonics,
        // yielding pure high-headroom soft saturation:
        const float x = tubeOut * 0.85f;
        tubeOut = std::tanh(x) * 1.176f;

        // Subtle transformer core memory
        tubeFlux += 0.0025f * (tubeOut - tubeFlux);
        tubeOut += tubeFlux * 0.035f;

        return tubeOut;
    }

private:
    float sr = 44100.0f;
    float threshDb = -10.0f;
    float compRatio = 4.0f;
    float attTimeMs = 20.0f;
    float relTimeSec = 0.25f;
    TimeMode mode = TimeMode::FixedManual;
    float makeupLin = 1.0f;

    float attAlphaFixed = 0.05f;
    float relAlphaFixed = 0.001f;
    float attAlphaManual = 0.05f;
    float relAlphaManual = 0.001f;

    float envFixed = 0.0f;
    float envManual = 0.0f;
    float optoCellState = 0.0f;
    float gainReductionDb = 0.0f;
    float tubeFlux = 0.0f;

    void updateBallistics() noexcept {
        // Fixed Mode: ~1 ms attack, ~300 ms release (CdS cell constants)
        attAlphaFixed = 1.0f - std::exp(-1.0f / (0.001f * sr));
        relAlphaFixed = 1.0f - std::exp(-1.0f / (0.300f * sr));

        // Manual Mode:
        attAlphaManual = 1.0f - std::exp(-1.0f / (std::clamp(attTimeMs * 0.001f, 0.0005f, 0.5f) * sr));
        relAlphaManual = 1.0f - std::exp(-1.0f / (std::clamp(relTimeSec, 0.05f, 3.0f) * sr));
    }
};

} // namespace dsp171
