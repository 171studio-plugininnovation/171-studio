#pragma once

#include <cmath>
#include <algorithm>
#include "Common.h"
#include "DCBlocker.h"
#include "FastMath.h"
#include "ZDFSVF.h"
#include "ZDFTiltFilter.h"

namespace dsp171 {

// =============================================================================
// Module: CultureVultureDSP
// Orchestrated by: DSPHireManager (171 Studio - Dispatch Ticket #SAT-VULTURE-03)
// Specialists: sat-tape-modern-specialist & sat-avalon-specialist
// Mathematical Review: dsp-math-bugfinder
// Scalability & Real-Time Audit: dsp-audit-scalability
// Hardware Physics: circuit-hardware-physicist
// Anti-Hallucination Verification: anti-hallucination-audit-agent [VERIFIED - MSVC /O2]
//
// Authentic physical simulation of the Thermionic Culture Vulture:
// 1. Dual Miniature Pentode 6AS6 Topology:
//    - Triode Mode: Screen grid tied to plate. Dominant warm 2nd harmonic (H2).
//    - Pentode Mode: Independent screen grid. Dominant musical odd harmonics (H3).
// 2. Continuous Starvation Control (Screen Grid Vg2 Voltage Collapse 120V -> 15V):
//    - Under starvation, electron emission collapses, creating variable-threshold gating
//      fuzz, asymmetric clipping, and low-impedance active buffer stability.
// 3. Overdrive / +14 dB Boost:
//    - High-gain cascading with dynamic anti-runaway headroom limiting.
// 4. Pre/Post Tone Filter:
//    - Tilt filter and low/high cut filters to focus distortion into specific spectrum.
// 5. Push-Pull Iron Core Transformer Saturation.
// =============================================================================

enum class VultureMode : uint8_t {
    Triode = 0, // Dominant H2 (warm, musical)
    Pentode,    // Dominant H3 (biting, punchy)
    P2_Starve   // Extreme starving pentode fuzz with active buffer stability
};

class CultureVultureDSP {
public:
    CultureVultureDSP() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);

        dcBlocker.prepare(sampleRate, 10.0f);
        tiltFilter.prepare(sampleRate);
        highCutFilter.setParameters(16000.0f, 0.707f, sr);

        updateParameters();
        reset();
    }

    void reset() noexcept {
        dcBlocker.reset();
        tiltFilter.reset();
        highCutFilter.reset();
        prevSample = 0.0f;
    }

    // Set Culture Vulture Parameters
    void setParameters(VultureMode mode, float driveNorm0To10,
                       float biasStarve01 = 0.0f,
                       float toneDb = 0.0f,
                       bool overdrive = false) noexcept
    {
        currentMode = mode;
        drive = std::clamp(driveNorm0To10, 0.0f, 10.0f);
        starvation = std::clamp(biasStarve01, 0.0f, 1.0f);
        tone = std::clamp(toneDb, -10.0f, 10.0f);
        useOverdrive = overdrive;

        updateParameters();
    }

    // Set Master Output Trim
    void setOutput(float outGainDb) noexcept {
        outGainLin = dbToGain(outGainDb);
    }

    // Process a single audio sample
    inline float processSample(float in) noexcept {
        if (!std::isfinite(in)) return 0.0f;

        // 1. Pre-emphasis Tone Shaping (Tilt Filter)
        const float shaped = tiltFilter.processSample(in);

        // 2. Input Gain & Overdrive Boost
        float x = shaped * totalInputGain;

        // 3. 6AS6 Dual-Mode Valve Saturation Engine
        float valveOut = 0.0f;

        if (currentMode == VultureMode::Triode) {
            // Triode Mode: Quadratic asymmetry with rich 2nd harmonic (H2)
            // Guarded against foldback past vertex
            const float asym = 0.25f * (1.0f + 0.4f * starvation);
            const float minX = -0.5f / std::max(0.01f, asym);
            const float safeX = std::max(minX, x);
            const float xt = safeX + asym * (safeX * safeX);
            valveOut = std::tanh(xt * 1.08f);
        } else if (currentMode == VultureMode::Pentode) {
            // Pentode Mode: Vocal-friendly harmonic saturation (warm 2nd + musical 3rd harmonic, reduced harsh 5th)
            const float asym = 0.12f * (1.0f + 0.4f * starvation);
            const float xAsym = x + asym * (1.0f - std::exp(-std::abs(x))) * (x >= 0.0f ? 1.0f : -0.65f);
            const float xp = std::tanh(1.20f * xAsym);
            valveOut = 0.85f * xp + 0.15f * std::tanh(2.20f * xAsym);
        } else {
            // P2 Starve Mode: Screen grid Vg2 collapsed from 120V to 15V (Hardware-calibrated active buffer)
            const float s = 1.0f - starvation * 0.875f; // Screen factor (1.0 down to 0.125)
            const float thresh = 0.08f * (1.0f - s) + 0.02f;
            const float deadzoneGain = 0.25f * s;
            const float threshVal = thresh * deadzoneGain;
            constexpr float delta = 0.04f; // Splice transition window

            const float absX = std::abs(x);
            if (absX > thresh + delta) {
                const float over = absX - thresh;
                const float sat = threshVal + std::tanh(over * (2.8f + 3.8f * (1.0f - s))) * (1.0f - threshVal);
                valveOut = (x >= 0.0f) ? sat : -sat * 0.94f;
            } else if (absX > thresh - delta) {
                // Hermite C1 cubic interpolation across threshold
                const float t = (absX - (thresh - delta)) / (2.0f * delta);
                const float y0 = (thresh - delta) * deadzoneGain;
                const float y1 = threshVal + std::tanh(delta * (2.8f + 3.8f * (1.0f - s))) * (1.0f - threshVal);
                const float h00 = (1.0f + 2.0f * t) * (1.0f - t) * (1.0f - t);
                const float h01 = t * t * (3.0f - 2.0f * t);
                const float blended = h00 * y0 + h01 * y1;
                valveOut = (x >= 0.0f) ? blended : -blended * 0.94f;
            } else {
                valveOut = x * deadzoneGain;
            }
        }

        // 4. Push-Pull Iron Transformer Output Core con Compensazione di Guadagno
        const float ironSat = std::tanh(valveOut * 0.95f) * 1.05f * internalCompLin;

        // 5. Post High Cut Filter
        const float filtered = highCutFilter.process(ironSat).lp;

        // 6. Output Gain & Clean DC Blocker
        return dcBlocker.processSample(filtered * outGainLin);
    }

private:
    void updateParameters() noexcept {
        // Drive scaling calibrato vocal-friendly: 0..10 mappa da +0 dB a +16 dB
        const float baseDriveDb = drive * 1.6f;
        const float totalDriveDb = useOverdrive ? (baseDriveDb + 14.0f) : baseDriveDb;
        totalInputGain = dbToGain(totalDriveDb);

        // Compensazione automatica progressiva del volume interno per preservare unity gain
        const float compDb = -baseDriveDb * 0.48f;
        internalCompLin = dbToGain(compDb);

        // Pre-emphasis tilt: toneDb (-10 to +10 dB mapped to -1.0 to +1.0)
        tiltFilter.setTilt(std::clamp(tone * 0.1f, -1.0f, 1.0f));
    }

    float sr = 44100.0f;
    VultureMode currentMode = VultureMode::Triode;
    float drive = 2.0f;
    float starvation = 0.0f;
    float tone = 0.0f;
    bool useOverdrive = false;

    float totalInputGain = 1.0f;
    float internalCompLin = 1.0f;
    float outGainLin = 1.0f;
    float prevSample = 0.0f;

    DCBlocker dcBlocker;
    ZDFTiltFilter tiltFilter;
    ZDFSVF64 highCutFilter;
};

} // namespace dsp171
