#pragma once
#include <cmath>
#include <algorithm>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// API 2500 Thrust Sidechain Filter Emulation
//
// Designed under Agente 11 (sat-api-specialist) & Agente 09 (comp-optical-universal).
//
// Modes:
// 1. Normal (Flat): No modification to sidechain detector energy.
// 2. Medium: 3 dB/octave gentle low-cut and high-boost filter (+/- 3 dB over band).
// 3. Loud: Full 10 dB/decade (-10 dB/dec down to 20 Hz, +10 dB/dec up to 20 kHz),
//    crossing at 1 kHz unity gain. Equalizes acoustic energy so loud low-end kicks
//    and bass guitars do not trigger premature pumping, creating massive punch.
// =============================================================================
class APIThrustFilter {
public:
    enum class ThrustMode : uint8_t {
        Normal = 0,
        Medium,
        Loud
    };

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        reset();
        updateCoeffs();
    }

    void reset() noexcept {
        s1 = 0.0f;
        s2 = 0.0f;
        s3 = 0.0f;
    }

    void setMode(ThrustMode m) noexcept {
        if (mode != m) {
            mode = m;
            updateCoeffs();
        }
    }

    ThrustMode getMode() const noexcept { return mode; }

    inline float processSample(float in) noexcept {
        if (mode == ThrustMode::Normal || !std::isfinite(in)) {
            return in;
        }

        // 3-pole fractional integrator/differentiator network modeling continuous spectral tilt
        float y = in;
        if (mode == ThrustMode::Medium) {
            // Medium: 1st order shelf tilt
            const float v1 = (y - s1) * g1;
            const float lp1 = v1 + s1;
            s1 = lp1 + v1;
            y = (in - lp1) * gainHfMed + in * gainLfMed;
        } else {
            // Loud: Cascaded 10 dB/decade tilt curve centered at 1 kHz
            const float v1 = (y - s1) * g1;
            const float lp1 = v1 + s1;
            s1 = lp1 + v1;

            const float v2 = (y - s2) * g2;
            const float lp2 = v2 + s2;
            s2 = lp2 + v2;

            const float v3 = (y - s3) * g3;
            const float lp3 = v3 + s3;
            s3 = lp3 + v3;

            // Synthesis of energy-equalized tilt
            const float highs = (in - lp1) * 2.2f + (in - lp2) * 1.1f;
            const float lows = (lp1 * 0.25f + lp2 * 0.40f + lp3 * 0.35f);
            y = highs + lows;
        }

        // Denormal guard
        if (std::abs(s1) < 1e-25f) s1 = 0.0f;
        if (std::abs(s2) < 1e-25f) s2 = 0.0f;
        if (std::abs(s3) < 1e-25f) s3 = 0.0f;

        return y;
    }

private:
    void updateCoeffs() noexcept {
        const float safeSr = sr > 0.0f ? sr : 44100.0f;
        const float maxTheta = 0.495f * PI;
        const float theta1 = std::min((2.0f * PI * 350.0f) * 0.5f / safeSr, maxTheta);
        const float theta2 = std::min((2.0f * PI * 1000.0f) * 0.5f / safeSr, maxTheta);
        const float theta3 = std::min((2.0f * PI * 2800.0f) * 0.5f / safeSr, maxTheta);

        g1 = std::clamp(std::tan(theta1), 0.001f, 0.95f);
        g2 = std::clamp(std::tan(theta2), 0.001f, 0.95f);
        g3 = std::clamp(std::tan(theta3), 0.001f, 0.95f);

        gainLfMed = 0.707f; // -3 dB LF
        gainHfMed = 1.414f; // +3 dB HF
    }

    float sr{44100.0f};
    ThrustMode mode{ThrustMode::Normal};
    float g1{0.05f};
    float g2{0.14f};
    float g3{0.38f};
    float gainLfMed{0.707f};
    float gainHfMed{1.414f};

    float s1{0.0f};
    float s2{0.0f};
    float s3{0.0f};
};

} // namespace dsp171
