#pragma once
#include <cmath>
#include <algorithm>
#include <atomic>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>

namespace dsp171 {

// =============================================================================
// 171 VocalCraft - Smart Vocal Gain Stager & Input Calibrator
//
// Automatically normalizes incoming vocal signal to the optimal analog-modeled
// internal operating sweet spot (-18.0 dBFS RMS / -14 LUFS).
// Features:
// - Relative speech gating (-36 dBFS): ignores headphone bleed, quiet breaths,
//   and silence between phrases so background pauses never distort the measurement.
// - Safe musical clamp [-6.0 dB, +6.0 dB]: prevents catastrophic +24 dB gain blasts.
// - Starts at 0.0 dB unity gain on plugin insertion.
// - 20ms clickless cosine slew rate.
// =============================================================================
class VocalCraftGainStager {
public:
    enum class State {
        Idle,
        Calibrating,
        Locked
    };

    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 0.0 ? sampleRate : 44100.0;
        // 25ms one-pole slew rate to guarantee clickless gain transitions
        gainSlewCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.025 * sr)));
        reset();
    }

    void reset() noexcept {
        currentState = State::Idle;
        accumulatedEnergy = 0.0;
        validSampleCount = 0;
        currentGainLinear = 1.0f;
        targetGainLinear = 1.0f;
        measuredRmsDb.store(-90.0f, std::memory_order_relaxed);
        currentTrimDb.store(0.0f, std::memory_order_relaxed);
        isLockedState.store(false, std::memory_order_relaxed);
        isCalibratingState.store(false, std::memory_order_relaxed);
    }

    void startCalibration() noexcept {
        currentState = State::Calibrating;
        accumulatedEnergy = 0.0;
        validSampleCount = 0;
        isLockedState.store(false, std::memory_order_relaxed);
        isCalibratingState.store(true, std::memory_order_relaxed);
    }

    void setTargetRmsDb(float targetDb) noexcept {
        targetOperatingRmsDb = std::clamp(targetDb, -24.0f, -12.0f);
    }

    void setManualTrimDb(float trimDb) noexcept {
        manualTrimDb = std::clamp(trimDb, -18.0f, 18.0f);
        if (currentState != State::Locked) {
            targetGainLinear = fastDbToLinear(manualTrimDb);
            currentTrimDb.store(manualTrimDb, std::memory_order_relaxed);
        }
    }

    // Process a block of audio samples with seamless gain ramping
    void process(float* channelData, int numSamples) noexcept {
        if (numSamples <= 0 || channelData == nullptr)
            return;

        for (int i = 0; i < numSamples; ++i) {
            const float in = channelData[i];
            const float absIn = std::abs(in);

            // Relative Speech Gating during calibration
            if (currentState == State::Calibrating) {
                // Ignore silence, room noise, and breaths below -36 dBFS (~0.0158 linear)
                if (absIn > 0.0158f) {
                    accumulatedEnergy += static_cast<double>(in) * static_cast<double>(in);
                    validSampleCount++;

                    // Minimum required speech frames: ~1.2 seconds of actual singing
                    const size_t targetSamples = static_cast<size_t>(sr * 1.2);
                    if (validSampleCount >= targetSamples) {
                        finishCalibration();
                    }
                }
            }

            // Smooth one-pole gain smoothing to eliminate clicks
            currentGainLinear += (targetGainLinear - currentGainLinear) * gainSlewCoeff;

            channelData[i] = in * currentGainLinear;
        }
    }

    // Process stereo buffer
    void processStereo(float* left, float* right, int numSamples) noexcept {
        if (numSamples <= 0) return;
        for (int i = 0; i < numSamples; ++i) {
            const float monoMix = 0.5f * (left[i] + right[i]);
            const float absIn = std::abs(monoMix);

            if (currentState == State::Calibrating && absIn > 0.0158f) {
                accumulatedEnergy += static_cast<double>(monoMix) * static_cast<double>(monoMix);
                validSampleCount++;
                if (validSampleCount >= static_cast<size_t>(sr * 1.2)) {
                    finishCalibration();
                }
            }

            currentGainLinear += (targetGainLinear - currentGainLinear) * gainSlewCoeff;

            left[i]  *= currentGainLinear;
            if (right != nullptr)
                right[i] *= currentGainLinear;
        }
    }

    // Telemetry queries for GUI (60 FPS thread-safe)
    float getMeasuredRmsDb() const noexcept { return measuredRmsDb.load(std::memory_order_relaxed); }
    float getCurrentTrimDb() const noexcept { return currentTrimDb.load(std::memory_order_relaxed); }
    bool isCalibrating() const noexcept { return isCalibratingState.load(std::memory_order_relaxed); }
    bool isLocked() const noexcept { return isLockedState.load(std::memory_order_relaxed); }

private:
    void finishCalibration() noexcept {
        if (validSampleCount > 0) {
            const double meanSquare = accumulatedEnergy / static_cast<double>(validSampleCount);
            const double rms = std::sqrt(std::max(1e-12, meanSquare));
            const float measuredDb = static_cast<float>(20.0 * std::log10(rms));
            measuredRmsDb.store(measuredDb, std::memory_order_relaxed);

            // Compute optimal gain trim to hit targetOperatingRmsDb (-18 dBFS default)
            float neededTrimDb = targetOperatingRmsDb - measuredDb;
            // Musical clamp [-12 dB, +12 dB] prevents extreme runaway boosts while allowing proper staging
            neededTrimDb = std::clamp(neededTrimDb, -12.0f, 12.0f);

            targetGainLinear = fastDbToLinear(neededTrimDb);
            currentTrimDb.store(neededTrimDb, std::memory_order_relaxed);
            currentState = State::Locked;
            isLockedState.store(true, std::memory_order_relaxed);
            isCalibratingState.store(false, std::memory_order_relaxed);
        }
    }

    double sr = 44100.0;
    State currentState = State::Idle;
    float targetOperatingRmsDb = -18.0f;
    float manualTrimDb = 0.0f;

    double accumulatedEnergy = 0.0;
    size_t validSampleCount = 0;

    float currentGainLinear = 1.0f;
    float targetGainLinear = 1.0f;
    float gainSlewCoeff = 0.001f;

    std::atomic<float> measuredRmsDb{-90.0f};
    std::atomic<float> currentTrimDb{0.0f};
    std::atomic<bool>  isCalibratingState{false};
    std::atomic<bool>  isLockedState{false};
};

} // namespace dsp171
