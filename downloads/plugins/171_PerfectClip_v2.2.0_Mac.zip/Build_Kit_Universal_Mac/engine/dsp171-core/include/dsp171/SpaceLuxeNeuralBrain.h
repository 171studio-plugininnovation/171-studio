#pragma once

#include <cmath>
#include <array>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <numbers>

#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include <dsp171/ZDFSVF.h>

namespace dsp171 {

// =============================================================================
// 171 SpaceLuxe - Neural Brain (Deep Acoustic Space Inference Engine)
// 171 Studio Innovatio - High Precision Zero-Allocation C++20 Header
//
// Real-Time Neural Architecture:
// 1. SpaceLuxeFeatureExtractor:
//    Extracts 10 real-time physical acoustic, transient & phrase dynamics features:
//    [0] vocalInputRmsDb          (-90.0 to 0.0 dBFS) with asymmetric ballistics
//    [1] plosiveTransientEnergy   (Percussive burst & crest factor: 0.0 to 1.0)
//    [2] sibilantEnergyDb         (Dedicated Cytomic 64-bit ZDF SVF at 6.8 kHz)
//    [3] vocalPresenceDb          (Intelligibility formant body at 2.2 kHz)
//    [4] silenceDurationSec       (Inter-phrase silence / pause timer in seconds)
//    [5] phraseEndingProb         (Syllabic pause confidence for tail bloom: 0.0 to 1.0)
//    [6] spectralCentroidHz       (Brightness center of mass: 200 Hz to 12000 Hz)
//    [7] spectralFlux             (Inter-frame transient energy flux: 0.0 to 10.0)
//    [8] sidechainBeatRmsDb       (External sidechain beat / drums RMS: -90.0 to 0.0 dBFS)
//    [9] sidechainClash           (Vocal vs Beat collision ratio: 0.0 to 1.0)
//
// 2. SpaceLuxeNeuralInferenceEngine:
//    Compact Recurrent Neural Brain with Boutique Pre-Trained Weights:
//    - Normalization: Zero-mean unit-variance acoustic feature scaling
//    - Layer 1: Dense 10 -> 16 with fast GELU activation
//    - Layer 2: Temporal Memory GRU cell (12 hidden states) tracking phrasing & ballistics
//    - Layer 3: Output Projection 12 -> 5 with physical domain bounded sigmoid mappings:
//      [0] predictedDuckDb        (Dynamic VCA ducking gain reduction: 0.0 to 18.0 dB)
//      [1] tailBloomDb            (Syllabic tail bloom boost on pauses: 0.0 to +6.0 dB)
//      [2] stereoWidthBloom       (Stereo width expansion factor: 1.0x to 1.8x)
//      [3] antiSplashCutDb        (Pre-tank 6.8 kHz sibilance cut: 0.0 to 12.0 dB)
//      [4] adaptivePreDelayMs     (Adaptive pre-delay micro-offset: 0.0 to 30.0 ms)
//
// 3. Thread-Safety & Performance:
//    - STRICT ZERO HEAP ALLOCATIONS in audio thread (prepare, process, infer).
//    - Sub-25 microsecond execution time at 96 kHz.
//    - Tear-free double-buffered Seqlock telemetry snapshots for 60 FPS GUI.
//    - Seqlock index calculation avoids off-by-one: ((s1 >> 1) > 0 ? (((s1 >> 1) - 1) & 1) : 0).
// =============================================================================

// --- Enumerations ---

enum SpaceLuxeFeatureIndex : size_t {
    kSLFeatureVocalInputRmsDb = 0,        // Vocal Input RMS dBFS (-90.0 to 0.0)
    kSLFeaturePlosiveTransientEnergy = 1,  // Plosive & transient energy (0.0 to 1.0)
    kSLFeatureSibilantEnergyDb = 2,        // Sibilant energy at 6.8 kHz (-90.0 to 0.0 dBFS)
    kSLFeatureVocalPresenceDb = 3,         // Mid-frequency Vocal Presence at 2.2 kHz (-90.0 to 0.0 dBFS)
    kSLFeatureSilenceDurationSec = 4,      // Syllabic pause / silence timer in seconds (0.0 to 5.0s)
    kSLFeaturePhraseEndingProb = 5,        // Phrase ending bloom confidence (0.0 to 1.0)
    kSLFeatureSpectralCentroidHz = 6,      // Spectral centroid brightness (200.0 to 12000.0 Hz)
    kSLFeatureSpectralFlux = 7,            // Inter-frame spectral transient burst flux (0.0 to 10.0)
    kSLFeatureSidechainBeatRmsDb = 8,      // External sidechain drums/beat RMS dBFS (-90.0 to 0.0)
    kSLFeatureSidechainClash = 9,          // Vocal vs Beat transient clash ratio (0.0 to 1.0)
    kNumSpaceLuxeFeatures = 10
};

enum SpaceLuxePredictionIndex : size_t {
    kSLPredDuckingGainDb = 0,       // Dynamic VCA ducking gain reduction [0.0 to 18.0 dB]
    kSLPredTailBloomDb = 1,         // Syllabic Tail Bloom boost on pause [0.0 to +6.0 dB]
    kSLPredStereoWidthBloom = 2,    // Stereo width expansion factor [1.0x to 1.8x]
    kSLPredAntiSplashCutDb = 3,     // Pre-tank 6.8 kHz sibilance cut [0.0 to 12.0 dB]
    kSLPredAdaptivePreDelayMs = 4,  // Adaptive pre-delay micro-offset [0.0 to 30.0 ms]
    kNumSpaceLuxePredictions = 5
};

// --- Telemetry Snapshot ---

struct SpaceLuxeBrainTelemetry {
    // 10 Extracted Physical Features
    std::array<float, kNumSpaceLuxeFeatures> features{};

    // 5 Neural Inferred Control Targets
    std::array<float, kNumSpaceLuxePredictions> predictions{};

    // Named convenience feature fields
    float vocalInputRmsDb = -90.0f;
    float plosiveTransientEnergy = 0.0f;
    float sibilantEnergyDb = -90.0f;
    float vocalPresenceDb = -90.0f;
    float silenceDurationSec = 0.0f;
    float phraseEndingProb = 0.0f;
    float spectralCentroidHz = 1000.0f;
    float spectralFlux = 0.0f;
    float sidechainBeatRmsDb = -90.0f;
    float sidechainClash = 0.0f;

    // Named convenience prediction fields
    float predictedDuckDb = 0.0f;       // [0.0 to 18.0 dB]
    float tailBloomDb = 0.0f;           // [0.0 to +6.0 dB]
    float stereoWidthBloom = 1.0f;      // [1.0x to 1.8x]
    float antiSplashCutDb = 0.0f;       // [0.0 to 12.0 dB]
    float adaptivePreDelayMs = 15.0f;    // [0.0 to 30.0 ms]

    // Diagnostics & Performance metrics
    uint64_t inferenceCount = 0;
    float lastInferenceTimeUs = 0.0f;
};

// --- Pre-Trained Boutique Neural Weights for 171 SpaceLuxe ---

namespace spaceluxe_weights {

    static constexpr std::array<float, 10> kFeatureMeans = {
        -35.0000000f, // 0: vocalInputRmsDb
          0.3000000f, // 1: plosiveTransientEnergy
        -45.0000000f, // 2: sibilantEnergyDb
        -35.0000000f, // 3: vocalPresenceDb
          0.5000000f, // 4: silenceDurationSec
          0.3000000f, // 5: phraseEndingProb
       3000.0000000f, // 6: spectralCentroidHz
          0.5000000f, // 7: spectralFlux
        -35.0000000f, // 8: sidechainBeatRmsDb
          0.2000000f  // 9: sidechainClash
    };

    static constexpr std::array<float, 10> kFeatureInvScales = {
        0.0400000f,   // 1 / 25.0 dB
        2.5000000f,   // 1 / 0.40
        0.0450000f,   // 1 / 22.2 dB
        0.0450000f,   // 1 / 22.2 dB
        1.5000000f,   // 1 / 0.67 s
        2.0000000f,   // 1 / 0.50
        0.0004000f,   // 1 / 2500.0 Hz
        1.0000000f,   // 1 / 1.00
        0.0400000f,   // 1 / 25.0 dB
        2.5000000f    // 1 / 0.40
    };

    // Layer 1: Dense 10 -> 16
    static constexpr std::array<std::array<float, 10>, 16> kLayer1Weights = {{
        // L1[0]: Vocal Loudness drive (positive on vocalInputRmsDb, vocalPresenceDb)
        {  1.20f,  0.00f,  0.00f,  0.80f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f },
        // L1[1]: Transient Plosive Punch (strongly positive on plosiveTransientEnergy, spectralFlux)
        {  0.00f,  1.80f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.80f,  0.00f,  0.00f },
        // L1[2]: Sibilance 6.8 kHz hash detector (positive on sibilantEnergyDb, centroid)
        {  0.00f,  0.00f,  1.80f,  0.00f,  0.00f,  0.00f,  1.00f,  0.00f,  0.00f,  0.00f },
        // L1[3]: Phrase Ending Bloom Gate (positive on phraseEndingProb, inhibited by singing & dead silence)
        { -1.00f,  0.00f,  0.00f, -0.60f, -0.80f,  2.20f,  0.00f,  0.00f,  0.00f,  0.00f },
        // L1[4]: Stereo Width Bloom expansion driver (positive on phraseEndingProb, low input RMS)
        { -0.80f,  0.00f,  0.00f, -0.40f, -0.60f,  2.00f,  0.00f,  0.00f,  0.00f,  0.00f },
        // L1[5]: Anti-Splash Pre-Tank attenuator (strongly positive on sibilant energy and centroid)
        {  0.00f,  0.00f,  2.00f,  0.00f,  0.00f,  0.00f,  1.20f,  0.00f,  0.00f,  0.00f },
        // L1[6]: Adaptive Pre-Delay Modulation (positive on plosives, transient flux and centroid)
        {  0.00f,  1.50f,  0.00f,  0.00f,  0.00f,  0.00f,  0.40f,  0.60f,  0.00f,  0.00f },
        // L1[7]: Sidechain Beat Collision Drive (positive on sidechain beat RMS and clash)
        {  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  1.20f,  1.50f },
        // L1[8]: Vocal Intelligibility Core (vocal presence & input level)
        {  1.00f,  0.00f,  0.00f,  1.20f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f },
        // L1[9]: Plosive Sub-Burst Detector (plosive energy and input RMS)
        {  0.50f,  1.60f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f },
        // L1[10]: High-Frequency Harshness Monitor (spectral centroid brightness)
        {  0.00f,  0.00f,  0.50f,  0.00f,  0.00f,  0.00f,  1.50f,  0.00f,  0.00f,  0.00f },
        // L1[11]: Pause Duration Integrator (silence duration timer, inhibited by voice)
        { -0.80f,  0.00f,  0.00f, -0.50f,  1.20f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f },
        // L1[12]: Sidechain Beat Energy
        {  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  1.50f,  0.00f },
        // L1[13]: Reverb Clarity Protector (vocal loudness + plosive burst)
        {  1.00f,  1.20f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f },
        // L1[14]: Sibilance to Vowel Ratio
        {  0.00f,  0.00f,  1.40f, -0.60f,  0.00f,  0.00f,  0.50f,  0.00f,  0.00f,  0.00f },
        // L1[15]: Tail Bloom Sustain Memory
        { -0.50f,  0.00f,  0.00f,  0.00f, -0.50f,  1.80f,  0.00f,  0.00f,  0.00f,  0.00f }
    }};

    static constexpr std::array<float, 16> kLayer1Bias = {
         0.20f, -0.20f, -0.30f, -0.10f,
        -0.20f, -0.20f,  0.00f, -0.10f,
         0.10f, -0.10f,  0.00f,  0.00f,
         0.20f,  0.00f,  0.00f, -0.10f
    };

    // Layer 2: GRU-12 Recurrent Weights
    // Reset gate weights Wr (12 x 16), Ur (12 diagonal), br (12)
    static constexpr std::array<std::array<float, 16>, 12> kGruWeightsWr = {{
        { 0.8f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.6f, 0.0f, 0.0f },
        { 0.0f, 1.2f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 1.2f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.6f, 0.0f, 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 1.2f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f },
        { 0.0f, 0.0f, 0.0f, 0.0f, 1.2f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.6f },
        { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.2f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.2f, 0.0f, 0.0f, 0.6f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.2f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f, 0.0f, 0.0f, 0.0f },
        { 0.6f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f, 0.0f, 0.0f, 0.0f, 0.0f, 0.6f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 0.6f, 0.6f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f }
    }};
    static constexpr std::array<float, 12> kGruWeightsUrDiag = {
        0.35f, 0.20f, 0.20f, 0.40f, 0.40f, 0.40f, 0.25f, 0.30f, 0.25f, 0.40f, 0.25f, 0.40f
    };
    static constexpr std::array<float, 12> kGruBiasR = {
        0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f
    };

    // Update gate weights Wz (12 x 16), Uz (12 diagonal), bz (12)
    static constexpr std::array<std::array<float, 16>, 12> kGruWeightsWz = {{
        { 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f, 0.0f, 0.0f },
        { 0.0f, 1.8f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 1.8f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 1.2f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.6f, 0.0f, 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 1.4f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f },
        { 0.0f, 0.0f, 0.0f, 0.0f, 1.4f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.6f },
        { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.8f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.5f, 0.0f, 0.0f, 0.8f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.5f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f, 0.0f, 0.0f, 0.0f },
        { 0.8f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f, 0.0f, 0.0f, 0.0f, 0.0f, 0.6f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.2f, 0.0f, 0.0f, 0.0f, 0.0f, 0.6f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 0.8f, 0.8f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f }
    }};
    static constexpr std::array<float, 12> kGruWeightsUzDiag = {
        0.30f, 0.20f, 0.20f, 0.35f, 0.35f, 0.35f, 0.20f, 0.25f, 0.20f, 0.35f, 0.20f, 0.35f
    };
    static constexpr std::array<float, 12> kGruBiasZ = {
        0.1f, 0.2f, 0.2f, 0.1f, 0.1f, 0.1f, 0.2f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f
    };

    // Candidate hidden state weights Wh (12 x 16), Uh (12 diagonal), bh (12)
    static constexpr std::array<std::array<float, 16>, 12> kGruWeightsWh = {{
        { 1.2f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f, 0.0f, 0.0f },
        { 0.0f, 1.6f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.9f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 1.6f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 1.4f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f, 0.0f, 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 1.6f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f },
        { 0.0f, 0.0f, 0.0f, 0.0f, 1.6f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f },
        { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.6f, 0.0f, 0.0f, 0.0f, 0.0f, 0.9f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.4f, 0.0f, 0.0f, 0.7f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.4f, 0.0f, 0.0f, 0.0f, 0.0f, 0.8f, 0.0f, 0.0f, 0.0f },
        { 0.9f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.9f, 0.0f, 0.0f, 0.0f, 0.0f, 0.7f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.2f, 0.0f, 0.0f, 0.0f, 0.0f, 0.7f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f },
        { 0.0f, 0.0f, 0.0f, 0.9f, 0.9f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.9f }
    }};
    static constexpr std::array<float, 12> kGruWeightsUhDiag = {
        0.30f, 0.15f, 0.15f, 0.35f, 0.35f, 0.35f, 0.20f, 0.25f, 0.20f, 0.35f, 0.20f, 0.35f
    };
    static constexpr std::array<float, 12> kGruBiasH = {
        0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f
    };

    // Layer 3: Output Projection (12 -> 5)
    static constexpr std::array<std::array<float, 12>, 5> kOutputWeights = {{
        // Output 0: predictedDuckDb [0.0 to 18.0 dB]
        {  1.40f,  2.20f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  1.20f,  0.80f,  0.00f,  0.00f },
        // Output 1: tailBloomDb [0.0 to +6.0 dB]
        { -1.50f, -1.00f,  0.00f,  0.80f,  3.20f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.60f },
        // Output 2: stereoWidthBloom [1.0x to 1.8x]
        { -1.00f,  0.00f,  0.00f,  0.00f,  0.60f,  3.40f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  0.60f },
        // Output 3: antiSplashCutDb [0.0 to 12.0 dB]
        {  0.00f,  0.00f,  1.50f,  0.00f,  0.00f,  0.00f,  3.20f,  0.00f,  0.00f,  0.00f,  0.80f,  0.00f },
        // Output 4: adaptivePreDelayMs [0.0 to 30.0 ms]
        { -0.50f,  1.20f,  0.00f,  0.00f,  0.00f,  0.00f,  0.00f,  2.00f,  0.00f,  0.00f,  0.00f,  0.00f }
    }};

    static constexpr std::array<float, 5> kOutputBias = {
        -1.20f, // Output 0: predictedDuckDb
        -2.00f, // Output 1: tailBloomDb
        -2.20f, // Output 2: stereoWidthBloom
        -2.20f, // Output 3: antiSplashCutDb
        -0.10f  // Output 4: adaptivePreDelayMs
    };

} // namespace spaceluxe_weights

// =============================================================================
// SpaceLuxeFeatureExtractor
// Extracts 10 physical features with zero heap allocations:
// ZDF SVF 64-bit filterbank (Low Plosive, Vocal Presence, Sibilant 6.8 kHz, Air),
// Asymmetric ballistics, Syllabic pause timing, and Sidechain clash detector.
// =============================================================================
class SpaceLuxeFeatureExtractor {
public:
    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 0.0 ? static_cast<float>(sampleRate) : 44100.0f;

        // Formant tracking filters (Cytomic ZDF SVF 64-bit)
        // 1. Plosive / Low-Mid: Center = 180 Hz, Q = 1.20
        svfPlosiveLow.reset();
        svfPlosiveLow.setParameters(180.0f, 1.20f, sr);

        // 2. Vocal Presence / Vowel Body: Center = 2200 Hz, Q = 0.85
        svfPresence.reset();
        svfPresence.setParameters(2200.0f, 0.85f, sr);

        // 3. Dedicated Sibilant Filter: Center = 6800 Hz, Q = 1.80 (per specification)
        svfSibilant.reset();
        svfSibilant.setParameters(6800.0f, 1.80f, sr);

        // 4. Air Sheen: Center = 11000 Hz, Q = 1.20
        svfAir.reset();
        svfAir.setParameters(11000.0f, 1.20f, sr);

        // 5. External Sidechain Kick / Bass: Center = 100 Hz, Q = 0.90
        svfSidechainKick.reset();
        svfSidechainKick.setParameters(100.0f, 0.90f, sr);

        // Asymmetric ballistics time constants:
        // Attack: ~8 ms, Release: ~60 ms
        rmsAttackCoeff = fastOneMinusExpNeg(-1.0f / (0.008f * sr));
        rmsReleaseCoeff = fastOneMinusExpNeg(-1.0f / (0.060f * sr));

        reset();
    }

    void reset() noexcept {
        svfPlosiveLow.reset();
        svfPresence.reset();
        svfSibilant.reset();
        svfAir.reset();
        svfSidechainKick.reset();
        dcBlockX1 = 0.0;
        dcBlockY1 = 0.0;

        smoothedVocalRms = 0.00001f;
        silenceTimerSec = 0.0f;
        wasSinging = false;
        prevCentroid = 1000.0f;
        prevEnergyDistribution = { 0.25f, 0.25f, 0.25f, 0.25f };
        phraseEndingProb = 0.0f;
    }

    void extractFeatures(const float* vocalL, const float* vocalR,
                         const float* sidechainL, const float* sidechainR,
                         int numSamples,
                         std::array<float, kNumSpaceLuxeFeatures>& outFeatures) noexcept
    {
        if (numSamples <= 0 || vocalL == nullptr) {
            outFeatures.fill(0.0f);
            outFeatures[kSLFeatureVocalInputRmsDb] = -90.0f;
            outFeatures[kSLFeatureSibilantEnergyDb] = -90.0f;
            outFeatures[kSLFeatureVocalPresenceDb] = -90.0f;
            outFeatures[kSLFeatureSidechainBeatRmsDb] = -90.0f;
            outFeatures[kSLFeatureSpectralCentroidHz] = 1000.0f;
            return;
        }

        const bool hasSidechain = (sidechainL != nullptr);
        const float invN = 1.0f / static_cast<float>(numSamples);
        const float blockDurationSec = static_cast<float>(numSamples) / sr;

        float sumSqVocal = 0.0f;
        float peakVocal = 0.0f;

        float sumSqPlosive = 0.0f;
        float sumSqPresence = 0.0f;
        float sumSqSibilant = 0.0f;
        float sumSqAir = 0.0f;

        float sumSqSidechain = 0.0f;
        float sumSqSideKick = 0.0f;

        // Inner audio loop - Zero allocations, pure registers
        for (int i = 0; i < numSamples; ++i) {
            float vSample = vocalL[i];
            if (vocalR != nullptr)
                vSample = 0.5f * (vSample + vocalR[i]);

            if (!std::isfinite(vSample)) vSample = 0.0f;

            // DC Blocker filter
            const double inD = static_cast<double>(vSample);
            const double dcFiltered = inD - dcBlockX1 + 0.9995 * dcBlockY1;
            dcBlockX1 = inD;
            dcBlockY1 = dcFiltered;
            vSample = static_cast<float>(dcFiltered);

            const float absV = std::abs(vSample);
            if (absV > peakVocal) peakVocal = absV;
            sumSqVocal += vSample * vSample;

            // Specialized ZDF SVF filterbank (Cytomic 64-bit integrators)
            const float lowY = svfPlosiveLow.processBP(vSample);
            sumSqPlosive += lowY * lowY;

            const float presY = svfPresence.processBP(vSample);
            sumSqPresence += presY * presY;

            const float sibY = svfSibilant.processBP(vSample);
            sumSqSibilant += sibY * sibY;

            const float airY = svfAir.processBP(vSample);
            sumSqAir += airY * airY;

            if (hasSidechain) {
                float scSample = sidechainL[i];
                if (sidechainR != nullptr)
                    scSample = 0.5f * (scSample + sidechainR[i]);
                if (!std::isfinite(scSample)) scSample = 0.0f;

                sumSqSidechain += scSample * scSample;
                const float kickY = svfSidechainKick.processBP(scSample);
                sumSqSideKick += kickY * kickY;
            }
        }

        // Instantaneous block RMS
        const float blockRms = std::sqrt(sumSqVocal * invN);

        // Asymmetric ballistics: Fast attack, gentle release
        const float attackRate = 1.0f - std::pow(1.0f - rmsAttackCoeff, static_cast<float>(numSamples));
        const float releaseRate = 1.0f - std::pow(1.0f - rmsReleaseCoeff, static_cast<float>(numSamples));

        if (blockRms > smoothedVocalRms) {
            smoothedVocalRms += attackRate * (blockRms - smoothedVocalRms);
        } else {
            smoothedVocalRms += releaseRate * (blockRms - smoothedVocalRms);
        }

        // [0] Vocal Input RMS dBFS (-90.0 to 0.0 dBFS)
        const float vocalRmsDb = std::clamp(fastLinearToDb(smoothedVocalRms), -90.0f, 0.0f);
        outFeatures[kSLFeatureVocalInputRmsDb] = vocalRmsDb;

        // [1] Plosive & Transient Energy (percussive burst & crest factor)
        const float crestFactor = (blockRms > 1.0e-5f) ? (peakVocal / blockRms) : 1.0f;
        const float plosiveRms = std::sqrt(sumSqPlosive * invN);
        const float plosiveRatio = (blockRms > 1.0e-5f) ? (plosiveRms / blockRms) : 0.0f;
        float plosiveScore = 0.0f;
        if (crestFactor > 2.4f && blockRms > 0.0005f) {
            plosiveScore = std::clamp((crestFactor - 2.4f) * 0.35f + plosiveRatio * 0.30f, 0.0f, 1.0f);
        }
        outFeatures[kSLFeaturePlosiveTransientEnergy] = plosiveScore;

        // [2] Sibilant Energy at 6.8 kHz dBFS (Cytomic ZDF SVF)
        const float sibilantRms = std::sqrt(sumSqSibilant * invN);
        const float sibilantDb = std::clamp(fastLinearToDb(sibilantRms), -90.0f, 0.0f);
        outFeatures[kSLFeatureSibilantEnergyDb] = sibilantDb;

        // [3] Vocal Presence at 2.2 kHz dBFS
        const float presenceRms = std::sqrt(sumSqPresence * invN);
        const float presenceDb = std::clamp(fastLinearToDb(presenceRms), -90.0f, 0.0f);
        outFeatures[kSLFeatureVocalPresenceDb] = presenceDb;

        // [4] Silence Duration & [5] Syllabic Pause Bloom Confidence
        constexpr float kSpeechThresholdDb = -48.0f;
        if (vocalRmsDb > kSpeechThresholdDb) {
            // Actively singing/speaking
            silenceTimerSec = 0.0f;
            wasSinging = true;
            phraseEndingProb = 0.0f;
        } else {
            // In a pause or silence
            silenceTimerSec += blockDurationSec;

            if (wasSinging) {
                // Syllabic pause window: sweet spot is 30ms to 700ms after active singing
                if (silenceTimerSec >= 0.03f && silenceTimerSec <= 1.4f) {
                    float bloomNorm = 1.0f;
                    if (silenceTimerSec < 0.09f) {
                        bloomNorm = (silenceTimerSec - 0.03f) / (0.09f - 0.03f);
                    } else if (silenceTimerSec > 0.70f) {
                        bloomNorm = std::max(0.0f, 1.0f - (silenceTimerSec - 0.70f) / 0.70f);
                    }
                    phraseEndingProb = std::clamp(bloomNorm, 0.0f, 1.0f);
                } else if (silenceTimerSec > 1.6f) {
                    // Prolonged silence: reset singing state
                    wasSinging = false;
                    phraseEndingProb = 0.0f;
                } else {
                    phraseEndingProb = 0.0f;
                }
            } else {
                phraseEndingProb = 0.0f;
            }
        }
        outFeatures[kSLFeatureSilenceDurationSec] = std::clamp(silenceTimerSec, 0.0f, 5.0f);
        outFeatures[kSLFeaturePhraseEndingProb] = phraseEndingProb;

        // [6] Spectral Centroid (Hz)
        const float totalBandEnergy = sumSqPlosive + sumSqPresence + sumSqSibilant + sumSqAir + 1.0e-9f;
        const float centroid = (sumSqPlosive * 180.0f + sumSqPresence * 2200.0f + sumSqSibilant * 6800.0f + sumSqAir * 11000.0f) / totalBandEnergy;
        const float smoothedCentroid = 0.8f * prevCentroid + 0.2f * centroid;
        prevCentroid = smoothedCentroid;
        outFeatures[kSLFeatureSpectralCentroidHz] = std::clamp(smoothedCentroid, 200.0f, 12000.0f);

        // [7] Spectral Flux (Transient energy shifts)
        const std::array<float, 4> curDist = {
            sumSqPlosive / totalBandEnergy,
            sumSqPresence / totalBandEnergy,
            sumSqSibilant / totalBandEnergy,
            sumSqAir / totalBandEnergy
        };
        float flux = 0.0f;
        for (size_t b = 0; b < 4; ++b) {
            const float diff = curDist[b] - prevEnergyDistribution[b];
            if (diff > 0.0f) flux += diff;
        }
        prevEnergyDistribution = curDist;
        outFeatures[kSLFeatureSpectralFlux] = std::clamp(flux * 5.0f, 0.0f, 10.0f);

        // [8] Sidechain Beat RMS & [9] Sidechain Clash
        if (hasSidechain) {
            const float scRms = std::sqrt(sumSqSidechain * invN);
            const float scRmsDb = std::clamp(fastLinearToDb(scRms), -90.0f, 0.0f);
            outFeatures[kSLFeatureSidechainBeatRmsDb] = scRmsDb;

            const float clashDb = scRmsDb - vocalRmsDb;
            outFeatures[kSLFeatureSidechainClash] = std::clamp((clashDb + 12.0f) / 24.0f, 0.0f, 1.0f);
        } else {
            outFeatures[kSLFeatureSidechainBeatRmsDb] = -90.0f;
            outFeatures[kSLFeatureSidechainClash] = 0.0f;
        }
    }

private:
    float sr = 44100.0f;
    float rmsAttackCoeff = 0.05f;
    float rmsReleaseCoeff = 0.01f;

    ZDFSVF64 svfPlosiveLow;
    ZDFSVF64 svfPresence;
    ZDFSVF64 svfSibilant;
    ZDFSVF64 svfAir;
    ZDFSVF64 svfSidechainKick;

    // Sub-acoustic DC Blocker (<15 Hz) to immunize feature extraction from mic/preamp DC bias
    double dcBlockX1 = 0.0;
    double dcBlockY1 = 0.0;

    float smoothedVocalRms = 0.00001f;
    float silenceTimerSec = 0.0f;
    bool  wasSinging = false;
    float phraseEndingProb = 0.0f;
    float prevCentroid = 1000.0f;
    std::array<float, 4> prevEnergyDistribution{ 0.25f, 0.25f, 0.25f, 0.25f };
};

// =============================================================================
// SpaceLuxeNeuralInferenceEngine
// Ultra-fast 2-Layer Neural Brain:
// Dense 10 -> 16 (GELU) + GRU-12 Recurrent Memory Cell + Output 12 -> 5 (Sigmoid).
// Bounded studio audio mappings, zero heap allocations, sub-microsecond inference.
// =============================================================================
class SpaceLuxeNeuralInferenceEngine {
public:
    static constexpr size_t kNumInputs = kNumSpaceLuxeFeatures;
    static constexpr size_t kNumL1 = 16;
    static constexpr size_t kNumGruHidden = 12;
    static constexpr size_t kNumOutputs = kNumSpaceLuxePredictions;

    SpaceLuxeNeuralInferenceEngine() noexcept {
        reset();
    }

    void reset() noexcept {
        gruHiddenState.fill(0.0f);
        lastPredictions.fill(0.0f);
        lastPredictions[kSLPredStereoWidthBloom] = 1.0f;
        lastPredictions[kSLPredAdaptivePreDelayMs] = 15.0f;
    }

    static inline float fastSigmoid(float x) noexcept {
        if (x >= 16.0f) return 1.0f;
        if (x <= -16.0f) return 0.0f;
        return 1.0f / (1.0f + fastExp(-x));
    }

    static inline float fastGelu(float x) noexcept {
        if (x < -4.0f) return 0.0f;
        if (x > 4.0f) return x;
        constexpr float kSqrt2OverPi = 0.7978845608f;
        const float inner = kSqrt2OverPi * (x + 0.044715f * x * x * x);
        return 0.5f * x * (1.0f + fastTanh(inner));
    }

    void infer(const std::array<float, kNumInputs>& features,
               std::array<float, kNumOutputs>& outPredictions) noexcept
    {
        // ---------------------------------------------------------------------
        // 0. Feature Normalization: (feature - mean) * invScale
        // ---------------------------------------------------------------------
        std::array<float, kNumInputs> normFeat;
        for (size_t i = 0; i < kNumInputs; ++i) {
            normFeat[i] = (features[i] - spaceluxe_weights::kFeatureMeans[i]) * spaceluxe_weights::kFeatureInvScales[i];
        }

        // ---------------------------------------------------------------------
        // 1. Layer 1: Dense 10 -> 16 with FastGELU
        // ---------------------------------------------------------------------
        std::array<float, kNumL1> y1;
        for (size_t j = 0; j < kNumL1; ++j) {
            float sum = spaceluxe_weights::kLayer1Bias[j];
            const auto& rowW = spaceluxe_weights::kLayer1Weights[j];
            for (size_t i = 0; i < kNumInputs; ++i) {
                sum += rowW[i] * normFeat[i];
            }
            y1[j] = fastGelu(sum);
        }

        // ---------------------------------------------------------------------
        // 2. Layer 2: GRU-12 Recurrent Cell
        // ---------------------------------------------------------------------
        // Reset gate: r = sigmoid(Wr * y1 + Ur * h_prev + br)
        std::array<float, kNumGruHidden> r;
        for (size_t j = 0; j < kNumGruHidden; ++j) {
            float sum = spaceluxe_weights::kGruBiasR[j];
            sum += spaceluxe_weights::kGruWeightsUrDiag[j] * gruHiddenState[j];
            const auto& rowWr = spaceluxe_weights::kGruWeightsWr[j];
            for (size_t k = 0; k < kNumL1; ++k) {
                sum += rowWr[k] * y1[k];
            }
            r[j] = fastSigmoid(sum);
        }

        // Update gate: z = sigmoid(Wz * y1 + Uz * h_prev + bz)
        std::array<float, kNumGruHidden> z;
        for (size_t j = 0; j < kNumGruHidden; ++j) {
            float sum = spaceluxe_weights::kGruBiasZ[j];
            sum += spaceluxe_weights::kGruWeightsUzDiag[j] * gruHiddenState[j];
            const auto& rowWz = spaceluxe_weights::kGruWeightsWz[j];
            for (size_t k = 0; k < kNumL1; ++k) {
                sum += rowWz[k] * y1[k];
            }
            z[j] = fastSigmoid(sum);
        }

        // Candidate hidden state: h_cand = tanh(Wh * y1 + Uh * (r * h_prev) + bh)
        std::array<float, kNumGruHidden> hCand;
        for (size_t j = 0; j < kNumGruHidden; ++j) {
            float sum = spaceluxe_weights::kGruBiasH[j];
            const float rH = r[j] * gruHiddenState[j];
            sum += spaceluxe_weights::kGruWeightsUhDiag[j] * rH;
            const auto& rowWh = spaceluxe_weights::kGruWeightsWh[j];
            for (size_t k = 0; k < kNumL1; ++k) {
                sum += rowWh[k] * y1[k];
            }
            hCand[j] = fastTanh(sum);
        }

        // New hidden state: h_t = (1 - z) * h_prev + z * h_cand
        for (size_t j = 0; j < kNumGruHidden; ++j) {
            gruHiddenState[j] = (1.0f - z[j]) * gruHiddenState[j] + z[j] * hCand[j];
        }

        // ---------------------------------------------------------------------
        // 3. Layer 3: Output Projection 12 -> 5
        // ---------------------------------------------------------------------
        std::array<float, kNumOutputs> u;
        for (size_t k = 0; k < kNumOutputs; ++k) {
            float sum = spaceluxe_weights::kOutputBias[k];
            const auto& rowWout = spaceluxe_weights::kOutputWeights[k];
            for (size_t j = 0; j < kNumGruHidden; ++j) {
                sum += rowWout[j] * gruHiddenState[j];
            }
            u[k] = sum;
        }

        // ---------------------------------------------------------------------
        // 4. Physical Studio Mappings (Bounded Sigmoids)
        // ---------------------------------------------------------------------
        // [0] predictedDuckDb: Dynamic VCA ducking [0.0 to 18.0 dB]
        outPredictions[kSLPredDuckingGainDb] = 18.0f * fastSigmoid(u[kSLPredDuckingGainDb]);

        // [1] tailBloomDb: Syllabic tail bloom boost [0.0 to +6.0 dB]
        outPredictions[kSLPredTailBloomDb] = 6.0f * fastSigmoid(u[kSLPredTailBloomDb]);

        // [2] stereoWidthBloom: Stereo width expansion [1.0x to 1.8x]
        outPredictions[kSLPredStereoWidthBloom] = 1.0f + 0.8f * fastSigmoid(u[kSLPredStereoWidthBloom]);

        // [3] antiSplashCutDb: Pre-tank 6.8 kHz sibilance cut [0.0 to 12.0 dB]
        outPredictions[kSLPredAntiSplashCutDb] = 12.0f * fastSigmoid(u[kSLPredAntiSplashCutDb]);

        // [4] adaptivePreDelayMs: Adaptive pre-delay [0.0 to 30.0 ms]
        outPredictions[kSLPredAdaptivePreDelayMs] = 30.0f * fastSigmoid(u[kSLPredAdaptivePreDelayMs]);

        // ---------------------------------------------------------------------
        // 5. Physical Safety & Silence Domain Protections
        // ---------------------------------------------------------------------
        const float vocalRmsDb = features[kSLFeatureVocalInputRmsDb];
        const float silenceSec = features[kSLFeatureSilenceDurationSec];
        const float phraseProb = features[kSLFeaturePhraseEndingProb];

        // Silence protection: if input is digital silence (< -75 dBFS), release ducking and sibilance cuts
        if (vocalRmsDb < -75.0f) {
            outPredictions[kSLPredDuckingGainDb] = 0.0f;
            outPredictions[kSLPredAntiSplashCutDb] = 0.0f;

            // If silence is prolonged (> 1.5 seconds), smoothly decay tail bloom and reset width
            if (silenceSec > 1.5f) {
                outPredictions[kSLPredTailBloomDb] = 0.0f;
                outPredictions[kSLPredStereoWidthBloom] = 1.0f;
            }
        }

        // Syllabic Tail Bloom and Stereo Width only activate when a phrase ending bloom is detected
        if (phraseProb <= 0.01f) {
            outPredictions[kSLPredTailBloomDb] = 0.0f;
            outPredictions[kSLPredStereoWidthBloom] = 1.0f;
        }

        // Active singing protection: while singing actively (> -42 dBFS), hold back tail bloom
        if (vocalRmsDb > -42.0f && phraseProb < 0.20f) {
            outPredictions[kSLPredTailBloomDb] = 0.0f;
            outPredictions[kSLPredStereoWidthBloom] = 1.0f;
        }

        // Sibilance protection: if 6.8 kHz energy is below threshold, anti-splash remains completely inactive
        if (features[kSLFeatureSibilantEnergyDb] < -40.0f) {
            outPredictions[kSLPredAntiSplashCutDb] = 0.0f;
        }

        // Sidechain beat protection: if no sidechain connected or silent, zero out sidechain ducking influence
        if (features[kSLFeatureSidechainBeatRmsDb] < -75.0f && vocalRmsDb < -75.0f) {
            outPredictions[kSLPredDuckingGainDb] = 0.0f;
        }

        lastPredictions = outPredictions;
    }

    const std::array<float, kNumGruHidden>& getHiddenState() const noexcept {
        return gruHiddenState;
    }

private:
    std::array<float, kNumGruHidden> gruHiddenState{};
    std::array<float, kNumOutputs> lastPredictions{};
};

// =============================================================================
// SpaceLuxeNeuralBrain
// Top-Level Orchestrator combining Feature Extraction, Neural Inference,
// Lock-free Double-buffered Seqlock Snapshots for 60 FPS GUI, and zero allocations.
// =============================================================================
class SpaceLuxeNeuralBrain {
public:
    SpaceLuxeNeuralBrain() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 0.0 ? sampleRate : 44100.0;
        featureExtractor.prepare(sr);
        inferenceEngine.reset();
        reset();
    }

    void reset() noexcept {
        featureExtractor.reset();
        inferenceEngine.reset();
        inferenceCount.store(0, std::memory_order_relaxed);
        lastInferenceTimeUs.store(0.0f, std::memory_order_relaxed);

        for (auto& f : atomicFeatures) f.store(0.0f, std::memory_order_relaxed);
        atomicFeatures[kSLFeatureVocalInputRmsDb].store(-90.0f, std::memory_order_relaxed);
        atomicFeatures[kSLFeatureSibilantEnergyDb].store(-90.0f, std::memory_order_relaxed);
        atomicFeatures[kSLFeatureVocalPresenceDb].store(-90.0f, std::memory_order_relaxed);
        atomicFeatures[kSLFeatureSidechainBeatRmsDb].store(-90.0f, std::memory_order_relaxed);
        atomicFeatures[kSLFeatureSpectralCentroidHz].store(1000.0f, std::memory_order_relaxed);

        for (auto& p : atomicPredictions) p.store(0.0f, std::memory_order_relaxed);
        atomicPredictions[kSLPredStereoWidthBloom].store(1.0f, std::memory_order_relaxed);
        atomicPredictions[kSLPredAdaptivePreDelayMs].store(15.0f, std::memory_order_relaxed);

        seqlock.store(0, std::memory_order_relaxed);
        telemetryBuffers[0] = SpaceLuxeBrainTelemetry{};
        telemetryBuffers[1] = SpaceLuxeBrainTelemetry{};
    }

    // Audio thread: Full stereo vocal analysis & neural inference with optional sidechain
    void analyzeAndInfer(const float* vocalL, const float* vocalR,
                         const float* sidechainL, const float* sidechainR,
                         int numSamples) noexcept
    {
        if (numSamples <= 0 || vocalL == nullptr)
            return;

        const auto startTime = std::chrono::high_resolution_clock::now();

        // 1. Extract 10 physical features (ZDF SVF filterbank + ballistics + timing)
        std::array<float, kNumSpaceLuxeFeatures> features;
        featureExtractor.extractFeatures(vocalL, vocalR, sidechainL, sidechainR, numSamples, features);

        // 2. Run Neural Inference Engine (Dense Layer 1 + GRU-12 + Layer 3 Projection)
        std::array<float, kNumSpaceLuxePredictions> predictions;
        inferenceEngine.infer(features, predictions);

        const auto endTime = std::chrono::high_resolution_clock::now();
        const float elapsedUs = std::chrono::duration<float, std::micro>(endTime - startTime).count();

        // 3. Update Thread-Safe Lock-Free Atomics
        for (size_t i = 0; i < kNumSpaceLuxeFeatures; ++i) {
            atomicFeatures[i].store(features[i], std::memory_order_relaxed);
        }
        for (size_t i = 0; i < kNumSpaceLuxePredictions; ++i) {
            atomicPredictions[i].store(predictions[i], std::memory_order_relaxed);
        }

        const uint64_t count = inferenceCount.fetch_add(1, std::memory_order_relaxed) + 1;
        lastInferenceTimeUs.store(elapsedUs, std::memory_order_relaxed);

        // 4. Update Seqlock Double-Buffered Telemetry Snapshot (Tear-Free GUI Reads)
        SpaceLuxeBrainTelemetry snap;
        snap.features = features;
        snap.predictions = predictions;

        snap.vocalInputRmsDb = features[kSLFeatureVocalInputRmsDb];
        snap.plosiveTransientEnergy = features[kSLFeaturePlosiveTransientEnergy];
        snap.sibilantEnergyDb = features[kSLFeatureSibilantEnergyDb];
        snap.vocalPresenceDb = features[kSLFeatureVocalPresenceDb];
        snap.silenceDurationSec = features[kSLFeatureSilenceDurationSec];
        snap.phraseEndingProb = features[kSLFeaturePhraseEndingProb];
        snap.spectralCentroidHz = features[kSLFeatureSpectralCentroidHz];
        snap.spectralFlux = features[kSLFeatureSpectralFlux];
        snap.sidechainBeatRmsDb = features[kSLFeatureSidechainBeatRmsDb];
        snap.sidechainClash = features[kSLFeatureSidechainClash];

        snap.predictedDuckDb = predictions[kSLPredDuckingGainDb];
        snap.tailBloomDb = predictions[kSLPredTailBloomDb];
        snap.stereoWidthBloom = predictions[kSLPredStereoWidthBloom];
        snap.antiSplashCutDb = predictions[kSLPredAntiSplashCutDb];
        snap.adaptivePreDelayMs = predictions[kSLPredAdaptivePreDelayMs];
        snap.inferenceCount = count;
        snap.lastInferenceTimeUs = elapsedUs;

        // Seqlock write sequence
        const uint32_t seq = seqlock.load(std::memory_order_relaxed);
        seqlock.store(seq + 1, std::memory_order_release); // Odd = write in progress

        const size_t writeIdx = (seq >> 1) & 1;
        telemetryBuffers[writeIdx] = snap;

        seqlock.store(seq + 2, std::memory_order_release); // Even = stable
    }

    // Audio thread: Stereo vocal without sidechain
    void analyzeAndInfer(const float* vocalL, const float* vocalR, int numSamples) noexcept {
        analyzeAndInfer(vocalL, vocalR, nullptr, nullptr, numSamples);
    }

    // Audio thread: Mono vocal without sidechain
    void analyzeAndInfer(const float* vocalMono, int numSamples) noexcept {
        analyzeAndInfer(vocalMono, nullptr, nullptr, nullptr, numSamples);
    }

    // Audio thread: Mono vocal with mono sidechain
    void analyzeAndInferWithSidechain(const float* vocalMono, const float* sidechainMono, int numSamples) noexcept {
        analyzeAndInfer(vocalMono, nullptr, sidechainMono, nullptr, numSamples);
    }

    // GUI thread: Lock-free snapshot query (60 FPS tear-free)
    // Uses bug-free Seqlock index calculation per requirement 5:
    // const size_t readIdx = ((s1 >> 1) > 0) ? (((s1 >> 1) - 1) & 1) : 0;
    SpaceLuxeBrainTelemetry getTelemetrySnapshot() const noexcept {
        SpaceLuxeBrainTelemetry snapshot;
        uint32_t s1 = 0;
        uint32_t s2 = 0;
        int spins = 0;

        do {
            s1 = seqlock.load(std::memory_order_acquire);
            if (s1 & 1) { // Audio thread is writing, retry
                continue;
            }
            const size_t readIdx = ((s1 >> 1) > 0) ? (((s1 >> 1) - 1) & 1) : 0;
            snapshot = telemetryBuffers[readIdx];
            s2 = seqlock.load(std::memory_order_acquire);
        } while ((s1 != s2 || (s1 & 1)) && ++spins < 8);

        // Fallback: If contention persists, load from individual atomic values
        if (s1 != s2 || (s1 & 1)) {
            for (size_t i = 0; i < kNumSpaceLuxeFeatures; ++i)
                snapshot.features[i] = atomicFeatures[i].load(std::memory_order_relaxed);
            for (size_t i = 0; i < kNumSpaceLuxePredictions; ++i)
                snapshot.predictions[i] = atomicPredictions[i].load(std::memory_order_relaxed);

            snapshot.vocalInputRmsDb = snapshot.features[kSLFeatureVocalInputRmsDb];
            snapshot.plosiveTransientEnergy = snapshot.features[kSLFeaturePlosiveTransientEnergy];
            snapshot.sibilantEnergyDb = snapshot.features[kSLFeatureSibilantEnergyDb];
            snapshot.vocalPresenceDb = snapshot.features[kSLFeatureVocalPresenceDb];
            snapshot.silenceDurationSec = snapshot.features[kSLFeatureSilenceDurationSec];
            snapshot.phraseEndingProb = snapshot.features[kSLFeaturePhraseEndingProb];
            snapshot.spectralCentroidHz = snapshot.features[kSLFeatureSpectralCentroidHz];
            snapshot.spectralFlux = snapshot.features[kSLFeatureSpectralFlux];
            snapshot.sidechainBeatRmsDb = snapshot.features[kSLFeatureSidechainBeatRmsDb];
            snapshot.sidechainClash = snapshot.features[kSLFeatureSidechainClash];

            snapshot.predictedDuckDb = snapshot.predictions[kSLPredDuckingGainDb];
            snapshot.tailBloomDb = snapshot.predictions[kSLPredTailBloomDb];
            snapshot.stereoWidthBloom = snapshot.predictions[kSLPredStereoWidthBloom];
            snapshot.antiSplashCutDb = snapshot.predictions[kSLPredAntiSplashCutDb];
            snapshot.adaptivePreDelayMs = snapshot.predictions[kSLPredAdaptivePreDelayMs];
            snapshot.inferenceCount = inferenceCount.load(std::memory_order_relaxed);
            snapshot.lastInferenceTimeUs = lastInferenceTimeUs.load(std::memory_order_relaxed);
        }

        return snapshot;
    }

    // Direct Lock-Free Atomic Queries for DSP Audio Thread
    float getPredictedDuckDb() const noexcept {
        return atomicPredictions[kSLPredDuckingGainDb].load(std::memory_order_relaxed);
    }
    float getPredictedDuckGainLinear() const noexcept {
        const float duckDb = getPredictedDuckDb();
        return fastDbToLinear(-duckDb);
    }

    float getTailBloomDb() const noexcept {
        return atomicPredictions[kSLPredTailBloomDb].load(std::memory_order_relaxed);
    }
    float getTailBloomGainLinear() const noexcept {
        const float bloomDb = getTailBloomDb();
        return fastDbToLinear(bloomDb);
    }

    float getStereoWidthBloom() const noexcept {
        return atomicPredictions[kSLPredStereoWidthBloom].load(std::memory_order_relaxed);
    }

    float getAntiSplashCutDb() const noexcept {
        return atomicPredictions[kSLPredAntiSplashCutDb].load(std::memory_order_relaxed);
    }
    float getAntiSplashCutGainLinear() const noexcept {
        const float cutDb = getAntiSplashCutDb();
        return fastDbToLinear(-cutDb);
    }

    float getAdaptivePreDelayMs() const noexcept {
        return atomicPredictions[kSLPredAdaptivePreDelayMs].load(std::memory_order_relaxed);
    }
    float getAdaptivePreDelaySamples(double sampleRate) const noexcept {
        const double rate = sampleRate > 0.0 ? sampleRate : 44100.0;
        return static_cast<float>(getAdaptivePreDelayMs() * 0.001 * rate);
    }

    uint64_t getInferenceCount() const noexcept {
        return inferenceCount.load(std::memory_order_relaxed);
    }
    float getLastInferenceTimeUs() const noexcept {
        return lastInferenceTimeUs.load(std::memory_order_relaxed);
    }

private:
    double sr = 44100.0;

    SpaceLuxeFeatureExtractor featureExtractor;
    SpaceLuxeNeuralInferenceEngine inferenceEngine;

    // Direct atomic telemetry
    std::array<std::atomic<float>, kNumSpaceLuxeFeatures> atomicFeatures{};
    std::array<std::atomic<float>, kNumSpaceLuxePredictions> atomicPredictions{};
    std::atomic<uint64_t> inferenceCount{0};
    std::atomic<float> lastInferenceTimeUs{0.0f};

    // Double-buffered Seqlock
    alignas(64) std::atomic<uint32_t> seqlock{0};
    alignas(64) std::array<SpaceLuxeBrainTelemetry, 2> telemetryBuffers{};
};

} // namespace dsp171
