#pragma once

#include <cmath>
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include "Common.h"
#include "FastMath.h"
#include "PolyphaseOversampler.h"
#include "AcousticThermalDiodeClipper.h"
#include "TransDetailMatrix.h"
#include "SafetyCeiling.h"
#include "ZDFSVF.h"
#include "DCBlocker.h"

namespace dsp171 {

// =============================================================================
// 171PerfectClipEngine
// Master Audio Engine for 171PerfectClip VST3 / AU / Standalone
//
// Unifies:
// 1. Multi-Topology 4x Polyphase Oversampled Clipping:
//    - Precision Digital (Piecewise Hard Clip + C2 Quintic/Quadratic Soft Knee)
//    - Gold Converter 122 (Lavry Gold 122-96 ADC with JFET H2 and Thermal Sag)
//    - Tube Triode Class-A (Single-Ended Class-A Triode with Asymmetric Saturation & Zero Volume Drop)
//    - Germanium Diode (Vintage 1N34A Point-Contact Hyperbolic Conduction Knee)
// 2. 171 TransDetail™ Matrix: Phase-locked transient preservation & Alchemy Air.
// 3. Continuously Variable Soft Knee [0% (Brickwall) to 100% (Pure Smooth C2)].
// 4. Stereo & Mid/Side Processing with Sub-Bass Mono-Maker (< 80 Hz).
// 5. ITU-R BS.1770-4 Compliant True-Peak / Inter-Sample Peak Safety Ceiling.
// 6. Delta Audition Mode (solo shaved transient peaks).
// 7. 60 FPS Lock-Free Atomic Telemetry & Bipolar Scope Ringbuffer.
// =============================================================================

enum class ClipperMode : uint32_t {
    PrecisionDigital = 0, // Analytical Piecewise Hard Clip with C2 Soft Knee (Max RMS)
    GoldConverter122,     // Lavry Gold 122-96 ADC Dynamic Soft Knee & Harmonic Mojo
    TubeTriodeClassA,     // Asymmetric Class-A Tube Warmth (Single-Ended Triode)
    GermaniumDiode        // Organic Germanium 1N34A Diode Knee (Punchy & Gritty)
};

enum class ChannelRouting : uint32_t {
    StereoLR = 0,
    MidSideSplit,
    MidOnly,
    SideOnly
};

class PerfectClipEngine {
public:
    static constexpr size_t SCOPE_BUFFER_SIZE = 1024;
    static constexpr size_t OVERSAMPLE_LATENCY = 4; // 4x Polyphase FIR/IIR group delay
    static constexpr size_t ISP_LATENCY = TruePeakLimiter::LookaheadLatency; // 4 samples

    struct TelemetryData {
        float inPeakDbL = -100.0f;
        float inPeakDbR = -100.0f;
        float outPeakDbL = -100.0f;
        float outPeakDbR = -100.0f;
        float maxGainReductionDb = 0.0f;
        float crestFactorDb = 0.0f;
        bool isClippingNow = false;
    };

    struct ScopeSample {
        float inSample;
        float outSample;
        float deltaSample;
        bool clipped;
    };

    PerfectClipEngine() noexcept {
        reset();
    }

    PerfectClipEngine(const PerfectClipEngine&) = delete;
    PerfectClipEngine& operator=(const PerfectClipEngine&) = delete;

    void prepare(double sampleRate, size_t /*maxBlockSize*/ = 512) noexcept {
        sr = (sampleRate > 0.0) ? static_cast<float>(sampleRate) : 44100.0f;

        for (int ch = 0; ch < 2; ++ch) {
            oversamplers[ch].reset();
            goldClippers[ch].prepare(sr * 4.0);
            transDetail[ch].prepare(sr * 4.0); // TransDetail operates in 4x oversampled domain
            dcBlockers[ch].prepare(sr, 5.0f);
            ispLimiters[ch].prepare(sr, 2.0f); // 2 ms transparent release without pumping
            monoMakerFilters[ch].setParameters(monoMakerFreqHz, 0.7071f, sr);
        }

        reset();
    }

    void reset() noexcept {
        for (int ch = 0; ch < 2; ++ch) {
            oversamplers[ch].reset();
            goldClippers[ch].reset();
            transDetail[ch].reset();
            dcBlockers[ch].reset();
            ispLimiters[ch].reset();
            monoMakerFilters[ch].reset();
        }

        inDelayL.fill(0.0f);
        inDelayR.fill(0.0f);
        inDelayIdx = 0;

        deltaDelayL.fill(0.0f);
        deltaDelayR.fill(0.0f);
        deltaDelayIdx = 0;

        scopeRingBuffer.fill({ 0.0f, 0.0f, 0.0f, false });
        scopeWriteIndex.store(0, std::memory_order_relaxed);

        peakInL = 0.0f;
        peakInR = 0.0f;
        peakOutL = 0.0f;
        peakOutR = 0.0f;
        maxGR = 0.0f;
        smoothMeanSq = 0.0f;

        atomicInPeakL.store(0.0f, std::memory_order_relaxed);
        atomicInPeakR.store(0.0f, std::memory_order_relaxed);
        atomicOutPeakL.store(0.0f, std::memory_order_relaxed);
        atomicOutPeakR.store(0.0f, std::memory_order_relaxed);
        atomicMaxGR.store(0.0f, std::memory_order_relaxed);
        atomicCrestFactorDb.store(0.0f, std::memory_order_relaxed);
        isClippingFlag.store(false, std::memory_order_relaxed);
    }

    // --- Audio Parameter Setters ---
    void setInputGainDb(float gainDb) noexcept {
        inGainDb = std::clamp(gainDb, -24.0f, 24.0f);
        inGainLinear = dbToGain(inGainDb);
    }

    void setCeilingDb(float ceilDb) noexcept {
        ceilingDb = std::clamp(ceilDb, -24.0f, 0.0f);
        ceilingLinear = dbToGain(ceilingDb);
    }

    void setOutputGainDb(float gainDb) noexcept {
        outGainDb = std::clamp(gainDb, -24.0f, 24.0f);
        outGainLinear = dbToGain(outGainDb);
    }

    void setClipperMode(ClipperMode mode) noexcept {
        currentMode = mode;
    }

    void setSoftKnee(float knee) noexcept {
        softKnee = std::clamp(knee, 0.0f, 1.0f);
    }

    void setDetailPreservation(float amount) noexcept {
        const float clamped = std::clamp(amount, 0.0f, 1.0f);
        if (std::abs(clamped - detailPreserve) > 1.0e-5f) {
            detailPreserve = clamped;
            for (int ch = 0; ch < 2; ++ch) {
                transDetail[ch].setDetailPreservation(detailPreserve);
            }
        }
    }

    void setAlchemyAirDb(float gainDb) noexcept {
        const float clamped = std::clamp(gainDb, -6.0f, 6.0f);
        if (std::abs(clamped - alchemyAirDb) > 1.0e-4f) {
            alchemyAirDb = clamped;
            for (int ch = 0; ch < 2; ++ch) {
                transDetail[ch].setAlchemyAirDb(alchemyAirDb);
            }
        }
    }

    void setRouting(ChannelRouting routing) noexcept {
        currentRouting = routing;
    }

    void setMonoMaker(bool enable, float freqHz = 80.0f) noexcept {
        const float clampedFreq = std::clamp(freqHz, 20.0f, 300.0f);
        if (enable != monoMakerEnabled || std::abs(clampedFreq - monoMakerFreqHz) > 0.05f) {
            monoMakerEnabled = enable;
            monoMakerFreqHz = clampedFreq;
            for (int ch = 0; ch < 2; ++ch) {
                monoMakerFilters[ch].setParameters(monoMakerFreqHz, 0.7071f, sr);
            }
        }
    }

    void setTruePeakGuard(bool enable) noexcept {
        truePeakGuardEnabled = enable;
    }

    void setDeltaAudition(bool enable) noexcept {
        deltaAudition = enable;
    }

    [[nodiscard]] size_t getLatencySamples() const noexcept {
        return OVERSAMPLE_LATENCY + (truePeakGuardEnabled ? ISP_LATENCY : 0);
    }

    // --- Core Stereo Audio Processing Block ---
    void processBlock(float* leftChannel, float* rightChannel, size_t numSamples) noexcept {
        if (numSamples == 0 || leftChannel == nullptr) return;
        const bool isStereo = (rightChannel != nullptr);

        float blockMaxGR = 0.0f;
        float blockMaxInL = 0.0f;
        float blockMaxInR = 0.0f;
        float blockMaxOutL = 0.0f;
        float blockMaxOutR = 0.0f;
        float blockSumSq = 0.0f;
        bool anyClipping = false;

        size_t writeIdx = scopeWriteIndex.load(std::memory_order_relaxed);

        for (size_t i = 0; i < numSamples; ++i) {
            const float inL = leftChannel[i] * inGainLinear;
            const float inR = isStereo ? (rightChannel[i] * inGainLinear) : inL;

            // Pipeline alignment delay buffer: aligns unclipped input with 4x oversampler delay
            const float alignedInL = inDelayL[inDelayIdx];
            const float alignedInR = inDelayR[inDelayIdx];
            inDelayL[inDelayIdx] = inL;
            inDelayR[inDelayIdx] = inR;
            inDelayIdx = (inDelayIdx + 1) % OVERSAMPLE_LATENCY;

            blockMaxInL = std::max(blockMaxInL, std::abs(inL));
            blockMaxInR = std::max(blockMaxInR, std::abs(inR));

            // 1. Channel Routing (Stereo L/R vs Mid/Side)
            float ch1 = inL;
            float ch2 = inR;

            if (currentRouting != ChannelRouting::StereoLR && isStereo) {
                constexpr float invSqrt2 = 0.7071067811865475f;
                ch1 = (inL + inR) * invSqrt2; // Mid
                ch2 = (inL - inR) * invSqrt2; // Side

                // MonoMaker: highpass filter on Side channel (<80 Hz mono bass)
                if (monoMakerEnabled) {
                    const auto svfOut = monoMakerFilters[1].process(ch2);
                    ch2 = svfOut.hp;
                }
            }

            // 2. Process Channel 1 (Left or Mid)
            bool clippedCh1 = false;
            float grCh1 = 0.0f;
            float out1 = processSingleChannel(ch1, 0, clippedCh1, grCh1);

            // 3. Process Channel 2 (Right or Side)
            bool clippedCh2 = false;
            float grCh2 = 0.0f;
            float out2 = out1;
            if (isStereo) {
                if (currentRouting == ChannelRouting::MidOnly) {
                    out1 = dcBlockers[0].processSample(out1);
                    out2 = dcBlockers[1].processSample(ch2);
                } else if (currentRouting == ChannelRouting::SideOnly) {
                    out1 = dcBlockers[0].processSample(ch1);
                    out2 = processSingleChannel(ch2, 1, clippedCh2, grCh2);
                    out2 = dcBlockers[1].processSample(out2);
                } else if (currentRouting == ChannelRouting::MidSideSplit) {
                    out2 = processSingleChannel(ch2, 1, clippedCh2, grCh2);
                    out1 = dcBlockers[0].processSample(out1);
                    out2 = dcBlockers[1].processSample(out2);
                } else {
                    out2 = processSingleChannel(ch2, 1, clippedCh2, grCh2);
                }
            }

            // 4. MS Decoding back to L/R if needed
            float clippedL = out1;
            float clippedR = out2;

            if (currentRouting != ChannelRouting::StereoLR && isStereo) {
                constexpr float invSqrt2 = 0.7071067811865475f;
                clippedL = (out1 + out2) * invSqrt2;
                clippedR = (out1 - out2) * invSqrt2;
            }

            const bool sampleClipped = (clippedCh1 || clippedCh2);
            if (sampleClipped) anyClipping = true;

            const float sampleGR = std::max(grCh1, grCh2);
            blockMaxGR = std::max(blockMaxGR, sampleGR);

            // 5. Shaved Peak Delta (pure pre-clip minus post-clip material)
            const float diffL = alignedInL - clippedL;
            const float diffR = alignedInR - clippedR;
            float deltaRawL = (std::abs(diffL) > 1.0e-5f) ? diffL : 0.0f;
            float deltaRawR = (std::abs(diffR) > 1.0e-5f) ? diffR : 0.0f;

            // Delta delay compensation to align with ISP lookahead (4 samples)
            const float deltaDelayedL = deltaDelayL[deltaDelayIdx];
            const float deltaDelayedR = deltaDelayR[deltaDelayIdx];
            deltaDelayL[deltaDelayIdx] = deltaRawL;
            deltaDelayR[deltaDelayIdx] = deltaRawR;
            deltaDelayIdx = (deltaDelayIdx + 1) % ISP_LATENCY;

            const float finalDeltaL = truePeakGuardEnabled ? deltaDelayedL : deltaRawL;
            const float finalDeltaR = truePeakGuardEnabled ? deltaDelayedR : deltaRawR;

            // 6. Apply Output Makeup Gain
            float finalL = clippedL * outGainLinear;
            float finalR = clippedR * outGainLinear;

            // 7. DC Blocking for Stereo L/R mode
            if (currentRouting == ChannelRouting::StereoLR) {
                finalL = dcBlockers[0].processSample(finalL);
                if (isStereo) finalR = dcBlockers[1].processSample(finalR);
            }

            // 8. True Peak Inter-Sample Peak Guard (or strict ceiling safety clamp)
            if (truePeakGuardEnabled) {
                if (isStereo) {
                    TruePeakLimiter::processStereoPair(ispLimiters[0], ispLimiters[1], finalL, finalR, finalL, finalR, ceilingDb);
                } else {
                    finalL = ispLimiters[0].processSample(finalL, ceilingDb);
                    finalR = finalL;
                }
            } else {
                if (outGainLinear <= 1.001f && currentRouting != ChannelRouting::MidOnly && currentRouting != ChannelRouting::SideOnly) {
                    finalL = std::clamp(finalL, -ceilingLinear, ceilingLinear);
                    if (isStereo) finalR = std::clamp(finalR, -ceilingLinear, ceilingLinear);
                }
            }

            // 9. Delta Audition Mode (Output = isolated shaved peaks)
            float outSampleL = finalL;
            float outSampleR = finalR;

            if (deltaAudition) {
                outSampleL = finalDeltaL;
                outSampleR = finalDeltaR;
            }

            leftChannel[i] = outSampleL;
            if (isStereo) rightChannel[i] = outSampleR;

            blockMaxOutL = std::max(blockMaxOutL, std::abs(outSampleL));
            blockMaxOutR = std::max(blockMaxOutR, std::abs(outSampleR));

            // 10. Scope Snapshot Streaming (Lock-free triple-ring)
            scopeRingBuffer[writeIdx] = {
                (alignedInL + alignedInR) * 0.5f,
                (outSampleL + outSampleR) * 0.5f,
                (finalDeltaL + finalDeltaR) * 0.5f,
                sampleClipped
            };
            writeIdx = (writeIdx + 1) % SCOPE_BUFFER_SIZE;

            const float sumSq = outSampleL * outSampleL + outSampleR * outSampleR;
            blockSumSq += sumSq;
        }

        scopeWriteIndex.store(writeIdx, std::memory_order_release);

        // Ballistics decay tau = 50 ms
        const float dt = static_cast<float>(numSamples) / sr;
        const float blockDecayAlpha = 1.0f - std::exp(-dt / 0.050f);

        peakInL  = (blockMaxInL  > peakInL)  ? blockMaxInL  : (peakInL  + blockDecayAlpha * (blockMaxInL  - peakInL));
        peakInR  = (blockMaxInR  > peakInR)  ? blockMaxInR  : (peakInR  + blockDecayAlpha * (blockMaxInR  - peakInR));
        peakOutL = (blockMaxOutL > peakOutL) ? blockMaxOutL : (peakOutL + blockDecayAlpha * (blockMaxOutL - peakOutL));
        peakOutR = (blockMaxOutR > peakOutR) ? blockMaxOutR : (peakOutR + blockDecayAlpha * (blockMaxOutR - peakOutR));
        maxGR    = (blockMaxGR   > maxGR)    ? blockMaxGR   : (maxGR    + blockDecayAlpha * (blockMaxGR   - maxGR));

        const float blockMeanSq = blockSumSq / static_cast<float>(numSamples * 2);
        smoothMeanSq += blockDecayAlpha * (blockMeanSq - smoothMeanSq);
        const float rms = std::sqrt(std::max(1.0e-8f, smoothMeanSq));
        const float peak = std::max(peakOutL, peakOutR);
        const float crestFactorDb = std::max(0.0f, gainToDb(peak) - gainToDb(rms));

        // Publish to GUI thread (lock-free)
        atomicInPeakL.store(peakInL, std::memory_order_relaxed);
        atomicInPeakR.store(peakInR, std::memory_order_relaxed);
        atomicOutPeakL.store(peakOutL, std::memory_order_relaxed);
        atomicOutPeakR.store(peakOutR, std::memory_order_relaxed);
        atomicMaxGR.store(maxGR, std::memory_order_relaxed);
        atomicCrestFactorDb.store(crestFactorDb, std::memory_order_relaxed);
        isClippingFlag.store(anyClipping, std::memory_order_relaxed);
    }

    [[nodiscard]] TelemetryData getTelemetry() const noexcept {
        TelemetryData d;
        d.inPeakDbL = gainToDb(std::max(1.0e-5f, atomicInPeakL.load(std::memory_order_relaxed)));
        d.inPeakDbR = gainToDb(std::max(1.0e-5f, atomicInPeakR.load(std::memory_order_relaxed)));
        d.outPeakDbL = gainToDb(std::max(1.0e-5f, atomicOutPeakL.load(std::memory_order_relaxed)));
        d.outPeakDbR = gainToDb(std::max(1.0e-5f, atomicOutPeakR.load(std::memory_order_relaxed)));
        d.maxGainReductionDb = atomicMaxGR.load(std::memory_order_relaxed);
        d.isClippingNow = isClippingFlag.load(std::memory_order_relaxed);
        d.crestFactorDb = atomicCrestFactorDb.load(std::memory_order_relaxed);
        return d;
    }

    void copyScopeSnapshot(std::array<ScopeSample, SCOPE_BUFFER_SIZE>& dest) const noexcept {
        const size_t currentWrite = scopeWriteIndex.load(std::memory_order_acquire);
        for (size_t i = 0; i < SCOPE_BUFFER_SIZE; ++i) {
            const size_t srcIdx = (currentWrite + i) % SCOPE_BUFFER_SIZE;
            dest[i] = scopeRingBuffer[srcIdx];
        }
    }

private:
    // Core Topology Transfer Functions with Mathematical Precision & Zero Volume Drop
    static inline float clipTopology(float x, float T, ClipperMode mode, float softKnee, AcousticThermalDiodeClipper& goldClipper) noexcept {
        const float ax = std::abs(x);
        if (ax <= 1.0e-9f) return x;

        switch (mode) {
            case ClipperMode::PrecisionDigital: {
                // Analytical Hard Clip with continuous C2 Soft Knee
                const float w = softKnee * 0.5f * T;
                if (w < 1.0e-4f * T) {
                    return (ax > T) ? ((x > 0.0f) ? T : -T) : x;
                }
                const float xk = T - w;
                if (ax <= xk) return x;
                if (ax >= T + w) return (x > 0.0f) ? T : -T;
                const float delta = ax - xk;
                const float y = xk + delta * (1.0f - delta / (4.0f * w));
                return (x > 0.0f) ? y : -y;
            }

            case ClipperMode::GoldConverter122: {
                // Lavry Gold 122-96 ADC Authentic Physical Emulation:
                // Linear up to -1.7 dBFS (0.82 * T) with dynamic thermal memory sag & JFET H2
                goldClipper.setDiodeProfile(AcousticThermalDiodeClipper::DiodeProfile::Silicon_1N4148);
                return goldClipper.processSample(x, T, true);
            }

            case ClipperMode::TubeTriodeClassA: {
                // Authentic Single-Ended Class-A Triode Vacuum Tube:
                // Asymmetric soft-knee plate saturation / grid cutoff
                // ZERO volume drop! Guaranteed to reach exact +/- T with rich 2nd harmonic warmth.
                const float xPos = 0.58f * T;
                const float xNeg = 0.72f * T;
                if (x >= -xNeg && x <= xPos) {
                    // Class-A linear swing with subtle 2nd-harmonic tube glow
                    const float h2 = 0.015f * (x * x / T) * (1.0f - ax / T);
                    return x + h2;
                }
                if (x > xPos) {
                    const float S = T - xPos;
                    const float delta = x - xPos;
                    return xPos + S * std::tanh(delta / S);
                } else {
                    const float S = T - xNeg;
                    const float delta = -x - xNeg;
                    return -(xNeg + S * std::tanh(delta / S));
                }
            }

            case ClipperMode::GermaniumDiode: {
                // Vintage Germanium 1N34A Point-Contact Diode Conduction
                goldClipper.setDiodeProfile(AcousticThermalDiodeClipper::DiodeProfile::Germanium_1N34A);
                return goldClipper.processSample(x, T, true);
            }
        }
        return x;
    }

    // Process a single channel through 4x Polyphase Oversampling + TransDetail + Selected Clipper
    inline float processSingleChannel(float in, int chIdx, bool& outClipped, float& outGR) noexcept {
        const float absIn = std::abs(in);
        outClipped = (absIn > ceilingLinear);

        if (outClipped) {
            outGR = gainToDb(absIn) - ceilingDb;
        } else {
            outGR = 0.0f;
        }

        // 4x Polyphase Half-Band Upsampling
        std::array<float, 4> up4;
        oversamplers[chIdx].upsample(in, up4);

        for (int s = 0; s < 4; ++s) {
            // 1. TransDetail Orthogonal Carrier / Detail Split at 4x
            const auto split = transDetail[chIdx].split(up4[s]);

            // 2. Apply Selected Clipper Topology to Carrier
            const float clippedCarrier = clipTopology(split.carrier, ceilingLinear, currentMode, softKnee, goldClippers[chIdx]);

            // 3. Recombine Carrier and Detail with Dynamic Transient Protection
            up4[s] = transDetail[chIdx].recombine(split.rawIn, clippedCarrier, split.detail, split.transientWeight, ceilingLinear);
        }

        // 4x Polyphase Decimation (>96 dB stopband alias rejection)
        const float out = oversamplers[chIdx].downsample(up4);
        return std::isfinite(out) ? out : 0.0f;
    }

    float sr = 44100.0f;
    float inGainDb = 0.0f;
    float inGainLinear = 1.0f;
    float ceilingDb = 0.0f;
    float ceilingLinear = 1.0f;
    float outGainDb = 0.0f;
    float outGainLinear = 1.0f;
    float softKnee = 0.0f;
    float detailPreserve = 1.0f;
    float alchemyAirDb = 0.0f;
    float monoMakerFreqHz = 80.0f;

    bool monoMakerEnabled = true;
    bool truePeakGuardEnabled = true;
    bool deltaAudition = false;

    ClipperMode currentMode = ClipperMode::PrecisionDigital;
    ChannelRouting currentRouting = ChannelRouting::StereoLR;

    // Channels
    PolyphaseOversampler4x oversamplers[2];
    AcousticThermalDiodeClipper goldClippers[2];
    TransDetailMatrix transDetail[2];
    DCBlocker dcBlockers[2];
    TruePeakLimiter ispLimiters[2];
    ZDFSVF64 monoMakerFilters[2];

    // Oversampler alignment delay buffers (4 samples matching oversampler latency)
    std::array<float, OVERSAMPLE_LATENCY> inDelayL{};
    std::array<float, OVERSAMPLE_LATENCY> inDelayR{};
    size_t inDelayIdx = 0;

    // Delta latency alignment delay buffers (4 samples matching TruePeak lookahead)
    std::array<float, ISP_LATENCY> deltaDelayL{};
    std::array<float, ISP_LATENCY> deltaDelayR{};
    size_t deltaDelayIdx = 0;

    // Telemetry & Scope (Audio-thread local states)
    float peakInL = 0.0f;
    float peakInR = 0.0f;
    float peakOutL = 0.0f;
    float peakOutR = 0.0f;
    float maxGR = 0.0f;
    float smoothMeanSq = 0.0f;

    // Atomic telemetry for lock-free 60 FPS GUI reading
    std::atomic<float> atomicInPeakL{0.0f};
    std::atomic<float> atomicInPeakR{0.0f};
    std::atomic<float> atomicOutPeakL{0.0f};
    std::atomic<float> atomicOutPeakR{0.0f};
    std::atomic<float> atomicMaxGR{0.0f};
    std::atomic<float> atomicCrestFactorDb{0.0f};
    std::atomic<bool> isClippingFlag{false};

    // CRT Oscilloscope Triple Ring-buffer (Audio thread writes, GUI reads)
    std::array<ScopeSample, SCOPE_BUFFER_SIZE> scopeRingBuffer{};
    std::atomic<size_t> scopeWriteIndex{0};
};

} // namespace dsp171
