#pragma once
#include <cmath>
#include <algorithm>
#include <atomic>
#include <array>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include <dsp171/ZDFSVF.h>

namespace dsp171 {

// =============================================================================
// 171 VocalCraft - AI Transient & Consonant Phoneme Detector
// Neural Engine 2.0 Architectural Upgrade
//
// Real-time phoneme extraction separating fast percussive/fricative
// consonants (P, T, K, B, D, G, S, Z, F, V) from sustained harmonic vowels.
// 1. 4D Continuous Phoneme Probability Vector:
//    P(t) = [P_silence, P_vowel, P_plosive, P_sibilant] via temperature softmax (T = 0.85).
// 2. High-Frequency Spectral Flux with Pitch-Snap Spike Guard:
//    Inhibits false transient triggers from rapid vocal pitch transitions or vibrato.
// 3. Style-Conditioned Ballistics:
//    - Trap/Drill (160 BPM): 28 ms fast hold to prevent syllable accumulation.
//    - Hip-Hop: 50 ms punch-through hold.
//    - Pop: 45 ms smooth hold.
//    - R&B: 35 ms gentle micro-hold.
// 4. Strict Zero Heap Allocations & Wait-Free Telemetry.
// =============================================================================
class VocalCraftConsonantDetector {
public:
    VocalCraftConsonantDetector() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 0.0 ? sampleRate : 44100.0;
        hpf.reset();
        hpf.setParameters(2800.0f, 0.707f, static_cast<float>(sr));

        hpfSibilant.reset();
        hpfSibilant.setParameters(5500.0f, 0.707f, static_cast<float>(sr));

        // Time constants
        fastAttackCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.0015 * sr)));  // 1.5ms
        fastReleaseCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.018 * sr)));  // 18ms

        slowAttackCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.015 * sr)));   // 15ms
        slowReleaseCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.120 * sr)));  // 120ms
        zcrSmoothCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.005 * sr)));    // 5ms

        updateHoldSamples();
        reset();
    }

    void reset() noexcept {
        hpf.reset();
        hpfSibilant.reset();
        fastEnv = 0.0f;
        slowEnv = 0.0f;
        sibEnv = 0.0f;
        prevHfSample = 0.0f;
        hfDeltaSmoothed = 0.0f;
        prevSign = 0;
        zcrAccumulator = 0.0f;
        holdCounter = 0;
        smoothedConsonant = 0.0f;
        consonantActivity.store(0.0f, std::memory_order_relaxed);

        phonemeProbs = { 1.0f, 0.0f, 0.0f, 0.0f };
        for (auto& a : atomicPhonemeProbs) a.store(0.0f, std::memory_order_relaxed);
        atomicPhonemeProbs[0].store(1.0f, std::memory_order_relaxed);
    }

    void setStyle(int styleIndex) noexcept {
        currentStyleIndex = std::clamp(styleIndex, 0, 3);
        updateHoldSamples();
    }

    // Process a single sample and return continuous consonant punch weight [0.0, 1.0]
    inline float processSample(float input) noexcept {
        const float absIn = std::abs(input);

        // 1. High-frequency filtering (> 2.8 kHz where plosives and fricatives live)
        const auto outputs = hpf.process(input);
        const float hfSample = outputs.hp;
        const float absHf = std::abs(hfSample);

        // Sibilant band filter (> 5.5 kHz)
        const auto sibOutputs = hpfSibilant.process(input);
        const float absSib = std::abs(sibOutputs.hp);

        // 2. High-Frequency Spectral Flux with Pitch-Snap Spike Guard
        const float rawDelta = std::max(0.0f, absHf - prevHfSample);
        prevHfSample = absHf;
        // Slew guard suppresses isolated micro-spikes from pitch glides
        hfDeltaSmoothed += (rawDelta - hfDeltaSmoothed) * 0.40f;
        const float hfDelta = hfDeltaSmoothed;

        // 3. Zero-Crossing Density
        const int currentSign = (hfSample >= 0.0f) ? 1 : -1;
        const float isZeroCross = (currentSign != prevSign && prevSign != 0) ? 1.0f : 0.0f;
        prevSign = currentSign;

        // Smooth ZCR estimation over ~5ms window
        zcrAccumulator += (isZeroCross - zcrAccumulator) * zcrSmoothCoeff;

        // 4. Multi-Rate Envelopes
        const float targetFast = absHf;
        if (targetFast > fastEnv)
            fastEnv += (targetFast - fastEnv) * fastAttackCoeff;
        else
            fastEnv += (targetFast - fastEnv) * fastReleaseCoeff;

        const float targetSlow = absIn;
        if (targetSlow > slowEnv)
            slowEnv += (targetSlow - slowEnv) * slowAttackCoeff;
        else
            slowEnv += (targetSlow - slowEnv) * slowReleaseCoeff;

        if (absSib > sibEnv)
            sibEnv += (absSib - sibEnv) * fastAttackCoeff;
        else
            sibEnv += (absSib - sibEnv) * fastReleaseCoeff;

        // Transient Crest Ratio: fast HF burst over general broadband body
        const float broadbandFloor = std::max(0.0001f, slowEnv);
        const float transientRatio = fastEnv / broadbandFloor;

        // 5. 4D Continuous Phoneme Logit Computation
        // Logits: [0: Silence, 1: Vowel, 2: Plosive, 3: Sibilant]
        std::array<float, 4> logits{};

        // Silence logit: high when overall energy is low (< -50 dBFS)
        const float inDb = fastLinearToDb(broadbandFloor);
        logits[0] = std::clamp((-45.0f - inDb) * 0.15f, -6.0f, 6.0f);

        // Vowel logit: high when broadband body is strong, but HF flux is low
        const float hfToBodyRatio = fastEnv / broadbandFloor;
        logits[1] = std::clamp((inDb + 40.0f) * 0.10f - hfToBodyRatio * 2.0f, -6.0f, 6.0f);

        // Plosive logit: high transient burst, moderate ZCR
        logits[2] = std::clamp((hfDelta * 8.0f) + (transientRatio - 1.0f) * 1.5f - (zcrAccumulator * 1.2f), -6.0f, 6.0f);

        // Sibilant logit: extreme high frequency (> 5.5 kHz) energy and elevated ZCR
        const float sibRatio = sibEnv / broadbandFloor;
        logits[3] = std::clamp((sibRatio * 2.5f) + (zcrAccumulator * 3.0f) - 1.2f, -6.0f, 6.0f);

        // Temperature Softmax (T = 0.85)
        constexpr float invTemp = 1.0f / 0.85f;
        float maxLogit = std::max({ logits[0], logits[1], logits[2], logits[3] });
        float sumExp = 0.0f;
        std::array<float, 4> expLogits{};
        for (size_t p = 0; p < 4; ++p) {
            expLogits[p] = fastExp((logits[p] - maxLogit) * invTemp);
            sumExp += expLogits[p];
        }
        const float invSumExp = (sumExp > 1.0e-6f) ? (1.0f / sumExp) : 0.25f;
        for (size_t p = 0; p < 4; ++p) {
            phonemeProbs[p] = expLogits[p] * invSumExp;
            atomicPhonemeProbs[p].store(phonemeProbs[p], std::memory_order_relaxed);
        }

        // 6. Composite Consonant Punch Score
        // Consonant burst = Plosive probability + Sibilant probability
        float rawScore = (phonemeProbs[2] * 1.2f) + (phonemeProbs[3] * 0.85f);
        if (fastEnv < 0.003f || slowEnv < 0.002f) {
            rawScore = 0.0f;
        } else {
            rawScore = std::clamp(rawScore, 0.0f, 1.0f);
        }

        // 7. Style-Conditioned Hold Window
        if (rawScore > 0.35f) {
            holdCounter = holdSamplesMax;
        } else if (holdCounter > 0) {
            holdCounter--;
            rawScore = std::max(rawScore, 0.5f);
        }

        // Smooth output to eliminate jagged envelope chatter
        const float smoothCoeff = (rawScore > smoothedConsonant) ? 0.35f : 0.06f;
        smoothedConsonant += (rawScore - smoothedConsonant) * smoothCoeff;

        // Update atomic for 60 FPS GUI telemetry
        consonantActivity.store(smoothedConsonant, std::memory_order_relaxed);

        return smoothedConsonant;
    }

    // Telemetry query for 60 FPS Oscilloscope highlight
    float getConsonantActivity() const noexcept {
        return consonantActivity.load(std::memory_order_relaxed);
    }

    // Get 4D continuous phoneme probabilities: [Silence, Vowel, Plosive, Sibilant]
    std::array<float, 4> getPhonemeProbabilities() const noexcept {
        return {
            atomicPhonemeProbs[0].load(std::memory_order_relaxed),
            atomicPhonemeProbs[1].load(std::memory_order_relaxed),
            atomicPhonemeProbs[2].load(std::memory_order_relaxed),
            atomicPhonemeProbs[3].load(std::memory_order_relaxed)
        };
    }

private:
    void updateHoldSamples() noexcept {
        // Style-specific hold window duration:
        // Style 0 (Hip-Hop): 50 ms
        // Style 1 (Pop): 45 ms
        // Style 2 (Trap/Drill): 28 ms (per producer specs)
        // Style 3 (R&B): 35 ms
        float holdSec = 0.050f;
        switch (currentStyleIndex) {
            case 0: holdSec = 0.050f; break; // Hip-Hop
            case 1: holdSec = 0.045f; break; // Pop
            case 2: holdSec = 0.028f; break; // Trap / Drill
            case 3: holdSec = 0.035f; break; // R&B
            default: holdSec = 0.045f; break;
        }
        holdSamplesMax = std::max(1, static_cast<int>(sr * holdSec));
    }

    double sr = 44100.0;
    int currentStyleIndex = 0;

    ZDFSVF64 hpf;
    ZDFSVF64 hpfSibilant;

    float fastEnv = 0.0f;
    float slowEnv = 0.0f;
    float sibEnv = 0.0f;
    float prevHfSample = 0.0f;
    float hfDeltaSmoothed = 0.0f;
    int prevSign = 0;
    float zcrAccumulator = 0.0f;

    int holdSamplesMax = 1323;
    int holdCounter = 0;
    float smoothedConsonant = 0.0f;

    float fastAttackCoeff = 0.1f;
    float fastReleaseCoeff = 0.01f;
    float slowAttackCoeff = 0.05f;
    float slowReleaseCoeff = 0.001f;
    float zcrSmoothCoeff = 0.01f;

    std::array<float, 4> phonemeProbs{ 1.0f, 0.0f, 0.0f, 0.0f };
    std::array<std::atomic<float>, 4> atomicPhonemeProbs{ 1.0f, 0.0f, 0.0f, 0.0f };

    std::atomic<float> consonantActivity{0.0f};
};

} // namespace dsp171
