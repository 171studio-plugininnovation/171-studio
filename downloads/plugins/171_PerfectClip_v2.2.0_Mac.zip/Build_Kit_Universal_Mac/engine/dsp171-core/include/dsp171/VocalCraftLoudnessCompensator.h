#pragma once
#include <cmath>
#include <algorithm>
#include <atomic>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>

namespace dsp171 {

// =============================================================================
// 171 VocalCraft - Perceptual Auto-Makeup Gain Compensator
//
// Eliminates deceptive loudness differences. Calculates the real-time perceptual
// energy differential between pre-compressed and post-compressed vocal stages,
// and automatically injects exact loudness-matching makeup gain.
//
// The operator hears ONLY the increased punch, control, and density when
// moving the "Compression Amount" knob, with zero volume drops.
// =============================================================================
class VocalCraftLoudnessCompensator {
public:
    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 0.0 ? sampleRate : 44100.0;
        // 180 ms smoothing for perceptual makeup gain (smooth, musical, zero pumping)
        makeupSmoothCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.180 * sr)));
        // 120 ms smoothing for pre/post energy tracking (sample-rate invariant)
        energySmoothCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.120 * sr)));
        // 350 ms graceful decay to unity in pauses (eliminates whisper/breath inflation)
        silenceDecayCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.350 * sr)));
        holdSamplesMax = static_cast<int>(0.250 * sr); // 250 ms hold
        reset();
    }

    void reset() noexcept {
        smoothedPreEnergy = 0.001f;
        smoothedPostEnergy = 0.001f;
        currentMakeupGain = 1.0f;
        targetMakeupGain = 1.0f;
        holdCounter = 0;
        currentMakeupDb.store(0.0f, std::memory_order_relaxed);
    }

    void setAutoMakeupEnabled(bool enabled) noexcept {
        autoMakeupEnabled = enabled;
    }

    // Process sample: given pre-compression sample and post-compression sample,
    // returns the loudness-compensated sample.
    inline float processSample(float preSample, float postSample) noexcept {
        if (!autoMakeupEnabled) {
            currentMakeupDb.store(0.0f, std::memory_order_relaxed);
            return postSample;
        }

        const float absPre = std::abs(preSample);
        const float absPost = std::abs(postSample);

        // Gated energy tracking with hold and pause release (eliminates whisper/breath inflation)
        if (absPre > 0.0158f) {
            holdCounter = holdSamplesMax;
            smoothedPreEnergy += (absPre - smoothedPreEnergy) * energySmoothCoeff;
            smoothedPostEnergy += (absPost - smoothedPostEnergy) * energySmoothCoeff;

            const float ratio = (smoothedPreEnergy + 1e-5f) / (smoothedPostEnergy + 1e-5f);
            // Musical makeup gain clamped up to +6.0 dB (ratio 1.0 to 2.0)
            targetMakeupGain = std::clamp(ratio, 1.0f, 2.0f);
        } else {
            if (holdCounter > 0) {
                --holdCounter;
            } else {
                // Gracefully decay back to unity (1.0 = 0 dB) during pauses
                targetMakeupGain += (1.0f - targetMakeupGain) * silenceDecayCoeff;
            }
        }

        currentMakeupGain += (targetMakeupGain - currentMakeupGain) * makeupSmoothCoeff;

        const float compensated = postSample * currentMakeupGain;

        // Store makeup gain in dB for telemetry
        currentMakeupDb.store(20.0f * std::log10(std::max(1.0f, currentMakeupGain)), std::memory_order_relaxed);

        return compensated;
    }

    // Telemetry getter for GUI
    float getAutoMakeupDb() const noexcept {
        return currentMakeupDb.load(std::memory_order_relaxed);
    }

private:
    double sr = 44100.0;
    bool autoMakeupEnabled = true;

    float smoothedPreEnergy = 0.001f;
    float smoothedPostEnergy = 0.001f;
    float currentMakeupGain = 1.0f;
    float targetMakeupGain = 1.0f;
    float makeupSmoothCoeff = 0.001f;
    float energySmoothCoeff = 0.0005f;
    float silenceDecayCoeff = 0.0002f;
    int holdSamplesMax = 11025;
    int holdCounter = 0;

    std::atomic<float> currentMakeupDb{0.0f};
};

} // namespace dsp171
