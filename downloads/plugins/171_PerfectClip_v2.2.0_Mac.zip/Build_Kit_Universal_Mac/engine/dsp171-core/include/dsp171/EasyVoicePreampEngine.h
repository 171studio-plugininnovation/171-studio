#pragma once

#include <cmath>
#include <algorithm>
#include <array>
#include <cstdint>
#include "Common.h"
#include "NLSSummingDSP.h"
#include "TransformerSaturator.h"
#include "AvalonTubeSaturator.h"
#include "CultureVultureDSP.h"
#include "PABlackBoxHG2.h"
#include "UADStuderA800.h"
#include "DecapitatorDSP.h"
#include "PolyphaseOversampler.h"

namespace dsp171 {

// =============================================================================
// EasyVoicePreampEngine
// Modular Multi-Model Analog Preamp & Distortion Engine for 171EasyVoice
//
// Models:
// 0: Neve 5116       - Vintage British Class-A Console (NLS Nevo + Marinair LO1166)
// 1: SSL 4000G       - Punchy Modern Solid-State Console (NLS Spike VCA precision)
// 2: EMI TG12345     - Abbey Road Harmonic Console (NLS Mike Germanium/Tube hybrid)
// 3: Avalon VT-737sp - High-Voltage Class-A Tube Triode (Child-Langmuir 3/2 power curve)
// 4: Culture Vulture - Thermionic 6AS6 Miniature Pentode / Triode Saturation
// 5: Black Box HG-2  - 6U8A Pentode/Triode Dual Tube Distortion with Air Exciter
// 6: Studer A800     - Legendary 2-Inch Multichannel Master Tape Machine
// 7: Decapitator N   - Neve 1057 Germanium Transistor Input Drive
//
// Key Real-Time Architecture:
// - Dual-Engine Ping-Pong Crossfade (12.5 ms S-curve cosine ramp) for click-free model changes
// - Zero dynamic memory allocations in processBlock() (Hard real-time safe)
// - Polyphase 4x oversampling on high-harmonic tube & distortion models
// - Preserves 100% backward compatibility with legacy preampConsole parameter and presets
// =============================================================================

class EasyVoicePreampEngine {
public:
    enum class PreampModelType : int {
        Neve5116 = 0,         // Vintage British Console (Legacy Index 0)
        SSL4000G = 1,         // Punchy Solid-State Console (Legacy Index 1)
        EMITG12345 = 2,       // Abbey Road Harmonic Console (Legacy Index 2)
        AvalonVT737 = 3,      // High-Voltage Class-A Tube Triode
        CultureVulture = 4,   // 6AS6 Miniature Pentode Saturation
        BlackBoxHG2 = 5,      // 6U8A Pentode/Triode Dual Tube
        StuderA800 = 6,       // 2-Inch Magnetic Tape Machine
        DecapitatorGerm = 7   // Germanium Transistor Drive
    };

    static constexpr int kNumModels = 8;

    static const char* getModelName(PreampModelType type) noexcept {
        switch (type) {
            case PreampModelType::Neve5116:       return "Snow (Neve 5116)";
            case PreampModelType::SSL4000G:       return "SpikeProtein (SSL)";
            case PreampModelType::EMITG12345:     return "Maik (EMI TG12345)";
            case PreampModelType::AvalonVT737:    return "Avalon VT-737 (Tube)";
            case PreampModelType::CultureVulture: return "Culture Vulture (Pentode)";
            case PreampModelType::BlackBoxHG2:    return "Black Box HG-2 (Dual Tube)";
            case PreampModelType::StuderA800:     return "Studer A800 (Tape)";
            case PreampModelType::DecapitatorGerm:return "Decapitator (Germanium)";
            default:                              return "Custom Preamp";
        }
    }

    EasyVoicePreampEngine() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        m_sampleRate = sampleRate > 0.0 ? sampleRate : 44100.0;
        m_crossfadeLengthSamples = static_cast<int>(m_sampleRate * 0.0125); // 12.5 ms
        if (m_crossfadeLengthSamples < 16) m_crossfadeLengthSamples = 16;

        slotA.prepare(m_sampleRate);
        slotB.prepare(m_sampleRate);

        slotA.setModel(currentModel);
        slotB.setModel(currentModel);
        slotA.setParameters(drive, warmth, trimDb);
        slotB.setParameters(drive, warmth, trimDb);

        crossfadeActive = false;
        crossfadeProgress = 0;
        activeSlotIndex = 0; // 0 = slotA, 1 = slotB
    }

    void reset() noexcept {
        slotA.reset();
        slotB.reset();
        crossfadeActive = false;
        crossfadeProgress = 0;
        activeSlotIndex = 0;
    }

    void setModel(PreampModelType newModel, bool immediate = false) noexcept {
        const int modelInt = std::clamp(static_cast<int>(newModel), 0, kNumModels - 1);
        const PreampModelType validatedModel = static_cast<PreampModelType>(modelInt);

        if (validatedModel == currentModel && !immediate) return;

        currentModel = validatedModel;

        if (immediate || m_sampleRate <= 0.0) {
            // Immediate switch without crossfade
            slotA.setModel(currentModel);
            slotA.setParameters(drive, warmth, trimDb);
            slotB.setModel(currentModel);
            slotB.setParameters(drive, warmth, trimDb);
            activeSlotIndex = 0;
            crossfadeActive = false;
            crossfadeProgress = 0;
            return;
        }

        // Ping-Pong switch: configure the inactive slot and start cosine crossfade
        if (activeSlotIndex == 0) {
            // Target is slotB
            slotB.reset();
            slotB.setModel(currentModel);
            slotB.setParameters(drive, warmth, trimDb);
            targetSlotIndex = 1;
        } else {
            // Target is slotA
            slotA.reset();
            slotA.setModel(currentModel);
            slotA.setParameters(drive, warmth, trimDb);
            targetSlotIndex = 0;
        }

        crossfadeProgress = 0;
        crossfadeActive = true;
    }

    void setModelIndex(int idx, bool immediate = false) noexcept {
        setModel(static_cast<PreampModelType>(std::clamp(idx, 0, kNumModels - 1)), immediate);
    }

    [[nodiscard]] PreampModelType getModel() const noexcept {
        return currentModel;
    }

    [[nodiscard]] int getModelIndex() const noexcept {
        return static_cast<int>(currentModel);
    }

    void setParameters(float drive0To12, float warmth0To10, float trimDbVal) noexcept {
        drive = std::clamp(drive0To12, 0.0f, 12.0f);
        warmth = std::clamp(warmth0To10, 0.0f, 10.0f);
        trimDb = std::clamp(trimDbVal, -24.0f, 24.0f);

        slotA.setParameters(drive, warmth, trimDb);
        slotB.setParameters(drive, warmth, trimDb);
    }

    void setDrive(float drive0To12) noexcept {
        setParameters(drive0To12, warmth, trimDb);
    }

    void setWarmth(float warmth0To10) noexcept {
        setParameters(drive, warmth0To10, trimDb);
    }

    void setTrimDb(float trimDbVal) noexcept {
        setParameters(drive, warmth, trimDbVal);
    }

    // Process stereo or dual-mono block
    void process(float* left, float* right, int numSamples) noexcept {
        if (numSamples <= 0 || left == nullptr) return;

        if (!crossfadeActive) {
            // Fast path: direct execution in active slot
            if (activeSlotIndex == 0) {
                slotA.process(left, right, numSamples);
            } else {
                slotB.process(left, right, numSamples);
            }
            return;
        }

        // Crossfade path: copy dry input and render both slots
        constexpr int kSliceSize = 256;
        float dryL[kSliceSize];
        float dryR[kSliceSize];
        float altL[kSliceSize];
        float altR[kSliceSize];

        int samplesRemaining = numSamples;
        int offset = 0;

        while (samplesRemaining > 0) {
            const int chunkSize = std::min(samplesRemaining, kSliceSize);

            if (!crossfadeActive) {
                if (activeSlotIndex == 0) {
                    slotA.process(&left[offset], right ? &right[offset] : nullptr, chunkSize);
                } else {
                    slotB.process(&left[offset], right ? &right[offset] : nullptr, chunkSize);
                }
                offset += chunkSize;
                samplesRemaining -= chunkSize;
                continue;
            }

            // Crossfade is active: save dry input for alternate slot
            for (int i = 0; i < chunkSize; ++i) {
                dryL[i] = left[offset + i];
                dryR[i] = right ? right[offset + i] : left[offset + i];
                altL[i] = dryL[i];
                altR[i] = dryR[i];
            }

            // Process both slots on slice
            if (activeSlotIndex == 0) {
                slotA.process(&left[offset], right ? &right[offset] : nullptr, chunkSize);
                slotB.process(altL, right ? altR : nullptr, chunkSize);
            } else {
                slotB.process(&left[offset], right ? &right[offset] : nullptr, chunkSize);
                slotA.process(altL, right ? altR : nullptr, chunkSize);
            }

            // Perform raised cosine S-curve interpolation
            for (int i = 0; i < chunkSize; ++i) {
                const float t = static_cast<float>(crossfadeProgress) / static_cast<float>(m_crossfadeLengthSamples);
                const float w = 0.5f * (1.0f - std::cos(3.14159265f * t));

                left[offset + i] = left[offset + i] * (1.0f - w) + altL[i] * w;
                if (right) {
                    right[offset + i] = right[offset + i] * (1.0f - w) + altR[i] * w;
                }

                crossfadeProgress++;
                if (crossfadeProgress >= m_crossfadeLengthSamples) {
                    activeSlotIndex = targetSlotIndex;
                    crossfadeActive = false;
                    for (int j = i + 1; j < chunkSize; ++j) {
                        left[offset + j] = altL[j];
                        if (right) right[offset + j] = altR[j];
                    }
                    break;
                }
            }

            offset += chunkSize;
            samplesRemaining -= chunkSize;
        }
    }

private:
    struct PreampSlot {
        PreampModelType modelType{PreampModelType::Neve5116};
        double sampleRate{44100.0};

        NLSSummingDSP nlsPreamp;
        TransformerSaturator marinairSatL;
        TransformerSaturator marinairSatR;
        AvalonTubeSaturator avalonL;
        AvalonTubeSaturator avalonR;
        CultureVultureDSP vultureL;
        CultureVultureDSP vultureR;
        ZDFSVF64 vultureHpL;
        ZDFSVF64 vultureHpR;
        BlackBoxHG2 blackBox;
        UADStuderA800 studerTape;
        DecapitatorDSP decapitator;

        PolyphaseOversampler4x oversamplerL;
        PolyphaseOversampler4x oversamplerR;

        std::array<float, 8> alignDelayL{};
        std::array<float, 8> alignDelayR{};
        int alignDelayIdx{0};

        float drive{0.0f};
        float warmth{0.0f};
        float trimDb{0.0f};

        void prepare(double sr) noexcept {
            sampleRate = sr;
            nlsPreamp.prepare(sr);
            nlsPreamp.setNoise(false); // Disabilita rumore analogico sintetico per evitare fuzz/buzz in catene con alto gain
            marinairSatL.prepare(sr);
            marinairSatR.prepare(sr);

            avalonL.prepare(sr * 4.0);
            avalonR.prepare(sr * 4.0);
            vultureL.prepare(sr * 4.0);
            vultureR.prepare(sr * 4.0);
            vultureHpL.setParameters(15.0f, 0.707f, static_cast<float>(sr * 4.0));
            vultureHpR.setParameters(15.0f, 0.707f, static_cast<float>(sr * 4.0));

            blackBox.prepare(static_cast<float>(sr));
            studerTape.prepare(static_cast<float>(sr));
            decapitator.prepare(sr);

            oversamplerL.reset();
            oversamplerR.reset();
            alignDelayL.fill(0.0f);
            alignDelayR.fill(0.0f);
            alignDelayIdx = 0;
        }

        void reset() noexcept {
            nlsPreamp.reset();
            nlsPreamp.setNoise(false);
            marinairSatL.reset();
            marinairSatR.reset();
            avalonL.reset();
            avalonR.reset();
            vultureL.reset();
            vultureR.reset();
            vultureHpL.reset();
            vultureHpR.reset();
            blackBox.prepare(static_cast<float>(sampleRate));
            studerTape.prepare(static_cast<float>(sampleRate));
            decapitator.reset();
            oversamplerL.reset();
            oversamplerR.reset();
            alignDelayL.fill(0.0f);
            alignDelayR.fill(0.0f);
            alignDelayIdx = 0;
        }

        void setModel(PreampModelType type) noexcept {
            modelType = type;
            switch (modelType) {
                case PreampModelType::Neve5116:
                    nlsPreamp.setConsole(NLSSummingDSP::ConsoleType::Nevo);
                    break;
                case PreampModelType::SSL4000G:
                    nlsPreamp.setConsole(NLSSummingDSP::ConsoleType::Spike);
                    break;
                case PreampModelType::EMITG12345:
                    nlsPreamp.setConsole(NLSSummingDSP::ConsoleType::Mike);
                    break;
                case PreampModelType::CultureVulture: {
                    // Parametri iniziali: setParameters() sovrascriverà subito dopo con valori coerenti
                    // Usiamo già 0.22f qui per coerenza con setParameters (fix v3.1 — anti-halluc insp)
                    const auto vMode = (drive <= 8.5f) ? VultureMode::Triode : VultureMode::Pentode;
                    const float vDrive = (drive / 12.0f) * 3.2f;
                    const float vStarve = (warmth / 10.0f) * 0.22f; // Coerente con setParameters (era 0.08f — BUG)
                    const float vultureCompDb = -0.66f - (drive / 12.0f) * 2.5f - (drive > 8.5f ? 2.5f : 0.0f);
                    vultureL.setParameters(vMode, vDrive, vStarve, 0.0f, false);
                    vultureR.setParameters(vMode, vDrive, vStarve, 0.0f, false);
                    vultureL.setOutput(trimDb + vultureCompDb);
                    vultureR.setOutput(trimDb + vultureCompDb);
                    break;
                }
                case PreampModelType::DecapitatorGerm:
                    decapitator.setStyle(DecapitatorDSP::SatStyle::StyleN);
                    decapitator.setAutoGain(true);
                    break;
                default:
                    break;
            }
        }

        void setParameters(float d, float w, float tDb) noexcept {
            drive = d;
            warmth = w;
            trimDb = tDb;

            // Model 0, 1, 2: NLS Consoles
            nlsPreamp.setDrive(drive);
            nlsPreamp.setTrimDb(trimDb);

            // Model 4: Culture Vulture (Calibrato per Voce: Triode setoso con 2a armonica, Pentode morbido > 8.5)
            if (modelType == PreampModelType::CultureVulture) {
                const auto vMode = (drive <= 8.5f) ? VultureMode::Triode : VultureMode::Pentode;
                const float vultureDrive = (drive / 12.0f) * 3.2f;
                const float starve = (warmth / 10.0f) * 0.22f; // Espanso a 0.22 per reale caduta di griglia 6AS6
                const float vultureCompDb = -0.66f - (drive / 12.0f) * 2.5f - (drive > 8.5f ? 2.5f : 0.0f);
                vultureL.setParameters(vMode, vultureDrive, starve, 0.0f, false);
                vultureR.setParameters(vMode, vultureDrive, starve, 0.0f, false);
                vultureL.setOutput(trimDb + vultureCompDb);
                vultureR.setOutput(trimDb + vultureCompDb);
            }

            // Model 5: Black Box HG-2 (Calibrato per Unity Gain a riposo 0 dB e drive progressivo controllato)
            if (modelType == PreampModelType::BlackBoxHG2) {
                const float pDrive = (drive / 12.0f) * 65.0f;
                const float tDrive = (drive / 12.0f) * 55.0f;
                const float satDrive = (warmth / 10.0f) * 60.0f;
                const float airPercent = (warmth / 10.0f) * 40.0f; // Calibrazione dinamica air band [0%..40%] (neutro a warmth=0)
                blackBox.setParameters(pDrive, tDrive, satDrive, BlackBoxHG2::SaturationFreq::Flat, airPercent, trimDb);
            }

            // Model 6: Studer A800 — Calibrazione livello nominale Ampex 456 @ 250 nWb/m
            // drive=0 -> inDrive=0.0 dB (unity gain perfetto), drive=12 -> inDrive=+12 dB con compensazione automatica
            if (modelType == PreampModelType::StuderA800) {
                const float inDrive = (drive / 12.0f) * 12.0f;
                const float bias = (warmth / 10.0f) * 3.0f;  // 0.0..3.0 -> Underbias to Overbias
                const float tapeCompDb = -1.62f - inDrive * 0.95f;
                studerTape.setParameters(inDrive, trimDb + tapeCompDb, UADStuderA800::TapeSpeed::IPS_15,
                                         UADStuderA800::TapeType::Tape456, bias, 0.0f, 0.0f);
            }

            // Model 7: Decapitator Germanium 1057 (Con Auto-Gain per unity gain calibrato)
            if (modelType == PreampModelType::DecapitatorGerm) {
                decapitator.setStyle(DecapitatorDSP::SatStyle::StyleN);
                decapitator.setAutoGain(true);
                decapitator.setDrive((drive / 12.0f) * 7.5f);
                decapitator.setToneDb((warmth - 5.0f) * 1.0f);
                decapitator.setOutputTrimDb(trimDb);
            }
        }

        inline void process(float* left, float* right, int numSamples) noexcept {
            switch (modelType) {
                case PreampModelType::Neve5116: {
                    nlsPreamp.process(left, right ? right : left, static_cast<size_t>(numSamples));
                    // Discrete Neve Marinair LO1166 Class-A Transformer saturation
                    if (warmth > 0.001f) {
                        const float marinairDrive = 1.0f + (drive / 12.0f) * 1.75f;
                        for (int i = 0; i < numSamples; ++i) {
                            left[i] = marinairSatL.processSample(left[i], marinairDrive, warmth);
                            if (right) right[i] = marinairSatR.processSample(right[i], marinairDrive, warmth);
                        }
                    }
                    alignDelay4Samples(left, right, numSamples);
                    break;
                }

                case PreampModelType::SSL4000G:
                case PreampModelType::EMITG12345: {
                    // Modern Solid-State VCA (SSL) and Abbey Road Germanium (EMI) console modeling
                    // Authentic discrete channel strip circuitry without Neve Marinair contamination
                    nlsPreamp.process(left, right ? right : left, static_cast<size_t>(numSamples));
                    alignDelay4Samples(left, right, numSamples);
                    break;
                }

                case PreampModelType::AvalonVT737: {
                    const float driveDb = (drive / 12.0f) * 18.0f;
                    const float warmth01 = warmth * 0.1f;
                    const float airSheenDb = (warmth / 10.0f) * 2.8f; // Air Sheen a 32 kHz attivato
                    const float trimLin = std::pow(10.0f, trimDb / 20.0f);
                    const float driveCompLin = std::pow(10.0f, -driveDb * 0.88f * 0.05f);

                    std::array<float, 4> upL{}, upR{};
                    for (int i = 0; i < numSamples; ++i) {
                        oversamplerL.upsample(left[i], upL);
                        if (right) oversamplerR.upsample(right[i], upR);

                        for (int k = 0; k < 4; ++k) {
                            upL[k] = avalonL.processSample(upL[k], driveDb, warmth01, airSheenDb);
                            if (right) upR[k] = avalonR.processSample(upR[k], driveDb, warmth01, airSheenDb);
                        }

                        left[i] = oversamplerL.downsample(upL) * trimLin * driveCompLin;
                        if (right) right[i] = oversamplerR.downsample(upR) * trimLin * driveCompLin;
                    }
                    break;
                }

                case PreampModelType::CultureVulture: {
                    std::array<float, 4> upL{}, upR{};
                    for (int i = 0; i < numSamples; ++i) {
                        oversamplerL.upsample(left[i], upL);
                        if (right) oversamplerR.upsample(right[i], upR);

                        for (int k = 0; k < 4; ++k) {
                            upL[k] = vultureHpL.process(upL[k]).hp;
                            if (right) upR[k] = vultureHpR.process(upR[k]).hp;
                            upL[k] = vultureL.processSample(upL[k]);
                            if (right) upR[k] = vultureR.processSample(upR[k]);
                        }

                        left[i] = oversamplerL.downsample(upL);
                        if (right) right[i] = oversamplerR.downsample(upR);
                    }
                    break;
                }

                case PreampModelType::BlackBoxHG2: {
                    // Compensazione baseline di -5.76 dB (0.515 lin) per azzerare il guadagno pentodo+triodo a riposo (0.00 dB)
                    // e compensazione progressiva per mantenere il throughput a unity gain (+/-0.5 dB) su tutta la corsa del drive
                    const float hgComp = 0.491f * std::pow(10.0f, -(drive / 12.0f) * 15.0f * 0.05f);
                    for (int i = 0; i < numSamples; ++i) {
                        float l = left[i];
                        float r = right ? right[i] : left[i];
                        blackBox.process(l, r, left[i], r);
                        left[i] *= hgComp;
                        if (right) right[i] = r * hgComp;
                    }
                    alignDelay4Samples(left, right, numSamples);
                    break;
                }

                case PreampModelType::StuderA800: {
                    for (int i = 0; i < numSamples; ++i) {
                        float l = left[i];
                        float r = right ? right[i] : left[i];
                        studerTape.process(l, r, left[i], r);
                        if (right) right[i] = r;
                    }
                    alignDelay4Samples(left, right, numSamples);
                    break;
                }

                case PreampModelType::DecapitatorGerm: {
                    decapitator.process(left, right ? right : left, static_cast<size_t>(numSamples));
                    alignDelay4Samples(left, right, numSamples);
                    break;
                }
            }
        }

    private:
        inline void alignDelay4Samples(float* left, float* right, int numSamples) noexcept {
            for (int i = 0; i < numSamples; ++i) {
                const int readIdx = (alignDelayIdx + 8 - 4) & 7;
                const float outL = alignDelayL[readIdx];
                const float outR = alignDelayR[readIdx];

                alignDelayL[alignDelayIdx] = left[i];
                alignDelayR[alignDelayIdx] = right ? right[i] : left[i];
                alignDelayIdx = (alignDelayIdx + 1) & 7;

                left[i] = outL;
                if (right) right[i] = outR;
            }
        }
    };

    double m_sampleRate{44100.0};
    int m_crossfadeLengthSamples{550};
    PreampModelType currentModel{PreampModelType::Neve5116};

    float drive{0.0f};
    float warmth{0.0f};
    float trimDb{0.0f};

    PreampSlot slotA;
    PreampSlot slotB;

    int activeSlotIndex{0};
    int targetSlotIndex{0};
    int crossfadeProgress{0};
    bool crossfadeActive{false};
};

} // namespace dsp171
