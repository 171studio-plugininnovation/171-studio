#pragma once
#include <cmath>
#include <algorithm>
#include <array>
#include <cstdint>
#include "Common.h"
#include "ZDFSVF.h"
#include "ZDFTiltFilter.h"
#include "DCBlocker.h"

namespace dsp171 {

// =============================================================================
// Module: DecapitatorDSP
// Orchestrated by: DSPHireManager (171 Studio - Dispatch Ticket #HW-DECAP-02)
// Specialists: sat-tape-modern-specialist & sat-avalon-specialist
// Mathematical Review: dsp-math-bugfinder
// Scalability & Real-Time Audit: dsp-audit-scalability
// Hardware Physics: circuit-hardware-physicist
// Anti-Hallucination Verification: anti-hallucination-audit-agent [VERIFIED - MSVC /O2]
//
// Emulatore Analog Saturation & Drive modellato su Soundtoys Decapitator
// 5 Stili di Saturazione Analogica:
// - Style A: Ampex 350 tape recorder tube preamp (caldo, nastro, saturazione morbida)
// - Style E: EMI TG12345 console channel strip (punchy, aggressivo, ricche armoniche dispari)
// - Style N: Neve 1057 Germanium input stage (transistor al germanio, bias asimmetrico C1-continuo)
// - Style T: Culture Vulture Triode mode (armoniche pari dominanti 2nd harmonic, valvolare setoso)
// - Style P: Culture Vulture Pentode mode (armoniche dispari 3rd/5th harmonic, zanzaroso e tagliente)
// =============================================================================

class DecapitatorDSP {
public:
    enum class SatStyle : uint8_t {
        StyleA = 0, // Ampex 350
        StyleE = 1, // EMI TG12345
        StyleN = 2, // Neve 1057 Germanium
        StyleT = 3, // Triode
        StyleP = 4  // Pentode
    };

    DecapitatorDSP() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        invSr = 1.0f / sr;
        
        lowCutSVF_L.reset();
        lowCutSVF_R.reset();
        highCutSVF_L.reset();
        highCutSVF_R.reset();
        highCut2_L.reset();
        highCut2_R.reset();
        
        tiltFilterL.prepare(sampleRate);
        tiltFilterR.prepare(sampleRate);
        
        dcBlockerL.prepare(sampleRate, 10.0f);
        dcBlockerR.prepare(sampleRate, 10.0f);
        
        updateFilters();
        updateDriveGain();
        reset();
    }

    void reset() noexcept {
        lowCutSVF_L.reset();
        lowCutSVF_R.reset();
        highCutSVF_L.reset();
        highCutSVF_R.reset();
        highCut2_L.reset();
        highCut2_R.reset();
        tiltFilterL.reset();
        tiltFilterR.reset();
        dcBlockerL.reset();
        dcBlockerR.reset();
    }

    void setStyle(SatStyle style) noexcept {
        currentStyle = style;
    }

    void setStyleIndex(int idx) noexcept {
        idx = std::clamp(idx, 0, 4);
        currentStyle = static_cast<SatStyle>(idx);
    }

    void setDrive(float driveNorm0To10) noexcept {
        driveVal = std::clamp(driveNorm0To10, 0.0f, 10.0f);
        updateDriveGain();
    }

    void setPunish(bool enabled) noexcept {
        punish = enabled;
        updateDriveGain();
    }

    void setLowCutHz(float hz) noexcept {
        lowCutHz = std::clamp(hz, 20.0f, 1000.0f);
        updateFilters();
    }

    void setLowCutNormalized(float norm01) noexcept {
        norm01 = std::clamp(norm01, 0.0f, 1.0f);
        setLowCutHz(20.0f * std::pow(50.0f, norm01));
    }

    void setLowThump(bool enabled) noexcept {
        lowThump = enabled;
        updateFilters();
    }

    void setHighCutHz(float hz) noexcept {
        highCutHz = std::clamp(hz, 1000.0f, 20000.0f);
        updateFilters();
    }

    void setHighCutNormalized(float norm01) noexcept {
        norm01 = std::clamp(norm01, 0.0f, 1.0f);
        setHighCutHz(1000.0f * std::pow(20.0f, norm01));
    }

    void setHighSlopeSteep(bool steep) noexcept {
        highSlopeSteep = steep;
        updateFilters();
    }

    void setToneDb(float toneDb) noexcept {
        toneDbVal = std::clamp(toneDb, -12.0f, 12.0f);
        updateFilters();
    }

    void setToneNormalized(float norm01) noexcept {
        norm01 = std::clamp(norm01, 0.0f, 1.0f);
        setToneDb(-12.0f + 24.0f * norm01);
    }

    void setAutoGain(bool enabled) noexcept {
        autoGain = enabled;
        updateDriveGain();
    }

    void setMixPercent(float mixPct) noexcept {
        mix = std::clamp(mixPct * 0.01f, 0.0f, 1.0f);
    }

    void setMixNormalized(float norm01) noexcept {
        mix = std::clamp(norm01, 0.0f, 1.0f);
    }

    void setOutputTrimDb(float trimDb) noexcept {
        trimDbVal = std::clamp(trimDb, -24.0f, 12.0f);
        outputTrimGain = std::pow(10.0f, trimDbVal * 0.05f);
    }

    void setOutputTrimNormalized(float norm01) noexcept {
        norm01 = std::clamp(norm01, 0.0f, 1.0f);
        setOutputTrimDb(-24.0f + 36.0f * norm01);
    }

    // --- Processing Block with Mono-Safe Buffer Protection ---
    void process(float* inOutL, float* inOutR, size_t numSamples) noexcept {
        if (!inOutL || numSamples == 0) return;
        const bool isMono = (inOutR == nullptr || inOutR == inOutL);

        for (size_t i = 0; i < numSamples; ++i) {
            const float dryL = inOutL[i];
            const float dryR = isMono ? dryL : inOutR[i];

            // 1. Pre-Filtering (Low-Cut con Thump opzionale)
            float sL = lowCutSVF_L.process(dryL).hp;
            float sR = isMono ? sL : lowCutSVF_R.process(dryR).hp;

            // 2. Pre-Gain / Drive Stage
            sL *= inputDriveGain;
            sR *= inputDriveGain;

            // 3. Nonlinear Waveshaping (5 stili analogici hardware-calibrati)
            sL = shapeStyle(sL, currentStyle);
            sR = isMono ? sL : shapeStyle(sR, currentStyle);

            // 4. DC Offset Blocker post saturazione asimmetrica
            sL = dcBlockerL.processSample(sL);
            sR = isMono ? sL : dcBlockerR.processSample(sR);

            // 5. Tone Tilt Filter (Baxandall Pivot a 250 Hz)
            sL = tiltFilterL.processSample(sL);
            sR = isMono ? sL : tiltFilterR.processSample(sR);

            // 6. Post High-Cut (Gentle o Steep 18 dB/oct)
            sL = highCutSVF_L.process(sL).lp;
            if (highSlopeSteep) {
                sL = highCut2_L.process(sL).lp;
            }
            if (!isMono) {
                sR = highCutSVF_R.process(sR).lp;
                if (highSlopeSteep) {
                    sR = highCut2_R.process(sR).lp;
                }
            }

            // 7. AutoGain compensation & Output Trim
            sL *= postGain * outputTrimGain;
            sR *= postGain * outputTrimGain;

            // 8. Dry / Wet Mix
            inOutL[i] = (1.0f - mix) * dryL + mix * sL;
            if (!isMono) {
                inOutR[i] = (1.0f - mix) * dryR + mix * sR;
            }
        }
    }

private:
    float shapeStyle(float x, SatStyle style) const noexcept {
        if (!std::isfinite(x)) return 0.0f;

        switch (style) {
            case SatStyle::StyleA: {
                // Ampex 350 Tape Tube: saturazione a nastro morbida con compressione progressiva
                const float bias = 0.06f;
                const float xb = x + bias;
                const float y = std::tanh(xb * 1.05f) - std::tanh(bias * 1.05f);
                return y * 1.04f;
            }
            case SatStyle::StyleE: {
                // EMI TG12345 Channel: solid state aggressivo, armoniche 3a e 5a
                const float x2 = x * x;
                const float x4 = x2 * x2;
                return (x / std::sqrt(std::sqrt(1.0f + 0.65f * x4))) * 1.15f;
            }
            case SatStyle::StyleN: {
                // Neve 1057 Germanium: Transistor Mullard OC72/OC75
                // Asimmetria marcata, morso caldo sulle medie e rigido sui picchi negativi
                // Garantisce rigoroso unity gain a riposo (x -> 0) e compressione organica sui picchi
                const float asym = (x >= 0.0f) ? 0.32f : -0.40f;
                const float xCurved = x + asym * (x * x) / (1.0f + 0.85f * std::abs(x));
                const float satN = xCurved / std::sqrt(1.0f + 0.50f * xCurved * xCurved);
                return satN;
            }
            case SatStyle::StyleT: {
                // Culture Vulture Triode: prevalenza armonica pari (2a armonica)
                const float a = 0.25f;
                const float safeX = std::max(-1.95f, x);
                const float xt = safeX + a * safeX * safeX;
                return std::tanh(xt * 1.15f);
            }
            case SatStyle::StyleP: {
                // Culture Vulture Pentode: prevalenza armonica dispari (3a e 5a)
                const float xp = std::tanh(1.5f * x);
                return 0.78f * xp + 0.22f * std::tanh(3.1f * x);
            }
        }
        return std::tanh(x);
    }

    void updateDriveGain() noexcept {
        float gainDb = driveVal * 2.8f;
        if (punish) gainDb += 20.0f;
        inputDriveGain = std::pow(10.0f, gainDb * 0.05f);

        if (autoGain) {
            const float compDb = -gainDb * 0.88f;
            postGain = std::pow(10.0f, compDb * 0.05f);
        } else {
            postGain = 1.0f;
        }
    }

    void updateFilters() noexcept {
        const float qLow = lowThump ? 1.414f : 0.707f;
        lowCutSVF_L.setParameters(lowCutHz, qLow, sr);
        lowCutSVF_R.setParameters(lowCutHz, qLow, sr);

        highCutSVF_L.setParameters(highCutHz, 0.707f, sr);
        highCutSVF_R.setParameters(highCutHz, 0.707f, sr);
        if (highSlopeSteep) {
            highCut2_L.setParameters(highCutHz, 0.707f, sr);
            highCut2_R.setParameters(highCutHz, 0.707f, sr);
        }

        tiltFilterL.setTilt(std::clamp(toneDbVal / 12.0f, -1.0f, 1.0f));
        tiltFilterR.setTilt(std::clamp(toneDbVal / 12.0f, -1.0f, 1.0f));
    }

    float sr = 44100.0f;
    float invSr = 1.0f / 44100.0f;

    SatStyle currentStyle = SatStyle::StyleA;
    float driveVal = 0.0f;
    bool punish = false;
    float lowCutHz = 20.0f;
    bool lowThump = false;
    float highCutHz = 20000.0f;
    bool highSlopeSteep = false;
    float toneDbVal = 0.0f;
    bool autoGain = true;
    float mix = 1.0f;
    float trimDbVal = 0.0f;

    float inputDriveGain = 1.0f;
    float postGain = 1.0f;
    float outputTrimGain = 1.0f;

    ZDFSVF64 lowCutSVF_L, lowCutSVF_R;
    ZDFSVF64 highCutSVF_L, highCutSVF_R;
    ZDFSVF64 highCut2_L, highCut2_R;
    ZDFTiltFilter tiltFilterL, tiltFilterR;
    DCBlocker dcBlockerL, dcBlockerR;
};

} // namespace dsp171
