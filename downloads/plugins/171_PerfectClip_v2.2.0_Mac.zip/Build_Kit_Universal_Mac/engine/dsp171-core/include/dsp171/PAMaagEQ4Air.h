#pragma once
#include <cmath>
#include <algorithm>
#include <array>

namespace dsp171 {

/**
 * @brief MaagEQ4Air
 * Reverse-engineered from Mäag Audio EQ4.
 * Models Cliff Mäag's 6-band equalizer with 5 fixed-frequency proportional-Q bands
 * and the iconic Air Band (2.5k, 5k, 10k, 15k, 20k, and 40k Hz ultra-wide phase-coherent shelf).
 */
class MaagEQ4Air {
public:
    enum class AirFrequency {
        Air_2k5,
        Air_5k,
        Air_10k,
        Air_15k,
        Air_20k,
        Air_40k
    };

    MaagEQ4Air() noexcept 
        : m_sampleRate(44100.0f) {}

    void prepare(float sampleRate) noexcept {
        m_sampleRate = sampleRate > 0.0f ? sampleRate : 44100.0f;
        for (auto& b : m_bandsL) b.reset();
        for (auto& b : m_bandsR) b.reset();
        m_airShelfL.reset();
        m_airShelfR.reset();
        m_lastAirGainDb = -1.0f;
        updateFilters();
        updateAirShelf();
    }

    void reset() noexcept {
        for (auto& b : m_bandsL) b.reset();
        for (auto& b : m_bandsR) b.reset();
        m_airShelfL.reset();
        m_airShelfR.reset();
    }

    void setBands(float sub10HzDb, float band40HzDb, float band160HzDb,
                  float band650HzDb, float band2k5HzDb) noexcept {
        m_gainDb[0] = std::clamp(sub10HzDb, -5.0f, 5.0f);
        m_gainDb[1] = std::clamp(band40HzDb, -5.0f, 5.0f);
        m_gainDb[2] = std::clamp(band160HzDb, -5.0f, 5.0f);
        m_gainDb[3] = std::clamp(band650HzDb, -5.0f, 5.0f);
        m_gainDb[4] = std::clamp(band2k5HzDb, -5.0f, 5.0f);

        m_hasActiveBands = false;
        for (float g : m_gainDb) {
            if (std::abs(g) > 0.001f) {
                m_hasActiveBands = true;
                break;
            }
        }
        updateFilters();
    }

    void setAirBand(AirFrequency freq, float gainDb) noexcept {
        const float clampedGain = std::clamp(gainDb, 0.0f, 10.0f);
        if (freq == m_airFreqChoice && std::abs(clampedGain - m_lastAirGainDb) < 0.0005f) {
            return;
        }
        m_airFreqChoice = freq;
        m_airGainDb = clampedGain;
        m_lastAirGainDb = clampedGain;
        updateAirShelf();
    }

    void setParameters(AirFrequency freq, float gainDb) noexcept {
        setAirBand(freq, gainDb);
    }

    inline void process(float inL, float inR, float& outL, float& outR) noexcept {
        float sigL = inL;
        float sigR = inR;

        // Process 5 fixed bell bands in series only if any band is active (> 0 dB)
        if (m_hasActiveBands) {
            for (size_t i = 0; i < 5; ++i) {
                sigL = m_bandsL[i].process(sigL);
                sigR = m_bandsR[i].process(sigR);
            }
        }

        // Process Air Band ultra-wide shelf
        if (m_airGainDb > 0.001f) {
            outL = m_airShelfL.process(sigL);
            outR = m_airShelfR.process(sigR);
        } else {
            outL = sigL;
            outR = sigR;
        }
    }

    inline void processAirOnly(float inL, float inR, float& outL, float& outR) noexcept {
        if (m_airGainDb > 0.001f) {
            outL = m_airShelfL.process(inL);
            outR = m_airShelfR.process(inR);
        } else {
            outL = inL;
            outR = inR;
        }
    }

    inline float processAirOnlySample(float in) noexcept {
        if (m_airGainDb > 0.001f) {
            return m_airShelfL.process(in);
        }
        return in;
    }

    void processBlock(float* left, float* right, int numSamples) noexcept {
        for (int i = 0; i < numSamples; ++i) {
            process(left[i], right[i], left[i], right[i]);
        }
    }

private:
    float m_sampleRate = 44100.0f;
    std::array<float, 5> m_gainDb{0, 0, 0, 0, 0};
    bool m_hasActiveBands = false;
    AirFrequency m_airFreqChoice{AirFrequency::Air_40k};
    float m_airGainDb{0.0f};
    float m_lastAirGainDb{-1.0f};

    struct Biquad {
        float b0{1}, b1{0}, b2{0}, a1{0}, a2{0};
        float z1{0}, z2{0};
        inline float process(float in) noexcept {
            float out = b0 * in + z1;
            z1 = b1 * in - a1 * out + z2;
            z2 = b2 * in - a2 * out;
            return out;
        }
        void reset() noexcept { z1 = 0.0f; z2 = 0.0f; }
        void setPassthrough() noexcept {
            b0 = 1.0f; b1 = 0.0f; b2 = 0.0f;
            a1 = 0.0f; a2 = 0.0f;
            z1 = 0.0f; z2 = 0.0f;
        }
    };

    std::array<Biquad, 5> m_bandsL;
    std::array<Biquad, 5> m_bandsR;
    Biquad m_airShelfL;
    Biquad m_airShelfR;

    void updateFilters() noexcept {
        const float freqs[5] = {10.0f, 40.0f, 160.0f, 650.0f, 2500.0f};
        const float qs[5]    = {0.8f,  1.1f,  1.2f,   1.2f,   1.3f};

        for (int i = 0; i < 5; ++i) {
            float A = std::pow(10.0f, m_gainDb[i] / 40.0f);
            float omega = 2.0f * 3.14159265358979323846f * freqs[i] / m_sampleRate;
            float alpha = std::sin(omega) / (2.0f * qs[i]);
            float cosW = std::cos(omega);

            float b0 = 1.0f + alpha * A;
            float b1 = -2.0f * cosW;
            float b2 = 1.0f - alpha * A;
            float a0 = 1.0f + alpha / A;
            float a1 = -2.0f * cosW;
            float a2 = 1.0f - alpha / A;

            float invA0 = 1.0f / a0;
            m_bandsL[i].b0 = b0 * invA0; m_bandsL[i].b1 = b1 * invA0; m_bandsL[i].b2 = b2 * invA0;
            m_bandsL[i].a1 = a1 * invA0; m_bandsL[i].a2 = a2 * invA0;

            m_bandsR[i].b0 = m_bandsL[i].b0; m_bandsR[i].b1 = m_bandsL[i].b1; m_bandsR[i].b2 = m_bandsL[i].b2;
            m_bandsR[i].a1 = m_bandsL[i].a1; m_bandsR[i].a2 = m_bandsL[i].a2;
        }
    }

    void updateAirShelf() noexcept {
        if (m_airGainDb <= 0.0005f) {
            m_airShelfL.setPassthrough();
            m_airShelfR.setPassthrough();
            return;
        }

        float f0 = 40000.0f;
        switch (m_airFreqChoice) {
            case AirFrequency::Air_2k5: f0 = 2500.0f; break;
            case AirFrequency::Air_5k:  f0 = 5000.0f; break;
            case AirFrequency::Air_10k: f0 = 10000.0f; break;
            case AirFrequency::Air_15k: f0 = 15000.0f; break;
            case AirFrequency::Air_20k: f0 = 20000.0f; break;
            case AirFrequency::Air_40k: f0 = std::min(m_sampleRate * 0.48f, 38000.0f); break;
        }

        // Decramping protection for HF air bands at 44.1k / 48k:
        // Clamps turnover safely below Nyquist while preserving the iconic ultra-wide analog slope
        const float nyquist = m_sampleRate * 0.5f;
        const float fClamped = std::min(f0, nyquist * 0.90f);

        // Cliff Mäag Air Band: Wide slope high-shelf
        const float A = std::pow(10.0f, m_airGainDb / 40.0f);
        const float omega = 2.0f * 3.14159265358979323846f * fClamped / m_sampleRate;
        const float cosW = std::cos(omega);
        const float sinW = std::sin(omega);
        const float alpha = sinW / (2.0f * 0.45f); // Very wide Q = 0.45

        const float b0 = A * ((A + 1.0f) + (A - 1.0f) * cosW + 2.0f * std::sqrt(A) * alpha);
        const float b1 = -2.0f * A * ((A - 1.0f) + (A + 1.0f) * cosW);
        const float b2 = A * ((A + 1.0f) + (A - 1.0f) * cosW - 2.0f * std::sqrt(A) * alpha);
        const float a0 = (A + 1.0f) - (A - 1.0f) * cosW + 2.0f * std::sqrt(A) * alpha;
        const float a1 = 2.0f * ((A - 1.0f) - (A + 1.0f) * cosW);
        const float a2 = (A + 1.0f) - (A - 1.0f) * cosW - 2.0f * std::sqrt(A) * alpha;

        const float invA0 = 1.0f / a0;
        m_airShelfL.b0 = b0 * invA0; m_airShelfL.b1 = b1 * invA0; m_airShelfL.b2 = b2 * invA0;
        m_airShelfL.a1 = a1 * invA0; m_airShelfL.a2 = a2 * invA0;

        m_airShelfR.b0 = m_airShelfL.b0; m_airShelfR.b1 = m_airShelfL.b1; m_airShelfR.b2 = m_airShelfL.b2;
        m_airShelfR.a1 = m_airShelfL.a1; m_airShelfR.a2 = m_airShelfL.a2;
    }
};

} // namespace dsp171
