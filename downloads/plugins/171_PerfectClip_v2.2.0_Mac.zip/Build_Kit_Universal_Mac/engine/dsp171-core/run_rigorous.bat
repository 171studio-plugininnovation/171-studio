@echo off
cd /d "c:\Users\171Studio\Desktop\171 PLUGIN INNOVATIO GUI AND DSP\engine\dsp171-core"
tests\test_all_43_modules_rigorous.exe
