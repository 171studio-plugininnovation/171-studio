@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
cd /d "c:\Users\171Studio\Desktop\171 PLUGIN INNOVATIO GUI AND DSP\engine\dsp171-core"
cl.exe /EHsc /std:c++20 /O2 /I include tests\test_phase1_phase2.cpp /Fe:tests\test_phase1_phase2.exe
if %ERRORLEVEL% EQU 0 (
    echo.
    echo Running Phase 1 and Phase 2 Rigorous Verification:
    tests\test_phase1_phase2.exe
)
