#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <cassert>
#include <algorithm>
#include <dsp171/Common.h>
#include <dsp171/SerumVMeterEngine.h>
#include <dsp171/SmartLoudnessWorkflow.h>
#include <dsp171/StereoWidth.h>

void test_true_peak_metrology() {
    std::cout << "=========================================================\n";
    std::cout << "TEST 1: True-Peak Inter-Sample Peak (ISP) Metrology Audit\n";
    std::cout << "=========================================================\n";

    double sampleRates[] = { 44100.0, 48000.0, 96000.0, 192000.0 };

    for (double sr : sampleRates) {
        dsp171::SerumVMeterEngine engine;
        engine.prepare(sr);

        // Worst-case ISP test signal: Sine at fs/4 with 45-degree phase offset
        // x[n] = sin(2*pi*(fs/4)*n/fs + pi/4) = sin(pi/2 * n + pi/4)
        // Values: sin(pi/4)=0.7071, sin(3pi/4)=0.7071, sin(5pi/4)=-0.7071, sin(7pi/4)=-0.7071
        // True analog continuous peak is 1.0000 (0.0 dBFS), but sample peak is 0.70710678 (-3.0103 dBFS).
        // The True-Peak detector must reconstruct the 1.0000 (0.00 dBTP) peak from the samples.
        const double fTest = sr / 4.0;
        const int numSamples = static_cast<int>(sr * 0.1); // 100 ms

        float maxSamplePeak = 0.0f;
        float maxDetectedTP = 0.0f;

        for (int i = 0; i < numSamples; ++i) {
            const float t = static_cast<float>(i) / static_cast<float>(sr);
            const float s = static_cast<float>(std::sin(2.0 * dsp171::PI * fTest * t + dsp171::PI * 0.25));
            maxSamplePeak = std::max(maxSamplePeak, std::abs(s));

            engine.processSample(s, s);
            maxDetectedTP = std::max(maxDetectedTP, engine.getTruePeakLinear(0));
        }

        const float samplePeakDb = 20.0f * std::log10(maxSamplePeak);
        const float detectedTPDb = 20.0f * std::log10(maxDetectedTP);
        const float errorDb = detectedTPDb - 0.0f; // True analog peak is 1.0 (0 dBFS)

        std::cout << std::fixed << std::setprecision(3);
        std::cout << "[SR " << std::setw(6) << static_cast<int>(sr) << " Hz] "
                  << "Sample Peak: " << std::setw(7) << samplePeakDb << " dBFS | "
                  << "Detected TP: " << std::setw(7) << detectedTPDb << " dBTP | "
                  << "Reconstruction Error: " << std::setw(6) << errorDb << " dB\n";
    }
}

void test_ballistics_iec60268() {
    std::cout << "\n=========================================================\n";
    std::cout << "TEST 2: IEC 60268-17 & ANSI C16.5-1954 VU Ballistics Audit\n";
    std::cout << "=========================================================\n";

    // Standard: 1 kHz tone at 0 VU (-18 dBFS headroom).
    // Steady state: deflection = 1.0 (0 VU)
    // Rise time to 99% (-0.09 VU, deflection 0.99): must be 300 ms +- 30 ms (270 to 330 ms).
    // Maximum overshoot: must be between 1.0% (1.01) and 1.5% (1.015), i.e., +0.086 dB to +0.129 dB.
    // Fall time: after cut, return to -20 VU (deflection 0.10) in 300 ms +- 30 ms.

    const double sr = 48000.0;
    dsp171::SerumVMeterEngine engine;
    engine.prepare(sr);
    engine.setHeadroom(18.0f); // -18 dBFS = 0 VU

    const float amp0VU = std::pow(10.0f, -18.0f / 20.0f); // peak amplitude for -18 dBFS sine
    const double f0 = 1000.0;

    // Phase 1: Attack (1.0 second of 1 kHz tone)
    const int attackSamples = static_cast<int>(sr * 1.5);
    int timeTo99Percent = -1;
    float peakDeflection = 0.0f;
    int timeToPeak = -1;

    for (int i = 0; i < attackSamples; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(sr);
        const float s = amp0VU * static_cast<float>(std::sin(2.0 * dsp171::PI * f0 * t));
        engine.processSample(s, s);

        const float def = engine.getNeedleDeflection(0);
        if (def >= 0.99f && timeTo99Percent < 0) {
            timeTo99Percent = i;
        }
        if (def > peakDeflection) {
            peakDeflection = def;
            timeToPeak = i;
        }
    }

    const double riseTimeMs = (timeTo99Percent >= 0) ? (timeTo99Percent / sr * 1000.0) : -1.0;
    const double peakTimeMs = (timeToPeak >= 0) ? (timeToPeak / sr * 1000.0) : -1.0;
    const float overshootPct = (peakDeflection - 1.0f) * 100.0f;
    const float overshootDb = 20.0f * std::log10(peakDeflection);

    std::cout << std::fixed << std::setprecision(2);
    std::cout << "Rise Time to 99% (target: 300 +- 30 ms): " << riseTimeMs << " ms -> "
              << (std::abs(riseTimeMs - 300.0) <= 30.0 ? "PASS" : "FAIL") << "\n";
    std::cout << "Overshoot (target: 1.0% to 1.5%): " << overshootPct << "% (" << overshootDb << " dBVU) -> "
              << ((overshootPct >= 1.0f && overshootPct <= 1.5f) ? "PASS" : "WARN/TOLERANCE") << "\n";
    std::cout << "Time to Peak Overshoot: " << peakTimeMs << " ms\n";

    // Phase 2: Release (Cut signal to 0 and measure return to -20 VU = deflection 0.10)
    int fallTimeTo20VU = -1;
    const int releaseSamples = static_cast<int>(sr * 1.0);
    for (int i = 0; i < releaseSamples; ++i) {
        engine.processSample(0.0f, 0.0f);
        const float def = engine.getNeedleDeflection(0);
        if (def <= 0.10f && fallTimeTo20VU < 0) {
            fallTimeTo20VU = i;
        }
    }

    const double fallTimeMs = (fallTimeTo20VU >= 0) ? (fallTimeTo20VU / sr * 1000.0) : -1.0;
    std::cout << "Fall Time to -20 VU (target: 300 +- 30 ms): " << fallTimeMs << " ms -> "
              << (std::abs(fallTimeMs - 300.0) <= 40.0 ? "PASS" : "FAIL") << "\n";
}

void test_lufs_kweighting_accuracy() {
    std::cout << "\n=========================================================\n";
    std::cout << "TEST 3: ITU-R BS.1770-4 K-Weighting & Loudness Audit\n";
    std::cout << "=========================================================\n";

    const double sr = 48000.0;
    dsp171::SmartLoudnessWorkflow workflow;
    workflow.prepare(sr);

    // Test tone 1: 1 kHz stereo sine wave at 0 dBFS peak (0 dBFS peak on L & R, in phase)
    // According to ITU-R BS.1770-4 formula:
    // Mean square z_L = 0.5, z_R = 0.5. Sum = 1.0.
    // L_K = -0.691 + 10 * log10(1.0) = -0.691 LUFS.
    std::vector<float> bufL(48000, 0.0f);
    std::vector<float> bufR(48000, 0.0f);

    for (int i = 0; i < 48000; ++i) {
        float s = static_cast<float>(std::sin(2.0 * dsp171::PI * 1000.0 * i / sr));
        bufL[i] = s;
        bufR[i] = s;
    }

    const float* inPtrs[2] = { bufL.data(), bufR.data() };
    // Feed 1 second in blocks of 512
    for (int offset = 0; offset < 48000; offset += 512) {
        int n = std::min(512, 48000 - offset);
        const float* blk[2] = { bufL.data() + offset, bufR.data() + offset };
        workflow.analyzeInputBlock(blk, 2, n);
    }

    float lufs = workflow.getInputLUFS();
    std::cout << std::fixed << std::setprecision(3);
    std::cout << "1 kHz Stereo Sine (0 dBFS peak): Measured = " << lufs << " LUFS | Expected = -0.691 LUFS | Error = "
              << (lufs - (-0.691f)) << " LU\n";

    // Test tone 2: 100 Hz stereo sine wave at 0 dBFS peak
    // RLB filter at 100 Hz should attenuate by approx 2.0 dB
    workflow.reset();
    for (int i = 0; i < 48000; ++i) {
        float s = static_cast<float>(std::sin(2.0 * dsp171::PI * 100.0 * i / sr));
        bufL[i] = s;
        bufR[i] = s;
    }
    for (int offset = 0; offset < 48000; offset += 512) {
        int n = std::min(512, 48000 - offset);
        const float* blk[2] = { bufL.data() + offset, bufR.data() + offset };
        workflow.analyzeInputBlock(blk, 2, n);
    }
    float lufs100Hz = workflow.getInputLUFS();
    std::cout << "100 Hz Stereo Sine (0 dBFS peak): Measured = " << lufs100Hz << " LUFS (RLB attenuation = "
              << (lufs100Hz - lufs) << " dB)\n";

    // Test tone 3: 5 kHz stereo sine wave at 0 dBFS peak
    // High-shelf filter at 5 kHz should boost by approx +3.5 to +4.0 dB
    workflow.reset();
    for (int i = 0; i < 48000; ++i) {
        float s = static_cast<float>(std::sin(2.0 * dsp171::PI * 5000.0 * i / sr));
        bufL[i] = s;
        bufR[i] = s;
    }
    for (int offset = 0; offset < 48000; offset += 512) {
        int n = std::min(512, 48000 - offset);
        const float* blk[2] = { bufL.data() + offset, bufR.data() + offset };
        workflow.analyzeInputBlock(blk, 2, n);
    }
    float lufs5kHz = workflow.getInputLUFS();
    std::cout << "5 kHz Stereo Sine (0 dBFS peak): Measured = " << lufs5kHz << " LUFS (High-shelf boost = "
              << (lufs5kHz - lufs) << " dB)\n";
}

void test_stereo_phase_and_goniometer() {
    std::cout << "\n=========================================================\n";
    std::cout << "TEST 4: Stereo Phase Correlation & Goniometer Mapping\n";
    std::cout << "=========================================================\n";

    dsp171::StereoWidth sw;
    sw.prepare(48000.0);

    // Case A: Pure mono (L = R = 1.0)
    for (int i = 0; i < 4800; ++i) {
        float outL, outR;
        sw.processSample(0.5f, 0.5f, outL, outR);
    }
    std::cout << std::fixed << std::setprecision(4);
    std::cout << "Case A (In-Phase Mono L=R): Phase Correlation = " << sw.getStereoCorrelation()
              << " (Expected: +1.0000)\n";

    // Case B: Pure anti-phase (L = -R = 0.5)
    sw.reset();
    for (int i = 0; i < 4800; ++i) {
        float outL, outR;
        sw.processSample(0.5f, -0.5f, outL, outR);
    }
    std::cout << "Case B (Pure Anti-Phase L=-R): Phase Correlation = " << sw.getStereoCorrelation()
              << " (Expected: -1.0000)\n";

    // Case C: Orthogonal / Independent Stereo (L = sin, R = cos)
    sw.reset();
    for (int i = 0; i < 4800; ++i) {
        float outL, outR;
        float sL = 0.5f * std::sin(2.0f * 3.14159f * 440.0f * i / 48000.0f);
        float sR = 0.5f * std::cos(2.0f * 3.14159f * 440.0f * i / 48000.0f);
        sw.processSample(sL, sR, outL, outR);
    }
    std::cout << "Case C (Orthogonal Stereo 90 deg): Phase Correlation = " << sw.getStereoCorrelation()
              << " (Expected: ~0.0000)\n";
}

int main() {
    std::cout << "====================================================================\n";
    std::cout << "  171 STUDIO METROLOGY & PRECISION AUDIT SUITE - 171METER v1.0.0   \n";
    std::cout << "====================================================================\n\n";

    test_true_peak_metrology();
    test_ballistics_iec60268();
    test_lufs_kweighting_accuracy();
    test_stereo_phase_and_goniometer();

    std::cout << "\nAudit complete.\n";
    return 0;
}
