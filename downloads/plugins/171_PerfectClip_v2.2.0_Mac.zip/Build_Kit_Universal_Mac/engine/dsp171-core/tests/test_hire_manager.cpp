#include <iostream>
#include <cassert>
#include "dsp171/DSPHireManager.h"

int main() {
    std::cout << "======================================================" << std::endl;
    std::cout << "171 DSP HIRE MANAGER IN-ENGINE VERIFICATION TEST" << std::endl;
    std::cout << "======================================================" << std::endl;

    using namespace dsp171;

    // 1. Test Neve 1073 Dispatch
    {
        auto decision = DSPHireManager::dispatchSaturation(HardwareTarget::Neve_1073_1081, 4);
        assert(decision.primaryAgent.agentId == "sat-neve-specialist");
        assert(decision.qaAuditorAgent.agentId == "dsp-audit-scalability");
        std::cout << "[PASS] Neve 1073 dispatch -> sat-neve-specialist" << std::endl;
        std::cout << decision.toMarkdownTicket() << std::endl;
    }

    // 2. Test API 2520 Dispatch
    {
        auto decision = DSPHireManager::dispatchSaturation(HardwareTarget::API_2520_2500, 4);
        assert(decision.primaryAgent.agentId == "sat-api-specialist");
        std::cout << "[PASS] API 2520 dispatch -> sat-api-specialist" << std::endl;
    }

    // 3. Test Avalon VT-737sp Dispatch
    {
        auto decision = DSPHireManager::dispatchSaturation(HardwareTarget::Avalon_VT737sp, 4);
        assert(decision.primaryAgent.agentId == "sat-avalon-specialist");
        std::cout << "[PASS] Avalon VT-737sp dispatch -> sat-avalon-specialist" << std::endl;
    }

    // 4. Test Focusrite ISA 110 Dispatch
    {
        auto decision = DSPHireManager::dispatchSaturation(HardwareTarget::Focusrite_ISA110_430, 4);
        assert(decision.primaryAgent.agentId == "sat-focusrite-specialist");
        std::cout << "[PASS] Focusrite ISA dispatch -> sat-focusrite-specialist" << std::endl;
    }

    // 5. Test Studer/Ampex Tape Dispatch
    {
        auto decision = DSPHireManager::dispatchSaturation(HardwareTarget::Studer_A800_Ampex_ATR102, 4);
        assert(decision.primaryAgent.agentId == "sat-tape-modern-specialist");
        std::cout << "[PASS] Studer/Ampex Tape dispatch -> sat-tape-modern-specialist" << std::endl;
        std::cout << decision.toMarkdownTicket() << std::endl;
    }

    // 5b. Test Culture Vulture Extreme Saturation Dispatch
    {
        auto decision = DSPHireManager::dispatchSaturation(HardwareTarget::Culture_Vulture, 4);
        assert(decision.primaryAgent.agentId == "sat-tape-modern-specialist");
        assert(decision.qaAuditorAgent.agentId == "dsp-audit-scalability");
        std::cout << "[PASS] Culture Vulture dispatch -> sat-tape-modern-specialist" << std::endl;
        std::cout << decision.toMarkdownTicket() << std::endl;
    }

    // 6. Test Optical T4B Compressor Dispatch
    {
        auto decision = DSPHireManager::dispatchCompression(CompressionTopology::Optical_T4B);
        assert(decision.primaryAgent.agentId == "comp-optical-universal");
        assert(decision.reviewerAgent.agentId == "dsp-math-bugfinder");
        assert(decision.qaAuditorAgent.agentId == "dsp-audit-scalability");
        assert(decision.estimatedLatencySamples == 0);
        assert(decision.recommendedCPlusPlusClass == "dsp171::CLA2ACompressor");
        std::cout << "[PASS] Optical T4B dispatch -> comp-optical-universal (0 latency)" << std::endl;
        std::cout << decision.toMarkdownTicket() << std::endl;
    }

    // 6b. Test FET 1176 Peak Limiter Dispatch
    {
        auto decision = DSPHireManager::dispatchCompression(CompressionTopology::FET_1176);
        assert(decision.primaryAgent.agentId == "comp-optical-universal");
        assert(decision.reviewerAgent.agentId == "dsp-math-bugfinder");
        assert(decision.qaAuditorAgent.agentId == "dsp-audit-scalability");
        assert(decision.estimatedLatencySamples == 0);
        assert(decision.recommendedCPlusPlusClass == "dsp171::CLA76Compressor");
        std::cout << "[PASS] FET 1176 Peak Limiter dispatch -> comp-optical-universal (0 latency)" << std::endl;
        std::cout << decision.toMarkdownTicket() << std::endl;
    }

    // 7. Test Pitch Tuning (Zero Latency DPLL) Dispatch
    {
        auto decision = DSPHireManager::dispatchPitchTune(true, true);
        assert(decision.primaryAgent.agentId == "pitch-tune-specialist");
        assert(decision.estimatedLatencySamples == 0);
        std::cout << "[PASS] Live DPLL Pitch Tune dispatch -> pitch-tune-specialist (0 latency)" << std::endl;
    }

    // 8. Test MIDI 2.0 / MPE Harmony Dispatch
    {
        auto decision = DSPHireManager::dispatchMidiHarmony(true);
        assert(decision.primaryAgent.agentId == "midi-harmony-specialist");
        std::cout << "[PASS] MIDI 2.0 / MPE dispatch -> midi-harmony-specialist" << std::endl;
    }

    // 9. Test Wave Digital Filter (Analytical Math) Dispatch
    {
        auto decision = DSPHireManager::dispatchAnalyticalMath(MathModelPrecision::WDF_WaveDigitalFilter);
        assert(decision.primaryAgent.agentId == "analytical-math-physicist");
        std::cout << "[PASS] WDF Physics dispatch -> analytical-math-physicist" << std::endl;
    }

    // 10. Test Spatial Audio / True Peak Limiter Dispatch
    {
        auto decision = DSPHireManager::dispatchMasteringSpatial(true, true);
        assert(decision.primaryAgent.agentId == "spatial-mastering-engineer");
        std::cout << "[PASS] Spatial / True Peak dispatch -> spatial-mastering-engineer" << std::endl;
    }

    // 11. Test JSON serialization
    {
        auto decision = DSPHireManager::dispatchSaturation(HardwareTarget::Neve_1073_1081);
        std::string json = decision.toFormattedJson();
        assert(json.find("sat-neve-specialist") != std::string::npos);
        std::cout << "[PASS] JSON Serialization verified:\n" << json << std::endl;
    }

    // 12. Test Newly Inducted Agents 19-23 (Guild Expansion)
    {
        assert(DSPHireManager::AGENT_VOCAL_GATE.agentId == "vocal-gate-expander-specialist");
        assert(DSPHireManager::AGENT_VOCAL_DOUBLER.agentId == "vocal-spatial-doubler-specialist");
        assert(DSPHireManager::AGENT_FFT_SPECTRAL.agentId == "fft-spectral-visualizer-specialist");
        assert(DSPHireManager::AGENT_SMART_LOUDNESS.agentId == "smart-loudness-workflow-specialist");
        assert(DSPHireManager::AGENT_MAAG_AIR.agentId == "maag-air-resonance-specialist");
        std::cout << "[PASS] All 5 Newly Inducted Guild Agents Verified (19 to 23): PASS" << std::endl;
    }

    // 13. Test GUI Art & Visual Engineering Team Agents 24-27
    {
        assert(DSPHireManager::AGENT_GUI_ART_DIRECTOR.agentId == "gui-art-director");
        assert(DSPHireManager::AGENT_GUI_ARTWORKER.agentId == "gui-artworker");
        assert(DSPHireManager::AGENT_AI_IMAGE_PROMPT.agentId == "ai-image-prompt-specialist");
        assert(DSPHireManager::AGENT_JUCE_GUI_IMPLEMENTER.agentId == "juce-gui-implementer");
        std::cout << "[PASS] All 4 GUI Visual Team Agents Verified (24 to 27): PASS" << std::endl;
    }

    // 14. Test GUI Reengineering, Silkscreen & Boutique Branding Guild (Agents 28-33)
    {
        assert(DSPHireManager::AGENT_GRAPHIC_DESIGNER.agentId == "graphic-designer");
        assert(DSPHireManager::AGENT_GUI_MATHEMATICIAN.agentId == "gui-mathematician");
        assert(DSPHireManager::AGENT_SILKSCREEN_TYPOGRAPHY.agentId == "silkscreen-typography-specialist");
        assert(DSPHireManager::AGENT_PLUGIN_BOUTIQUER.agentId == "plugin-boutiquer");
        assert(DSPHireManager::AGENT_GUI_REVERSE_ENGINEER.agentId == "gui-reverse-engineering-specialist");
        assert(DSPHireManager::AGENT_ASSET_ATLAS_OPTIMIZER.agentId == "asset-atlas-optimizer");

        // Verify dispatches
        auto dSilkscreen = DSPHireManager::dispatchSilkscreen();
        assert(dSilkscreen.primaryAgent.agentId == "silkscreen-typography-specialist");

        auto dBoutique = DSPHireManager::dispatchBoutiqueBranding();
        assert(dBoutique.primaryAgent.agentId == "plugin-boutiquer");

        auto dRevEng = DSPHireManager::dispatchGuiReverseEngineering();
        assert(dRevEng.primaryAgent.agentId == "gui-reverse-engineering-specialist");

        auto dAtlas = DSPHireManager::dispatchAssetAtlas();
        assert(dAtlas.primaryAgent.agentId == "asset-atlas-optimizer");

        std::cout << "[PASS] All 6 GUI Reengineering & Boutique Guild Agents Verified (28 to 33): PASS" << std::endl;
        std::cout << dBoutique.toMarkdownTicket() << std::endl;
    }

    std::cout << "======================================================" << std::endl;
    std::cout << "ALL 14 HIRE MANAGER TESTS PASSED WITH 100% ACCURACY!" << std::endl;
    std::cout << "======================================================" << std::endl;

    return 0;
}
