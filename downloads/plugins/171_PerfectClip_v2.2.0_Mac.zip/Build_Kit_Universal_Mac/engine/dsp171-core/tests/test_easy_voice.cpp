#include <iostream>
#include <cassert>
#include <cmath>
#include <vector>

#include "dsp171/Common.h"
#include "dsp171/RenaissanceDeEsser.h"
#include "dsp171/SSLGChannelEQ.h"
#include "dsp171/EasyVoiceChannelStrip.h"

int main() {
    std::cout << "==================================================================" << std::endl;
    std::cout << "   171 MUSIC INNOVATION: EASY VOICE (VOCAL CHANNEL STRIP) TEST    " << std::endl;
    std::cout << "   Neve 5116 Pre + Waves R-DeEsser + SSL 242 EQ + UAD 1176 Comp   " << std::endl;
    std::cout << "==================================================================" << std::endl;

    constexpr double sampleRate = 48000.0;

    auto isSafe = [](float x) noexcept {
        return !std::isnan(x) && !std::isinf(x);
    };

    // -------------------------------------------------------------------------
    // 1. TEST RENAISSANCE DE-ESSER
    // -------------------------------------------------------------------------
    std::cout << "\n[TEST 1] Testing RenaissanceDeEsser (Split-Band & Wideband)..." << std::endl;
    {
        dsp171::RenaissanceDeEsser deEsser;
        deEsser.prepare(sampleRate);
        deEsser.setFrequency(6000.0f);
        deEsser.setThresholdDb(-18.0f);
        deEsser.setRangeDb(12.0f);
        deEsser.setMode(dsp171::RenaissanceDeEsser::DeEsserMode::SplitBand);
        deEsser.setSidechainType(dsp171::RenaissanceDeEsser::SidechainType::Bell);

        // Low frequency test (150 Hz vocal fundamental): should NOT trigger de-esser
        for (int i = 0; i < 512; ++i) {
            float s = 0.5f * std::sin(2.0f * dsp171::PI * 150.0f * i / 48000.0f);
            float outL = 0.0f, outR = 0.0f;
            deEsser.processSample(s, s, outL, outR);
            assert(isSafe(outL) && isSafe(outR));
        }
        assert(deEsser.getGainReductionL() < 0.1f); // No GR on bass
        std::cout << "  [PASS] Low-frequency transparency verified (GR = 0 dB on vowel)" << std::endl;

        // High frequency sibilance burst (6000 Hz 'S' sound @ -6 dBFS): MUST trigger de-esser
        float lastOut = 0.0f;
        for (int i = 0; i < 1024; ++i) {
            float s = 0.5f * std::sin(2.0f * dsp171::PI * 6000.0f * i / 48000.0f);
            float outL = 0.0f, outR = 0.0f;
            deEsser.processSample(s, s, outL, outR);
            lastOut = outL;
            assert(isSafe(outL) && isSafe(outR));
        }
        const float gr = deEsser.getGainReductionL();
        assert(gr > 3.0f && gr <= 12.05f); // GR triggered and bounded by Range (12 dB)
        std::cout << "  [PASS] Sibilance burst detection: Gain Reduction = " << gr << " dB (Range bounded)" << std::endl;

        // Wideband mode test
        deEsser.setMode(dsp171::RenaissanceDeEsser::DeEsserMode::Wideband);
        float outL = 0.0f, outR = 0.0f;
        deEsser.processSample(0.4f, 0.4f, outL, outR);
        assert(isSafe(outL) && isSafe(outR));
        std::cout << "  [PASS] Wideband de-esser mode verified" << std::endl;
    }

    // -------------------------------------------------------------------------
    // 2. TEST SSL 4000 G-SERIES 242 BLACK KNOB EQ
    // -------------------------------------------------------------------------
    std::cout << "\n[TEST 2] Testing SSLGChannelEQ (4-Band Parametric + HPF/LPF)..." << std::endl;
    {
        dsp171::SSLGChannelEQ sslEQ;
        sslEQ.prepare(sampleRate);

        // Bit-exact null test on flat settings
        float outL = 0.0f, outR = 0.0f;
        sslEQ.processSample(0.5f, -0.5f, outL, outR);
        assert(std::abs(outL - 0.5f) < 1.0e-5f);
        assert(std::abs(outR - (-0.5f)) < 1.0e-5f);
        std::cout << "  [PASS] Bit-exact flat response null test" << std::endl;

        // Configure full SSL vocal curve:
        // HPF @ 80 Hz, LF Shelf +3 dB @ 100 Hz, LMF -2.5 dB @ 400 Hz (mud cut),
        // HMF +3.5 dB @ 3 kHz (presence), HF Shelf +4 dB @ 10 kHz (air)
        sslEQ.setHPFFreq(80.0f);
        sslEQ.setLPFFreq(20000.0f);
        sslEQ.setLF(100.0f, 3.0f, dsp171::SSLGChannelEQ::BandType::Shelf);
        sslEQ.setLMF(400.0f, -2.5f, 1.2f);
        sslEQ.setHMF(3000.0f, 3.5f, 1.5f);
        sslEQ.setHF(10000.0f, 4.0f, dsp171::SSLGChannelEQ::BandType::Shelf);

        for (int i = 0; i < 512; ++i) {
            float s = 0.3f * std::sin(2.0f * dsp171::PI * 1000.0f * i / 48000.0f);
            sslEQ.processSample(s, s, outL, outR);
            assert(isSafe(outL) && isSafe(outR));
        }
        std::cout << "  [PASS] SSL 242 4-Band + Filters vocal EQ curves verified" << std::endl;
    }

    // -------------------------------------------------------------------------
    // 3. TEST FULL EASY VOICE CHANNEL STRIP INTEGRATION
    // -------------------------------------------------------------------------
    std::cout << "\n[TEST 3] Testing EasyVoiceChannelStrip (Full Cascade)..." << std::endl;
    {
        dsp171::EasyVoiceChannelStrip strip;
        strip.prepare(sampleRate);

        // Preamp setup: Neve 5116 Drive + Warmth
        strip.setPreampDrive(5.0f);
        strip.setPreampWarmth(4.0f);

        // De-Esser setup: R-DeEsser Split-Band @ 5.8 kHz
        strip.setDeEsserFrequency(5800.0f);
        strip.setDeEsserThresholdDb(-20.0f);
        strip.setDeEsserRangeDb(10.0f);

        // EQ setup: SSL 242
        strip.setHPFFreq(75.0f);
        strip.setHMF(3200.0f, 2.5f, 1.4f); // Presence boost
        strip.setHF(12000.0f, 3.0f, dsp171::SSLGChannelEQ::BandType::Shelf); // Air sheen

        // Compressor setup: UAD 1176 Blue Stripe @ 4:1 Ratio
        strip.setCompInputDb(-18.0f);
        strip.setCompOutputDb(-12.0f);
        strip.setCompAttackKnob(3.0f);  // Fast
        strip.setCompReleaseKnob(5.0f); // Snappy release
        strip.setCompRatio(dsp171::CLA76Compressor::Ratio::Ratio4);
        strip.setCompRevision(dsp171::CLA76Compressor::Revision::BlueStripe);

        // Process a block of 1024 vocal samples
        std::vector<float> bufferL(1024);
        std::vector<float> bufferR(1024);
        for (size_t i = 0; i < 1024; ++i) {
            // Complex vocal simulated signal: 220 Hz fundamental + 3.2 kHz formant + 6 kHz sibilance burst
            float f0 = 0.35f * std::sin(2.0f * dsp171::PI * 220.0f * i / 48000.0f);
            float f1 = 0.20f * std::sin(2.0f * dsp171::PI * 3200.0f * i / 48000.0f);
            float sib = (i > 256 && i < 768) ? (0.25f * std::sin(2.0f * dsp171::PI * 6000.0f * i / 48000.0f)) : 0.0f;
            bufferL[i] = f0 + f1 + sib;
            bufferR[i] = bufferL[i];
        }

        strip.processBlock(bufferL.data(), bufferR.data(), 1024);

        for (size_t i = 0; i < 1024; ++i) {
            assert(isSafe(bufferL[i]) && isSafe(bufferR[i]));
            // Brickwall ceiling safety check (-0.09 dBFS / 0.9900 max)
            assert(std::abs(bufferL[i]) <= 0.995f);
            assert(std::abs(bufferR[i]) <= 0.995f);
        }

        std::cout << "  [PASS] Full vocal strip processed successfully" << std::endl;
        std::cout << "  [PASS] De-Esser Telemetry GR = " << strip.getDeEsserGR_dB() << " dB" << std::endl;
        std::cout << "  [PASS] 1176 Comp Telemetry GR = " << strip.getCompressorGR_dB() << " dB" << std::endl;
        std::cout << "  [PASS] Output Meter Peak = " << strip.getOutputMeterL() << std::endl;

        // Test All-Buttons-In British Mode on 1176
        strip.setCompRatio(dsp171::CLA76Compressor::Ratio::AllButtons);
        strip.processBlock(bufferL.data(), bufferR.data(), 512);
        std::cout << "  [PASS] 1176 All-Buttons-In British Mode verified (GR: "
                  << strip.getCompressorGR_dB() << " dB)" << std::endl;
    }

    std::cout << "\n==================================================================" << std::endl;
    std::cout << "   SUCCESS: EASY VOICE DSP CORE FULLY VALIDATED AND CERTIFIED!    " << std::endl;
    std::cout << "==================================================================" << std::endl;

    return 0;
}
