#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include "dsp171/Common.h"
#include "dsp171/TDPSOLAShifter.h"

using namespace dsp171;

int main() {
    const double sr = 48000.0;
    TDPSOLAShifter shifter;
    shifter.prepare(sr, 192);

    const size_t numSamples = 72000;
    std::vector<float> input(numSamples, 0.0f);
    std::vector<float> output(numSamples, 0.0f);

    float currentPhase = 0.0f;
    for (size_t i = 0; i < numSamples; ++i) {
        float f = 335.0f;
        currentPhase += 2.0f * PI * f / static_cast<float>(sr);
        if (currentPhase > 2.0f * PI) currentPhase -= 2.0f * PI;
        float sample = 0.0f;
        for (int h = 1; h <= 10; ++h) {
            sample += (1.0f / h) * std::sin(h * currentPhase);
        }
        input[i] = sample * 0.3f;
    }

    float ratio = 329.63f / 335.0f;
    float t0 = static_cast<float>(sr / 335.0);

    for (size_t i = 0; i < numSamples; ++i) {
        float outL = 0.0f, outR = 0.0f;
        shifter.processStereo(input[i], input[i], outL, outR, t0, ratio, true, 0.95f);
        output[i] = outL;

        if (i >= 69330 && i <= 69370) {
            std::cout << "i=" << i << " out=" << std::setw(10) << outL 
                      << " delta=" << std::setw(10) << (outL - output[i-1]) << "\n";
        }
    }
    return 0;
}
