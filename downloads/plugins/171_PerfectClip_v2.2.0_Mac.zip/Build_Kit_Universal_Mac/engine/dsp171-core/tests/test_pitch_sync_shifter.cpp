#include <iostream>
#include <vector>
#include <array>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include "dsp171/Common.h"
#include "dsp171/TDPSOLAShifter.h"

using namespace dsp171;

static inline float hermite4(float x, float y0, float y1, float y2, float y3) noexcept {
    const float c0 = y1;
    const float c1 = 0.5f * (y2 - y0);
    const float c2 = y0 - 2.5f * y1 + 2.0f * y2 - 0.5f * y3;
    const float c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);
    return ((c3 * x + c2) * x + c1) * x + c0;
}

static inline float readHermite(const float* buf, size_t mask, double idx) noexcept {
    if (!std::isfinite(idx)) return 0.0f;
    const int64_t i1 = static_cast<int64_t>(std::floor(idx));
    const float frac = static_cast<float>(idx - static_cast<double>(i1));
    const float y0 = buf[static_cast<size_t>(i1 - 1) & mask];
    const float y1 = buf[static_cast<size_t>(i1) & mask];
    const float y2 = buf[static_cast<size_t>(i1 + 1) & mask];
    const float y3 = buf[static_cast<size_t>(i1 + 2) & mask];
    return hermite4(frac, y0, y1, y2, y3);
}

// Shifter with Pitch-Synchronous (Zero-Crossing / GCI) Alignment
class PitchSyncShifter {
public:
    static constexpr size_t BUFFER_SIZE = 16384;
    static constexpr size_t BUFFER_MASK = BUFFER_SIZE - 1;

    struct Playhead {
        double readPos = 0.0;
        bool active = false;
    };

    void prepare(double sampleRate, size_t latencySamples = 192) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        latency = std::clamp(latencySamples, size_t(96), BUFFER_SIZE / 4);
        reset();
    }

    void reset() noexcept {
        inputBuffer.fill(0.0f);
        globalSampleCount = 0;
        heads[0].readPos = -static_cast<double>(latency);
        heads[0].active = true;
        heads[1].readPos = -static_cast<double>(latency);
        heads[1].active = false;
        activeHead = 0;
        isCrossfading = false;
        crossfadePhase = 0.0f;
        crossfadeStep = 0.01f;
        jumpCount = 0;
        jumpRequested = false;
        pendingK = 0;
        waitSamples = 0;
        prevSample = 0.0f;
    }

    inline float processSample(float inSample, float inputT0, float pitchRatio, bool isVoiced) noexcept {
        const size_t writeIdx = static_cast<size_t>(globalSampleCount) & BUFFER_MASK;
        inputBuffer[writeIdx] = inSample;

        const float safeT0 = std::isfinite(inputT0) ? std::clamp(inputT0, sr / 1200.0f, sr / 50.0f) : (sr / 440.0f);
        const float safeRatio = std::isfinite(pitchRatio) ? std::clamp(pitchRatio, 0.5f, 2.0f) : 1.0f;

        if (isVoiced) {
            heads[activeHead].readPos += static_cast<double>(safeRatio);

            if (isCrossfading) {
                const int otherHead = 1 - activeHead;
                heads[otherHead].readPos += static_cast<double>(safeRatio);
                crossfadePhase += crossfadeStep;

                if (crossfadePhase >= 1.0f) {
                    crossfadePhase = 1.0f;
                    activeHead = otherHead;
                    heads[1 - activeHead].active = false;
                    isCrossfading = false;
                }
            }

            const double currentDelay = static_cast<double>(globalSampleCount) - heads[activeHead].readPos;
            constexpr double minAllowedDelay = 8.0;
            const float fadeSamples = std::clamp(safeT0 * 0.70f, 32.0f, 256.0f);
            const double minDelayTrigger = minAllowedDelay + static_cast<double>(fadeSamples) + 8.0;

            if (!isCrossfading && !jumpRequested) {
                if (safeRatio > 1.002f && currentDelay < minDelayTrigger) {
                    int k = -static_cast<int>(std::ceil((minDelayTrigger - currentDelay) / safeT0));
                    if (k >= 0) k = -1;
                    pendingK = k;
                    jumpRequested = true;
                    waitSamples = 0;
                } else if (safeRatio < 0.998f) {
                    const double triggerDelay = std::max(
                        static_cast<double>(latency) + 0.60 * static_cast<double>(safeT0),
                        minDelayTrigger + static_cast<double>(safeT0)
                    );

                    if (currentDelay > triggerDelay) {
                        int k = static_cast<int>(std::floor((currentDelay - static_cast<double>(latency)) / safeT0));
                        if (k <= 0) k = 1;
                        if ((currentDelay - static_cast<double>(k) * safeT0) < minDelayTrigger) {
                            k = std::max(0, static_cast<int>((currentDelay - minDelayTrigger) / safeT0));
                        }
                        if (k > 0) {
                            pendingK = k;
                            jumpRequested = true;
                            waitSamples = 0;
                        }
                    }
                }
            }

            // Pitch-Synchronous Anchor: Wait for zero-crossing or max wait timeout (~0.75 * T0)
            bool executeJumpNow = false;
            if (jumpRequested) {
                waitSamples++;
                const float curHeadVal = readHermite(inputBuffer.data(), BUFFER_MASK, heads[activeHead].readPos);
                const float prevHeadVal = readHermite(inputBuffer.data(), BUFFER_MASK, heads[activeHead].readPos - 1.0);
                const bool isZeroCross = (prevHeadVal <= 0.0f && curHeadVal > 0.0f) || (prevHeadVal >= 0.0f && curHeadVal < 0.0f);
                const bool isTimeout = (waitSamples > static_cast<uint32_t>(safeT0 * 0.75f));

                if (isZeroCross || isTimeout) {
                    executeJumpNow = true;
                    jumpRequested = false;
                }
            }

            if (executeJumpNow) {
                jumpCount++;
                const double candidatePos = heads[activeHead].readPos + static_cast<double>(pendingK) * safeT0;

                const int corrRadius = std::clamp(static_cast<int>(safeT0 * 0.25f), 16, 96);
                const int windowLen  = std::clamp(static_cast<int>(safeT0 * 0.60f), 32, 256);
                int bestDelta = 0;
                float maxNormCorr = -2.0f;

                float refEnergy = 1e-9f;
                for (int m = 0; m < windowLen; ++m) {
                    const float s = readHermite(inputBuffer.data(), BUFFER_MASK, heads[activeHead].readPos + m);
                    refEnergy += s * s;
                }

                for (int delta = -corrRadius; delta <= corrRadius; ++delta) {
                    float dotProduct = 0.0f;
                    float candEnergy = 1e-9f;
                    for (int m = 0; m < windowLen; ++m) {
                        const float refSample = readHermite(inputBuffer.data(), BUFFER_MASK, heads[activeHead].readPos + m);
                        const float candSample = readHermite(inputBuffer.data(), BUFFER_MASK, candidatePos + delta + m);
                        dotProduct += refSample * candSample;
                        candEnergy += candSample * candSample;
                    }

                    const float normCorr = dotProduct / std::sqrt(refEnergy * candEnergy);
                    if (normCorr > maxNormCorr) {
                        maxNormCorr = normCorr;
                        bestDelta = delta;
                    }
                }

                const int nextHead = 1 - activeHead;
                heads[nextHead].readPos = candidatePos + static_cast<double>(bestDelta);
                heads[nextHead].active = true;

                isCrossfading = true;
                crossfadePhase = 0.0f;
                crossfadeStep = 1.0f / fadeSamples;
            }
        } else {
            heads[activeHead].readPos += 1.0;
            const double targetPos = static_cast<double>(globalSampleCount - static_cast<int64_t>(latency));
            const double err = targetPos - heads[activeHead].readPos;
            heads[activeHead].readPos += 0.02 * err;
            isCrossfading = false;
            jumpRequested = false;
            crossfadePhase = 0.0f;
        }

        const float s0 = readHermite(inputBuffer.data(), BUFFER_MASK, heads[activeHead].readPos);
        float shifted = s0;

        if (isCrossfading) {
            const int otherHead = 1 - activeHead;
            const float s1 = readHermite(inputBuffer.data(), BUFFER_MASK, heads[otherHead].readPos);
            const float w0 = 0.5f * (1.0f + std::cos(PI * crossfadePhase));
            const float w1 = 1.0f - w0;
            shifted = s0 * w0 + s1 * w1;
        }

        prevSample = inSample;
        globalSampleCount++;
        return shifted;
    }

    uint32_t getJumpCount() const noexcept { return jumpCount; }

private:
    float sr = 48000.0f;
    size_t latency = 192;
    std::array<float, BUFFER_SIZE> inputBuffer{};
    int64_t globalSampleCount = 0;
    std::array<Playhead, 2> heads{};
    int activeHead = 0;
    bool isCrossfading = false;
    float crossfadePhase = 0.0f;
    float crossfadeStep = 0.01f;
    uint32_t jumpCount = 0;
    bool jumpRequested = false;
    int pendingK = 0;
    uint32_t waitSamples = 0;
    float prevSample = 0.0f;
};

int main() {
    const double sr = 48000.0;
    const float f0 = 120.0f;
    const float t0 = static_cast<float>(sr / f0);
    const float pitchRatioDown = 0.840896f;

    const size_t numSamples = 48000;
    std::vector<float> input(numSamples, 0.0f);

    for (size_t i = 0; i < numSamples; ++i) {
        float phase = std::fmod(static_cast<float>(i), t0) / t0;
        if (phase < 0.15f) {
            input[i] = -std::sin(phase / 0.15f * PI);
        } else {
            input[i] = 0.08f * std::sin((phase - 0.15f) / 0.85f * PI);
        }
    }

    // Current
    TDPSOLAShifter cur;
    cur.prepare(sr, 192);
    float curMaxStep = 0.0f;
    for (size_t i = 0; i < numSamples; ++i) {
        float outL = 0.0f, outR = 0.0f;
        cur.processStereo(input[i], input[i], outL, outR, t0, pitchRatioDown, true, 0.95f);
        if (i > 1000) {
            static float prevL = 0.0f;
            curMaxStep = std::max(curMaxStep, std::abs(outL - prevL));
            prevL = outL;
        }
    }

    // PitchSync
    PitchSyncShifter sync;
    sync.prepare(sr, 192);
    float syncMaxStep = 0.0f;
    for (size_t i = 0; i < numSamples; ++i) {
        float out = sync.processSample(input[i], t0, pitchRatioDown, true);
        if (i > 1000) {
            static float prevS = 0.0f;
            syncMaxStep = std::max(syncMaxStep, std::abs(out - prevS));
            prevS = out;
        }
    }

    std::cout << "Current Shifter Max Step Delta: " << curMaxStep << "\n";
    std::cout << "PitchSync Shifter Max Step Delta: " << syncMaxStep << "\n";
    std::cout << "Step Discontinuity Reduction: " << ((curMaxStep - syncMaxStep) / curMaxStep * 100.0f) << "%\n";

    return 0;
}
