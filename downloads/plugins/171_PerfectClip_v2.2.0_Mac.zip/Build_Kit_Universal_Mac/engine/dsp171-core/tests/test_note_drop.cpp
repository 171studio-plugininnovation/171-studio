#include <iostream>
#include <vector>
#include <cmath>
#include "dsp171/Common.h"
#include "dsp171/TDPSOLAShifter.h"
#include "dsp171/RealTuneEngine.h"

using namespace dsp171;

int main() {
    const double sr = 48000.0;
    RealTuneEngine engine;
    engine.prepare(sr);
    engine.setLowLatencyMode(true);
    engine.setRetuneSpeedMs(0.0f); // Fast / Hard-tune transitions
    engine.setScale(ScaleType::Chromatic);

    // Sing alternating notes: E4 (329.6 Hz) -> C4 (261.6 Hz) -> A3 (220 Hz)
    const size_t numSamples = 48000 * 2; // 2 seconds
    std::vector<float> input(numSamples, 0.0f);
    std::vector<float> output(numSamples, 0.0f);

    float currentPhase = 0.0f;
    for (size_t i = 0; i < numSamples; ++i) {
        float f = (i < 48000) ? 335.0f : 215.0f; // Rapid drop across notes
        currentPhase += 2.0f * PI * f / static_cast<float>(sr);
        if (currentPhase > 2.0f * PI) currentPhase -= 2.0f * PI;
        // Vocal buzz waveform with rich harmonics
        float sample = 0.0f;
        for (int h = 1; h <= 10; ++h) {
            sample += (1.0f / h) * std::sin(h * currentPhase);
        }
        input[i] = sample * 0.3f;
    }

    engine.process(input.data(), output.data(), numSamples);

    float maxPop = 0.0f;
    size_t popIdx = 0;
    for (size_t i = 1; i < numSamples; ++i) {
        float d = std::abs(output[i] - output[i-1]);
        if (d > maxPop) {
            maxPop = d;
            popIdx = i;
        }
    }

    std::cout << "Max Delta on fast downward note transition: " << maxPop << " at sample " << popIdx << "\n";
    return 0;
}
