#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include "dsp171/Common.h"
#include "dsp171/ZDFSVF.h"
#include "dsp171/ZDFTiltFilter.h"
#include "dsp171/FormantShaperZDF.h"

using namespace dsp171;

int main() {
    std::cout << "=========================================================\n";
    std::cout << "TEST SILK FORMANT SHAPING FOR NATURAL & SILKY TONE\n";
    std::cout << "=========================================================\n\n";

    const double sr = 48000.0;
    FormantShaperZDF shaper;
    shaper.prepare(sr);
    shaper.setKeepFormants(true);

    const float f0 = 130.0f;
    const float pitchDownRatio = 0.840896f; // -3 semitones down

    shaper.updateTracking(f0, pitchDownRatio, true);

    std::cout << "AutoShift: " << shaper.getAutoFormantShift() << " st\n";
    std::cout << "Tracked F1: " << shaper.getTrackedF1Hz() << " -> Target: " << shaper.getTargetF1Hz() << "\n";
    std::cout << "Tracked F2: " << shaper.getTrackedF2Hz() << " -> Target: " << shaper.getTargetF2Hz() << "\n\n";

    return 0;
}
