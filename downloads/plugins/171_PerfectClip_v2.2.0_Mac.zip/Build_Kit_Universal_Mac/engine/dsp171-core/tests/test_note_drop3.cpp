#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include "dsp171/Common.h"

// Let us test the combination of Hann crossfade + 0.5 ms ratio slew on test_note_drop
int main() {
    std::cout << "Testing note drop with improved smoothing\n";
    return 0;
}
