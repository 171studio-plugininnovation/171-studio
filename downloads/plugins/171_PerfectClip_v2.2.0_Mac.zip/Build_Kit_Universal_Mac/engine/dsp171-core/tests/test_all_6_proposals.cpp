#include <iostream>
#include <vector>
#include <cmath>
#include <cassert>
#include <iomanip>

// Include all 6 integrated improvement modules
#include "dsp171/ADAA2Clipper.h"
#include "dsp171/PolyphaseOversampler.h"
#include "dsp171/TransformerSaturator.h"
#include "dsp171/APIThrustFilter.h"
#include "dsp171/CLA2ACompressor.h"
#include "dsp171/BoutiqueVUMeter.h"
#include "dsp171/FFTSpectralVisualizer.h"
#include "dsp171/SmartLoudnessWorkflow.h"

using namespace dsp171;

int main() {
    std::cout << "========================================================\n";
    std::cout << "  171 STUDIO - VERIFICA INTEGRATA DEI 6 MIGLIORAMENTI   \n";
    std::cout << "========================================================\n\n";

    int passedTests = 0;
    int totalTests = 6;

    // -------------------------------------------------------------------------
    // TEST 1: ADAA-2 Clipper 4th-Order Taylor & Zero-Singularity Resilience
    // -------------------------------------------------------------------------
    std::cout << "[TEST 1] ADAA2Clipper - Singularity & 4th-Order Taylor Expansion...\n";
    {
        ADAA2Clipper clipper;
        clipper.reset();

        // A. Identical input stress test (d0 = 0, dTot = 0)
        float outIdentical = 0.0f;
        for (int i = 0; i < 100; ++i) {
            outIdentical = clipper.processSample(0.7071f, 2.5f);
            assert(std::isfinite(outIdentical));
        }
        std::cout << "   - Triple-coincident singularity test: PASSED (out=" << outIdentical << ")\n";

        // B. Micro-step input stress test (d0 = 1e-7, exercising 4th-order Taylor)
        float x = 0.50000000f;
        for (int i = 0; i < 50; ++i) {
            float y = clipper.processSample(x, 1.8f);
            assert(std::isfinite(y));
            x += 1.0e-7f; // Tiny increment
        }
        std::cout << "   - Micro-differential Taylor expansion (1e-7): PASSED\n";

        // C. NaN and Extreme overdrive guard
        float outNan = clipper.processSample(std::numeric_limits<float>::quiet_NaN(), 1.0f);
        float outOver = clipper.processSample(100.0f, 10.0f);
        assert(std::isfinite(outNan));
        assert(std::isfinite(outOver));
        std::cout << "   - NaN and +100.0 extreme overdrive guard: PASSED (out=" << outOver << ")\n";
        passedTests++;
    }

    // -------------------------------------------------------------------------
    // TEST 2: Polyphase Half-Band IIR Oversampler (2x & 4x Low-Latency)
    // -------------------------------------------------------------------------
    std::cout << "\n[TEST 2] PolyphaseOversampler - Low-Latency Half-Band IIR 2x & 4x...\n";
    {
        PolyphaseHalfBand2x over2x;
        over2x.reset();

        float inSample = 0.85f;
        float up0 = 0.0f, up1 = 0.0f;
        over2x.upsample(inSample, up0, up1);
        assert(std::isfinite(up0) && std::isfinite(up1));

        float downSample = over2x.downsample(up0, up1);
        assert(std::isfinite(downSample));
        std::cout << "   - Polyphase 2x Up/Down (Latency=" << over2x.getLatencySamples() << " samples): PASSED\n";

        PolyphaseOversampler4x over4x;
        over4x.reset();
        std::array<float, 4> up4x{};
        over4x.upsample(inSample, up4x);
        for (float s : up4x) assert(std::isfinite(s));
        float down4x = over4x.downsample(up4x);
        assert(std::isfinite(down4x));
        std::cout << "   - Polyphase 4x Cascaded (Latency=" << over4x.getLatencySamples() << " samples): PASSED\n";
        passedTests++;
    }

    // -------------------------------------------------------------------------
    // TEST 3: Dynamic Magnetic Core Saturation & Multi-Profile Transformer
    // -------------------------------------------------------------------------
    std::cout << "\n[TEST 3] TransformerSaturator - Magnetic Core Hysteresis & Profiles...\n";
    {
        TransformerSaturator trans;
        trans.prepare(48000.0);

        // Test all 4 vintage profiles
        std::vector<TransformerSaturator::CoreProfile> profiles = {
            TransformerSaturator::CoreProfile::NeveMarinair,
            TransformerSaturator::CoreProfile::APIPunch,
            TransformerSaturator::CoreProfile::FocusriteLundahl,
            TransformerSaturator::CoreProfile::StuderTapeCore
        };

        const char* names[] = { "Neve Marinair LO1166", "API 2503 Punch", "Focusrite Lundahl 1538", "Studer A800 Tape" };

        for (size_t p = 0; p < profiles.size(); ++p) {
            trans.setProfile(profiles[p]);
            trans.reset();

            // Low frequency 50 Hz test tone for heavy magnetic flux swing
            float maxOut = 0.0f;
            for (int i = 0; i < 480; ++i) {
                float inTone = std::sin(2.0f * 3.14159265f * 50.0f * (float)i / 48000.0f);
                float out = trans.processSample(inTone, 2.0f, 1.0f);
                assert(std::isfinite(out));
                maxOut = std::max(maxOut, std::abs(out));
            }
            std::cout << "   - Profile [" << names[p] << "] 50 Hz Flux Saturation: PASSED (Peak=" << maxOut << ")\n";
        }
        passedTests++;
    }

    // -------------------------------------------------------------------------
    // TEST 4: API Thrust Sidechain Filter & T4B Luminescent Opto Compressor
    // -------------------------------------------------------------------------
    std::cout << "\n[TEST 4] CLA2ACompressor & API Thrust Sidechain Engine...\n";
    {
        CLA2ACompressor comp;
        comp.prepare(48000.0);
        comp.setPeakReduction(65.0f);
        comp.setGain(40.0f);

        // A. Normal Mode
        comp.setThrustMode(APIThrustFilter::ThrustMode::Normal);
        std::vector<float> bufL(512, 0.7f), bufR(512, 0.7f);
        comp.process(bufL.data(), bufR.data(), bufL.size());
        float grNormal = comp.getGainReductionL();
        assert(grNormal > 0.0f && std::isfinite(grNormal));

        // B. Loud Thrust Mode (Equalized acoustic energy tilt)
        comp.setThrustMode(APIThrustFilter::ThrustMode::Loud);
        comp.process(bufL.data(), bufR.data(), bufL.size());
        float grThrust = comp.getGainReductionL();
        assert(std::isfinite(grThrust));

        std::cout << "   - Dual-Trap T4B Opto Response (GR Normal=" << grNormal << " dB): PASSED\n";
        std::cout << "   - API Thrust Mode Switch (GR Loud Thrust=" << grThrust << " dB): PASSED\n";
        passedTests++;
    }

    // -------------------------------------------------------------------------
    // TEST 5: IEC 60268-17 Physical Moving-Coil VU Meter Ballistics Engine
    // -------------------------------------------------------------------------
    std::cout << "\n[TEST 5] BoutiqueVUBallistics - IEC 60268-17 300ms Ballistics & Peak LED...\n";
    {
        BoutiqueVUBallistics meter;
        meter.prepare(48000.0);
        meter.setCalibration(BoutiqueVUBallistics::Calibration::Minus18dBFS);
        meter.setMode(BoutiqueVUBallistics::Mode::VU);

        // Apply a 300 ms calibrated tone burst at -18 dBFS RMS (Peak = RMS * sqrt(2))
        const float toneRms = 0.12589254f;
        const float tonePeak = toneRms * 1.41421356f;
        const int burstSamples = static_cast<int>(48000.0 * 0.300); // 300 ms
        float maxDeflection = 0.0f;

        for (int i = 0; i < burstSamples; ++i) {
            float s = tonePeak * std::sin(2.0f * 3.14159265f * 1000.0f * (float)i / 48000.0f);
            meter.processSample(s);
            maxDeflection = std::max(maxDeflection, meter.getDeflectionNormalized());
        }

        // Standard IEC 60268-17 requires reaching 99% - 101.5% deflection (0.99 to 1.015)
        std::cout << "   - 300 ms Tone Burst Deflection: " << maxDeflection * 100.0f << "% (IEC Standard: 99%-101.5%)\n";
        assert(maxDeflection >= 0.95f && maxDeflection <= 1.05f);

        // Needle angle verification
        float angleDeg = meter.getNeedleAngleDegrees();
        std::cout << "   - Needle Angle at 0 VU: " << angleDeg << " degrees\n";
        assert(std::abs(angleDeg) < 3.0f); // Should be very close to 0 deg at 0 VU

        // Peak Overload LED test
        meter.processSample(1.0f); // Digital 0 dBFS full scale spike
        assert(meter.isPeakLedActive());
        std::cout << "   - True Peak LED Trigger (1 ms Attack): PASSED (LED Active=" << (meter.isPeakLedActive() ? "TRUE" : "FALSE") << ")\n";
        passedTests++;
    }

    // -------------------------------------------------------------------------
    // TEST 6: Real-Time 2048-Point Lock-Free Spectral Visualizer
    // -------------------------------------------------------------------------
    std::cout << "\n[TEST 6] FFTSpectralVisualizer - 2048-pt Blackman-Harris & Lock-Free FIFO...\n";
    {
        FFTSpectralVisualizer fft;
        fft.prepare(48000.0);

        // Push 1 kHz pure sine wave into lock-free audio thread FIFO
        for (int i = 0; i < 2048; ++i) {
            float s = 0.707f * std::sin(2.0f * 3.14159265f * 1000.0f * (float)i / 48000.0f);
            fft.pushSample(s);
        }

        // GUI thread updates analysis
        fft.updateAnalysis(1.5f);
        const auto& bands = fft.getBandLevels();

        float maxBandEnergy = 0.0f;
        size_t peakBandIndex = 0;
        for (size_t b = 0; b < bands.size(); ++b) {
            if (bands[b] > maxBandEnergy) {
                maxBandEnergy = bands[b];
                peakBandIndex = b;
            }
        }

        std::cout << "   - 64-Band Log Spectrum FFT (Peak at Band #" << peakBandIndex 
                  << " with Energy=" << maxBandEnergy << "): PASSED\n";
        assert(maxBandEnergy > 0.5f);
        passedTests++;
    }

    // -------------------------------------------------------------------------
    // SUMMARY
    // -------------------------------------------------------------------------
    std::cout << "\n========================================================\n";
    std::cout << "  RISULTATO VERIFICA: " << passedTests << " / " << totalTests << " TEST SUPERATI CON SUCCESSO! \n";
    std::cout << "========================================================\n";

    return (passedTests == totalTests) ? 0 : 1;
}
