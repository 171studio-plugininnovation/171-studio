#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include <chrono>
#include <thread>
#include <atomic>
#include <random>
#include <cassert>
#include <string>

// Include core DSP and Neural Brain
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include <dsp171/VocalCraftNeuralBrain.h>
#include <dsp171/VocalCraftEngine.h>

using namespace dsp171;

// =============================================================================
// Heap Allocation Trap for Zero-Allocation Audio Thread Verification
// =============================================================================
static std::atomic<bool> g_trapAllocations{false};
static std::atomic<uint64_t> g_allocationCount{0};

void* operator new(size_t size) {
    if (g_trapAllocations.load(std::memory_order_relaxed)) {
        g_allocationCount.fetch_add(1, std::memory_order_relaxed);
    }
    return std::malloc(size);
}

void* operator new[](size_t size) {
    if (g_trapAllocations.load(std::memory_order_relaxed)) {
        g_allocationCount.fetch_add(1, std::memory_order_relaxed);
    }
    return std::malloc(size);
}

void operator delete(void* p) noexcept {
    std::free(p);
}

void operator delete[](void* p) noexcept {
    std::free(p);
}

void operator delete(void* p, size_t) noexcept {
    std::free(p);
}

void operator delete[](void* p, size_t) noexcept {
    std::free(p);
}

// =============================================================================
// Helper Signal Generators
// =============================================================================
void generateSine(std::vector<float>& buf, double sampleRate, double freqHz, double amplitude) {
    const double phaseIncr = 2.0 * std::numbers::pi * freqHz / sampleRate;
    double phase = 0.0;
    for (size_t i = 0; i < buf.size(); ++i) {
        buf[i] = static_cast<float>(amplitude * std::sin(phase));
        phase += phaseIncr;
        if (phase >= 2.0 * std::numbers::pi) phase -= 2.0 * std::numbers::pi;
    }
}

void generateWhiteNoise(std::vector<float>& buf, float amplitude, uint32_t seed = 12345) {
    std::mt19937 rng(seed);
    std::uniform_real_distribution<float> dist(-amplitude, amplitude);
    for (size_t i = 0; i < buf.size(); ++i) {
        buf[i] = dist(rng);
    }
}

void generatePinkNoise(std::vector<float>& buf, float amplitude, uint32_t seed = 54321) {
    // Paul Kellet's filtered pink noise generator
    std::mt19937 rng(seed);
    std::uniform_real_distribution<float> dist(-1.0f, 1.0f);
    float b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (size_t i = 0; i < buf.size(); ++i) {
        float white = dist(rng);
        b0 = 0.99886f * b0 + white * 0.0555179f;
        b1 = 0.99332f * b1 + white * 0.0750759f;
        b2 = 0.96900f * b2 + white * 0.1538520f;
        b3 = 0.86650f * b3 + white * 0.3104856f;
        b4 = 0.55000f * b4 + white * 0.5329522f;
        b5 = -0.7616f * b5 - white * 0.0168980f;
        float pink = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362f;
        b6 = white * 0.115926f;
        buf[i] = pink * 0.11f * amplitude;
    }
}

// =============================================================================
// MAIN AUDIT SUITE
// =============================================================================
int main() {
    std::cout << "=======================================================================\n";
    std::cout << "171 STUDIO INNOVATIO - VOCALCRAFT NEURAL BRAIN AUDIT SUITE (C++20)\n";
    std::cout << "=======================================================================\n\n";

    int failures = 0;

    // -------------------------------------------------------------------------
    // TEST 1: ZERO HEAP ALLOCATION AUDIT IN AUDIO THREAD
    // -------------------------------------------------------------------------
    std::cout << "[TEST 1] Auditing Zero Heap Allocation Ban in Audio Thread...\n";
    {
        VocalCraftNeuralBrain brain;
        brain.prepare(96000.0);

        VocalCraftEngine engine;
        engine.prepare(96000.0, 512);

        std::vector<float> vocalL(512, 0.5f);
        std::vector<float> vocalR(512, 0.5f);
        std::vector<float> beatL(512, 0.3f);
        std::vector<float> beatR(512, 0.3f);

        float* channelData[2] = { vocalL.data(), vocalR.data() };
        const float* beatData[2] = { beatL.data(), beatR.data() };

        // Warm up
        brain.analyzeAndInfer(vocalL.data(), vocalR.data(), beatL.data(), beatR.data(), 512, 0);
        engine.processWithBeat(channelData, 2, beatData, 2, 512);

        // Turn on allocation trap
        g_allocationCount.store(0);
        g_trapAllocations.store(true);

        for (int b = 0; b < 1000; ++b) {
            brain.analyzeAndInfer(vocalL.data(), vocalR.data(), beatL.data(), beatR.data(), 512, 1);
            auto snap = brain.getTelemetrySnapshot();
            (void)snap;
            engine.processWithBeat(channelData, 2, beatData, 2, 512);
        }

        g_trapAllocations.store(false);
        uint64_t allocs = g_allocationCount.load();
        std::cout << "  - Heap Allocations during 1000 audio blocks (prepare excluded): " << allocs << "\n";
        if (allocs == 0) {
            std::cout << "  -> [PASS] ZERO HEAP ALLOCATIONS STRICTLY MAINTAINED.\n";
        } else {
            std::cout << "  -> [FAIL] Heap allocations detected: " << allocs << "\n";
            failures++;
        }
    }

    // -------------------------------------------------------------------------
    // TEST 2: EXECUTION BUDGET AUDIT (< 50 us at 96 kHz)
    // -------------------------------------------------------------------------
    std::cout << "\n[TEST 2] Auditing Real-Time Execution Budget (< 50 us per block)...\n";
    {
        VocalCraftNeuralBrain brain;
        brain.prepare(96000.0);

        std::vector<float> vocalL(128, 0.25f);
        std::vector<float> vocalR(128, 0.25f);
        std::vector<float> beatL(128, 0.20f);
        std::vector<float> beatR(128, 0.20f);

        // Warm up
        for (int i = 0; i < 500; ++i) {
            brain.analyzeAndInfer(vocalL.data(), vocalR.data(), beatL.data(), beatR.data(), 128, 0);
        }

        constexpr int kBenchmarkRuns = 10000;
        std::vector<double> timingsUs;
        timingsUs.reserve(kBenchmarkRuns);

        for (int i = 0; i < kBenchmarkRuns; ++i) {
            auto tStart = std::chrono::high_resolution_clock::now();
            brain.analyzeAndInfer(vocalL.data(), vocalR.data(), beatL.data(), beatR.data(), 128, (i % 4));
            auto tEnd = std::chrono::high_resolution_clock::now();
            double durUs = std::chrono::duration<double, std::micro>(tEnd - tStart).count();
            timingsUs.push_back(durUs);
        }

        std::sort(timingsUs.begin(), timingsUs.end());
        double minUs = timingsUs.front();
        double medUs = timingsUs[kBenchmarkRuns / 2];
        double p95Us = timingsUs[static_cast<size_t>(kBenchmarkRuns * 0.95)];
        double p99Us = timingsUs[static_cast<size_t>(kBenchmarkRuns * 0.99)];
        double maxUs = timingsUs.back();

        std::cout << std::fixed << std::setprecision(2);
        std::cout << "  - 96 kHz / 128 samples (1.33 ms audio block budget):\n";
        std::cout << "    Min:    " << minUs << " us\n";
        std::cout << "    Median: " << medUs << " us\n";
        std::cout << "    p95:    " << p95Us << " us\n";
        std::cout << "    p99:    " << p99Us << " us\n";
        std::cout << "    Max:    " << maxUs << " us\n";

        if (medUs < 50.0 && p99Us < 50.0) {
            std::cout << "  -> [PASS] Sub-50us real-time budget verified!\n";
        } else {
            std::cout << "  -> [WARN/FAIL] Execution time exceeded 50us budget! (p99 = " << p99Us << " us)\n";
            if (medUs >= 50.0) failures++;
        }
    }

    // -------------------------------------------------------------------------
    // TEST 3: 16-D FEATURE EXTRACTOR PHYSICAL & MATHEMATICAL VERIFICATION
    // -------------------------------------------------------------------------
    std::cout << "\n[TEST 3] Auditing 16-D Feature Extractor Mathematical & Physical Rules...\n";
    {
        VocalCraftNeuralBrain brain;
        brain.prepare(44100.0);

        // Subtest 3.1: Digital Silence
        {
            std::vector<float> silence(512, 0.0f);
            for (int i = 0; i < 20; ++i)
                brain.analyzeAndInfer(silence.data(), silence.data(), nullptr, nullptr, 512, 0);

            auto snap = brain.getTelemetrySnapshot();
            std::cout << "  3.1 Digital Silence:\n";
            std::cout << "      RMS:             " << snap.inputRmsDb << " dBFS (expected <= -90.0)\n";
            std::cout << "      Crest Factor:    " << snap.crestFactor << " (expected 1.0)\n";
            std::cout << "      Centroid:        " << snap.spectralCentroidHz << " Hz\n";
            std::cout << "      Flux:            " << snap.spectralFlux << " (expected 0.0)\n";
            std::cout << "      Wiener Entropy:  " << snap.spectralFlatness << " (expected 0.0)\n";
            std::cout << "      Phoneme Class:   " << snap.phonemeClass << " (expected 0: Silence)\n";

            assert(snap.inputRmsDb <= -90.0f);
            assert(snap.crestFactor == 1.0f);
            assert(snap.spectralFlux <= 0.01f);
            assert(snap.spectralFlatness == 0.0f);
            assert(snap.phonemeClass == kPhonemeSilence);

            if (snap.spectralCentroidHz > 1050.0f) {
                std::cout << "      -> [CRITICAL FINDING]: Spectral centroid on silence returned " 
                          << snap.spectralCentroidHz << " Hz instead of resting 1000 Hz!\n"
                          << "         Cause: kEpsilonPower inside sqrt(power) prevents sumMagnitude <= 1e-7!\n";
            } else {
                std::cout << "      -> Spectral centroid correctly at resting 1000 Hz.\n";
            }
        }

        // Subtest 3.2: 1 kHz Sine Tone (0 dBFS peak = -3.01 dBFS RMS)
        {
            brain.reset();
            std::vector<float> tone(512);
            generateSine(tone, 44100.0, 1000.0, 1.0);
            for (int i = 0; i < 20; ++i)
                brain.analyzeAndInfer(tone.data(), tone.data(), nullptr, nullptr, 512, 0);

            auto snap = brain.getTelemetrySnapshot();
            std::cout << "  3.2 1 kHz Pure Sine Wave (Peak 1.0):\n";
            std::cout << "      RMS:             " << snap.inputRmsDb << " dBFS (expected ~ -3.0 dBFS)\n";
            std::cout << "      Crest Factor:    " << snap.crestFactor << " (expected ~ 1.414)\n";
            std::cout << "      Centroid:        " << snap.spectralCentroidHz << " Hz (expected ~ 1000 Hz)\n";
            std::cout << "      Wiener Entropy:  " << snap.spectralFlatness << " (expected ~ 0.0, tonality)\n";
            std::cout << "      F2 Energy (1350Hz band): " << snap.f2EnergyDb << " dBFS\n";

            if (std::abs(snap.inputRmsDb - (-3.01f)) < 1.0f && std::abs(snap.crestFactor - 1.414f) < 0.15f) {
                std::cout << "      -> [PASS] Pure tone acoustics verified.\n";
            } else {
                std::cout << "      -> [FAIL] Tone acoustics outside tolerance!\n";
                failures++;
            }
        }

        // Subtest 3.3: White Noise vs Pure Tone Wiener Entropy
        {
            brain.reset();
            std::vector<float> white(512);
            generateWhiteNoise(white, 0.25f);
            for (int i = 0; i < 30; ++i)
                brain.analyzeAndInfer(white.data(), white.data(), nullptr, nullptr, 512, 0);

            auto snapWhite = brain.getTelemetrySnapshot();
            std::cout << "  3.3 White Noise Wiener Entropy:\n";
            std::cout << "      Wiener Entropy:  " << snapWhite.spectralFlatness << " (expected > 0.70 for noise)\n";
            std::cout << "      Centroid:        " << snapWhite.spectralCentroidHz << " Hz (expected ~ 10-12 kHz)\n";

            if (snapWhite.spectralFlatness > 0.65f) {
                std::cout << "      -> [PASS] Wiener entropy distinguishes noise from tonal body.\n";
            } else {
                std::cout << "      -> [WARN/FAIL] Flatness lower than expected for white noise: " << snapWhite.spectralFlatness << "\n";
            }
        }

        // Subtest 3.4: Pure DC Offset (1.0 constant, 0 dBFS)
        {
            brain.reset();
            std::vector<float> dc(512, 1.0f);
            for (int i = 0; i < 30; ++i)
                brain.analyzeAndInfer(dc.data(), dc.data(), nullptr, nullptr, 512, 0);

            auto snapDC = brain.getTelemetrySnapshot();
            std::cout << "  3.4 Pure DC Offset (1.0):\n";
            std::cout << "      RMS:             " << snapDC.inputRmsDb << " dBFS (expected 0.0 dBFS)\n";
            std::cout << "      Crest:           " << snapDC.crestFactor << " (expected 1.0)\n";
            std::cout << "      Sub Rumble (<60Hz): " << snapDC.subRumbleEnergyDb << " dBFS (expected ~ 0 dBFS)\n";
            std::cout << "      F1 (450Hz):      " << snapDC.f1EnergyDb << " dBFS (expected <= -80 dBFS)\n";
            std::cout << "      Sibilant:        " << snapDC.sibilantEnergyDb << " dBFS (expected <= -80 dBFS)\n";
            std::cout << "      Phoneme:         " << snapDC.phonemeClass << "\n";

            if (snapDC.subRumbleEnergyDb > -6.0f && snapDC.f1EnergyDb <= -70.0f) {
                std::cout << "      -> [PASS] DC isolation correctly assigned to sub-rumble.\n";
            } else {
                std::cout << "      -> [WARN] DC filterbank bleed: Sub=" << snapDC.subRumbleEnergyDb 
                          << ", F1=" << snapDC.f1EnergyDb << "\n";
            }
        }

        // Subtest 3.5: Extreme Sibilance Burst (7 kHz sine burst)
        {
            brain.reset();
            std::vector<float> sib(512);
            generateSine(sib, 44100.0, 6800.0, 0.40); // -8 dBFS at 6.8 kHz
            for (int i = 0; i < 20; ++i)
                brain.analyzeAndInfer(sib.data(), sib.data(), nullptr, nullptr, 512, 0);

            auto snapSib = brain.getTelemetrySnapshot();
            std::cout << "  3.5 Sibilance Burst (6.8 kHz, -8 dBFS):\n";
            std::cout << "      Centroid:        " << snapSib.spectralCentroidHz << " Hz (expected > 5500 Hz)\n";
            std::cout << "      Sibilant Energy: " << snapSib.sibilantEnergyDb << " dBFS (expected > -15 dBFS)\n";
            std::cout << "      Phoneme Class:   " << snapSib.phonemeClass << " (expected 3: Sibilant/Fricative)\n";
            std::cout << "      Predicted Deess Depth: " << snapSib.deesserDepthDb << " dB\n";

            if (snapSib.phonemeClass == kPhonemeSibilantFricative && snapSib.spectralCentroidHz > 5000.0f) {
                std::cout << "      -> [PASS] Sibilance acoustics & phoneme classification accurate.\n";
            } else {
                std::cout << "      -> [FAIL] Sibilance not classified correctly! Phoneme=" << snapSib.phonemeClass << "\n";
                failures++;
            }
        }

        // Subtest 3.6: Step Transient / Plosive Burst (Low-Frequency Vocal Plosive)
        {
            brain.reset();
            std::vector<float> plosive(512, 0.0f);
            // Realistic plosive: burst of 200 Hz vocal air pop with fast decay
            for (size_t i = 0; i < 64; ++i) {
                float env = std::exp(-static_cast<float>(i) / 15.0f);
                plosive[i] = env * std::sin(2.0f * PI * 200.0f * static_cast<float>(i) / 44100.0f);
            }

            brain.analyzeAndInfer(plosive.data(), plosive.data(), nullptr, nullptr, 512, 0);
            brain.analyzeAndInfer(plosive.data(), plosive.data(), nullptr, nullptr, 512, 0);
            auto snapPulse = brain.getTelemetrySnapshot();
            float directCrest = brain.getFeature(kFeatureCrestFactor);
            float directFlux = brain.getFeature(kFeatureSpectralFlux);
            float directCentroid = brain.getFeature(kFeatureSpectralCentroidHz);
            int directPhoneme = brain.getPhonemeClass();
            float directPunch = brain.getPrediction(kPredConsonantPunch);

            std::cout << "  3.6 Vocal Plosive Burst (200 Hz burst with fast decay):\n";
            std::cout << "      Crest Factor:    " << directCrest << " (expected > 2.8)\n";
            std::cout << "      Spectral Flux:   " << directFlux << "\n";
            std::cout << "      Centroid:        " << directCentroid << " Hz (expected < 4000)\n";
            std::cout << "      Phoneme Class:   " << directPhoneme << " (expected 2: Plosive)\n";
            std::cout << "      Predicted Punch: " << directPunch << "\n";

            if (directPhoneme == kPhonemePlosive) {
                std::cout << "      -> [PASS] Physical vocal plosive correctly classified as kPhonemePlosive.\n";
            } else {
                std::cout << "      -> [WARN] Plosive classified as " << directPhoneme << "\n";
            }
        }

        // Subtest 3.7: 96 kHz Nyquist Boundary & Ultrasound (40 kHz tone)
        {
            brain.prepare(96000.0);
            brain.reset();
            std::vector<float> ultra(512);
            generateSine(ultra, 96000.0, 40000.0, 0.5); // 40 kHz ultrasound
            for (int i = 0; i < 20; ++i)
                brain.analyzeAndInfer(ultra.data(), ultra.data(), nullptr, nullptr, 512, 0);

            auto snapUltra = brain.getTelemetrySnapshot();
            std::cout << "  3.7 96 kHz Operation with 40 kHz Ultrasound:\n";
            std::cout << "      RMS:             " << snapUltra.inputRmsDb << " dBFS\n";
            std::cout << "      Centroid:        " << snapUltra.spectralCentroidHz << " Hz (clamped <= 20000)\n";
            std::cout << "      Inference Time:  " << snapUltra.lastInferenceTimeUs << " us\n";

            bool isAllFinite = true;
            for (float f : snapUltra.features) if (!std::isfinite(f)) isAllFinite = false;
            for (float p : snapUltra.predictions) if (!std::isfinite(p)) isAllFinite = false;

            if (isAllFinite && snapUltra.spectralCentroidHz <= 20000.0f) {
                std::cout << "      -> [PASS] 96 kHz numerical safety verified.\n";
            } else {
                std::cout << "      -> [FAIL] Non-finite or out-of-bounds at 96 kHz!\n";
                failures++;
            }
        }
    }

    // -------------------------------------------------------------------------
    // TEST 4: NEURAL INFERENCE DYNAMICS, GRU-16 STABILITY & SATURATION
    // -------------------------------------------------------------------------
    std::cout << "\n[TEST 4] Auditing Neural Inference Engine & GRU Recurrent Stability...\n";
    {
        NeuralInferenceEngine engine;
        engine.reset();

        // 4.1 Activation function verification
        std::cout << "  4.1 Activation Function Check:\n";
        float geluM6 = NeuralInferenceEngine::fastGELU(-6.0f);
        float gelu0  = NeuralInferenceEngine::fastGELU(0.0f);
        float gelu1  = NeuralInferenceEngine::fastGELU(1.0f);
        float geluP6 = NeuralInferenceEngine::fastGELU(6.0f);
        std::cout << "      GELU(-6): " << geluM6 << " (expected 0.0)\n";
        std::cout << "      GELU(0):  " << gelu0 << " (expected 0.0)\n";
        std::cout << "      GELU(1):  " << gelu1 << " (expected ~0.8413)\n";
        std::cout << "      GELU(6):  " << geluP6 << " (expected 6.0)\n";

        float lreluNeg = NeuralInferenceEngine::fastLeakyReLU(-2.0f);
        float lreluPos = NeuralInferenceEngine::fastLeakyReLU(2.0f);
        std::cout << "      LeakyReLU(-2): " << lreluNeg << " (expected -0.2)\n";
        std::cout << "      LeakyReLU(+2): " << lreluPos << " (expected +2.0)\n";

        assert(std::abs(gelu0) < 1e-5f);
        assert(std::abs(gelu1 - 0.8413f) < 0.05f);
        assert(std::abs(lreluNeg - (-0.2f)) < 1e-5f);

        // 4.2 500,000 Iteration Endurance Test (GRU Recurrent Stability & Bound Check)
        std::cout << "  4.2 Running 500,000 Iteration Endurance Test on GRU (16 States)...\n";
        std::mt19937 rng(42);
        std::uniform_real_distribution<float> fDist(-50.0f, 50.0f);

        float maxAbsH = 0.0f;
        bool stateDiverged = false;
        std::array<float, 8> preds{};

        for (int iter = 0; iter < 500000; ++iter) {
            std::array<float, 16> feat;
            for (size_t i = 0; i < 16; ++i) feat[i] = fDist(rng);

            engine.infer(feat, preds);

            const auto& h = engine.getHiddenState();
            for (size_t j = 0; j < 16; ++j) {
                float absH = std::abs(h[j]);
                if (absH > maxAbsH) maxAbsH = absH;
                if (!std::isfinite(h[j]) || absH > 1.0f + 1e-5f) {
                    stateDiverged = true;
                }
            }

            // Verify output bounded domains
            if (preds[kPredCompRatio] < 1.2f || preds[kPredCompRatio] > 12.0f) stateDiverged = true;
            if (preds[kPredConsonantPunch] < 0.0f || preds[kPredConsonantPunch] > 1.0f) stateDiverged = true;
            if (preds[kPredAcousticResonanceMask] < 0.0f || preds[kPredAcousticResonanceMask] > 1.0f) stateDiverged = true;
            if (preds[kPredDeesserThresholdOffsetDb] < -12.0f || preds[kPredDeesserThresholdOffsetDb] > 6.0f) stateDiverged = true;
            if (preds[kPredDeesserDepthDb] < 0.0f || preds[kPredDeesserDepthDb] > 14.0f) stateDiverged = true;
            if (preds[kPredBeatPocketCarveDb] < 0.0f || preds[kPredBeatPocketCarveDb] > 9.0f) stateDiverged = true;
            if (preds[kPredAirSheenBoostDb] < 0.0f || preds[kPredAirSheenBoostDb] > 6.0f) stateDiverged = true;
            if (preds[kPredDynamicFaderRideDb] < -4.0f || preds[kPredDynamicFaderRideDb] > 4.0f) stateDiverged = true;

            if (stateDiverged) {
                std::cout << "      -> [FAIL] State diverged at iteration " << iter << "!\n";
                failures++;
                break;
            }
        }

        std::cout << "      Max |h_t| across all 16 states over 500k iterations: " << maxAbsH << "\n";
        if (!stateDiverged && maxAbsH <= 1.00001f) {
            std::cout << "      -> [PASS] GRU recurrence strictly bounded in [-1, 1], zero drift.\n";
        } else {
            std::cout << "      -> [FAIL] GRU bounds violated!\n";
            failures++;
        }

        // 4.3 Adversarial Input Ingestion: NaNs, Infinities, +48 dBFS
        std::cout << "  4.3 Adversarial Numerical Input Ingestion (NaN, +Inf, -Inf, 1e20):\n";
        std::array<float, 16> advFeat;
        advFeat.fill(std::numeric_limits<float>::quiet_NaN());
        advFeat[0] = std::numeric_limits<float>::infinity();
        advFeat[1] = -std::numeric_limits<float>::infinity();
        advFeat[2] = 1e20f;

        engine.infer(advFeat, preds);
        bool nanInPreds = false;
        for (float p : preds) if (std::isnan(p)) nanInPreds = true;

        std::cout << "      Output CompRatio under NaN input: " << preds[kPredCompRatio] << "\n";
        std::cout << "      Output Punch under NaN input:     " << preds[kPredConsonantPunch] << "\n";
        std::cout << "      Output Carve under NaN input:     " << preds[kPredBeatPocketCarveDb] << "\n";
    }

    // -------------------------------------------------------------------------
    // TEST 5: PHYSICAL DSP INTEGRATION & SLEWING CLICK-FREE VERIFICATION
    // -------------------------------------------------------------------------
    std::cout << "\n[TEST 5] Auditing Physical DSP Parameter Integration & Click-Free Slewing...\n";
    {
        VocalCraftEngine engine;
        engine.prepare(44100.0, 512);

        // Turn on all processing
        engine.setLinearizerDepth(1.0f);
        engine.setCompressionAmount(0.8f);
        engine.setUnmaskAmount(1.0f);
        engine.setAirSheen(1.0f);
        engine.setDeessAmount(1.0f);
        engine.setClipperDrive(0.5f);

        // Generate test tone
        std::vector<float> left(512);
        std::vector<float> right(512);
        generateSine(left, 44100.0, 1000.0, 0.5);
        generateSine(right, 44100.0, 1000.0, 0.5);

        std::vector<float> beatL(512);
        std::vector<float> beatR(512);
        generateSine(beatL, 44100.0, 200.0, 0.5);
        generateSine(beatR, 44100.0, 200.0, 0.5);

        float* channelData[2] = { left.data(), right.data() };
        const float* beatData[2] = { beatL.data(), beatR.data() };

        float maxStepDerivative = 0.0f;
        float prevSample = 0.0f;

        // Run 50 blocks alternating style and signal levels to trigger maximum parameter slewing
        for (int b = 0; b < 50; ++b) {
            engine.setStyle(b % 4);
            if (b % 2 == 0) {
                generateSine(left, 44100.0, 1000.0, 0.8);
            } else {
                generateSine(left, 44100.0, 6000.0, 0.2);
            }
            right = left;

            engine.processWithBeat(channelData, 2, beatData, 2, 512);

            for (int i = 0; i < 512; ++i) {
                if (b > 0 || i > 0) {
                    float diff = std::abs(left[i] - prevSample);
                    if (diff > maxStepDerivative) maxStepDerivative = diff;
                }
                prevSample = left[i];
            }
        }

        std::cout << "  - Max sample-to-sample derivative under rapid block modulation: " << maxStepDerivative << "\n";
        // A full-scale 1 kHz sine at 44.1 kHz has natural derivative = 2*pi*1000/44100 * 0.8 = ~0.114
        if (maxStepDerivative < 0.60f) {
            std::cout << "  -> [PASS] Continuous click-free parameter transitions verified!\n";
        } else {
            std::cout << "  -> [WARN/FAIL] Potential discontinuity/click detected: derivative = " << maxStepDerivative << "\n";
        }
    }

    // -------------------------------------------------------------------------
    // TEST 6: THREAD SAFETY & SEQLOCK SNAPSHOT CONSISTENCY AUDIT
    // -------------------------------------------------------------------------
    std::cout << "\n[TEST 6] Auditing Seqlock Telemetry Snapshots & Concurrency...\n";
    {
        VocalCraftNeuralBrain brain;
        brain.prepare(96000.0);

        // First: Verify the single-block read index bug
        brain.reset();
        std::vector<float> testBlock(128, 0.5f);
        brain.analyzeAndInfer(testBlock.data(), testBlock.data(), nullptr, nullptr, 128, 0);

        auto firstSnap = brain.getTelemetrySnapshot();
        std::cout << "  6.1 Single-Block Telemetry Read Check:\n";
        std::cout << "      Inference Count Reported by Snapshot: " << firstSnap.inferenceCount << " (Actual = 1)\n";
        std::cout << "      Reported Input RMS:                   " << firstSnap.inputRmsDb << " dBFS\n";

        if (firstSnap.inferenceCount == 1) {
            std::cout << "      -> Seqlock correctly reported fresh snapshot.\n";
        } else {
            std::cout << "      -> [CRITICAL FINDING]: Seqlock readIdx vs writeIdx offset bug confirmed!\n"
                      << "         Snapshot returned inferenceCount = " << firstSnap.inferenceCount 
                      << " instead of 1 (read unwritten/stale buffer)!\n";
        }

        // 6.2 Multi-Threaded Concurrent Read/Write Stress Test
        std::cout << "  6.2 Multi-Threaded Stress Test (Audio Thread @ 96kHz vs GUI Thread @ 60FPS)...\n";
        std::atomic<bool> stopStress{false};
        std::atomic<uint64_t> totalReads{0};
        std::atomic<uint64_t> inconsistentReads{0};

        std::thread audioThread([&]() {
            std::vector<float> block(128, 0.4f);
            while (!stopStress.load(std::memory_order_relaxed)) {
                brain.analyzeAndInfer(block.data(), block.data(), nullptr, nullptr, 128, 0);
                std::this_thread::yield();
            }
        });

        std::thread guiThread([&]() {
            while (!stopStress.load(std::memory_order_relaxed)) {
                auto snap = brain.getTelemetrySnapshot();
                totalReads.fetch_add(1, std::memory_order_relaxed);

                // Verify internal consistency: if inferenceCount > 0, features must not be all zeros
                if (snap.inferenceCount > 0 && snap.inputRmsDb < -95.0f) {
                    inconsistentReads.fetch_add(1, std::memory_order_relaxed);
                }
                std::this_thread::yield();
            }
        });

        std::this_thread::sleep_for(std::chrono::milliseconds(500));
        stopStress.store(true);
        audioThread.join();
        guiThread.join();

        std::cout << "      Total GUI Telemetry Snapshots: " << totalReads.load() << "\n";
        std::cout << "      Inconsistent / Torn Snapshots: " << inconsistentReads.load() << "\n";
        if (inconsistentReads.load() == 0) {
            std::cout << "      -> [PASS] Zero torn reads detected under aggressive concurrency.\n";
        } else {
            std::cout << "      -> [FAIL] Inconsistent reads detected under concurrency!\n";
            failures++;
        }
    }

    std::cout << "\n=======================================================================\n";
    std::cout << "AUDIT SUITE COMPLETE - Total Critical Failures: " << failures << "\n";
    std::cout << "=======================================================================\n";

    return failures;
}
