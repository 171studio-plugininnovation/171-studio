#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include "dsp171/Common.h"
#include "dsp171/TDPSOLAShifter.h"
#include "dsp171/FormantShaperZDF.h"
#include "dsp171/RealTuneEngine.h"

using namespace dsp171;

int main() {
    std::cout << "=========================================================\n";
    std::cout << "DIAGNOSTIC TEST: PITCH DOWN & FAST TRANSITIONS & HARSHNESS\n";
    std::cout << "=========================================================\n\n";

    const double sr = 48000.0;

    // Test with low latency = 192 samples, T0 = 400 samples (120 Hz)
    std::cout << "--- 1. TDPSOLA: Low Latency (192) vs T0 = 400 (120 Hz) ---\n";
    {
        TDPSOLAShifter shifter;
        shifter.prepare(sr, 192);

        const float f0 = 120.0f;
        const float t0 = static_cast<float>(sr / f0); // 400 samples
        const float pitchRatioDown = 0.840896f; // -3 semitones down

        const size_t numSamples = 48000;
        std::vector<float> input(numSamples, 0.0f);
        std::vector<float> output(numSamples, 0.0f);

        for (size_t i = 0; i < numSamples; ++i) {
            float phase = std::fmod(static_cast<float>(i), t0) / t0;
            // Glottal waveform with sharp closure slope
            if (phase < 0.15f) {
                input[i] = -std::sin(phase / 0.15f * PI);
            } else {
                input[i] = 0.08f * std::sin((phase - 0.15f) / 0.85f * PI);
            }
        }

        float maxStepDelta = 0.0f;
        size_t worstSample = 0;
        float maxAmp = 0.0f;

        for (size_t i = 0; i < numSamples; ++i) {
            float outL = 0.0f, outR = 0.0f;
            shifter.processStereo(input[i], input[i], outL, outR, t0, pitchRatioDown, true, 0.95f);
            output[i] = outL;
            maxAmp = std::max(maxAmp, std::abs(outL));

            if (i > 1000) {
                float delta = std::abs(output[i] - output[i - 1]);
                if (delta > maxStepDelta) {
                    maxStepDelta = delta;
                    worstSample = i;
                }
            }
        }

        std::cout << "T0 = 400, Latency = 192, Ratio = " << pitchRatioDown << " (-3 st)\n";
        std::cout << "Shifter Jumps: " << shifter.getJumpCount() << "\n";
        std::cout << "Max Output Amp: " << maxAmp << " (Input Max: 1.0) -> Gain swell: " 
                  << (20.0f * std::log10(maxAmp)) << " dB\n";
        std::cout << "Max Step Discontinuity Delta: " << maxStepDelta << " at sample " << worstSample << "\n\n";
    }

    // Fast Note Switch Test (Hard-Tune or rapid note transition)
    std::cout << "--- 2. Fast Note Change in RealTuneEngine (Snap to Note Below) ---\n";
    {
        RealTuneEngine engine;
        engine.prepare(sr, 512);
        engine.setScale(ScaleType::Chromatic);
        engine.setRetuneSpeedMs(0.0f); // Hard-Tune
        engine.setLowLatencyMode(true); // 192 samples

        // Sing a pitch dropping rapidly from 240 Hz to 175 Hz (B3 to F3)
        const size_t numSamples = 48000;
        std::vector<float> inL(numSamples, 0.0f);
        std::vector<float> inR(numSamples, 0.0f);
        std::vector<float> outL(numSamples, 0.0f);
        std::vector<float> outR(numSamples, 0.0f);

        double curPhase = 0.0;
        for (size_t i = 0; i < numSamples; ++i) {
            float f = (i < 24000) ? 240.0f : 175.0f;
            curPhase += 2.0 * PI_D * f / sr;
            if (curPhase >= 2.0 * PI_D) curPhase -= 2.0 * PI_D;
            float s = 0.7f * static_cast<float>(std::sin(curPhase));
            inL[i] = s;
            inR[i] = s;
        }

        const float* ins[2] = { inL.data(), inR.data() };
        float* outs[2] = { outL.data(), outR.data() };
        engine.process(ins, outs, 2, numSamples);

        float maxStepDelta = 0.0f;
        size_t worstIdx = 0;
        for (size_t i = 1; i < numSamples; ++i) {
            float delta = std::abs(outL[i] - outL[i - 1]);
            if (delta > maxStepDelta) {
                maxStepDelta = delta;
                worstIdx = i;
            }
        }
        std::cout << "Hard-Tune Fast Switch Max Step Delta: " << maxStepDelta << " at sample " << worstIdx << "\n\n";
    }

    // 3. FormantShaperZDF response on -4 and -6 semitones
    std::cout << "--- 3. FormantShaperZDF Spectral Boost on -4 st and -6 st ---\n";
    {
        FormantShaperZDF shaper;
        shaper.prepare(sr);
        shaper.setKeepFormants(true);

        const std::vector<float> semitonesDown = { -3.0f, -6.0f };
        for (float st : semitonesDown) {
            float ratio = std::pow(2.0f, st / 12.0f);
            shaper.reset();
            shaper.setKeepFormants(true);
            shaper.updateTracking(200.0f, ratio, true);
            for (int i = 0; i < 4000; ++i) shaper.processSample(0.0f);

            std::cout << "\nSpectral Response for " << st << " semitones (AutoShift = +" << (-st) << " st):\n";
            const std::vector<float> freqs = { 200.0f, 650.0f, 1500.0f, 2500.0f, 2900.0f, 3500.0f, 5000.0f, 8000.0f };
            for (float f : freqs) {
                float maxIn = 0.0f, maxOut = 0.0f;
                for (int i = 0; i < 4800; ++i) {
                    float sIn = std::sin(2.0f * PI * f * static_cast<float>(i) / static_cast<float>(sr));
                    float sOut = shaper.processSample(sIn);
                    if (i > 3800) {
                        maxIn = std::max(maxIn, std::abs(sIn));
                        maxOut = std::max(maxOut, std::abs(sOut));
                    }
                }
                float gainDb = 20.0f * std::log10(maxOut / maxIn);
                std::cout << "  Freq " << std::setw(6) << f << " Hz: Gain = " 
                          << std::showpos << std::fixed << std::setprecision(2) << gainDb << " dB\n";
            }
        }
    }

    return 0;
}
