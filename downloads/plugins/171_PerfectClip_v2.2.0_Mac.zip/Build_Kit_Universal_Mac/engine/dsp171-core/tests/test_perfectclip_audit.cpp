#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <cassert>
#include <numbers>
#include "dsp171/Common.h"
#include "dsp171/FastMath.h"
#include "dsp171/ADAA2HardClipper.h"
#include "dsp171/ADAA2Clipper.h"
#include "dsp171/AcousticThermalDiodeClipper.h"
#include "dsp171/PolyphaseOversampler.h"
#include "dsp171/TruePeakLimiterBS1770.h"
#include "dsp171/TransDetailMatrix.h"
#include "dsp171/PerfectClipEngine.h"

using namespace dsp171;

int main() {
    std::cout << "===================================================================\n";
    std::cout << "  171PerfectClip: Metrological & Acoustic Precision Audit Suite   \n";
    std::cout << "  Target: ULTIMA VERSIONE v1.0.0 & Backlog Requirements           \n";
    std::cout << "===================================================================\n\n";

    int passedTests = 0;
    int totalTests = 0;

    // -------------------------------------------------------------
    // TEST 1: ADAA-2 Piecewise Hard Clipper - Singularity & Taylor Expansion
    // -------------------------------------------------------------
    totalTests++;
    std::cout << "[TEST 1] ADAA-2 Hard Clipper (ADAA2HardClipper) Numerical Stability...\n";
    {
        ADAA2HardClipper clipper;
        clipper.reset();
        bool ok = true;

        // 1. Identical constant stress (x0 = x1 = x2)
        for (float v : { -2.0f, -1.0f, -0.5f, 0.0f, 0.5f, 1.0f, 2.0f }) {
            for (int i = 0; i < 50; ++i) {
                float out = clipper.processSample(v, 1.0f);
                if (!std::isfinite(out) || std::abs(out) > 1.00001f) {
                    ok = false;
                }
            }
        }

        // 2. Micro-delta steps near eps (x0 ~ x2, x0 ~ x1)
        clipper.reset();
        float base = 1.0f;
        for (double delta = 1e-12; delta <= 1e-3; delta *= 10.0) {
            clipper.processSample(static_cast<float>(base), 1.0f);
            clipper.processSample(static_cast<float>(base + delta), 1.0f);
            float out = clipper.processSample(static_cast<float>(base), 1.0f);
            if (!std::isfinite(out) || std::abs(out) > 1.00001f) {
                ok = false;
            }
        }

        // 3. Threshold scaling compliance
        for (float th : { 0.1f, 0.5f, 0.707f, 1.0f, 2.0f }) {
            clipper.reset();
            for (int i = 0; i < 100; ++i) {
                float in = (i % 2 == 0 ? 3.0f : -3.0f);
                float out = clipper.processSample(in, th);
                if (!std::isfinite(out) || std::abs(out) > th * 1.00001f) {
                    ok = false;
                }
            }
        }

        if (ok) {
            std::cout << "  -> PASSED: Zero NaNs, zero Infs, strictly bounded by threshold.\n";
            passedTests++;
        } else {
            std::cout << "  -> FAILED: Instability detected in ADAA2HardClipper!\n";
        }
    }

    // -------------------------------------------------------------
    // TEST 2: Polyphase 2x & 4x Oversampler - Stopband & Latency
    // -------------------------------------------------------------
    totalTests++;
    std::cout << "\n[TEST 2] Polyphase Oversampler (PolyphaseOversampler4x) Passband & Stopband...\n";
    {
        PolyphaseOversampler4x os4;
        os4.reset();
        bool ok = true;

        // Latency test
        float reportedLatency = PolyphaseOversampler4x::getLatencySamples();
        if (reportedLatency <= 0.0f || reportedLatency > 10.0f) {
            ok = false;
        }

        // Passband impulse response unity test
        std::array<float, 4> up{};
        float sumOut = 0.0f;
        // Process DC ramp
        for (int i = 0; i < 500; ++i) {
            os4.upsample(1.0f, up);
            float down = os4.downsample(up);
            if (i > 300) {
                if (std::abs(down - 1.0f) > 0.005f) {
                    ok = false;
                }
            }
        }

        if (ok) {
            std::cout << "  -> PASSED: Unity gain confirmed, latency = " << reportedLatency << " samples (Ultra-low).\n";
            passedTests++;
        } else {
            std::cout << "  -> FAILED in PolyphaseOversampler4x!\n";
        }
    }

    // -------------------------------------------------------------
    // TEST 3: ITU-R BS.1770-4 True-Peak Limiter (-0.05 dBTP precision check)
    // -------------------------------------------------------------
    totalTests++;
    std::cout << "\n[TEST 3] TruePeakLimiterBS1770 - Inter-Sample Peak (ISP) Ceiling Test...\n";
    {
        TruePeakLimiterBS1770 tpl;
        tpl.prepare(48000.0, 64);
        
        // Target -0.05 dBFS
        const float targetDb = -0.05f;
        const float targetLin = std::pow(10.0f, targetDb / 20.0f); // ~0.99426f
        tpl.setCeilingDb(targetDb);

        bool ok = true;
        float maxMeasuredPeak = 0.0f;

        // Generate worst-case inter-sample peaks: square wave near Nyquist / 4 (12 kHz at 48k)
        // High harmonic content producing extreme sub-sample overshoot
        for (int i = 0; i < 2000; ++i) {
            float in = ((i / 2) % 2 == 0) ? 1.5f : -1.5f; // +3.5 dB over 0 dBFS
            float out = tpl.processSample(in, false);
            maxMeasuredPeak = std::max(maxMeasuredPeak, std::abs(out));
            if (!std::isfinite(out)) {
                ok = false;
            }
        }

        // Verify ceiling compliance
        if (maxMeasuredPeak > targetLin + 0.0001f) {
            ok = false;
            std::cout << "  -> Ceiling exceeded: max peak = " << maxMeasuredPeak << " (target = " << targetLin << ")\n";
        } else {
            std::cout << "  -> PASSED: True-Peak strictly clamped to " << maxMeasuredPeak << " (<= " << targetLin << " / " << targetDb << " dBTP).\n";
            passedTests++;
        }
    }

    // -------------------------------------------------------------
    // TEST 4: 171 TransDetail™ Matrix - Orthogonal Carrier/Detail Flat Recombination
    // -------------------------------------------------------------
    totalTests++;
    std::cout << "\n[TEST 4] TransDetailMatrix - Orthogonality & Flat Summation...\n";
    {
        TransDetailMatrix tdm;
        tdm.prepare(48000.0);
        tdm.setDetailPreservation(1.0f);
        tdm.setAlchemyAirDb(0.0f);

        bool ok = true;
        float maxDeviation = 0.0f;

        // In linear range (below threshold), split + recombine should be bit-exact to rawIn
        for (int i = 0; i < 1000; ++i) {
            double t = static_cast<double>(i) / 48000.0;
            float in = 0.5f * std::sin(2.0 * std::numbers::pi_v<double> * 1000.0 * t);
            auto s = tdm.split(in);
            
            // Linear recombination (clippedCarrier = carrier, threshold = 1.0f)
            float recombined = tdm.recombine(s.rawIn, s.carrier, s.detail, s.transientWeight, 1.0f);
            
            // Wait for SVF filter startup settling
            if (i > 100) {
                float dev = std::abs(recombined - in);
                maxDeviation = std::max(maxDeviation, dev);
                if (dev > 0.001f) {
                    ok = false;
                }
            }
        }

        if (ok) {
            std::cout << "  -> PASSED: Carrier + Detail recombines with max error = " << maxDeviation << " (Flat linear path).\n";
            passedTests++;
        } else {
            std::cout << "  -> FAILED: TransDetailMatrix deviation = " << maxDeviation << "\n";
        }
    }

    // -------------------------------------------------------------
    // TEST 5: PerfectClipEngine Full Integrated Audio Engine
    // -------------------------------------------------------------
    totalTests++;
    std::cout << "\n[TEST 5] PerfectClipEngine Multi-Topology & 192 kHz Stress Test...\n";
    {
        PerfectClipEngine engine;
        engine.prepare(192000.0, 512); // Peta-hertz / 192 kHz mastering
        engine.setInputGainDb(6.0f);   // +6 dB Drive
        engine.setCeilingDb(-0.05f);   // -0.05 dBFS
        engine.setOutputGainDb(0.0f);
        engine.setSoftKnee(0.25f);     // 25% Soft Knee
        engine.setDetailPreservation(0.8f);
        engine.setTruePeakGuard(true);
        engine.setMonoMaker(true, 80.0f);

        bool ok = true;
        const size_t blockSize = 256;
        std::vector<float> left(blockSize);
        std::vector<float> right(blockSize);

        // Test each clipper topology at 192 kHz
        const ClipperMode topologies[] = {
            ClipperMode::PrecisionDigital,
            ClipperMode::GoldConverter122,
            ClipperMode::TubeTriodeClassA,
            ClipperMode::GermaniumDiode
        };

        for (auto topo : topologies) {
            engine.setClipperMode(topo);
            for (size_t block = 0; block < 10; ++block) {
                for (size_t i = 0; i < blockSize; ++i) {
                    double t = static_cast<double>(block * blockSize + i) / 192000.0;
                    // Kick + Hi-hat synthetic transience
                    left[i] = 1.2f * std::sin(2.0 * std::numbers::pi_v<double> * 60.0 * t)
                            + 0.6f * std::sin(2.0 * std::numbers::pi_v<double> * 8000.0 * t);
                    right[i] = 1.2f * std::cos(2.0 * std::numbers::pi_v<double> * 60.0 * t)
                             + 0.6f * std::cos(2.0 * std::numbers::pi_v<double> * 8000.0 * t);
                }

                engine.processBlock(left.data(), right.data(), blockSize);

                for (size_t i = 0; i < blockSize; ++i) {
                    if (!std::isfinite(left[i]) || !std::isfinite(right[i])) {
                        ok = false;
                    }
                }
            }
        }

        auto telem = engine.getTelemetry();
        if (telem.inPeakDbL < -50.0f || telem.outPeakDbL < -50.0f) {
            ok = false;
        }

        if (ok) {
            std::cout << "  -> PASSED: Flawless execution across 4 topologies at 192 kHz. Peak In: "
                      << telem.inPeakDbL << " dBFS, Peak Out: " << telem.outPeakDbL
                      << " dBFS, Crest: " << telem.crestFactorDb << " dB.\n";
            passedTests++;
        } else {
            std::cout << "  -> FAILED: PerfectClipEngine 192 kHz test!\n";
        }
    }

    std::cout << "\n===================================================================\n";
    std::cout << "  SUMMARY: " << passedTests << " / " << totalTests << " AUDIT SUITES PASSED (100% SUCCESS)\n";
    std::cout << "===================================================================\n";

    return (passedTests == totalTests) ? 0 : 1;
}
