#include <iostream>
#include <vector>
#include <cmath>
#include "dsp171/Common.h"
#include "dsp171/TDPSOLAShifter.h"

using namespace dsp171;

int main() {
    const double sr = 48000.0;
    TDPSOLAShifter shifter;
    shifter.prepare(sr, 192);

    const size_t numSamples = 48000 * 2;
    std::vector<float> input(numSamples, 0.0f);
    std::vector<float> output(numSamples, 0.0f);

    float currentPhase = 0.0f;
    for (size_t i = 0; i < numSamples; ++i) {
        float f = 335.0f;
        currentPhase += 2.0f * PI * f / static_cast<float>(sr);
        if (currentPhase > 2.0f * PI) currentPhase -= 2.0f * PI;
        float sample = 0.0f;
        for (int h = 1; h <= 10; ++h) {
            sample += (1.0f / h) * std::sin(h * currentPhase);
        }
        input[i] = sample * 0.3f;
    }

    // Retune 335 Hz to E4 (329.6 Hz) -> pitchRatio = 329.63 / 335.0 = 0.98397
    float ratio = 329.63f / 335.0f;
    float t0 = static_cast<float>(sr / 335.0);

    for (size_t i = 0; i < numSamples; ++i) {
        float outL = 0.0f, outR = 0.0f;
        uint32_t prevJumps = shifter.getJumpCount();
        shifter.processStereo(input[i], input[i], outL, outR, t0, ratio, true, 0.95f);
        output[i] = outL;
        if (shifter.getJumpCount() > prevJumps) {
            std::cout << "Jump at i=" << i << " count=" << shifter.getJumpCount() << "\n";
        }
    }

    float maxPop = 0.0f;
    size_t popIdx = 0;
    for (size_t i = 1; i < numSamples; ++i) {
        float d = std::abs(output[i] - output[i-1]);
        if (d > maxPop) {
            maxPop = d;
            popIdx = i;
        }
    }
    std::cout << "Shifter alone max delta: " << maxPop << " at sample " << popIdx << "\n";
    return 0;
}
