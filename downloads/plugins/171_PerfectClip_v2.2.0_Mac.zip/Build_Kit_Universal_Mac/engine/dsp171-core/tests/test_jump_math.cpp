#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include "dsp171/Common.h"

// Let us inspect the exact math inside TDPSOLAShifter around jump
int main() {
    const double sr = 48000.0;
    const float f = 335.0f;
    const float t0 = static_cast<float>(sr / f); // 143.28 samples
    const size_t latency = 192;
    const float safeRatio = 329.63f / 335.0f; // 0.98397
    const float fadeSamples = std::clamp(t0 * 0.40f, 16.0f, 64.0f); // 57.3 samples

    double readPos = -static_cast<double>(latency);
    int64_t globalSampleCount = 0;

    for (int64_t i = 0; i < 70000; ++i) {
        globalSampleCount = i;
        readPos += safeRatio;

        double currentDelay = static_cast<double>(globalSampleCount) - readPos;
        if (currentDelay > (static_cast<double>(latency) + 0.75 * static_cast<double>(t0))) {
            int k = static_cast<int>(std::floor((currentDelay - static_cast<double>(latency)) / t0));
            std::cout << "Trigger at i=" << i << ": currentDelay=" << currentDelay 
                      << " latency=" << latency << " safeT0=" << t0 
                      << " k=" << k << " (currentDelay - k*t0)=" << (currentDelay - k*t0) 
                      << " candidatePos=" << (readPos + k*t0) 
                      << " distToPresent=" << (globalSampleCount - (readPos + k*t0)) << "\n";
            // advance readPos as if jumped
            readPos += k * t0;
        }
    }
    return 0;
}
