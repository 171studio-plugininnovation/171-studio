#include <iostream>
#include <vector>
#include <cmath>
#include <cassert>
#include <chrono>
#include <random>

#include "dsp171/Common.h"
#include "dsp171/DPLLPitchTracker.h"
#include "dsp171/LPCVocalTract.h"
#include "dsp171/RealTuneEngine.h"

using namespace dsp171;

void testButterworthBandpassPreFilter() {
    std::cout << "[TEST 1] ButterworthBandpassPreFilter Verification..." << std::endl;
    ButterworthBandpassPreFilter bp;
    const double sr = 48000.0;
    bp.prepare(sr);

    // 1. Rumble 20 Hz (below 70 Hz HP cutoff) -> must be heavily attenuated (> 20 dB attenuation)
    float maxAmp20 = 0.0f;
    for (int i = 0; i < 4800; ++i) {
        float in = std::sin(2.0f * PI * 20.0f * static_cast<float>(i) / 48000.0f);
        float out = bp.processSample(in);
        if (i > 3800) maxAmp20 = std::max(maxAmp20, std::abs(out));
    }
    const float atten20Db = gainToDb(maxAmp20);
    std::cout << "  20 Hz Rumble Gain: " << atten20Db << " dB (Ideal: < -18 dB)" << std::endl;
    assert(atten20Db < -18.0f);

    // 2. Vocal fundamental 440 Hz (in passband) -> pass through with minimal loss (< 0.5 dB)
    bp.reset();
    float maxAmp440 = 0.0f;
    for (int i = 0; i < 4800; ++i) {
        float in = std::sin(2.0f * PI * 440.0f * static_cast<float>(i) / 48000.0f);
        float out = bp.processSample(in);
        if (i > 3800) maxAmp440 = std::max(maxAmp440, std::abs(out));
    }
    const float gain440Db = gainToDb(maxAmp440);
    std::cout << "  440 Hz Vocal Passband Gain: " << gain440Db << " dB (Ideal: ~ 0 dB)" << std::endl;
    assert(std::abs(gain440Db) < 0.5f);

    // 3. High Sibilance 12000 Hz (above 4500 Hz LP cutoff) -> attenuated (> 15 dB)
    bp.reset();
    float maxAmp12k = 0.0f;
    for (int i = 0; i < 4800; ++i) {
        float in = std::sin(2.0f * PI * 12000.0f * static_cast<float>(i) / 48000.0f);
        float out = bp.processSample(in);
        if (i > 3800) maxAmp12k = std::max(maxAmp12k, std::abs(out));
    }
    const float atten12kDb = gainToDb(maxAmp12k);
    std::cout << "  12 kHz High Sibilance Gain: " << atten12kDb << " dB (Ideal: < -15 dB)" << std::endl;
    assert(atten12kDb < -15.0f);

    std::cout << "  [PASS] ButterworthBandpassPreFilter passed all tests.\n" << std::endl;
}

void testHilbertPhaseSplitter() {
    std::cout << "[TEST 2] HilbertPhaseSplitter Quadrature Verification..." << std::endl;
    HilbertPhaseSplitter splitter;
    const double sr = 48000.0;

    // Test a varie frequenze della gamma vocale (100 Hz, 440 Hz, 1000 Hz)
    const std::vector<float> freqs = { 100.0f, 220.0f, 440.0f, 880.0f, 1500.0f };

    for (float f : freqs) {
        splitter.reset();
        // Warm up
        for (int i = 0; i < 4800; ++i) {
            float in = std::sin(2.0f * PI * f * static_cast<float>(i) / 48000.0f);
            float outI = 0.0f, outQ = 0.0f;
            splitter.processSample(in, outI, outQ);
        }

        // Misura correlazione / prodotto scalare tra I e Q su un periodo (deve essere ~ 0 per quadratura 90°)
        float dotProduct = 0.0f;
        float powerI = 0.0f;
        float powerQ = 0.0f;
        const size_t testSamples = static_cast<size_t>(sr / f) * 10;

        for (size_t i = 0; i < testSamples; ++i) {
            float in = std::sin(2.0f * PI * f * static_cast<float>(i) / 48000.0f);
            float outI = 0.0f, outQ = 0.0f;
            splitter.processSample(in, outI, outQ);
            dotProduct += outI * outQ;
            powerI += outI * outI;
            powerQ += outQ * outQ;
        }

        const float correlation = dotProduct / (std::sqrt(powerI * powerQ) + 1e-12f);
        std::cout << "  Freq " << f << " Hz -> Quadrature Orthogonality Correlation: " 
                  << correlation << " (Ideal: < 0.02)" << std::endl;
        assert(std::abs(correlation) < 0.02f);
    }
    std::cout << "  [PASS] HilbertPhaseSplitter passed quadrature tests.\n" << std::endl;
}

void testDPLLPitchTrackerLockAndSNR() {
    std::cout << "[TEST 3] DPLLPitchTracker 3-Stage SNR Hysteresis & Sample-by-Sample f0 Tracking..." << std::endl;
    DPLLPitchTracker tracker;
    const double sr = 48000.0;
    tracker.prepare(sr, VocalRange::AltoTenor);

    // Initial state: Unlocked
    assert(tracker.getState() == DPLLTrackingState::Unlocked);
    assert(tracker.isLocked() == false);

    // Feed a clean 220 Hz sinusoid (A3)
    const float testFreq = 220.0f;
    const size_t numSamples = 48000; // 1.0 second

    for (size_t i = 0; i < numSamples; ++i) {
        float in = 0.7f * std::sin(2.0f * PI * testFreq * static_cast<float>(i) / 48000.0f);
        tracker.processSample(in);
    }

    const auto& telem = tracker.getTelemetry();
    std::cout << "  Target: " << testFreq << " Hz | Tracked f0: " << telem.f0Hz 
              << " Hz | SNR: " << telem.snrDb << " dB | State: " 
              << (telem.state == DPLLTrackingState::Locked ? "Locked" : "Other") << std::endl;

    assert(tracker.isLocked() == true);
    assert(tracker.getState() == DPLLTrackingState::Locked);
    assert(telem.snrDb >= PARAM_SNR_ACQUISITION_THRESHOLD); // > 16 dB
    assert(std::abs(telem.f0Hz - testFreq) < 0.5f); // Errore sub-cent

    // Test noise dropout: feed random noise, tracker must unlock after hold time
    std::mt19937 rng(1337);
    std::uniform_real_distribution<float> dist(-0.5f, 0.5f);

    for (size_t i = 0; i < 4800; ++i) { // 100 ms of noise
        tracker.processSample(dist(rng));
    }

    std::cout << "  After 100 ms Noise -> State: " 
              << (tracker.getState() == DPLLTrackingState::Unlocked ? "Unlocked" : "Locked")
              << " | SNR: " << tracker.getSNR() << " dB" << std::endl;

    assert(tracker.getState() == DPLLTrackingState::Unlocked);
    assert(tracker.isLocked() == false);

    std::cout << "  [PASS] DPLLPitchTracker 3-Stage SNR Hysteresis passed.\n" << std::endl;
}

void testDualPathVibratoSeparation() {
    std::cout << "[TEST 4] DualPathVibratoEngine (5.8 Hz Isolation & Multiplier Scaling)..." << std::endl;
    DualPathVibratoEngine vib;
    const double sr = 48000.0;
    vib.prepare(sr);

    // Invia modulazione di frequenza a 5.8 Hz con ampiezza 50 cents
    const float vibRateHz = 5.8f;
    const float vibAmpCents = 50.0f;
    const size_t numSamples = 48000;

    for (size_t i = 0; i < numSamples; ++i) {
        float t = static_cast<float>(i) / 48000.0f;
        float mod = vibAmpCents * std::sin(2.0f * PI * vibRateHz * t);
        vib.processCents(mod);
    }

    std::cout << "  Extracted Vibrato Cents: " << vib.getVibratoCents() 
              << " | Integrated Energy: " << vib.getIntegratedEnergy() 
              << " | Active: " << (vib.isActive() ? "YES" : "NO") << std::endl;

    assert(vib.isActive() == true);
    assert(vib.getIntegratedEnergy() > PARAM_VIBRATO_ENERGY_DETECTOR_THRESH); // > 0.6 cents

    // Test moltiplicatore: a 200% raddoppia la modulazione, a 0% la azzera
    vib.setMultiplier(0.0f);
    float zeroVib = vib.applyVibratoToPitch(440.0f);
    assert(std::abs(zeroVib - 440.0f) < 1e-4f);

    vib.setMultiplier(1.0f);
    float normalVib = vib.applyVibratoToPitch(440.0f);
    std::cout << "  440 Hz + Vibrato (-48.7 cents) -> Modulated Pitch: " << normalVib << " Hz" << std::endl;
    assert(normalVib > 425.0f && normalVib < 455.0f);

    std::cout << "  [PASS] DualPathVibratoEngine passed all tests.\n" << std::endl;
}

void testExtremaOLADPLL() {
    std::cout << "[TEST 5] ExtremaOLADPLL Vocal Cycle Extrema Synchronization..." << std::endl;
    ExtremaOLADPLL extrema;
    const double sr = 48000.0;
    extrema.prepare(sr);

    float prevS = 0.0f;
    float phase = 0.0f;
    const float freq = 200.0f;
    const float phaseInc = 2.0f * PI * freq / 48000.0f;

    for (int i = 0; i < 9600; ++i) {
        float s = std::sin(phase);
        extrema.update(phase, s, prevS);
        prevS = s;
        phase += phaseInc;
        if (phase >= PI) phase -= 2.0f * PI;
    }

    std::cout << "  Settled Extrema Phase Offset: " << extrema.getPhaseOffset() << " rad" << std::endl;
    assert(std::abs(extrema.getPhaseOffset()) < PI);
    std::cout << "  [PASS] ExtremaOLADPLL passed.\n" << std::endl;
}

void testLPCLevinsonDurbinAndInverseFilter() {
    std::cout << "[TEST 6] LPCVocalTract: Levinson-Durbin Recursion & Deconvolution..." << std::endl;
    LPCVocalTract<24> lpc;
    const double sr = 48000.0;
    lpc.prepare(sr, 20);

    // Sintetizziamo una vocale sintetica /a/ con due formanti a 700 Hz e 1200 Hz
    // Pilotata da treno di impulsi glottici a 150 Hz
    const float f0 = 150.0f;
    const float period = 48000.0f / f0;
    std::vector<float> vocalSignal(48000, 0.0f);

    // Generatore vocale semplice a 2 poli risonanti
    float y1 = 0.0f, y2 = 0.0f;
    float y3 = 0.0f, y4 = 0.0f;
    const float r1 = 0.96f, theta1 = 2.0f * PI * 700.0f / 48000.0f;
    const float r2 = 0.95f, theta2 = 2.0f * PI * 1200.0f / 48000.0f;

    for (size_t i = 0; i < 48000; ++i) {
        float pulse = (std::fmod(static_cast<float>(i), period) < 1.0f) ? 1.0f : 0.0f;
        // Biquad 1 (F1 = 700 Hz)
        float out1 = pulse + 2.0f * r1 * std::cos(theta1) * y1 - r1 * r1 * y2;
        y2 = y1; y1 = out1;
        // Biquad 2 (F2 = 1200 Hz)
        float out2 = out1 + 2.0f * r2 * std::cos(theta2) * y3 - r2 * r2 * y4;
        y4 = y3; y3 = out2;
        vocalSignal[i] = out2 * 0.1f;
    }

    // Inserisci campioni nell'analizzatore LPC
    for (size_t i = 0; i < 4800; ++i) {
        lpc.pushSampleForAnalysis(vocalSignal[i], true);
    }

    const auto& frame = lpc.getCurrentFrame();
    std::cout << "  LPC Order: " << frame.order << " | Residual Gain: " << frame.gain << std::endl;
    assert(frame.gain > 0.0f);

    // Verifica stabilita' di Levinson-Durbin: tutti i |kappa_i| < 1.0f
    for (size_t i = 1; i <= frame.order; ++i) {
        assert(std::abs(frame.k[i]) < 1.0f);
    }

    // Test Deconvoluzione (FIR Inverse Filtering): estrae il residuo d'eccitazione
    std::vector<float> residual(1000);
    for (size_t i = 0; i < 1000; ++i) {
        residual[i] = lpc.deconvolveSample(vocalSignal[4000 + i]);
    }

    // Il residuo deve presentare picchi d'impulso glottico netti
    float maxRes = 0.0f;
    for (float r : residual) maxRes = std::max(maxRes, std::abs(r));
    std::cout << "  Max Glottal Residual Pulse: " << maxRes << std::endl;
    assert(maxRes > 0.01f);

    std::cout << "  [PASS] LPC Levinson-Durbin & Inverse Filter passed.\n" << std::endl;
}

void testThroatLengthAllpassWarping() {
    std::cout << "[TEST 7] LPC Throat Length Conformal Allpass Warping (50% - 150%)..." << std::endl;
    LPCVocalTract<24> lpc;
    const double sr = 48000.0;
    lpc.prepare(sr, 20);

    // 1. Natural (100%): lambda must be exactly 0.0
    lpc.setThroatLength(100.0f);
    std::cout << "  Throat 100% -> Lambda: " << lpc.getLambda() << " (Ideal: 0.0)" << std::endl;
    assert(std::abs(lpc.getLambda() - 0.0f) < 1e-5f);

    // 2. Short Throat (50%): alpha = 0.5 -> lambda = (1 - 0.5) / (1 + 0.5) = 0.5 / 1.5 = 1/3
    lpc.setThroatLength(50.0f);
    const float expectedLambda50 = 1.0f / 3.0f;
    std::cout << "  Throat 50%  -> Lambda: " << lpc.getLambda() << " (Expected: " << expectedLambda50 << ")" << std::endl;
    assert(std::abs(lpc.getLambda() - expectedLambda50) < 1e-4f);

    // 3. Long Throat (150%): alpha = 1.5 -> lambda = (1 - 1.5) / (1 + 1.5) = -0.5 / 2.5 = -0.2
    lpc.setThroatLength(150.0f);
    const float expectedLambda150 = -0.2f;
    std::cout << "  Throat 150% -> Lambda: " << lpc.getLambda() << " (Expected: " << expectedLambda150 << ")" << std::endl;
    assert(std::abs(lpc.getLambda() - expectedLambda150) < 1e-4f);

    // 4. Stabilità Risintesi Allpass Ladder ZDF
    // Invia treno di impulsi al sintetizzatore Allpass
    lpc.reset();
    lpc.setThroatLength(75.0f); // Shorter throat
    float maxSynth = 0.0f;
    for (int i = 0; i < 4800; ++i) {
        float pulse = (i % 200 == 0) ? 1.0f : 0.0f;
        float y = lpc.synthesizeSample(pulse);
        maxSynth = std::max(maxSynth, std::abs(y));
    }
    std::cout << "  Allpass Ladder ZDF Synthesis (Throat 75%) Max Output: " << maxSynth << " (Stable)" << std::endl;
    assert(maxSynth > 0.0f && maxSynth < 100.0f); // Stabile e privo di divergenza

    std::cout << "  [PASS] LPC Throat Length Conformal Allpass Warping passed.\n" << std::endl;
}

void testFlexTuneAndHumanize() {
    std::cout << "[TEST 8] Antares Flex-Tune & Humanize Formulas Verification..." << std::endl;
    LPCVocalTract<24> lpc;
    lpc.prepare(48000.0, 20);

    // Flex-Tune formula: Weight = max(0, 1 - (|cents| / 50) * (Flex / 100))
    lpc.setFlexTune(100.0f); // 100% Flex
    // At 0 cents offset -> Weight = 1.0 (Full retune at note center)
    float w0 = lpc.calculateFlexTuneWeight(0.0f);
    assert(std::abs(w0 - 1.0f) < 1e-4f);

    // At 25 cents offset -> Weight = 1 - (25 / 50) * 1.0 = 0.5
    float w25 = lpc.calculateFlexTuneWeight(25.0f);
    std::cout << "  Flex 100% @ 25 cents -> Weight: " << w25 << " (Ideal: 0.50)" << std::endl;
    assert(std::abs(w25 - 0.5f) < 1e-4f);

    // At 50 cents offset -> Weight = 0.0 (Zero retune at note boundary, expressive freedom)
    float w50 = lpc.calculateFlexTuneWeight(50.0f);
    std::cout << "  Flex 100% @ 50 cents -> Weight: " << w50 << " (Ideal: 0.00)" << std::endl;
    assert(std::abs(w50 - 0.0f) < 1e-4f);

    // Humanize test: Note held for < 250 ms -> 0 relaxation
    lpc.setHumanize(80.0f);
    lpc.reset();
    for (int i = 0; i < 48000 * 0.20; ++i) { // 200 ms
        lpc.updateVoicingState(true, 15.0f);
    }
    float r200 = lpc.calculateHumanizeRelaxation();
    std::cout << "  Humanize @ 200 ms sustain -> Relaxation: " << r200 << " (Expected: 0.0)" << std::endl;
    assert(std::abs(r200 - 0.0f) < 1e-4f);

    // Note held for 500 ms (> 250 ms) -> relaxation kicks in
    for (int i = 0; i < 48000 * 0.30; ++i) { // additional 300 ms (total 500 ms)
        lpc.updateVoicingState(true, 15.0f);
    }
    float r500 = lpc.calculateHumanizeRelaxation();
    std::cout << "  Humanize @ 500 ms sustain -> Relaxation: " << r500 << " (Expected: > 0.3)" << std::endl;
    assert(r500 > 0.3f);

    std::cout << "  [PASS] Flex-Tune & Humanize passed.\n" << std::endl;
}

void testRealTimeBenchmark() {
    std::cout << "[TEST 9] High-Throughput Hard Real-Time Benchmark..." << std::endl;
    DPLLPitchTracker dpll;
    dpll.prepare(48000.0);

    LPCVocalTract<20> lpc;
    lpc.prepare(48000.0, 20);

    const size_t benchSamples = 48000 * 4; // 4 seconds of audio
    std::vector<float> testAudio(benchSamples);
    for (size_t i = 0; i < benchSamples; ++i) {
        testAudio[i] = 0.6f * std::sin(2.0f * PI * 330.0f * static_cast<float>(i) / 48000.0f);
    }

    const auto tStart = std::chrono::high_resolution_clock::now();
    for (size_t i = 0; i < benchSamples; ++i) {
        float f0 = dpll.processSample(testAudio[i]);
        (void)f0;
        lpc.pushSampleForAnalysis(testAudio[i], true);
        float res = lpc.deconvolveSample(testAudio[i]);
        float synth = lpc.synthesizeSample(res);
        (void)synth;
    }
    const auto tEnd = std::chrono::high_resolution_clock::now();

    const double elapsedSec = std::chrono::duration<double>(tEnd - tStart).count();
    const double mSampsPerSec = (benchSamples / 1e6) / elapsedSec;
    const double realTimeSpeed = 4.0 / elapsedSec;

    std::cout << "  Processed 4.0s full Dual DPLL + LPC chain in " << (elapsedSec * 1000.0) 
              << " ms (" << mSampsPerSec << " MSamples/s, " << realTimeSpeed << "x Real-Time!)" << std::endl;

    assert(realTimeSpeed > 10.0); // Extreme real-time throughput (> 10x)
    std::cout << "  [PASS] Hard Real-Time Benchmark passed.\n" << std::endl;
}

int main() {
    std::cout << "=========================================================================" << std::endl;
    std::cout << "=== 171 DSP: DUAL DPLL (WAVES TUNE RT) & LPC VOCAL TRACT (AUTO-TUNE) ===" << std::endl;
    std::cout << "=========================================================================" << std::endl;

    try {
        testButterworthBandpassPreFilter();
        testHilbertPhaseSplitter();
        testDPLLPitchTrackerLockAndSNR();
        testDualPathVibratoSeparation();
        testExtremaOLADPLL();
        testLPCLevinsonDurbinAndInverseFilter();
        testThroatLengthAllpassWarping();
        testFlexTuneAndHumanize();
        testRealTimeBenchmark();

        std::cout << "=========================================================================" << std::endl;
        std::cout << ">>> ALL 9 DUAL DPLL & LPC VOCAL TRACT TESTS PASSED WITH 100% SUCCESS! <<<" << std::endl;
        std::cout << "=========================================================================" << std::endl;
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "EXCEPTION: " << e.what() << std::endl;
        return 1;
    }
}
