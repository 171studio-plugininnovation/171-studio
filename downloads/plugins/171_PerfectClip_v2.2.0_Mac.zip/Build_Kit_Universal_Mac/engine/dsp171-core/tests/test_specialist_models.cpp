#include <iostream>
#include <vector>
#include <cmath>
#include <cassert>

#include "dsp171/Common.h"
#include "dsp171/FocusriteISAPreamp.h"
#include "dsp171/APIDiscreteSaturator.h"
#include "dsp171/AvalonTubeSaturator.h"
#include "dsp171/TapeHysteresisDSP.h"
#include "dsp171/VCABusCompressor.h"
#include "dsp171/VariMuCompressor.h"
#include "dsp171/NevePreampStrip.h"
#include "dsp171/APIVisionStrip.h"
#include "dsp171/AvalonTubeStrip.h"
#include "dsp171/TapeMachineStrip.h"
#include "dsp171/CultureVultureDSP.h"
#include "dsp171/TruePeakLimiterBS1770.h"

int main() {
    std::cout << "======================================================" << std::endl;
    std::cout << "171 SPECIALIST GUILD DSP PHYSICAL MODELS VERIFICATION" << std::endl;
    std::cout << "======================================================" << std::endl;

    constexpr double sampleRate = 48000.0;
    constexpr size_t numSamples = 4800; // 100 ms test signal

    // 1. Focusrite ISA Preamp Test (Lundahl Transformer & Variable-Z)
    {
        dsp171::FocusriteISAPreamp isa;
        isa.prepare(sampleRate);
        isa.setImpedance(dsp171::ISAImpedance::Low_600Ohm);

        float maxVal = 0.0f;
        for (size_t i = 0; i < numSamples; ++i) {
            float in = std::sin(2.0f * dsp171::PI * 100.0f * static_cast<float>(i) / 48000.0f) * 0.8f;
            float out = isa.processSample(in, /*gainDb=*/ 6.0f, /*airBoostDb=*/ 2.0f);
            assert(!std::isnan(out) && !std::isinf(out));
            maxVal = std::max(maxVal, std::abs(out));
        }
        std::cout << "[PASS] FocusriteISAPreamp: Clean Lundahl transformer pass, maxVal = " << maxVal << std::endl;
    }

    // 2. API 2520 Discrete Saturator Test (Slew limiting & 2503 steel transformer H3)
    {
        dsp171::APIDiscreteSaturator api;
        api.prepare(sampleRate);

        float maxVal = 0.0f;
        for (size_t i = 0; i < numSamples; ++i) {
            // High frequency transient step + 1 kHz tone
            float in = (i % 200 == 0) ? 1.5f : std::sin(2.0f * dsp171::PI * 1000.0f * static_cast<float>(i) / 48000.0f) * 0.7f;
            float out = api.processSample(in, /*driveDb=*/ 9.0f, /*punch=*/ 0.75f, /*thrust=*/ true);
            assert(!std::isnan(out) && !std::isinf(out));
            maxVal = std::max(maxVal, std::abs(out));
        }
        std::cout << "[PASS] APIDiscreteSaturator: 2520 slew limit + 2503 punch pass, maxVal = " << maxVal << std::endl;
    }

    // 3. Avalon VT-737sp Tube Saturator Test (High-voltage Class-A dual triode)
    {
        dsp171::AvalonTubeSaturator avalon;
        avalon.prepare(sampleRate);

        float maxVal = 0.0f;
        for (size_t i = 0; i < numSamples; ++i) {
            float in = std::sin(2.0f * dsp171::PI * 440.0f * static_cast<float>(i) / 48000.0f) * 0.5f;
            float out = avalon.processSample(in, /*driveDb=*/ 12.0f, /*warmth=*/ 0.8f, /*airDb=*/ 3.0f);
            assert(!std::isnan(out) && !std::isinf(out));
            maxVal = std::max(maxVal, std::abs(out));
        }
        std::cout << "[PASS] AvalonTubeSaturator: Class-A 6922/12AX7 tube sheen pass, maxVal = " << maxVal << std::endl;
    }

    // 4. Tape Hysteresis DSP Test (Studer A800 / Ampex ATR-102)
    {
        dsp171::TapeHysteresisDSP tape;
        tape.prepare(sampleRate);
        tape.setSpeed(dsp171::TapeSpeed::IPS_15);

        float maxVal = 0.0f;
        for (size_t i = 0; i < numSamples; ++i) {
            float in = std::sin(2.0f * dsp171::PI * 60.0f * static_cast<float>(i) / 48000.0f) * 1.2f;
            float out = tape.processSample(in, /*driveDb=*/ 6.0f, /*tapeWarmth=*/ 0.6f);
            assert(!std::isnan(out) && !std::isinf(out));
            maxVal = std::max(maxVal, std::abs(out));
        }
        std::cout << "[PASS] TapeHysteresisDSP: 15 IPS head bump & Jiles-Atherton pass, maxVal = " << maxVal << std::endl;
    }

    // 5. VCA Bus Compressor Test (SSL G-Master & API 2500 Thrust styles)
    {
        // 5a: SSL 4000 G Bus mode (Feedforward, Norm Thrust, Auto-Release)
        dsp171::VCABusCompressor vca;
        vca.prepare(sampleRate);
        vca.setParameters(/*thresholdDb=*/ -20.0f, /*ratio=*/ 4.0f, /*attackMs=*/ 10.0f, /*releaseMs=*/ 100.0f, /*autoRelease=*/ true);

        float maxGr = 0.0f;
        for (size_t i = 0; i < numSamples; ++i) {
            float in = std::sin(2.0f * dsp171::PI * 1000.0f * static_cast<float>(i) / 48000.0f) * 0.9f;
            float gr = 0.0f;
            float out = vca.processSample(in, &gr);
            assert(!std::isnan(out) && !std::isinf(out));
            maxGr = std::max(maxGr, gr);
        }
        std::cout << "[PASS] VCABusCompressor (SSL G-Master Feedforward + Auto): maxGR = " << maxGr << " dB" << std::endl;
        assert(maxGr > 0.5f);

        // 5b: API 2500 Old Feedback mode + Loud Thrust + Soft Knee
        dsp171::VCABusCompressor apiVca;
        apiVca.prepare(sampleRate);
        apiVca.setParameters(/*thresholdDb=*/ -18.0f, /*ratio=*/ 6.0f, /*attackMs=*/ 3.0f, /*releaseMs=*/ 200.0f,
                             /*autoRelease=*/ false, /*scHPFreq=*/ 90.0f,
                             dsp171::ThrustMode::Loud, dsp171::VCATopology::Feedback_Old, dsp171::KneeType::Soft);
        float maxGrApi = 0.0f;
        for (size_t i = 0; i < numSamples; ++i) {
            float in = std::sin(2.0f * dsp171::PI * 100.0f * static_cast<float>(i) / 48000.0f) * 0.85f;
            float gr = 0.0f;
            float out = apiVca.processSample(in, &gr);
            assert(!std::isnan(out) && !std::isinf(out));
            maxGrApi = std::max(maxGrApi, gr);
        }
        std::cout << "[PASS] VCABusCompressor (API 2500 Feedback + Loud Thrust + Soft Knee): maxGR = " << maxGrApi << " dB" << std::endl;
        assert(maxGrApi > 0.3f);
    }

    // 6. Vari-Mu Compressor Test (Fairchild 660 / 670 Physical Tube Modeling)
    {
        // 6a: Fairchild Pos 1 (Snare / Transient, 0.2ms attack, 300ms release)
        dsp171::VariMuCompressor variMu;
        variMu.prepare(sampleRate);
        variMu.setParameters(/*threshold0To10=*/ 5.0f, /*inputGainDb=*/ 6.0f, dsp171::FairchildTimeConstant::Pos1);

        std::vector<float> bufferL(numSamples, 0.0f);
        std::vector<float> bufferR(numSamples, 0.0f);
        for (size_t i = 0; i < numSamples; ++i) {
            bufferL[i] = std::sin(2.0f * dsp171::PI * 1000.0f * static_cast<float>(i) / 48000.0f) * 0.8f;
            bufferR[i] = std::sin(2.0f * dsp171::PI * 1000.0f * static_cast<float>(i) / 48000.0f + 0.5f) * 0.8f;
        }

        variMu.process(bufferL.data(), bufferR.data(), numSamples);
        const float grPos1 = variMu.getGainReductionL();
        assert(!std::isnan(grPos1) && !std::isinf(grPos1));
        assert(grPos1 > 0.5f);
        std::cout << "[PASS] VariMuCompressor (Fairchild 660 Pos 1 Fast Attack): maxGR = " << grPos1 << " dB" << std::endl;

        // 6b: Fairchild Pos 5 (Dual-Automatic Recovery, Lat/Vert Mid/Side mode)
        variMu.reset();
        variMu.setParameters(/*threshold0To10=*/ 7.0f, /*inputGainDb=*/ 8.0f,
                             dsp171::FairchildTimeConstant::Pos5,
                             dsp171::ChannelMode::LatVert_MidSide,
                             /*scHPFreq=*/ 100.0f);

        for (size_t i = 0; i < numSamples; ++i) {
            bufferL[i] = std::sin(2.0f * dsp171::PI * 440.0f * static_cast<float>(i) / 48000.0f) * 0.9f;
            bufferR[i] = std::sin(2.0f * dsp171::PI * 880.0f * static_cast<float>(i) / 48000.0f) * 0.5f;
        }

        variMu.process(bufferL.data(), bufferR.data(), numSamples);
        const float grPos5L = variMu.getGainReductionL();
        const float grPos5R = variMu.getGainReductionR();
        assert(!std::isnan(grPos5L) && !std::isnan(grPos5R));
        assert(grPos5L > 1.0f && grPos5R > 0.2f);
        for (size_t i = 0; i < numSamples; ++i) {
            assert(!std::isnan(bufferL[i]) && !std::isinf(bufferL[i]));
            assert(!std::isnan(bufferR[i]) && !std::isinf(bufferR[i]));
        }
        std::cout << "[PASS] VariMuCompressor (Fairchild 670 Pos 5 Dual Auto + Lat/Vert Mid/Side): Lat GR = " 
                  << grPos5L << " dB, Vert GR = " << grPos5R << " dB" << std::endl;
    }

    // 7. True Peak Limiter Test (ITU-R BS.1770-4 inter-sample peak protection)
    {
        dsp171::TruePeakLimiterBS1770 limiter;
        limiter.prepare(sampleRate, 64);
        limiter.setCeilingDb(-0.5f); // -0.5 dBTP ceiling

        float maxOut = 0.0f;
        // Feed severe overs (+6 dBFS hot transients)
        for (size_t i = 0; i < numSamples; ++i) {
            float in = std::sin(2.0f * dsp171::PI * 2000.0f * static_cast<float>(i) / 48000.0f) * 2.0f;
            float out = limiter.processSample(in, /*enableDither=*/ true);
            assert(!std::isnan(out) && !std::isinf(out));
            maxOut = std::max(maxOut, std::abs(out));
        }

        const float ceilingLinear = dsp171::dbToGain(-0.5f);
        std::cout << "[PASS] TruePeakLimiterBS1770: ISP lookahead brickwall pass, maxOut = " 
                  << maxOut << " (ceiling: " << ceilingLinear << ")" << std::endl;
        assert(maxOut <= ceilingLinear + 0.001f); // Must strictly respect ceiling
    }

    // 8. Neve 1073 Preamp & Equalizer Channel Strip (Ticket #PRE-NEVE-01)
    {
        dsp171::NevePreampStrip neve;
        neve.prepare(sampleRate);
        neve.setPreamp(/*inputGainDb=*/ 12.0f, /*driveWarmth=*/ 0.8f);
        neve.setEQ(dsp171::NeveHPFFreq::Hz_80,
                    dsp171::NeveLowFreq::Hz_60, /*lowGainDb=*/ 4.0f,
                    dsp171::NeveMidFreq::kHz_3_2, /*midGainDb=*/ 6.0f,
                    /*highGainDb=*/ 3.0f);
        neve.setOutput(/*outGainDb=*/ -2.0f);

        float maxVal = 0.0f;
        for (size_t i = 0; i < numSamples; ++i) {
            float in = std::sin(2.0f * dsp171::PI * 100.0f * static_cast<float>(i) / 48000.0f) * 0.7f;
            float out = neve.processSample(in);
            assert(!std::isnan(out) && !std::isinf(out));
            maxVal = std::max(maxVal, std::abs(out));
        }
        std::cout << "[PASS] NevePreampStrip: BA283 Class-A + Marinair LO1166 + 1073 Inductor EQ pass, maxVal = " << maxVal << std::endl;
        assert(maxVal > 0.1f);
    }

    // 9. API Vision Channel Strip (API 2520 Slew + 2503 H3 + Proportional-Q, Ticket #PRE-API-02)
    {
        dsp171::APIVisionStrip api;
        api.prepare(sampleRate);
        api.setPreamp(/*driveDb=*/ 8.0f, /*punch=*/ 0.85f, /*thrust=*/ true);
        api.setBandpassFilter(true);
        // Band 0: Low Shelf @ 100 Hz, +4 dB
        api.setBand(0, 100.0f, 4.0f, dsp171::APIBandMode::Shelf);
        // Band 2: Proportional-Q Bell @ 2.5 kHz, +8 dB
        api.setBand(2, 2500.0f, 8.0f, dsp171::APIBandMode::Peak);
        api.setOutput(/*outGainDb=*/ -1.0f);

        float maxVal = 0.0f;
        for (size_t i = 0; i < numSamples; ++i) {
            float in = std::sin(2.0f * dsp171::PI * 1000.0f * static_cast<float>(i) / 48000.0f) * 0.8f;
            float out = api.processSample(in);
            assert(!std::isnan(out) && !std::isinf(out));
            maxVal = std::max(maxVal, std::abs(out));
        }
        std::cout << "[PASS] APIVisionStrip: 2520 Slew + 2503 Steel + Proportional-Q pass, maxVal = " << maxVal << std::endl;
        assert(maxVal > 0.1f);
    }

    // 10. Avalon VT-737sp Vacuum Tube Channel Strip (Ticket #PRE-AVALON-03)
    {
        dsp171::AvalonTubeStrip avalon;
        avalon.prepare(sampleRate);
        avalon.setPreamp(/*driveDb=*/ 10.0f, /*warmth=*/ 0.75f, /*airSheenDb=*/ 4.0f,
                         /*enableHpf=*/ true, /*hpfFreq=*/ 60.0f);
        avalon.setEQ(/*bassGainDb=*/ 3.0f, /*lowMidGainDb=*/ 2.0f, /*lowMidFreq=*/ 200.0f,
                     /*highMidGainDb=*/ 4.0f, /*highMidFreq=*/ 3500.0f,
                     /*trebleGainDb=*/ 5.0f);
        avalon.setOutput(/*outGainDb=*/ -1.5f);

        float maxVal = 0.0f;
        for (size_t i = 0; i < numSamples; ++i) {
            float in = std::sin(2.0f * dsp171::PI * 440.0f * static_cast<float>(i) / 48000.0f) * 0.65f;
            float out = avalon.processSample(in);
            assert(!std::isnan(out) && !std::isinf(out));
            maxVal = std::max(maxVal, std::abs(out));
        }
        std::cout << "[PASS] AvalonTubeStrip: Class-A 6922/12AX7 + 32 kHz Air Sheen + 4-band tube EQ pass, maxVal = " << maxVal << std::endl;
        assert(maxVal > 0.1f);
    }

    // 11. TapeMachineStrip Test (Studer A800 & Ampex ATR-102 Modeling, Ticket #TAPE-STUDER-01)
    {
        dsp171::TapeMachineStrip tape;
        tape.prepare(sampleRate);
        tape.setParameters(dsp171::TapeSpeedExtended::IPS_15,
                           dsp171::TapeFormulation::Classic_456,
                           dsp171::TapeEmphasis::NAB,
                           dsp171::TapeBiasMode::OverBias,
                           /*inputGainDb=*/ 3.0f, /*tapeDriveDb=*/ 4.0f,
                           /*wowFlutter=*/ 0.5f);
        tape.setOutputTrim(-1.0f);

        std::vector<float> bufL(numSamples, 0.0f);
        std::vector<float> bufR(numSamples, 0.0f);
        for (size_t i = 0; i < numSamples; ++i) {
            bufL[i] = std::sin(2.0f * dsp171::PI * 60.0f * static_cast<float>(i) / 48000.0f) * 0.85f;
            bufR[i] = std::sin(2.0f * dsp171::PI * 120.0f * static_cast<float>(i) / 48000.0f) * 0.70f;
        }

        tape.process(bufL.data(), bufR.data(), numSamples);
        const float fluxL = tape.getFluxL();
        assert(!std::isnan(fluxL) && fluxL > 0.1f);
        for (size_t i = 0; i < numSamples; ++i) {
            assert(!std::isnan(bufL[i]) && !std::isinf(bufL[i]));
            assert(!std::isnan(bufR[i]) && !std::isinf(bufR[i]));
        }
        std::cout << "[PASS] TapeMachineStrip: Studer/Ampex 15 IPS + 456 + OverBias + Wow/Flutter pass, flux = " << fluxL << std::endl;
    }

    // 12. CultureVultureDSP Test (Thermionic Dual Pentode 6AS6 & Starvation, Ticket #SAT-VULTURE-02)
    {
        // 12a: Triode Mode (Warm H2 Richness)
        dsp171::CultureVultureDSP vulture;
        vulture.prepare(sampleRate);
        vulture.setParameters(dsp171::VultureMode::Triode, /*drive=*/ 4.0f, /*starve=*/ 0.0f, /*tone=*/ 1.5f);

        float maxValTriode = 0.0f;
        for (size_t i = 0; i < numSamples; ++i) {
            float in = std::sin(2.0f * dsp171::PI * 1000.0f * static_cast<float>(i) / 48000.0f) * 0.7f;
            float out = vulture.processSample(in);
            assert(!std::isnan(out) && !std::isinf(out));
            maxValTriode = std::max(maxValTriode, std::abs(out));
        }
        assert(maxValTriode > 0.1f);

        // 12b: P2 Starve Mode with Screen Grid Voltage Collapse
        vulture.reset();
        vulture.setParameters(dsp171::VultureMode::P2_Starve, /*drive=*/ 7.5f, /*starve=*/ 0.85f, /*tone=*/ -2.0f, /*overdrive=*/ true);

        float maxValStarve = 0.0f;
        for (size_t i = 0; i < numSamples; ++i) {
            float in = std::sin(2.0f * dsp171::PI * 250.0f * static_cast<float>(i) / 48000.0f) * 0.9f;
            float out = vulture.processSample(in);
            assert(!std::isnan(out) && !std::isinf(out));
            maxValStarve = std::max(maxValStarve, std::abs(out));
        }
        assert(maxValStarve > 0.1f);
        std::cout << "[PASS] CultureVultureDSP: 6AS6 Triode + P2 Starve Vg2 Collapse + Overdrive pass, maxVal = " << maxValStarve << std::endl;
    }

    std::cout << "======================================================" << std::endl;
    std::cout << "ALL 12 SPECIALIST DSP MODELS VERIFIED WITH 100% SUCCESS!" << std::endl;
    std::cout << "======================================================" << std::endl;

    return 0;
}
