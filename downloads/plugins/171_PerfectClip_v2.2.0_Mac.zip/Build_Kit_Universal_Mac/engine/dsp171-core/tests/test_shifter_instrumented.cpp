#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include "dsp171/Common.h"

// Copy TDPSOLA logic to instrument the jump
#define private public
#include "dsp171/TDPSOLAShifter.h"
#undef private

using namespace dsp171;

int main() {
    const double sr = 48000.0;
    TDPSOLAShifter shifter;
    shifter.prepare(sr, 192);

    const size_t numSamples = 72000;
    std::vector<float> input(numSamples, 0.0f);

    float currentPhase = 0.0f;
    for (size_t i = 0; i < numSamples; ++i) {
        float f = 335.0f;
        currentPhase += 2.0f * PI * f / static_cast<float>(sr);
        if (currentPhase > 2.0f * PI) currentPhase -= 2.0f * PI;
        float sample = 0.0f;
        for (int h = 1; h <= 10; ++h) {
            sample += (1.0f / h) * std::sin(h * currentPhase);
        }
        input[i] = sample * 0.3f;
    }

    float ratio = 329.63f / 335.0f;
    float t0 = static_cast<float>(sr / 335.0);

    for (size_t i = 0; i < numSamples; ++i) {
        float outL = 0.0f, outR = 0.0f;
        uint32_t prevJumps = shifter.getJumpCount();
        shifter.processStereo(input[i], input[i], outL, outR, t0, ratio, true, 0.95f);
        if (shifter.getJumpCount() > prevJumps) {
            std::cout << "Jump at i=" << i 
                      << " activeHead=" << (1 - shifter.activeHead) // was just set to crossfade
                      << " isCrossfading=" << shifter.isCrossfading 
                      << " fadeSamples=" << (1.0f / shifter.crossfadeStep)
                      << " head0.readPos=" << shifter.heads[0].readPos 
                      << " head1.readPos=" << shifter.heads[1].readPos 
                      << " diff=" << (shifter.heads[1].readPos - shifter.heads[0].readPos) 
                      << " diff/T0=" << ((shifter.heads[1].readPos - shifter.heads[0].readPos) / t0) << "\n";
        }
    }
    return 0;
}
