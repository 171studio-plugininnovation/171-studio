#include <iostream>
#include <vector>
#include <cmath>
#include <cassert>
#include <chrono>
#include <random>

#include "dsp171/Common.h"
#include "dsp171/PitchDetectorMPM.h"
#include "dsp171/GlottalClosureDetector.h"
#include "dsp171/MusicalQuantizer.h"
#include "dsp171/RetuneFilter.h"
#include "dsp171/TDPSOLAShifter.h"
#include "dsp171/RealTuneEngine.h"

using namespace dsp171;

void testPitchDetectorMPM() {
    std::cout << "[TEST] 1. PitchDetectorMPM Verification..." << std::endl;
    PitchDetectorMPM detector;
    const double sr = 48000.0;
    detector.prepare(sr, 1024, 64);

    const std::vector<float> testFreqs = { 110.0f, 220.0f, 440.0f, 659.25f, 880.0f };

    for (float targetFreq : testFreqs) {
        detector.reset();
        PitchResult res{};
        
        // Genera 4096 campioni di onda sinusoidale pura
        const size_t numSamples = 4096;
        for (size_t i = 0; i < numSamples; ++i) {
            const float sample = std::sin(2.0f * PI * targetFreq * static_cast<float>(i) / static_cast<float>(sr));
            detector.pushSample(sample, res);
        }

        const float detected = res.frequencyHz;
        const float errorPct = std::abs(detected - targetFreq) / targetFreq * 100.0f;

        std::cout << "  Target: " << targetFreq << " Hz | Detected: " << detected 
                  << " Hz | Clarity: " << res.clarity 
                  << " | Voiced: " << (res.isVoiced ? "YES" : "NO") 
                  << " | Error: " << errorPct << "%" << std::endl;

        assert(res.isVoiced == true);
        assert(res.clarity > 0.90f);
        assert(errorPct < 0.5f); // Errore inferiore allo 0.5%
    }

    // Test con Rumore Bianco (Unvoiced)
    {
        detector.reset();
        PitchResult noiseRes{};
        std::mt19937 rng(1337);
        std::uniform_real_distribution<float> dist(-1.0f, 1.0f);

        for (size_t i = 0; i < 4096; ++i) {
            detector.pushSample(dist(rng), noiseRes);
        }

        std::cout << "  Noise Test -> Voiced: " << (noiseRes.isVoiced ? "YES" : "NO") 
                  << " | Clarity: " << noiseRes.clarity << std::endl;
        assert(noiseRes.isVoiced == false);
        assert(noiseRes.clarity < 0.55f);
    }
    std::cout << "  [PASS] PitchDetectorMPM passed all tests." << std::endl << std::endl;
}

void testGlottalClosureDetector() {
    std::cout << "[TEST] 2. GlottalClosureDetector Verification..." << std::endl;
    GlottalClosureDetector gci;
    const double sr = 48000.0;
    gci.prepare(sr);

    const float period = 48000.0f / 220.0f; // ~218.18 samples
    std::vector<float> circBuf(8192, 0.0f);
    const size_t mask = 8191;

    for (int64_t i = 0; i < 2000; ++i) {
        // Simulazione impulso glottico asimmetrico
        const float phase = std::fmod(static_cast<float>(i), period) / period;
        const float sample = (phase < 0.1f) ? -std::sin(phase * 10.0f * PI) : 0.05f * std::sin(phase * 2.0f * PI);
        circBuf[static_cast<size_t>(i) & mask] = sample;

        gci.processSample(sample, i, period, true, circBuf.data(), mask);
    }

    assert(gci.getHistoryCount() > 5);
    const GCIMark mark = gci.findNearestGCI(1000.0f);
    std::cout << "  Nearest GCI to 1000.0: Timestamp " << mark.timestamp 
              << " | Period: " << mark.period << " | Strength: " << mark.strength << std::endl;
    assert(std::abs(mark.timestamp - 1000.0f) < period);
    std::cout << "  [PASS] GlottalClosureDetector passed." << std::endl << std::endl;
}

void testMusicalQuantizer() {
    std::cout << "[TEST] 3. MusicalQuantizer Verification..." << std::endl;
    MusicalQuantizer quant;

    // Test C Major (Ionian)
    quant.setScale(ScaleType::Major);
    quant.setRootKey(0); // C
    quant.setA4Reference(440.0f);

    // 440 Hz = A4 (MIDI 69), in scala
    QuantizeResult resA4 = quant.quantize(440.0f);
    std::cout << "  In: 440 Hz -> Target: " << resA4.targetFreqHz 
              << " Hz | MIDI: " << resA4.targetMidiNote 
              << " | Note: " << MusicalQuantizer::getPitchClassName(resA4.notePitchClass) 
              << resA4.octave << " | Cents: " << resA4.centsOffset << std::endl;
    assert(resA4.targetMidiNote == 69);
    assert(std::abs(resA4.centsOffset) < 0.01f);

    // 466.16 Hz = A#4 (MIDI 70) NON in C Major -> deve quantizzare a B4 (71) o A4 (69)
    QuantizeResult resAs4 = quant.quantize(466.16f);
    std::cout << "  In: 466.16 Hz (A#4) -> Snapped to: " 
              << MusicalQuantizer::getPitchClassName(resAs4.notePitchClass) 
              << resAs4.octave << " (MIDI " << resAs4.targetMidiNote << ")" << std::endl;
    assert(resAs4.targetMidiNote == 71 || resAs4.targetMidiNote == 69);
    assert(resAs4.notePitchClass != 10); // Non può essere A#

    // Test C Minor Pentatonic: {C, Eb, F, G, Bb} = {0, 3, 5, 7, 10}
    quant.setScale(ScaleType::MinorPentatonic);
    quant.setRootKey(0);
    // D4 (MIDI 62) non è in scala -> deve andare a C4 (60) o Eb4 (63)
    QuantizeResult resD4 = quant.quantize(293.66f); // D4
    std::cout << "  In: D4 (293.66 Hz) with C Minor Pentatonic -> Snapped to: " 
              << MusicalQuantizer::getPitchClassName(resD4.notePitchClass) 
              << resD4.octave << std::endl;
    assert(resD4.targetMidiNote == 60 || resD4.targetMidiNote == 63);

    std::cout << "  [PASS] MusicalQuantizer passed all scale rules." << std::endl << std::endl;
}

void testRetuneFilter() {
    std::cout << "[TEST] 4. RetuneFilter Verification..." << std::endl;
    RetuneFilter rf;
    const double sr = 48000.0;
    rf.prepare(sr);

    // Test 1: Hard-Tune (0 ms)
    rf.setRetuneSpeedMs(0.0f);
    rf.setAmount(1.0f);
    float outHard = rf.processSample(1.5f);
    std::cout << "  Hard-Tune (0 ms): Target 1.5 -> Output: " << outHard << std::endl;
    assert(std::abs(outHard - 1.5f) < 1e-4f);

    // Test 2: S-Curve Smoothness (20 ms = 960 campioni a 48k)
    rf.reset();
    rf.setRetuneSpeedMs(20.0f);
    rf.setAmount(1.0f);

    // Step change da 1.0 a 1.2
    std::vector<float> traj;
    traj.reserve(1200);
    for (size_t i = 0; i < 1200; ++i) {
        traj.push_back(rf.processSample(1.2f));
    }

    std::cout << "  S-Curve (20 ms): start=" << traj[0] 
              << " | mid(480)=" << traj[480] 
              << " | end(960)=" << traj[960] 
              << " | settled(1199)=" << traj[1199] << std::endl;

    // Verifica proprietà S-Curve: inizio a 1.0, punto medio a metà strada, arrivo a 1.2
    assert(traj[0] < 1.01f);
    assert(traj[480] > 1.05f && traj[480] < 1.15f);
    assert(std::abs(traj[1199] - 1.2f) < 0.005f);

    // Verifica derivata: non ci devono essere salti bruschi
    float maxDelta = 0.0f;
    for (size_t i = 1; i < traj.size(); ++i) {
        maxDelta = std::max(maxDelta, std::abs(traj[i] - traj[i-1]));
    }
    std::cout << "  Max sample-to-sample slope: " << maxDelta << " (strictly smooth)" << std::endl;
    assert(maxDelta < 0.001f);

    std::cout << "  [PASS] RetuneFilter passed." << std::endl << std::endl;
}

void testRealTuneEngineIntegration() {
    std::cout << "[TEST] 5. RealTuneEngine End-to-End Integration..." << std::endl;
    RealTuneEngine engine;
    const double sr = 48000.0;
    engine.prepare(sr, 512);

    engine.setScale(ScaleType::Major);
    engine.setRootKey(0); // C Major
    engine.setRetuneSpeedMs(10.0f);
    engine.setAmount(1.0f);

    std::cout << "  Engine Latency: " << engine.getLatencySamples() << " samples (" 
              << (static_cast<float>(engine.getLatencySamples()) / sr * 1000.0f) << " ms)" << std::endl;

    // Input: Segnale stereo a 445 Hz (circa 20 cents sopra A4 = 440 Hz)
    const size_t blockSize = 256;
    const size_t totalBlocks = 30;
    std::vector<float> inL(blockSize);
    std::vector<float> inR(blockSize);
    std::vector<float> outL(blockSize);
    std::vector<float> outR(blockSize);

    const float* inChannels[2] = { inL.data(), inR.data() };
    float* outChannels[2] = { outL.data(), outR.data() };

    float phase = 0.0f;
    const float phaseInc = 2.0f * PI * 445.0f / static_cast<float>(sr);

    for (size_t b = 0; b < totalBlocks; ++b) {
        for (size_t i = 0; i < blockSize; ++i) {
            inL[i] = 0.8f * std::sin(phase);
            inR[i] = 0.8f * std::sin(phase);
            phase += phaseInc;
            if (phase >= 2.0f * PI) phase -= 2.0f * PI;
        }

        engine.process(inChannels, outChannels, 2, blockSize);
    }

    std::cout << "  Final Detected Pitch: " << engine.getDetectedPitchHz() << " Hz" << std::endl;
    std::cout << "  Final Target Pitch: " << engine.getTargetPitchHz() << " Hz (" 
              << engine.getTargetNoteName() << engine.getTargetMidiNote() / 12 - 1 << ")" << std::endl;
    std::cout << "  Final Correction Cents: " << engine.getCorrectionCents() << " cents" << std::endl;
    std::cout << "  Voiced Clarity: " << engine.getVoicingClarity() << std::endl;

    assert(engine.isVoiced() == true);
    assert(std::abs(engine.getTargetPitchHz() - 440.0f) < 1.0f); // Snappato a A4 = 440.0 Hz!

    // Benchmark Throughput
    const size_t benchSamples = 48000 * 2; // 2 secondi di audio stereo
    std::vector<float> bInL(benchSamples, 0.5f);
    std::vector<float> bInR(benchSamples, 0.5f);
    std::vector<float> bOutL(benchSamples, 0.0f);
    std::vector<float> bOutR(benchSamples, 0.0f);
    const float* bIns[2] = { bInL.data(), bInR.data() };
    float* bOuts[2] = { bOutL.data(), bOutR.data() };

    const auto tStart = std::chrono::high_resolution_clock::now();
    engine.process(bIns, bOuts, 2, benchSamples);
    const auto tEnd = std::chrono::high_resolution_clock::now();

    const double elapsedSec = std::chrono::duration<double>(tEnd - tStart).count();
    const double mSampsPerSec = (benchSamples / 1e6) / elapsedSec;
    const double realTimeFactor = 2.0 / elapsedSec;

    std::cout << "  [BENCHMARK] Processed 2.0s stereo in " << (elapsedSec * 1000.0) << " ms (" 
              << mSampsPerSec << " MSamples/s, " << realTimeFactor << "x Real-Time speed!)" << std::endl;

    assert(realTimeFactor > 5.0); // Deve essere ampiamente più veloce del real-time

    std::cout << "  [PASS] RealTuneEngine passed end-to-end integration and benchmark." << std::endl << std::endl;
}

void testSampleRateStress() {
    std::cout << "[TEST] 6. Sample Rate Stress Test (96 kHz & 192 kHz)..." << std::endl;
    PitchDetectorMPM mpm96k;
    mpm96k.prepare(96000.0, 2048, 128);

    PitchResult res{};
    // Test 65.4 Hz (C2, nota bassa maschile) a 96 kHz
    const float testFreq96 = 65.4f;
    for (size_t i = 0; i < 8192; ++i) {
        float s = std::sin(2.0f * PI * testFreq96 * static_cast<float>(i) / 96000.0f);
        mpm96k.pushSample(s, res);
    }
    std::cout << "  [96 kHz] Target: " << testFreq96 << " Hz | Detected: " << res.frequencyHz 
              << " Hz | Clarity: " << res.clarity << " | Voiced: " << (res.isVoiced ? "YES" : "NO") << std::endl;
    assert(res.isVoiced == true);
    assert(std::abs(res.frequencyHz - testFreq96) / testFreq96 < 0.01f);

    PitchDetectorMPM mpm192k;
    mpm192k.prepare(192000.0, 2048, 256);
    // Test 110.0 Hz (A2) a 192 kHz
    const float testFreq192 = 110.0f;
    for (size_t i = 0; i < 16384; ++i) {
        float s = std::sin(2.0f * PI * testFreq192 * static_cast<float>(i) / 192000.0f);
        mpm192k.pushSample(s, res);
    }
    std::cout << "  [192 kHz] Target: " << testFreq192 << " Hz | Detected: " << res.frequencyHz 
              << " Hz | Clarity: " << res.clarity << " | Voiced: " << (res.isVoiced ? "YES" : "NO") << std::endl;
    assert(res.isVoiced == true);
    assert(std::abs(res.frequencyHz - testFreq192) / testFreq192 < 0.01f);

    std::cout << "  [PASS] Sample Rate Stress Test passed at 96k and 192k." << std::endl << std::endl;
}

void testDCOffsetImmunity() {
    std::cout << "[TEST] 7. DC Offset & Baseline Immunity Verification..." << std::endl;
    PitchDetectorMPM detector;
    detector.prepare(48000.0, 1024, 64);

    PitchResult res{};
    const float testFreq = 220.0f;
    const float dcBias = 0.15f; // Forte DC offset tipico di convertitori sbilanciati

    for (size_t i = 0; i < 8192; ++i) {
        float s = dcBias + 0.5f * std::sin(2.0f * PI * testFreq * static_cast<float>(i) / 48000.0f);
        detector.pushSample(s, res);
    }

    std::cout << "  DC (+0.15V) Target: " << testFreq << " Hz | Detected: " << res.frequencyHz 
              << " Hz | Clarity: " << res.clarity << " | Voiced: " << (res.isVoiced ? "YES" : "NO") << std::endl;
    assert(res.isVoiced == true);
    assert(res.clarity > 0.90f);
    assert(std::abs(res.frequencyHz - testFreq) < 1.0f);

    std::cout << "  [PASS] DC Offset Immunity passed." << std::endl << std::endl;
}

void testHumanizeVibrato() {
    std::cout << "[TEST] 8. Tolerance Natural Vibrato Deadband Verification..." << std::endl;
    RetuneFilter rf;
    rf.prepare(48000.0);
    rf.setRetuneSpeedMs(15.0f);
    rf.setAmount(1.0f);
    rf.setTolerance(15.0f, 0.0f); // Deadband di +/- 15 cents (Waves Tune RT)

    // Simulazione di micro-vibrato naturale entro il deadband (+10 cents deviazione)
    const float naturalRatio = std::pow(2.0f, 10.0f / 1200.0f);
    float outRatio = 0.0f;
    for (int i = 0; i < 1000; ++i) {
        outRatio = rf.processSample(naturalRatio, 10.0f); // 10 cents offset
    }

    std::cout << "  Within Deadband (+10 cents) -> Out Ratio: " << outRatio 
              << " (Ideal: 1.0 = untouched vibrato)" << std::endl;
    assert(std::abs(outRatio - 1.0f) < 0.005f); // Il vibrato passa inalterato!

    // Simulazione di errore di intonazione oltre il deadband (+35 cents deviazione)
    const float outOfTuneRatio = std::pow(2.0f, 35.0f / 1200.0f);
    for (int i = 0; i < 2000; ++i) {
        outRatio = rf.processSample(outOfTuneRatio, 35.0f);
    }
    std::cout << "  Beyond Deadband (+35 cents) -> Out Ratio: " << outRatio 
              << " (Corrected excess: ~" << (1200.0f * std::log2(outRatio)) << " cents)" << std::endl;
    assert(outRatio > 1.005f); // Corregge l'errore oltre il deadband

    std::cout << "  [PASS] Humanize Vibrato Deadband passed." << std::endl << std::endl;
}

void testFormantShiftIntegration() {
    std::cout << "[TEST] 9. Formant Shift Spectral Response Verification..." << std::endl;
    RealTuneEngine engine;
    engine.prepare(48000.0, 512);

    engine.setFormantShiftSemitones(-6.0f); // Deep Male Formant
    assert(std::abs(engine.getFormantShiftSemitones() - (-6.0f)) < 0.01f);

    engine.setFormantShiftSemitones(+6.0f); // Bright Female Formant
    assert(std::abs(engine.getFormantShiftSemitones() - (+6.0f)) < 0.01f);

    std::cout << "  [PASS] Formant Shift Integration passed." << std::endl << std::endl;
}

void testStereoWidthMonoCancellation() {
    std::cout << "[TEST] 10. Stereo Width (0-200%) & 100% Mono Cancellation-Free Verification..." << std::endl;
    StereoWidthEnhancer widener;
    const double sr = 48000.0;
    widener.prepare(sr);

    const std::vector<float> testWidths = { 0.0f, 25.0f, 50.0f, 100.0f, 150.0f, 180.0f, 200.0f };

    // Test con segnale Stereo complesso (voce doppia con panning e riverbero)
    std::mt19937 rng(42);
    std::uniform_real_distribution<float> dist(-0.8f, 0.8f);

    for (float w : testWidths) {
        widener.reset();
        widener.setWidth(w);

        // Warm up lo smoothing
        float dL = 0.0f, dR = 0.0f;
        for (int i = 0; i < 2000; ++i) {
            widener.processSample(0.5f, 0.5f, dL, dR);
        }

        // Test di cancellazione mono algebrica
        float maxError = 0.0f;
        for (int i = 0; i < 4096; ++i) {
            const float inL = dist(rng);
            const float inR = dist(rng);
            const float expectedMono = 0.5f * (inL + inR);

            float outL = 0.0f;
            float outR = 0.0f;
            widener.processSample(inL, inR, outL, outR);

            const float resultingMono = 0.5f * (outL + outR);
            const float error = std::abs(resultingMono - expectedMono);
            maxError = std::max(maxError, error);
        }

        std::cout << "  Width: " << w << "% -> Max Mono Sum Error: " << maxError 
                  << " (Ideal: < 1e-6 / -120 dBFS)" << std::endl;
        assert(maxError < 1.0e-5f); // 100% cancellation-free garantito a precisione macchina!
    }

    // Verifica Width 0% (Full Mono fold-down)
    {
        widener.setWidth(0.0f);
        widener.reset();
        float dL = 0.0f, dR = 0.0f;
        for (int i = 0; i < 2000; ++i) widener.processSample(0.0f, 0.0f, dL, dR);

        widener.processSample(0.7f, -0.3f, dL, dR);
        std::cout << "  Width 0% Check -> OutL: " << dL << " | OutR: " << dR 
                  << " | Diff: " << std::abs(dL - dR) << std::endl;
        assert(std::abs(dL - dR) < 1.0e-4f); // L == R rigoroso
    }

    // Verifica Width 200% su Lead Vocal Mono (L == R) -> decorrelazione psicoacustica generata
    {
        widener.setWidth(200.0f);
        widener.reset();
        float dL = 0.0f, dR = 0.0f;
        for (int i = 0; i < 2000; ++i) widener.processSample(0.0f, 0.0f, dL, dR);

        // Invia burst vocale mono
        float sideEnergySum = 0.0f;
        for (int i = 0; i < 1000; ++i) {
            const float vocalMono = 0.6f * std::sin(2.0f * PI * 440.0f * static_cast<float>(i) / 48000.0f);
            widener.processSample(vocalMono, vocalMono, dL, dR);
            const float side = 0.5f * (dL - dR);
            sideEnergySum += side * side;
        }

        std::cout << "  Width 200% Mono Lead Vocal -> Synthetic Side Energy: " << sideEnergySum << std::endl;
        assert(sideEnergySum > 0.01f); // Ha generato stereo spaziale sul mono!
    }

    std::cout << "  [PASS] Stereo Width & Mono Cancellation-Free passed all tests." << std::endl << std::endl;
}

void testKeepFormantsDynamicTracking() {
    std::cout << "[TEST] 11. Keep Formants (Melda-style) & ZDF SVF Dual-Pole Formant Tracking Verification..." << std::endl;
    FormantProcessor fp;
    const double sr = 48000.0;
    fp.prepare(sr);

    // 1. Verifica Matematica Rigorosa della compensazione automatica (FormantShift_auto = -12 * log2(ratio))
    struct IntervalTest {
        float semitones;
        float ratio;
        float expectedAutoShift;
    };

    const std::vector<IntervalTest> intervals = {
        { +3.0f,  std::exp2(3.0f / 12.0f),   -3.0f },   // Terza minore su -> auto -3 st
        { -4.0f,  std::exp2(-4.0f / 12.0f),  +4.0f },   // Terza maggiore giu' -> auto +4 st
        { +7.0f,  std::exp2(7.0f / 12.0f),   -7.0f },   // Quinta giusta su -> auto -7 st
        { +12.0f, 2.0f,                      -12.0f },  // Ottava su -> auto -12 st
        { -12.0f, 0.5f,                      +12.0f },  // Ottava giu' -> auto +12 st
        { 0.0f,   1.0f,                       0.0f }    // Unisono -> auto 0 st
    };

    fp.setKeepFormants(true);
    fp.setFormantShiftSemitones(0.0f);

    for (const auto& it : intervals) {
        fp.updateTracking(220.0f, it.ratio, true);
        const float autoShift = fp.getAutoFormantShiftSemitones();
        std::cout << "  Interval " << (it.semitones >= 0 ? "+" : "") << it.semitones 
                  << " st (Ratio " << it.ratio << ") -> Auto Formant Shift: " 
                  << autoShift << " st (Expected: " << it.expectedAutoShift << " st)" << std::endl;
        assert(std::abs(autoShift - it.expectedAutoShift) < 0.01f);
    }

    // 2. Verifica Formant Shift bipolare manuale [-12 .. +12] cumulabile con Keep Formants
    struct CumulationTest {
        float manualSt;
        float pitchRatio;
        bool keepFormants;
        float expectedEffective;
    };

    const std::vector<CumulationTest> cumulations = {
        { +3.0f, std::exp2(3.0f / 12.0f), true,   0.0f },   // +3 manual + (-3 auto) = 0.0 st
        { -5.0f, std::exp2(-2.0f / 12.0f), true, -3.0f },  // -5 manual + (+2 auto) = -3.0 st
        { +6.0f, std::exp2(4.0f / 12.0f), false, +6.0f },  // Keep OFF -> puro manuale +6.0 st
        { 0.0f,  std::exp2(5.0f / 12.0f), true,  -5.0f },  // 0 manual + (-5 auto) = -5.0 st
        { -12.0f, 1.0f,                   true,  -12.0f }, // -12 manual + 0 auto = -12.0 st
        { +12.0f, 1.0f,                   true,  +12.0f }  // +12 manual + 0 auto = +12.0 st
    };

    for (const auto& ct : cumulations) {
        fp.reset();
        fp.setKeepFormants(ct.keepFormants);
        fp.setFormantShiftSemitones(ct.manualSt);
        fp.updateTracking(220.0f, ct.pitchRatio, true);

        // Warm up lo smoothing esponenziale (2000 campioni ~ 41 ms)
        for (int i = 0; i < 2000; ++i) {
            fp.processSample(0.0f);
        }

        const float eff = fp.getEffectiveFormantShiftSemitones();
        std::cout << "  Manual: " << ct.manualSt << " st | Keep: " << (ct.keepFormants ? "ON " : "OFF") 
                  << " | Pitch Ratio: " << ct.pitchRatio << " -> Effective Shift: " << eff 
                  << " st (Expected: " << ct.expectedEffective << " st)" << std::endl;
        assert(std::abs(eff - ct.expectedEffective) < 0.05f);
    }

    // 3. Verifica ZDF SVF Bell a doppio polo a 64-bit: Risposta in Frequenza e stabilita'
    {
        ZDFSVFBell64 bell;
        const float fc = 1000.0f;
        const float Q = 2.5f;

        // Caso 3a: Guadagno 0 dB -> Bit-exact passthrough
        bell.setParameters(fc, Q, 0.0f, static_cast<float>(sr));
        const float testVal = 0.7071f;
        const float outVal = bell.process(testVal);
        assert(std::abs(outVal - testVal) < 1.0e-6f);

        // Caso 3b: Guadagno +6 dB a fc -> Raddoppio esatto dell'ampiezza (V = 2.0)
        bell.reset();
        bell.setParameters(fc, Q, 6.0206f, static_cast<float>(sr));
        // Invia onda sinusoidale alla frequenza centrale fc
        float maxAmpIn = 0.0f, maxAmpOut = 0.0f;
        for (int i = 0; i < 4800; ++i) {
            const float inS = std::sin(2.0f * PI * fc * static_cast<float>(i) / static_cast<float>(sr));
            const float outS = bell.process(inS);
            if (i > 3800) { // Steady state
                maxAmpIn = std::max(maxAmpIn, std::abs(inS));
                maxAmpOut = std::max(maxAmpOut, std::abs(outS));
            }
        }
        const float measuredGainBoost = maxAmpOut / maxAmpIn;
        std::cout << "  ZDF SVF Bell 64-bit +6 dB Test -> Measured Gain: " << measuredGainBoost 
                  << " (Ideal: 2.0000)" << std::endl;
        assert(std::abs(measuredGainBoost - 2.0f) < 0.01f);

        // Caso 3c: Guadagno -6 dB a fc -> Dimezzamento esatto (V = 0.5)
        bell.reset();
        bell.setParameters(fc, Q, -6.0206f, static_cast<float>(sr));
        maxAmpIn = 0.0f; maxAmpOut = 0.0f;
        for (int i = 0; i < 4800; ++i) {
            const float inS = std::sin(2.0f * PI * fc * static_cast<float>(i) / static_cast<float>(sr));
            const float outS = bell.process(inS);
            if (i > 3800) {
                maxAmpIn = std::max(maxAmpIn, std::abs(inS));
                maxAmpOut = std::max(maxAmpOut, std::abs(outS));
            }
        }
        const float measuredGainCut = maxAmpOut / maxAmpIn;
        std::cout << "  ZDF SVF Bell 64-bit -6 dB Test -> Measured Gain: " << measuredGainCut 
                  << " (Ideal: 0.5000)" << std::endl;
        assert(std::abs(measuredGainCut - 0.5f) < 0.01f);
    }

    // 4. Verifica Formant Tracking adattivo su registri vocali differenti (Male / Female / Soprano)
    {
        fp.reset();
        fp.setKeepFormants(false);
        fp.setFormantShiftSemitones(0.0f);

        // Registro maschile basso (F0 = 110 Hz, A2) -> F1 base neutro
        fp.updateTracking(110.0f, 1.0f, true);
        for (int i = 0; i < 200; ++i) fp.processSample(0.0f);
        const float f1Male = fp.getTrackedF1Hz();
        const float f2Male = fp.getTrackedF2Hz();
        std::cout << "  Male Voice (F0=110 Hz) -> Tracked F1: " << f1Male << " Hz | Tracked F2: " << f2Male << " Hz" << std::endl;
        assert(f1Male >= 600.0f && f1Male <= 660.0f);
        assert(f2Male >= 1700.0f && f2Male <= 1800.0f);

        // Registro soprano / acuto (F0 = 880 Hz, A5) -> Formant Tuning adatta F1 affinche' sia > F0
        fp.updateTracking(880.0f, 1.0f, true);
        for (int i = 0; i < 2000; ++i) fp.processSample(0.0f);
        const float f1Soprano = fp.getTrackedF1Hz();
        const float f2Soprano = fp.getTrackedF2Hz();
        std::cout << "  Soprano Voice (F0=880 Hz) -> Tracked F1: " << f1Soprano << " Hz | Tracked F2: " << f2Soprano << " Hz" << std::endl;
        assert(f1Soprano > 880.0f); // F1 sale sopra F0 per evitare risonanze spurie mute!
        assert(f2Soprano > f1Soprano * 2.0f);
    }

    // 5. Verifica Integrata su RealTuneEngine (Keep Formants End-to-End)
    {
        RealTuneEngine engine;
        engine.prepare(sr, 512);
        engine.setKeepFormants(true);
        assert(engine.isKeepFormantsEnabled() == true);

        engine.setFormantShiftSemitones(-3.0f);
        assert(std::abs(engine.getFormantShiftSemitones() - (-3.0f)) < 1e-4f);

        // Esegui blocco vocale sintetico a 440 Hz con retuning attivo
        std::vector<float> inBuf(512);
        std::vector<float> outBuf(512);
        for (size_t i = 0; i < 512; ++i) {
            inBuf[i] = 0.5f * std::sin(2.0f * PI * 440.0f * static_cast<float>(i) / static_cast<float>(sr));
        }

        const float* ins[1] = { inBuf.data() };
        float* outs[1] = { outBuf.data() };
        engine.process(ins, outs, 1, 512);

        std::cout << "  RealTuneEngine Formant Telemetry -> Effective: " 
                  << engine.getEffectiveFormantShiftSemitones() 
                  << " st | F1: " << engine.getFormantF1Hz() << " Hz | F2: " << engine.getFormantF2Hz() << " Hz" << std::endl;
        assert(engine.getFormantF1Hz() > 0.0f);
        assert(engine.getFormantF2Hz() > engine.getFormantF1Hz());
    }

    std::cout << "  [PASS] Keep Formants Dynamic Tracking & ZDF Dual-Pole Formant Shaper passed all tests." << std::endl << std::endl;
}

void testMeldaDepthSpeedBlend() {
    std::cout << "[TEST] 12. Melda Depth & Speed Dynamic Retune Blending Verification..." << std::endl;
    RetuneFilter rf;
    rf.prepare(48000.0);
    rf.setRetuneSpeedMs(0.0f); // Hard-Tune istantaneo per verificare il Depth puro

    // Cents offset = +50 cents (quarto di tono stonato, ratio ~ 1.0293)
    const float rawRatio = std::pow(2.0f, 50.0f / 1200.0f);

    // Case 1: Depth = 0% -> ratio = 1.0 (naturale non toccato)
    rf.setDepth(0.0f);
    float outRatio = rf.processSample(rawRatio, 50.0f);
    std::cout << "  Depth 0% -> Target Ratio: 1.0 | Out Ratio: " << outRatio << std::endl;
    assert(std::abs(outRatio - 1.0f) < 1.0e-4f);

    // Case 2: Depth = 50% -> correzione a metà (+25 cents)
    rf.setDepth(0.5f);
    outRatio = rf.processSample(rawRatio, 50.0f);
    const float expectedHalfRatio = std::pow(2.0f, 25.0f / 1200.0f);
    std::cout << "  Depth 50% -> Expected: " << expectedHalfRatio << " | Out: " << outRatio << std::endl;
    assert(std::abs(outRatio - expectedHalfRatio) < 1.0e-3f);

    // Case 3: Depth = 100% -> correzione piena (+50 cents)
    rf.setDepth(1.0f);
    outRatio = rf.processSample(rawRatio, 50.0f);
    std::cout << "  Depth 100% -> Expected: " << rawRatio << " | Out: " << outRatio << std::endl;
    assert(std::abs(outRatio - rawRatio) < 1.0e-3f);

    std::cout << "  [PASS] Melda Depth & Speed Blending passed." << std::endl << std::endl;
}

void testRapidNoteAndScaleSwitching() {
    std::cout << "[TEST] 13. Rapid Note & Scale Switching & Blocked Mask Safety..." << std::endl;
    MusicalQuantizer quant;
    quant.setA4Reference(440.0f);

    // 1. Test NaN and Inf safety in quantizer
    QuantizeResult nanRes = quant.quantize(std::numeric_limits<float>::quiet_NaN());
    assert(std::isfinite(nanRes.pitchRatio));
    assert(std::isfinite(nanRes.targetFreqHz));

    QuantizeResult infRes = quant.quantize(std::numeric_limits<float>::infinity());
    assert(std::isfinite(infRes.pitchRatio));
    assert(std::isfinite(infRes.targetFreqHz));

    // 2. Test All Notes Blocked Mask (0x0FFF = all 12 notes blocked)
    quant.setScale(ScaleType::Major);
    quant.setRootKey(0); // C
    quant.setBlockedMask(0x0FFF); // All blocked
    QuantizeResult allBlockedRes = quant.quantize(440.0f);
    std::cout << "  All notes blocked -> pitchRatio: " << allBlockedRes.pitchRatio << std::endl;
    assert(std::abs(allBlockedRes.pitchRatio - 1.0f) < 1e-4f); // Must bypass

    // 3. Test Scale Switching across all 12 roots and scales while processing RealTuneEngine
    RealTuneEngine engine;
    engine.prepare(48000.0, 512);
    engine.setRetuneSpeedMs(15.0f);

    std::vector<float> inBuffer(512);
    std::vector<float> outBuffer(512);

    for (int root = 0; root < 12; ++root) {
        engine.setRootKey(root);
        for (int scale = 0; scale <= 7; ++scale) {
            engine.setScale(static_cast<ScaleType>(scale));
            engine.setBlockedMask(static_cast<uint16_t>(1 << ((root + 1) % 12)));

            // Genera tono sinusoidale a 440 Hz (A4)
            for (size_t i = 0; i < 512; ++i) {
                inBuffer[i] = 0.5f * std::sin(2.0f * PI * 440.0f * static_cast<float>(i) / 48000.0f);
            }

            engine.process(inBuffer.data(), outBuffer.data(), 512);

            for (size_t i = 0; i < 512; ++i) {
                assert(std::isfinite(outBuffer[i]));
                assert(std::abs(outBuffer[i]) < 5.0f);
            }
        }
    }

    std::cout << "  [PASS] Rapid Note & Scale Switching passed with 0 crashes, 0 NaNs." << std::endl << std::endl;
}

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "   171RealTune DSP Core Architecture Verification Suite   " << std::endl;
    std::cout << "==========================================================" << std::endl;

    try {
        testPitchDetectorMPM();
        testGlottalClosureDetector();
        testMusicalQuantizer();
        testRetuneFilter();
        testRealTuneEngineIntegration();
        testSampleRateStress();
        testDCOffsetImmunity();
        testHumanizeVibrato();
        testFormantShiftIntegration();
        testStereoWidthMonoCancellation();
        testKeepFormantsDynamicTracking();
        testMeldaDepthSpeedBlend();
        testRapidNoteAndScaleSwitching();

        std::cout << ">>> ALL 171REALTUNE DSP UNIT TESTS PASSED SUCCESSFULLY! <<<" << std::endl;
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "EXCEPTION: " << e.what() << std::endl;
        return 1;
    }
}
