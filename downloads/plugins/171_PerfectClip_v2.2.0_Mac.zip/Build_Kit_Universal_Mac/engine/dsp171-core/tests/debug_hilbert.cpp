#include <iostream>
#include <cmath>
#include <vector>
#include "dsp171/DPLLPitchTracker.h"

int main() {
    dsp171::HilbertPhaseSplitter splitter;
    const float f = 100.0f;
    const float sr = 48000.0f;

    splitter.reset();
    for (int i = 0; i < 4800; ++i) {
        float in = std::sin(2.0f * 3.1415926535f * f * static_cast<float>(i) / sr);
        float outI = 0.0f, outQ = 0.0f;
        splitter.processSample(in, outI, outQ);
    }

    float dotProduct = 0.0f;
    float powerI = 0.0f;
    float powerQ = 0.0f;
    const size_t testSamples = static_cast<size_t>(sr / f) * 10;

    for (size_t i = 0; i < testSamples; ++i) {
        float in = std::sin(2.0f * 3.1415926535f * f * static_cast<float>(i) / sr);
        float outI = 0.0f, outQ = 0.0f;
        splitter.processSample(in, outI, outQ);
        dotProduct += outI * outQ;
        powerI += outI * outI;
        powerQ += outQ * outQ;
    }

    const float correlation = dotProduct / (std::sqrt(powerI * powerQ) + 1e-12f);
    std::cout << "dotProduct=" << dotProduct << " powerI=" << powerI << " powerQ=" << powerQ << " correlation=" << correlation << std::endl;
    return 0;
}
