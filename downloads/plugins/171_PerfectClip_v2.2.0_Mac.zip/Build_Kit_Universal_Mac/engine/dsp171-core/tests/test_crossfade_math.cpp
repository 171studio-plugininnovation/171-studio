#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include "dsp171/Common.h"

using namespace dsp171;

// Comparison of Crossfade Curves: Equal-Power vs Equal-Gain Hann
void testCrossfadeCurves() {
    std::cout << "--- Crossfade Coherent Sum Test (s1 == s0) ---\n";
    for (float phase = 0.0f; phase <= 1.01f; phase += 0.25f) {
        // Equal-Power (Current code)
        float rad = 0.5f * PI * phase;
        float ep0 = std::cos(rad);
        float ep1 = std::sin(rad);
        float epSum = ep0 + ep1;
        float epGainDb = 20.0f * std::log10(epSum);

        // Equal-Gain Hann (Proposed)
        float eg0 = 0.5f * (1.0f + std::cos(PI * phase));
        float eg1 = 0.5f * (1.0f - std::cos(PI * phase));
        float egSum = eg0 + eg1;
        float egGainDb = 20.0f * std::log10(egSum);

        std::cout << "Phase " << std::fixed << std::setprecision(2) << phase 
                  << " | Equal-Power Gain: " << std::showpos << epGainDb << " dB"
                  << " | Equal-Gain Hann: " << egGainDb << " dB\n";
    }
    std::cout << std::endl;
}

int main() {
    testCrossfadeCurves();
    return 0;
}
