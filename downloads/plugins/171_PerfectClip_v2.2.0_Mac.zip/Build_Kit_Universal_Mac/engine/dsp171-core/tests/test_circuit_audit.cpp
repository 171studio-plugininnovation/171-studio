#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include <fstream>
#include <complex>
#include <numbers>
#include "dsp171/Common.h"
#include "dsp171/FastMath.h"
#include "dsp171/ADAA2HardClipper.h"
#include "dsp171/ADAA2Clipper.h"
#include "dsp171/AcousticThermalDiodeClipper.h"
#include "dsp171/DCBlocker.h"
#include "dsp171/PerfectClipEngine.h"
#include "dsp171/TransformerSaturator.h"

using namespace dsp171;

// Simple DFT to compute exact magnitude and phase of specific harmonic bins
struct HarmonicAnalysis {
    double fundamentalMag = 0.0;
    double fundamentalPhase = 0.0;
    double h2Mag = 0.0;
    double h2DbRel = -200.0;
    double h3Mag = 0.0;
    double h3DbRel = -200.0;
    double h4Mag = 0.0;
    double h4DbRel = -200.0;
    double h5Mag = 0.0;
    double h5DbRel = -200.0;
    double dcOffset = 0.0;
    double thdPercent = 0.0;
};

HarmonicAnalysis analyzeHarmonics(const std::vector<float>& buffer, double sampleRate, double f0, size_t skipStart = 4096) {
    const size_t N = buffer.size() - skipStart;
    auto getBin = [&](double targetFreq) -> std::complex<double> {
        std::complex<double> sum(0.0, 0.0);
        for (size_t i = 0; i < N; ++i) {
            double sample = buffer[skipStart + i];
            double angle = -2.0 * std::numbers::pi_v<double> * targetFreq * static_cast<double>(i) / sampleRate;
            sum += sample * std::complex<double>(std::cos(angle), std::sin(angle));
        }
        return sum * (2.0 / static_cast<double>(N));
    };

    HarmonicAnalysis res;
    // DC
    double dcSum = 0.0;
    for (size_t i = 0; i < N; ++i) {
        dcSum += buffer[skipStart + i];
    }
    res.dcOffset = dcSum / static_cast<double>(N);

    auto h1 = getBin(f0);
    res.fundamentalMag = std::abs(h1);
    res.fundamentalPhase = std::arg(h1) * (180.0 / std::numbers::pi_v<double>);

    auto h2 = getBin(2.0 * f0);
    res.h2Mag = std::abs(h2);
    res.h2DbRel = (res.fundamentalMag > 1e-12) ? 20.0 * std::log10(res.h2Mag / res.fundamentalMag) : -200.0;

    auto h3 = getBin(3.0 * f0);
    res.h3Mag = std::abs(h3);
    res.h3DbRel = (res.fundamentalMag > 1e-12) ? 20.0 * std::log10(res.h3Mag / res.fundamentalMag) : -200.0;

    auto h4 = getBin(4.0 * f0);
    res.h4Mag = std::abs(h4);
    res.h4DbRel = (res.fundamentalMag > 1e-12) ? 20.0 * std::log10(res.h4Mag / res.fundamentalMag) : -200.0;

    auto h5 = getBin(5.0 * f0);
    res.h5Mag = std::abs(h5);
    res.h5DbRel = (res.fundamentalMag > 1e-12) ? 20.0 * std::log10(res.h5Mag / res.fundamentalMag) : -200.0;

    double harmPwr = res.h2Mag * res.h2Mag + res.h3Mag * res.h3Mag + res.h4Mag * res.h4Mag + res.h5Mag * res.h5Mag;
    res.thdPercent = (res.fundamentalMag > 1e-12) ? 100.0 * std::sqrt(harmPwr) / res.fundamentalMag : 0.0;

    return res;
}

int main() {
    std::cout << "===================================================================\n";
    std::cout << "  171PerfectClip: Exhaustive Circuit, Tube & Transformer Audit Test\n";
    std::cout << "===================================================================\n\n";

    const double sampleRate = 48000.0;
    const size_t totalSamples = 48000 * 2; // 2 seconds

    // -------------------------------------------------------------
    // TEST 1: GoldConverter122 (AcousticThermalDiodeClipper)
    // -------------------------------------------------------------
    std::cout << "--- 1. AUDIT OF GoldConverter122 (AcousticThermalDiodeClipper) ---\n";
    AcousticThermalDiodeClipper goldClipper;
    goldClipper.prepare(sampleRate);

    // Test a: JFET harmonic coloration at different input levels
    double levelsDb[] = { -18.0, -12.0, -6.0, -3.0, -1.0, 0.0, +3.0 };
    std::cout << "Input Level | H1 (dBFS) | H2 (dB rel) | H3 (dB rel) | Residual DC | THD (%)\n";
    std::cout << "------------+-----------+-------------+-------------+-------------+---------\n";

    for (double inDb : levelsDb) {
        goldClipper.reset();
        goldClipper.prepare(sampleRate);
        double peakAmp = std::pow(10.0, inDb / 20.0);
        std::vector<float> buf(totalSamples);
        const double f0 = 1000.0;

        for (size_t i = 0; i < totalSamples; ++i) {
            double t = static_cast<double>(i) / sampleRate;
            float in = static_cast<float>(peakAmp * std::cos(2.0 * std::numbers::pi_v<double> * f0 * t));
            buf[i] = goldClipper.processSample(in, 1.0f, true);
        }

        auto a = analyzeHarmonics(buf, sampleRate, f0, 24000);
        double h1Db = 20.0 * std::log10(a.fundamentalMag);
        std::cout << std::setw(10) << inDb << " dB | "
                  << std::setw(9) << std::fixed << std::setprecision(2) << h1Db << " | "
                  << std::setw(11) << a.h2DbRel << " | "
                  << std::setw(11) << a.h3DbRel << " | "
                  << std::setw(11) << std::scientific << std::setprecision(2) << a.dcOffset << " | "
                  << std::setw(6) << std::fixed << std::setprecision(3) << a.thdPercent << "%\n";
    }

    // Test b: Thermal Sag Step Response & Time Constant Verification
    std::cout << "\nThermal ODE Sag Dynamics (tau_th = 35 ms):\n";
    goldClipper.reset();
    goldClipper.prepare(sampleRate);

    // Apply +6 dB overload burst of 500 ms (24000 samples)
    float overloadAmp = 2.0f; // +6 dBFS
    std::vector<float> sagCurve;
    sagCurve.reserve(48000);
    for (size_t i = 0; i < 24000; ++i) {
        float in = overloadAmp * std::sin(2.0f * std::numbers::pi_v<float> * 1000.0f * static_cast<float>(i) / 48000.0f);
        goldClipper.processSample(in, 1.0f, true);
        sagCurve.push_back(goldClipper.getThermalSag());
    }
    // Now silence for 500 ms (relaxation phase)
    for (size_t i = 0; i < 24000; ++i) {
        goldClipper.processSample(0.0f, 1.0f, true);
        sagCurve.push_back(goldClipper.getThermalSag());
    }

    float maxSag = sagCurve[23999];
    // Find 63.2% rise time
    float targetRise = 0.6321f * maxSag;
    size_t riseIdx = 0;
    for (size_t i = 0; i < 24000; ++i) {
        if (sagCurve[i] >= targetRise) {
            riseIdx = i;
            break;
        }
    }
    double tauMeasuredMs = (static_cast<double>(riseIdx) / sampleRate) * 1000.0;

    // Find 63.2% decay time
    float targetDecay = maxSag * (1.0f - 0.6321f);
    size_t decayIdx = 24000;
    for (size_t i = 24000; i < 48000; ++i) {
        if (sagCurve[i] <= targetDecay) {
            decayIdx = i - 24000;
            break;
        }
    }
    double tauDecayMeasuredMs = (static_cast<double>(decayIdx) / sampleRate) * 1000.0;

    std::cout << "  - Max Thermal State: " << maxSag << "\n";
    std::cout << "  - Measured Rise tau: " << tauMeasuredMs << " ms (Target: 35.0 ms)\n";
    std::cout << "  - Measured Decay tau: " << tauDecayMeasuredMs << " ms (Target: 35.0 ms)\n";
    std::cout << "  - Effective Ceiling Sag: " << 20.0 * std::log10(1.0 - 0.05 * maxSag) << " dB\n";

    // -------------------------------------------------------------
    // TEST 2: TubeTriodeClassA
    // -------------------------------------------------------------
    std::cout << "\n--- 2. AUDIT OF TubeTriodeClassA ---\n";
    ADAA2Clipper tubeClipper;

    std::cout << "Input Level | H1 (dBFS) | H2 (dB rel) | H3 (dB rel) | H4 (dB rel) | H2/H3 Ratio (dB)\n";
    std::cout << "------------+-----------+-------------+-------------+-------------+------------------\n";
    for (double inDb : levelsDb) {
        tubeClipper.reset();
        double peakAmp = std::pow(10.0, inDb / 20.0);
        std::vector<float> buf(totalSamples);
        const double f0 = 1000.0;

        for (size_t i = 0; i < totalSamples; ++i) {
            double t = static_cast<double>(i) / sampleRate;
            float in = static_cast<float>(peakAmp * std::cos(2.0 * std::numbers::pi_v<double> * f0 * t));
            // In PerfectClipEngine:
            float scaled = in; // ceilingLinear = 1.0
            float tubeIn = scaled + 0.12f * scaled * scaled;
            float tubeOut = tubeClipper.processSample(tubeIn, 1.15f);
            buf[i] = tubeOut;
        }

        auto a = analyzeHarmonics(buf, sampleRate, f0, 24000);
        double h1Db = 20.0 * std::log10(a.fundamentalMag);
        double h2_h3 = a.h2DbRel - a.h3DbRel;
        std::cout << std::setw(10) << inDb << " dB | "
                  << std::setw(9) << std::fixed << std::setprecision(2) << h1Db << " | "
                  << std::setw(11) << a.h2DbRel << " | "
                  << std::setw(11) << a.h3DbRel << " | "
                  << std::setw(11) << a.h4DbRel << " | "
                  << std::setw(14) << h2_h3 << " dB\n";
    }

    // -------------------------------------------------------------
    // TEST 3: GermaniumDiode
    // -------------------------------------------------------------
    std::cout << "\n--- 3. AUDIT OF GermaniumDiode Mode ---\n";
    std::cout << "Input Level | H1 (dBFS) | H2 (dB rel) | H3 (dB rel) | THD (%) | Peak Compression\n";
    std::cout << "------------+-----------+-------------+-------------+---------+------------------\n";
    for (double inDb : levelsDb) {
        double peakAmp = std::pow(10.0, inDb / 20.0);
        std::vector<float> buf(totalSamples);
        const double f0 = 1000.0;

        for (size_t i = 0; i < totalSamples; ++i) {
            double t = static_cast<double>(i) / sampleRate;
            float in = static_cast<float>(peakAmp * std::cos(2.0 * std::numbers::pi_v<double> * f0 * t));
            // In PerfectClipEngine:
            float scaled = in;
            float diodeOut = static_cast<float>(ADAA2Clipper::f(static_cast<double>(scaled) * 1.5)) / 1.2f;
            buf[i] = diodeOut;
        }

        auto a = analyzeHarmonics(buf, sampleRate, f0, 24000);
        double h1Db = 20.0 * std::log10(a.fundamentalMag);
        float maxOut = 0.0f;
        for (size_t i = 24000; i < totalSamples; ++i) {
            if (std::abs(buf[i]) > maxOut) maxOut = std::abs(buf[i]);
        }
        double compDb = 20.0 * std::log10(maxOut / peakAmp);
        std::cout << std::setw(10) << inDb << " dB | "
                  << std::setw(9) << std::fixed << std::setprecision(2) << h1Db << " | "
                  << std::setw(11) << a.h2DbRel << " | "
                  << std::setw(11) << a.h3DbRel << " | "
                  << std::setw(7) << std::fixed << std::setprecision(2) << a.thdPercent << "% | "
                  << std::setw(14) << compDb << " dB\n";
    }

    // -------------------------------------------------------------
    // TEST 4: DC Blockers & Sub-Bass Phase Integrity (Transformer Interaction)
    // -------------------------------------------------------------
    std::cout << "\n--- 4. AUDIT OF DC BLOCKERS & SUB-BASS PHASE INTEGRITY ---\n";
    DCBlocker preparedBlocker10;
    preparedBlocker10.prepare(sampleRate, 10.0f);
    DCBlocker preparedBlocker5;
    preparedBlocker5.prepare(sampleRate, 5.0f);
    DCBlocker unpreparedBlocker; // Default rDC = 0.995

    double testFrequencies[] = { 10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 80.0, 100.0 };
    std::cout << "Freq (Hz) | 5Hz Blocker Phase | 10Hz Prep Phase | Unprep (0.995) Mag & Phase\n";
    std::cout << "----------+-------------------+-----------------+---------------------------\n";

    for (double f : testFrequencies) {
        preparedBlocker5.reset();
        preparedBlocker10.reset();
        unpreparedBlocker.reset();

        std::vector<float> b5(totalSamples), b10(totalSamples), bUnp(totalSamples);
        for (size_t i = 0; i < totalSamples; ++i) {
            double t = static_cast<double>(i) / sampleRate;
            float in = static_cast<float>(std::cos(2.0 * std::numbers::pi_v<double> * f * t));
            b5[i] = preparedBlocker5.processSample(in);
            b10[i] = preparedBlocker10.processSample(in);
            bUnp[i] = unpreparedBlocker.processSample(in);
        }

        auto a5 = analyzeHarmonics(b5, sampleRate, f, 24000);
        auto a10 = analyzeHarmonics(b10, sampleRate, f, 24000);
        auto aUnp = analyzeHarmonics(bUnp, sampleRate, f, 24000);

        std::cout << std::setw(8) << std::fixed << std::setprecision(1) << f << " Hz | "
                  << std::setw(15) << std::fixed << std::setprecision(2) << a5.fundamentalPhase << " deg | "
                  << std::setw(13) << a10.fundamentalPhase << " deg | "
                  << std::setw(8) << 20.0 * std::log10(aUnp.fundamentalMag) << " dB, "
                  << std::setw(6) << aUnp.fundamentalPhase << " deg\n";
    }

    // -------------------------------------------------------------
    // TEST 5: TransformerSaturator Behavior
    // -------------------------------------------------------------
    std::cout << "\n--- 5. AUDIT OF TransformerSaturator (Faraday Flux & Core Asymmetry) ---\n";
    TransformerSaturator trans;
    trans.prepare(sampleRate);

    std::cout << "Frequency | Input | Out H1 (dBFS) | Out H2 (dB rel) | Out H3 (dB rel) | THD (%)\n";
    std::cout << "----------+-------+---------------+-----------------+-----------------+--------\n";
    double transFreqs[] = { 30.0, 50.0, 100.0, 1000.0 };
    for (double f : transFreqs) {
        trans.reset();
        trans.prepare(sampleRate);
        std::vector<float> buf(totalSamples);
        for (size_t i = 0; i < totalSamples; ++i) {
            double t = static_cast<double>(i) / sampleRate;
            float in = static_cast<float>(0.8 * std::cos(2.0 * std::numbers::pi_v<double> * f * t));
            buf[i] = trans.processSample(in, 1.0f, 0.5f); // warmth = 0.5
        }
        auto a = analyzeHarmonics(buf, sampleRate, f, 24000);
        std::cout << std::setw(7) << std::fixed << std::setprecision(1) << f << " Hz | -1.9 dB | "
                  << std::setw(11) << 20.0 * std::log10(a.fundamentalMag) << " dBFS | "
                  << std::setw(13) << a.h2DbRel << " dB | "
                  << std::setw(13) << a.h3DbRel << " dB | "
                  << std::setw(6) << a.thdPercent << "%\n";
    }

    std::cout << "\nAudit verification tests completed successfully.\n";
    return 0;
}
