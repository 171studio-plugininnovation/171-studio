#include <iostream>
#include <vector>
#include <cmath>
#include <cassert>
#include "dsp171/FlagshipTubeSaturator.h"

int main() {
    std::cout << "========================================================\n";
    std::cout << "  171 Studio - Flagship Tube Saturator Test Suite       \n";
    std::cout << "  Physical Simulation: 12AX7 Class-A + 6AS6 Starvation \n";
    std::cout << "========================================================\n\n";

    dsp171::FlagshipTubeSaturator171 saturator;
    saturator.prepare(48000.0);

    // Test 1: Triode Mode Linear & Saturation Response
    saturator.setParameters(dsp171::FlagshipTubeMode::Triode, 6.0f, 0.0f, 0.0f, 0.0f);
    float outLow = saturator.processSample(0.1f);
    float outHigh = saturator.processSample(2.0f);
    std::cout << "[Test 1: Triode Mode]\n";
    std::cout << "  - Small signal out (in=0.1): " << outLow << "\n";
    std::cout << "  - Heavy drive out  (in=2.0): " << outHigh << "\n";
    assert(std::isfinite(outLow) && std::isfinite(outHigh));
    assert(std::abs(outHigh) < 2.5f); // Bounded saturation check

    // Test 2: Pentode Mode Nominal (Vg2 = 120V)
    saturator.setParameters(dsp171::FlagshipTubeMode::Pentode, 12.0f, 0.0f, 3.0f, 0.0f);
    float pentNominal = saturator.processSample(1.0f);
    std::cout << "\n[Test 2: Pentode Mode 120V Headroom]\n";
    std::cout << "  - Nominal Pentode out: " << pentNominal << "\n";
    assert(std::isfinite(pentNominal));

    // Test 3: Pentode Starvation Mode (Vg2 = 15V, starve=1.0)
    saturator.setParameters(dsp171::FlagshipTubeMode::Pentode, 18.0f, 1.0f, 0.0f, 0.0f);
    float starveQuiet = saturator.processSample(0.01f);
    float starveLoud = saturator.processSample(1.5f);
    std::cout << "\n[Test 3: Extreme Starvation Fuzz (Vg2 = 15V)]\n";
    std::cout << "  - Sub-threshold quiet signal (gated): " << starveQuiet << "\n";
    std::cout << "  - Heavy conduction starved fuzz:      " << starveLoud << "\n";
    assert(std::isfinite(starveQuiet) && std::isfinite(starveLoud));

    // Test 4: Long Block Stability & Zero NaN/Denormals
    saturator.reset();
    bool stable = true;
    for (int i = 0; i < 48000; ++i) {
        float sample = std::sin(2.0f * 3.14159265f * 440.0f * (float)i / 48000.0f);
        float sOut = saturator.processSample(sample);
        if (!std::isfinite(sOut)) {
            stable = false;
            break;
        }
    }
    std::cout << "\n[Test 4: 1-Second Audio Stream Stability]: " << (stable ? "PASSED (Zero NaN/Inf)" : "FAILED") << "\n";
    assert(stable);

    std::cout << "\n>>> ALL 171 FLAGSHIP TUBE SATURATOR TESTS PASSED SUCCESSFULLY! <<<\n";
    return 0;
}
