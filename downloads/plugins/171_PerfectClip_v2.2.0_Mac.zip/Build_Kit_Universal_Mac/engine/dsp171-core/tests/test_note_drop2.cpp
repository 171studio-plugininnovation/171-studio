#include <iostream>
#include <vector>
#include <cmath>
#include "dsp171/Common.h"
#include "dsp171/TDPSOLAShifter.h"
#include "dsp171/RealTuneEngine.h"

using namespace dsp171;

int main() {
    const double sr = 48000.0;
    RealTuneEngine engine;
    engine.prepare(sr);
    engine.setLowLatencyMode(true);
    engine.setRetuneSpeedMs(0.0f);
    engine.setScale(ScaleType::Chromatic);

    const size_t numSamples = 48000 * 2;
    std::vector<float> input(numSamples, 0.0f);
    std::vector<float> output(numSamples, 0.0f);

    float currentPhase = 0.0f;
    for (size_t i = 0; i < numSamples; ++i) {
        float f = (i < 48000) ? 335.0f : 215.0f;
        currentPhase += 2.0f * PI * f / static_cast<float>(sr);
        if (currentPhase > 2.0f * PI) currentPhase -= 2.0f * PI;
        float sample = 0.0f;
        for (int h = 1; h <= 10; ++h) {
            sample += (1.0f / h) * std::sin(h * currentPhase);
        }
        input[i] = sample * 0.3f;
    }

    engine.process(input.data(), output.data(), numSamples);

    for (size_t i = 43850; i <= 43865; ++i) {
        std::cout << "i=" << i << " in=" << input[i] << " out=" << output[i] 
                  << " delta=" << (output[i] - output[i-1]) << "\n";
    }
    return 0;
}
