#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include "dsp171/Common.h"
#include "dsp171/ZDFTiltFilter.h"
#include "dsp171/FormantShaperZDF.h"

using namespace dsp171;

// Reformed Formant Shaper
class ReformedFormantShaper {
public:
    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        tiltFilter.prepare(sampleRate);
        reset();
    }

    void reset() noexcept {
        f1TargetBell.reset();
        f1BaseBell.reset();
        f2TargetBell.reset();
        f2BaseBell.reset();
        tiltFilter.reset();

        manualShiftSemitones = 0.0f;
        autoShiftSemitones = 0.0f;
        targetEffectiveShift = 0.0f;
        smoothedEffectiveShift = 0.0f;

        targetPitchHz = 0.0f;
        smoothedPitchHz = 0.0f;

        trackedF1 = 650.0f;
        trackedF2 = 1750.0f;
        targetF1 = 650.0f;
        targetF2 = 1750.0f;

        keepFormantsEnabled = false;
        subSampleCount = 0;
    }

    void setKeepFormants(bool enabled) noexcept {
        keepFormantsEnabled = enabled;
        updateTargetShift();
    }

    void setManualFormantShift(float semitones) noexcept {
        manualShiftSemitones = std::clamp(semitones, -12.0f, 12.0f);
        updateTargetShift();
    }

    void updateTracking(float currentPitchHz, float pitchRatio, bool isVoiced) noexcept {
        if (keepFormantsEnabled && isVoiced && pitchRatio > 0.05f) {
            autoShiftSemitones = -12.0f * std::log2(pitchRatio);
            autoShiftSemitones = std::clamp(autoShiftSemitones, -12.0f, 12.0f);
        } else {
            autoShiftSemitones = 0.0f;
        }

        updateTargetShift();

        if (isVoiced && currentPitchHz > 30.0f) {
            targetPitchHz = currentPitchHz;
        } else {
            targetPitchHz = 0.0f;
        }
    }

    inline float processSample(float inSample) noexcept {
        const float alpha = std::clamp(1.0f - std::exp(-1.0f / (0.005f * sr)), 0.001f, 0.1f);
        smoothedEffectiveShift += alpha * (targetEffectiveShift - smoothedEffectiveShift);
        smoothedPitchHz += alpha * (targetPitchHz - smoothedPitchHz);

        if ((subSampleCount++ & 15) == 0) {
            updateFilterCoefficients();
        }

        float s = inSample;
        s = f1TargetBell.process(s);
        s = f1BaseBell.process(s);
        s = f2TargetBell.process(s);
        s = f2BaseBell.process(s);
        s = tiltFilter.processSample(s);
        return s;
    }

private:
    void updateTargetShift() noexcept {
        const float combined = manualShiftSemitones + (keepFormantsEnabled ? autoShiftSemitones : 0.0f);
        targetEffectiveShift = std::clamp(combined, -12.0f, 12.0f);
    }

    void updateFilterCoefficients() noexcept {
        if (smoothedPitchHz > 60.0f) {
            trackedF1 = std::max(550.0f, smoothedPitchHz * 1.15f);
            trackedF2 = std::max(1600.0f, trackedF1 * 2.3f);
        } else {
            trackedF1 = 600.0f;
            trackedF2 = 1700.0f;
        }

        const float M = std::exp2(smoothedEffectiveShift * (1.0f / 12.0f));
        const float nyquistMargin = sr * 0.45f;

        targetF1 = std::clamp(trackedF1 * M, 80.0f, nyquistMargin);
        targetF2 = std::clamp(trackedF2 * M, 200.0f, nyquistMargin);

        const float absShift = std::abs(smoothedEffectiveShift);
        const float gainRamp = std::clamp(absShift / 0.10f, 0.0f, 1.0f);

        // Gentle musical dipole gains: max 1.8 dB, Q = 0.75 (silky, zero resonance)
        const float boostF1 = std::min(1.8f, absShift * 0.35f) * gainRamp;
        const float boostF2 = std::min(1.8f, absShift * 0.35f) * gainRamp;

        // Dipole: Boost target, Cut base (preserving energy)
        if (smoothedEffectiveShift >= 0.0f) {
            f1TargetBell.setParameters(targetF1, 0.75f, +boostF1, sr);
            f1BaseBell.setParameters(trackedF1, 0.75f, -boostF1, sr);
            f2TargetBell.setParameters(targetF2, 0.80f, +boostF2, sr);
            f2BaseBell.setParameters(trackedF2, 0.80f, -boostF2, sr);
        } else {
            f1TargetBell.setParameters(targetF1, 0.75f, -boostF1, sr);
            f1BaseBell.setParameters(trackedF1, 0.75f, +boostF1, sr);
            f2TargetBell.setParameters(targetF2, 0.80f, -boostF2, sr);
            f2BaseBell.setParameters(trackedF2, 0.80f, +boostF2, sr);
        }

        // Tilt is kept neutral / zero in automatic mode to avoid harshness
        tiltFilter.setTilt(0.0f);
    }

    float sr = 48000.0f;
    ZDFSVFBell64 f1TargetBell;
    ZDFSVFBell64 f1BaseBell;
    ZDFSVFBell64 f2TargetBell;
    ZDFSVFBell64 f2BaseBell;
    ZDFTiltFilter tiltFilter;

    float manualShiftSemitones = 0.0f;
    float autoShiftSemitones = 0.0f;
    float targetEffectiveShift = 0.0f;
    float smoothedEffectiveShift = 0.0f;
    float targetPitchHz = 0.0f;
    float smoothedPitchHz = 0.0f;
    float trackedF1 = 600.0f;
    float trackedF2 = 1700.0f;
    float targetF1 = 600.0f;
    float targetF2 = 1700.0f;
    bool keepFormantsEnabled = false;
    uint32_t subSampleCount = 0;
};

int main() {
    const double sr = 48000.0;
    const float f0 = 200.0f;
    const float pitchRatioDown = std::pow(2.0f, -6.0f / 12.0f); // -6 semitones down

    FormantShaperZDF orig;
    orig.prepare(sr);
    orig.setKeepFormants(true);
    orig.updateTracking(f0, pitchRatioDown, true);
    for (int i = 0; i < 4000; ++i) orig.processSample(0.0f);

    ReformedFormantShaper ref;
    ref.prepare(sr);
    ref.setKeepFormants(true);
    ref.updateTracking(f0, pitchRatioDown, true);
    for (int i = 0; i < 4000; ++i) ref.processSample(0.0f);

    std::cout << "=========================================================\n";
    std::cout << "SPECTRAL RESPONSE COMPARISON: -6 SEMITONES PITCH DROP\n";
    std::cout << "=========================================================\n\n";

    const std::vector<float> freqs = { 200.0f, 600.0f, 850.0f, 1500.0f, 2500.0f, 2900.0f, 3500.0f, 5000.0f, 8000.0f };
    std::cout << "Freq (Hz) | Current Gain (dB) | Reformed Gain (dB) | Harshness Delta\n";
    std::cout << "--------------------------------------------------------------------\n";

    for (float f : freqs) {
        // Orig
        float origMaxIn = 0.0f, origMaxOut = 0.0f;
        for (int i = 0; i < 4800; ++i) {
            float sIn = std::sin(2.0f * PI * f * static_cast<float>(i) / static_cast<float>(sr));
            float sOut = orig.processSample(sIn);
            if (i > 3800) {
                origMaxIn = std::max(origMaxIn, std::abs(sIn));
                origMaxOut = std::max(origMaxOut, std::abs(sOut));
            }
        }
        float origGainDb = 20.0f * std::log10(origMaxOut / origMaxIn);

        // Reformed
        float refMaxIn = 0.0f, refMaxOut = 0.0f;
        for (int i = 0; i < 4800; ++i) {
            float sIn = std::sin(2.0f * PI * f * static_cast<float>(i) / static_cast<float>(sr));
            float sOut = ref.processSample(sIn);
            if (i > 3800) {
                refMaxIn = std::max(refMaxIn, std::abs(sIn));
                refMaxOut = std::max(refMaxOut, std::abs(sOut));
            }
        }
        float refGainDb = 20.0f * std::log10(refMaxOut / refMaxIn);

        std::cout << std::setw(8) << std::fixed << std::setprecision(0) << f << " | "
                  << std::setw(17) << std::showpos << std::setprecision(2) << origGainDb << " | "
                  << std::setw(18) << std::showpos << std::setprecision(2) << refGainDb << " | "
                  << std::setw(14) << std::showpos << std::setprecision(2) << (refGainDb - origGainDb) << " dB\n";
    }

    return 0;
}
