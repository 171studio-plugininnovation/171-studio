#include <iostream>
#include <vector>
#include <cmath>
#include <cassert>
#include <chrono>
#include <random>
#include <iomanip>

#include "dsp171/Common.h"
#include "dsp171/StereoWidth.h"

using namespace dsp171;

// -----------------------------------------------------------------------------
// Test 1: Matrice Mid/Side e controllo Width (0%, 100%, 200%)
// -----------------------------------------------------------------------------
void testMidSideWidthScaling() {
    std::cout << "[TEST] 1. Matrice Mid/Side e Controllo Width (0%, 100%, 200%)..." << std::endl;
    StereoWidth widener;
    const double sr = 48000.0;
    widener.prepare(sr);
    widener.setSideHighPassEnabled(false); // Disattiva temporaneamente l'HPF per testare la linearità pura della matrice

    // Caso A: Width = 0% (Mono Puro)
    {
        widener.setWidth(0.0f);
        widener.reset();

        // Segnale stereo fortemente asimmetrico: L = 1.0, R = -0.5
        float outL = 0.0f, outR = 0.0f;
        for (int i = 0; i < 2000; ++i) { // Rampa di assestamento smoothing
            widener.processSample(1.0f, -0.5f, outL, outR);
        }

        const float expectedMid = 0.5f * (1.0f + (-0.5f)); // 0.25f
        std::cout << "  [Width 0%] Input: (1.0, -0.5) -> Output: (" 
                  << outL << ", " << outR << ") | Expected Mid: " << expectedMid << std::endl;
        
        // Entrambi i canali devono essere perfettamente identici al Mid originale
        assert(std::abs(outL - expectedMid) < 1.0e-4f);
        assert(std::abs(outR - expectedMid) < 1.0e-4f);
        assert(std::abs(outL - outR) < 1.0e-5f); // Differenza stereo rigorosamente zero!
    }

    // Caso B: Width = 100% (Stereo Naturale)
    {
        widener.setWidth(1.0f);
        widener.reset();

        float outL = 0.0f, outR = 0.0f;
        for (int i = 0; i < 2000; ++i) {
            widener.processSample(0.8f, -0.2f, outL, outR);
        }

        std::cout << "  [Width 100%] Input: (0.8, -0.2) -> Output: (" 
                  << outL << ", " << outR << ") | Target: (0.8, -0.2)" << std::endl;
        
        assert(std::abs(outL - 0.8f) < 1.0e-3f);
        assert(std::abs(outR - (-0.2f)) < 1.0e-3f);
    }

    // Caso C: Width = 200% (Super Wide)
    {
        widener.setWidth(2.0f);
        widener.reset();

        const float inL = 0.7f;
        const float inR = 0.3f;
        const float mid = 0.5f * (inL + inR); // 0.5
        const float side = 0.5f * (inL - inR); // 0.2
        const float expectedL = mid + 2.0f * side; // 0.5 + 0.4 = 0.9
        const float expectedR = mid - 2.0f * side; // 0.5 - 0.4 = 0.1

        float outL = 0.0f, outR = 0.0f;
        for (int i = 0; i < 2000; ++i) {
            widener.processSample(inL, inR, outL, outR);
        }

        std::cout << "  [Width 200%] Input: (" << inL << ", " << inR << ") -> Output: (" 
                  << outL << ", " << outR << ") | Target: (" << expectedL << ", " << expectedR << ")" << std::endl;

        assert(std::abs(outL - expectedL) < 1.0e-3f);
        assert(std::abs(outR - expectedR) < 1.0e-3f);
    }

    std::cout << "  [PASS] Matrice Mid/Side e scaling Width verificati con successo." << std::endl << std::endl;
}

// -----------------------------------------------------------------------------
// Test 2: Segnali Mono in ingresso e Decorrelatore Dispersivo (7-12 ms)
// -----------------------------------------------------------------------------
void testMonoInputDecorrelation() {
    std::cout << "[TEST] 2. Ingresso Mono Puro (Side = 0) e Decorrelatore Allpass Dispersivo..." << std::endl;
    StereoWidth widener;
    const double sr = 48000.0;
    widener.prepare(sr);
    widener.setSideHighPassEnabled(false); // Test sul decorrelatore a banda intera

    // Verifichiamo che con Width = 100% e segnale mono (L == R),
    // il decorrelatore genera un Side e produce un'apertura stereo
    widener.setWidth(1.0f);
    widener.setDecorrelationAmount(1.0f);
    widener.setDecorrelationMode(StereoWidth::DecorrelationMode::Auto);
    widener.reset();

    std::mt19937 rng(42);
    std::uniform_real_distribution<float> dist(-0.5f, 0.5f);

    float sumDiffSquared = 0.0f;
    float sumOutSquared = 0.0f;

    // Eseguiamo 4800 campioni (100 ms) di rumore bianco mono
    for (size_t i = 0; i < 4800; ++i) {
        const float monoSample = dist(rng);
        float outL = 0.0f, outR = 0.0f;
        widener.processSample(monoSample, monoSample, outL, outR);

        if (i > 1500) { // Dopo transiente di avvio
            const float diff = outL - outR; // 2 * Side sintetico
            sumDiffSquared += diff * diff;
            sumOutSquared += (outL * outL + outR * outR);
        }
    }

    const float detectedMono = widener.getDetectedMonoFactor();
    const float correlation = widener.getStereoCorrelation();
    const float sideRms = std::sqrt(sumDiffSquared / 3300.0f) * 0.5f;

    std::cout << "  Mono Input Detector: " << detectedMono << " (Ideal: ~1.0)" << std::endl;
    std::cout << "  Stereo Correlation: " << correlation << " (Ideal: decorrelated, ~0.50 - 0.70)" << std::endl;
    std::cout << "  Synthetic Side RMS: " << sideRms << " (Ideal: > 0.0, energy present)" << std::endl;

    assert(detectedMono > 0.90f);          // Il rilevatore deve riconoscere il segnale mono
    assert(sideRms > 0.05f);               // Il Side decorrelato DEVE avere energia
    assert(correlation > 0.3f && correlation < 0.85f); // Correlazione naturale stereo

    // Verifichiamo con Width = 200%: il Side decorrelato deve raddoppiare in ampiezza
    widener.setWidth(2.0f);
    widener.reset();
    sumDiffSquared = 0.0f;
    for (size_t i = 0; i < 4800; ++i) {
        const float monoSample = dist(rng);
        float outL = 0.0f, outR = 0.0f;
        widener.processSample(monoSample, monoSample, outL, outR);
        if (i > 1500) {
            const float diff = outL - outR;
            sumDiffSquared += diff * diff;
        }
    }
    const float sideRmsWide = std::sqrt(sumDiffSquared / 3300.0f) * 0.5f;
    std::cout << "  Super-Wide Side RMS (200%): " << sideRmsWide 
              << " vs Natural Side RMS (100%): " << sideRms << std::endl;
    assert(sideRmsWide > sideRms * 1.5f); // Il side deve essere proporzionale a width!

    std::cout << "  [PASS] Decorrelatore allpass dispersivo verificato con successo." << std::endl << std::endl;
}

// -----------------------------------------------------------------------------
// Test 3: Garanzia Matematica 100% Mono Compatibilità (Zero Comb Filtering)
// -----------------------------------------------------------------------------
void testMonoCompatibilityMathematicalZero() {
    std::cout << "[TEST] 3. Garanzia Matematica 100% Mono Compatibilità (Comb-Filter Free)..." << std::endl;
    StereoWidth widener;
    const double sr = 48000.0;
    widener.prepare(sr);

    // Testiamo a diverse ampiezze di Width: 0%, 50%, 100%, 150%, 200%
    const std::vector<float> widths = { 0.0f, 0.5f, 1.0f, 1.5f, 2.0f };

    std::mt19937 rng(999);
    std::uniform_real_distribution<float> dist(-1.0f, 1.0f);

    for (float w : widths) {
        widener.setWidth(w);
        widener.setDecorrelationAmount(1.0f);
        widener.setSideHighPassEnabled(true); // HPF attivo
        widener.reset();

        float maxError = 0.0f;

        // Generiamo un segnale complesso: mix di sinusoidi + transienti + rumore
        for (size_t i = 0; i < 5000; ++i) {
            const float t = static_cast<float>(i) / static_cast<float>(sr);
            const float inL = 0.4f * std::sin(2.0f * PI * 150.0f * t) + 0.3f * std::sin(2.0f * PI * 1200.0f * t) + 0.1f * dist(rng);
            const float inR = 0.3f * std::sin(2.0f * PI * 220.0f * t) + 0.2f * std::sin(2.0f * PI * 3400.0f * t) + 0.1f * dist(rng);

            const float expectedMonoMid = 0.5f * (inL + inR);

            float outL = 0.0f, outR = 0.0f;
            widener.processSample(inL, inR, outL, outR);

            const float actualMonoSum = 0.5f * (outL + outR);
            const float err = std::abs(actualMonoSum - expectedMonoMid);
            maxError = std::max(maxError, err);
        }

        std::cout << "  Width " << std::setw(3) << static_cast<int>(w * 100.0f) << "% | "
                  << "Max Mono Cancellation Error: " << maxError 
                  << " (Strictly < 1.0e-6)" << std::endl;

        // La cancellazione deve essere IDENTICAMENTE ZERO (entro la precisione del float a 32 bit)
        assert(maxError < 1.0e-6f);
    }

    std::cout << "  [PASS] Mono compatibilità al 100% verificata matematicamente a zero." << std::endl << std::endl;
}

// -----------------------------------------------------------------------------
// Test 4: Filtro Passa-Alto sul Canale Side a 120 Hz (Mono Bass Solid Anchor)
// -----------------------------------------------------------------------------
void testSideHighPassFilter120Hz() {
    std::cout << "[TEST] 4. Filtro Passa-Alto Side a 120 Hz (Mono Bass Punch Verification)..." << std::endl;
    StereoWidth widener;
    const double sr = 48000.0;
    widener.prepare(sr);
    widener.setWidth(1.0f);
    widener.setSideHighPassFrequency(120.0f);
    widener.setSideHighPassEnabled(true);
    widener.reset();

    // Inviamo una sinusoide pura nel canale Side a 40 Hz (Sub-bass / Kick fundamental)
    // L = +1.0, R = -1.0 -> Mid = 0.0, Side = 1.0
    const float lowFreq = 40.0f;
    float maxSideLowOut = 0.0f;
    for (size_t i = 0; i < 4800; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(sr);
        const float s = std::sin(2.0f * PI * lowFreq * t);
        float outL = 0.0f, outR = 0.0f;
        widener.processSample(s, -s, outL, outR);
        if (i > 2400) { // Regime stazionario
            const float sideOut = 0.5f * (outL - outR);
            maxSideLowOut = std::max(maxSideLowOut, std::abs(sideOut));
        }
    }

    // A 40 Hz con filtro 12 dB/oct calibrato a 120 Hz (rapporto 120/40 = 3x, circa 1.58 ottave):
    // Attenuazione attesa > 18 dB (guadagno < 0.125)
    std::cout << "  Input Side @ 40 Hz (Peak 1.0) -> Output Side Peak: " << maxSideLowOut 
              << " (" << gainToDb(maxSideLowOut) << " dBFS, Attenuation: " 
              << -gainToDb(maxSideLowOut) << " dB)" << std::endl;
    assert(maxSideLowOut < 0.15f); // Fortemente attenuato nei bassi!

    // Ora inviamo una sinusoide a 1000 Hz nel canale Side (Midrange stereo)
    widener.reset();
    const float midFreq = 1000.0f;
    float maxSideMidOut = 0.0f;
    for (size_t i = 0; i < 4800; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(sr);
        const float s = std::sin(2.0f * PI * midFreq * t);
        float outL = 0.0f, outR = 0.0f;
        widener.processSample(s, -s, outL, outR);
        if (i > 2400) {
            const float sideOut = 0.5f * (outL - outR);
            maxSideMidOut = std::max(maxSideMidOut, std::abs(sideOut));
        }
    }

    std::cout << "  Input Side @ 1000 Hz (Peak 1.0) -> Output Side Peak: " << maxSideMidOut 
              << " (" << gainToDb(maxSideMidOut) << " dBFS, Passband Unity)" << std::endl;
    assert(maxSideMidOut > 0.95f); // Passa inalterato nella banda utile!

    std::cout << "  [PASS] Filtro Passa-Alto Side a 120 Hz verificato con successo." << std::endl << std::endl;
}

// -----------------------------------------------------------------------------
// Test 5: Stress Test Sample Rates Multipli (44.1k, 48k, 96k, 192k) & Throughput Benchmark
// -----------------------------------------------------------------------------
void testSampleRatesAndBenchmark() {
    std::cout << "[TEST] 5. Stress Test Sample Rates (44.1k, 48k, 96k, 192k) & Throughput..." << std::endl;
    const std::vector<double> rates = { 44100.0, 48000.0, 88200.0, 96000.0, 192000.0 };

    for (double sr : rates) {
        StereoWidth sw;
        sw.prepare(sr);
        sw.setWidth(1.5f);
        sw.reset();

        for (int i = 0; i < 1000; ++i) {
            float outL = 0.0f, outR = 0.0f;
            sw.processSample(0.5f, -0.3f, outL, outR);
            assert(!std::isnan(outL) && !std::isnan(outR));
            assert(!std::isinf(outL) && !std::isinf(outR));
        }
        std::cout << "  Sample Rate: " << static_cast<int>(sr) << " Hz -> Stable, OK." << std::endl;
    }

    // Benchmark Throughput su blocco di 480000 campioni (10 secondi stereo a 48k)
    StereoWidth benchWidener;
    benchWidener.prepare(48000.0);
    benchWidener.setWidth(1.4f);
    benchWidener.reset();

    const size_t numSamples = 480000;
    std::vector<float> blockL(numSamples, 0.4f);
    std::vector<float> blockR(numSamples, -0.2f);

    const auto tStart = std::chrono::high_resolution_clock::now();
    benchWidener.processBlock(blockL.data(), blockR.data(), numSamples);
    const auto tEnd = std::chrono::high_resolution_clock::now();

    const double elapsedSec = std::chrono::duration<double>(tEnd - tStart).count();
    const double mSampsPerSec = (numSamples / 1e6) / elapsedSec;
    const double realTimeMultiplier = 10.0 / elapsedSec;

    std::cout << "  [BENCHMARK] Elaborati 10.0s stereo (" << numSamples << " campioni) in " 
              << (elapsedSec * 1000.0) << " ms (" << mSampsPerSec << " MSamples/s, " 
              << realTimeMultiplier << "x Real-Time!)" << std::endl;

    assert(realTimeMultiplier > 20.0); // Ultra performante, zero allocazioni

    std::cout << "  [PASS] Sample Rates e Throughput verificati con successo." << std::endl << std::endl;
}

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "   dsp171::StereoWidth Spatial Audio Verification Suite   " << std::endl;
    std::cout << "==========================================================" << std::endl;

    try {
        testMidSideWidthScaling();
        testMonoInputDecorrelation();
        testMonoCompatibilityMathematicalZero();
        testSideHighPassFilter120Hz();
        testSampleRatesAndBenchmark();

        std::cout << ">>> ALL dsp171::StereoWidth TESTS PASSED PERFECTLY! <<<" << std::endl;
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "EXCEPTION: " << e.what() << std::endl;
        return 1;
    }
}
