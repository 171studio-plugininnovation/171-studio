#include <iostream>
#include <cassert>
#include <cmath>
#include <vector>
#include <dsp171/Common.h>
#include <dsp171/EasyVoiceChannelStrip.h>
#include <dsp171/SSLGChannelEQ.h>
#include <dsp171/RenaissanceDeEsser.h>

int main() {
    std::cout << "========================================================\n";
    std::cout << "  171 EASYVOICE OVERHAUL & RETROENGINEERING TEST SUITE  \n";
    std::cout << "========================================================\n\n";

    constexpr double sampleRate = 48000.0;
    constexpr int blockSize = 512;

    // -------------------------------------------------------------------------
    // TEST 1: SSL 4000 G 242 EQ (ZDF Proportional-Q & Smooth High Sheen)
    // -------------------------------------------------------------------------
    std::cout << "[TEST 1] SSLGChannelEQ (Cytomic ZDF SVF & Proportional-Q)...\n";
    {
        dsp171::SSLGChannelEQ eq;
        eq.prepare(sampleRate);

        // Test LF Bell vs Shelf
        eq.setLF(100.0f, +6.0f, dsp171::SSLGChannelEQ::BandType::Shelf);
        eq.setLMF(500.0f, -4.0f, 1.5f);
        eq.setHMF(3000.0f, +5.0f, 1.2f);
        eq.setHF(12000.0f, +8.0f, dsp171::SSLGChannelEQ::BandType::Bell);
        eq.setHPFFreq(80.0f);
        eq.setLPFFreq(18000.0f);

        // Process a block of test sine tones
        std::vector<float> bufferL(blockSize, 0.0f);
        std::vector<float> bufferR(blockSize, 0.0f);
        for (int i = 0; i < blockSize; ++i) {
            float t = static_cast<float>(i) / static_cast<float>(sampleRate);
            bufferL[i] = std::sin(2.0f * 3.14159265f * 1000.0f * t) * 0.5f;
            bufferR[i] = bufferL[i];
        }

        eq.processBlock(bufferL.data(), bufferR.data(), blockSize);

        for (int i = 0; i < blockSize; ++i) {
            assert(std::isfinite(bufferL[i]));
            assert(std::isfinite(bufferR[i]));
        }

        // Test high frequency de-cramped air sheen (16 kHz boost)
        eq.reset();
        eq.setLPFFreq(22000.0f); // bypass LPF
        eq.setHF(16000.0f, +12.0f, dsp171::SSLGChannelEQ::BandType::Shelf);
        float peak16k = 0.0f;
        float peak20k = 0.0f;
        for (int i = 0; i < blockSize; ++i) {
            float t = static_cast<float>(i) / static_cast<float>(sampleRate);
            float in = std::sin(2.0f * 3.14159265f * 16000.0f * t) * 0.2f;
            float outL = 0.0f, outR = 0.0f;
            eq.processSample(in, in, outL, outR);
            assert(std::isfinite(outL));
            peak16k = std::max(peak16k, std::abs(outL));
        }
        for (int i = 0; i < blockSize; ++i) {
            float t = static_cast<float>(i) / static_cast<float>(sampleRate);
            float in = std::sin(2.0f * 3.14159265f * 20000.0f * t) * 0.2f;
            float outL = 0.0f, outR = 0.0f;
            eq.processSample(in, in, outL, outR);
            assert(std::isfinite(outL));
            peak20k = std::max(peak20k, std::abs(outL));
        }
        std::cout << "   - 16 kHz High Shelf Cutoff Gain: " << peak16k << " (In=0.2): PASSED\n";
        std::cout << "   - 20 kHz High Shelf Plateau Gain: " << peak20k << " (In=0.2): PASSED\n";
        assert(peak16k > 0.35f); // confirmed boost at cutoff
        assert(peak20k > 0.70f); // confirmed full plateau boost
    }

    // -------------------------------------------------------------------------
    // TEST 2: Waves Renaissance DeEsser (Split-Band Crossover & Sibilant Ducking)
    // -------------------------------------------------------------------------
    std::cout << "[TEST 2] RenaissanceDeEsser (Split-Band Crossover Precision)...\n";
    {
        dsp171::RenaissanceDeEsser deEsser;
        deEsser.prepare(sampleRate);
        deEsser.setMode(dsp171::RenaissanceDeEsser::DeEsserMode::SplitBand);
        deEsser.setFrequency(6000.0f);
        deEsser.setThresholdDb(-24.0f);
        deEsser.setRangeDb(12.0f);

        // 1. Vocal body test (200 Hz fundamental) with NO sibilance
        float maxDeltaBody = 0.0f;
        for (int i = 0; i < 200; ++i) {
            float t = static_cast<float>(i) / static_cast<float>(sampleRate);
            float in = std::sin(2.0f * 3.14159265f * 200.0f * t) * 0.1f;
            float outL = 0.0f, outR = 0.0f;
            deEsser.processSample(in, in, outL, outR);
            maxDeltaBody = std::max(maxDeltaBody, std::abs(outL - in));
        }
        std::cout << "   - Low Vocal Body (200 Hz) Transparency Delta: " << maxDeltaBody << " dBFS: PASSED\n";
        assert(maxDeltaBody < 1.0e-5f); // 100% bit-exact body!

        // 2. Harsh Sibilance Burst (7 kHz at -10 dBFS)
        float maxGR = 0.0f;
        for (int i = 0; i < 500; ++i) {
            float t = static_cast<float>(i) / static_cast<float>(sampleRate);
            float in = std::sin(2.0f * 3.14159265f * 7000.0f * t) * 0.35f; // -9 dBFS peak
            float outL = 0.0f, outR = 0.0f;
            deEsser.processSample(in, in, outL, outR);
            maxGR = std::max(maxGR, deEsser.getGainReductionL());
        }
        std::cout << "   - Sibilant Burst Ducking (7 kHz): GR = " << maxGR << " dB: PASSED\n";
        assert(maxGR > 5.0f);
    }

    // -------------------------------------------------------------------------
    // TEST 3: Preamp Console Voicing & Color Differentiation
    // -------------------------------------------------------------------------
    std::cout << "[TEST 3] Preamp Console Color Differentiation (Neve vs SSL vs EMI)...\n";
    {
        dsp171::EasyVoiceChannelStrip stripNevo;
        stripNevo.prepare(sampleRate);
        stripNevo.setPreampEnabled(true);
        stripNevo.setPreampDrive(6.0f);
        stripNevo.setPreampWarmth(5.0f);
        stripNevo.setPreampConsole(dsp171::NLSSummingDSP::ConsoleType::Nevo);

        dsp171::EasyVoiceChannelStrip stripSpike;
        stripSpike.prepare(sampleRate);
        stripSpike.setPreampEnabled(true);
        stripSpike.setPreampDrive(6.0f);
        stripSpike.setPreampWarmth(5.0f);
        stripSpike.setPreampConsole(dsp171::NLSSummingDSP::ConsoleType::Spike);

        dsp171::EasyVoiceChannelStrip stripMike;
        stripMike.prepare(sampleRate);
        stripMike.setPreampEnabled(true);
        stripMike.setPreampDrive(6.0f);
        stripMike.setPreampWarmth(5.0f);
        stripMike.setPreampConsole(dsp171::NLSSummingDSP::ConsoleType::Mike);

        // Compare outputs on 60 Hz bass note (transformer test)
        float diffNevoSpike = 0.0f;
        float diffSpikeMike = 0.0f;
        for (int i = 0; i < 500; ++i) {
            float t = static_cast<float>(i) / static_cast<float>(sampleRate);
            float inVal = std::sin(2.0f * 3.14159265f * 60.0f * t) * 0.4f;

            float yNevoL = inVal, yNevoR = inVal;
            float ySpikeL = inVal, ySpikeR = inVal;
            float yMikeL = inVal, yMikeR = inVal;

            stripNevo.processBlock(&yNevoL, &yNevoR, 1);
            stripSpike.processBlock(&ySpikeL, &ySpikeR, 1);
            stripMike.processBlock(&yMikeL, &yMikeR, 1);

            diffNevoSpike += std::abs(yNevoL - ySpikeL);
            diffSpikeMike += std::abs(ySpikeL - yMikeL);
        }

        std::cout << "   - Neve vs SSL Cumulative Difference: " << diffNevoSpike << ": PASSED\n";
        std::cout << "   - SSL vs EMI Cumulative Difference:  " << diffSpikeMike << ": PASSED\n";
        assert(diffNevoSpike > 1.0f); // Clearly distinct color between consoles!
        assert(diffSpikeMike > 1.0f);
    }

    // -------------------------------------------------------------------------
    // TEST 4: Full EasyVoice Channel Strip End-to-End Processing
    // -------------------------------------------------------------------------
    std::cout << "[TEST 4] Full EasyVoice Channel Strip Real-Time Block Integrity...\n";
    {
        dsp171::EasyVoiceChannelStrip channelStrip;
        channelStrip.prepare(sampleRate);

        // Turn on Preamp, De-Esser, SSL EQ, Opto Leveler, FET Limiter
        channelStrip.setPreampEnabled(true);
        channelStrip.setPreampDrive(4.0f);
        channelStrip.setPreampWarmth(3.0f);

        channelStrip.setDeEsserEnabled(true);
        channelStrip.setDeEsserFrequency(5500.0f);
        channelStrip.setDeEsserThresholdDb(-20.0f);

        channelStrip.setEQEnabled(true);
        channelStrip.setLF(120.0f, +2.5f, dsp171::SSLGChannelEQ::BandType::Shelf);
        channelStrip.setLMF(450.0f, -3.0f, 1.2f);
        channelStrip.setHMF(3200.0f, +2.0f, 1.0f);
        channelStrip.setHF(10000.0f, +3.5f, dsp171::SSLGChannelEQ::BandType::Shelf);

        channelStrip.setOptoEnabled(true);
        channelStrip.setOptoPeakReduction(40.0f);
        channelStrip.setOptoGain(35.0f);

        std::vector<float> left(blockSize);
        std::vector<float> right(blockSize);
        for (int i = 0; i < blockSize; ++i) {
            float t = static_cast<float>(i) / static_cast<float>(sampleRate);
            left[i] = std::sin(2.0f * 3.14159265f * 350.0f * t) * 0.3f;
            right[i] = left[i];
        }

        channelStrip.processBlock(left.data(), right.data(), blockSize);

        for (int i = 0; i < blockSize; ++i) {
            assert(std::isfinite(left[i]));
            assert(std::isfinite(right[i]));
            assert(std::abs(left[i]) < 5.0f); // well-behaved dynamics
        }
        std::cout << "   - Processed 512 samples with 0 NaNs and rock-solid headroom: PASSED\n";
    }

    std::cout << "\n========================================================\n";
    std::cout << "  ALL EASYVOICE OVERHAUL TESTS COMPLETED SUCCESSFULLY!  \n";
    std::cout << "========================================================\n";
    return 0;
}
