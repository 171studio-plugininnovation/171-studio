#include <iostream>
#include <cassert>
#include <cmath>
#include <vector>
#include <numeric>

#include "dsp171/Common.h"
#include "dsp171/ReverbFDN16.h"
#include "dsp171/SchroederDiffuser.h"
#include "dsp171/PlateDispersionFilter.h"
#include "dsp171/SmartDuckingVCA.h"
#include "dsp171/HarmonicShimmer.h"
#include "dsp171/MonoMakerMS.h"
#include "dsp171/DecayRateEQ.h"
#include "dsp171/VintageColorUnit.h"
#include "dsp171/DSPHireManager.h"

int main() {
    std::cout << "==================================================================" << std::endl;
    std::cout << "   171 MUSIC INNOVATION: ENRICHED GENERAL DSP ENGINE TEST HARNESS " << std::endl;
    std::cout << "   Focus: Reverb FDN-16, Diffusers, Plate, Shimmer, Ducking & M/S " << std::endl;
    std::cout << "==================================================================" << std::endl;

    constexpr double sampleRate = 48000.0;
    int passed = 0;

    auto isSafe = [](float x) noexcept {
        return !std::isnan(x) && !std::isinf(x);
    };

    // TEST 1: ReverbFDN16 - Orthogonal Householder stability & decay scaling
    {
        dsp171::ReverbFDN16 fdn;
        fdn.prepare(sampleRate);
        fdn.updateDecay(2.0f, 1.0f, 0.0f);
        fdn.updateDamping(8000.0f);
        fdn.setModulation(3.2f, 0.65f);

        // Inietta un impulso unitario
        float outL = 0.0f, outR = 0.0f;
        fdn.processSample(1.0f, 1.0f, 0.0f, 0.0f, outL, outR);
        assert(isSafe(outL) && isSafe(outR));

        // Stress test su 50,000 campioni
        float maxVal = 0.0f;
        for (int i = 0; i < 50000; ++i) {
            fdn.processSample(0.0f, 0.0f, 0.0f, 0.0f, outL, outR);
            assert(isSafe(outL) && isSafe(outR));
            maxVal = std::max(maxVal, std::max(std::abs(outL), std::abs(outR)));
        }
        // Il sistema FDN con matrice Householder deve essere dissipativo ed energicamente stabile
        assert(maxVal < 1.0f);
        std::cout << "[TEST 01/09] ReverbFDN16: PASS (Energy bounded, max peak: " << maxVal << ")" << std::endl;
        passed++;
    }

    // TEST 2: SchroederDiffuser - Allpass 4-stage cascade with Golden Ratio
    {
        dsp171::SchroederDiffuser diffuser;
        diffuser.prepare(sampleRate);

        float outL = 0.0f, outR = 0.0f;
        float energyIn = 0.0f;
        float energyOut = 0.0f;

        // Inietta impulso e misura conservazione energetica
        diffuser.processSample(1.0f, 0.8f, outL, outR);
        energyIn += 1.0f * 1.0f + 0.8f * 0.8f;
        energyOut += outL * outL + outR * outR;

        for (int i = 0; i < 2000; ++i) {
            diffuser.processSample(0.0f, 0.0f, outL, outR);
            assert(isSafe(outL) && isSafe(outR));
            energyOut += outL * outL + outR * outR;
        }

        // Gli allpass ideali conservano l'energia totale (scarto < 5% per troncamento temporale)
        float ratio = energyOut / energyIn;
        assert(ratio > 0.85f && ratio < 1.15f);
        std::cout << "[TEST 02/09] SchroederDiffuser: PASS (Golden-Ratio unitary allpass conservation: " << ratio << ")" << std::endl;
        passed++;
    }

    // TEST 3: PlateDispersionFilter - EMT 140 Physical Bending Wave Dispersion
    {
        dsp171::PlateDispersionFilter plate;
        plate.prepare(sampleRate);
        plate.setDispersionAmount(0.85f);

        float outL = 0.0f, outR = 0.0f;
        plate.processSample(1.0f, 1.0f, outL, outR);
        assert(isSafe(outL) && isSafe(outR));

        float tailEnergy = 0.0f;
        for (int i = 0; i < 500; ++i) {
            plate.processSample(0.0f, 0.0f, outL, outR);
            assert(isSafe(outL) && isSafe(outR));
            tailEnergy += outL * outL + outR * outR;
        }

        assert(tailEnergy > 0.01f); // L'allpass cascata ha disperso nel tempo l'impulso
        std::cout << "[TEST 03/09] PlateDispersionFilter: PASS (Physical chirp transient dispersion confirmed)" << std::endl;
        passed++;
    }

    // TEST 4: SmartDuckingVCA - Dynamic Gating & External Sidechain
    {
        dsp171::SmartDuckingVCA vca;
        vca.prepare(sampleRate);
        vca.setParameters(-20.0f, 18.0f, 5.0f, 50.0f); // -20 dBFS soglia, 18 dB attenuazione

        // 1. Con segnale pilota basso (-40 dBFS), nessun ducking
        float silentGain = vca.computeGain(0.01f, 0.01f);
        assert(silentGain > 0.95f);
        assert(!vca.isDuckingActive());

        // 2. Con segnale pilota forte (0 dBFS), il ducking si attiva
        for (int i = 0; i < 500; ++i) {
            vca.computeGain(1.0f, 1.0f);
        }
        float duckedGain = vca.computeGain(1.0f, 1.0f);
        assert(duckedGain < 0.25f); // Circa -18 dB
        assert(vca.isDuckingActive());
        assert(vca.getGainReductionDb() > 10.0f);

        // 3. Ritorno al silenzio: il VCA recupera pienamente dopo 300 ms (15,000 campioni a 48 kHz)
        for (int i = 0; i < 15000; ++i) {
            vca.computeGain(0.0f, 0.0f);
        }
        float recoveredGain = vca.computeGain(0.0f, 0.0f);
        assert(recoveredGain > 0.95f);

        std::cout << "[TEST 04/09] SmartDuckingVCA: PASS (Max GR: " << vca.getMaxObservedGR() << " dB, Attack/Release verified)" << std::endl;
        passed++;
    }

    // TEST 5: HarmonicShimmer - Fractional Octave Pitch Shifting
    {
        dsp171::HarmonicShimmer shimmer;
        shimmer.prepare(sampleRate);
        shimmer.setParameters(12.0f, 40.0f); // +1 ottava

        // Invia una sinusoide a 440 Hz (La3) e verifica che l'uscita contenga energia e rimanga limitata
        float outL = 0.0f, outR = 0.0f;
        float sumEnergy = 0.0f;
        for (int i = 0; i < 4800; ++i) {
            float in = std::sin(2.0f * dsp171::PI * 440.0f * static_cast<float>(i) / 48000.0f);
            shimmer.processSample(in, in, outL, outR, 1.0f);
            assert(isSafe(outL) && isSafe(outR));
            assert(std::abs(outL) <= 1.0f && std::abs(outR) <= 1.0f);
            sumEnergy += outL * outL + outR * outR;
        }

        assert(sumEnergy > 10.0f);
        std::cout << "[TEST 05/09] HarmonicShimmer: PASS (+1 Octave energy generation bounded, zero glitch)" << std::endl;
        passed++;
    }

    // TEST 6: MonoMakerMS - TrueSpace Mid/Side Low-End Phase Punch
    {
        dsp171::MonoMakerMS mm;
        mm.prepare(sampleRate);
        mm.setParameters(150.0f, 1.0f); // 150 Hz mono cutoff

        // 1. Segnale a 60 Hz in pura controfase (L = +1, R = -1 => puro Side, zero Mid)
        float lowL = 1.0f, lowR = -1.0f;
        for (int i = 0; i < 500; ++i) {
            float s = std::sin(2.0f * dsp171::PI * 60.0f * static_cast<float>(i) / 48000.0f);
            float curL = s, curR = -s;
            mm.processSample(curL, curR);
            lowL = curL;
            lowR = curR;
        }
        // Il canale Side al di sotto di 150 Hz deve essere fortemente attenuato
        assert(std::abs(lowL) < 0.15f && std::abs(lowR) < 0.15f);

        // 2. Segnale a 60 Hz in fase (L = 1, R = 1 => puro Mid)
        mm.reset();
        float midL = 1.0f, midR = 1.0f;
        mm.processSample(midL, midR);
        // Il Mid deve passare inalterato al 100%
        assert(std::abs(midL - 1.0f) < 0.01f && std::abs(midR - 1.0f) < 0.01f);

        std::cout << "[TEST 06/09] MonoMakerMS: PASS (Sub-150Hz Side suppressed, Mid 100% preserved)" << std::endl;
        passed++;
    }

    // TEST 7: DecayRateEQ - Parametric Multi-Band RT60 Loop Coefficients
    {
        dsp171::DecayRateEQ eq;
        eq.prepare(sampleRate);
        eq.setBands(2.0f, 250.0f, 1.2f, 1500.0f, 1.0f, 0.5f, 6000.0f);

        // Valuta i moltiplicatori
        float multBass = eq.evaluateMultiplierAt(80.0f);
        float multMid = eq.evaluateMultiplierAt(1500.0f);
        float multHigh = eq.evaluateMultiplierAt(10000.0f);

        assert(multBass > 1.5f); // Bass Multiply attivo
        assert(multMid > 1.05f); // Mid Bell presente
        assert(multHigh < 0.75f); // High Damping attivo

        // Calcola guadagni FDN
        int delays[4] = { 1000, 2000, 3000, 4000 };
        float gains[4] = { 0.0f };
        eq.calculateGainVector(2.5f, delays, gains, 4, false);

        for (int i = 0; i < 4; ++i) {
            assert(gains[i] > 0.0f && gains[i] < 1.0f);
        }

        std::cout << "[TEST 07/09] DecayRateEQ: PASS (Bass mult: " << multBass << ", High damping: " << multHigh << ")" << std::endl;
        passed++;
    }

    // TEST 8: VintageColorUnit - 1970s, 1980s and NOW Converter Emulation
    {
        dsp171::VintageColorUnit color;
        color.prepare(sampleRate);

        // Test 1970s mode (12-bit decimation + 8.5 kHz analog reconstruction)
        color.setEra(dsp171::VintageEra::Era1970s, 3.0f);
        float outL = 0.0f, outR = 0.0f;
        for (int i = 0; i < 1000; ++i) {
            float in = std::sin(2.0f * dsp171::PI * 1000.0f * static_cast<float>(i) / 48000.0f);
            color.processSample(in, in, outL, outR);
            assert(isSafe(outL) && isSafe(outR));
        }

        // Test NOW mode (ultra clean 32-bit flat)
        color.setEra(dsp171::VintageEra::EraNOW, 0.0f);
        color.processSample(0.5f, -0.5f, outL, outR);
        assert(std::abs(outL - 0.5f) < 0.001f);
        assert(std::abs(outR - (-0.5f)) < 0.001f);

        std::cout << "[TEST 08/09] VintageColorUnit: PASS (1970s 12-bit decimation & NOW mode verified)" << std::endl;
        passed++;
    }

    // TEST 9: DSPHireManager - Orchestration of Enriched Spatial & Dynamics Tasks
    {
        auto d1 = dsp171::DSPHireManager::dispatchSpatialReverb();
        assert(d1.primaryAgent.agentId == "spatial-mastering-engineer");
        assert(d1.recommendedCPlusPlusClass.find("ReverbFDN16") != std::string_view::npos);

        auto d2 = dsp171::DSPHireManager::dispatchDynamicDucking();
        assert(d2.primaryAgent.agentId == "comp-optical-universal");
        assert(d2.recommendedCPlusPlusClass.find("SmartDuckingVCA") != std::string_view::npos);

        auto d3 = dsp171::DSPHireManager::dispatchVintageColor();
        assert(d3.primaryAgent.agentId == "sat-neve-specialist");
        assert(d3.recommendedCPlusPlusClass.find("VintageColorUnit") != std::string_view::npos);

        auto d4 = dsp171::DSPHireManager::dispatchMonoMaker();
        assert(d4.primaryAgent.agentId == "spatial-mastering-engineer");
        assert(d4.recommendedCPlusPlusClass.find("MonoMakerMS") != std::string_view::npos);

        std::cout << "[TEST 09/09] DSPHireManager: PASS (Dispatch tickets for 4 new architectural domains verified)" << std::endl;
        passed++;
    }

    std::cout << "==================================================================" << std::endl;
    std::cout << "   ALL " << passed << "/9 ENRICHED DSP ARCHITECTURE TESTS PASSED RIGOROUSLY! " << std::endl;
    std::cout << "==================================================================" << std::endl;
    return 0;
}
