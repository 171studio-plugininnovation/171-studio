@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
cd /d "%~dp0"
cl.exe /EHsc /std:c++20 /O2 /DDSP171_NO_JUCE_GUI=1 /I include tests\test_meter_metrology.cpp /Fe:tests\test_meter_metrology.exe
if %ERRORLEVEL% EQU 0 (
    echo.
    echo ==================== RUNNING TEST ====================
    tests\test_meter_metrology.exe
)
