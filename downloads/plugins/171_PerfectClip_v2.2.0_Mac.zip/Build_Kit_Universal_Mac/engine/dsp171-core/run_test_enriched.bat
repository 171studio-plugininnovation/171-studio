@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
cd /d "C:\Users\171Studio\Desktop\171 PLUGIN INNOVATIO GUI AND DSP\engine\dsp171-core"
cl.exe /EHsc /std:c++20 /O2 /I include tests\test_enriched_dsp_suite.cpp /Fe:tests\test_enriched_dsp_suite.exe
if %ERRORLEVEL% EQU 0 (
    echo.
    echo Running Enriched DSP Suite...
    tests\test_enriched_dsp_suite.exe
)
