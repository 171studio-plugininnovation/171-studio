@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
cd /d "C:\Users\171Studio\Desktop\171 dsp and gui engine\engine\dsp171-core"
cl.exe /EHsc /std:c++20 /O2 /I include tests\test_full_suite.cpp /Fe:tests\test_full_suite.exe
cl.exe /EHsc /std:c++20 /O2 /I include tests\test_hire_manager.cpp /Fe:tests\test_hire_manager.exe
cl.exe /EHsc /std:c++20 /O2 /I include tests\test_specialist_models.cpp /Fe:tests\test_specialist_models.exe
cl.exe /EHsc /std:c++20 /O2 /I include tests\test_all_43_modules_rigorous.cpp /Fe:tests\test_all_43_modules_rigorous.exe
cl.exe /EHsc /std:c++20 /O2 /I include tests\test_easy_voice.cpp /Fe:tests\test_easy_voice.exe
cl.exe /EHsc /std:c++20 /O2 /I include tests\test_easy_voice_pro.cpp /Fe:tests\test_easy_voice_pro.exe
if %ERRORLEVEL% EQU 0 (
    echo.
    echo ==============================================
    echo Running 171 DSP Complete Architecture Verification:
    echo ==============================================
    tests\test_full_suite.exe
    tests\test_hire_manager.exe
    tests\test_specialist_models.exe
    tests\test_all_43_modules_rigorous.exe
    tests\test_easy_voice.exe
    tests\test_easy_voice_pro.exe
)
