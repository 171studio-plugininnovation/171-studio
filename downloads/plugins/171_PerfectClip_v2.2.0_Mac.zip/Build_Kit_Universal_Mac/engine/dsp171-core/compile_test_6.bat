@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
cd /d "c:\Users\171Studio\Desktop\171 PLUGIN INNOVATIO GUI AND DSP\engine\dsp171-core"
cl.exe /EHsc /std:c++20 /O2 /I include tests\test_all_6_proposals.cpp /Fe:tests\test_all_6_proposals.exe
if %ERRORLEVEL% EQU 0 (
    echo.
    echo Running Verification Test:
    tests\test_all_6_proposals.exe
)
