# ==============================================================================
# 171 MUSIC INNOVATION - macOS Cross-Platform Master Configuration Module
# Universal Binary Fat Build: Apple Silicon (ARM64: M1/M2/M3/M4) & Intel (x86_64)
# ==============================================================================

if(171_MACOS_CROSSPLATFORM_CONFIG_INCLUDED)
    return()
endif()
set(171_MACOS_CROSSPLATFORM_CONFIG_INCLUDED TRUE)

message(STATUS "==================================================================")
message(STATUS " [171 Music Innovation] Initializing macOS Cross-Platform Engine  ")
message(STATUS "==================================================================")

# ------------------------------------------------------------------------------
# 1. macOS Universal Architectures (arm64 + x86_64) & Deployment Target (11.0+)
# ------------------------------------------------------------------------------
if(APPLE)
    # Target Universal Binary fat (Apple Silicon M1-M4 arm64 + Intel x86_64)
    if(NOT CMAKE_OSX_ARCHITECTURES)
        set(CMAKE_OSX_ARCHITECTURES "arm64;x86_64" CACHE STRING "Target macOS architectures (Universal Fat)" FORCE)
    endif()

    # macOS 11.0 (Big Sur) come baseline minima per supporto nativo M1/Apple Silicon
    if(NOT CMAKE_OSX_DEPLOYMENT_TARGET)
        set(CMAKE_OSX_DEPLOYMENT_TARGET "11.0" CACHE STRING "Minimum macOS deployment target" FORCE)
    endif()

    # Standard di sicurezza e bundle Apple: Hardened Runtime & Retina HiDPI
    set(CMAKE_XCODE_ATTRIBUTE_ENABLE_HARDENED_RUNTIME "YES" CACHE INTERNAL "Enable Hardened Runtime for Apple Gatekeeper")
    set(CMAKE_XCODE_ATTRIBUTE_COMBINE_HIDPI_IMAGES "YES" CACHE INTERNAL "Combine HiDPI Retina Images")
    set(CMAKE_XCODE_ATTRIBUTE_CLANG_ENABLE_OBJC_ARC "YES" CACHE INTERNAL "Enable ARC for Objective-C/Metal")

    # Formati target su macOS: VST3, AU (AudioUnit v2 per Logic Pro / GarageBand), Standalone
    set(171_PLUGIN_FORMATS VST3 AU Standalone CACHE STRING "Target Plugin Formats for macOS" FORCE)

    message(STATUS " [macOS Config] Target Architectures:      ${CMAKE_OSX_ARCHITECTURES}")
    message(STATUS " [macOS Config] Deployment Target (min):   macOS ${CMAKE_OSX_DEPLOYMENT_TARGET} (Big Sur)")
    message(STATUS " [macOS Config] Active Plugin Formats:     ${171_PLUGIN_FORMATS}")
    message(STATUS " [macOS Config] Security Hardened Runtime: ENABLED")
else()
    # Formati target su Windows / Linux
    set(171_PLUGIN_FORMATS VST3 Standalone CACHE STRING "Target Plugin Formats for Windows/Linux" FORCE)
endif()

# ------------------------------------------------------------------------------
# 2. Ottimizzazioni Compilatore Clang / Apple Clang (NEON SIMD, -O3, -ffast-math)
# ------------------------------------------------------------------------------
if(CMAKE_CXX_COMPILER_ID MATCHES "AppleClang" OR CMAKE_CXX_COMPILER_ID MATCHES "Clang")
    # Flag di compilazione ad alte prestazioni per calcolo vettoriale e isolamento simboli
    add_compile_options(
        -O3                             # Massima ottimizzazione del loop e inlining
        -ffast-math                     # Ottimizzazione floating-point e vettorizzazione FMA per DSP
        -fvisibility=hidden             # Isolamento simboli interni (essenziale per plugin audio in host DAW)
        -fvisibility-inlines-hidden     # Isolamento classi e funzioni inline C++
        -fvectorize                     # Vettorizzazione automatica SIMD (NEON su ARM64, SSE/AVX su x86_64)
    )

    if(APPLE)
        add_compile_definitions(
            JUCE_USE_VDSP_FRAMEWORK=1               # Sfrutta Apple Accelerate vDSP per convoluzione FFT e filtri
            JUCE_SILENCE_XCODE_15_LINKER_WARNING=1  # Sopprime warning duplicati nei linker moderni di Xcode 15+
            JUCE_COREGRAPHICS_DRAW_ASYNC=1          # Rendering grafico asincrono su display Liquid Retina HiDPI
            JUCE_DISPLAY_SPLIT_PEN_COLOR=1          # Sub-pixel rendering su display Retina
        )
    endif()
endif()

# ------------------------------------------------------------------------------
# 3. Funzione Helper di Configurazione Target: apply_171_macos_target_config
#    Configura framework nativi (Accelerate, CoreAudio, CoreMIDI, Metal)
#    e proprietà bundle AudioUnit / VST3
# ------------------------------------------------------------------------------
function(apply_171_macos_target_config TARGET_NAME)
    if(APPLE)
        # Link dei framework di sistema macOS richiesti per DSP, CoreAudio e Metal
        target_link_libraries(${TARGET_NAME} PRIVATE
            "-framework Accelerate"      # Apple Accelerate (vDSP, vForce, BLAS per FFT convoluzione e filtering NEON)
            "-framework CoreAudio"       # Gestione audio I/O a bassissima latenza nativa macOS
            "-framework CoreMIDI"        # Gestione MIDI nativa
            "-framework Metal"           # Accelerazione grafica GPU per GUI su Liquid Retina
            "-framework MetalKit"        # Texture e visualizzazioni grafiche Metal
            "-framework AudioToolbox"    # Servizi AudioUnit e hosting AUv2 per Logic Pro
            "-framework Cocoa"           # Finestre native e gestione eventi macOS
            "-framework QuartzCore"      # CoreAnimation e GPU buffer compositing
        )

        # Definizioni DSP e accelerazione hardware
        target_compile_definitions(${TARGET_NAME} PRIVATE
            JUCE_USE_VDSP_FRAMEWORK=1
            JUCE_SILENCE_XCODE_15_LINKER_WARNING=1
            JUCE_COREGRAPHICS_DRAW_ASYNC=1
        )

        # Flag Clang specifici del target
        target_compile_options(${TARGET_NAME} PRIVATE
            -O3
            -ffast-math
            -fvisibility=hidden
            -fvisibility-inlines-hidden
            -fvectorize
        )

        # Proprietà del bundle target e Hardened Runtime
        set_target_properties(${TARGET_NAME} PROPERTIES
            XCODE_ATTRIBUTE_ENABLE_HARDENED_RUNTIME "YES"
            XCODE_ATTRIBUTE_COMBINE_HIDPI_IMAGES "YES"
            XCODE_ATTRIBUTE_CLANG_ENABLE_OBJC_ARC "YES"
            XCODE_ATTRIBUTE_GCC_GENERATE_DEBUGGING_SYMBOLS "YES"
            XCODE_ATTRIBUTE_DEAD_CODE_STRIPPING "YES"
        )

        message(STATUS " [171 Module] Target '${TARGET_NAME}' configurato con successo per Apple Silicon & Intel (Universal Binary).")
    else()
        if(MSVC)
            target_compile_options(${TARGET_NAME} PRIVATE /fp:fast /MP)
        endif()
    endif()
endfunction()
