"""
=============================================================================
171Studio Boutique Hardware - Audio Plugin Knob Filmstrip Generator (make_knob.py)
=============================================================================
Takes a single transparent upright knob (knob_clean.png), rotates it across 
128 frames (-135 deg to +135 deg, 270 deg sweep), applies a FIXED STATIC 
drop shadow and ambient occlusion underneath (so the shadow does not unnaturally
rotate with the knob), and exports a ready-to-use vertical filmstrip for JUCE/HISE.
"""

import sys, os, math
from PIL import Image, ImageDraw, ImageFilter
import numpy as np

def generate_filmstrip(
    input_path, 
    output_path=None, 
    num_frames=128, 
    start_angle=-135.0, 
    end_angle=135.0,
    target_size=(128, 128),
    shadow_offset=(2, 4),
    shadow_blur=4,
    shadow_opacity=160
):
    if not os.path.exists(input_path):
        print(f"Error: file not found: {input_path}")
        return False
        
    if output_path is None:
        base, _ = os.path.splitext(input_path)
        output_path = f"{base}_filmstrip_{num_frames}frames_{target_size[0]}x{target_size[1]*num_frames}.png"

    # 1. Load clean knob
    knob = Image.open(input_path).convert('RGBA')
    # Resize to target frame size
    if knob.size != target_size:
        knob = knob.resize(target_size, Image.Resampling.LANCZOS)
        
    fw, fh = target_size
    cx, cy = fw / 2.0, fh / 2.0
    
    # Estimate knob radius from alpha channel
    alpha_arr = np.array(knob.split()[-1])
    y_idx, x_idx = np.where(alpha_arr > 30)
    if len(x_idx) > 0:
        r_est = (np.max(x_idx) - np.min(x_idx) + np.max(y_idx) - np.min(y_idx)) / 4.0
    else:
        r_est = fw * 0.42
        
    # 2. Build the FIXED STATIC drop shadow and ambient occlusion (renders ONCE)
    SS = 2
    sw_ss, sh_ss = fw * SS, fh * SS
    shadow_canvas = Image.new('RGBA', (sw_ss, sh_ss), (0, 0, 0, 0))
    s_draw = ImageDraw.Draw(shadow_canvas)
    
    scx = cx * SS + shadow_offset[0] * SS
    scy = cy * SS + shadow_offset[1] * SS
    s_rad = r_est * SS
    
    # Outer soft drop shadow (light from 105 deg -> shadow towards bottom-right)
    s_draw.ellipse([scx - s_rad, scy - s_rad, scx + s_rad, scy + s_rad], fill=(0, 0, 0, shadow_opacity))
    # Inner tight ambient occlusion (contact ring under base)
    s_draw.ellipse([cx * SS - r_est * SS, cy * SS - r_est * SS, cx * SS + r_est * SS, cy * SS + r_est * SS], fill=(0, 0, 0, int(shadow_opacity * 1.3)))
    
    shadow_canvas = shadow_canvas.filter(ImageFilter.GaussianBlur(shadow_blur * SS))
    static_shadow = shadow_canvas.resize(target_size, Image.Resampling.LANCZOS)
    
    # 3. Create vertical filmstrip canvas
    total_height = fh * num_frames
    filmstrip = Image.new('RGBA', (fw, total_height), (0, 0, 0, 0))
    
    print(f"Generating {num_frames}-frame filmstrip ({fw}x{total_height})...")
    
    for i in range(num_frames):
        norm = i / float(num_frames - 1)
        angle = start_angle + norm * (end_angle - start_angle)
        
        # In PIL, rotate is counter-clockwise, so pass -angle for clockwise sweep
        rotated_knob = knob.rotate(-angle, resample=Image.Resampling.BICUBIC)
        
        # Frame composition: Static Shadow (bottom) + Rotated Knob (top)
        frame = Image.new('RGBA', (fw, fh), (0, 0, 0, 0))
        frame.alpha_composite(static_shadow)
        frame.alpha_composite(rotated_knob)
        
        # Paste into filmstrip column
        filmstrip.paste(frame, (0, i * fh))
        
    filmstrip.save(output_path, 'PNG')
    print(f"Filmstrip generated successfully: {output_path}")
    return output_path

if __name__ == '__main__':
    if len(sys.argv) > 1:
        inp = sys.argv[1]
        outp = sys.argv[2] if len(sys.argv) > 2 else None
        generate_filmstrip(inp, outp)
    else:
        print("Usage: python make_knob.py <path_to_knob_clean.png> [optional_output_path.png]")
