# 171PluginInnovation – Audio Plugin Graphics Engine (APGE)
**Version:** 1.0.0 Architecture Specification  
**Design:** Hybrid Procedural GPU Vector + Filmstrip Sprite Blitter  
**Standards:** HiDPI / Retina (Windows Direct2D / macOS Metal / OpenGL 3.3+)

---

## 1. Architettura a Livelli (Layering System)

Un'interfaccia grafica per audio plugin a 60-144 FPS con consumo CPU $< 1\%$ deve essere strutturata in **3 livelli di rendering rigorosamente separati**:

```
+-------------------------------------------------------------------------+
| LIVELLO 3: CONTROLLI E INTERAZIONI MOUSE (Top Overlay)                  |
| - Manopole rotative (Knob Caps ruotati via AffineTransform)             |
| - Switch fisici a levetta / slider a 2 o più stati                      |
| - Tooltips, menu contestuali dei preset e popover numerici              |
+-------------------------------------------------------------------------+
                                   ^
                                   | (Disegnato sopra)
+-------------------------------------------------------------------------+
| LIVELLO 2: ELEMENTI DINAMICI GPU (Dynamic Waveform & Metering Layer)    |
| - Oscilloscopio CRT a persistenza fosforica                             |
| - Spettrogramma FFT a cascata (Hann Windowing, 60 FPS)                  |
| - Ago del VU Meter guidato da equazione differenziale IEC 60268-17      |
| - Barre LED Peak/RMS con degradazione balistica istantanea              |
| - Anelli al neon procedurali (Glow Gaussiano additivo)                  |
+-------------------------------------------------------------------------+
                                   ^
                                   | (Disegnato sopra)
+-------------------------------------------------------------------------+
| LIVELLO 1: BACKPLATE STATICO (Background Cache)                         |
| - Piastra in metallo spazzolato fotorealistica (1024x571, 1503x548...)  |
| - Loghi incisi, serigrafie, viti di montaggio rack e cornici display    |
| - Disegnato UNA SOLA VOLTA in bitmap offscreen / Texture VRAM           |
+-------------------------------------------------------------------------+
```

---

## 2. I Due Motori di Rendering Supportati

### Paradigma A: Procedurale Vettoriale con Texture Isolati (Stile 171CleanDrive & FabFilter)
* **Come funziona:** 
  1. Si usa una singola immagine PNG quadrata per la ghiera della manopola (es. `171Knob_Hardware_1.png`).
  2. Il motore ruota l'immagine al volo attorno al centro con `juce::AffineTransform::rotation(angle, cx, cy)`.
  3. L'anello di stato esterno e il bagliore luminoso (Glow) sono generati matematicamente tramite coordinate polari ed archi vettoriali:
     $$\text{Arco}(t) = \theta_{\text{start}} + t \cdot (\theta_{\text{end}} - \theta_{\text{start}})$$
* **Vantaggi:** Peso del plugin ridotto al minimo ($< 2\text{ MB}$), risoluzione infinita su monitor 4K/8K, animazione fluida a frame rate nativo (60/120/144 Hz).

### Paradigma B: Filmstrip / Sprite Sheet Blitter (Stile Analog Obsession & Soundtoys)
* **Come funziona:** 
  1. Si utilizza una striscia verticale ad altissima definizione contenente tutti i frame di rotazione pre-renderizzati in 3D (es. `Filmstrip_BritPre_61Frames_210x12810.png` con 61 frame).
  2. L'indice del frame da disegnare viene calcolato linearmente dal valore normalizzato del parametro $v \in [0.0, 1.0]$:
     $$\text{frameIndex} = \operatorname{clamp}\left( \operatorname{round}(v \cdot (N_{\text{frames}} - 1)), 0, N_{\text{frames}} - 1 \right)$$
  3. Il blitter ritaglia il rettangolo sorgente $Y = \text{frameIndex} \cdot H_{\text{frame}}$ e lo proietta sul display.
* **Vantaggi:** Fotorealismo 3D estremo, riflessi metallici e ombre raytraced calcolate offline.

---

## 3. Balistica dell'Ago VU Meter (IEC 60268-17)

Per evitare movimenti "finti" dell'ago, il motore calcola la fisica del galvanometro tramite integrazione numerica semi-implicita ad ogni frame $\Delta t$:

$$\Delta = \theta_{\text{target}} - \theta_{\text{ago}}$$
$$F_{\text{molla}} = \omega_n^2 \cdot \Delta$$
$$F_{\text{freno}} = 2 \zeta \omega_n \cdot v_{\text{ago}}$$
$$v_{\text{ago}} \leftarrow v_{\text{ago}} + (F_{\text{molla}} - F_{\text{freno}}) \cdot \Delta t$$
$$\theta_{\text{ago}} \leftarrow \theta_{\text{ago}} + v_{\text{ago}} \cdot \Delta t$$

* $\zeta = 0.707$ (Smorzamento critico che elimina le oscillazioni residue).
* $\omega_n = 11.5\text{ rad/s}$ ($300\text{ ms}$ per raggiungere il $99\%$ del fondo scala con overshooting limitato all'$1\%$).

---

## 4. Persistenza CRT dell'Oscilloscopio

Per simulare il fosforo verde o dorato di un monitor a raggi catodici vintage:
1. Ad ogni frame di disegno, lo schermo non viene azzerato con un nero puro (`clear()`).
2. Viene applicata una semitrasparenza nera additiva (Decay Pass):
   ```cpp
   g.fillAll(juce::Colour(0x28050608)); // alpha ~15% nero per dissolvenza continua
   ```
3. La nuova forma d'onda viene tracciata con gradiente dorato/verde brillante e linea spessa a 2 passaggi (anima centrale bianca da 1.5px e bagliore esterno colorato da 4px).
