import os
import cv2
import numpy as np
from PIL import Image
import rembg

def extract_all():
    img_up_path = 'C:/Users/171Studio/.gemini/antigravity/brain/2f4a0ca7-5fa7-47eb-9a6a-f713f410d3de/.user_uploaded/media_1792525968241_9f708000.jpg'
    img_down_path = 'C:/Users/171Studio/.gemini/antigravity/brain/2f4a0ca7-5fa7-47eb-9a6a-f713f410d3de/.user_uploaded/media_1792525989780_dd370158.jpg'

    img_up = cv2.imread(img_up_path)
    img_down = cv2.imread(img_down_path)

    sw_dir = 'C:/Users/171Studio/.gemini/antigravity/scratch/Plugin_Assets_Hub/Switches'
    face_dir = 'C:/Users/171Studio/.gemini/antigravity/scratch/Plugin_Assets_Hub/Faceplates'
    screws_dir = 'C:/Users/171Studio/.gemini/antigravity/scratch/Plugin_Assets_Hub/Screws_and_Hardware'

    os.makedirs(sw_dir, exist_ok=True)
    os.makedirs(face_dir, exist_ok=True)
    os.makedirs(screws_dir, exist_ok=True)

    # Exact centers of the 4 switches:
    switches = [
        ('SW1', 196, 286),
        ('SW2', 406, 286),
        ('SW3', 616, 286),
        ('SW4', 824, 285)
    ]

    crop_sz = 220
    half = crop_sz // 2

    # Initialize a single rembg session to reuse weights and maximize speed
    session = rembg.new_session('bria-rmbg')

    # 1. Extract UP and DOWN for each switch
    for name, cx, cy in switches:
        # State UP (ON)
        crop_up = img_up[cy-half:cy+half, cx-half:cx+half]
        rgb_up = cv2.cvtColor(crop_up, cv2.COLOR_BGR2RGB)
        pil_up = Image.fromarray(rgb_up)
        out_up = rembg.remove(pil_up, session=session)
        
        fn_up = f'Switch_Toggle_BoutiqueBrass_ChromeBaton_{name}_UP_ON_220x220.png'
        out_up.save(os.path.join(sw_dir, fn_up))
        print(f'Extracted: {fn_up}, bbox: {out_up.getbbox()}')

        # State DOWN (OFF)
        crop_down = img_down[cy-half:cy+half, cx-half:cx+half]
        rgb_down = cv2.cvtColor(crop_down, cv2.COLOR_BGR2RGB)
        pil_down = Image.fromarray(rgb_down)
        out_down = rembg.remove(pil_down, session=session)
        
        fn_down = f'Switch_Toggle_BoutiqueBrass_ChromeBaton_{name}_DOWN_OFF_220x220.png'
        out_down.save(os.path.join(sw_dir, fn_down))
        print(f'Extracted: {fn_down}, bbox: {out_down.getbbox()}')

    # 2. Pick SW2 (near center, neutral lighting) as the MASTER canonical asset
    im_master_up = Image.open(os.path.join(sw_dir, 'Switch_Toggle_BoutiqueBrass_ChromeBaton_SW2_UP_ON_220x220.png'))
    im_master_down = Image.open(os.path.join(sw_dir, 'Switch_Toggle_BoutiqueBrass_ChromeBaton_SW2_DOWN_OFF_220x220.png'))

    # Save as canonical master replacements
    im_master_up.save(os.path.join(sw_dir, 'Switch_Toggle_HeavyDuty_ChromeBaton_UP_Master.png'))
    im_master_down.save(os.path.join(sw_dir, 'Switch_Toggle_HeavyDuty_ChromeBaton_DOWN_Master.png'))

    # Also downsampled 80x140 / 128x128 versions for standard UI slots
    res_up_128 = im_master_up.resize((128, 128), Image.Resampling.LANCZOS)
    res_down_128 = im_master_down.resize((128, 128), Image.Resampling.LANCZOS)
    res_up_128.save(os.path.join(sw_dir, 'Switch_Toggle_HeavyDuty_ChromeBaton_UP_128x128.png'))
    res_down_128.save(os.path.join(sw_dir, 'Switch_Toggle_HeavyDuty_ChromeBaton_DOWN_128x128.png'))

    # Overwrite the old approximate switch files
    old_up_path = os.path.join(sw_dir, 'Switch_Toggle_HeavyDuty_ChromeBaton_UP_80x140.png')
    old_down_path = os.path.join(sw_dir, 'Switch_Toggle_HeavyDuty_ChromeBaton_DOWN_80x140.png')
    im_master_up.resize((80, 140), Image.Resampling.LANCZOS).save(old_up_path)
    im_master_down.resize((80, 140), Image.Resampling.LANCZOS).save(old_down_path)

    print('Updated master and standard size switch replacements.')

    # 3. Extract the 4 Corner Phillips Screws (TL, TR, BL, BR)
    screws = [
        ('Screw_Phillips_BoutiqueCorner_TL', 57, 43),
        ('Screw_Phillips_BoutiqueCorner_TR', 944, 43),
        ('Screw_Phillips_BoutiqueCorner_BL', 57, 528),
        ('Screw_Phillips_BoutiqueCorner_BR', 944, 528)
    ]
    for sname, scx, scy in screws:
        s_crop = img_up[scy-32:scy+32, scx-32:scx+32]
        s_pil = Image.fromarray(cv2.cvtColor(s_crop, cv2.COLOR_BGR2RGB))
        s_out = rembg.remove(s_pil, session=session)
        s_fn = f'{sname}_64x64.png'
        s_out.save(os.path.join(screws_dir, s_fn))
        print(f'Extracted: {s_fn}')

    # 4. Clean Master Boutique Plate (Inpainting the 4 switches)
    plate = img_up.copy()
    inpaint_mask = np.zeros((plate.shape[0], plate.shape[1]), np.uint8)
    for name, cx, cy in switches:
        cv2.circle(inpaint_mask, (cx, cy), 78, 255, -1)
    
    clean_plate = cv2.inpaint(plate, inpaint_mask, 15, cv2.INPAINT_TELEA)
    clean_plate_fn = 'Faceplate_Boutique_AnisotropicBrass_4WayToggle_Clean_1024x571.png'
    cv2.imwrite(os.path.join(face_dir, clean_plate_fn), clean_plate)
    print(f'Generated clean boutique faceplate: {clean_plate_fn}')

    print('ALL SWITCHES, SCREWS, AND FACEPLATE ASSETS PROCESSED SUCCESSFULLY!')

if __name__ == '__main__':
    extract_all()
