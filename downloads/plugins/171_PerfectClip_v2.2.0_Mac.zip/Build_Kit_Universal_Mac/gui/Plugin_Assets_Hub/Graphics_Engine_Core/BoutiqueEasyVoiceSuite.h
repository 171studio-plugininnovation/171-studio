#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_graphics/juce_graphics.h>
#include <cmath>
#include <algorithm>

namespace gui171
{
    // ==============================================================================
    // 171 EASYVOICE DESIGN PALETTE & TOKENS
    // ==============================================================================
    namespace Palette
    {
        inline const juce::Colour obsidianTop       { 0xff121316 };
        inline const juce::Colour obsidianBottom    { 0xff1a1c22 };
        inline const juce::Colour obsidianDark      { 0xff0b0d10 };
        inline const juce::Colour obsidianPill      { 0xff101217 };
        inline const juce::Colour sectionBg         { 0xff13151b };
        inline const juce::Colour sectionBorder     { 0xff282b35 };
        
        inline const juce::Colour satinGold         { 0xffd4af37 };
        inline const juce::Colour champagneGold     { 0xffc5a059 };
        inline const juce::Colour brightGold        { 0xffffe082 };
        inline const juce::Colour deepBronze        { 0xff8c7042 };
        
        inline const juce::Colour ledAmberLit       { 0xffffa31a };
        inline const juce::Colour ledAmberDim       { 0x353a220b };
        inline const juce::Colour ledGreenLit       { 0xff22c55e };
        inline const juce::Colour ledGreenDim       { 0x30083315 };
        inline const juce::Colour ledRedLit         { 0xffef4444 };
        inline const juce::Colour ledRedDim         { 0x353d0909 };
        
        inline const juce::Colour textBright        { 0xfff1f5f9 };
        inline const juce::Colour textMuted         { 0xff94a3b8 };
        inline const juce::Colour textGold          { 0xffe6c67a };
    }

    // ==============================================================================
    // 1. BOUTIQUE PANEL RENDERER (Obsidian Brushed Metal, Screws, Bezel & Headers)
    // ==============================================================================
    class BoutiquePanelRenderer
    {
    public:
        static void drawObsidianPanel(juce::Graphics& g, juce::Rectangle<float> bounds)
        {
            // 1. Sfondo metallo ossidiana a gradiente verticale
            juce::ColourGradient grad(Palette::obsidianTop, 0.0f, bounds.getY(),
                                      Palette::obsidianBottom, 0.0f, bounds.getBottom(), false);
            g.setGradientFill(grad);
            g.fillRect(bounds);

            // 2. Micro-spazzolatura orizzontale metallica satinata (zero allocazioni heap)
            const int topInt = juce::roundToInt(bounds.getY());
            const int botInt = juce::roundToInt(bounds.getBottom());
            const float leftX = bounds.getX() + 6.0f;
            const float rightX = bounds.getRight() - 6.0f;

            for (int y = topInt; y < botInt; y += 3)
            {
                const uint8_t alpha = ((y % 6) == 0) ? 0x07 : 0x03;
                g.setColour(juce::Colour(0x00ffffff | (alpha << 24)));
                g.drawHorizontalLine(y, leftX, rightX);
            }

            // 3. Cornice perimetrale bisellata a 45° con bordo in oro satinato cesellato
            auto fBounds = bounds.reduced(5.0f);
            constexpr float chamfer = 10.0f;

            juce::Path bezelPath;
            bezelPath.startNewSubPath(fBounds.getX() + chamfer, fBounds.getY());
            bezelPath.lineTo(fBounds.getRight() - chamfer, fBounds.getY());
            bezelPath.lineTo(fBounds.getRight(), fBounds.getY() + chamfer);
            bezelPath.lineTo(fBounds.getRight(), fBounds.getBottom() - chamfer);
            bezelPath.lineTo(fBounds.getRight() - chamfer, fBounds.getBottom());
            bezelPath.lineTo(fBounds.getX() + chamfer, fBounds.getBottom());
            bezelPath.lineTo(fBounds.getX(), fBounds.getBottom() - chamfer);
            bezelPath.lineTo(fBounds.getX(), fBounds.getY() + chamfer);
            bezelPath.closeSubPath();

            // Ombra interna scanalata
            g.setColour(juce::Colours::black.withAlpha(0.60f));
            g.strokePath(bezelPath, juce::PathStrokeType(2.5f));

            // Bordo cesellato oro satinato con gradiente luminoso da ore 11 a ore 5
            juce::ColourGradient goldBorder(Palette::brightGold.withAlpha(0.85f), fBounds.getX(), fBounds.getY(),
                                            Palette::champagneGold.withAlpha(0.50f), fBounds.getRight(), fBounds.getBottom(), false);
            g.setGradientFill(goldBorder);
            g.strokePath(bezelPath, juce::PathStrokeType(1.2f));

            // Linea hairline interna di rifinitura
            g.setColour(juce::Colour(0x20ffffff));
            g.drawRect(fBounds.reduced(2.0f), 0.6f);
        }

        static void drawKnurledScrew(juce::Graphics& g, float cx, float cy, float radius = 7.5f, float angleDeg = 45.0f)
        {
            // Drop shadow d'appoggio verso ore 5
            g.setColour(juce::Colours::black.withAlpha(0.65f));
            g.fillEllipse(cx - radius + 1.2f, cy - radius + 2.0f, radius * 2.0f, radius * 2.0f);

            // Ghiera metallica esterna scura fresata
            juce::ColourGradient ringGrad(juce::Colour(0xff333742), cx - radius, cy - radius,
                                         juce::Colour(0xff121316), cx + radius, cy + radius, false);
            g.setGradientFill(ringGrad);
            g.fillEllipse(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f);

            // Bordo metallico scanalato
            g.setColour(juce::Colour(0xff525a6c));
            g.drawEllipse(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f, 0.8f);

            // Testa della vite in ottone/bronzo tornito
            const float capR = radius * 0.72f;
            juce::ColourGradient brassHead(Palette::champagneGold.brighter(0.2f), cx - capR, cy - capR,
                                          Palette::deepBronze.darker(0.3f), cx + capR, cy + capR, false);
            g.setGradientFill(brassHead);
            g.fillEllipse(cx - capR, cy - capR, capR * 2.0f, capR * 2.0f);

            // Highlight superiore
            g.setColour(Palette::brightGold.withAlpha(0.50f));
            g.drawEllipse(cx - capR, cy - capR, capR * 2.0f, capR * 2.0f, 0.6f);

            // Taglio della vite a taglio / Phillips con angolo realistico
            const float rad = juce::degreesToRadians(angleDeg);
            const float slotLen = capR * 0.75f;
            const float cosA = std::cos(rad);
            const float sinA = std::sin(rad);

            // Ombra del taglio
            g.setColour(juce::Colour(0xff090a0d));
            g.drawLine(cx - cosA * slotLen, cy - sinA * slotLen,
                       cx + cosA * slotLen, cy + sinA * slotLen, 1.6f);

            // Highlight luminoso sul bordo della fresatura
            g.setColour(Palette::brightGold.withAlpha(0.60f));
            g.drawLine(cx - cosA * slotLen + 0.5f, cy - sinA * slotLen + 0.5f,
                       cx + cosA * slotLen + 0.5f, cy + sinA * slotLen + 0.5f, 0.6f);
        }

        static void drawSectionBox(juce::Graphics& g, juce::Rectangle<float> bounds,
                                   const juce::String& title, const juce::String& italianSubtitle = {})
        {
            // Pannello incassato in metallo scuro
            g.setColour(Palette::sectionBg);
            g.fillRoundedRectangle(bounds, 5.0f);

            // Bordo cesellato con micro-riflesso
            g.setColour(Palette::sectionBorder);
            g.drawRoundedRectangle(bounds, 5.0f, 1.2f);

            // Filetto d'oro satinato in testa alla sezione
            g.setColour(Palette::champagneGold.withAlpha(0.35f));
            g.drawHorizontalLine(juce::roundToInt(bounds.getY() + 24.0f), bounds.getX() + 8.0f, bounds.getRight() - 8.0f);

            // Titolo in maiuscolo cesellato oro
            g.setFont(juce::FontOptions(10.5f, juce::Font::bold));
            g.setColour(Palette::satinGold);
            g.drawText(title, static_cast<int>(bounds.getX() + 12.0f), static_cast<int>(bounds.getY() + 5.0f),
                       static_cast<int>(bounds.getWidth() - 24.0f), 16, juce::Justification::centredLeft, false);

            if (italianSubtitle.isNotEmpty())
            {
                g.setFont(juce::FontOptions(8.5f, juce::Font::plain));
                g.setColour(Palette::textMuted);
                g.drawText(italianSubtitle, static_cast<int>(bounds.getX() + 12.0f), static_cast<int>(bounds.getY() + 6.0f),
                           static_cast<int>(bounds.getWidth() - 24.0f), 15, juce::Justification::centredRight, false);
            }
        }

        static void drawHeader(juce::Graphics& g, juce::Rectangle<float> bounds,
                               const juce::Image& badge, const juce::Image& emblem,
                               const juce::String& title, const juce::String& subtitle)
        {
            const float h = bounds.getHeight();

            // 1. Badge Oro Satinato Ufficiale a sinistra
            if (badge.isValid())
            {
                const float badgeAspect = static_cast<float>(badge.getWidth()) / static_cast<float>(badge.getHeight());
                const float badgeH = h * 0.76f;
                const float badgeW = badgeH * badgeAspect;
                g.drawImage(badge, juce::Rectangle<float>(bounds.getX() + 18.0f, bounds.getY() + (h - badgeH) * 0.5f,
                                                          badgeW, badgeH));
            }

            // 2. Emblema Oro Satinato a destra
            if (emblem.isValid())
            {
                const float embSize = h * 0.80f;
                g.drawImage(emblem, juce::Rectangle<float>(bounds.getRight() - embSize - 18.0f, bounds.getY() + (h - embSize) * 0.5f,
                                                           embSize, embSize));
            }

            // 3. Typography Centrale / Allineata
            const float textX = bounds.getX() + (badge.isValid() ? 160.0f : 24.0f);
            const float textW = bounds.getWidth() - textX - (emblem.isValid() ? 70.0f : 24.0f);

            // Titolo Principale
            g.setFont(juce::FontOptions(20.0f, juce::Font::bold));
            g.setColour(Palette::textBright);
            g.drawText(title, static_cast<int>(textX), static_cast<int>(bounds.getY() + 5.0f),
                       static_cast<int>(textW), 22, juce::Justification::centredLeft, false);

            // Sottotitolo Boutique & Provenienza Artigianale Firenze / Milano
            g.setFont(juce::FontOptions(9.5f, juce::Font::bold));
            g.setColour(Palette::champagneGold);
            juce::String subText = subtitle;
            if (!subText.contains("FIRENZE / MILANO"))
                subText += "  |  171 STUDIO INNOVATIO  •  FIRENZE / MILANO";
            g.drawText(subText, static_cast<int>(textX), static_cast<int>(bounds.getY() + 27.0f),
                       static_cast<int>(textW), 14, juce::Justification::centredLeft, false);
        }
    };

    // ==============================================================================
    // 2. STUDIO171 COMBOBOX LOOK AND FEEL (Dark Obsidian + Gold Chevron)
    // ==============================================================================
    class Studio171ComboBoxLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        Studio171ComboBoxLookAndFeel()
        {
            setColour(juce::ComboBox::backgroundColourId, Palette::obsidianPill);
            setColour(juce::ComboBox::textColourId, Palette::textBright);
            setColour(juce::ComboBox::outlineColourId, Palette::champagneGold);
            setColour(juce::ComboBox::arrowColourId, Palette::satinGold);

            setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xf8101217));
            setColour(juce::PopupMenu::textColourId, Palette::textBright);
            setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xff2d2417));
            setColour(juce::PopupMenu::highlightedTextColourId, Palette::brightGold);
        }

        void drawComboBox(juce::Graphics& g, int width, int height, bool isButtonDown,
                          int buttonX, int buttonY, int buttonW, int buttonH, juce::ComboBox& box) override
        {
            juce::ignoreUnused(isButtonDown);
            auto bounds = juce::Rectangle<float>(0.0f, 0.0f, static_cast<float>(width), static_cast<float>(height)).reduced(1.0f);

            // Ombra incassata
            g.setColour(juce::Colours::black.withAlpha(0.50f));
            g.fillRoundedRectangle(bounds.translated(1.0f, 1.5f), 4.0f);

            // Metallo spazzolato scuro
            juce::ColourGradient grad(juce::Colour(0xff20242e), bounds.getX(), bounds.getY(),
                                      Palette::obsidianPill, bounds.getX(), bounds.getBottom(), false);
            g.setGradientFill(grad);
            g.fillRoundedRectangle(bounds, 4.0f);

            // Bordo cesellato in oro satinato
            g.setColour(box.hasKeyboardFocus(true) ? Palette::brightGold : Palette::champagneGold);
            g.drawRoundedRectangle(bounds, 4.0f, 1.2f);

            // Chevron dorato cesellato
            const float arrowCx = static_cast<float>(buttonX) + static_cast<float>(buttonW) * 0.5f;
            const float arrowCy = static_cast<float>(buttonY) + static_cast<float>(buttonH) * 0.5f;
            constexpr float arrowW = 6.5f;
            constexpr float arrowH = 4.0f;

            juce::Path arrow;
            arrow.startNewSubPath(arrowCx - arrowW * 0.5f, arrowCy - arrowH * 0.5f);
            arrow.lineTo(arrowCx, arrowCy + arrowH * 0.5f);
            arrow.lineTo(arrowCx + arrowW * 0.5f, arrowCy - arrowH * 0.5f);

            g.setColour(Palette::satinGold);
            g.strokePath(arrow, juce::PathStrokeType(1.6f, juce::PathStrokeType::mitered, juce::PathStrokeType::rounded));
        }

        juce::Font getComboBoxFont(juce::ComboBox&) override
        {
            return juce::FontOptions(10.5f, juce::Font::bold);
        }

        void positionComboBoxText(juce::ComboBox& box, juce::Label& label) override
        {
            label.setBounds(6, 1, box.getWidth() - 22, box.getHeight() - 2);
            label.setFont(getComboBoxFont(box));
        }
    };

    // ==============================================================================
    // 3. BOUTIQUE CONSOLE BUTTON LOOK AND FEEL (Amber / Gold LED Indicator)
    // ==============================================================================
    class BoutiqueConsoleButtonLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        BoutiqueConsoleButtonLookAndFeel(juce::Colour ledActiveCol = Palette::ledAmberLit)
            : activeLedColour(ledActiveCol)
        {
        }

        void setLedColour(juce::Colour col) { activeLedColour = col; }

        void drawButtonBackground(juce::Graphics& g, juce::Button& button,
                                  const juce::Colour& backgroundColour,
                                  bool shouldDrawButtonAsHighlighted,
                                  bool shouldDrawButtonAsDown) override
        {
            juce::ignoreUnused(backgroundColour);
            auto bounds = button.getLocalBounds().toFloat().reduced(1.0f);
            const bool isToggled = button.getToggleState();

            // Ombra di fondo
            g.setColour(juce::Colours::black.withAlpha(0.55f));
            g.fillRoundedRectangle(bounds.translated(1.0f, 1.5f), 4.0f);

            // Corpo del pulsante in metallo brunito
            juce::Colour topCol = isToggled ? juce::Colour(0xff2b2014) : (shouldDrawButtonAsHighlighted ? juce::Colour(0xff292d37) : juce::Colour(0xff1c1e25));
            juce::Colour botCol = isToggled ? juce::Colour(0xff18120c) : juce::Colour(0xff101115);

            if (shouldDrawButtonAsDown)
                std::swap(topCol, botCol);

            juce::ColourGradient grad(topCol, bounds.getX(), bounds.getY(),
                                      botCol, bounds.getX(), bounds.getBottom(), false);
            g.setGradientFill(grad);
            g.fillRoundedRectangle(bounds, 4.0f);

            // Bordo cesellato oro satinato
            juce::Colour borderCol = isToggled ? Palette::brightGold : (shouldDrawButtonAsHighlighted ? Palette::champagneGold : Palette::deepBronze.withAlpha(0.7f));
            g.setColour(borderCol);
            g.drawRoundedRectangle(bounds, 4.0f, 1.2f);

            // Spia LED (pallino o barra luminosa) sul lato sinistro del pulsante
            const float ledSize = 6.0f;
            const float ledX = bounds.getX() + 7.0f;
            const float ledY = bounds.getCentreY() - ledSize * 0.5f;

            // Alloggiamento LED incassato
            g.setColour(juce::Colour(0xff08090b));
            g.fillEllipse(ledX - 1.0f, ledY - 1.0f, ledSize + 2.0f, ledSize + 2.0f);

            if (isToggled)
            {
                // Bagliore diffuso
                g.setColour(activeLedColour.withAlpha(0.35f));
                g.fillEllipse(ledX - 3.0f, ledY - 3.0f, ledSize + 6.0f, ledSize + 6.0f);

                // LED acceso
                g.setColour(activeLedColour);
                g.fillEllipse(ledX, ledY, ledSize, ledSize);

                // Nucleo incandescente
                g.setColour(juce::Colours::white.withAlpha(0.85f));
                g.fillEllipse(ledX + 1.5f, ledY + 1.5f, ledSize - 3.0f, ledSize - 3.0f);
            }
            else
            {
                // LED spento (fumo semitrasparente)
                g.setColour(Palette::ledAmberDim);
                g.fillEllipse(ledX, ledY, ledSize, ledSize);
                g.setColour(juce::Colour(0x30ffffff));
                g.drawEllipse(ledX, ledY, ledSize, ledSize, 0.6f);
            }
        }

        void drawButtonText(juce::Graphics& g, juce::TextButton& button,
                            bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override
        {
            juce::ignoreUnused(shouldDrawButtonAsDown);
            auto bounds = button.getLocalBounds();
            // Spazio per il LED a sinistra
            bounds.removeFromLeft(16);

            const bool isToggled = button.getToggleState();
            juce::Colour textCol = isToggled ? Palette::brightGold : (shouldDrawButtonAsHighlighted ? Palette::textBright : Palette::textMuted);

            g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
            g.setColour(textCol);
            g.drawFittedText(button.getButtonText(), bounds, juce::Justification::centred, 1);
        }

    private:
        juce::Colour activeLedColour;
    };

    // ==============================================================================
    // 4. BOUTIQUE EASYVOICE ROTARY KNOB LOOK AND FEEL
    // Machined dual-ring aluminum, champagne brass center cap, tick arc, sharp needle
    // ==============================================================================
    class BoutiqueEasyVoiceKnobLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        BoutiqueEasyVoiceKnobLookAndFeel(juce::Colour needleCol = Palette::brightGold,
                                         juce::Colour arcAccent = Palette::satinGold)
            : needleColour(needleCol), arcColour(arcAccent)
        {
        }

        void setNeedleColour(juce::Colour col) { needleColour = col; }
        void setArcColour(juce::Colour col)    { arcColour = col; }

        void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                              float sliderPosProportional, float rotaryStartAngle,
                              float rotaryEndAngle, juce::Slider& slider) override
        {
            const float size = static_cast<float>(juce::jmin(width, height));
            const float centreX = static_cast<float>(x) + static_cast<float>(width) * 0.5f;
            // Spostamento leggero verso l'alto se è visibile la pillola del valore sotto
            const bool hasTextBox = (slider.getTextBoxPosition() != juce::Slider::NoTextBox);
            const float centreY = static_cast<float>(y) + (hasTextBox ? (size * 0.44f) : (static_cast<float>(height) * 0.5f));

            const float currentAngle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);
            const float maxRadius = size * 0.47f;
            const float arcRadius = maxRadius - 2.0f;
            const float knobRadius = maxRadius * 0.72f;
            const float brassCapRadius = knobRadius * 0.62f;

            // ----------------------------------------------------------------------
            // 1. QUADRANTE CALIBRATO CON TACCHE GRADUATE (Outer Graduated Tick Arc)
            // ----------------------------------------------------------------------
            constexpr int numTicks = 15;
            for (int i = 0; i < numTicks; ++i)
            {
                const float normT = static_cast<float>(i) / static_cast<float>(numTicks - 1);
                const float tickAngle = rotaryStartAngle + normT * (rotaryEndAngle - rotaryStartAngle);
                const bool isMajor = (i == 0 || i == (numTicks - 1) / 2 || i == (numTicks - 1));

                const float rInner = isMajor ? (arcRadius - 3.5f) : (arcRadius - 1.5f);
                const float rOuter = isMajor ? (arcRadius + 3.5f) : (arcRadius + 1.5f);

                const float sinA = std::sin(tickAngle);
                const float cosA = std::cos(tickAngle);

                const float x1 = centreX + rInner * sinA;
                const float y1 = centreY - rInner * cosA;
                const float x2 = centreX + rOuter * sinA;
                const float y2 = centreY - rOuter * cosA;

                juce::Colour tickCol = isMajor ? Palette::satinGold : Palette::deepBronze.withAlpha(0.70f);
                g.setColour(tickCol);
                g.drawLine(x1, y1, x2, y2, isMajor ? 1.5f : 0.9f);
            }

            // Traccia circolare scura incassata nel pannello
            g.setColour(juce::Colour(0x500a0c10));
            g.drawEllipse(centreX - arcRadius, centreY - arcRadius, arcRadius * 2.0f, arcRadius * 2.0f, 2.5f);

            // Arco luminoso attivo in oro satinato / colore d'accento
            if (sliderPosProportional > 0.01f)
            {
                juce::Path activeArc;
                activeArc.addCentredArc(centreX, centreY, arcRadius, arcRadius, 0.0f,
                                        rotaryStartAngle, currentAngle, true);

                // Bagliore soft
                g.setColour(arcColour.withAlpha(0.25f));
                g.strokePath(activeArc, juce::PathStrokeType(6.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

                // Tubo luminoso saturo
                g.setColour(arcColour);
                g.strokePath(activeArc, juce::PathStrokeType(2.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            }

            // ----------------------------------------------------------------------
            // 2. CORPO MANOPOLA IN ALLUMINIO TORNITO CONICO (Machined Aluminum Dual Ring)
            // ----------------------------------------------------------------------
            // Drop shadow a ore 5
            g.setColour(juce::Colours::black.withAlpha(0.68f));
            g.fillEllipse(centreX - knobRadius + 1.5f, centreY - knobRadius + 2.8f,
                          knobRadius * 2.0f, knobRadius * 2.0f);

            // Anello esterno in alluminio spazzolato (gradiente radiale dal metallo canna di fucile allo scuro)
            juce::ColourGradient bodyGrad(juce::Colour(0xff353942), centreX - knobRadius * 0.4f, centreY - knobRadius * 0.4f,
                                         juce::Colour(0xff121316), centreX + knobRadius, centreY + knobRadius, true);
            g.setGradientFill(bodyGrad);
            g.fillEllipse(centreX - knobRadius, centreY - knobRadius, knobRadius * 2.0f, knobRadius * 2.0f);

            // Micro-scanalatura concentrica fresata per effetto grip zigrinato
            g.setColour(juce::Colour(0xff555c6e).withAlpha(0.6f));
            g.drawEllipse(centreX - knobRadius, centreY - knobRadius, knobRadius * 2.0f, knobRadius * 2.0f, 1.0f);
            g.setColour(juce::Colour(0xff101114));
            g.drawEllipse(centreX - knobRadius + 2.0f, centreY - knobRadius + 2.0f,
                          (knobRadius - 2.0f) * 2.0f, (knobRadius - 2.0f) * 2.0f, 1.2f);

            // ----------------------------------------------------------------------
            // 3. CAPPUCCIO CENTRALE IN OTTONE SATINATO CHAMPAGNE (Champagne Gold Cap)
            // ----------------------------------------------------------------------
            // Scanalatura nera incassata sotto la cupola
            g.setColour(juce::Colour(0xff09090b));
            g.fillEllipse(centreX - brassCapRadius - 1.0f, centreY - brassCapRadius - 1.0f,
                          (brassCapRadius + 1.0f) * 2.0f, (brassCapRadius + 1.0f) * 2.0f);

            // Cupola d'ottone satinato con riflesso champagne a ore 11
            juce::ColourGradient brassGrad(Palette::brightGold, centreX - brassCapRadius * 0.6f, centreY - brassCapRadius * 0.6f,
                                          Palette::deepBronze.darker(0.2f), centreX + brassCapRadius, centreY + brassCapRadius, false);
            g.setGradientFill(brassGrad);
            g.fillEllipse(centreX - brassCapRadius, centreY - brassCapRadius,
                          brassCapRadius * 2.0f, brassCapRadius * 2.0f);

            // Bordo luce cesellato
            g.setColour(Palette::brightGold.withAlpha(0.70f));
            g.drawEllipse(centreX - brassCapRadius, centreY - brassCapRadius,
                          brassCapRadius * 2.0f, brassCapRadius * 2.0f, 0.8f);

            // Bottone centrale micro-incassato
            const float microCapR = brassCapRadius * 0.35f;
            juce::ColourGradient microGrad(Palette::deepBronze, centreX, centreY,
                                          Palette::satinGold, centreX + microCapR, centreY + microCapR, true);
            g.setGradientFill(microGrad);
            g.fillEllipse(centreX - microCapR, centreY - microCapR, microCapR * 2.0f, microCapR * 2.0f);

            // ----------------------------------------------------------------------
            // 4. INDICATORE AD AGO AFFILATO (Sharp Needle Pointer)
            // ----------------------------------------------------------------------
            const float needleInnerR = brassCapRadius * 0.45f;
            const float needleOuterR = knobRadius - 1.5f;
            const float sinAng = std::sin(currentAngle);
            const float cosAng = std::cos(currentAngle);

            const float nx1 = centreX + needleInnerR * sinAng;
            const float ny1 = centreY - needleInnerR * cosAng;
            const float nx2 = centreX + needleOuterR * sinAng;
            const float ny2 = centreY - needleOuterR * cosAng;

            // Ombra dell'ago
            g.setColour(juce::Colours::black.withAlpha(0.6f));
            g.drawLine(nx1 + 0.8f, ny1 + 1.2f, nx2 + 0.8f, ny2 + 1.2f, 2.2f);

            // Ago affilato satin gold / accent
            g.setColour(needleColour);
            g.drawLine(nx1, ny1, nx2, ny2, 2.0f);

            // Punta dell'ago incandescente
            g.setColour(juce::Colours::white);
            g.drawEllipse(nx2 - 1.2f, ny2 - 1.2f, 2.4f, 2.4f, 0.8f);
        }

        juce::Slider::SliderLayout getSliderLayout(juce::Slider& slider) override
        {
            auto layout = juce::LookAndFeel_V4::getSliderLayout(slider);
            if (slider.getTextBoxPosition() != juce::Slider::NoTextBox)
            {
                const int w = slider.getWidth();
                const int h = slider.getHeight();
                constexpr int tbH = 17;
                const int tbW = juce::jmin(w - 6, 70);
                layout.textBoxBounds = juce::Rectangle<int>((w - tbW) / 2, h - tbH - 2, tbW, tbH);
                layout.sliderBounds  = juce::Rectangle<int>(0, 0, w, h - tbH - 4);
            }
            return layout;
        }

        void drawLabel(juce::Graphics& g, juce::Label& label) override
        {
            // Pillola valore incassata in ossidiana con filetto oro satinato (Value readout pill)
            auto bounds = label.getLocalBounds().toFloat();
            g.setColour(Palette::obsidianPill);
            g.fillRoundedRectangle(bounds, 3.5f);

            g.setColour(Palette::champagneGold.withAlpha(0.45f));
            g.drawRoundedRectangle(bounds, 3.5f, 0.9f);

            g.setFont(juce::FontOptions(10.5f, juce::Font::bold));
            g.setColour(Palette::brightGold);
            g.drawFittedText(label.getText(), label.getLocalBounds(), juce::Justification::centred, 1);
        }

    private:
        juce::Colour needleColour;
        juce::Colour arcColour;
    };

    // ==============================================================================
    // 5. PHOTOREALISTIC ANALOG METERS (Distressor LED, Pultec VU, SSL, TubeTech)
    // ==============================================================================
    class BoutiqueMeterRenderer
    {
    public:
        /**
         * @brief Distressor 16-LED Gain Reduction Ladder
         * Calibrated authentic LEDs:
         * Green: 1, 2, 3, 4, 5, 6 dB
         * Amber: 7, 8, 9, 10, 12, 14 dB
         * Red:   16, 18, 20, 24+ dB
         */
        static void drawDistressorLedLadder(juce::Graphics& g, juce::Rectangle<float> bounds, float grDb)
        {
            // Alloggiamento in metallo nero anodizzato incassato
            g.setColour(Palette::obsidianDark);
            g.fillRoundedRectangle(bounds, 5.0f);

            // Bordo cesellato in ottone satinato
            g.setColour(Palette::champagneGold.withAlpha(0.65f));
            g.drawRoundedRectangle(bounds, 5.0f, 1.2f);

            constexpr int numLeds = 16;
            constexpr float thresholds[numLeds] = {
                1.0f, 2.0f, 3.0f, 4.0f, 5.0f, 6.0f,
                7.0f, 8.0f, 9.0f, 10.0f, 12.0f, 14.0f,
                16.0f, 18.0f, 20.0f, 24.0f
            };

            const float padding = 6.0f;
            const float availableW = bounds.getWidth() - padding * 2.0f;
            const float ledW = (availableW - (numLeds - 1) * 2.0f) / static_cast<float>(numLeds);
            const float ledH = bounds.getHeight() * 0.44f;
            const float ledY = bounds.getY() + 6.0f;

            for (int i = 0; i < numLeds; ++i)
            {
                const float ledX = bounds.getX() + padding + static_cast<float>(i) * (ledW + 2.0f);
                const bool lit = (grDb >= thresholds[i]);

                juce::Colour litCol;
                juce::Colour dimCol;

                if (i < 6) {
                    litCol = Palette::ledGreenLit;
                    dimCol = Palette::ledGreenDim;
                } else if (i < 12) {
                    litCol = Palette::ledAmberLit;
                    dimCol = Palette::ledAmberDim;
                } else {
                    litCol = Palette::ledRedLit;
                    dimCol = Palette::ledRedDim;
                }

                auto ledRect = juce::Rectangle<float>(ledX, ledY, ledW, ledH);

                if (lit)
                {
                    // Bagliore alone
                    g.setColour(litCol.withAlpha(0.40f));
                    g.fillRoundedRectangle(ledRect.expanded(1.5f), 2.0f);

                    // Lente acrilica accesa
                    g.setColour(litCol);
                    g.fillRoundedRectangle(ledRect, 1.5f);

                    // Riflesso speculare superiore
                    g.setColour(juce::Colours::white.withAlpha(0.70f));
                    g.fillRect(ledRect.getX() + 1.0f, ledRect.getY() + 1.0f, ledRect.getWidth() - 2.0f, 2.0f);
                }
                else
                {
                    // Lente spenta
                    g.setColour(dimCol);
                    g.fillRoundedRectangle(ledRect, 1.5f);
                    g.setColour(juce::Colour(0x20ffffff));
                    g.drawRoundedRectangle(ledRect, 1.5f, 0.6f);
                }
            }

            // Diciture numeriche serigrafate sotto ogni gruppo di LED
            g.setFont(juce::FontOptions(8.0f, juce::Font::bold));
            g.setColour(Palette::textGold);
            g.drawText("1   2   3   4   5   6   7   8   9  10  12  14  16  18  20  24+ dB",
                       static_cast<int>(bounds.getX()), static_cast<int>(ledY + ledH + 2.0f),
                       static_cast<int>(bounds.getWidth()), 13, juce::Justification::centred, false);
        }

        /**
         * @brief Pultec Classic Incandescent VU Meter (Warm Backlight, Gold Needle)
         */
        static void drawPultecVUMeter(juce::Graphics& g, juce::Rectangle<float> bounds, float grDb)
        {
            // Alloggiamento esterno bisellato
            g.setColour(Palette::obsidianDark);
            g.fillRoundedRectangle(bounds, 6.0f);

            // Bordo cesellato oro satinato
            g.setColour(Palette::champagneGold);
            g.drawRoundedRectangle(bounds, 6.0f, 1.5f);

            // Quadrante interno avorio vintage retroilluminato da lampada a incandescenza calda
            auto dialRect = bounds.reduced(5.0f);
            juce::ColourGradient dialGrad(juce::Colour(0xfffff9eb), dialRect.getCentreX(), dialRect.getY(),
                                         juce::Colour(0xffe8d5ab), dialRect.getCentreX(), dialRect.getBottom(), false);
            g.setGradientFill(dialGrad);
            g.fillRoundedRectangle(dialRect, 4.0f);

            // Alone caldo d'incandescenza al centro
            juce::ColourGradient bulbGlow(juce::Colour(0x55ffb84d), dialRect.getCentreX(), dialRect.getBottom(),
                                         juce::Colours::transparentBlack, dialRect.getCentreX(), dialRect.getY(), true);
            g.setGradientFill(bulbGlow);
            g.fillRoundedRectangle(dialRect, 4.0f);

            // Arco graduato serigrafato
            const float pivotX = dialRect.getCentreX();
            const float pivotY = dialRect.getBottom() + dialRect.getHeight() * 0.50f;
            const float meterRadius = dialRect.getHeight() * 1.30f;

            // Arco nero (-20 a 0) e rosso (+0 a +3)
            g.setColour(juce::Colour(0xff181a1f));
            g.setFont(juce::FontOptions(9.5f, juce::Font::bold));
            g.drawText("-20  -10  -7  -5  -3  -2  -1   0  +1 +2 +3",
                       static_cast<int>(dialRect.getX()), static_cast<int>(dialRect.getY() + 10.0f),
                       static_cast<int>(dialRect.getWidth()), 14, juce::Justification::centred, false);

            g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
            g.setColour(Palette::deepBronze.darker(0.3f));
            g.drawText("VU", static_cast<int>(dialRect.getX()), static_cast<int>(dialRect.getY() + 26.0f),
                       static_cast<int>(dialRect.getWidth()), 16, juce::Justification::centred, false);

            g.setFont(juce::FontOptions(8.0f, juce::Font::bold));
            g.setColour(Palette::deepBronze);
            g.drawText("PEERLESS S-217-D  •  171 PULTEC",
                       static_cast<int>(dialRect.getX()), static_cast<int>(dialRect.getBottom() - 16.0f),
                       static_cast<int>(dialRect.getWidth()), 12, juce::Justification::centred, false);

            // Calcolo cinematica dell'ago (VU needle)
            // Valori normalizzati: -20 VU (-0.6 rad) a +3 VU (+0.6 rad)
            const float normVal = std::clamp((grDb + 20.0f) / 23.0f, 0.0f, 1.0f);
            const float needleAngle = -0.58f + normVal * 1.16f;

            const float tipX = pivotX + std::sin(needleAngle) * meterRadius;
            const float tipY = pivotY - std::cos(needleAngle) * meterRadius;

            // Ombra dell'ago proiettata sul fondo avorio
            g.setColour(juce::Colours::black.withAlpha(0.25f));
            g.drawLine(pivotX + 1.5f, pivotY + 1.5f, tipX + 1.5f, tipY + 1.5f, 2.0f);

            // Ago in metallo dorato cesellato
            g.setColour(Palette::deepBronze.darker(0.6f));
            g.drawLine(pivotX, pivotY, tipX, tipY, 1.8f);

            // Coperchio pivot scuro
            g.setColour(juce::Colour(0xff121316));
            g.fillEllipse(pivotX - 9.0f, dialRect.getBottom() - 6.0f, 18.0f, 18.0f);
            g.setColour(Palette::champagneGold);
            g.drawEllipse(pivotX - 9.0f, dialRect.getBottom() - 6.0f, 18.0f, 18.0f, 1.0f);

            // Riflesso di vetro bombato sul display
            g.setColour(juce::Colours::white.withAlpha(0.12f));
            g.fillRoundedRectangle(dialRect.getX() + 2.0f, dialRect.getY() + 2.0f,
                                   dialRect.getWidth() - 4.0f, dialRect.getHeight() * 0.40f, 3.0f);
        }

        /**
         * @brief SSL Twin Bargraphs (Dynamics GR and Output Peak Meter)
         */
        static void drawSSLTwinBargraphs(juce::Graphics& g, juce::Rectangle<float> bounds,
                                         float grDb, float outPeakDb)
        {
            // Alloggiamento doppio bargraph in metallo canna di fucile
            g.setColour(Palette::obsidianDark);
            g.fillRoundedRectangle(bounds, 5.0f);

            g.setColour(Palette::champagneGold.withAlpha(0.60f));
            g.drawRoundedRectangle(bounds, 5.0f, 1.2f);

            const float colW = (bounds.getWidth() - 20.0f) * 0.5f;
            const float barH = bounds.getHeight() - 42.0f;
            const float topY = bounds.getY() + 18.0f;

            auto grRect  = juce::Rectangle<float>(bounds.getX() + 8.0f, topY, colW, barH);
            auto outRect = juce::Rectangle<float>(bounds.getRight() - colW - 8.0f, topY, colW, barH);

            // Bargraph 1: Dynamics GR (12 segmenti verticali da 0 a 24 dB di riduzione)
            drawVerticalBargraph(g, grRect, grDb, 0.0f, 24.0f, true);

            // Bargraph 2: Output Peak (12 segmenti verticali da -36 a +6 dBFS)
            drawVerticalBargraph(g, outRect, outPeakDb, -36.0f, 6.0f, false);

            // Titoli colonna
            g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
            g.setColour(Palette::textGold);
            g.drawText("GR", static_cast<int>(grRect.getX()), static_cast<int>(bounds.getY() + 4.0f),
                       static_cast<int>(colW), 12, juce::Justification::centred, false);
            g.drawText("OUT", static_cast<int>(outRect.getX()), static_cast<int>(bounds.getY() + 4.0f),
                       static_cast<int>(colW), 12, juce::Justification::centred, false);

            // Scala diciture
            g.setFont(juce::FontOptions(7.5f, juce::Font::plain));
            g.setColour(Palette::textMuted);
            g.drawText("dB", static_cast<int>(bounds.getX()), static_cast<int>(bounds.getBottom() - 16.0f),
                       static_cast<int>(bounds.getWidth()), 12, juce::Justification::centred, false);
        }

        /**
         * @brief TubeTech Danish Circular Analog VU Meter (Warm Amber Backlight & Moving Needle)
         */
        static void drawTubeTechDanishVUMeter(juce::Graphics& g, juce::Rectangle<float> bounds, float grDb)
        {
            // Alloggiamento esterno rotondo con ghiera oro satinato
            const float diam = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx = bounds.getCentreX();
            const float cy = bounds.getCentreY();
            const float radius = diam * 0.5f - 4.0f;

            // Ombra di fondo
            g.setColour(juce::Colours::black.withAlpha(0.65f));
            g.fillEllipse(cx - radius + 2.0f, cy - radius + 3.0f, radius * 2.0f, radius * 2.0f);

            // Ghiera esterna tornita in oro satinato / bronzo danese
            juce::ColourGradient ringGrad(Palette::brightGold, cx - radius, cy - radius,
                                         Palette::deepBronze.darker(0.3f), cx + radius, cy + radius, false);
            g.setGradientFill(ringGrad);
            g.fillEllipse(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f);

            // Bordo cesellato
            g.setColour(Palette::champagneGold);
            g.drawEllipse(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f, 1.2f);

            // Quadrante interno incassato avorio vintage con illuminazione a lampadina calda
            const float dialR = radius - 5.0f;
            juce::ColourGradient dialGrad(juce::Colour(0xfffdf6e4), cx, cy - dialR,
                                         juce::Colour(0xffecd4a4), cx, cy + dialR, false);
            g.setGradientFill(dialGrad);
            g.fillEllipse(cx - dialR, cy - dialR, dialR * 2.0f, dialR * 2.0f);

            // Alone caldo lampadina (Warm incandescent halo)
            juce::ColourGradient bulbGrad(juce::Colour(0x60ffa834), cx, cy + dialR * 0.4f,
                                         juce::Colours::transparentBlack, cx, cy - dialR * 0.6f, true);
            g.setGradientFill(bulbGrad);
            g.fillEllipse(cx - dialR, cy - dialR, dialR * 2.0f, dialR * 2.0f);

            // Tacche e serigrafia danese Tube-Tech CL 1B
            g.setFont(juce::FontOptions(9.0f, juce::Font::bold));
            g.setColour(juce::Colour(0xff18191c));
            g.drawText("20   16   12   8   4   2   0 dB",
                       static_cast<int>(cx - dialR), static_cast<int>(cy - dialR * 0.55f),
                       static_cast<int>(dialR * 2.0f), 14, juce::Justification::centred, false);

            g.setFont(juce::FontOptions(7.5f, juce::Font::bold));
            g.setColour(Palette::deepBronze.darker(0.2f));
            g.drawText("TUBE-TECH CL 1B  •  COPENHAGEN",
                       static_cast<int>(cx - dialR), static_cast<int>(cy + dialR * 0.28f),
                       static_cast<int>(dialR * 2.0f), 12, juce::Justification::centred, false);

            // Ago in burgundy scuro / oro satinato (sweeps right to left from 0 down to -20 dB)
            const float normGr = std::clamp(grDb / 20.0f, 0.0f, 1.0f);
            // Angolo: 0 dB a +0.55 rad (destra), 20 dB a -0.55 rad (sinistra)
            const float needleAngle = 0.55f - normGr * 1.10f;
            const float needleLen = dialR * 0.88f;

            const float tipX = cx + std::sin(needleAngle) * needleLen;
            const float tipY = cy + dialR * 0.20f - std::cos(needleAngle) * needleLen;

            // Ombra dell'ago
            g.setColour(juce::Colours::black.withAlpha(0.25f));
            g.drawLine(cx + 1.2f, cy + dialR * 0.20f + 1.2f, tipX + 1.2f, tipY + 1.2f, 2.0f);

            // Ago
            g.setColour(juce::Colour(0xffb91c1c));
            g.drawLine(cx, cy + dialR * 0.20f, tipX, tipY, 1.8f);

            // Cupola perno centrale in ottone brunito
            const float capR = 7.0f;
            g.setColour(juce::Colour(0xff121316));
            g.fillEllipse(cx - capR, cy + dialR * 0.20f - capR, capR * 2.0f, capR * 2.0f);
            g.setColour(Palette::satinGold);
            g.drawEllipse(cx - capR, cy + dialR * 0.20f - capR, capR * 2.0f, capR * 2.0f, 1.0f);

            // Riflesso lente di vetro
            g.setColour(juce::Colours::white.withAlpha(0.12f));
            g.fillEllipse(cx - dialR * 0.85f, cy - dialR * 0.85f, dialR * 1.70f, dialR * 0.80f);
        }

    private:
        static void drawVerticalBargraph(juce::Graphics& g, juce::Rectangle<float> bounds,
                                         float value, float minVal, float maxVal, bool invertReduction)
        {
            constexpr int numSegs = 12;
            const float segH = (bounds.getHeight() - (numSegs - 1) * 2.0f) / static_cast<float>(numSegs);

            for (int i = 0; i < numSegs; ++i)
            {
                // Segmento 0 è in cima
                const float normPos = static_cast<float>(numSegs - 1 - i) / static_cast<float>(numSegs - 1);
                const float segVal = minVal + normPos * (maxVal - minVal);

                bool lit = false;
                if (invertReduction)
                    lit = (value >= (minVal + (static_cast<float>(i + 1) / static_cast<float>(numSegs)) * (maxVal - minVal)));
                else
                    lit = (value >= segVal);

                juce::Colour litCol;
                juce::Colour dimCol;

                if (i < 3) {
                    litCol = Palette::ledRedLit;
                    dimCol = Palette::ledRedDim;
                } else if (i < 7) {
                    litCol = Palette::ledAmberLit;
                    dimCol = Palette::ledAmberDim;
                } else {
                    litCol = Palette::ledGreenLit;
                    dimCol = Palette::ledGreenDim;
                }

                const float segY = bounds.getY() + static_cast<float>(i) * (segH + 2.0f);
                auto segRect = juce::Rectangle<float>(bounds.getX(), segY, bounds.getWidth(), segH);

                if (lit)
                {
                    g.setColour(litCol.withAlpha(0.40f));
                    g.fillRoundedRectangle(segRect.expanded(1.0f), 1.5f);
                    g.setColour(litCol);
                    g.fillRoundedRectangle(segRect, 1.5f);
                    g.setColour(juce::Colours::white.withAlpha(0.50f));
                    g.fillRect(segRect.getX() + 1.0f, segRect.getY() + 0.5f, segRect.getWidth() - 2.0f, 1.0f);
                }
                else
                {
                    g.setColour(dimCol);
                    g.fillRoundedRectangle(segRect, 1.5f);
                }
            }
        }
    };
} // namespace gui171
