import os
import cv2
import numpy as np
from PIL import Image

def process_faders():
    fader_dir = 'C:/Users/171Studio/.gemini/antigravity/scratch/Plugin_Assets_Hub/Faders'
    os.makedirs(fader_dir, exist_ok=True)

    cap_rembg_path = 'C:/Users/171Studio/.gemini/antigravity/scratch/test_fader_cap_rembg.png'
    track_rembg_path = 'C:/Users/171Studio/.gemini/antigravity/scratch/test_fader_track_rembg.png'

    im_cap = Image.open(cap_rembg_path)
    im_track = Image.open(track_rembg_path)

    # 1. Tight crop the Cap: bbox is (305, 138, 719, 887) -> width 414, height 749
    cap_tight = im_cap.crop(im_cap.getbbox())
    cap_master_path = os.path.join(fader_dir, 'Fader_Cap_Boutique_Gunmetal_AmberLED_Master_414x749.png')
    cap_tight.save(cap_master_path)
    print('Saved Master Fader Cap:', cap_master_path)

    # Also save canonical alias
    cap_tight.save(os.path.join(fader_dir, 'Fader_Cap_Boutique_Gunmetal_AmberLED_Master.png'))

    # Resolutions for Cap:
    # 80x145 (Console Standard), 64x116, 48x87, 32x58
    cap_sizes = [
        (80, 145),
        (64, 116),
        (48, 87),
        (32, 58)
    ]
    for cw, ch in cap_sizes:
        res_cap = cap_tight.resize((cw, ch), Image.Resampling.LANCZOS)
        fn = f'Fader_Cap_Boutique_Gunmetal_AmberLED_{cw}x{ch}.png'
        res_cap.save(os.path.join(fader_dir, fn))
        print(f'Saved Fader Cap: {fn}')

    # 2. Tight crop the Track: bbox is (30, 28, 224, 997) -> width 194, height 969
    track_tight = im_track.crop(im_track.getbbox())
    track_master_path = os.path.join(fader_dir, 'Fader_Track_Boutique_AgedBrass_Slot_Master_194x969.png')
    track_tight.save(track_master_path)
    print('Saved Master Fader Track:', track_master_path)

    # Also save canonical alias
    track_tight.save(os.path.join(fader_dir, 'Fader_Track_Boutique_AgedBrass_Slot_Master.png'))

    # Resolutions for Track:
    # 96x480 (Console 100mm throw standard), 64x320, 48x240
    track_sizes = [
        (96, 480),
        (64, 320),
        (48, 240)
    ]
    for tw, th in track_sizes:
        res_track = track_tight.resize((tw, th), Image.Resampling.LANCZOS)
        fn = f'Fader_Track_Boutique_AgedBrass_Slot_{tw}x{th}.png'
        res_track.save(os.path.join(fader_dir, fn))
        print(f'Saved Fader Track: {fn}')

    # 3. Generate Integrated Fader Track with Calibrated dB Scale (160x480)
    # Track centered, with dB serigraphy on left and right wings
    th = 480
    tw = 80
    canvas_w = 160
    scale_track = track_tight.resize((tw, th), Image.Resampling.LANCZOS)
    
    # Create RGBA canvas
    calib_canvas = Image.new('RGBA', (canvas_w, th), (0, 0, 0, 0))
    track_x = (canvas_w - tw) // 2
    calib_canvas.paste(scale_track, (track_x, 0), scale_track)

    # Convert to OpenCV to draw fine serigraphy
    calib_cv = cv2.cvtColor(np.array(calib_canvas), cv2.COLOR_RGBA2BGRA)

    # dB scale points (+10 dB at top travel, 0 dB at ~75%, -inf at bottom)
    # Travel is between y=40 (top) and y=440 (bottom), span = 400px
    db_points = [
        (+10, 48, "+10"),
        (+5,  85,  "+5"),
        (0,   135, "0"),
        (-5,  185, "-5"),
        (-10, 235, "-10"),
        (-15, 280, "-15"),
        (-20, 325, "-20"),
        (-30, 370, "-30"),
        (-40, 405, "-40"),
        (-50, 430, "-50"),
        (-999, 452, "oo")
    ]

    for db_val, y_pos, label in db_points:
        is_zero = (db_val == 0)
        line_col = (110, 185, 230, 240) if is_zero else (80, 140, 185, 180) # Gold
        txt_col = (130, 210, 255, 255) if is_zero else (100, 160, 205, 210)
        thickness = 2 if is_zero else 1
        line_len = 10 if is_zero else 6

        # Left tick
        calib_cv[y_pos : y_pos + thickness, track_x - 4 - line_len : track_x - 4] = line_col
        # Right tick
        calib_cv[y_pos : y_pos + thickness, track_x + tw + 4 : track_x + tw + 4 + line_len] = line_col

        # Labels (left and right)
        cv2.putText(calib_cv, label, (6, y_pos + 4), cv2.FONT_HERSHEY_SIMPLEX, 0.32, txt_col, 1, cv2.LINE_AA)
        cv2.putText(calib_cv, label, (track_x + tw + 18, y_pos + 4), cv2.FONT_HERSHEY_SIMPLEX, 0.32, txt_col, 1, cv2.LINE_AA)

    calib_out_path = os.path.join(fader_dir, 'Fader_Track_Boutique_Precision_dB_Scale_160x480.png')
    cv2.imwrite(calib_out_path, calib_cv)
    print('Generated calibrated track with dB scale:', calib_out_path)

    # Replace old precision scale with new one
    old_scale_path = os.path.join(fader_dir, 'Fader_Track_Console_Precision_dB_Scale_120x480.png')
    cv2.imwrite(old_scale_path, cv2.resize(calib_cv, (120, 480), interpolation=cv2.INTER_LANCZOS4))

    # 4. Eliminate obsolete / deprecated previous files
    obsolete = [
        'Fader_Cap_171_Custom_Metallic.png',
        'Fader_Track_Golden_Recessed.png',
        'Fader_Slot_Track.png',
        'Fader_Cap_Charcoal_Black.png',
        'Fader_Cap_Console_Blue.png',
        'Fader_Cap_Console_Red.png',
        'Fader_Cap_Studio_Grey.png',
        'Fader_Cap_Vintage_White.png'
    ]
    for obs in obsolete:
        p = os.path.join(fader_dir, obs)
        if os.path.exists(p):
            os.remove(p)
            print('Removed obsolete file:', obs)

    # 5. Build Comprehensive Master Showcase
    showcase_path = 'C:/Users/171Studio/.gemini/antigravity/scratch/fader_master_showcase.png'
    sc_w, sc_h = 960, 560
    canvas = np.zeros((sc_h, sc_w, 3), dtype=np.uint8)

    # Dark boutique brushed brass background
    for y in range(sc_h):
        noise = np.random.randint(-2, 3)
        val = 30 + noise
        canvas[y, :, :] = [val - 4, val, val + 2]

    def overlay_rgba(bg, fg, x, y):
        h, w = fg.shape[:2]
        a = fg[:, :, 3] / 255.0
        for c in range(3):
            bg[y:y+h, x:x+w, c] = (a * fg[:, :, c] + (1.0 - a) * bg[y:y+h, x:x+w, c]).astype(np.uint8)

    # Column 1: Fader Track Alone (160x480)
    overlay_rgba(canvas, calib_cv, 40, 40)
    cv2.putText(canvas, "TRACK + dB SCALE", (45, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 220, 240), 1, cv2.LINE_AA)

    # Column 2: Fader Cap Macro Detail (160x290)
    macro_cap = cap_tight.resize((160, 290), Image.Resampling.LANCZOS)
    macro_cv = cv2.cvtColor(np.array(macro_cap), cv2.COLOR_RGBA2BGRA)
    overlay_rgba(canvas, macro_cv, 240, 135)
    cv2.putText(canvas, "FADER CAP MACRO", (250, 115), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 220, 240), 1, cv2.LINE_AA)
    cv2.putText(canvas, "Pyramid knurl + Amber LED line", (230, 450), cv2.FONT_HERSHEY_SIMPLEX, 0.38, (160, 160, 160), 1, cv2.LINE_AA)

    # Column 3 & 4 & 5: Assembled Dynamic Faders at different positions!
    # Positions: +5 dB (y=85), 0 dB Unity (y=135), -20 dB (y=325)
    cap_ui = cap_tight.resize((60, 108), Image.Resampling.LANCZOS)
    cap_ui_cv = cv2.cvtColor(np.array(cap_ui), cv2.COLOR_RGBA2BGRA)

    fader_demos = [
        ("+5 dB BOOST", 460, 85 - 54),
        ("0 dB UNITY",  630, 135 - 54),
        ("-20 dB ATTEN", 800, 325 - 54)
    ]

    for title, fx, cap_y in fader_demos:
        # Draw track
        overlay_rgba(canvas, calib_cv, fx - 10, 40)
        # Draw cap over track (cap width 60, track center is fx + 70)
        cx = fx - 10 + (canvas_w - 60) // 2
        cy = 40 + cap_y
        overlay_rgba(canvas, cap_ui_cv, cx, cy)
        cv2.putText(canvas, title, (fx + 20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 215, 120), 1, cv2.LINE_AA)

    cv2.imwrite(showcase_path, canvas)
    print('Saved Master Fader Showcase:', showcase_path)

if __name__ == '__main__':
    process_faders()
