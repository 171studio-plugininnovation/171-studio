import os
import cv2
import numpy as np
from PIL import Image

def process_jewel_lights():
    jewel_dir = 'C:/Users/171Studio/.gemini/antigravity/scratch/Plugin_Assets_Hub/Jewel_Lamps'
    os.makedirs(jewel_dir, exist_ok=True)

    sources = [
        ('Amber_ON', 'Jewel_Lamp_VintageBoutique_Faceted_Amber_ON', 'C:/Users/171Studio/.gemini/antigravity/brain/2f4a0ca7-5fa7-47eb-9a6a-f713f410d3de/.user_uploaded/media_1792526203858_9f48166b.jpg'),
        ('Green_ON', 'Jewel_Lamp_VintageBoutique_Faceted_Green_ON', 'C:/Users/171Studio/.gemini/antigravity/brain/2f4a0ca7-5fa7-47eb-9a6a-f713f410d3de/.user_uploaded/media_1792526203865_0fc49eb7.jpg'),
        ('Ruby_ON',  'Jewel_Lamp_VintageBoutique_Faceted_Ruby_ON',  'C:/Users/171Studio/.gemini/antigravity/brain/2f4a0ca7-5fa7-47eb-9a6a-f713f410d3de/.user_uploaded/media_1792526203868_48c3ba85.jpg'),
        ('Dark_OFF', 'Jewel_Lamp_VintageBoutique_Faceted_Dark_OFF', 'C:/Users/171Studio/.gemini/antigravity/brain/2f4a0ca7-5fa7-47eb-9a6a-f713f410d3de/.user_uploaded/media_1792526223686_a450f77c.jpg')
    ]

    master_outputs = {}

    for label, base_name, img_path in sources:
        img = cv2.imread(img_path)
        h, w = img.shape[:2]
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # Background thresholding
        _, thresh = cv2.threshold(gray, 5, 255, cv2.THRESH_BINARY)
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        c = max(contours, key=cv2.contourArea)

        # Solid mask
        mask = np.zeros((h, w), np.uint8)
        cv2.drawContours(mask, [c], -1, 255, -1)

        # Gaussian anti-aliasing on the mask
        mask_blurred = cv2.GaussianBlur(mask, (3, 3), 0.75)

        # Sub-pixel centering to exact (512.0, 512.0)
        (cx, cy), radius = cv2.minEnclosingCircle(c)
        dx = 512.0 - cx
        dy = 512.0 - cy
        M = np.float32([[1, 0, dx], [0, 1, dy]])
        img_centered = cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_LANCZOS4)
        mask_centered = cv2.warpAffine(mask_blurred, M, (w, h), flags=cv2.INTER_LANCZOS4)

        rgba = cv2.cvtColor(img_centered, cv2.COLOR_BGR2BGRA)
        rgba[:, :, 3] = mask_centered

        # Save Master 1024x1024
        master_fn = f'{base_name}_1024x1024.png'
        master_path = os.path.join(jewel_dir, master_fn)
        cv2.imwrite(master_path, rgba)
        print(f'Saved Master: {master_fn}')

        # Save standard resolutions: 256, 128, 64
        pil_master = Image.fromarray(cv2.cvtColor(rgba, cv2.COLOR_BGRA2RGBA))
        master_outputs[label] = pil_master

        for sz in [256, 128, 64]:
            res = pil_master.resize((sz, sz), Image.Resampling.LANCZOS)
            res_fn = f'{base_name}_{sz}x{sz}.png'
            res.save(os.path.join(jewel_dir, res_fn))
            print(f'Saved resolution: {res_fn}')

    # Save canonical aliases:
    master_outputs['Amber_ON'].save(os.path.join(jewel_dir, 'Jewel_Lamp_Large_Faceted_Amber_ON.png'))
    master_outputs['Green_ON'].save(os.path.join(jewel_dir, 'Jewel_Lamp_Large_Faceted_Green_ON.png'))
    master_outputs['Ruby_ON'].save(os.path.join(jewel_dir, 'Jewel_Lamp_Large_Faceted_Ruby_ON.png'))
    master_outputs['Dark_OFF'].save(os.path.join(jewel_dir, 'Jewel_Lamp_Large_Faceted_Universal_OFF.png'))

    # Replace the old/deprecated smaller files in place with high-res Lanczos downsamples
    replacements = {
        'Lamp_Jewel_Amber_Gold_ON.png': (master_outputs['Amber_ON'], 128),
        'Lamp_Jewel_Amber_Gold_OFF.png': (master_outputs['Dark_OFF'], 128),
        'Lamp_Jewel_Emerald_Green_ON.png': (master_outputs['Green_ON'], 128),
        'Lamp_Jewel_Emerald_Green_OFF.png': (master_outputs['Dark_OFF'], 128),
        'Lamp_Jewel_Ruby_Red_ON.png': (master_outputs['Ruby_ON'], 128),
        'Lamp_Jewel_Ruby_Red_OFF.png': (master_outputs['Dark_OFF'], 128),
        'Jewel_Lamp_Large_Faceted_Amber_ON_250x250.png': (master_outputs['Amber_ON'], 250),
        'Jewel_Lamp_Large_Faceted_Ruby_ON_250x250.png': (master_outputs['Ruby_ON'], 250),
        'Jewel_Lamp_Large_Faceted_Topaz_ON_250x250.png': (master_outputs['Green_ON'], 250),
        'Jewel_Lamp_Small_Faceted_Amber_OFF_144x144.png': (master_outputs['Dark_OFF'], 144),
        'Jewel_Lamp_Small_Faceted_Ruby_OFF_144x144.png': (master_outputs['Dark_OFF'], 144),
        'Jewel_Lamp_Small_Faceted_Topaz_OFF_144x144.png': (master_outputs['Dark_OFF'], 144),
        'Jewel_Gem_Isolated_Amber.png': (master_outputs['Amber_ON'], 128)
    }

    for fn, (pil_img, sz) in replacements.items():
        res = pil_img.resize((sz, sz), Image.Resampling.LANCZOS)
        res.save(os.path.join(jewel_dir, fn))
        print(f'Replaced old file: {fn} ({sz}x{sz})')

    # Remove the 3 deprecated synthetic faceted gem placeholders
    obsolete = [
        'Faceted_Gem_171_Amber_Glowing_164x164.png',
        'Faceted_Gem_171_Ruby_Glowing_164x164.png',
        'Faceted_Gem_171_Topaz_Glowing_164x164.png'
    ]
    for obs in obsolete:
        p = os.path.join(jewel_dir, obs)
        if os.path.exists(p):
            os.remove(p)
            print(f'Removed obsolete file: {obs}')

    # Create Showcase Comparison: Amber, Green, Ruby, and Universal Dark OFF
    showcase_path = 'C:/Users/171Studio/.gemini/antigravity/scratch/jewel_lamps_master_showcase.png'
    cell_w, cell_h = 240, 240
    grid = np.zeros((cell_h + 60, cell_w * 4, 3), dtype=np.uint8)

    # Dark brushed panel background (#211e1b)
    for y in range(grid.shape[0]):
        noise = np.random.randint(-2, 3)
        val = 33 + noise
        grid[y, :, :] = [val - 4, val, val + 2]

    def overlay(bg, fg, x, y):
        h_f, w_f = fg.shape[:2]
        a = fg[:, :, 3] / 255.0
        for c in range(3):
            bg[y:y+h_f, x:x+w_f, c] = (a * fg[:, :, c] + (1.0 - a) * bg[y:y+h_f, x:x+w_f, c]).astype(np.uint8)

    items = [
        ('AMBER GOLD [ON]', 'Jewel_Lamp_VintageBoutique_Faceted_Amber_ON_256x256.png', (255, 200, 120)),
        ('EMERALD GREEN [ON]', 'Jewel_Lamp_VintageBoutique_Faceted_Green_ON_256x256.png', (140, 255, 160)),
        ('RUBY RED [ON]', 'Jewel_Lamp_VintageBoutique_Faceted_Ruby_ON_256x256.png', (140, 160, 255)),
        ('UNIVERSAL DARK [OFF]', 'Jewel_Lamp_VintageBoutique_Faceted_Dark_OFF_256x256.png', (180, 180, 180))
    ]

    for col, (label, fn, txt_col) in enumerate(items):
        im_cv = cv2.imread(os.path.join(jewel_dir, fn), cv2.IMREAD_UNCHANGED)
        # Resize to 200x200 for showcase
        im_cv = cv2.resize(im_cv, (200, 200), interpolation=cv2.INTER_LANCZOS4)
        x = col * cell_w + (cell_w - 200) // 2
        y = 40 + (cell_h - 200) // 2
        overlay(grid, im_cv, x, y)
        cv2.putText(grid, label, (col * cell_w + 18, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.45, txt_col, 1, cv2.LINE_AA)

    cv2.imwrite(showcase_path, grid)
    print(f'Saved showcase image: {showcase_path}')

if __name__ == '__main__':
    process_jewel_lights()
