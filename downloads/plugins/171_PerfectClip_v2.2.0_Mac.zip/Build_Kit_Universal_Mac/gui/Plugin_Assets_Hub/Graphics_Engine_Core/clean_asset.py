"""
=============================================================================
171Studio Boutique Hardware - Sub-Pixel Asset Background Cleaner (clean_asset.py)
=============================================================================
Takes a raw render on pure solid white (#FFFFFF) or pure solid black (#000000),
detects the background color, extracts an antialiased sub-pixel alpha channel,
applies color de-spill, and centers the asset symmetrically to guarantee 0 wobble.
"""

import sys, os
import cv2
import numpy as np
from PIL import Image, ImageFilter

def clean_asset(input_path, output_path=None, target_size=None, feather=1.0):
    if not os.path.exists(input_path):
        print(f"Error: file not found: {input_path}")
        return None
        
    if output_path is None:
        base, _ = os.path.splitext(input_path)
        output_path = f"{base}_clean.png"
        
    im_bgr = cv2.imread(input_path)
    h, w = im_bgr.shape[:2]
    
    # 1. Detect background color from 4 corners
    corners = np.array([im_bgr[4, 4], im_bgr[4, -5], im_bgr[-5, 4], im_bgr[-5, -5]], dtype=float)
    bg_color = np.median(corners, axis=0)
    is_white_bg = np.mean(bg_color) > 128.0
    
    # 2. Compute color distance from background
    diff = np.linalg.norm(im_bgr.astype(float) - bg_color, axis=2)
    
    if is_white_bg:
        # Soft threshold from white: diff > 15 is foreground
        alpha = np.clip((diff - 12.0) / 18.0, 0.0, 1.0) * 255.0
    else:
        # Soft threshold from black
        gray = cv2.cvtColor(im_bgr, cv2.COLOR_BGR2GRAY)
        alpha = np.clip((gray.astype(float) - 4.0) / 12.0, 0.0, 1.0) * 255.0
        
    pil_alpha = Image.fromarray(alpha.astype(np.uint8)).filter(ImageFilter.GaussianBlur(feather))
    alpha_arr = np.array(pil_alpha)
    
    # 3. Find center of mass of non-transparent pixels
    bright = alpha_arr > 30
    y_idx, x_idx = np.where(bright)
    if len(x_idx) == 0:
        print("Error: no foreground detected!")
        return None
        
    cx = np.mean(x_idx)
    cy = np.mean(y_idx)
    half_w = (np.max(x_idx) - np.min(x_idx)) / 2.0
    half_h = (np.max(y_idx) - np.min(y_idx)) / 2.0
    radius = max(half_w, half_h) + 6.0
    
    # 4. Crop symmetrically centered on (cx, cy)
    R_int = int(np.ceil(radius))
    x_min = max(0, int(round(cx)) - R_int)
    x_max = min(w, int(round(cx)) + R_int)
    y_min = max(0, int(round(cy)) - R_int)
    y_max = min(h, int(round(cy)) + R_int)
    
    cropped_bgr = im_bgr[y_min:y_max, x_min:x_max]
    cropped_alpha = alpha_arr[y_min:y_max, x_min:x_max]
    
    # De-spill: if white background, remove white fringe from semi-transparent edge pixels
    rgba = cv2.cvtColor(cropped_bgr, cv2.COLOR_BGR2BGRA)
    if is_white_bg:
        # Unmix white from RGB: C_true = (C_obs - (1-a)*255) / a
        a_norm = np.clip(cropped_alpha.astype(float) / 255.0, 0.001, 1.0)
        for c in range(3):
            unmixed = (cropped_bgr[:, :, c].astype(float) - (1.0 - a_norm) * 255.0) / a_norm
            rgba[:, :, c] = np.clip(unmixed, 0, 255).astype(np.uint8)
            
    rgba[:, :, 3] = cropped_alpha
    
    # 5. Resize to target size if specified
    pil_final = Image.fromarray(cv2.cvtColor(rgba, cv2.COLOR_BGRA2RGBA))
    if target_size is not None:
        pil_final = pil_final.resize(target_size, Image.Resampling.LANCZOS)
        
    pil_final.save(output_path, 'PNG')
    print(f"Cleaned asset saved: {output_path} (size: {pil_final.size})")
    return output_path

if __name__ == '__main__':
    if len(sys.argv) > 1:
        inp = sys.argv[1]
        outp = sys.argv[2] if len(sys.argv) > 2 else None
        clean_asset(inp, outp)
    else:
        print("Usage: python clean_asset.py <raw_render.jpg> [clean_output.png]")
