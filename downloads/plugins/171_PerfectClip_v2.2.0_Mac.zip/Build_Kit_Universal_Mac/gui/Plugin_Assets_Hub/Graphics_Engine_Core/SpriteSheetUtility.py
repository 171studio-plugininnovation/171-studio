#!/usr/bin/env python3
"""
171PluginInnovation – Sprite Sheet & Asset Utility Tool
Utility per la manipolazione, packing e generazione di asset per plugin audio.
"""

import os
import sys
from PIL import Image

def slice_filmstrip(filmstrip_path, num_frames, output_dir):
    """Ritaglia una striscia verticale o orizzontale in singoli frame PNG numerati."""
    im = Image.open(filmstrip_path)
    w, h = im.size
    os.makedirs(output_dir, exist_ok=True)
    
    # Determina se la striscia e' verticale o orizzontale
    is_vertical = h > w
    if is_vertical:
        frame_h = h // num_frames
        frame_w = w
    else:
        frame_w = w // num_frames
        frame_h = h
        
    print(f"Slicing '{os.path.basename(filmstrip_path)}' ({w}x{h}) into {num_frames} frames ({frame_w}x{frame_h})...")
    
    for i in range(num_frames):
        if is_vertical:
            box = (0, i * frame_h, frame_w, (i + 1) * frame_h)
        else:
            box = (i * frame_w, 0, (i + 1) * frame_w, frame_h)
            
        frame = im.crop(box)
        frame.save(os.path.join(output_dir, f"frame_{i:03d}.png"))
        
    print(f"Salvato con successo in: {output_dir}")

def pack_images_to_filmstrip(image_files, output_path, horizontal=False):
    """Compatta una lista di immagini PNG individuali in una singola striscia filmstrip."""
    images = [Image.open(f) for f in image_files]
    if not images:
        print("Nessuna immagine fornita.")
        return

    frame_w, frame_h = images[0].size
    num_frames = len(images)

    if horizontal:
        strip_w = frame_w * num_frames
        strip_h = frame_h
    else:
        strip_w = frame_w
        strip_h = frame_h * num_frames

    strip = Image.new("RGBA", (strip_w, strip_h), (0, 0, 0, 0))

    for idx, img in enumerate(images):
        if horizontal:
            strip.paste(img, (idx * frame_w, 0))
        else:
            strip.paste(img, (0, idx * frame_h))

    strip.save(output_path, "PNG")
    print(f"Generata filmstrip {strip_w}x{strip_h} con {num_frames} frame in: {output_path}")

if __name__ == "__main__":
    print("APGE Sprite Sheet Utility 1.0 pronto.")
