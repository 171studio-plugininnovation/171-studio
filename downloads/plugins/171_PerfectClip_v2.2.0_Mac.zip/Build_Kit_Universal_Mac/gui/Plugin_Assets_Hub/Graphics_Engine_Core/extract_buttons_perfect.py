import os
import sys
import cv2
import numpy as np
from PIL import Image

def extract_buttons():
    img_on_path = 'C:/Users/171Studio/.gemini/antigravity/brain/2f4a0ca7-5fa7-47eb-9a6a-f713f410d3de/.user_uploaded/media_1792525837597_1b277fd6.jpg'
    img_off_path = 'C:/Users/171Studio/.gemini/antigravity/brain/2f4a0ca7-5fa7-47eb-9a6a-f713f410d3de/.user_uploaded/media_1792525908516_c3f9719e.jpg'

    img_on = cv2.imread(img_on_path)
    img_off = cv2.imread(img_off_path)

    out_dir = 'C:/Users/171Studio/.gemini/antigravity/scratch/Plugin_Assets_Hub/Switches'
    os.makedirs(out_dir, exist_ok=True)

    # We crop each button as a 160x160 square centered on the button
    # The button body itself is ~134x120 px plus drop shadow
    crop_size = 160
    half_crop = crop_size // 2

    buttons_on = [
        ('SOLO', 228, 285),
        ('MUTE', 418, 285),
        ('SC_LISTEN', 610, 285),
        ('BYPASS', 801, 286)
    ]

    buttons_off = [
        ('SOLO', 511, 112),
        ('MUTE', 511, 224),
        ('SC_LISTEN', 511, 336),
        ('BYPASS', 511, 448)
    ]

    # Try importing rembg
    try:
        import rembg
        use_rembg = True
        print('rembg imported successfully!')
    except Exception as e:
        use_rembg = False
        print('rembg not available, using precision morphological matting:', e)

    results = []

    for name, cx, cy in buttons_on:
        crop_bgr = img_on[cy-half_crop : cy+half_crop, cx-half_crop : cx+half_crop]
        filename = f'Button_Console_Square_{name}_Lit_ON.png'
        out_path = os.path.join(out_dir, filename)

        crop_rgb = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2RGB)
        pil_img = Image.fromarray(crop_rgb)

        if use_rembg:
            try:
                out_pil = rembg.remove(pil_img)
                out_pil.save(out_path)
                print(f'Extracted with rembg: {filename}')
                results.append((filename, out_path, 'ON'))
                continue
            except Exception as e:
                print(f'rembg error on {filename}: {e}')

        # Fallback precision matting
        # Convert to RGBA
        # The background is the circular brushed metal outside the outer brass bezel
        # Outer bezel has outer radius ~66px from center
        h, w = crop_bgr.shape[:2]
        center = (w // 2, h // 2)
        
        # GrabCut segmentation
        mask = np.zeros(crop_bgr.shape[:2], np.uint8)
        bgdModel = np.zeros((1, 65), np.float64)
        fgdModel = np.zeros((1, 65), np.float64)
        
        # Button rectangle inside 160x160 is roughly [15, 15, 130, 130]
        rect = (12, 12, w - 24, h - 24)
        cv2.grabCut(crop_bgr, mask, rect, bgdModel, fgdModel, 5, cv2.GC_INIT_WITH_RECT)
        mask2 = np.where((mask == 2) | (mask == 0), 0, 1).astype('uint8')
        
        # Smooth mask
        mask2 = cv2.GaussianBlur(mask2 * 255, (5, 5), 0)
        
        rgba = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2BGRA)
        rgba[:, :, 3] = mask2
        cv2.imwrite(out_path, rgba)
        print(f'Extracted with GrabCut: {filename}')
        results.append((filename, out_path, 'ON'))

    for name, cx, cy in buttons_off:
        crop_bgr = img_off[cy-half_crop : cy+half_crop, cx-half_crop : cx+half_crop]
        filename = f'Button_Console_Square_{name}_Unlit_OFF.png'
        out_path = os.path.join(out_dir, filename)

        crop_rgb = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2RGB)
        pil_img = Image.fromarray(crop_rgb)

        if use_rembg:
            try:
                out_pil = rembg.remove(pil_img)
                out_pil.save(out_path)
                print(f'Extracted with rembg: {filename}')
                results.append((filename, out_path, 'OFF'))
                continue
            except Exception as e:
                print(f'rembg error on {filename}: {e}')

        h, w = crop_bgr.shape[:2]
        mask = np.zeros(crop_bgr.shape[:2], np.uint8)
        bgdModel = np.zeros((1, 65), np.float64)
        fgdModel = np.zeros((1, 65), np.float64)
        rect = (14, 14, w - 28, h - 28)
        cv2.grabCut(crop_bgr, mask, rect, bgdModel, fgdModel, 5, cv2.GC_INIT_WITH_RECT)
        mask2 = np.where((mask == 2) | (mask == 0), 0, 1).astype('uint8')
        mask2 = cv2.GaussianBlur(mask2 * 255, (5, 5), 0)
        
        rgba = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2BGRA)
        rgba[:, :, 3] = mask2
        cv2.imwrite(out_path, rgba)
        print(f'Extracted with GrabCut: {filename}')
        results.append((filename, out_path, 'OFF'))

    print(f'Successfully processed all {len(results)} buttons!')

if __name__ == '__main__':
    extract_buttons()
