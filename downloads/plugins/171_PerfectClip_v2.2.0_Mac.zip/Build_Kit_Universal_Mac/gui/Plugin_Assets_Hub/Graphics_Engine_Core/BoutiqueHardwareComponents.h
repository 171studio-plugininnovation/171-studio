#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_graphics/juce_graphics.h>
#include <cmath>
#include <vector>

namespace plugin_171
{
    // ==============================================================================
    // 1. FINESTRA DOPPIA VALVOLA "12AX7 / ECC83" ANIMATA IN TEMPO REALE
    // ==============================================================================
    class DualTubeWindowComponent : public juce::Component
    {
    public:
        DualTubeWindowComponent()
        {
            setOpaque(false);
        }

        /**
         * @brief Imposta l'intensità di saturazione/drive per modulare il bagliore dei filamenti.
         * @param drive0to1 Valore normalizzato tra 0.0f (riposo, filamento caldo) e 1.0f (saturazione massima).
         */
        void setSaturationAmount(float drive0to1)
        {
            saturation = juce::jlimit(0.0f, 1.0f, drive0to1);
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float w  = bounds.getWidth();
            const float h  = bounds.getHeight();
            const float cx = bounds.getCentreX();
            const float cy = bounds.getCentreY();

            // --------------------------------------------------------------------------
            // 1. CHASSIS ESTERNO: FLANGIA CIRCOLARE IN OTTONE + ALETTE RACK LATERALI
            // --------------------------------------------------------------------------
            const float earW = w * 0.14f;
            const float earH = h * 0.38f;
            const float earY = cy - earH * 0.5f;

            // Alette laterali rettangolari
            auto drawRackEar = [&](float x)
            {
                juce::Rectangle<float> earRect(x, earY, earW, earH);
                
                // Ombra portata
                g.setColour(juce::Colours::black.withAlpha(0.55f));
                g.fillRoundedRectangle(earRect.translated(1.5f, 2.5f), 4.0f);

                // Gradiente metallo spazzolato scuro
                juce::ColourGradient earGrad(
                    juce::Colour::fromString("ff42382c"), earRect.getX(), earRect.getY(),
                    juce::Colour::fromString("ff1f1a14"), earRect.getRight(), earRect.getBottom(), false);
                g.setGradientFill(earGrad);
                g.fillRoundedRectangle(earRect, 4.0f);

                // Bordo ottone dorato sottile
                g.setColour(juce::Colour::fromString("ffa3834a").withAlpha(0.7f));
                g.drawRoundedRectangle(earRect, 4.0f, 1.0f);

                // Foro ovale per vite rack
                const float slotW = earW * 0.42f;
                const float slotH = earH * 0.36f;
                juce::Rectangle<float> slot(earRect.getCentreX() - slotW * 0.5f, earRect.getCentreY() - slotH * 0.5f, slotW, slotH);
                g.setColour(juce::Colour::fromString("ff110e0a"));
                g.fillRoundedRectangle(slot, slotH * 0.5f);
                g.setColour(juce::Colour::fromString("ff6b5735"));
                g.drawRoundedRectangle(slot, slotH * 0.5f, 1.0f);
            };

            drawRackEar(bounds.getX() + 2.0f);
            drawRackEar(bounds.getRight() - earW - 2.0f);

            // Flangia circolare centrale in ottone brunito
            const float flangeRadius = juce::jmin(w * 0.42f, h * 0.48f);
            
            // Ombra flangia esterna
            g.setColour(juce::Colours::black.withAlpha(0.65f));
            g.fillEllipse(cx - flangeRadius + 2.0f, cy - flangeRadius + 3.5f, flangeRadius * 2.0f, flangeRadius * 2.0f);

            // Gradiente radiale conico ottone brunito
            juce::ColourGradient flangeGrad(
                juce::Colour::fromString("ff8c6d3b"), cx, cy - flangeRadius,
                juce::Colour::fromString("ff261d12"), cx, cy + flangeRadius, false);
            flangeGrad.addColour(0.30, juce::Colour::fromString("ffb89254"));
            flangeGrad.addColour(0.70, juce::Colour::fromString("ff473720"));
            g.setGradientFill(flangeGrad);
            g.fillEllipse(cx - flangeRadius, cy - flangeRadius, flangeRadius * 2.0f, flangeRadius * 2.0f);

            // Spazzolatura concentrica sottile
            for (float r = flangeRadius * 0.70f; r < flangeRadius; r += 2.5f)
            {
                float a = (std::fmod(r, 5.0f) < 2.5f) ? 0.05f : 0.02f;
                g.setColour(juce::Colours::white.withAlpha(a));
                g.drawEllipse(cx - r, cy - r, r * 2.0f, r * 2.0f, 0.7f);
            }

            // 6 bulloni esagonali incassati lungo il perimetro (ogni 60°)
            const float boltTrackR = flangeRadius * 0.88f;
            for (int i = 0; i < 6; ++i)
            {
                const float ang = (float)i * juce::MathConstants<float>::twoPi / 6.0f + 0.523f; // sfalsati di 30°
                const float bx = cx + std::cos(ang) * boltTrackR;
                const float by = cy + std::sin(ang) * boltTrackR;
                const float bR = flangeRadius * 0.055f;

                // Incasso scuro
                g.setColour(juce::Colour::fromString("ff120d08"));
                g.fillEllipse(bx - bR * 1.3f, by - bR * 1.3f, bR * 2.6f, bR * 2.6f);

                // Testa esagonale
                juce::Path hex;
                for (int j = 0; j < 6; ++j)
                {
                    float ha = (float)j * juce::MathConstants<float>::twoPi / 6.0f;
                    float hx = bx + std::cos(ha) * bR;
                    float hy = by + std::sin(ha) * bR;
                    if (j == 0) hex.startNewSubPath(hx, hy);
                    else        hex.lineTo(hx, hy);
                }
                hex.closeSubPath();

                juce::ColourGradient hexGrad(
                    juce::Colour::fromString("ffd6b677"), bx - bR, by - bR,
                    juce::Colour::fromString("ff4a371c"), bx + bR, by + bR, false);
                g.setGradientFill(hexGrad);
                g.fillPath(hex);
            }

            // --------------------------------------------------------------------------
            // 2. CAVITÀ INTERNA (CUTOUT A DOPPIA CUPOLA E LOGO ESAGONALE "171")
            // --------------------------------------------------------------------------
            const float cavW = flangeRadius * 1.48f;
            const float cavH = flangeRadius * 1.32f;
            const float halfCavW = cavW * 0.5f;

            juce::Path cavityPath;
            // Cupola sinistra, ponte centrale che scende, cupola destra
            const float topDomeR = cavH * 0.42f;
            const float tubeSpanX = halfCavW * 0.48f; // distanza centro cupole dal centro
            const float bridgeDropY = cy + cavH * 0.12f;

            cavityPath.startNewSubPath(cx - halfCavW, cy + cavH * 0.35f);
            // Salita sinistra
            cavityPath.lineTo(cx - halfCavW, cy - cavH * 0.05f);
            // Arco cupola sinistra
            cavityPath.cubicTo(cx - halfCavW, cy - cavH * 0.45f,
                               cx - tubeSpanX - topDomeR * 0.6f, cy - cavH * 0.48f,
                               cx - tubeSpanX, cy - cavH * 0.48f);
            cavityPath.cubicTo(cx - tubeSpanX + topDomeR * 0.6f, cy - cavH * 0.48f,
                               cx - 10.0f, cy - cavH * 0.25f,
                               cx, bridgeDropY); // discesa al ponte centrale
            // Risalita su cupola destra
            cavityPath.cubicTo(cx + 10.0f, cy - cavH * 0.25f,
                               cx + tubeSpanX - topDomeR * 0.6f, cy - cavH * 0.48f,
                               cx + tubeSpanX, cy - cavH * 0.48f);
            cavityPath.cubicTo(cx + tubeSpanX + topDomeR * 0.6f, cy - cavH * 0.48f,
                               cx + halfCavW, cy - cavH * 0.45f,
                               cx + halfCavW, cy - cavH * 0.05f);
            // Discesa destra e base
            cavityPath.lineTo(cx + halfCavW, cy + cavH * 0.35f);
            cavityPath.quadraticTo(cx, cy + cavH * 0.52f, cx - halfCavW, cy + cavH * 0.35f);
            cavityPath.closeSubPath();

            // Fondo nero profondo della cavità
            g.setColour(juce::Colour::fromString("ff0a0806"));
            g.fillPath(cavityPath);

            // Bordo smussato (bevel) dorato 2px e ombra interna
            juce::ColourGradient cavBevel(
                juce::Colour::fromString("ffd6b265"), cx, cy - cavH * 0.5f,
                juce::Colour::fromString("ff423018"), cx, cy + cavH * 0.5f, false);
            g.setGradientFill(cavBevel);
            g.strokePath(cavityPath, juce::PathStrokeType(2.2f));

            // Ombra interna marcata della cavità
            g.setColour(juce::Colours::black.withAlpha(0.70f));
            g.strokePath(cavityPath, juce::PathStrokeType(4.5f));

            // --------------------------------------------------------------------------
            // 3. LE 2 VALVOLE ECC83 (SINISTRA E DESTRA)
            // --------------------------------------------------------------------------
            auto drawECC83Tube = [&](float tubeCx)
            {
                const float tubeW = halfCavW * 0.65f;
                const float tubeH = cavH * 0.72f;
                const float tubeTopY = cy - tubeH * 0.52f;
                const float tubeBotY = tubeTopY + tubeH;

                // A. Griglia posteriore ventilazione (fessure orizzontali scure)
                for (float fy = tubeTopY + 12.0f; fy < tubeBotY - 20.0f; fy += 7.0f)
                {
                    g.setColour(juce::Colour::fromString("ff1a1510"));
                    g.drawLine(tubeCx - tubeW * 0.42f, fy, tubeCx + tubeW * 0.42f, fy, 2.0f);
                    g.setColour(juce::Colour::fromString("ff050403"));
                    g.drawLine(tubeCx - tubeW * 0.42f, fy - 1.0f, tubeCx + tubeW * 0.42f, fy - 1.0f, 1.0f);
                }

                // B. Bagliore dinamico filamento interno (Glow arancione/ambra)
                const float glowIntensity = 0.35f + saturation * 0.65f;
                const float filY = tubeTopY + tubeH * 0.42f;
                juce::ColourGradient filGlow(
                    juce::Colour::fromString("ffff8a1f").withAlpha(glowIntensity * 0.95f), tubeCx, filY,
                    juce::Colour::fromString("ffff3b00").withAlpha(0.0f), tubeCx, filY + tubeW * 0.9f, true);
                filGlow.addColour(0.35, juce::Colour::fromString("ffffb042").withAlpha(glowIntensity * 0.75f));
                filGlow.addColour(0.70, juce::Colour::fromString("ffcf4205").withAlpha(glowIntensity * 0.30f));
                g.setGradientFill(filGlow);
                g.fillEllipse(tubeCx - tubeW * 0.8f, filY - tubeW * 0.8f, tubeW * 1.6f, tubeW * 1.6f);

                // Filamenti interni incandescenti (Twin Triode - due anelli/bobine)
                for (float dx : { -tubeW * 0.15f, tubeW * 0.15f })
                {
                    g.setColour(juce::Colour::fromString("fffff7d6").withAlpha(0.85f + saturation * 0.15f));
                    g.drawLine(tubeCx + dx, filY - 8.0f, tubeCx + dx, filY + 8.0f, 2.2f);
                    g.setColour(juce::Colour::fromString("ffff851c"));
                    g.drawLine(tubeCx + dx, filY - 10.0f, tubeCx + dx, filY + 10.0f, 4.0f);
                }

                // C. Bulbo in vetro con cupola arrotondata
                juce::Rectangle<float> glassRect(tubeCx - tubeW * 0.40f, tubeTopY, tubeW * 0.80f, tubeH * 0.75f);
                juce::Path glassBulb;
                glassBulb.addRoundedRectangle(glassRect.getX(), glassRect.getY(), glassRect.getWidth(), glassRect.getHeight(),
                                              glassRect.getWidth() * 0.45f, glassRect.getWidth() * 0.45f,
                                              true, true, false, false);

                // Trasparenza vetro e riflesso speculare laterale (alpha 0.15)
                g.setColour(juce::Colours::white.withAlpha(0.12f));
                g.strokePath(glassBulb, juce::PathStrokeType(1.5f));

                // Calotta superiore cromata speculare (Flash gettering)
                juce::ColourGradient getterGrad(
                    juce::Colour::fromString("ffffffff"), tubeCx, glassRect.getY(),
                    juce::Colour::fromString("ff4d5258").withAlpha(0.1f), tubeCx, glassRect.getY() + 18.0f, false);
                g.setGradientFill(getterGrad);
                g.fillRoundedRectangle(glassRect.getX() + 3.0f, glassRect.getY(), glassRect.getWidth() - 6.0f, 15.0f, 6.0f);

                // Riflessi verticali speculari sul vetro (Alpha 0.15)
                g.setColour(juce::Colours::white.withAlpha(0.15f));
                g.fillRect(glassRect.getX() + 3.0f, glassRect.getY() + 14.0f, 2.5f, glassRect.getHeight() - 20.0f);
                g.setColour(juce::Colours::white.withAlpha(0.08f));
                g.fillRect(glassRect.getRight() - 5.0f, glassRect.getY() + 14.0f, 1.8f, glassRect.getHeight() - 20.0f);

                // D. Gabbia di protezione metallica (3 anelli orizzontali + 2 astine verticali)
                const float cageTop = glassRect.getY() + 15.0f;
                const float cageBot = glassRect.getBottom() - 4.0f;
                // Astine verticali
                g.setColour(juce::Colour::fromString("ff665c52"));
                g.drawLine(tubeCx - tubeW * 0.32f, cageTop, tubeCx - tubeW * 0.32f, cageBot, 1.5f);
                g.drawLine(tubeCx + tubeW * 0.32f, cageTop, tubeCx + tubeW * 0.32f, cageBot, 1.5f);
                // 3 Anelli orizzontali
                for (int rIdx = 0; rIdx < 3; ++rIdx)
                {
                    float ringY = cageTop + (cageBot - cageTop) * (0.25f + 0.25f * (float)rIdx);
                    g.setColour(juce::Colour::fromString("ff1a1612"));
                    g.drawEllipse(tubeCx - tubeW * 0.34f, ringY - 2.0f, tubeW * 0.68f, 5.0f, 1.8f);
                    g.setColour(juce::Colour::fromString("ff8c7d6b").withAlpha(0.7f));
                    g.drawEllipse(tubeCx - tubeW * 0.34f, ringY - 2.5f, tubeW * 0.68f, 5.0f, 0.8f);
                }

                // E. Zoccolo inferiore cilindrico metallo grigio + anello ottone
                const float baseH = tubeH * 0.22f;
                juce::Rectangle<float> socketRect(tubeCx - tubeW * 0.44f, glassRect.getBottom() - 4.0f, tubeW * 0.88f, baseH);
                juce::ColourGradient socketGrad(
                    juce::Colour::fromString("ff5c5a57"), socketRect.getX(), socketRect.getY(),
                    juce::Colour::fromString("ff21201f"), socketRect.getRight(), socketRect.getBottom(), false);
                g.setGradientFill(socketGrad);
                g.fillRoundedRectangle(socketRect, 3.0f);

                // Anello in ottone dello zoccolo
                juce::ColourGradient brassBand(
                    juce::Colour::fromString("ffd4af37"), socketRect.getX(), socketRect.getY(),
                    juce::Colour::fromString("ff544211"), socketRect.getX(), socketRect.getY() + 4.0f, false);
                g.setGradientFill(brassBand);
                g.fillRect(socketRect.getX(), socketRect.getY(), socketRect.getWidth(), 3.5f);

                // Testi serigrafati "ECC83" e "171 STUDIO"
                g.setColour(juce::Colour::fromString("ffffeed1").withAlpha(0.85f));
                g.setFont(juce::Font("Arial", 8.5f, juce::Font::bold));
                g.drawText("ECC83", socketRect.getX(), socketRect.getY() + 4.0f, socketRect.getWidth(), 9.0f, juce::Justification::centred);
                g.setFont(juce::Font("Arial", 6.5f, juce::Font::plain));
                g.setColour(juce::Colour::fromString("ffb8a78f").withAlpha(0.70f));
                g.drawText("171 STUDIO", socketRect.getX(), socketRect.getY() + 13.0f, socketRect.getWidth(), 8.0f, juce::Justification::centred);

                // 5 Piedini (Pins) dorati alla base
                const float pinW = 1.8f;
                const float pinH = 5.0f;
                const float pinY = socketRect.getBottom();
                for (int p = 0; p < 5; ++p)
                {
                    float px = socketRect.getX() + socketRect.getWidth() * (0.16f + 0.17f * (float)p);
                    g.setColour(juce::Colour::fromString("ffe0be60"));
                    g.fillRect(px - pinW * 0.5f, pinY, pinW, pinH);
                }
            };

            // Disegna le due valvole simmetriche
            drawECC83Tube(cx - tubeSpanX);
            drawECC83Tube(cx + tubeSpanX);

            // --------------------------------------------------------------------------
            // 4. LOGO CENTRALE ESAGONALE "171" CON GLOW REATTIVO SUL PONTE
            // --------------------------------------------------------------------------
            const float logoR = cavW * 0.11f;
            const float logoY = bridgeDropY + 4.0f;

            // Glow dietro al logo quando la saturazione aumenta
            if (saturation > 0.05f)
            {
                juce::ColourGradient logoGlow(
                    juce::Colour::fromString("ffff7b19").withAlpha(saturation * 0.75f), cx, logoY,
                    juce::Colour::fromString("ffff3b00").withAlpha(0.0f), cx, logoY + logoR * 1.8f, true);
                g.setGradientFill(logoGlow);
                g.fillEllipse(cx - logoR * 1.8f, logoY - logoR * 1.8f, logoR * 3.6f, logoR * 3.6f);
            }

            // Stemma esagonale in ottone brunito
            juce::Path hexBadge;
            for (int i = 0; i < 6; ++i)
            {
                float a = (float)i * juce::MathConstants<float>::twoPi / 6.0f + juce::MathConstants<float>::halfPi;
                float hx = cx + std::cos(a) * logoR;
                float hy = logoY + std::sin(a) * logoR;
                if (i == 0) hexBadge.startNewSubPath(hx, hy);
                else        hexBadge.lineTo(hx, hy);
            }
            hexBadge.closeSubPath();

            juce::ColourGradient badgeGrad(
                juce::Colour::fromString("ff2e2418"), cx, logoY - logoR,
                juce::Colour::fromString("ff140f09"), cx, logoY + logoR, false);
            g.setGradientFill(badgeGrad);
            g.fillPath(hexBadge);

            // Bordo dorato esagono
            g.setColour(juce::Colour::fromString("ffd6b467"));
            g.strokePath(hexBadge, juce::PathStrokeType(1.2f));

            // Testo monogramma "171"
            g.setColour(juce::Colour::fromString("ffffebad"));
            g.setFont(juce::Font("Arial", 9.5f, juce::Font::bold));
            g.drawText("171", cx - logoR, logoY - logoR, logoR * 2.0f, logoR * 2.0f, juce::Justification::centred);
        }

    private:
        float saturation = 0.0f;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DualTubeWindowComponent)
    };


    // ==============================================================================
    // 2. SPIE A GEMMA SFACCETTATA "JEWEL LIGHTS" A DIAMANTE
    // ==============================================================================
    class JewelLightRenderer
    {
    public:
        /**
         * @brief Disegna una spia a gemma sfaccettata skeuomorfica in stile vintage boutique.
         * 
         * @param g Contesto grafico JUCE.
         * @param bounds Area rettangolare contenente la gemma.
         * @param baseColour Colore base (es. ambra #ff8a14 o rubino #b81428).
         * @param brightness0to1 Luminosità: 0.0f = spenta (faccette scure fredde); 1.0f = accesa (faccette incadescenti, bloom).
         */
        static void drawFacetedJewelLight(juce::Graphics& g, juce::Rectangle<float> bounds,
                                          juce::Colour baseColour, float brightness0to1)
        {
            const float size = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx   = bounds.getCentreX();
            const float cy   = bounds.getCentreY();
            const float r    = size * 0.48f;
            const float b    = juce::jlimit(0.0f, 1.0f, brightness0to1);
            const bool  isOn = (b > 0.02f);

            // --------------------------------------------------------------------------
            // 1. GHIERA ESTERNA (BEZEL) IN OTTONE SCURO ZIGRINATA CON 6 MICRO-VITI
            // --------------------------------------------------------------------------
            // Ombra di contatto esterna fissa verso ore 5
            g.setColour(juce::Colours::black.withAlpha(0.65f));
            g.fillEllipse(cx - r + 1.8f, cy - r + 3.0f, r * 2.0f, r * 2.0f);

            // Alone bloom esterno sul metallo se la gemma è accesa
            if (isOn)
            {
                juce::ColourGradient bloom(
                    baseColour.withAlpha(b * 0.45f), cx, cy,
                    baseColour.withAlpha(0.0f), cx, cy + r * 1.55f, true);
                g.setGradientFill(bloom);
                g.fillEllipse(cx - r * 1.55f, cy - r * 1.55f, r * 3.1f, r * 3.1f);
            }

            // Anello esterno in ottone scuro
            juce::ColourGradient bezelGrad(
                juce::Colour::fromString("ff7a6136"), cx - r, cy - r,
                juce::Colour::fromString("ff261c0e"), cx + r, cy + r, false);
            g.setGradientFill(bezelGrad);
            g.fillEllipse(cx - r, cy - r, r * 2.0f, r * 2.0f);

            // Texture zigrinata a puntini concentrici sul collarino metallico
            const float rKnurlMid = r * 0.88f;
            const int knurlCount  = 28;
            for (int k = 0; k < knurlCount; ++k)
            {
                float a = (float)k * juce::MathConstants<float>::twoPi / (float)knurlCount;
                float kx = cx + std::cos(a) * rKnurlMid;
                float ky = cy + std::sin(a) * rKnurlMid;
                g.setColour(juce::Colour::fromString("ff171109"));
                g.fillEllipse(kx - 1.1f, ky - 1.1f, 2.2f, 2.2f);
                g.setColour(juce::Colour::fromString("ffd6b467").withAlpha(0.6f));
                g.fillEllipse(kx - 0.7f, ky - 0.7f, 1.2f, 1.2f);
            }

            // 6 Micro-viti distribuite ogni 60°
            const float rScrews = r * 0.90f;
            for (int s = 0; s < 6; ++s)
            {
                float sa = (float)s * juce::MathConstants<float>::twoPi / 6.0f + 0.26f;
                float sx = cx + std::cos(sa) * rScrews;
                float sy = cy + std::sin(sa) * rScrews;
                g.setColour(juce::Colour::fromString("ff1a130a"));
                g.fillEllipse(sx - 2.0f, sy - 2.0f, 4.0f, 4.0f);
                g.setColour(juce::Colour::fromString("ffe0c279"));
                g.fillEllipse(sx - 1.4f, sy - 1.4f, 2.8f, 2.8f);
                g.setColour(juce::Colour::fromString("ff332412"));
                g.drawLine(sx - 1.0f, sy - 0.5f, sx + 1.0f, sy + 0.5f, 0.8f);
            }

            // Anello interno concavo in oro lucido
            const float rInnerBezel = r * 0.74f;
            juce::ColourGradient innerBezel(
                juce::Colour::fromString("ffffeb99"), cx, cy - rInnerBezel,
                juce::Colour::fromString("ff423214"), cx, cy + rInnerBezel, false);
            g.setGradientFill(innerBezel);
            g.drawEllipse(cx - rInnerBezel, cy - rInnerBezel, rInnerBezel * 2.0f, rInnerBezel * 2.0f, 2.0f);

            // --------------------------------------------------------------------------
            // 2. LENTE A DIAMANTE PROCEDURALE (Poligoni, Triangoli e Losanghe)
            // --------------------------------------------------------------------------
            const float rGem = r * 0.70f;
            const float rCenterTable = rGem * 0.38f; // faccetta piana centrale

            // Sfondo della gemma
            juce::Colour gemBg = isOn ? baseColour.darker(0.3f) : baseColour.darker(0.75f).withMultipliedSaturation(0.5f);
            g.setColour(gemBg);
            g.fillEllipse(cx - rGem, cy - rGem, rGem * 2.0f, rGem * 2.0f);

            // Costruzione radiale a 8 spicchi con losanghe e triangoli
            const int numFacets = 8;
            for (int i = 0; i < numFacets; ++i)
            {
                float a1 = (float)i * juce::MathConstants<float>::twoPi / (float)numFacets;
                float a2 = (float)(i + 1) * juce::MathConstants<float>::twoPi / (float)numFacets;
                float aMid = (a1 + a2) * 0.5f;

                // Vertici corona esterna
                float xOut1 = cx + std::cos(a1) * rGem;
                float yOut1 = cy + std::sin(a1) * rGem;
                float xOut2 = cx + std::cos(a2) * rGem;
                float yOut2 = cy + std::sin(a2) * rGem;

                // Vertici anello intermedio (faccette a losanga)
                float rMid = (rGem + rCenterTable) * 0.5f;
                float xMid = cx + std::cos(aMid) * rMid;
                float yMid = cy + std::sin(aMid) * rMid;

                // Vertici faccetta piana centrale
                float xIn1 = cx + std::cos(a1) * rCenterTable;
                float yIn1 = cy + std::sin(a1) * rCenterTable;
                float xIn2 = cx + std::cos(a2) * rCenterTable;
                float yIn2 = cy + std::sin(a2) * rCenterTable;

                // Triangolo esterno 1
                juce::Path t1;
                t1.startNewSubPath(xOut1, yOut1);
                t1.lineTo(xMid, yMid);
                t1.lineTo(xIn1, yIn1);
                t1.closeSubPath();

                // Triangolo esterno 2
                juce::Path t2;
                t2.startNewSubPath(xMid, yMid);
                t2.lineTo(xOut2, yOut2);
                t2.lineTo(xIn2, yIn2);
                t2.closeSubPath();

                // Determinazione colore faccetta:
                float altTone = (i % 2 == 0) ? 0.22f : -0.15f;
                if (isOn)
                {
                    // Variazioni radianti brillanti
                    juce::Colour c1 = baseColour.brighter(altTone * b + 0.15f * b);
                    juce::Colour c2 = baseColour.darker((0.25f - altTone) * (1.0f - b * 0.5f));
                    g.setColour(c1);
                    g.fillPath(t1);
                    g.setColour(c2);
                    g.fillPath(t2);
                }
                else
                {
                    // Stato OFF: toni scuri desaturati con riflessi freddi
                    juce::Colour darkBase = baseColour.darker(0.70f).withMultipliedSaturation(0.45f);
                    g.setColour(darkBase.brighter(altTone * 0.3f));
                    g.fillPath(t1);
                    g.setColour(darkBase.darker(0.2f));
                    g.fillPath(t2);
                }

                // Linee di taglio diamante (spigoli sfaccettature)
                g.setColour(isOn ? juce::Colours::white.withAlpha(0.35f * b) : juce::Colours::white.withAlpha(0.08f));
                g.strokePath(t1, juce::PathStrokeType(0.8f));
                g.strokePath(t2, juce::PathStrokeType(0.8f));
            }

            // Faccetta centrale (Table facet)
            juce::Path centerFacet;
            for (int i = 0; i < numFacets; ++i)
            {
                float a = (float)i * juce::MathConstants<float>::twoPi / (float)numFacets;
                float px = cx + std::cos(a) * rCenterTable;
                float py = cy + std::sin(a) * rCenterTable;
                if (i == 0) centerFacet.startNewSubPath(px, py);
                else        centerFacet.lineTo(px, py);
            }
            centerFacet.closeSubPath();

            if (isOn)
            {
                // Cuore incandescente centrale
                juce::ColourGradient coreGlow(
                    juce::Colours::white.withAlpha(0.85f * b), cx, cy,
                    baseColour.brighter(0.5f).withAlpha(0.95f), cx, cy + rCenterTable, true);
                g.setGradientFill(coreGlow);
                g.fillPath(centerFacet);
            }
            else
            {
                g.setColour(baseColour.darker(0.65f).withMultipliedSaturation(0.5f));
                g.fillPath(centerFacet);
            }
            g.setColour(isOn ? juce::Colours::white.withAlpha(0.6f * b) : juce::Colours::white.withAlpha(0.12f));
            g.strokePath(centerFacet, juce::PathStrokeType(1.0f));

            // Due punti di luce bianca sui bordi (Specular Highlights a ore 10:30)
            g.setColour(juce::Colours::white.withAlpha(isOn ? 0.75f : 0.25f));
            g.fillEllipse(cx - rGem * 0.55f, cy - rGem * 0.55f, rGem * 0.22f, rGem * 0.14f);
            g.setColour(juce::Colours::white.withAlpha(isOn ? 0.50f : 0.15f));
            g.fillEllipse(cx + rGem * 0.35f, cy + rGem * 0.35f, rGem * 0.12f, rGem * 0.08f);

            // --------------------------------------------------------------------------
            // 3. LOGO CENTRALE "171" CON SOTTILE CONTORNO DORATO
            // --------------------------------------------------------------------------
            const float monogramBox = rCenterTable * 1.25f;
            auto logoRect = juce::Rectangle<float>(cx - monogramBox * 0.5f, cy - monogramBox * 0.5f, monogramBox, monogramBox);

            // Contorno dorato
            g.setColour(juce::Colour::fromString("ffd6b467").withAlpha(isOn ? 0.85f : 0.40f));
            g.setFont(juce::Font("Arial", monogramBox * 0.58f, juce::Font::bold));
            g.drawText("171", logoRect.translated(0.5f, 0.5f), juce::Justification::centred, false);

            // Monogramma scuro interno
            g.setColour(juce::Colour::fromString("ff1a1208").withAlpha(0.85f));
            g.drawText("171", logoRect, juce::Justification::centred, false);
        }
    };


    // ==============================================================================
    // 3. METER STEREO ORIZZONTALE A SEGMENTI LED "RMS / PEAK"
    // ==============================================================================
    class HorizontalBargraphMeter : public juce::Component
    {
    public:
        HorizontalBargraphMeter()
        {
            setOpaque(false);
        }

        /**
         * @brief Imposta i livelli stereo in dB (range da -60.0f a +6.0f dB).
         */
        void setLevels(float leftDb, float rightDb)
        {
            currentLeftDb  = juce::jlimit(-60.0f, 6.0f, leftDb);
            currentRightDb = juce::jlimit(-60.0f, 6.0f, rightDb);
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float w = bounds.getWidth();
            const float h = bounds.getHeight();

            // --------------------------------------------------------------------------
            // 1. CORNICE IN OTTONE METALLICO SPAZZOLATO CON DOPPIO FILETTO E 4 VITI
            // --------------------------------------------------------------------------
            // Ombra esterna telaio
            g.setColour(juce::Colours::black.withAlpha(0.60f));
            g.fillRoundedRectangle(bounds.translated(1.5f, 2.5f), 6.0f);

            // Telaio spazzolato orizzontalmente
            juce::ColourGradient frameGrad(
                juce::Colour::fromString("ff6b5535"), bounds.getX(), bounds.getY(),
                juce::Colour::fromString("ff261d10"), bounds.getX(), bounds.getBottom(), false);
            frameGrad.addColour(0.35, juce::Colour::fromString("ff9e804f"));
            frameGrad.addColour(0.70, juce::Colour::fromString("ff473720"));
            g.setGradientFill(frameGrad);
            g.fillRoundedRectangle(bounds, 6.0f);

            // Spazzolatura orizzontale
            for (float y = bounds.getY() + 2.0f; y < bounds.getBottom() - 2.0f; y += 2.0f)
            {
                float a = (std::fmod(y, 4.0f) < 2.0f) ? 0.05f : 0.02f;
                g.setColour(juce::Colours::white.withAlpha(a));
                g.drawHorizontalLine((int)y, bounds.getX() + 4.0f, bounds.getRight() - 4.0f);
            }

            // Doppio filetto dorato smussato
            g.setColour(juce::Colour::fromString("ffd6b467"));
            g.drawRoundedRectangle(bounds.reduced(1.5f), 5.0f, 1.2f);
            g.setColour(juce::Colour::fromString("ff423218"));
            g.drawRoundedRectangle(bounds.reduced(3.0f), 4.0f, 1.0f);

            // 4 Viti esagonali agli angoli
            const float screwDist = 10.0f;
            const struct { float x, y; } screws[] = {
                { bounds.getX() + screwDist,     bounds.getY() + screwDist },
                { bounds.getRight() - screwDist, bounds.getY() + screwDist },
                { bounds.getX() + screwDist,     bounds.getBottom() - screwDist },
                { bounds.getRight() - screwDist, bounds.getBottom() - screwDist }
            };

            for (const auto& sc : screws)
            {
                g.setColour(juce::Colour::fromString("ff140e08"));
                g.fillEllipse(sc.x - 3.2f, sc.y - 3.2f, 6.4f, 6.4f);
                g.setColour(juce::Colour::fromString("ffd1b066"));
                g.fillEllipse(sc.x - 2.2f, sc.y - 2.2f, 4.4f, 4.4f);
                g.setColour(juce::Colour::fromString("ff26190a"));
                g.drawLine(sc.x - 1.5f, sc.y - 1.0f, sc.x + 1.5f, sc.y + 1.0f, 1.0f);
            }

            // Testi incisi sul telaio
            g.setFont(juce::Font("Arial", 9.0f, juce::Font::bold));
            g.setColour(juce::Colour::fromString("ffe0c99d"));
            g.drawText("171 STUDIO", bounds.getX(), bounds.getY() + 3.0f, w, 11.0f, juce::Justification::centred);
            g.setFont(juce::Font("Arial", 8.0f, juce::Font::bold));
            g.drawText("L   171 STUDIO   R", bounds.getX(), bounds.getBottom() - 14.0f, w, 11.0f, juce::Justification::centred);

            // --------------------------------------------------------------------------
            // 2. SCHERMO INTERNO NERO OPACO INCASSATO
            // --------------------------------------------------------------------------
            const float screenInsetX = 22.0f;
            const float screenInsetY = 16.0f;
            auto screenRect = bounds.reduced(screenInsetX, screenInsetY);

            // Incasso profondo nero opaco (#141414)
            g.setColour(juce::Colour::fromString("ff141414"));
            g.fillRoundedRectangle(screenRect, 4.0f);

            // Ombra interna superiore/laterale
            g.setColour(juce::Colours::black.withAlpha(0.75f));
            g.drawRoundedRectangle(screenRect, 4.0f, 2.0f);
            g.setColour(juce::Colour::fromString("ff362816"));
            g.drawRoundedRectangle(screenRect.expanded(0.8f), 4.5f, 1.0f);

            // --------------------------------------------------------------------------
            // 3. SCALE GRADUATE E PALLINI INDICATORI DI SOGLIA
            // --------------------------------------------------------------------------
            const float meterPadX = 14.0f;
            const float meterAreaW = screenRect.getWidth() - meterPadX * 2.0f;
            const float meterX = screenRect.getX() + meterPadX;
            const float meterMidY = screenRect.getCentreY();

            const char* scaleLabels[] = { "-inf", "-60", "-40", "-30", "-24", "-18", "-15", "-12", "-9", "-6", "-3", "0", "+" };
            const float scaleDbs[]    = { -60.0f, -50.0f, -40.0f, -30.0f, -24.0f, -18.0f, -15.0f, -12.0f, -9.0f, -6.0f, -3.0f, 0.0f, 3.0f };
            const int numLabels = 13;

            g.setFont(juce::Font("Arial", 7.5f, juce::Font::plain));
            for (int i = 0; i < numLabels; ++i)
            {
                float normX = (float)i / (float)(numLabels - 1);
                float lx = meterX + normX * meterAreaW;

                // Testo superiore e inferiore
                g.setColour(juce::Colour::fromString("ff8f8a80"));
                g.drawText(scaleLabels[i], lx - 14.0f, screenRect.getY() + 3.0f, 28.0f, 9.0f, juce::Justification::centred);

                // Tacca di riferimento centrale
                g.setColour(juce::Colour::fromString("ff423e38"));
                g.drawLine(lx, meterMidY - 3.0f, lx, meterMidY + 3.0f, 1.0f);

                // Pallini luminosi indicatori di soglia tra -12 e 0 dB
                if (scaleDbs[i] >= -12.0f && scaleDbs[i] <= 0.0f)
                {
                    juce::Colour dotCol = (scaleDbs[i] >= -3.0f) ? juce::Colour::fromString("ffff5214") : juce::Colour::fromString("ffffbe42");
                    g.setColour(dotCol.withAlpha(0.85f));
                    g.fillEllipse(lx - 1.5f, meterMidY - 1.5f, 3.0f, 3.0f);
                }
            }

            // --------------------------------------------------------------------------
            // 4. BARRE A 32 SEGMENTI LED (CANALE LEFT IN ALTO, RIGHT IN BASSO)
            // --------------------------------------------------------------------------
            const int numSegments = 32;
            const float segH = (screenRect.getHeight() * 0.5f) - 18.0f;
            const float segGap = 1.5f;
            const float segW = (meterAreaW - (numSegments - 1) * segGap) / (float)numSegments;

            auto drawBargraphChannel = [&](float topY, float currentDb)
            {
                // Mappatura non-lineare standard dB (-60 dB -> 0, +6 dB -> 32 seg)
                float normLevel = 0.0f;
                if (currentDb > -60.0f)
                {
                    if (currentDb <= 0.0f)
                        normLevel = (currentDb + 60.0f) / 60.0f * 0.875f; // i primi 28 segmenti arrivano a 0 dB
                    else
                        normLevel = 0.875f + (currentDb / 6.0f) * 0.125f; // gli ultimi 4 segmenti sopra 0 dB
                }
                const int activeSegs = juce::roundToInt(normLevel * (float)numSegments);

                for (int s = 0; s < numSegments; ++s)
                {
                    float sx = meterX + (float)s * (segW + segGap);
                    auto segRect = juce::Rectangle<float>(sx, topY, segW, segH);
                    bool isLit = (s < activeSegs);

                    // Colore segmenti in base alla posizione dB:
                    // Seg 0..17 (-inf..-18 dB): bianco freddo brillante
                    // Seg 18..24 (-18..-6 dB): giallo/ambra
                    // Seg 25..27 (-6..0 dB): arancione/rosso
                    // Seg 28..31 (>0 dB): rosso picco / marrone scuro se spenti
                    juce::Colour litColour;
                    if (s < 18)       litColour = juce::Colour::fromString("fff0f4ff"); // Bianco freddo
                    else if (s < 25)  litColour = juce::Colour::fromString("ffffbe42"); // Giallo ambra
                    else if (s < 28)  litColour = juce::Colour::fromString("ffff4514"); // Arancio caldo
                    else              litColour = juce::Colour::fromString("ffff1c1c"); // Rosso picco

                    if (isLit)
                    {
                        // Alone luminoso dietro i segmenti accesi
                        juce::ColourGradient bloom(
                            litColour.withAlpha(0.40f), segRect.getCentreX(), segRect.getCentreY(),
                            litColour.withAlpha(0.0f), segRect.getCentreX(), segRect.getCentreY() + segH * 0.8f, true);
                        g.setGradientFill(bloom);
                        g.fillRoundedRectangle(segRect.expanded(2.0f), 2.5f);

                        // Corpo segmento acceso
                        g.setColour(litColour);
                        g.fillRoundedRectangle(segRect, 1.2f);

                        // Highlight superiore 1px
                        g.setColour(juce::Colours::white.withAlpha(0.70f));
                        g.fillRect(segRect.getX(), segRect.getY(), segRect.getWidth(), 1.0f);
                    }
                    else
                    {
                        // Segmento spento (marrone/grigio scuro opaco)
                        juce::Colour offColour = (s >= 28) ? juce::Colour::fromString("ff332414") : juce::Colour::fromString("ff1f1c19");
                        g.setColour(offColour);
                        g.fillRoundedRectangle(segRect, 1.2f);
                        g.setColour(juce::Colour::fromString("ff0d0c0a"));
                        g.drawRoundedRectangle(segRect, 1.2f, 0.6f);
                    }
                }
            };

            // Canale L (superiore) e Canale R (inferiore)
            drawBargraphChannel(screenRect.getY() + 14.0f, currentLeftDb);
            drawBargraphChannel(meterMidY + 6.0f, currentRightDb);

            // --------------------------------------------------------------------------
            // 5. VETRO RIFLETTENTE (OVERLAY DIAGONALE CON SFUMATURA ALPHA 0.09)
            // --------------------------------------------------------------------------
            juce::Path glassReflection;
            // Trapezio diagonale da basso-sinistra ad alto-destra
            glassReflection.startNewSubPath(screenRect.getX(), screenRect.getBottom());
            glassReflection.lineTo(screenRect.getX() + screenRect.getWidth() * 0.45f, screenRect.getBottom());
            glassReflection.lineTo(screenRect.getRight(), screenRect.getY() + screenRect.getHeight() * 0.15f);
            glassReflection.lineTo(screenRect.getRight(), screenRect.getY());
            glassReflection.lineTo(screenRect.getX() + screenRect.getWidth() * 0.35f, screenRect.getY());
            glassReflection.closeSubPath();

            juce::ColourGradient glassGrad(
                juce::Colours::white.withAlpha(0.12f), screenRect.getX(), screenRect.getY(),
                juce::Colours::white.withAlpha(0.01f), screenRect.getRight(), screenRect.getBottom(), false);
            g.setGradientFill(glassGrad);
            g.fillPath(glassReflection);
        }

    private:
        float currentLeftDb  = -60.0f;
        float currentRightDb = -60.0f;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(HorizontalBargraphMeter)
    };


    // ==============================================================================
    // 4. SELETTORE ROTATIVO A "BECCO" CON TACCA LED (LOOKANDFEEL_V4)
    // ==============================================================================
    class DropPointerKnobLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        DropPointerKnobLookAndFeel() {}

        void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                              float sliderPosProportional, float rotaryStartAngle, float rotaryEndAngle,
                              juce::Slider& slider) override
        {
            const auto bounds = juce::Rectangle<float>((float)x, (float)y, (float)width, (float)height);
            const float size  = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx    = bounds.getCentreX();
            const float cy    = bounds.getCentreY();
            const float rBase = size * 0.44f;

            // Angolo corrente di rotazione
            const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

            // --------------------------------------------------------------------------
            // 1. BASE CIRCOLARE FISSA (Gonna cilindrica con DropShadow verso ore 5)
            // --------------------------------------------------------------------------
            // Ombra portata fissa sul pannello
            g.setColour(juce::Colours::black.withAlpha(0.65f));
            g.fillEllipse(cx - rBase + 2.0f, cy - rBase + 4.0f, rBase * 2.0f, rBase * 2.0f);

            // Gonna inferiore cilindrica in metallo scuro
            juce::ColourGradient baseGrad(
                juce::Colour::fromString("ff36302a"), cx - rBase, cy - rBase,
                juce::Colour::fromString("ff141210"), cx + rBase, cy + rBase, false);
            g.setGradientFill(baseGrad);
            g.fillEllipse(cx - rBase, cy - rBase, rBase * 2.0f, rBase * 2.0f);

            // Bordo luce superiore gonna
            g.setColour(juce::Colour::fromString("ff6b5c4d").withAlpha(0.6f));
            g.drawEllipse(cx - rBase, cy - rBase, rBase * 2.0f, rBase * 2.0f, 1.2f);

            // --------------------------------------------------------------------------
            // 2. CORPO SAGOMATO RUOTANTE (Tamburo centrale, Ala posteriore, Becco anteriore)
            // --------------------------------------------------------------------------
            const float rDrum = rBase * 0.72f;
            const float beakLen = rBase * 0.98f;
            const float beakTipW = 3.5f;
            const float wingLen = rBase * 0.65f;
            const float wingW = rDrum * 0.85f;

            // Costruiamo il Path sagomato centrato in (0,0) puntato verso l'alto (ore 12)
            juce::Path pointerShape;

            // Punta affusolata del becco (in alto a y = -beakLen)
            pointerShape.startNewSubPath(-beakTipW * 0.5f, -beakLen);
            pointerShape.lineTo(beakTipW * 0.5f, -beakLen);

            // Raccordo fianco destro becco -> tamburo centrale
            pointerShape.lineTo(rDrum * 0.55f, -rDrum * 0.45f);
            pointerShape.cubicTo(rDrum * 0.92f, -rDrum * 0.15f,
                                 rDrum, rDrum * 0.35f,
                                 wingW * 0.5f, wingLen * 0.4f);

            // Ala posteriore squadrata con angoli smussati (contrappeso in basso)
            pointerShape.lineTo(wingW * 0.5f, wingLen);
            pointerShape.lineTo(-wingW * 0.5f, wingLen);

            // Raccordo fianco sinistro ala -> tamburo -> becco
            pointerShape.lineTo(-wingW * 0.5f, wingLen * 0.4f);
            pointerShape.cubicTo(-rDrum, rDrum * 0.35f,
                                 -rDrum * 0.92f, -rDrum * 0.15f,
                                 -rDrum * 0.55f, -rDrum * 0.45f);
            pointerShape.closeSubPath();

            // Traslazione e rotazione simultanea
            juce::Path transformedShape = pointerShape;
            transformedShape.applyTransform(juce::AffineTransform::rotation(angle).translated(cx, cy));

            // Ombra di contatto sotto il corpo ruotante
            juce::Path shadowShape = transformedShape;
            shadowShape.applyTransform(juce::AffineTransform::translation(1.5f, 2.5f));
            g.setColour(juce::Colours::black.withAlpha(0.50f));
            g.fillPath(shadowShape);

            // --------------------------------------------------------------------------
            // 3. MATERIALE CANNA DI FUCILE E PROFILO FILETTATO IN OTTONE
            // --------------------------------------------------------------------------
            juce::ColourGradient bodyGrad(
                juce::Colour::fromString("ff3b3530"), cx, cy - rBase,
                juce::Colour::fromString("ff1f1b18"), cx, cy + rBase, false);
            bodyGrad.addColour(0.40, juce::Colour::fromString("ff2d2824"));
            g.setGradientFill(bodyGrad);
            g.fillPath(transformedShape);

            // Profilo dorato lungo il bordo interno (1.5px)
            g.setColour(juce::Colour::fromString("ff9e7b46"));
            g.strokePath(transformedShape, juce::PathStrokeType(1.5f));

            // Bordo luce superiore 0.8px
            g.setColour(juce::Colour::fromString("ffd4b272").withAlpha(0.65f));
            g.strokePath(transformedShape, juce::PathStrokeType(0.8f));

            // --------------------------------------------------------------------------
            // 4. TACCA LED INCANDESCENTE SULLA PUNTA DEL BECCO (#ff9d2e)
            // --------------------------------------------------------------------------
            juce::Path ledNotch;
            const float notchW = 2.2f;
            const float notchTopY = -beakLen + 2.0f;
            const float notchBotY = -rDrum * 0.40f;

            ledNotch.startNewSubPath(-notchW * 0.5f, notchTopY);
            ledNotch.lineTo(notchW * 0.5f, notchTopY);
            ledNotch.lineTo(notchW * 0.5f, notchBotY);
            ledNotch.lineTo(-notchW * 0.5f, notchBotY);
            ledNotch.closeSubPath();

            juce::Path transformedNotch = ledNotch;
            transformedNotch.applyTransform(juce::AffineTransform::rotation(angle).translated(cx, cy));

            // Alone luminoso sfumato (Glow arancione neon)
            juce::Path glowNotch = transformedNotch;
            g.setColour(juce::Colour::fromString("ffff7a00").withAlpha(0.55f));
            g.strokePath(glowNotch, juce::PathStrokeType(5.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Fessura LED accesa (#ff9d2e)
            g.setColour(juce::Colour::fromString("ffff9d2e"));
            g.fillPath(transformedNotch);

            // Centro incandescente bianco/giallo 1px
            g.setColour(juce::Colour::fromString("fffff1b8"));
            g.strokePath(transformedNotch, juce::PathStrokeType(1.0f));

            // --------------------------------------------------------------------------
            // 5. CAPPUCCIO CENTRALE (Standard concavo vs Master con logo "171")
            // --------------------------------------------------------------------------
            const float rCap = rDrum * 0.62f;
            const bool isMaster = slider.getComponentID().containsIgnoreCase("master");

            // Disco metallo spazzolato
            juce::ColourGradient capGrad(
                juce::Colour::fromString("ff423a31"), cx - rCap, cy - rCap,
                juce::Colour::fromString("ff171411"), cx + rCap, cy + rCap, false);
            g.setGradientFill(capGrad);
            g.fillEllipse(cx - rCap, cy - rCap, rCap * 2.0f, rCap * 2.0f);

            // Bordo ottone dorato
            g.setColour(juce::Colour::fromString("ffd6b467"));
            g.drawEllipse(cx - rCap, cy - rCap, rCap * 2.0f, rCap * 2.0f, 1.2f);

            if (isMaster)
            {
                // VARIANTE MASTER (Manopole esterne): logo "171" inciso
                g.setColour(juce::Colour::fromString("ff120e09"));
                g.setFont(juce::Font("Arial", rCap * 0.72f, juce::Font::bold));
                g.drawText("171", cx - rCap, cy - rCap + 0.8f, rCap * 2.0f, rCap * 2.0f, juce::Justification::centred);
                g.setColour(juce::Colour::fromString("ffd6b467").withAlpha(0.85f));
                g.drawText("171", cx - rCap, cy - rCap, rCap * 2.0f, rCap * 2.0f, juce::Justification::centred);
            }
            else
            {
                // VARIANTE STANDARD (Manopole centrali): perno concavo in ottone dorato lucido
                const float rPin = rCap * 0.45f;
                juce::ColourGradient pinGrad(
                    juce::Colour::fromString("ff2b1f0e"), cx, cy - rPin,
                    juce::Colour::fromString("ffd4af37"), cx, cy + rPin, false);
                g.setGradientFill(pinGrad);
                g.fillEllipse(cx - rPin, cy - rPin, rPin * 2.0f, rPin * 2.0f);
                g.setColour(juce::Colour::fromString("fffff2b3").withAlpha(0.8f));
                g.drawEllipse(cx - rPin, cy - rPin, rPin * 2.0f, rPin * 2.0f, 0.8f);
            }
        }
    };
}
