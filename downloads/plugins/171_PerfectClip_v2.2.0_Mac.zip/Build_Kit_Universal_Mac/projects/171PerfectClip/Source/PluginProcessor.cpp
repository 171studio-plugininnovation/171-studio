#include "PluginProcessor.h"
#include "GUI/171PerfectClipEditor.h"

PerfectClipAudioProcessor::PerfectClipAudioProcessor()
    : AudioProcessor(BusesProperties()
                     .withInput("Input", juce::AudioChannelSet::stereo(), true)
                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "PARAMETERS", createParameterLayout())
{
    inGainParam        = apvts.getRawParameterValue("inGain");
    ceilingParam       = apvts.getRawParameterValue("ceiling");
    outGainParam       = apvts.getRawParameterValue("outGain");
    clipModeParam      = apvts.getRawParameterValue("clipMode");
    softKneeParam      = apvts.getRawParameterValue("softKnee");
    transDetailParam   = apvts.getRawParameterValue("transDetail");
    alchemyAirParam    = apvts.getRawParameterValue("alchemyAir");
    routingParam       = apvts.getRawParameterValue("routing");
    monoMakerParam     = apvts.getRawParameterValue("monoMaker");
    monoMakerFreqParam = apvts.getRawParameterValue("monoMakerFreq");
    truePeakParam      = apvts.getRawParameterValue("truePeak");
    deltaAuditionParam = apvts.getRawParameterValue("deltaAudition");
    bypassParam        = apvts.getRawParameterValue("bypass");
}

PerfectClipAudioProcessor::~PerfectClipAudioProcessor() = default;

juce::AudioProcessorValueTreeState::ParameterLayout PerfectClipAudioProcessor::createParameterLayout() {
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // In Gain: [-24, +24 dB]
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "inGain", 1 }, "Drive",
        juce::NormalisableRange<float>(-24.0f, 24.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes()
            .withLabel("dB")
            .withStringFromValueFunction([](float val, int) {
                return (val >= 0.0f ? "+" : "") + juce::String(val, 1) + " dB";
            })
            .withValueFromStringFunction([](const juce::String& text) {
                return text.upToFirstOccurrenceOf("dB", false, false).getFloatValue();
            })));

    // Ceiling: [-24, 0 dBFS]
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "ceiling", 1 }, "Ceiling",
        juce::NormalisableRange<float>(-24.0f, 0.0f, 0.1f), -0.1f,
        juce::AudioParameterFloatAttributes()
            .withLabel("dBFS")
            .withStringFromValueFunction([](float val, int) {
                return juce::String(val, 1) + " dBFS";
            })
            .withValueFromStringFunction([](const juce::String& text) {
                return text.upToFirstOccurrenceOf("dBFS", false, false).getFloatValue();
            })));

    // Out Trim: [-24, +24 dB]
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "outGain", 1 }, "Output Trim",
        juce::NormalisableRange<float>(-24.0f, 24.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes()
            .withLabel("dB")
            .withStringFromValueFunction([](float val, int) {
                return (val >= 0.0f ? "+" : "") + juce::String(val, 1) + " dB";
            })
            .withValueFromStringFunction([](const juce::String& text) {
                return text.upToFirstOccurrenceOf("dB", false, false).getFloatValue();
            })));

    // Clipper Mode: 0: Precision Digital, 1: Gold Converter 122, 2: Tube Triode, 3: Germanium Diode
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{ "clipMode", 1 }, "Topology",
        juce::StringArray{ "Digital Hard (ADAA-2)", "Gold ADC 122 (Lavry Gold)", "Tube Triode Class-A", "Germanium Diode" }, 0));

    // Soft Knee: [0% to 100%]
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "softKnee", 1 }, "Soft Knee",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.0f,
        juce::AudioParameterFloatAttributes()
            .withLabel("%")
            .withStringFromValueFunction([](float val, int) {
                return juce::String(std::round(val * 100.0f), 0) + " %";
            })
            .withValueFromStringFunction([](const juce::String& text) {
                return text.upToFirstOccurrenceOf("%", false, false).getFloatValue() * 0.01f;
            })));

    // 171 TransDetail Preservation: [0% to 100%]
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "transDetail", 1 }, "Detail Preserve",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 1.0f,
        juce::AudioParameterFloatAttributes()
            .withLabel("%")
            .withStringFromValueFunction([](float val, int) {
                return juce::String(std::round(val * 100.0f), 0) + " %";
            })
            .withValueFromStringFunction([](const juce::String& text) {
                return text.upToFirstOccurrenceOf("%", false, false).getFloatValue() * 0.01f;
            })));

    // Alchemy Air: [-6 to +6 dB]
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "alchemyAir", 1 }, "Alchemy Air",
        juce::NormalisableRange<float>(-6.0f, 6.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes()
            .withLabel("dB")
            .withStringFromValueFunction([](float val, int) {
                return (val >= 0.0f ? "+" : "") + juce::String(val, 1) + " dB";
            })
            .withValueFromStringFunction([](const juce::String& text) {
                return text.upToFirstOccurrenceOf("dB", false, false).getFloatValue();
            })));

    // Routing: 0: Stereo L/R, 1: Mid/Side Split, 2: Mid Only, 3: Side Only
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{ "routing", 1 }, "Routing",
        juce::StringArray{ "Stereo L/R", "Mid/Side Split", "Mid Only", "Side Only" }, 0));

    // MonoMaker Enable
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{ "monoMaker", 1 }, "Mono Maker", true));

    // MonoMaker Frequency: [20 to 200 Hz]
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ "monoMakerFreq", 1 }, "Mono Freq",
        juce::NormalisableRange<float>(20.0f, 200.0f, 1.0f, 0.4f), 80.0f,
        juce::AudioParameterFloatAttributes().withLabel("Hz")));

    // True Peak Guard
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{ "truePeak", 1 }, "True-Peak Guard", true));

    // Delta Audition Mode
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{ "deltaAudition", 1 }, "Delta Audition", false));

    // Bypass
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{ "bypass", 1 }, "Bypass", false));

    return { params.begin(), params.end() };
}

void PerfectClipAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock) {
    engine.prepare(sampleRate, static_cast<size_t>(samplesPerBlock));
    updateEngineParameters();
}

void PerfectClipAudioProcessor::releaseResources() {
    engine.reset();
}

bool PerfectClipAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const {
    const auto& mainIn = layouts.getMainInputChannelSet();
    const auto& mainOut = layouts.getMainOutputChannelSet();

    if (mainIn != juce::AudioChannelSet::mono() && mainIn != juce::AudioChannelSet::stereo())
        return false;

    return mainIn == mainOut;
}

void PerfectClipAudioProcessor::updateEngineParameters() noexcept {
    if (inGainParam != nullptr)
        engine.setInputGainDb(inGainParam->load(std::memory_order_relaxed));

    if (ceilingParam != nullptr)
        engine.setCeilingDb(ceilingParam->load(std::memory_order_relaxed));

    if (outGainParam != nullptr)
        engine.setOutputGainDb(outGainParam->load(std::memory_order_relaxed));

    if (clipModeParam != nullptr) {
        const int mode = static_cast<int>(clipModeParam->load(std::memory_order_relaxed));
        engine.setClipperMode(static_cast<dsp171::ClipperMode>(std::clamp(mode, 0, 3)));
    }

    if (softKneeParam != nullptr)
        engine.setSoftKnee(softKneeParam->load(std::memory_order_relaxed));

    if (transDetailParam != nullptr)
        engine.setDetailPreservation(transDetailParam->load(std::memory_order_relaxed));

    if (alchemyAirParam != nullptr)
        engine.setAlchemyAirDb(alchemyAirParam->load(std::memory_order_relaxed));

    if (routingParam != nullptr) {
        const int route = static_cast<int>(routingParam->load(std::memory_order_relaxed));
        engine.setRouting(static_cast<dsp171::ChannelRouting>(std::clamp(route, 0, 3)));
    }

    if (monoMakerParam != nullptr && monoMakerFreqParam != nullptr) {
        const bool mmOn = monoMakerParam->load(std::memory_order_relaxed) > 0.5f;
        const float mmFreq = monoMakerFreqParam->load(std::memory_order_relaxed);
        engine.setMonoMaker(mmOn, mmFreq);
    }

    if (truePeakParam != nullptr) {
        const bool tpOn = truePeakParam->load(std::memory_order_relaxed) > 0.5f;
        engine.setTruePeakGuard(tpOn);
        const int targetLatency = static_cast<int>(engine.getLatencySamples());
        if (getLatencySamples() != targetLatency) {
            setLatencySamples(targetLatency);
        }
    }

    if (deltaAuditionParam != nullptr)
        engine.setDeltaAudition(deltaAuditionParam->load(std::memory_order_relaxed) > 0.5f);
}

void PerfectClipAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages) {
    juce::ignoreUnused(midiMessages);
    juce::ScopedNoDenormals noDenormals;

    const int totalNumInputChannels  = getTotalNumInputChannels();
    const int totalNumOutputChannels = getTotalNumOutputChannels();
    const int numSamples = buffer.getNumSamples();

    for (int i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear(i, 0, numSamples);

    if (numSamples == 0) return;

    const bool isBypassed = (bypassParam != nullptr && bypassParam->load(std::memory_order_relaxed) > 0.5f);
    if (isBypassed) return;

    updateEngineParameters();

    float* leftData = buffer.getWritePointer(0);
    float* rightData = (totalNumInputChannels > 1) ? buffer.getWritePointer(1) : nullptr;

    engine.processBlock(leftData, rightData, static_cast<size_t>(numSamples));
}

juce::AudioProcessorEditor* PerfectClipAudioProcessor::createEditor() {
    return new dsp171::PerfectClipEditor(*this);
}

void PerfectClipAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void PerfectClipAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType())) {
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
    }
}

// Juce Plugin instantiation entry point
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new PerfectClipAudioProcessor();
}
