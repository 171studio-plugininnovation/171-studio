#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <array>
#include <cmath>
#include <algorithm>
#include <dsp171/PerfectClipEngine.h>

namespace dsp171 {

class PerfectClipCRTScope : public juce::Component,
                            private juce::Timer
{
public:
    static constexpr size_t NUM_POINTS = 256;

    PerfectClipCRTScope(PerfectClipEngine& engineToRead)
        : engine(engineToRead)
    {
        setOpaque(true);
        phosphorUpper.fill(0.0f);
        phosphorLower.fill(0.0f);
        deltaPersistence.fill(0.0f);
        startTimerHz(60); // 60 FPS ultra-smooth CRT refresh
    }

    ~PerfectClipCRTScope() override {
        stopTimer();
    }

    void setCeilingLinear(float ceilingLin) noexcept {
        currentCeiling = std::clamp(ceilingLin, 0.01f, 1.0f);
    }

    void setGoldMode(bool isGold) noexcept {
        goldMode = isGold;
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const float w = bounds.getWidth();
        const float h = bounds.getHeight();
        if (w < 10.0f || h < 10.0f) return;

        // 1. Inset Dark CRT Screen Bezel
        g.setColour(juce::Colour(0xFF090B0E));
        g.fillRoundedRectangle(bounds, 6.0f);

        juce::ColourGradient crtGrad(juce::Colour(0xFF0E141D), w * 0.5f, h * 0.5f,
                                    juce::Colour(0xFF040608), 0.0f, 0.0f, true);
        g.setGradientFill(crtGrad);
        g.fillRoundedRectangle(bounds.reduced(1.5f), 5.0f);

        // Metallic precision chassis border
        g.setColour(juce::Colour(0xFF1E2530));
        g.drawRoundedRectangle(bounds.reduced(0.5f), 6.0f, 1.0f);

        // 2. Tektronix Laboratory Precision Graticule
        const float plotLeft = 6.0f;
        const float plotRight = w - 6.0f;
        const float plotTop = 26.0f;
        const float plotBottom = h - 6.0f;
        const float plotW = plotRight - plotLeft;
        const float plotH = plotBottom - plotTop;
        const float midY = plotTop + plotH * 0.5f;
        const float ampScale = plotH * 0.48f;

        // Subdued graticule grid lines
        g.setColour(juce::Colour(0x1200E5FF)); // Subdued cyan
        constexpr int numVLines = 10;
        for (int i = 1; i < numVLines; ++i) {
            float x = plotLeft + plotW * (static_cast<float>(i) / numVLines);
            g.drawVerticalLine(static_cast<int>(x), plotTop, plotBottom);
        }

        constexpr int numHLines = 6;
        for (int i = 1; i < numHLines; ++i) {
            float y = plotTop + plotH * (static_cast<float>(i) / numHLines);
            g.drawHorizontalLine(static_cast<int>(y), plotLeft, plotRight);
        }

        // Sub-division tick marks along center crosshairs (Tektronix style)
        g.setColour(juce::Colour(0x2400E5FF));
        for (int i = 0; i <= 50; ++i) {
            float x = plotLeft + plotW * (static_cast<float>(i) / 50.0f);
            float tickH = (i % 5 == 0) ? 4.0f : 2.0f;
            g.drawVerticalLine(static_cast<int>(x), midY - tickH, midY + tickH);
        }
        for (int i = 0; i <= 30; ++i) {
            float y = plotTop + plotH * (static_cast<float>(i) / 30.0f);
            float tickW = (i % 5 == 0) ? 4.0f : 2.0f;
            g.drawHorizontalLine(static_cast<int>(y), plotLeft + plotW * 0.5f - tickW, plotLeft + plotW * 0.5f + tickW);
        }

        // Zero AC Center Line
        g.setColour(juce::Colour(0x3500E5FF));
        g.drawHorizontalLine(static_cast<int>(midY), plotLeft, plotRight);

        // 3. Positive & Negative Clipping Ceiling Reference Lines
        const float ceilYPos = midY - currentCeiling * ampScale;
        const float ceilYNeg = midY + currentCeiling * ampScale;

        g.setColour(juce::Colour(0x75FF9100)); // Glowing Amber dashed reference lines
        float dashPattern[2] = { 4.0f, 3.0f };
        g.drawDashedLine(juce::Line<float>(plotLeft, ceilYPos, plotRight, ceilYPos), dashPattern, 2, 1.2f);
        g.drawDashedLine(juce::Line<float>(plotLeft, ceilYNeg, plotRight, ceilYNeg), dashPattern, 2, 1.2f);

        // 4. Capture Scope Snapshot from Audio Engine Lock-Free Buffer
        engine.copyScopeSnapshot(scopeSnapshot);
        const auto telemetry = engine.getTelemetry();

        if (telemetry.isClippingNow || telemetry.maxGainReductionDb > 0.05f) {
            clipLedDecay = 1.0f;
        }

        // 5. Build Waveform Paths & Update Phosphor Persistence
        constexpr size_t N = PerfectClipEngine::SCOPE_BUFFER_SIZE;

        normalPath.clear();
        preClipGhostPath.clear();
        clippedDeltaPath.clear();
        persistencePathUpper.clear();
        persistencePathLower.clear();

        bool hasPreClipDelta = false;

        for (size_t pt = 0; pt < NUM_POINTS; ++pt) {
            const float normX = static_cast<float>(pt) / static_cast<float>(NUM_POINTS - 1);
            const float px = plotLeft + normX * plotW;

            const size_t sampleIdx = (pt * N) / NUM_POINTS;
            const auto& sample = scopeSnapshot[sampleIdx];

            const float outVal = std::clamp(sample.outSample, -1.4f, 1.4f);
            const float inVal  = std::clamp(sample.inSample,  -1.4f, 1.4f);
            const float pyOut  = midY - outVal * ampScale;
            const float pyIn   = midY - inVal * ampScale;

            // Update P31 phosphor persistence envelope
            if (outVal >= 0.0f)
                phosphorUpper[pt] = std::max(phosphorUpper[pt], outVal);
            else
                phosphorLower[pt] = std::min(phosphorLower[pt], outVal);

            if (pt == 0) {
                normalPath.startNewSubPath(px, pyOut);
                preClipGhostPath.startNewSubPath(px, pyIn);
                persistencePathUpper.startNewSubPath(px, midY - phosphorUpper[pt] * ampScale);
                persistencePathLower.startNewSubPath(px, midY - phosphorLower[pt] * ampScale);
            } else {
                normalPath.lineTo(px, pyOut);
                preClipGhostPath.lineTo(px, pyIn);
                persistencePathUpper.lineTo(px, midY - phosphorUpper[pt] * ampScale);
                persistencePathLower.lineTo(px, midY - phosphorLower[pt] * ampScale);
            }

            // Delta spikes (shaved peaks beyond ceiling)
            const float deltaAbs = std::abs(inVal - outVal);
            if (sample.clipped || deltaAbs > 0.005f || std::abs(inVal) >= currentCeiling) {
                deltaPersistence[pt] = std::max(deltaPersistence[pt], deltaAbs);
                clippedDeltaPath.startNewSubPath(px, pyOut);
                clippedDeltaPath.lineTo(px, pyIn);
                hasPreClipDelta = true;
            } else if (deltaPersistence[pt] > 0.01f) {
                // Persistent delta spark trail
                float peakInPersistent = (inVal >= 0.0f) ? (outVal + deltaPersistence[pt]) : (outVal - deltaPersistence[pt]);
                float pyPersistentIn = midY - std::clamp(peakInPersistent, -1.4f, 1.4f) * ampScale;
                clippedDeltaPath.startNewSubPath(px, pyOut);
                clippedDeltaPath.lineTo(px, pyPersistentIn);
            }
        }

        // 6. Render Phosphor Persistence Trail (P31 Decay Glow)
        g.setColour(juce::Colour(0x1800E5FF)); // Soft cyan phosphor decay halo
        g.strokePath(persistencePathUpper, juce::PathStrokeType(2.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        g.strokePath(persistencePathLower, juce::PathStrokeType(2.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // 7. Dual-Trace Rendering: Pre-Clip Ghost Trace (Light Blue when clipping)
        if (hasPreClipDelta || clipLedDecay > 0.1f) {
            g.setColour(juce::Colour(0x3540C4FF)); // Ghost unclipped trace
            g.strokePath(preClipGhostPath, juce::PathStrokeType(1.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }

        // 8. Draw Main Post-Clipped Audio Waveform
        g.setColour(juce::Colour(0x3000E5FF)); // Soft beam halo
        g.strokePath(normalPath, juce::PathStrokeType(3.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        g.setColour(juce::Colour(0xFF00E5FF)); // Crisp focused electron beam
        g.strokePath(normalPath, juce::PathStrokeType(1.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // 9. Draw Clipped Delta Sparks in Intense Amber / Neon Red
        if (!clippedDeltaPath.isEmpty()) {
            g.setColour(juce::Colour(0x80FF3D00)); // Amber/red bloom
            g.strokePath(clippedDeltaPath, juce::PathStrokeType(3.0f, juce::PathStrokeType::mitered));

            g.setColour(juce::Colour(0xFFFF9100)); // Crisp spark core
            g.strokePath(clippedDeltaPath, juce::PathStrokeType(1.6f, juce::PathStrokeType::mitered));
        }

        // 10. Real-Time Telemetry On-Screen Display (HUD)
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 9.5f, juce::Font::bold)));

        // Left HUD: Signal Levels (Compact & Clean)
        juce::String inOutTxt = juce::String::formatted("IN: %.1f | OUT: %.1f", telemetry.inPeakDbL, telemetry.outPeakDbL);
        g.setColour(juce::Colour(0xFF88A0B8));
        g.drawText(inOutTxt, 8, 6, 150, 16, juce::Justification::left);

        // Center HUD: Gold 122 Active Badge
        if (goldMode) {
            g.setColour(juce::Colour(0xFFFFD54F)); // Radiant warm gold
            g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 9.0f, juce::Font::bold)));
            g.drawText(juce::String::fromUTF8("\xe2\x9c\xa6 GOLD 122 \xe2\x9c\xa6"),
                       155, 6, static_cast<int>(w) - 295, 16, juce::Justification::centred);
        }

        // Right HUD: Crest Factor
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 9.5f, juce::Font::bold)));
        juce::String rightTxt = juce::String::formatted("CREST: %.1f dB", telemetry.crestFactorDb);
        g.setColour(juce::Colour(0xFF00E5FF));
        g.drawText(rightTxt, static_cast<int>(w) - 138, 6, 85, 16, juce::Justification::right);

        // Hardware-Style Ruby Clipping Flash LED on Top-Right Bezel
        const float ledX = w - 46.0f;
        const float ledY = 9.0f;
        const float ledDiam = 8.0f;

        if (clipLedDecay > 0.05f) {
            // Active Incandescent Ruby Flash with Radial Bloom
            juce::Colour rubyCol = juce::Colour(0xFFFF1744).interpolatedWith(juce::Colour(0xFFFF9100), clipLedDecay * 0.4f);
            g.setColour(rubyCol.withAlpha(clipLedDecay * 0.45f));
            g.fillEllipse(ledX - 3.0f, ledY - 3.0f, ledDiam + 6.0f, ledDiam + 6.0f);

            g.setColour(rubyCol);
            g.fillEllipse(ledX, ledY, ledDiam, ledDiam);

            // Specular hot spot
            g.setColour(juce::Colours::white.withAlpha(clipLedDecay * 0.85f));
            g.fillEllipse(ledX + 2.0f, ledY + 1.5f, 2.8f, 2.8f);

            g.setColour(juce::Colour(0xFFFF5252));
        } else {
            // Dark Smoked Ruby Socket
            g.setColour(juce::Colour(0xFF240A0E));
            g.fillEllipse(ledX, ledY, ledDiam, ledDiam);
            g.setColour(juce::Colour(0xFF3A181E));
            g.drawEllipse(ledX, ledY, ledDiam, ledDiam, 1.0f);

            g.setColour(juce::Colour(0xFF6A7482));
        }

        // Silkscreen "CLIP" label next to the LED
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 8.5f, juce::Font::bold)));
        g.drawText("CLIP", static_cast<int>(w) - 34, 6, 28, 16, juce::Justification::left);
    }

private:
    void timerCallback() override {
        // Phosphor persistence decay (tau ~ 130ms at 60 FPS -> 0.87)
        constexpr float decay = 0.87f;
        for (size_t i = 0; i < NUM_POINTS; ++i) {
            phosphorUpper[i] *= decay;
            phosphorLower[i] *= decay;
            deltaPersistence[i] *= decay;
        }

        // Smooth analog ballistics for peak clip flash
        clipLedDecay = std::max(0.0f, clipLedDecay * 0.88f);

        repaint();
    }

    PerfectClipEngine& engine;
    float currentCeiling = 1.0f;
    bool goldMode = false;
    float clipLedDecay = 0.0f;

    std::array<PerfectClipEngine::ScopeSample, PerfectClipEngine::SCOPE_BUFFER_SIZE> scopeSnapshot{};
    std::array<float, NUM_POINTS> phosphorUpper{};
    std::array<float, NUM_POINTS> phosphorLower{};
    std::array<float, NUM_POINTS> deltaPersistence{};

    juce::Path normalPath;
    juce::Path preClipGhostPath;
    juce::Path clippedDeltaPath;
    juce::Path persistencePathUpper;
    juce::Path persistencePathLower;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PerfectClipCRTScope)
};

} // namespace dsp171
