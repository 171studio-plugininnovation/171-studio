#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <algorithm>

namespace plugin_171 {

// ==============================================================================
// BARRA E ANGOLARE DI RIDIMENSIONAMENTO DINAMICO BOUTIQUE 171
// Base: 960x600 (16:10) con aspect ratio lock, grip in ottone a 45°
// ==============================================================================
class ResizableHandleComponent : public juce::Component {
public:
    std::function<void(float currentScale)> onScaleChanged;

    ResizableHandleComponent() {
        setMouseCursor(juce::MouseCursor::BottomRightCornerResizeCursor);
    }

    ~ResizableHandleComponent() override = default;

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat();
        if (bounds.isEmpty()) return;

        const float w = bounds.getWidth();
        const float h = bounds.getHeight();

        // Scanalature d'ombra a 45 gradi
        g.setColour(juce::Colour(0x70000000));
        g.drawLine(w - 4.0f, h, w, h - 4.0f, 1.6f);
        g.drawLine(w - 8.0f, h, w, h - 8.0f, 1.6f);
        g.drawLine(w - 12.0f, h, w, h - 12.0f, 1.6f);
        g.drawLine(w - 16.0f, h, w, h - 16.0f, 1.6f);

        // Rilievi cesellati in foglia d'oro / ottone 171
        g.setColour(isHovered ? juce::Colour(0xffffe899) : juce::Colour(0xffc5a059));
        g.drawLine(w - 5.0f, h, w, h - 5.0f, 1.3f);
        g.drawLine(w - 9.0f, h, w, h - 9.0f, 1.3f);
        g.drawLine(w - 13.0f, h, w, h - 13.0f, 1.3f);
        g.drawLine(w - 17.0f, h, w, h - 17.0f, 1.3f);
    }

    void mouseEnter(const juce::MouseEvent&) override {
        isHovered = true;
        repaint();
    }

    void mouseExit(const juce::MouseEvent&) override {
        isHovered = false;
        repaint();
    }

    void mouseDown(const juce::MouseEvent& e) override {
        if (auto* parent = findEditorParent()) {
            originalSize = parent->getBounds();
            dragStartPos = e.getScreenPosition();
            isDragging = true;
            repaint();
        }
    }

    void mouseDrag(const juce::MouseEvent& e) override {
        if (!isDragging) return;
        if (auto* parent = findEditorParent()) {
            auto delta = e.getScreenPosition() - dragStartPos;

            constexpr float baseWidth   = 960.0f;
            constexpr float baseHeight  = 580.0f;
            constexpr float aspectRatio = baseWidth / baseHeight;

            float proposedWidth = static_cast<float>(originalSize.getWidth() + delta.x);
            float minW = baseWidth  * 0.75f;
            float maxW = baseWidth  * 2.00f;
            proposedWidth = std::clamp(proposedWidth, minW, maxW);

            float proposedHeight = proposedWidth / aspectRatio;
            float scale = proposedWidth / baseWidth;

            parent->setSize(static_cast<int>(std::round(proposedWidth)),
                            static_cast<int>(std::round(proposedHeight)));

            if (onScaleChanged) onScaleChanged(scale);
        }
    }

    void mouseUp(const juce::MouseEvent&) override {
        isDragging = false;
        repaint();
    }

private:
    juce::Component* findEditorParent() {
        return getParentComponent();
    }

    bool isHovered = false;
    bool isDragging = false;
    juce::Point<int> dragStartPos;
    juce::Rectangle<int> originalSize;
};

} // namespace plugin_171
