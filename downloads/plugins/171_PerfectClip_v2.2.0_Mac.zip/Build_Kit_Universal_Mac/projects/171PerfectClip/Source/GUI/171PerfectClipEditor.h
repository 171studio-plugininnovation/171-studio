#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <BinaryData.h>
#include "PerfectClipCRTScope.h"
#include "ResizableHandleComponent.h"
#include "../PluginProcessor.h"

namespace PerfectClipBinaryData = BinaryData;

namespace dsp171 {

// ==============================================================================
// BOUTIQUE LOOK AND FEEL FOR 171PERFECTCLIP
// ==============================================================================
class PerfectClipBoutiqueLookAndFeel : public juce::LookAndFeel_V4 {
public:
    PerfectClipBoutiqueLookAndFeel() {
        setColour(juce::Slider::textBoxTextColourId, juce::Colour(0xFFFFD54F)); // Gold text
        setColour(juce::Slider::textBoxBackgroundColourId, juce::Colour(0xFF090C12)); // Recessed dark display
        setColour(juce::Slider::textBoxOutlineColourId, juce::Colour(0xFF283240)); // Metallic bevel
        setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xFF131720));
        setColour(juce::ComboBox::textColourId, juce::Colour(0xFFFFD54F));
        setColour(juce::ComboBox::outlineColourId, juce::Colour(0xFF323B4A));
        setColour(juce::ComboBox::arrowColourId, juce::Colour(0xFFFFD54F));
        setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xFF121620));
        setColour(juce::PopupMenu::textColourId, juce::Colour(0xFFECEFF1));
        setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xFF253042));
        setColour(juce::PopupMenu::highlightedTextColourId, juce::Colour(0xFFFFD54F));
        setColour(juce::TooltipWindow::backgroundColourId, juce::Colour(0xFF141820));
        setColour(juce::TooltipWindow::textColourId, juce::Colour(0xFFECEFF1));
        setColour(juce::TooltipWindow::outlineColourId, juce::Colour(0xFFFFD54F));
    }

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPosProportional, float rotaryStartAngle,
                          float rotaryEndAngle, juce::Slider& slider) override
    {
        const float radius = static_cast<float>(std::min(width, height)) * 0.5f - 5.0f;
        const float centreX = static_cast<float>(x) + static_cast<float>(width) * 0.5f;
        const float centreY = static_cast<float>(y) + static_cast<float>(height) * 0.5f;
        const float currentAngle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

        // Accent color based on role
        juce::Colour accentCol(0xFFFF9100); // Amber (Drive / Clipping)
        if (slider.getName().containsIgnoreCase("ceiling") || slider.getName().containsIgnoreCase("thresh")) {
            accentCol = juce::Colour(0xFFFF5252); // Red/Coral (Ceiling)
        } else if (slider.getName().containsIgnoreCase("knee")) {
            accentCol = juce::Colour(0xFFFFAB00); // Warm Amber-Orange (Soft Knee)
        } else if (slider.getName().containsIgnoreCase("detail") || slider.getName().containsIgnoreCase("trans")) {
            accentCol = juce::Colour(0xFF00E5FF); // Electric Cyan (Detail Preservation)
        } else if (slider.getName().containsIgnoreCase("air") || slider.getName().containsIgnoreCase("alchemy")) {
            accentCol = juce::Colour(0xFF69F0AE); // Emerald Sheen (Alchemy Air)
        } else if (slider.getName().containsIgnoreCase("out") || slider.getName().containsIgnoreCase("trim")) {
            accentCol = juce::Colour(0xFFFFD54F); // Warm Gold (Master Makeup)
        }

        // 1. Drop shadow behind dial
        g.setColour(juce::Colour(0x75000000));
        g.fillEllipse(centreX - radius + 1.5f, centreY - radius + 3.5f, radius * 2.0f, radius * 2.0f);

        // 2. Outer knurled calibration index ticks around bezel
        constexpr int numTicks = 11;
        const float tickOuterR = radius + 3.0f;
        const float tickInnerR = radius + 0.8f;
        for (int i = 0; i < numTicks; ++i) {
            float frac = static_cast<float>(i) / static_cast<float>(numTicks - 1);
            float a = rotaryStartAngle + frac * (rotaryEndAngle - rotaryStartAngle);
            float sa = std::sin(a);
            float ca = -std::cos(a);

            bool isMajor = (i == 0 || i == (numTicks - 1) / 2 || i == numTicks - 1);
            float inR = isMajor ? (tickInnerR - 1.2f) : tickInnerR;

            g.setColour(isMajor ? accentCol.withAlpha(0.70f) : juce::Colour(0xFF384354));
            g.drawLine(centreX + sa * inR, centreY + ca * inR,
                       centreX + sa * tickOuterR, centreY + ca * tickOuterR,
                       isMajor ? 1.4f : 1.0f);
        }

        // 3. Glowing indicator arc on dial bezel
        juce::Path arcPath;
        arcPath.addCentredArc(centreX, centreY, radius + 2.0f, radius + 2.0f, 0.0f, rotaryStartAngle, currentAngle, true);
        g.setColour(accentCol.withAlpha(0.22f));
        g.strokePath(arcPath, juce::PathStrokeType(4.0f));
        g.setColour(accentCol);
        g.strokePath(arcPath, juce::PathStrokeType(1.8f));

        // 4. Render dial bitmap if available in BinaryData, or procedural PBR metal
        auto knobImg = juce::ImageCache::getFromMemory(PerfectClipBinaryData::knob_171_steel_satin_128_png,
                                                       PerfectClipBinaryData::knob_171_steel_satin_128_pngSize);
        if (knobImg.isValid()) {
            float knobDiam = radius * 2.0f;
            float imgW = static_cast<float>(knobImg.getWidth());
            float imgH = static_cast<float>(knobImg.getHeight());
            auto transform = juce::AffineTransform::rotation(currentAngle, imgW * 0.5f, imgH * 0.5f)
                .translated(centreX - imgW * 0.5f, centreY - imgH * 0.5f)
                .scaled(knobDiam / imgW, knobDiam / imgH, centreX, centreY);
            g.drawImageTransformed(knobImg, transform);
        } else {
            // Procedural brushed dark titanium disc
            juce::ColourGradient dialGrad(juce::Colour(0xFF282E38), centreX, centreY - radius,
                                          juce::Colour(0xFF14171E), centreX, centreY + radius, false);
            g.setGradientFill(dialGrad);
            g.fillEllipse(centreX - radius + 2.0f, centreY - radius + 2.0f, (radius - 2.0f) * 2.0f, (radius - 2.0f) * 2.0f);
            g.setColour(juce::Colour(0xFF3A4452));
            g.drawEllipse(centreX - radius + 2.0f, centreY - radius + 2.0f, (radius - 2.0f) * 2.0f, (radius - 2.0f) * 2.0f, 1.2f);
        }

        // 5. Laser indicator notch
        const float notchInnerR = radius * 0.35f;
        const float notchOuterR = radius * 0.88f;
        float nx1 = centreX + std::sin(currentAngle) * notchInnerR;
        float ny1 = centreY - std::cos(currentAngle) * notchInnerR;
        float nx2 = centreX + std::sin(currentAngle) * notchOuterR;
        float ny2 = centreY - std::cos(currentAngle) * notchOuterR;

        g.setColour(juce::Colour(0x90000000));
        g.drawLine(nx1 + 1.0f, ny1 + 1.0f, nx2 + 1.0f, ny2 + 1.0f, 3.0f);
        g.setColour(accentCol);
        g.drawLine(nx1, ny1, nx2, ny2, 2.0f);
    }

    void drawToggleButton(juce::Graphics& g, juce::ToggleButton& button,
                          bool /*isHighlighted*/, bool /*isDown*/) override
    {
        auto bounds = button.getLocalBounds().toFloat().reduced(0.5f);
        const bool isToggled = button.getToggleState();
        const juce::String text = button.getButtonText();

        // 1. Boutique console pushbutton chassis
        juce::Colour bgCol = isToggled ? juce::Colour(0xFF161B24) : juce::Colour(0xFF0F1218);
        g.setColour(bgCol);
        g.fillRoundedRectangle(bounds, 4.0f);

        // Active border
        juce::Colour borderCol = juce::Colour(0xFF2A3444);
        juce::Colour ledCol(0xFFFF9100); // Default amber

        if (text.containsIgnoreCase("Mono")) {
            ledCol = juce::Colour(0xFF00E5FF); // Electric Cyan
            if (isToggled) borderCol = ledCol.withAlpha(0.6f);
        } else if (text.containsIgnoreCase("True-Peak") || text.containsIgnoreCase("ISP")) {
            ledCol = juce::Colour(0xFF00E676); // Emerald Green
            if (isToggled) borderCol = ledCol.withAlpha(0.6f);
        } else if (text.containsIgnoreCase("Delta")) {
            ledCol = juce::Colour(0xFFFF9100); // Neon Amber Warning
            if (isToggled) borderCol = juce::Colour(0xFFFF9100).withAlpha(0.7f);
        } else if (text.containsIgnoreCase("Bypass")) {
            ledCol = juce::Colour(0xFFFF2222); // Red Alert
            if (isToggled) borderCol = juce::Colour(0xFFFF3333).withAlpha(0.8f);
        }

        g.setColour(borderCol);
        g.drawRoundedRectangle(bounds, 4.0f, isToggled ? 1.4f : 1.0f);

        // 2. Hardware jewel LED indicator on the left
        const float ledDiam = 8.5f;
        const float ledX = bounds.getX() + 8.0f;
        const float ledY = bounds.getCentreY() - ledDiam * 0.5f;

        if (isToggled) {
            // Illuminated LED with radial glow
            g.setColour(ledCol.withAlpha(0.35f));
            g.fillEllipse(ledX - 2.5f, ledY - 2.5f, ledDiam + 5.0f, ledDiam + 5.0f);

            g.setColour(ledCol);
            g.fillEllipse(ledX, ledY, ledDiam, ledDiam);

            // Specular hot spot
            g.setColour(juce::Colours::white.withAlpha(0.85f));
            g.fillEllipse(ledX + 2.0f, ledY + 1.5f, 2.5f, 2.5f);
        } else {
            // Dark inactive socket
            g.setColour(juce::Colour(0xFF181D26));
            g.fillEllipse(ledX, ledY, ledDiam, ledDiam);
            g.setColour(juce::Colour(0xFF333E50));
            g.drawEllipse(ledX, ledY, ledDiam, ledDiam, 1.0f);
        }

        // 3. Button Silkscreen Typography
        auto textRect = bounds.withTrimmedLeft(ledX + ledDiam + 7.0f - bounds.getX());
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 10.0f, juce::Font::bold)));
        g.setColour(isToggled ? juce::Colour(0xFFECEFF1) : juce::Colour(0xFF78889B));
        g.drawText(text, textRect, juce::Justification::centredLeft, false);
    }
};

// ==============================================================================
// 171PERFECTCLIP MAIN EDITOR
// ==============================================================================
class PerfectClipEditor : public juce::AudioProcessorEditor,
                          private juce::Timer
{
public:
    struct HelpItem {
        juce::String title;
        juce::String value;
        juce::String description;
        juce::String recommendation;
    };

    PerfectClipEditor(PerfectClipAudioProcessor& p)
        : AudioProcessorEditor(&p), audioProcessor(p),
          crtScope(audioProcessor.getEngine())
    {
        setLookAndFeel(&lookAndFeel);

        // Load 171 Studio Gold Logo
        goldLogoImage = juce::ImageCache::getFromMemory(PerfectClipBinaryData::logo_171_gold_png,
                                                        PerfectClipBinaryData::logo_171_gold_pngSize);

        // Configure CRT Scope
        addAndMakeVisible(crtScope);
        crtScope.addMouseListener(this, true);

        // 1. Controls: Drive
        setupRotarySlider(driveSlider, "Drive");
        driveSlider.setDoubleClickReturnValue(true, 0.0);
        driveSlider.textFromValueFunction = [](double v) {
            return (v >= 0.0 ? "+" : "") + juce::String(v, 1) + " dB";
        };
        driveSlider.valueFromTextFunction = [](const juce::String& t) {
            return t.upToFirstOccurrenceOf("dB", false, false).getDoubleValue();
        };
        driveSlider.updateText();
        driveSlider.setTooltip(
            "INPUT DRIVE | Guadagno di Ingresso Mastering (+0.0 dB a +24.0 dB)\n"
            "Spinge il segnale audio all'interno del nucleo di clipping 4x Polyphase con zero DC drift.\n"
            "✦ CONSIGLIATI: Modern Trap/EDM: +4.0 a +7.0 dB | Modern Pop: +2.0 a +4.0 dB | Master Acustico: +0.5 a +1.5 dB | Drum Bus: +5.0 a +8.0 dB");
        driveSlider.addMouseListener(this, true);
        driveAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            audioProcessor.getAPVTS(), "inGain", driveSlider);

        // 2. Controls: Ceiling
        setupRotarySlider(ceilingSlider, "Ceiling");
        ceilingSlider.setDoubleClickReturnValue(true, -0.1);
        ceilingSlider.textFromValueFunction = [](double v) {
            return juce::String(v, 1) + " dBFS";
        };
        ceilingSlider.valueFromTextFunction = [](const juce::String& t) {
            return t.upToFirstOccurrenceOf("dBFS", false, false).getDoubleValue();
        };
        ceilingSlider.updateText();
        ceilingSlider.setTooltip(
            "SAFETY CEILING | Tetto di Picco Massimo (-24.0 dBFS a 0.0 dBFS)\n"
            "Soglia assoluta di taglio. Garantisce il rispetto matematico del picco massimo senza alcun superamento.\n"
            "✦ CONSIGLIATI: Master Digitale Standard: -0.1 dBFS a -0.2 dBFS | Streaming (Spotify/Apple Music): -1.0 dBFS | Club/Festival: -0.1 dBFS");
        ceilingSlider.addMouseListener(this, true);
        ceilingAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            audioProcessor.getAPVTS(), "ceiling", ceilingSlider);

        // 3. Controls: Soft Knee
        setupRotarySlider(kneeSlider, "Knee");
        kneeSlider.setDoubleClickReturnValue(true, 0.0);
        kneeSlider.textFromValueFunction = [](double v) {
            return juce::String(v * 100.0, 0) + " %";
        };
        kneeSlider.valueFromTextFunction = [](const juce::String& t) {
            return t.upToFirstOccurrenceOf("%", false, false).getDoubleValue() * 0.01;
        };
        kneeSlider.updateText();
        kneeSlider.setTooltip(
            "SOFT KNEE | Raccordo Morbido Continuo (0% Brickwall a 100% Analog C2)\n"
            "Transizione progressiva da taglio netto a lama di rasoio (0%) a curva quintica C2 analogica morbida (100%).\n"
            "✦ CONSIGLIATI: Drum Bus & Snares: 0% (massimo crest snap) | EDM/Trap Drop: 10% a 20% | Master Pop/Rock: 20% a 35% | Acustica: 40% a 60%");
        kneeSlider.addMouseListener(this, true);
        kneeAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            audioProcessor.getAPVTS(), "softKnee", kneeSlider);

        // 4. Controls: TransDetail Preservation
        setupRotarySlider(detailSlider, "Detail");
        detailSlider.setDoubleClickReturnValue(true, 1.0);
        detailSlider.textFromValueFunction = [](double v) {
            return juce::String(v * 100.0, 0) + " %";
        };
        detailSlider.valueFromTextFunction = [](const juce::String& t) {
            return t.upToFirstOccurrenceOf("%", false, false).getDoubleValue() * 0.01;
        };
        detailSlider.updateText();
        detailSlider.setTooltip(
            "171 TRANSDETAIL™ MATRIX | Preservazione Micro-Transienti Ortogonale (0% a 100%)\n"
            "Decomposizione in Carrier (basse) e Detail (alte). Previene che i picchi di cassa e 808 schiaccino i piatti e l'aria delle voci.\n"
            "✦ CONSIGLIATI: Mix Master Trasparente: 85% a 100% | Trap con 808 pesanti: 45% a 65% | Drum Bus Punch: 50% a 70% | Naive Hard Clip: 0%");
        detailSlider.addMouseListener(this, true);
        detailAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            audioProcessor.getAPVTS(), "transDetail", detailSlider);

        // 5. Controls: Alchemy Air
        setupRotarySlider(alchemySlider, "Air");
        alchemySlider.setDoubleClickReturnValue(true, 0.0);
        alchemySlider.textFromValueFunction = [](double v) {
            return (v >= 0.0 ? "+" : "") + juce::String(v, 1) + " dB";
        };
        alchemySlider.valueFromTextFunction = [](const juce::String& t) {
            return t.upToFirstOccurrenceOf("dB", false, false).getDoubleValue();
        };
        alchemySlider.updateText();
        alchemySlider.setTooltip(
            "AIR SHEEN | Equalizzatore High-Shelf Attivo a Fase Coerente (-6.0 dB a +6.0 dB)\n"
            "Filtro Cytomic ZDF High-Shelf a 10 kHz applicato al dettaglio transiente. Inietta brillantezza e respiro setoso senza buchi di fase.\n"
            "✦ CONSIGLIATI: Risposta Lineare Piatta: 0.0 dB | Apertura Aria Vocale / Master Cupi: +0.5 a +1.5 dB | Cymbals Sizzle: +1.0 a +2.0 dB");
        alchemySlider.addMouseListener(this, true);
        alchemyAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            audioProcessor.getAPVTS(), "alchemyAir", alchemySlider);

        // 6. Controls: Output Trim
        setupRotarySlider(outTrimSlider, "Out Trim");
        outTrimSlider.setDoubleClickReturnValue(true, 0.0);
        outTrimSlider.textFromValueFunction = [](double v) {
            return (v >= 0.0 ? "+" : "") + juce::String(v, 1) + " dB";
        };
        outTrimSlider.valueFromTextFunction = [](const juce::String& t) {
            return t.upToFirstOccurrenceOf("dB", false, false).getDoubleValue();
        };
        outTrimSlider.updateText();
        outTrimSlider.setTooltip(
            "OUTPUT TRIM | Recupero di Guadagno Master (-24.0 dB a +24.0 dB)\n"
            "Trim pulito in uscita a 64-bit seguito da disaccoppiamento DC a 5 Hz e limitatore True-Peak lookahead.\n"
            "✦ CONSIGLIATI: 0.0 dB per uscita master calibrata; trim negativo per confronto A/B a loudness costante.");
        outTrimSlider.addMouseListener(this, true);
        outTrimAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            audioProcessor.getAPVTS(), "outGain", outTrimSlider);

        // 7. Controls: Unified Topology Mode Selector
        topologyBox.addItem("Digital Hard (ADAA-2)", 1);
        topologyBox.addItem("Gold ADC 122 (Lavry Gold)", 2);
        topologyBox.addItem("Tube Triode Class-A", 3);
        topologyBox.addItem("Germanium Diode", 4);
        topologyBox.setSelectedId(1, juce::dontSendNotification);
        topologyBox.setTooltip(
            "CLIPPER TOPOLOGY | Modello Fisico Circuitale\n"
            "DIGITAL HARD: ADAA-2 analitico a tratti (massimo LUFS e crest snap);\n"
            "GOLD ADC 122: Emulazione Lavry Gold con JFET 2a armonica e sag termico;\n"
            "TUBE TRIODE: Saturazione asimmetrica a valvole Classe-A calda e musicale, zero cali di volume;\n"
            "GERMANIUM: Diodo al germanio organico con knee Shockley per bus di batteria e rock master.");
        topologyBox.addMouseListener(this, true);
        addAndMakeVisible(topologyBox);
        topologyAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(
            audioProcessor.getAPVTS(), "clipMode", topologyBox);

        // 8. Controls: Routing Selector
        routingBox.addItem("Stereo L/R", 1);
        routingBox.addItem("Mid/Side Split", 2);
        routingBox.addItem("Mid Only", 3);
        routingBox.addItem("Side Only", 4);
        routingBox.setSelectedId(1, juce::dontSendNotification);
        routingBox.setTooltip(
            "CHANNEL ROUTING | Instradamento Canali Stereo / Mid-Side\n"
            "STEREO L/R: Elaborazione stereo convenzionale;\n"
            "MID/SIDE SPLIT: Elaborazione M/S con DC blocker a fase simmetrica;\n"
            "MID ONLY: Taglia i picchi mono centrali preservando la spazialita dei lati;\n"
            "SIDE ONLY: Controlla l'energia laterale senza intaccare il punch centrale.");
        routingBox.addMouseListener(this, true);
        addAndMakeVisible(routingBox);
        routingAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(
            audioProcessor.getAPVTS(), "routing", routingBox);

        // 9. Buttons: Mono-Maker, True-Peak, Delta Audition, Bypass
        setupButton(monoMakerBtn, "Mono < 80Hz", true);
        monoMakerBtn.setTooltip(
            "SUB-BASS MONO MAKER (< 80 Hz) | Crossover Ellittico Mid/Side\n"
            "Filtro passa-alto sul canale Side (<80 Hz). Collassa i sub-bassi al centro perfetto per un punch solido su club system e vinile.\n"
            "✦ CONSIGLIATO: Attivo per master EDM, Trap, Pop e per impianti PA professionali.");
        monoMakerBtn.addMouseListener(this, true);
        monoMakerAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            audioProcessor.getAPVTS(), "monoMaker", monoMakerBtn);

        setupButton(truePeakBtn, "ISP True-Peak", true);
        truePeakBtn.setTooltip(
            "ITU-R BS.1770-4 TRUE-PEAK GUARD | Limitatore Anti Inter-Sample Peaks\n"
            "Filtro sinc polifase 4x con lookahead a 4 campioni e recupero trasparente a 2 ms. Previene la distorsione di ricostruzione nei DAC.\n"
            "✦ CONSIGLIATO: Sempre ATTIVO su master destinati a piattaforme streaming (Spotify, Apple Music, YouTube).");
        truePeakBtn.addMouseListener(this, true);
        truePeakAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            audioProcessor.getAPVTS(), "truePeak", truePeakBtn);

        setupButton(deltaAuditionBtn, "Delta Audition", false);
        deltaAuditionBtn.setTooltip(
            "DELTA AUDITION | Ascolto Isolato dei Picchi Tagliati\n"
            "Mette in solo esclusivamente l'energia dei picchi rimossi dal clipper (ingresso meno uscita). Silenzio assoluto sotto soglia.\n"
            "✦ STRUMENTO DI CALIBRAZIONE: Attiva per verificare se stai tagliando solo micro-transienti o intaccando il corpo musicale.");
        deltaAuditionBtn.addMouseListener(this, true);
        deltaAuditionAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            audioProcessor.getAPVTS(), "deltaAudition", deltaAuditionBtn);

        setupButton(bypassBtn, "Bypass", false);
        bypassBtn.setTooltip(
            "MASTER BYPASS | Bypass Hardware Bit-Exact\n"
            "Passaggio istantaneo e privo di click con allineamento temporale PDC perfetto.\n"
            "✦ CONFRONTO A/B: Disattiva l'intero processore per confrontare il suono elaborato con la sorgente originale.");
        bypassBtn.addMouseListener(this, true);
        bypassAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            audioProcessor.getAPVTS(), "bypass", bypassBtn);

        addAndMakeVisible(resizableHandle);

        setResizable(true, true);
        setResizeLimits(800, 520, 1440, 900);
        setSize(960, 580);

        startTimerHz(60); // 60 FPS high-refresh rate CRT oscilloscope & metering
    }

    ~PerfectClipEditor() override {
        stopTimer();
        setLookAndFeel(nullptr);
    }

    void mouseEnter(const juce::MouseEvent& e) override {
        updateHoverHelp(e.eventComponent);
    }

    void mouseExit(const juce::MouseEvent& e) override {
        if (e.eventComponent == activeHoveredComponent) {
            activeHoveredComponent = nullptr;
            repaint(infoBarBounds);
        }
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const float w = bounds.getWidth();
        const float h = bounds.getHeight();

        // 1. Brushed Dark Titanium Chassis Background
        juce::ColourGradient bgGrad(juce::Colour(0xFF171A21), 0.0f, 0.0f,
                                    juce::Colour(0xFF0D0F14), 0.0f, h, false);
        g.setGradientFill(bgGrad);
        g.fillRect(bounds);

        // Subtle anodized brushed lines
        g.setColour(juce::Colour(0x06FFFFFF));
        for (float y = 0.0f; y < h; y += 3.0f) {
            g.drawHorizontalLine(static_cast<int>(y), 0.0f, w);
        }

        // 2. Header Bar with Gold 171 Logo
        g.setColour(juce::Colour(0xFF101319));
        g.fillRect(0.0f, 0.0f, w, 46.0f);
        g.setColour(juce::Colour(0xFF28303C));
        g.drawHorizontalLine(46, 0.0f, w);

        if (goldLogoImage.isValid()) {
            g.drawImageWithin(goldLogoImage, 16, 7, 140, 32,
                              juce::RectanglePlacement(juce::RectanglePlacement::xLeft | juce::RectanglePlacement::yMid));
        }

        g.setColour(juce::Colour(0xFFFFD54F));
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 15.0f, juce::Font::bold)));
        g.drawText("171 PERFECTCLIP", 165, 11, 220, 24, juce::Justification::left);

        g.setColour(juce::Colour(0xFF78889B));
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultSansSerifFontName(), 10.0f, juce::Font::plain)));
        g.drawText("4x POLYSINC TRUE-PEAK MASTERING CLIPPER // TRANSDETAIL MATRIX",
                   360, 14, 430, 20, juce::Justification::left);

        // Active Topology Badge in Header
        drawTopologyBadge(g, static_cast<int>(w) - 210, 11, 195, 24);

        // 3. Draw Functional Bays (Bay 1 Core, Bay 2 Scope, Bay 3 TransDetail, Bay 4 Master)
        drawBay(g, bay1Bounds, "CLIPPING CORE");
        drawBay(g, bay2Bounds, "CRT BIPOLAR DELTA SCOPE (60 FPS)");
        drawBay(g, bay3Bounds, juce::String::fromUTF8("TOPOLOGY & TRANSDETAIL\xe2\x84\xa2"));
        drawBay(g, bay4Bounds, "OUTPUT & MONITORING");

        // 4. Draw Permanent High-Contrast Silkscreen Plaques with Explicit Roles on All Controls
        drawBayLabels(g);

        // 5. Draw Interactive Pro Parameter Inspector / Info Bar
        drawInfoBar(g, infoBarBounds);
    }

    void resized() override {
        const auto bounds = getLocalBounds();
        const int w = bounds.getWidth();
        const int h = bounds.getHeight();

        const int topY = 52;
        const int infoBarH = 68;
        const int bottomH = h - topY - infoBarH - 12;

        const int baySpacing = 6;
        const int totalBayW = w - 16 - 3 * baySpacing;

        // Proportional bay widths
        const int bay1W = static_cast<int>(totalBayW * 0.22f); // ~205 px: Core
        const int bay2W = static_cast<int>(totalBayW * 0.38f); // ~355 px: CRT Scope
        const int bay3W = static_cast<int>(totalBayW * 0.22f); // ~205 px: TransDetail
        const int bay4W = totalBayW - bay1W - bay2W - bay3W;   // ~168 px: Master & I/O

        bay1Bounds = juce::Rectangle<int>(8, topY, bay1W, bottomH);
        bay2Bounds = juce::Rectangle<int>(bay1Bounds.getRight() + baySpacing, topY, bay2W, bottomH);
        bay3Bounds = juce::Rectangle<int>(bay2Bounds.getRight() + baySpacing, topY, bay3W, bottomH);
        bay4Bounds = juce::Rectangle<int>(bay3Bounds.getRight() + baySpacing, topY, bay4W, bottomH);

        infoBarBounds = juce::Rectangle<int>(8, h - infoBarH - 6, w - 16, infoBarH);

        // -------------------------------------------------------------
        // Bay 1: Clipping Core (Drive, Ceiling, Soft Knee)
        // -------------------------------------------------------------
        const int b1X = bay1Bounds.getX();
        const int b1W = bay1Bounds.getWidth();
        const int dial1Size = std::clamp(static_cast<int>(b1W * 0.44f), 66, 80);
        const int b1DialX = b1X + (b1W - dial1Size) / 2;
        const int b1StartY = bay1Bounds.getY() + 26;
        const int b1AvailH = bay1Bounds.getHeight() - 32;
        const int b1StepY = b1AvailH / 3;

        // Cell 0: Drive
        const int b1Cell0Y = b1StartY;
        driveSlider.setBounds(b1DialX, b1Cell0Y + 34, dial1Size, dial1Size + 16);

        // Cell 1: Ceiling
        const int b1Cell1Y = b1StartY + b1StepY;
        ceilingSlider.setBounds(b1DialX, b1Cell1Y + 34, dial1Size, dial1Size + 16);

        // Cell 2: Soft Knee
        const int b1Cell2Y = b1StartY + 2 * b1StepY;
        kneeSlider.setBounds(b1DialX, b1Cell2Y + 34, dial1Size, dial1Size + 16);

        // -------------------------------------------------------------
        // Bay 2: CRT Bipolar Delta Scope (Spans full height of Bay 2)
        // -------------------------------------------------------------
        crtScope.setBounds(bay2Bounds.getX() + 8, bay2Bounds.getY() + 28,
                           bay2Bounds.getWidth() - 16, bay2Bounds.getHeight() - 36);

        // -------------------------------------------------------------
        // Bay 3: Topology & TransDetail Matrix
        // -------------------------------------------------------------
        const int b3X = bay3Bounds.getX();
        const int b3W = bay3Bounds.getWidth();
        const int b3StartY = bay3Bounds.getY() + 26;

        topologyBox.setBounds(b3X + 12, b3StartY + 32, b3W - 24, 26);

        const int dial3Size = std::clamp(static_cast<int>(b3W * 0.44f), 68, 82);
        const int b3DialX = b3X + (b3W - dial3Size) / 2;

        const int b3TopSecY = b3StartY + 64;
        const int b3RemH = bay3Bounds.getBottom() - b3TopSecY - 10;
        const int b3Step = b3RemH / 2;

        // Cell 0: TransDetail
        const int b3Cell0Y = b3TopSecY + 4;
        detailSlider.setBounds(b3DialX, b3Cell0Y + 32, dial3Size, dial3Size + 16);

        // Cell 1: Air Sheen
        const int b3Cell1Y = b3TopSecY + b3Step + 4;
        alchemySlider.setBounds(b3DialX, b3Cell1Y + 32, dial3Size, dial3Size + 16);

        // -------------------------------------------------------------
        // Bay 4: Output & Monitoring
        // -------------------------------------------------------------
        const int b4X = bay4Bounds.getX();
        const int b4W = bay4Bounds.getWidth();
        const int b4StartY = bay4Bounds.getY() + 26;

        const int dial4Size = std::clamp(static_cast<int>(b4W * 0.44f), 66, 80);
        const int b4DialX = b4X + (b4W - dial4Size) / 2;
        outTrimSlider.setBounds(b4DialX, b4StartY + 34, dial4Size, dial4Size + 16);

        const int b4MidY = b4StartY + dial4Size + 56;
        routingBox.setBounds(b4X + 10, b4MidY + 28, b4W - 20, 26);

        const int btnStartY = b4MidY + 62;
        const int btnH = 26;
        const int btnGap = 6;
        int btnY = btnStartY + 34;
        monoMakerBtn.setBounds(b4X + 10, btnY, b4W - 20, btnH);
        btnY += btnH + btnGap;
        truePeakBtn.setBounds(b4X + 10, btnY, b4W - 20, btnH);
        btnY += btnH + btnGap;
        deltaAuditionBtn.setBounds(b4X + 10, btnY, b4W - 20, btnH);
        btnY += btnH + btnGap;
        bypassBtn.setBounds(b4X + 10, btnY, b4W - 20, btnH);

        resizableHandle.setBounds(w - 18, h - 18, 18, 18);
    }

private:
    void timerCallback() override {
        const float cVal = audioProcessor.getAPVTS().getRawParameterValue("ceiling")->load(std::memory_order_relaxed);
        crtScope.setCeilingLinear(std::pow(10.0f, cVal / 20.0f));

        const int topId = topologyBox.getSelectedId();
        const bool isGold = (topId == 2);
        crtScope.setGoldMode(isGold);

        // Repaint CRT Scope and InfoBar at 60 FPS
        crtScope.repaint();
        repaint(infoBarBounds);
    }

    void updateHoverHelp(juce::Component* comp) {
        activeHoveredComponent = comp;
        repaint(infoBarBounds);
    }

    // Engraved Silkscreen Plaque Badge Component for Chassis Knobs & Controls
    void drawPlaqueBadge(juce::Graphics& g, int x, int y, int w,
                         const juce::String& title, const juce::String& subtitle, juce::Colour accentCol)
    {
        auto r = juce::Rectangle<int>(x, y, w, 28).toFloat();

        // 1. Recessed dark metallic backing
        g.setColour(juce::Colour(0xFF101319));
        g.fillRoundedRectangle(r, 3.5f);
        g.setColour(accentCol.withAlpha(0.40f));
        g.drawRoundedRectangle(r, 3.5f, 1.0f);

        // 2. Corner jewel accent pip
        g.setColour(accentCol);
        g.fillEllipse(r.getX() + 6.0f, r.getY() + 7.0f, 4.0f, 4.0f);

        // 3. Main Silkscreen Title (Bold, High-Contrast)
        g.setColour(accentCol);
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 9.5f, juce::Font::bold)));
        g.drawText(title, static_cast<int>(r.getX() + 14.0f), static_cast<int>(r.getY() + 2.0f), static_cast<int>(r.getWidth() - 16.0f), 13, juce::Justification::left);

        // 4. Role Subtitle (Engraved explanation stating exactly what the knob does!)
        g.setColour(juce::Colour(0xFFCCD6E0));
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultSansSerifFontName(), 8.5f, juce::Font::bold)));
        g.drawText(subtitle, static_cast<int>(r.getX() + 14.0f), static_cast<int>(r.getY() + 14.0f), static_cast<int>(r.getWidth() - 16.0f), 12, juce::Justification::left);
    }

    void drawBayLabels(juce::Graphics& g) {
        const int b1X = bay1Bounds.getX();
        const int b1W = bay1Bounds.getWidth();
        const int b1StartY = bay1Bounds.getY() + 26;
        const int b1AvailH = bay1Bounds.getHeight() - 32;
        const int b1StepY = b1AvailH / 3;

        // Bay 1 Knobs: Drive, Ceiling, Soft Knee
        drawPlaqueBadge(g, b1X + 10, b1StartY + 2, b1W - 20, "INPUT DRIVE", "CLIP GAIN [dB]", juce::Colour(0xFFFF9100));
        drawPlaqueBadge(g, b1X + 10, b1StartY + b1StepY + 2, b1W - 20, "SAFETY CEILING", "PEAK THRESHOLD [dBFS]", juce::Colour(0xFFFF5252));
        drawPlaqueBadge(g, b1X + 10, b1StartY + 2 * b1StepY + 2, b1W - 20, "SOFT KNEE", "C2 TRANSITION [%]", juce::Colour(0xFFFFAB00));

        // Bay 3 Controls: Topology, TransDetail, Air Sheen
        const int b3X = bay3Bounds.getX();
        const int b3W = bay3Bounds.getWidth();
        const int b3StartY = bay3Bounds.getY() + 26;
        const int b3TopSecY = b3StartY + 64;
        const int b3RemH = bay3Bounds.getBottom() - b3TopSecY - 10;
        const int b3Step = b3RemH / 2;
        const int b3Cell0Y = b3TopSecY + 4;
        const int b3Cell1Y = b3TopSecY + b3Step + 4;

        drawPlaqueBadge(g, b3X + 10, b3StartY + 2, b3W - 20, "CLIPPER TOPOLOGY", "CIRCUIT MODEL", juce::Colour(0xFFFFD54F));
        drawPlaqueBadge(g, b3X + 10, b3Cell0Y + 2, b3W - 20, "TRANSDETAIL" + juce::String::fromUTF8("\xe2\x84\xa2"), "MICRO-TRANSIENTS [%]", juce::Colour(0xFF00E5FF));
        drawPlaqueBadge(g, b3X + 10, b3Cell1Y + 2, b3W - 20, "AIR SHEEN", "10 kHz HF SHELF [dB]", juce::Colour(0xFF69F0AE));

        // Bay 4 Controls: Output Trim, Routing, Guards
        const int b4X = bay4Bounds.getX();
        const int b4W = bay4Bounds.getWidth();
        const int b4StartY = bay4Bounds.getY() + 26;
        const int dial4Size = std::clamp(static_cast<int>(b4W * 0.44f), 66, 80);
        const int b4MidY = b4StartY + dial4Size + 56;
        const int btnStartY = b4MidY + 62;

        drawPlaqueBadge(g, b4X + 10, b4StartY + 2, b4W - 20, "OUTPUT TRIM", "MASTER MAKEUP [dB]", juce::Colour(0xFFFFD54F));
        drawPlaqueBadge(g, b4X + 10, b4MidY + 2, b4W - 20, "CHANNEL ROUTING", "STEREO vs MID-SIDE", juce::Colour(0xFFB0BEC5));
        drawPlaqueBadge(g, b4X + 10, btnStartY + 2, b4W - 20, "MASTERING GUARDS", "DSP PROTECTION", juce::Colour(0xFF00E676));
    }

    void drawTopologyBadge(juce::Graphics& g, int x, int y, int w, int h) {
        auto r = juce::Rectangle<int>(x, y, w, h).toFloat();
        g.setColour(juce::Colour(0xFF141820));
        g.fillRoundedRectangle(r, 4.0f);
        g.setColour(juce::Colour(0xFF303846));
        g.drawRoundedRectangle(r, 4.0f, 1.0f);

        const int topId = topologyBox.getSelectedId();
        juce::String topName = "DIGITAL HARD";
        juce::Colour ledCol(0xFF00E5FF);

        if (topId == 2) {
            topName = "GOLD ADC 122";
            ledCol = juce::Colour(0xFFFFD54F);
        } else if (topId == 3) {
            topName = "TUBE TRIODE";
            ledCol = juce::Colour(0xFFFF9100);
        } else if (topId == 4) {
            topName = "GERMANIUM";
            ledCol = juce::Colour(0xFFFF5252);
        }

        // Illuminated LED indicator
        g.setColour(ledCol);
        g.fillEllipse(r.getX() + 8.0f, r.getCentreY() - 3.5f, 7.0f, 7.0f);
        g.setColour(ledCol.withAlpha(0.35f));
        g.fillEllipse(r.getX() + 6.0f, r.getCentreY() - 5.5f, 11.0f, 11.0f);

        g.setColour(juce::Colour(0xFFCCD6E0));
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 10.0f, juce::Font::bold)));
        g.drawText("TOPOLOGY: " + topName, static_cast<int>(r.getX() + 22.0f), static_cast<int>(r.getY()), static_cast<int>(r.getWidth() - 26.0f), static_cast<int>(r.getHeight()), juce::Justification::left);
    }

    void drawBay(juce::Graphics& g, const juce::Rectangle<int>& bounds, const juce::String& title) {
        auto r = bounds.toFloat();
        g.setColour(juce::Colour(0xFF101319));
        g.fillRoundedRectangle(r, 6.0f);
        g.setColour(juce::Colour(0xFF242B36));
        g.drawRoundedRectangle(r, 6.0f, 1.0f);

        // Bay Title Banner
        g.setColour(juce::Colour(0xFF141820));
        g.fillRoundedRectangle(r.getX(), r.getY(), r.getWidth(), 22.0f, 6.0f);
        g.setColour(juce::Colour(0xFF8898AA));
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 9.5f, juce::Font::bold)));
        g.drawText(title, bounds.getX() + 10, bounds.getY() + 2, bounds.getWidth() - 20, 18, juce::Justification::left);
    }

    void drawInfoBar(juce::Graphics& g, const juce::Rectangle<int>& bounds) {
        auto r = bounds.toFloat();
        
        // Background Chassis
        g.setColour(juce::Colour(0xFF0F1218));
        g.fillRoundedRectangle(r, 5.0f);
        g.setColour(juce::Colour(0xFF2B3340));
        g.drawRoundedRectangle(r, 5.0f, 1.2f);

        // Header accent line
        g.setColour(juce::Colour(0xFFFFD54F).withAlpha(0.35f));
        g.drawHorizontalLine(bounds.getY() + 1, r.getX() + 2.0f, r.getRight() - 2.0f);

        auto help = getHelpForActiveComponent();

        if (help.title.isNotEmpty()) {
            // PARAMETER TITLE & VALUE
            g.setColour(juce::Colour(0xFFFFD54F));
            g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 11.0f, juce::Font::bold)));
            juce::String header = juce::String::fromUTF8("\xe2\x96\xb6 ") + help.title;
            if (help.value.isNotEmpty()) {
                header += " : [" + help.value + "]";
            }
            g.drawText(header, bounds.getX() + 14, bounds.getY() + 6, bounds.getWidth() - 28, 16, juce::Justification::left);

            // DESCRIPTION (Line 1)
            g.setColour(juce::Colour(0xFFE0E6ED));
            g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultSansSerifFontName(), 9.5f, juce::Font::plain)));
            g.drawText(help.description, bounds.getX() + 14, bounds.getY() + 24, bounds.getWidth() - 28, 16, juce::Justification::left);

            // RECOMMENDATION / STUDIO TIP (Line 2)
            g.setColour(juce::Colour(0xFF00E5FF));
            g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultSansSerifFontName(), 9.5f, juce::Font::bold)));
            g.drawText(help.recommendation, bounds.getX() + 14, bounds.getY() + 42, bounds.getWidth() - 28, 16, juce::Justification::left);
        } else {
            // Real-Time Telemetry & Studio Status when not hovering
            auto telem = audioProcessor.getEngine().getTelemetry();

            g.setColour(juce::Colour(0xFFFFD54F));
            g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 10.5f, juce::Font::bold)));
            g.drawText(juce::String::fromUTF8("\xe2\x96\xb6 REAL-TIME TELEMETRY & MASTERING STATUS"),
                       bounds.getX() + 14, bounds.getY() + 7, 450, 15, juce::Justification::left);

            // Active DSP Status
            g.setColour(juce::Colour(0xFF00E676));
            g.fillEllipse(bounds.getRight() - 110.0f, bounds.getY() + 11.0f, 7.0f, 7.0f);
            g.setColour(juce::Colour(0xFFECEFF1));
            g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 9.0f, juce::Font::bold)));
            g.drawText("DSP ACTIVE", bounds.getRight() - 98, bounds.getY() + 8, 90, 14, juce::Justification::left);

            // Row 1: True Peak & Ceilings
            g.setColour(juce::Colour(0xFFCFD8DC));
            g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 10.0f, juce::Font::plain)));
            juce::String row1 = "PEAK IN: " + juce::String(telem.inPeakDbL, 1) + " dBFS"
                              + " | CEILING: " + juce::String(ceilingSlider.getValue(), 1) + " dBFS"
                              + " | PEAK OUT: " + juce::String(telem.outPeakDbL, 1) + " dBFS";
            g.drawText(row1, bounds.getX() + 14, bounds.getY() + 25, bounds.getWidth() - 28, 16, juce::Justification::left);

            // Row 2: Dynamic GR, Crest Factor & True-Peak Protection
            g.setColour(juce::Colour(0xFF8898AA));
            juce::String row2 = "MAX CLIP REDUCTION: " + juce::String(telem.maxGainReductionDb, 1) + " dB"
                              + " | CREST FACTOR: " + juce::String(telem.crestFactorDb, 1) + " dB"
                              + " | 4x POLYSINC OVERSAMPLING: ACTIVE (>96dB REJECTION)";
            g.drawText(row2, bounds.getX() + 14, bounds.getY() + 43, bounds.getWidth() - 28, 16, juce::Justification::left);
        }
    }

    HelpItem getHelpForActiveComponent() {
        if (activeHoveredComponent == nullptr) return {};

        if (activeHoveredComponent == &driveSlider || activeHoveredComponent->isParentOf(&driveSlider)) {
            return {
                "INPUT DRIVE [dB]",
                driveSlider.getTextFromValue(driveSlider.getValue()),
                "Guadagno lineare di ingresso prima del modulo di clipping 4x oversampled. Spinge il segnale audio contro il tetto massimo.",
                "CONSIGLIATI: Modern EDM/Trap: +4 a +7 dB | Pop/Rock: +2 a +4 dB | Master Trasparente: +0.5 a +1.5 dB | Drum Bus: +5 a +8 dB"
            };
        }

        if (activeHoveredComponent == &ceilingSlider || activeHoveredComponent->isParentOf(&ceilingSlider)) {
            return {
                "SAFETY CEILING [dBFS]",
                ceilingSlider.getTextFromValue(ceilingSlider.getValue()),
                "Soglia assoluta di taglio. Garantisce il rispetto matematico del picco massimo senza alcun superamento.",
                "CONSIGLIATI: Master Digitale Standard: -0.1 dBFS a -0.2 dBFS | Streaming (Spotify/Apple Music): -1.0 dBFS | Club: -0.1 dBFS"
            };
        }

        if (activeHoveredComponent == &kneeSlider || activeHoveredComponent->isParentOf(&kneeSlider)) {
            return {
                "SOFT KNEE [%]",
                kneeSlider.getTextFromValue(kneeSlider.getValue()),
                "Raccordo quintico C2 continuo: da taglio netto a lama di rasoio (0%) a transizione analogica progressiva (100%).",
                "CONSIGLIATI: Drum Bus & Snare: 0% (massimo snap) | Trap/EDM: 10% a 20% | Pop Master: 20% a 35% | Acustica: 40% a 60%"
            };
        }

        if (activeHoveredComponent == &detailSlider || activeHoveredComponent->isParentOf(&detailSlider)) {
            return {
                "171 TRANSDETAIL MATRIX [%]",
                detailSlider.getTextFromValue(detailSlider.getValue()),
                "Preserva i micro-transienti ad alta frequenza dal collasso causato dai picchi delle basse frequenze (808 e casse).",
                "CONSIGLIATI: Mix Master Trasparente: 85% a 100% | Trap con 808 pesanti: 50% a 70% | Hard Clip Convenzionale: 0%"
            };
        }

        if (activeHoveredComponent == &alchemySlider || activeHoveredComponent->isParentOf(&alchemySlider)) {
            return {
                "AIR SHEEN [dB]",
                alchemySlider.getTextFromValue(alchemySlider.getValue()),
                "Equalizzatore High-Shelf ZDF a 10 kHz applicato al dettaglio transiente. Inietta brillantezza e respiro setoso senza buchi di fase.",
                "CONSIGLIATI: Risposta Lineare Piatta: 0.0 dB | Apertura Aria Vocale: +0.5 a +1.5 dB | Cymbals Sizzle: +1.0 a +2.0 dB"
            };
        }

        if (activeHoveredComponent == &outTrimSlider || activeHoveredComponent->isParentOf(&outTrimSlider)) {
            return {
                "OUTPUT TRIM [dB]",
                outTrimSlider.getTextFromValue(outTrimSlider.getValue()),
                "Trim pulito in uscita a 64-bit per livellamento loudness, disaccoppiamento DC e limitatore True-Peak finale.",
                "CONSIGLIATI: 0.0 dB per uscita master calibrata; trim negativo per confronto A/B a loudness costante."
            };
        }

        if (activeHoveredComponent == &topologyBox || activeHoveredComponent->isParentOf(&topologyBox)) {
            const int id = topologyBox.getSelectedId();
            juce::String modeName = "Digital Hard (ADAA-2)";
            if (id == 2) modeName = "Gold ADC 122 (Lavry Gold)";
            else if (id == 3) modeName = "Tube Triode Class-A";
            else if (id == 4) modeName = "Germanium Diode";
            return {
                "TOPOLOGY SELECTOR",
                modeName,
                "Seleziona il modello fisico: Digital Hard (massimo RMS), Gold ADC 122 (Lavry Gold JFET H2), Tube Triode (Classe-A senza cali di volume), Germanium (grinta vintage).",
                "CONSIGLIATI: Digital = max loudness; Gold 122 = calore H2 & sag termico Lavry; Tube = valvole calde; Germanium = batteria punchy."
            };
        }

        if (activeHoveredComponent == &routingBox || activeHoveredComponent->isParentOf(&routingBox)) {
            return {
                "CHANNEL ROUTING",
                routingBox.getText(),
                "Routing dei canali: Stereo L/R, Mid/Side Split, Mid Only (clippa il centro mono), Side Only (clippa l'ampiezza stereo).",
                "CONSIGLIATI: Stereo L/R per master standard; Mid/Side Split per controllare cassa/rullante senza toccare il riverbero laterale."
            };
        }

        if (activeHoveredComponent == &monoMakerBtn) {
            return {
                "SUB-BASS MONO MAKER (< 80 Hz)",
                monoMakerBtn.getToggleState() ? "ATTIVO" : "BYPASS",
                "Filtro passa-alto sul canale Side (<80 Hz). Collassa i sub-bassi al centro perfetto per un punch solido su club system e vinile.",
                "CONSIGLIATI: Sempre ATTIVO su master dance, trap, hip-hop e per impianti subwoofer professionali."
            };
        }

        if (activeHoveredComponent == &truePeakBtn) {
            return {
                "ITU-R BS.1770-4 TRUE-PEAK GUARD",
                truePeakBtn.getToggleState() ? "ATTIVO (4x Polyphase Sinc)" : "OFF",
                "Filtro sinc polifase 4x con lookahead a 4 campioni e recupero trasparente a 2 ms. Previene la distorsione inter-sample nei DAC.",
                "CONSIGLIATI: Sempre ATTIVO per master digitali e streaming (Spotify, Apple Music, YouTube, Tidal)."
            };
        }

        if (activeHoveredComponent == &deltaAuditionBtn) {
            return {
                "DELTA AUDITION MODE",
                deltaAuditionBtn.getToggleState() ? "SOLO ATTIVO" : "OFF",
                "Mette in solo esclusivamente l'energia dei picchi rimossi dal clipper (ingresso meno uscita). Silenzio assoluto sotto soglia.",
                "STRUMENTO DI ASCOLTO: Attiva per verificare se stai tagliando solo micro-transienti o intaccando il corpo musicale."
            };
        }

        if (activeHoveredComponent == &bypassBtn) {
            return {
                "MASTER BYPASS",
                bypassBtn.getToggleState() ? "BYPASS ATTIVO" : "PROCESSORE ATTIVO",
                "Bypass hardware bit-exact che passa l'ingresso direttamente all'uscita con allineamento temporale PDC perfetto.",
                "CONFRONTO A/B: Disattiva il processore per valutare l'effettivo miglioramento dinamico e timbrico rispetto all'originale."
            };
        }

        if (activeHoveredComponent == &crtScope || activeHoveredComponent->isParentOf(&crtScope)) {
            return {
                "60 FPS CRT BIPOLAR DELTA OSCILLOSCOPE",
                "ACTIVE",
                "Hardware-accelerated real-time CRT scope displaying input signal (dim green), clipped output (amber), and delta spikes (cyan).",
                "VISUAL GUIDE: Shaded amber region shows exact waveform saturation against the calibrated ceiling grid lines."
            };
        }

        return {};
    }

    void setupRotarySlider(juce::Slider& slider, const juce::String& name) {
        slider.setName(name);
        slider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
        slider.setMouseDragSensitivity(200);
        slider.setScrollWheelEnabled(true);
        slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 72, 16);
        addAndMakeVisible(slider);
    }

    void setupButton(juce::ToggleButton& btn, const juce::String& text, bool defaultState) {
        btn.setButtonText(text);
        btn.setToggleState(defaultState, juce::dontSendNotification);
        btn.setColour(juce::ToggleButton::textColourId, juce::Colour(0xFFCCD6E0));
        btn.setColour(juce::ToggleButton::tickColourId, juce::Colour(0xFFFF9100));
        addAndMakeVisible(btn);
    }

    PerfectClipAudioProcessor& audioProcessor;
    PerfectClipBoutiqueLookAndFeel lookAndFeel;

    PerfectClipCRTScope crtScope;
    plugin_171::ResizableHandleComponent resizableHandle;

    juce::Image goldLogoImage;

    juce::Rectangle<int> bay1Bounds;
    juce::Rectangle<int> bay2Bounds;
    juce::Rectangle<int> bay3Bounds;
    juce::Rectangle<int> bay4Bounds;
    juce::Rectangle<int> infoBarBounds;

    juce::Component* activeHoveredComponent = nullptr;

    // Sliders
    juce::Slider driveSlider, ceilingSlider, kneeSlider, detailSlider, alchemySlider, outTrimSlider;

    // ComboBoxes
    juce::ComboBox topologyBox, routingBox;

    // Buttons
    juce::ToggleButton monoMakerBtn, truePeakBtn, deltaAuditionBtn, bypassBtn;

    // Attachments
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> driveAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> ceilingAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> kneeAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> detailAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> alchemyAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> outTrimAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> topologyAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> routingAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> monoMakerAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> truePeakAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> deltaAuditionAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bypassAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PerfectClipEditor)
};

} // namespace dsp171
