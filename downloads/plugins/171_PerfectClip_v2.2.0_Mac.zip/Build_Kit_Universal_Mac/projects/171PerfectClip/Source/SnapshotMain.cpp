#include <juce_gui_basics/juce_gui_basics.h>
#include "PluginProcessor.h"
#include "GUI/171PerfectClipEditor.h"

int main()
{
    juce::ScopedJuceInitialiser_GUI juceInit;

    PerfectClipAudioProcessor processor;
    processor.prepareToPlay(48000.0, 512);

    std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
    if (editor == nullptr)
        return 1;

    editor->setSize(960, 580);
    editor->resized();
    editor->repaint();

    juce::Image snapshot = editor->createComponentSnapshot(editor->getLocalBounds());

    juce::File outFile("171PerfectClip_Real_Snapshot.png");
    if (outFile.existsAsFile())
        outFile.deleteFile();

    juce::FileOutputStream stream(outFile);
    if (stream.openedOk()) {
        juce::PNGImageFormat png;
        png.writeImageToStream(snapshot, stream);
    }

    return 0;
}
