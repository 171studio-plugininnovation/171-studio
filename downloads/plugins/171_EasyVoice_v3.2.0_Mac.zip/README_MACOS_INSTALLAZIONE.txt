================================================================================
171 STUDIO INNOVATIO — 171 EasyVoice v3.2.0 (macOS)
Rilascio Ufficiale: Novembre 2026
Architetture Supportate: Apple Silicon (ARM64: M1, M2, M3, M4) & Intel (x86_64)
================================================================================

CONTENUTO DEL PACCHETTO MAC:
1. 171EasyVoice.component   (AudioUnit v2 per Logic Pro, GarageBand, Final Cut Pro)
2. 171EasyVoice.vst3        (VST3 a 64-bit per Ableton Live, FL Studio, Cubase, Studio One, Reaper)
3. 171EasyVoice.app         (Applicazione Standalone nativa macOS)
4. INSTALLA_SU_MAC.command (Installatore rapido a doppio clic con rimozione quarantena)
5. Build_Kit_Universal_Mac/ (Sorgenti C++ JUCE e build toolchain vDSP / NEON)
6. 171EasyVoice_Retina_GUI.png (Anteprima interfaccia grafica HD Retina)
7. SCHEDA_TECNICA_APPLE_MACOS.md (Dossier tecnico ufficiale di certificazione)

ISTRUZIONI DI INSTALLAZIONE RAPIDA:
Metodo 1 (Consigliato - Automatico):
- Fai doppio clic sul file 'INSTALLA_SU_MAC.command'.
- Lo script installera automaticamente i bundle nelle directory audio corrette del tuo Mac:
    * AudioUnit: ~/Library/Audio/Plug-Ins/Components/
    * VST3:      ~/Library/Audio/Plug-Ins/VST3/
    * Standalone: /Applications/171 Studio/
- Rimuovera automaticamente il blocco di sicurezza Apple Gatekeeper (quarantena).

Metodo 2 (Manuale):
- Copia '171EasyVoice.component' in: ~/Library/Audio/Plug-Ins/Components/
- Copia '171EasyVoice.vst3' in:      ~/Library/Audio/Plug-Ins/VST3/
- Rimuovi l'attributo quarantine aprendo il Terminale e digitando:
    xattr -dr com.apple.quarantine ~/Library/Audio/Plug-Ins/Components/171EasyVoice.component
    xattr -dr com.apple.quarantine ~/Library/Audio/Plug-Ins/VST3/171EasyVoice.vst3
- Riavvia Logic Pro o la tua DAW preferita.

COMPILAZIONE NATIVA DA SORGENTI (OPZIONALE PER MASSIME PRESTAZIONI):
Se desideri ricompilare il plugin con ottimizzazioni SIMD NEON e Apple Accelerate vDSP
specifiche per il processore del tuo Mac (M1-M4 o Intel):
1. Apri il Terminale ed entra nella cartella 'Build_Kit_Universal_Mac'.
2. Esegui: chmod +x build_mac.sh && ./build_mac.sh --install
3. I binari compilati verranno generati e installati direttamente nelle cartelle di sistema.

VALIDAZIONE AUDIOUNIT IN APPLE LOGIC PRO:
Per verificare la corretta registrazione AU in Logic Pro, digita nel Terminale:
    auval -v aufx 171E 171P

NOVITA DELLA RELEASE v3.2.0:
Sovereign Calibration Update v3.2.0: 1) Calibrazione acustica a guadagno unitario nominale su tutti gli 8 modelli di preamplificazione con compensazione automatica del throughput costante lungo l'escursione Drive 0-12; 2) Risoluzione della formula high-shelf ed equalizzazione Cytomic ZDF (errore di taglio ridotto da 3.71 dB a 0.03 dB); 3) Calibrazione standard decibel del compressore FET 1176 (scala reale [-24 dB, +24 dB] con 0 dB a guadagno unitario e progressione di soglia rigorosamente monotona su tutte le ratio); 4) Protezione true-peak stereo-linked certificata a -0.15 dBTP; 5) VU meter calibrato logaritmico AES e ripristino audition deltaListen.

Sito Ufficiale: https://171studio.it
Supporto Tecnico: 171studioinnovatio@gmail.com
================================================================================
