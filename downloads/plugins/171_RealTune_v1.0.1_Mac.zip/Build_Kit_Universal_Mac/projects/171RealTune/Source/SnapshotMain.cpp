#include <juce_gui_basics/juce_gui_basics.h>
#include "PluginProcessor.h"
#include "PluginEditor.h"

int main()
{
    juce::ScopedJuceInitialiser_GUI juceInit;

    AudioPluginAudioProcessor processor;
    processor.prepareToPlay(48000.0, 512);

    // Imposta parametri di fabbrica per lo snapshot: Modern Pop Vocal (C Major, Retune Speed 15 ms)
    processor.setCurrentProgram(1);

    std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
    if (editor == nullptr)
        return 1;

    editor->setSize(1180, 720);
    editor->resized();

    auto* customEditor = dynamic_cast<AudioPluginAudioProcessorEditor*>(editor.get());

    // SIMULAZIONE STRESS INTERATTIVA: CAMBIO NOTE, SCALE E MATRICE PIANOFORTE
    std::cout << "[*] Collaudo interattivo cambio nota nella GUI..." << std::endl;
    auto& apvts = processor.getAPVTS();

    // 1. Cicla tutte le 12 note tonica (Root Key C..B) sia da APVTS che da ComboBox
    for (int r = 0; r < 12; ++r) {
        if (auto* param = apvts.getParameter("root_key")) {
            param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(r)));
        }
    }

    // 2. Cicla tutti i tipi di scala
    for (int s = 0; s < 8; ++s) {
        if (auto* param = apvts.getParameter("scale_type")) {
            param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(s)));
        }
    }

    // 3. Simula click sulla matrice delle note e sui tasti del pianoforte
    for (int key = 0; key < 12; ++key) {
        processor.setNoteBlockedMask(1 << key);
        processor.setNoteBypassMask(1 << ((key + 3) % 12));
    }
    std::cout << "[*] Cambio note, scale e mascheramenti completato senza alcun crash!" << std::endl;

    // Simula segnale vocale sinusoidale modulato per popolare la telemetria continua
    juce::AudioBuffer<float> testBuffer(2, 512);
    for (int frame = 0; frame < 180; ++frame) {
        for (int ch = 0; ch < 2; ++ch) {
            float* w = testBuffer.getWritePointer(ch);
            for (int i = 0; i < 512; ++i) {
                float t = static_cast<float>(frame * 512 + i) / 48000.0f;
                float vibrato = std::sin(2.0f * juce::MathConstants<float>::pi * 5.2f * t) * 6.5f;
                float melody = std::sin(t * 1.8f) * 18.0f;
                float freq = 392.0f + melody + vibrato;
                w[i] = std::sin(2.0f * juce::MathConstants<float>::pi * freq * t) * 0.75f;
            }
        }
        juce::MidiBuffer midi;
        processor.processBlock(testBuffer, midi);

        if (frame % 3 == 0 && customEditor != nullptr) {
            customEditor->forceTelemetryUpdate();
        }
    }

    // Convergenza balistica del galvanometro e lampade spia a 60 FPS
    for (int step = 0; step < 30; ++step) {
        if (customEditor != nullptr) {
            customEditor->forceTelemetryUpdate();
        }
    }
    editor->repaint();

    // Snapshot dell'editor
    juce::Image snapshot = editor->createComponentSnapshot(editor->getLocalBounds());

    const std::vector<std::string> outPaths = {
        R"(C:\Users\171Studio\.gemini\antigravity\brain\a512c5b2-faa2-4a19-af6f-b21bbccd03db\171realtune_gui_render.png)",
        R"(C:\Users\171Studio\.gemini\antigravity\brain\b62e3def-31d8-4845-90e1-6120187f83c2\171realtune_gui_render.png)",
        R"(C:\Users\171Studio\.gemini\antigravity\brain\09083e63-7efb-4e38-b54a-484d18d4fb1f\171realtune_gui_render.png)"
    };

    for (const auto& pathStr : outPaths) {
        juce::File outFile(pathStr);
        outFile.getParentDirectory().createDirectory();
        outFile.deleteFile();

        juce::FileOutputStream stream(outFile);
        if (stream.openedOk())
        {
            juce::PNGImageFormat png;
            png.writeImageToStream(snapshot, stream);
            std::cout << "[*] GUI Snapshot salvato con successo in: " << pathStr << std::endl;
        }
    }

    return 0;
}
