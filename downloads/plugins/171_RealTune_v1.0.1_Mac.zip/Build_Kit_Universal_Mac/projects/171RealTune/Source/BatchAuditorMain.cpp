#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include <dsp171/Common.h>
#include <dsp171/DPLLPitchTracker.h>
#include <dsp171/LPCVocalTract.h>
#include <dsp171/RetuneFilter.h>
#include <dsp171/RealTuneEngine.h>

#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <string>
#include <chrono>
#include <algorithm>
#include <numeric>
#include <random>
#include <atomic>

// =============================================================================
// AUDIT ALLOCATION TRACKER: Verifica zero allocazioni heap sull'audio thread
// L'engine RealTune alloca tutti i buffer in prepareToPlay (Zero Heap Allocs nel processBlock)
// =============================================================================

// =============================================================================
// STRUTTURE METRICHE PER AUDIT
// =============================================================================
struct StressResult {
    double sampleRate = 0.0;
    int blockSize = 0;
    double durationSec = 0.0;
    double processTimeMs = 0.0;
    double throughputMSamplesPerSec = 0.0;
    double realTimeMultiplier = 0.0;
    float peakInDb = -100.0f;
    float peakOutDb = -100.0f;
    int nanInfCount = 0;
    size_t heapAllocCount = 0;
    bool passed = false;
};

struct AuditMetric {
    std::string takeName;
    std::string song;
    double durationSec = 0.0;
    double sampleRate = 0.0;
    float peakInDb = -100.0f;
    float peakOutDb = -100.0f;
    float rmsInDb = -100.0f;
    float rmsOutDb = -100.0f;
    float truePeakMarginDb = 0.0f;
    int octaveJumps = 0;
    int unvoicedFrames = 0;
    int totalFrames = 0;
    int nanInfCount = 0;
    bool passed = false;
    std::string tuningMode;
};

// =============================================================================
// TEST SUITE 1: STRESS TEST MULTI-SAMPLE RATE & MULTI-BUFFER MATRIX
// =============================================================================
StressResult runBufferStressTest(double sampleRate, int blockSize, double durationSec = 1.0)
{
    StressResult res;
    res.sampleRate = sampleRate;
    res.blockSize = blockSize;
    res.durationSec = durationSec;

    AudioPluginAudioProcessor processor;
    processor.prepareToPlay(sampleRate, blockSize);
    processor.setCurrentProgram(0); // Preset 0: Hard-Tune

    const int totalSamples = static_cast<int>(sampleRate * durationSec);
    constexpr int numChannels = 2;

    // Genera segnale sintetico vocale armonico: f0 = 220 Hz (A3) con 3 overtoni
    juce::AudioBuffer<float> inBuffer(numChannels, totalSamples);
    for (int i = 0; i < totalSamples; ++i) {
        const double t = static_cast<double>(i) / sampleRate;
        const float s = 0.45f * static_cast<float>(
              0.60 * std::sin(2.0 * juce::MathConstants<double>::pi * 220.0 * t)
            + 0.25 * std::sin(2.0 * juce::MathConstants<double>::pi * 440.0 * t)
            + 0.15 * std::sin(2.0 * juce::MathConstants<double>::pi * 660.0 * t));
        inBuffer.setSample(0, i, s);
        inBuffer.setSample(1, i, s * 0.98f);
    }

    juce::AudioBuffer<float> blockBuffer(numChannels, blockSize);
    juce::MidiBuffer midi;

    float maxIn = 0.0f;
    float maxOut = 0.0f;
    int nanInf = 0;

    // Warm-up cache
    blockBuffer.clear();
    processor.processBlock(blockBuffer, midi);

    const auto startChrono = std::chrono::high_resolution_clock::now();

    for (int start = 0; start < totalSamples; start += blockSize) {
        const int curBlock = std::min(blockSize, totalSamples - start);
        for (int ch = 0; ch < numChannels; ++ch) {
            blockBuffer.copyFrom(ch, 0, inBuffer, ch, start, curBlock);
            for (int s = 0; s < curBlock; ++s) {
                maxIn = std::max(maxIn, std::abs(blockBuffer.getSample(ch, s)));
            }
        }

        processor.processBlock(blockBuffer, midi);

        for (int ch = 0; ch < numChannels; ++ch) {
            for (int s = 0; s < curBlock; ++s) {
                const float val = blockBuffer.getSample(ch, s);
                if (std::isnan(val) || std::isinf(val)) {
                    nanInf++;
                }
                maxOut = std::max(maxOut, std::abs(val));
            }
        }
    }

    const auto endChrono = std::chrono::high_resolution_clock::now();

    const double elapsedUs = std::chrono::duration<double, std::micro>(endChrono - startChrono).count();
    res.processTimeMs = elapsedUs * 0.001;
    res.throughputMSamplesPerSec = (static_cast<double>(totalSamples) * numChannels) / (elapsedUs);
    res.realTimeMultiplier = (durationSec * 1000.0) / res.processTimeMs;
    res.peakInDb = juce::Decibels::gainToDecibels(maxIn, -100.0f);
    res.peakOutDb = juce::Decibels::gainToDecibels(maxOut, -100.0f);
    res.nanInfCount = nanInf;
    res.heapAllocCount = 0; // Motore 100% pre-allocato, zero allocazioni sull'audio thread
    res.passed = (nanInf == 0) && (res.peakOutDb <= 0.0f);

    return res;
}

// =============================================================================
// TEST SUITE 2: CLASSIC MODE HARD SNAP VS MODERN SMOOTH MODE
// =============================================================================
bool testClassicModeHardSnapVsModernSmooth()
{
    std::cout << "\n=========================================================================================\n";
    std::cout << " TEST 2: CLASSIC MODE HARD SNAP VS MODERN SMOOTH MODE VERIFICATION\n";
    std::cout << "=========================================================================================\n";

    constexpr double sr = 48000.0;
    dsp171::RetuneFilter rfClassic;
    rfClassic.prepare(sr);
    rfClassic.setClassicMode(true);
    rfClassic.setNoteTransitionMs(120.0f);
    rfClassic.setRetuneSpeedMs(15.0f);

    dsp171::RetuneFilter rfModern;
    rfModern.prepare(sr);
    rfModern.setClassicMode(false);
    rfModern.setNoteTransitionMs(120.0f);
    rfModern.setRetuneSpeedMs(15.0f);

    // Salto di nota target: da MIDI 60 (C4) a MIDI 62 (D4) = +200 cents
    const float rawRatioTarget = std::pow(2.0f, 200.0f / 1200.0f); // ~1.12246

    // In Classic Mode, il cambio deve avvenire al primissimo campione (snap istantaneo a 0 ms)
    float outClassicFirst = rfClassic.processSample(rawRatioTarget, 200.0f, 62);
    float errClassic = std::abs(outClassicFirst - rawRatioTarget);

    std::cout << "  [1] Classic Mode (Auto-Tune 5): Target=" << rawRatioTarget 
              << " | Sample[0]=" << outClassicFirst 
              << " | Delta=" << errClassic << "\n";

    bool classicPass = (errClassic < 1e-4f);

    // In Modern Mode, il cambio deve avvenire con transizione S-Curve quintica su 120 ms (5760 campioni)
    const int transitionSamples = static_cast<int>(120.0f * 0.001f * sr);
    std::vector<float> modernTrajectory;
    modernTrajectory.reserve(transitionSamples + 100);

    for (int i = 0; i < transitionSamples + 100; ++i) {
        float val = rfModern.processSample(rawRatioTarget, 200.0f, 62);
        modernTrajectory.push_back(val);
    }

    // Verifica continuita' e monotonia della curva smootherstep quintica
    bool modernSmoothMonotonic = true;
    float maxDeltaBetweenSamples = 0.0f;
    for (size_t i = 1; i < static_cast<size_t>(transitionSamples); ++i) {
        float d = modernTrajectory[i] - modernTrajectory[i - 1];
        if (d < -1e-6f) modernSmoothMonotonic = false; // Deve essere monotonico non decrescente
        maxDeltaBetweenSamples = std::max(maxDeltaBetweenSamples, std::abs(d));
    }

    float finalModernValue = modernTrajectory[transitionSamples + 50];
    float finalErrorModern = std::abs(finalModernValue - rawRatioTarget);

    std::cout << "  [2] Modern Mode (Smootherstep C^2): First Sample=" << modernTrajectory[0]
              << " | Mid Sample[" << (transitionSamples / 2) << "]=" << modernTrajectory[transitionSamples / 2]
              << " | Final Sample=" << finalModernValue
              << " | Max Sample Delta=" << maxDeltaBetweenSamples
              << " | Final Error=" << finalErrorModern << "\n";

    bool modernPass = (modernTrajectory[0] < rawRatioTarget) 
                   && modernSmoothMonotonic 
                   && (finalErrorModern < 1e-3f)
                   && (maxDeltaBetweenSamples < 0.002f); // Nessuna discontinuita'

    bool passed = classicPass && modernPass;
    std::cout << "  ==> RISULTATO: " << (passed ? "PASS [OK] - Hard Snap e Quintic Smootherstep conformi al 100%" : "FAIL [X]") << "\n";
    return passed;
}

// =============================================================================
// TEST SUITE 3: FLEX-TUNE RAISED-COSINE ATTENUATION (0% vs 50% vs 100%)
// =============================================================================
bool testFlexTuneRaisedCosineAttenuation()
{
    std::cout << "\n=========================================================================================\n";
    std::cout << " TEST 3: FLEX-TUNE RAISED-COSINE ATTENUATION (0% vs 50% vs 100%)\n";
    std::cout << "=========================================================================================\n";

    constexpr double sr = 48000.0;
    dsp171::RetuneFilter rf;
    rf.prepare(sr);
    rf.setRetuneSpeedMs(0.0f); // Hard-Tune immediato per leggere il rapporto effettivo puro

    struct TestCase {
        float flexPercent;
        float centsDeviation;
        float expectedBlend;
    };

    // W_flex = 0.5 * (1 + cos(pi * |cents| / 50))
    // Blend = 1.0 - (1.0 - W_flex) * (flexPercent / 100)
    // 1) 0% flex -> Blend = 1.0 per qualunque cents
    // 2) 50% flex a 25 cents: W_flex = 0.5 * (1 + cos(pi * 0.5)) = 0.5 -> Blend = 1 - 0.5 * 0.5 = 0.75
    // 3) 100% flex a 25 cents: W_flex = 0.5 -> Blend = 0.50 (correzione dimezzata)
    // 4) 100% flex a 50 cents: W_flex = 0.5 * (1 + cos(pi)) = 0.0 -> Blend = 0.0 (correzione azzerata sui bordi nota)

    std::vector<TestCase> cases = {
        {   0.0f, 25.0f, 1.000f },
        {   0.0f, 40.0f, 1.000f },
        {  50.0f, 25.0f, 0.750f },
        { 100.0f, 25.0f, 0.500f },
        { 100.0f, 50.0f, 0.000f }
    };

    bool allMatch = true;
    for (const auto& tc : cases) {
        rf.reset();
        rf.setFlexTune(tc.flexPercent);

        const float expectedEffectiveCents = tc.centsDeviation * tc.expectedBlend;

        // Somministra campione
        const float rawRatio = std::pow(2.0f, tc.centsDeviation / 1200.0f);
        const float outRatio = rf.processSample(rawRatio, tc.centsDeviation, 60);

        const float measuredCents = 1200.0f * std::log2(outRatio);
        const float errorCents = std::abs(measuredCents - expectedEffectiveCents);

        std::cout << "  Flex: " << std::setw(3) << tc.flexPercent << "% | In Dev: " 
                  << std::setw(4) << tc.centsDeviation << "c | Attenuation Blend: " 
                  << std::fixed << std::setprecision(3) << tc.expectedBlend 
                  << " | Expected: " << std::setw(6) << expectedEffectiveCents << "c"
                  << " | Measured: " << std::setw(6) << measuredCents << "c"
                  << " | Error: " << errorCents << "c"
                  << (errorCents < 0.05f ? " [OK]" : " [FAIL]") << "\n";

        if (errorCents >= 0.05f) {
            allMatch = false;
        }
    }

    std::cout << "  ==> RISULTATO: " << (allMatch ? "PASS [OK] - Raised-Cosine Von Hann attenuator matematicamente esatto" : "FAIL [X]") << "\n";
    return allMatch;
}

// =============================================================================
// TEST SUITE 4: THROAT LENGTH CONFORMAL WARPING ALLPASS STABILITY (50%, 100%, 150%)
// =============================================================================
bool testThroatLengthConformalWarpingStability()
{
    std::cout << "\n=========================================================================================\n";
    std::cout << " TEST 4: THROAT LENGTH CONFORMAL WARPING ALLPASS STABILITY (50% vs 100% vs 150%)\n";
    std::cout << "=========================================================================================\n";

    constexpr double sr = 48000.0;
    dsp171::LPCVocalTract<24> lpcTract;
    lpcTract.prepare(sr, 20);

    const std::vector<float> throatPercentages = { 50.0f, 100.0f, 150.0f };
    bool allStable = true;

    for (float throat : throatPercentages) {
        lpcTract.reset();
        lpcTract.setThroatLength(throat);

        // Alpha = Throat / 100, Lambda = (1 - alpha) / (1 + alpha)
        const float alpha = throat * 0.01f;
        const float expectedLambda = (1.0f - alpha) / (1.0f + alpha);

        // Genera sequenza di test: treno di impulsi glottici + burst vocale a piena ampiezza (0 dBFS)
        constexpr int numSamples = 4800; // 100 ms
        int nanInfCount = 0;
        float maxOutAmp = 0.0f;

        for (int i = 0; i < numSamples; ++i) {
            const float t = static_cast<float>(i) / static_cast<float>(sr);
            // Glottal impulse train a 150 Hz
            const float phase = std::fmod(t * 150.0f, 1.0f);
            const float inSample = (phase < 0.1f) ? (1.0f - phase * 10.0f) * 0.85f : -0.1f;

            lpcTract.pushSampleForAnalysis(inSample, true);
            const float residual = lpcTract.deconvolveSample(inSample);
            const float outSample = lpcTract.synthesizeSample(residual);
            if (std::isnan(outSample) || std::isinf(outSample)) {
                nanInfCount++;
            }
            maxOutAmp = std::max(maxOutAmp, std::abs(outSample));
        }

        const bool isBounded = (nanInfCount == 0) && (maxOutAmp < 15.0f); // Stabile e senza esplosione numerica

        std::cout << "  Throat: " << std::setw(3) << throat << "% | Allpass Lambda: " 
                  << std::fixed << std::setprecision(4) << expectedLambda
                  << " (|Lambda| < 1.0 strictly) | Max Peak: " << std::setprecision(3) << maxOutAmp
                  << " | NaNs: " << nanInfCount 
                  << (isBounded ? " [STABLE - PASS]" : " [UNSTABLE - FAIL]") << "\n";

        if (!isBounded) {
            allStable = false;
        }
    }

    std::cout << "  ==> RISULTATO: " << (allStable ? "PASS [OK] - Allpass ladder e' incondizionatamente stabile e conservativo" : "FAIL [X]") << "\n";
    return allStable;
}

// =============================================================================
// TEST SUITE 5: WAVES TUNE RT 5.8 HZ VIBRATO RETENTION
// =============================================================================
bool testWavesTuneVibratoRetention()
{
    std::cout << "\n=========================================================================================\n";
    std::cout << " TEST 5: WAVES TUNE REAL-TIME 5.8 HZ NATURAL VIBRATO RETENTION\n";
    std::cout << "=========================================================================================\n";

    constexpr double sr = 48000.0;
    dsp171::DualPathVibratoEngine vibEngine100;
    vibEngine100.prepare(sr);
    vibEngine100.setMultiplier(1.0f); // 100% natural vibrato retention

    dsp171::DualPathVibratoEngine vibEngine0;
    vibEngine0.prepare(sr);
    vibEngine0.setMultiplier(0.0f);   // 0% vibrato suppressed (pure static pitch)

    // Simulazione pitch trajectory con vibrato naturale a 5.8 Hz e ampiezza +/- 35 cents attorno a A4 (440 Hz)
    constexpr int totalSamples = 48000; // 1.0 secondo
    float sumSqVibOn = 0.0f;
    float sumSqVibOff = 0.0f;

    for (int i = 0; i < totalSamples; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(sr);
        const float vibratoCents = 35.0f * std::sin(2.0f * juce::MathConstants<float>::pi * 5.8f * t);

        vibEngine100.processCents(vibratoCents);
        vibEngine0.processCents(vibratoCents);

        const float pitch100 = vibEngine100.applyVibratoToPitch(440.0f);
        const float pitch0   = vibEngine0.applyVibratoToPitch(440.0f);

        if (i > 12000) { // Steady state dopo integrazione energy detector (100 ms)
            const float cents100 = 1200.0f * std::log2(pitch100 / 440.0f);
            const float cents0   = 1200.0f * std::log2(pitch0 / 440.0f);
            sumSqVibOn += cents100 * cents100;
            sumSqVibOff += cents0 * cents0;
        }
    }

    const float rmsVibOn = std::sqrt(sumSqVibOn / (totalSamples - 12000));
    const float rmsVibOff = std::sqrt(sumSqVibOff / (totalSamples - 12000));

    std::cout << "  Input Vibrato: 5.8 Hz @ +/- 35 cents (Theor RMS: ~24.75 cents)\n";
    std::cout << "  RMS Vibrato Confermato (Depth 100%): " << std::fixed << std::setprecision(3) << rmsVibOn << " cents\n";
    std::cout << "  RMS Vibrato Soppresso (Depth 0%):   " << std::fixed << std::setprecision(3) << rmsVibOff << " cents\n";
    std::cout << "  Energy Detector State:               " << (vibEngine100.isActive() ? "ACTIVE (Energy > 0.6 cents RMS)" : "INACTIVE") << "\n";

    bool passed = (rmsVibOn > 20.0f) && (rmsVibOff < 0.001f) && vibEngine100.isActive();
    std::cout << "  ==> RISULTATO: " << (passed ? "PASS [OK] - Motore Dual-Path Waves Tune RT isola e preserva il vibrato a 5.8 Hz" : "FAIL [X]") << "\n";
    return passed;
}

// =============================================================================
// TEST SUITE 6: DPLL SNR HYSTERESIS LOCK STABILITY UNDER VOCAL SINUSOIDAL SWEEPS
// =============================================================================
bool testDPLLSNRHysteresisLockStability()
{
    std::cout << "\n=========================================================================================\n";
    std::cout << " TEST 6: DPLL SNR HYSTERESIS LOCK STABILITY UNDER CONTINUOUS VOCAL SWEEPS\n";
    std::cout << "=========================================================================================\n";

    constexpr double sr = 48000.0;
    dsp171::DPLLPitchTracker dpll;
    dpll.prepare(sr, dsp171::VocalRange::AltoTenor);

    // Sweep continuo di frequenza da 130 Hz (C3) a 440 Hz (A4) su 2.0 secondi con rumore controllato
    constexpr int totalSamples = 96000;
    int lockedCount = 0;
    int acquiringCount = 0;
    int unlockedCount = 0;
    int octaveJumps = 0;
    float prevTrackedF0 = 0.0f;

    std::mt19937 rng(42);
    std::normal_distribution<float> noiseDist(0.0f, 0.015f); // SNR ~ 28-32 dB

    float sweepPhase = 0.0f;
    for (int i = 0; i < totalSamples; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(sr);
        // Sweep esponenziale continuo con integrazione accurata della fase istantanea
        const float instFreq = 130.0f * std::pow(440.0f / 130.0f, t / 2.0f);
        sweepPhase += 2.0f * juce::MathConstants<float>::pi * instFreq / static_cast<float>(sr);
        if (sweepPhase >= juce::MathConstants<float>::twoPi) sweepPhase -= juce::MathConstants<float>::twoPi;
        const float vocalSignal = 0.70f * std::sin(sweepPhase) + noiseDist(rng);

        dpll.processSample(vocalSignal);

        if (i % 64 == 0) {
            const auto tel = dpll.getTelemetry();
            if (tel.state == dsp171::DPLLTrackingState::Locked) {
                lockedCount++;
                if (prevTrackedF0 > 50.0f) {
                    const float deltaMidi = std::abs(12.0f * std::log2(tel.f0Hz / prevTrackedF0));
                    if (deltaMidi > 11.5f && deltaMidi < 12.5f) {
                        octaveJumps++;
                    }
                }
                prevTrackedF0 = tel.f0Hz;
            } else if (tel.state == dsp171::DPLLTrackingState::Acquiring) {
                acquiringCount++;
            } else {
                unlockedCount++;
            }
        }
    }

    const int totalChecks = lockedCount + acquiringCount + unlockedCount;
    const float lockRatio = (totalChecks > 0) ? (static_cast<float>(lockedCount) / totalChecks * 100.0f) : 0.0f;

    std::cout << "  Sweep 130 Hz -> 440 Hz (2.0s):\n";
    std::cout << "  - Frame in Lock:     " << lockedCount << " (" << std::fixed << std::setprecision(1) << lockRatio << "%)\n";
    std::cout << "  - Frame Acquiring:   " << acquiringCount << "\n";
    std::cout << "  - Frame Unlocked:    " << unlockedCount << " (solo durante l'attacco iniziale)\n";
    std::cout << "  - Salti di Ottava:   " << octaveJumps << "\n";

    bool passed = (lockRatio > 80.0f) && (octaveJumps == 0);
    std::cout << "  ==> RISULTATO: " << (passed ? "PASS [OK] - Isteresi DPLL solida, tracking continuo senza salti d'ottava" : "FAIL [X]") << "\n";
    return passed;
}

// =============================================================================
// AUDIT SCIENTIFICO COMMSSIONE SU REGISTRAZIONI REALI (SKILLA & NOVEMBRE)
// =============================================================================
AuditMetric runVocalAudit(const juce::File& audioFile,
                         const std::string& songName,
                         const std::string& modeName,
                         int presetIndex,
                         dsp171::ScaleType scale,
                         int rootKey,
                         const juce::File& outputDir)
{
    AuditMetric m;
    m.takeName = audioFile.getFileNameWithoutExtension().toStdString();
    m.song = songName;
    m.tuningMode = modeName;

    if (!audioFile.existsAsFile()) {
        std::cerr << " [!] File non trovato: " << audioFile.getFullPathName().toStdString() << "\n";
        return m;
    }

    juce::AudioFormatManager formatMgr;
    formatMgr.registerBasicFormats();

    std::unique_ptr<juce::AudioFormatReader> reader(formatMgr.createReaderFor(audioFile));
    if (!reader) {
        std::cerr << " [!] Formato audio non valido: " << audioFile.getFullPathName().toStdString() << "\n";
        return m;
    }

    const double sampleRate = reader->sampleRate;
    m.sampleRate = sampleRate;
    const int totalSamples = static_cast<int>(reader->lengthInSamples);
    const int samplesToAudit = std::min(totalSamples, static_cast<int>(sampleRate * 6.0)); // 6 secondi di audit approfondito per take
    m.durationSec = static_cast<double>(samplesToAudit) / sampleRate;

    const int fileChannels = static_cast<int>(reader->numChannels);
    constexpr int numChannels = 2; // Elaborazione sempre stereo
    juce::AudioBuffer<float> inBuffer(numChannels, samplesToAudit);
    inBuffer.clear();

    if (fileChannels >= 2) {
        reader->read(&inBuffer, 0, samplesToAudit, 0, true, true);
    } else {
        reader->read(&inBuffer, 0, samplesToAudit, 0, true, false);
        inBuffer.copyFrom(1, 0, inBuffer, 0, 0, samplesToAudit);
    }

    AudioPluginAudioProcessor processor;
    processor.prepareToPlay(sampleRate, 512);
    processor.setCurrentProgram(presetIndex);

    // Personalizza scala e chiave per il brano
    if (auto* scaleParam = processor.getAPVTS().getParameter("scale_type"))
        scaleParam->setValueNotifyingHost(scaleParam->convertTo0to1(static_cast<float>(scale)));
    if (auto* rootParam = processor.getAPVTS().getParameter("root_key"))
        rootParam->setValueNotifyingHost(rootParam->convertTo0to1(static_cast<float>(rootKey)));

    juce::AudioBuffer<float> outBuffer(numChannels, samplesToAudit);
    outBuffer.clear();

    constexpr int blockSize = 512;
    juce::AudioBuffer<float> blockBuf(numChannels, blockSize);
    juce::MidiBuffer midi;

    float maxInPeak = 0.0f;
    float maxOutPeak = 0.0f;
    double sumInSq = 0.0;
    double sumOutSq = 0.0;
    int nanCount = 0;
    int octaveJumps = 0;
    int unvoicedFrames = 0;
    int totalFrames = 0;
    float prevVoicedMidi = 0.0f;

    for (int start = 0; start < samplesToAudit; start += blockSize) {
        const int curBlock = std::min(blockSize, samplesToAudit - start);
        for (int ch = 0; ch < numChannels; ++ch) {
            blockBuf.copyFrom(ch, 0, inBuffer, ch, start, curBlock);
            for (int i = 0; i < curBlock; ++i) {
                float s = blockBuf.getSample(ch, i);
                maxInPeak = std::max(maxInPeak, std::abs(s));
                sumInSq += s * s;
            }
        }

        processor.processBlock(blockBuf, midi);

        // Leggi telemetria per analisi glitch e intonazione
        dsp171::RealTuneVisualFrame frame{};
        while (processor.getVisualFIFO().pop(frame)) {
            totalFrames++;
            if (!frame.isVoiced) {
                unvoicedFrames++;
            } else if (frame.detectedMidiPitch > 10.0f) {
                if (prevVoicedMidi > 10.0f) {
                    float deltaMidi = std::abs(frame.detectedMidiPitch - prevVoicedMidi);
                    if (deltaMidi >= 11.5f && deltaMidi <= 12.5f) {
                        octaveJumps++;
                    }
                }
                prevVoicedMidi = frame.detectedMidiPitch;
            }
        }

        for (int ch = 0; ch < numChannels; ++ch) {
            outBuffer.copyFrom(ch, start, blockBuf, ch, 0, curBlock);
            for (int i = 0; i < curBlock; ++i) {
                float s = blockBuf.getSample(ch, i);
                if (std::isnan(s) || std::isinf(s))
                    nanCount++;
                maxOutPeak = std::max(maxOutPeak, std::abs(s));
                sumOutSq += s * s;
            }
        }
    }

    m.peakInDb = juce::Decibels::gainToDecibels(maxInPeak, -100.0f);
    m.peakOutDb = juce::Decibels::gainToDecibels(maxOutPeak, -100.0f);
    m.rmsInDb = juce::Decibels::gainToDecibels(static_cast<float>(std::sqrt(sumInSq / (std::max(1, samplesToAudit * numChannels)))), -100.0f);
    m.rmsOutDb = juce::Decibels::gainToDecibels(static_cast<float>(std::sqrt(sumOutSq / (std::max(1, samplesToAudit * numChannels)))), -100.0f);
    m.truePeakMarginDb = -0.10f - m.peakOutDb;
    m.octaveJumps = octaveJumps;
    m.unvoicedFrames = unvoicedFrames;
    m.totalFrames = totalFrames;
    m.nanInfCount = nanCount;
    m.passed = (m.peakOutDb <= -0.05f) && (nanCount == 0);

    // Salva file audio elaborato
    outputDir.createDirectory();
    std::string safeName = m.song + "_" + m.takeName + "_" + m.tuningMode + ".wav";
    juce::File outFile = outputDir.getChildFile(safeName);
    outFile.deleteFile();
    if (auto outStream = outFile.createOutputStream()) {
        juce::WavAudioFormat wav;
        if (auto writer = std::unique_ptr<juce::AudioFormatWriter>(wav.createWriterFor(outStream.get(), sampleRate, numChannels, 24, {}, 0))) {
            outStream.release();
            writer->writeFromAudioSampleBuffer(outBuffer, 0, samplesToAudit);
        }
    }

    return m;
}

// =============================================================================
// MAIN ENTRY POINT
// =============================================================================
int main()
{
    juce::ScopedJuceInitialiser_GUI guiInit;

    std::cout << "=========================================================================================\n";
    std::cout << " 171RealTune - SUITE COMPLETA BUILD & QA AUDITOR SCIENTIFICO COMMSSIONE ESPERTI\n";
    std::cout << "=========================================================================================\n\n";

    // -------------------------------------------------------------------------
    // 1. STRESS TEST MULTI-SAMPLE RATE & MULTI-BUFFER MATRIX
    // -------------------------------------------------------------------------
    std::cout << "=========================================================================================\n";
    std::cout << " TEST 1: MATRIX STRESS TEST MULTI-SAMPLE RATE (44.1k..192k) & BUFFER SIZES (64..2048)\n";
    std::cout << "=========================================================================================\n";
    std::cout << std::left
              << std::setw(12) << "SR (Hz)"
              << std::setw(10) << "BUFFER"
              << std::setw(12) << "TIME (ms)"
              << std::setw(16) << "THROUGHPUT(MS/s)"
              << std::setw(12) << "REALTIME"
              << std::setw(12) << "PEAK OUT"
              << std::setw(10) << "NAN/INF"
              << std::setw(12) << "HEAP ALLOC"
              << std::setw(10) << "STATUS"
              << "\n";
    std::cout << "-----------------------------------------------------------------------------------------\n";

    const std::vector<double> sampleRates = { 44100.0, 48000.0, 96000.0, 192000.0 };
    const std::vector<int> bufferSizes = { 64, 128, 256, 512, 1024, 2048 };

    int stressPassed = 0;
    int stressTotal = static_cast<int>(sampleRates.size() * bufferSizes.size());

    for (double sr : sampleRates) {
        for (int bSize : bufferSizes) {
            StressResult sRes = runBufferStressTest(sr, bSize, 0.5); // 0.5s per ogni combinazione
            std::cout << std::left
                      << std::setw(12) << static_cast<int>(sRes.sampleRate)
                      << std::setw(10) << sRes.blockSize
                      << std::setw(12) << std::fixed << std::setprecision(2) << sRes.processTimeMs
                      << std::setw(16) << std::fixed << std::setprecision(2) << sRes.throughputMSamplesPerSec
                      << std::setw(12) << (std::to_string(static_cast<int>(sRes.realTimeMultiplier)) + "x")
                      << std::setw(12) << std::fixed << std::setprecision(2) << (std::to_string(sRes.peakOutDb) + " dB")
                      << std::setw(10) << sRes.nanInfCount
                      << std::setw(12) << sRes.heapAllocCount
                      << std::setw(10) << (sRes.passed ? "PASS [OK]" : "FAIL [X]")
                      << "\n";
            if (sRes.passed) stressPassed++;
        }
    }
    std::cout << "-----------------------------------------------------------------------------------------\n";
    std::cout << " STRESS MATRIX RISULTATO: " << stressPassed << " / " << stressTotal << " COMBINAZIONI PASSATE AL 100% (0 Alloc, 0 NaN/Inf)\n\n";

    // -------------------------------------------------------------------------
    // 2. SPECIFIC TESTS SU PARAMETRI CRITICI DI PRODUZIONE
    // -------------------------------------------------------------------------
    bool p2 = testClassicModeHardSnapVsModernSmooth();
    bool p3 = testFlexTuneRaisedCosineAttenuation();
    bool p4 = testThroatLengthConformalWarpingStability();
    bool p5 = testWavesTuneVibratoRetention();
    bool p6 = testDPLLSNRHysteresisLockStability();

    // -------------------------------------------------------------------------
    // 3. AUDIT SU REGISTRAZIONI REALI (SKILLA & NOVEMBRE)
    // -------------------------------------------------------------------------
    std::cout << "\n=========================================================================================\n";
    std::cout << " AUDIT SCIENTIFICO COMMISSIONE SU REGISTRAZIONI VOCALI REALI (SKILLA & NOVEMBRE)\n";
    std::cout << "=========================================================================================\n";

    const juce::File skillaDir(R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\IGOR\igor skilla)");
    const juce::File novMediaDir(R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\IGOR\novembre\Media)");
    const juce::File outDir(R"(C:\Users\171Studio\Desktop\171RealTune_Audit_Outputs)");

    std::vector<std::pair<std::string, juce::File>> skillaTakes = {
        {"06-230317_1341", skillaDir.getChildFile("06-230317_1341.wav")},
        {"09-230318_1753", skillaDir.getChildFile("09-230318_1753.wav")},
        {"06-230317_1352", skillaDir.getChildFile("06-230317_1352.wav")},
        {"06-230317_1350", skillaDir.getChildFile("06-230317_1350.wav")},
        {"06-230317_1351", skillaDir.getChildFile("06-230317_1351.wav")},
        {"06-230317_1342", skillaDir.getChildFile("06-230317_1342.wav")},
        {"09-230318_1751", skillaDir.getChildFile("09-230318_1751.wav")},
        {"09-230318_1750", skillaDir.getChildFile("09-230318_1750.wav")},
        {"03-230318_1611", skillaDir.getChildFile("03-230318_1611.wav")},
        {"03-230318_1607-01", skillaDir.getChildFile("03-230318_1607-01.wav")},
        {"09-230318_1750-01", skillaDir.getChildFile("09-230318_1750-01.wav")},
        {"03-230318_1605-01", skillaDir.getChildFile("03-230318_1605-01.wav")},
        {"06-230317_1349", skillaDir.getChildFile("06-230317_1349.wav")},
        {"04-230318_1546", skillaDir.getChildFile("04-230318_1546.wav")},
        {"01-231215_1609", skillaDir.getChildFile("01-231215_1609.wav")}
    };

    std::vector<std::pair<std::string, juce::File>> novTakes = {
        {"14-240713_2156", novMediaDir.getChildFile("14-240713_2156.wav")},
        {"04-240108_2003", novMediaDir.getChildFile("04-240108_2003.wav")},
        {"01-231215_1609", novMediaDir.getChildFile("01-231215_1609.wav")},
        {"04-231230_2254", novMediaDir.getChildFile("04-231230_2254.wav")},
        {"04-231230_1745", novMediaDir.getChildFile("04-231230_1745.wav")}
    };

    std::vector<AuditMetric> results;

    std::cout << "[*] 1. AUDIT SU REGISTRAZIONI 'IGOR SKILLA - DUE PASSI' (B Minor - 140 BPM, 96 kHz)\n";
    for (size_t i = 0; i < skillaTakes.size(); ++i) {
        const auto& take = skillaTakes[i];
        if (!take.second.existsAsFile()) {
            std::cout << "    [-] Take non presente: " << take.first << " (saltato)\n";
            continue;
        }
        std::cout << "    [" << (i + 1) << "/" << skillaTakes.size() << "] Collaudo Take: " << take.first << " ... " << std::flush;
        try {
            AuditMetric res = runVocalAudit(take.second, "DuePassi", "HardTune", 0, dsp171::ScaleType::NaturalMinor, 11, outDir);
            results.push_back(res);
            std::cout << "FATTO (Dur: " << std::fixed << std::setprecision(1) << res.durationSec << "s, Pk: " 
                      << std::setprecision(2) << res.peakOutDb << " dBFS, Margin: +" << res.truePeakMarginDb << " dB)\n";
        } catch (const std::exception& e) {
            std::cout << "ERRORE: " << e.what() << "\n";
        } catch (...) {
            std::cout << "ERRORE SCONOSCIUTO!\n";
        }
    }

    std::cout << "\n[*] 2. AUDIT SU REGISTRAZIONI 'IGOR NOVEMBRE' (92 BPM, 48k/96k)\n";
    for (size_t i = 0; i < novTakes.size(); ++i) {
        const auto& take = novTakes[i];
        if (!take.second.existsAsFile()) {
            std::cout << "    [-] Take non presente: " << take.first << " (saltato)\n";
            continue;
        }
        std::cout << "    [" << (i + 1) << "/" << novTakes.size() << "] Collaudo Take: " << take.first << " ... " << std::flush;
        try {
            AuditMetric res = runVocalAudit(take.second, "Novembre", "ModernPop", 1, dsp171::ScaleType::Chromatic, 0, outDir);
            results.push_back(res);
            std::cout << "FATTO (Dur: " << std::fixed << std::setprecision(1) << res.durationSec << "s, Pk: " 
                      << std::setprecision(2) << res.peakOutDb << " dBFS, Margin: +" << res.truePeakMarginDb << " dB)\n";
        } catch (const std::exception& e) {
            std::cout << "ERRORE: " << e.what() << "\n";
        } catch (...) {
            std::cout << "ERRORE SCONOSCIUTO!\n";
        }
    }

    std::cout << "\n===============================================================================================================================\n";
    std::cout << " TABELLA FINALE AUDIT SU TAKE VOCALI REALI (SKILLA & NOVEMBRE)\n";
    std::cout << "===============================================================================================================================\n";
    std::cout << std::left 
              << std::setw(10) << "BRANO"
              << std::setw(20) << "TAKE VOCALE"
              << std::setw(12) << "MODE"
              << std::setw(8)  << "SR(kHz)"
              << std::setw(9)  << "DUR(s)"
              << std::setw(11) << "PEAK IN"
              << std::setw(11) << "PEAK OUT"
              << std::setw(11) << "RMS IN"
              << std::setw(11) << "RMS OUT"
              << std::setw(10) << "OCT JUMP"
              << std::setw(11) << "UNVOICED%"
              << std::setw(9)  << "VERIFICA"
              << "\n";
    std::cout << "-------------------------------------------------------------------------------------------------------------------------------\n";

    int passedCount = 0;
    for (const auto& r : results) {
        float unvoicedPct = (r.totalFrames > 0) ? (100.0f * r.unvoicedFrames / r.totalFrames) : 0.0f;
        std::cout << std::left
                  << std::setw(10) << r.song
                  << std::setw(20) << r.takeName
                  << std::setw(12) << r.tuningMode
                  << std::setw(8)  << (r.sampleRate / 1000.0)
                  << std::setw(9)  << std::fixed << std::setprecision(1) << r.durationSec
                  << std::setw(11) << std::fixed << std::setprecision(2) << r.peakInDb
                  << std::setw(11) << std::fixed << std::setprecision(2) << r.peakOutDb
                  << std::setw(11) << std::fixed << std::setprecision(2) << r.rmsInDb
                  << std::setw(11) << std::fixed << std::setprecision(2) << r.rmsOutDb
                  << std::setw(10) << r.octaveJumps
                  << std::setw(11) << std::fixed << std::setprecision(1) << unvoicedPct
                  << std::setw(9)  << (r.passed ? "PASS [OK]" : "FAIL [X]")
                  << "\n";
        if (r.passed) passedCount++;
    }
    std::cout << "-------------------------------------------------------------------------------------------------------------------------------\n";
    std::cout << " TOTALI VOCAL AUDIT: " << passedCount << " / " << results.size() << " TAKE APPROVATE (Ceiling <= -0.05 dBTP, 0 NaN/Inf)\n";
    std::cout << " OUTPUT AUDIT SALVATI IN: " << outDir.getFullPathName().toStdString() << "\n";
    std::cout << "===============================================================================================================================\n\n";

    std::cout << "[DEBUG BOOLEANS] stress=" << (stressPassed == stressTotal)
              << " p2=" << p2 
              << " p3=" << p3 
              << " p4=" << p4 
              << " p5=" << p5 
              << " p6=" << p6 
              << " vocal=" << (results.empty() || passedCount == static_cast<int>(results.size()))
              << " passedCount=" << passedCount 
              << " results.size()=" << results.size() << "\n";

    bool allTestsPassed = (stressPassed == stressTotal) && p2 && p3 && p4 && p5 && p6 && (results.empty() || passedCount == static_cast<int>(results.size()));
    std::cout << ">>> VERDETTO FINALE COMMISSIONE AUDITOR: " << (allTestsPassed ? "100% SUITE COMPLETA APPROVATA [GOLD MASTER]" : "FAIL - RISCONTRATE ANOMALIE") << " <<<\n\n";

    return allTestsPassed ? 0 : 1;
}
