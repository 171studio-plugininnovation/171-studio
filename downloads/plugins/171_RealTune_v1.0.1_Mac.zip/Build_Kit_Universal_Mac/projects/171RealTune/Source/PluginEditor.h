#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <dsp171/BoutiqueStepperButton.h>
#include "PluginProcessor.h"
#include "GUI/171RealTuneEditor.h"

class AudioPluginAudioProcessorEditor : public juce::AudioProcessorEditor,
                                        private juce::ComboBox::Listener
{
public:
    explicit AudioPluginAudioProcessorEditor(AudioPluginAudioProcessor&);
    ~AudioPluginAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

    void forceTelemetryUpdate() { editorView.timerCallback(); }

private:
    void comboBoxChanged(juce::ComboBox* box) override;

    AudioPluginAudioProcessor& processorRef;

    // Vista GUI Master completa a 60 FPS con telemetria lock-free
    gui171::RealTuneEditorComponent editorView;

    // Selettore Preset Master nella testata & Stepper Boutique
    juce::ComboBox presetComboBox;
    std::unique_ptr<gui171::BoutiqueStepperButton> prevPresetBtn;
    std::unique_ptr<gui171::BoutiqueStepperButton> nextPresetBtn;

    // Attachments APVTS
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboBoxAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;

    std::unique_ptr<SliderAttachment> retuneSpeedAttach;
    std::unique_ptr<SliderAttachment> noteTransitionAttach;
    std::unique_ptr<SliderAttachment> toleranceAttach;
    std::unique_ptr<SliderAttachment> flexTuneAttach;
    std::unique_ptr<SliderAttachment> humanizeAttach;

    std::unique_ptr<SliderAttachment> formantAttach;
    std::unique_ptr<SliderAttachment> throatLengthAttach;
    std::unique_ptr<SliderAttachment> vibratoDepthAttach;
    std::unique_ptr<SliderAttachment> stereoWidthAttach;
    std::unique_ptr<SliderAttachment> a4RefAttach;

    std::unique_ptr<SliderAttachment> outGainAttach;
    std::unique_ptr<SliderAttachment> mixAttach;

    std::unique_ptr<ComboBoxAttachment> vocalRangeAttach;
    std::unique_ptr<ComboBoxAttachment> scaleTypeAttach;
    std::unique_ptr<ComboBoxAttachment> rootKeyAttach;

    std::unique_ptr<ButtonAttachment> liveBoothAttach;
    std::unique_ptr<ButtonAttachment> midiTargetAttach;
    std::unique_ptr<ButtonAttachment> keepFormantsAttach;
    std::unique_ptr<ButtonAttachment> classicModeAttach;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AudioPluginAudioProcessorEditor)
};
