#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_formats/juce_audio_formats.h>
#include "PluginProcessor.h"
#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>

struct TestResult {
    std::string testId;
    std::string description;
    double durationSec = 0.0;
    float peakInDb = -100.0f;
    float peakOutDb = -100.0f;
    float rmsInDb = -100.0f;
    float rmsOutDb = -100.0f;
    bool safetyPassed = false;
    int nanInfCount = 0;
    bool passed = false;
};

void runTest(const std::string& testId,
             const std::string& desc,
             const juce::File& inputFile,
             const juce::File& outputDir,
             int presetIndex,
             std::vector<TestResult>& results)
{
    TestResult res;
    res.testId = testId;
    res.description = desc;

    if (!inputFile.existsAsFile()) {
        std::cout << " [!] File non trovato: " << inputFile.getFullPathName().toStdString() << "\n";
        results.push_back(res);
        return;
    }

    juce::AudioFormatManager formatManager;
    formatManager.registerBasicFormats();

    std::unique_ptr<juce::AudioFormatReader> reader(formatManager.createReaderFor(inputFile));
    if (!reader) {
        std::cout << " [!] Errore lettura formato: " << inputFile.getFullPathName().toStdString() << "\n";
        results.push_back(res);
        return;
    }

    const double sampleRate = reader->sampleRate;
    const int numChannels = std::min(2, static_cast<int>(reader->numChannels));
    const int totalSamples = static_cast<int>(reader->lengthInSamples);
    res.durationSec = static_cast<double>(totalSamples) / sampleRate;

    juce::AudioBuffer<float> inputBuffer(numChannels, totalSamples);
    reader->read(&inputBuffer, 0, totalSamples, 0, true, true);

    AudioPluginAudioProcessor processor;
    processor.prepareToPlay(sampleRate, 512);
    processor.setCurrentProgram(presetIndex);

    juce::AudioBuffer<float> outputBuffer(numChannels, totalSamples);
    outputBuffer.clear();

    constexpr int blockSize = 512;
    juce::AudioBuffer<float> blockBuffer(numChannels, blockSize);
    juce::MidiBuffer midi;

    float maxInPeak = 0.0f;
    float maxOutPeak = 0.0f;
    double sumInSq = 0.0;
    double sumOutSq = 0.0;
    int nanCount = 0;

    for (int start = 0; start < totalSamples; start += blockSize) {
        const int curBlock = std::min(blockSize, totalSamples - start);
        for (int ch = 0; ch < numChannels; ++ch) {
            blockBuffer.copyFrom(ch, 0, inputBuffer, ch, start, curBlock);
            for (int i = 0; i < curBlock; ++i) {
                float s = blockBuffer.getSample(ch, i);
                maxInPeak = std::max(maxInPeak, std::abs(s));
                sumInSq += s * s;
            }
        }

        processor.processBlock(blockBuffer, midi);

        for (int ch = 0; ch < numChannels; ++ch) {
            outputBuffer.copyFrom(ch, start, blockBuffer, ch, 0, curBlock);
            for (int i = 0; i < curBlock; ++i) {
                float s = blockBuffer.getSample(ch, i);
                if (std::isnan(s) || std::isinf(s))
                    nanCount++;
                maxOutPeak = std::max(maxOutPeak, std::abs(s));
                sumOutSq += s * s;
            }
        }
    }

    res.peakInDb = juce::Decibels::gainToDecibels(maxInPeak, -100.0f);
    res.peakOutDb = juce::Decibels::gainToDecibels(maxOutPeak, -100.0f);
    res.rmsInDb = juce::Decibels::gainToDecibels(static_cast<float>(std::sqrt(sumInSq / (totalSamples * numChannels))), -100.0f);
    res.rmsOutDb = juce::Decibels::gainToDecibels(static_cast<float>(std::sqrt(sumOutSq / (totalSamples * numChannels))), -100.0f);
    res.nanInfCount = nanCount;
    res.safetyPassed = (res.peakOutDb <= -0.05f) && (nanCount == 0);
    res.passed = res.safetyPassed;

    // Salva file audio elaborato
    outputDir.createDirectory();
    juce::File outFile = outputDir.getChildFile(testId + ".wav");
    outFile.deleteFile();
    if (auto outStream = outFile.createOutputStream()) {
        juce::WavAudioFormat wav;
        if (auto writer = std::unique_ptr<juce::AudioFormatWriter>(wav.createWriterFor(outStream.get(), sampleRate, numChannels, 24, {}, 0))) {
            outStream.release();
            writer->writeFromAudioSampleBuffer(outputBuffer, 0, totalSamples);
        }
    }

    results.push_back(res);
}

int main()
{
    std::cout << "====================================================================\n";
    std::cout << " 171RealTune - COLLAUDO INTEL & RETUNE PITCH SU AUDIO REALE (ALBUM)\n";
    std::cout << "====================================================================\n\n";

    juce::File vocalFile(R"(C:\Users\171Studio\Desktop\beat mixtape\REC ALBUM\REC BROTHER\Media\04-251202_1939.wav)");
    juce::File brotherFile(R"(C:\Users\171Studio\Desktop\beat mixtape\brother\Brother.wav)");
    juce::File outDir(R"(C:\Users\171Studio\Desktop\beat mixtape\171RealTune_Test_Outputs)");

    std::vector<TestResult> results;

    std::cout << "[*] Test 1: VOCE REC REALE (04-251202_1939.wav)\n";
    runTest("01A_Vocal_HardTune", "Preset 01 - Cher/T-Pain Hard-Tune (0 ms)", vocalFile, outDir, 0, results);
    runTest("01B_Vocal_ModernPop", "Preset 02 - Modern Pop Vocal (15 ms)", vocalFile, outDir, 1, results);
    runTest("01C_Vocal_SubtleStudio", "Preset 03 - Subtle Studio Tuning (45 ms)", vocalFile, outDir, 2, results);

    std::cout << "\n[*] Test 2: STEM COMPLETO (Brother.wav)\n";
    runTest("02A_Brother_HardTune", "Preset 01 - Hard-Tune Full Track Test", brotherFile, outDir, 0, results);
    runTest("02B_Brother_ModernPop", "Preset 02 - Modern Pop Vocal Blend", brotherFile, outDir, 1, results);

    std::cout << "\n========================================================================================================================\n";
    std::cout << " TABELLA RISULTATI COLLAUDO E VERIFICA INGEGNERISTICA 171RealTune\n";
    std::cout << "========================================================================================================================\n";
    std::cout << std::left << std::setw(30) << "Test ID / Modalita"
              << std::setw(10) << "Dur(s)"
              << std::setw(12) << "Peak In"
              << std::setw(12) << "Peak Out"
              << std::setw(12) << "RMS In"
              << std::setw(12) << "RMS Out"
              << std::setw(12) << "SafetyCeil"
              << std::setw(10) << "NaN/Inf"
              << "Esito\n";
    std::cout << "------------------------------------------------------------------------------------------------------------------------\n";

    bool allPassed = true;
    for (const auto& r : results) {
        std::cout << std::left << std::setw(30) << r.testId
                  << std::setw(10) << std::fixed << std::setprecision(1) << r.durationSec
                  << std::setw(12) << (juce::String(r.peakInDb, 1) + " dB").toStdString()
                  << std::setw(12) << (juce::String(r.peakOutDb, 1) + " dB").toStdString()
                  << std::setw(12) << (juce::String(r.rmsInDb, 1) + " dB").toStdString()
                  << std::setw(12) << (juce::String(r.rmsOutDb, 1) + " dB").toStdString()
                  << std::setw(12) << (r.safetyPassed ? "SICURO" : "ATTENZIONE")
                  << std::setw(10) << r.nanInfCount
                  << (r.passed ? "[SUPERATO]" : "[FALLITO]") << "\n";
        if (!r.passed) allPassed = false;
    }

    std::cout << "------------------------------------------------------------------------------------------------------------------------\n";
    std::cout << "Esito complessivo: " << (allPassed ? "TUTTI I TEST SUPERATI CON SUCCESSO (100% PASS)" : "TEST NON SUPERATI") << "\n";
    std::cout << "File audio esportati in: " << outDir.getFullPathName().toStdString() << "\n";
    std::cout << "========================================================================================================================\n\n";

    return allPassed ? 0 : 1;
}
