#include "PluginProcessor.h"
#include "PluginEditor.h"

AudioPluginAudioProcessorEditor::AudioPluginAudioProcessorEditor(AudioPluginAudioProcessor& p)
    : AudioProcessorEditor(&p),
      processorRef(p),
      editorView(p.getVisualFIFO())
{
    // 1. Aggiungi la vista master come componente principale
    addAndMakeVisible(editorView);

    // 2. Collega i controlli APVTS tramite Attachment
    auto& apvts = processorRef.getAPVTS();

    retuneSpeedAttach    = std::make_unique<SliderAttachment>(apvts, "retune_speed",    editorView.getRetuneSpeedSlider());
    noteTransitionAttach = std::make_unique<SliderAttachment>(apvts, "note_transition", editorView.getNoteTransitionSlider());
    toleranceAttach      = std::make_unique<SliderAttachment>(apvts, "tolerance_cents", editorView.getToleranceSlider());
    flexTuneAttach       = std::make_unique<SliderAttachment>(apvts, "flex_tune",       editorView.getFlexTuneSlider());
    humanizeAttach       = std::make_unique<SliderAttachment>(apvts, "humanize",        editorView.getHumanizeSlider());

    formantAttach        = std::make_unique<SliderAttachment>(apvts, "formant_shift",   editorView.getFormantSlider());
    throatLengthAttach   = std::make_unique<SliderAttachment>(apvts, "throat_length",   editorView.getThroatLengthSlider());
    vibratoDepthAttach   = std::make_unique<SliderAttachment>(apvts, "vibrato_depth",   editorView.getVibratoDepthSlider());
    stereoWidthAttach    = std::make_unique<SliderAttachment>(apvts, "stereo_width",    editorView.getStereoWidthSlider());
    a4RefAttach          = std::make_unique<SliderAttachment>(apvts, "a4_reference",     editorView.getA4RefSlider());
    outGainAttach        = std::make_unique<SliderAttachment>(apvts, "out_gain",         editorView.getOutGainSlider());
    mixAttach            = std::make_unique<SliderAttachment>(apvts, "mix",              editorView.getMixSlider());

    vocalRangeAttach     = std::make_unique<ComboBoxAttachment>(apvts, "vocal_range",   editorView.getVocalRangeBox());
    rootKeyAttach        = std::make_unique<ComboBoxAttachment>(apvts, "root_key",      editorView.getRootBox());
    scaleTypeAttach      = std::make_unique<ComboBoxAttachment>(apvts, "scale_type",    editorView.getScaleBox());

    liveBoothAttach    = std::make_unique<ButtonAttachment>(apvts, "zero_latency",  editorView.getLiveBoothButton());
    midiTargetAttach   = std::make_unique<ButtonAttachment>(apvts, "midi_mode",     editorView.getMidiTargetButton());
    keepFormantsAttach = std::make_unique<ButtonAttachment>(apvts, "keep_formants", editorView.getKeepFormantsButton());
    classicModeAttach  = std::make_unique<ButtonAttachment>(apvts, "classic_mode",  editorView.getClassicModeButton());

    // Connessione diretta della lampada gemma Ruby per Master Bypass
    auto* bypassParam = apvts.getParameter("bypass");
    if (bypassParam != nullptr) {
        editorView.getBypassJewel().setLit(bypassParam->getValue() > 0.5f);
        editorView.getBypassJewel().onClick = [bypassParam](bool newState) {
            bypassParam->setValueNotifyingHost(newState ? 1.0f : 0.0f);
        };
    }

    // Connessione diretta tra la matrice note a 3 stati e il DSP Processor
    editorView.getKeyboardMatrix().onScaleChanged = [this](uint16_t active, uint16_t bypass, uint16_t blocked) {
        juce::ignoreUnused(active);
        processorRef.setNoteBypassMask(bypass);
        processorRef.setNoteBlockedMask(blocked);
    };

    // 3. Selettore Preset centrale nella testata
    presetComboBox.setLookAndFeel(&editorView.comboBoxLookAndFeel);
    const auto& presets = AudioPluginAudioProcessor::getFactoryPresets();
    for (size_t i = 0; i < presets.size(); ++i) {
        presetComboBox.addItem(presets[i].name, static_cast<int>(i + 1));
    }
    presetComboBox.setSelectedId(processorRef.getCurrentProgram() + 1, juce::dontSendNotification);
    presetComboBox.addListener(this);
    addAndMakeVisible(presetComboBox);

    // Stepper Button Boutique dorati per preset (< e >)
    prevPresetBtn = std::make_unique<gui171::BoutiqueStepperButton>(gui171::BoutiqueStepperButton::Direction::Previous);
    prevPresetBtn->setOnClick([this]() {
        int cur = presetComboBox.getSelectedId() - 1;
        int num = processorRef.getNumPrograms();
        if (num > 0) {
            int prev = (cur - 1 + num) % num;
            presetComboBox.setSelectedId(prev + 1, juce::sendNotification);
        }
    });
    addAndMakeVisible(*prevPresetBtn);

    nextPresetBtn = std::make_unique<gui171::BoutiqueStepperButton>(gui171::BoutiqueStepperButton::Direction::Next);
    nextPresetBtn->setOnClick([this]() {
        int cur = presetComboBox.getSelectedId() - 1;
        int num = processorRef.getNumPrograms();
        if (num > 0) {
            int next = (cur + 1) % num;
            presetComboBox.setSelectedId(next + 1, juce::sendNotification);
        }
    });
    addAndMakeVisible(*nextPresetBtn);

    // 4. Supporto completo Resizable Bar
    setResizable(true, true);
    setResizeLimits(944, 576, 2360, 1440);
    getConstrainer()->setFixedAspectRatio(1180.0 / 720.0);
    setSize(1180, 720);
}

AudioPluginAudioProcessorEditor::~AudioPluginAudioProcessorEditor() {
    presetComboBox.setLookAndFeel(nullptr);
    presetComboBox.removeListener(this);
}

void AudioPluginAudioProcessorEditor::comboBoxChanged(juce::ComboBox* box) {
    if (box == &presetComboBox) {
        const int selectedIdx = presetComboBox.getSelectedId() - 1;
        if (selectedIdx >= 0 && selectedIdx != processorRef.getCurrentProgram()) {
            processorRef.setCurrentProgram(selectedIdx);
            processorRef.updateHostDisplay(juce::AudioProcessor::ChangeDetails().withProgramChanged(true));
        }
    }
}

void AudioPluginAudioProcessorEditor::paint(juce::Graphics& g) {
    g.fillAll(juce::Colour(0xff0d0f13));
}

void AudioPluginAudioProcessorEditor::resized() {
    auto bounds = getLocalBounds();
    editorView.setBounds(bounds);

    // Posiziona il Preset ComboBox nella barra superiore centrato tra il bypass e le status jewel lamps con stepper buttons
    const float scaleX = (float)getWidth()  / 1180.0f;
    const float scaleY = (float)getHeight() / 720.0f;

    // Centratura precisa senza sovrapposizione: Jewel Bypass termina a X=280*scaleX, Jewel Pitch Lock inizia a X=520*scaleX
    const int prevBtnX   = juce::roundToInt(292.0f * scaleX);
    const int prevBtnW   = juce::roundToInt(20.0f * scaleX);
    const int comboX     = juce::roundToInt(316.0f * scaleX);
    const int comboW     = juce::roundToInt(166.0f * scaleX);
    const int nextBtnX   = juce::roundToInt(486.0f * scaleX);
    const int nextBtnW   = juce::roundToInt(20.0f * scaleX);
    const int controlY   = juce::roundToInt(14.0f * scaleY);
    const int controlH   = juce::roundToInt(26.0f * scaleY);

    if (prevPresetBtn != nullptr) {
        prevPresetBtn->setBounds(prevBtnX, controlY, prevBtnW, controlH);
    }
    presetComboBox.setBounds(comboX, controlY, comboW, controlH);
    if (nextPresetBtn != nullptr) {
        nextPresetBtn->setBounds(nextBtnX, controlY, nextBtnW, controlH);
    }
}
