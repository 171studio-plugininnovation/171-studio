#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <BinaryData.h>
#include "RealTuneTelemetry.h"
#include <cmath>
#include <algorithm>

namespace gui171 {

// ==============================================================================
// GALVANOMETRO DI PRECISIONE PER DEVIAZIONE IN CENTS (-50 .. +50 ¢) (60 FPS)
// QUADRANTE FOTOREALISTICO IN GRAFITE E OTTONE, AGO SPADE E CUPOLA TORNITA
// ==============================================================================
class CentDeviationGalvanometer : public juce::Component {
public:
    CentDeviationGalvanometer() {
        setOpaque(false);

        if (BinaryData::namedResourceListSize > 0) {
            needleImg = juce::ImageCache::getFromMemory(BinaryData::meter_needle_spade_png,
                                                        BinaryData::meter_needle_spade_pngSize);
            dialImg   = juce::ImageCache::getFromMemory(BinaryData::galvanometer_dial_cents_photoreal_png,
                                                        BinaryData::galvanometer_dial_cents_photoreal_pngSize);
            glassImg  = juce::ImageCache::getFromMemory(BinaryData::Glass_Overlay_Round_VU_300x300_png,
                                                        BinaryData::Glass_Overlay_Round_VU_300x300_pngSize);
        }


    }

    ~CentDeviationGalvanometer() override = default;

    void updateTelemetry(const dsp171::RealTuneVisualFrame& frame) {
        float dev = std::isfinite(frame.centsDeviation) ? frame.centsDeviation : 0.0f;
        targetCents = std::clamp(dev, -50.0f, +50.0f);
        isVoiced    = frame.isVoiced && (frame.confidence > 0.25f);

        // Se non cantato, la lancetta riposa morbidamente al centro (0 cents)
        if (!isVoiced) {
            targetCents = 0.0f;
        }

        constexpr float dt = 1.0f / 60.0f;

        // Mappatura angolare calibrata sul quadrante fotorealistico (-50 ¢ = -42°, +50 ¢ = +42°)
        constexpr float maxAngle = 0.733038f; // 42 gradi
        float targetAngle = (targetCents / 50.0f) * maxAngle;

        // Fisica balistica di 2° ordine (massa-molla-smorzatore da laboratorio analogico)
        constexpr float kSpring  = 54.0f;
        constexpr float cDamping = 10.2f;

        float force = -kSpring * (needleAngle - targetAngle) - cDamping * needleVel;
        needleVel   += force * dt;
        needleAngle += needleVel * dt;

        if (!std::isfinite(needleAngle)) needleAngle = 0.0f;
        if (!std::isfinite(needleVel)) needleVel = 0.0f;

        currentDisplayedCents += 0.25f * (targetCents - currentDisplayedCents);
        if (!std::isfinite(currentDisplayedCents)) currentDisplayedCents = 0.0f;

        repaint();
    }

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat().reduced(2.0f);
        if (bounds.isEmpty()) return;

        const float size = std::min(bounds.getWidth(), bounds.getHeight());
        const float cx = bounds.getCentreX();
        const float cy = bounds.getY() + size * 0.50f;
        const float radius = size * 0.48f;
        auto dialRect = juce::Rectangle<float>(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f);

        // 1. Quadrante analogico fotorealistico in ottone e grafite
        if (dialImg.isValid()) {
            // Ombra portata incassata nel pannello
            g.setColour(juce::Colour(0x95000000));
            g.fillEllipse(dialRect.translated(2.0f, 3.0f));

            g.drawImage(dialImg, dialRect, juce::RectanglePlacement::centred);
        } else {
            // Fallback procedurale elegante
            g.setColour(juce::Colour(0xff181a20));
            g.fillEllipse(dialRect.expanded(2.0f));

            juce::ColourGradient brassBezel(juce::Colour(0xffffe082), cx - radius, cy - radius,
                                           juce::Colour(0xff8c6e28), cx + radius, cy + radius, false);
            g.setGradientFill(brassBezel);
            g.drawEllipse(dialRect, 2.5f);

            juce::ColourGradient dialBg(juce::Colour(0xff16181f), cx, cy - radius,
                                       juce::Colour(0xff0a0c10), cx, cy + radius, false);
            g.setGradientFill(dialBg);
            g.fillEllipse(dialRect.reduced(3.0f));

            drawProceduralScale(g, cx, cy, radius * 0.85f);
        }

        // 2. Alone di intonazione dinamica "IN TUNE" (Bagliore Ciano a 0 cents - zero allocazioni heap)
        if (isVoiced && std::abs(targetCents) <= 3.0f) {
            float inTuneAngle = 0.05f;
            inTuneGlowPath.clear();
            inTuneGlowPath.addCentredArc(cx, cy, radius * 0.65f, radius * 0.65f, 0.0f, -inTuneAngle, inTuneAngle, true);
            g.setColour(juce::Colour(0x7000e5ff));
            g.strokePath(inTuneGlowPath, juce::PathStrokeType(6.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }

        // 3. Lancetta Spade fotorealistica ad alta risoluzione (Perno ribassato per scoprire la serigrafia)
        float pivotY = cy + radius * 0.12f;
        drawNeedle(g, cx, pivotY, radius * 0.68f);

        // 4. Hub centrale coprivite in ottone tornito dal pieno
        drawCenterCap(g, cx, pivotY);

        // 5. Riflesso speculare bombato del vetro dell'indicatore
        if (glassImg.isValid()) {
            g.drawImage(glassImg, dialRect.reduced(radius * 0.04f), juce::RectanglePlacement::centred);
        } else {
            drawCurvedGlassReflection(g, cx, cy, radius);
        }

        // 6. Display digitale valore Cents HUD in basso
        drawDigitalReadout(g, cx, cy + radius * 0.64f, bounds.getWidth());
    }

private:
    void drawNeedle(juce::Graphics& g, float cx, float cy, float needleLen) {
        if (needleImg.isValid()) {
            const float origPivotX = 45.0f;
            const float origPivotY = 372.0f;
            const float origLen    = 367.0f;
            const float scale = needleLen / origLen;

            // Ombra portata della lancetta a ore 4
            g.saveState();
            auto shadowXform = juce::AffineTransform::translation(-origPivotX, -origPivotY)
                                   .scaled(scale)
                                   .rotated(needleAngle)
                                   .translated(cx + 2.0f, cy + 3.0f);
            g.setOpacity(0.50f);
            g.drawImageTransformed(needleImg, shadowXform);
            g.restoreState();

            // Lancetta spade fotorealistica
            g.saveState();
            auto needleXform = juce::AffineTransform::translation(-origPivotX, -origPivotY)
                                   .scaled(scale)
                                   .rotated(needleAngle)
                                   .translated(cx, cy);
            g.drawImageTransformed(needleImg, needleXform);
            g.restoreState();
        } else {
            // Fallback procedurale
            g.saveState();
            g.addTransform(juce::AffineTransform::rotation(needleAngle, cx, cy));

            juce::Path needlePath;
            needlePath.startNewSubPath(cx - 1.8f, cy + 10.0f);
            needlePath.lineTo(cx + 1.8f, cy + 10.0f);
            needlePath.lineTo(cx + 0.6f, cy - needleLen);
            needlePath.lineTo(cx - 0.6f, cy - needleLen);
            needlePath.closeSubPath();

            g.setColour(juce::Colour(0xff181a1f));
            g.fillPath(needlePath);

            juce::Path tipPath;
            tipPath.startNewSubPath(cx - 1.2f, cy - needleLen + 14.0f);
            tipPath.lineTo(cx + 1.2f, cy - needleLen + 14.0f);
            tipPath.lineTo(cx + 0.4f, cy - needleLen);
            tipPath.lineTo(cx - 0.4f, cy - needleLen);
            tipPath.closeSubPath();

            g.setColour(juce::Colour(0xffffe082));
            g.fillPath(tipPath);
            g.restoreState();
        }
    }

    void drawCenterCap(juce::Graphics& g, float cx, float cy) {
        float capR = 8.5f;

        // Ombra cupola
        g.setColour(juce::Colour(0x95000000));
        g.fillEllipse(cx - capR + 1.0f, cy - capR + 2.0f, capR * 2.0f, capR * 2.0f);

        // Cupola in ottone tornito dal pieno
        juce::ColourGradient capGrad(juce::Colour(0xffffe082), cx - capR * 0.4f, cy - capR * 0.4f,
                                    juce::Colour(0xff6e5018), cx + capR, cy + capR, false);
        g.setGradientFill(capGrad);
        g.fillEllipse(cx - capR, cy - capR, capR * 2.0f, capR * 2.0f);

        // Bordo bisellato
        g.setColour(juce::Colour(0xffc5a059));
        g.drawEllipse(cx - capR, cy - capR, capR * 2.0f, capR * 2.0f, 1.0f);

        // Punto di riflesso speculare
        g.setColour(juce::Colours::white.withAlpha(0.6f));
        g.fillEllipse(cx - 3.0f, cy - 3.5f, 2.5f, 2.0f);
    }

    void drawProceduralScale(juce::Graphics& g, float cx, float cy, float radius) {
        constexpr float maxAngle = 0.733038f;
        for (int cents = -50; cents <= 50; cents += 5) {
            float norm = static_cast<float>(cents) / 50.0f;
            float angle = norm * maxAngle;
            bool isMajor = (cents % 10 == 0);
            float rInner = radius * (isMajor ? 0.78f : 0.83f);
            float rOuter = radius * 0.90f;

            float x1 = cx + rInner * std::sin(angle);
            float y1 = cy - rInner * std::cos(angle);
            float x2 = cx + rOuter * std::sin(angle);
            float y2 = cy - rOuter * std::cos(angle);

            g.setColour(cents == 0 ? juce::Colour(0xff00e5ff) : (isMajor ? juce::Colour(0xffffe082) : juce::Colour(0x80c5a059)));
            g.drawLine(x1, y1, x2, y2, isMajor ? 1.5f : 0.8f);
        }
    }

    void drawCurvedGlassReflection(juce::Graphics& g, float cx, float cy, float radius) {
        juce::Path glassArc;
        glassArc.addCentredArc(cx, cy, radius * 0.92f, radius * 0.75f, -0.4f,
                              -juce::MathConstants<float>::pi * 0.70f,
                              -juce::MathConstants<float>::pi * 0.15f, true);
        g.setColour(juce::Colour(0x18ffffff));
        g.strokePath(glassArc, juce::PathStrokeType(radius * 0.15f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }

    void drawDigitalReadout(juce::Graphics& g, float cx, float cy, float totalW) {
        float pillW = std::min(78.0f, totalW * 0.38f);
        float pillH = 18.0f;
        auto pillRect = juce::Rectangle<float>(cx - pillW * 0.5f, cy - pillH * 0.5f, pillW, pillH);

        // Fondo pill
        g.setColour(juce::Colour(0xf0080a0d));
        g.fillRoundedRectangle(pillRect, 4.0f);

        // Bordo
        bool inTune = isVoiced && std::abs(currentDisplayedCents) <= 3.0f;
        g.setColour(inTune ? juce::Colour(0xff00e5ff) : juce::Colour(0xffc5a059));
        g.drawRoundedRectangle(pillRect, 4.0f, 1.0f);

        // Testo valore
        g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
        g.setColour(inTune ? juce::Colour(0xff00e5ff) : (isVoiced ? juce::Colour(0xffffe082) : juce::Colour(0xff9ca3af)));

        char buf[32];
        if (isVoiced) {
            std::snprintf(buf, sizeof(buf), "%+.1f ct", currentDisplayedCents);
        } else {
            std::snprintf(buf, sizeof(buf), "--- ct");
        }
        g.drawText(buf, pillRect, juce::Justification::centred);
    }

    float targetCents = 0.0f;
    float currentDisplayedCents = 0.0f;
    float needleAngle = 0.0f;
    float needleVel   = 0.0f;
    bool isVoiced = false;

    juce::Image needleImg;
    juce::Image dialImg;
    juce::Image glassImg;

    // Buffer preallocato per zero allocazioni heap in paint
    juce::Path inTuneGlowPath;
};

} // namespace gui171
