#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <cmath>

namespace gui171 {

// ==============================================================================
// PULSANTE BOUTIQUE RETROILLUMINATO CON LED AL NEON (Console Style 171 Studio)
// ==============================================================================
class BoutiquePushButton : public juce::Button {
public:
    BoutiquePushButton(const juce::String& buttonName,
                       const juce::String& subLabel,
                       juce::Colour activeNeon)
        : juce::Button(buttonName),
          mainLabel(buttonName),
          subtitle(subLabel),
          neonColor(activeNeon)
    {
        setClickingTogglesState(true);
        setOpaque(false);
    }

    void paintButton(juce::Graphics& g, bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override {
        auto bounds = getLocalBounds().toFloat().reduced(1.0f);
        const bool active = getToggleState();

        // 1. Ombra portata incassata
        g.setColour(juce::Colours::black.withAlpha(0.6f));
        g.fillRoundedRectangle(bounds.translated(1.0f, 2.0f), 4.0f);

        // 2. Chassis metallico pulsante
        juce::Colour topCol = active ? juce::Colour(0xff2a2e38) : (shouldDrawButtonAsHighlighted ? juce::Colour(0xff22252c) : juce::Colour(0xff181a20));
        juce::Colour botCol = active ? juce::Colour(0xff14161b) : juce::Colour(0xff0d0f13);
        if (shouldDrawButtonAsDown) {
            std::swap(topCol, botCol);
        }

        juce::ColourGradient btnGrad(topCol, bounds.getX(), bounds.getY(),
                                     botCol, bounds.getX(), bounds.getBottom(), false);
        g.setGradientFill(btnGrad);
        g.fillRoundedRectangle(bounds, 4.0f);

        // 3. Cornice bisellata in ottone / titanio
        juce::Colour rimCol = active ? neonColor.withAlpha(0.85f) : (shouldDrawButtonAsHighlighted ? juce::Colour(0xffffe082) : juce::Colour(0xffc5a059));
        g.setColour(rimCol);
        g.drawRoundedRectangle(bounds, 4.0f, 1.2f);

        // 4. Indicatore LED orizzontale superiore
        float ledW = bounds.getWidth() * 0.44f;
        float ledH = 3.0f;
        float ledX = bounds.getCentreX() - ledW * 0.5f;
        float ledY = bounds.getY() + 4.5f;
        auto ledRect = juce::Rectangle<float>(ledX, ledY, ledW, ledH);

        if (active) {
            // Radiant neon bloom
            juce::ColourGradient bloom(neonColor.withAlpha(0.75f), bounds.getCentreX(), ledY + 1.5f,
                                       neonColor.withAlpha(0.0f),  bounds.getCentreX() - ledW * 0.8f, ledY + 1.5f, true);
            g.setGradientFill(bloom);
            g.fillEllipse(bounds.getCentreX() - ledW * 0.7f, ledY - 3.0f, ledW * 1.4f, 9.0f);

            g.setColour(juce::Colours::white);
            g.fillRoundedRectangle(ledRect, 1.5f);

            g.setColour(neonColor);
            g.drawRoundedRectangle(ledRect.expanded(1.0f, 0.5f), 2.0f, 1.0f);
        } else {
            g.setColour(juce::Colour(0xff1a1d24));
            g.fillRoundedRectangle(ledRect, 1.5f);
            g.setColour(juce::Colour(0x40000000));
            g.drawRoundedRectangle(ledRect, 1.5f, 0.8f);
        }

        // 5. Serigrafia testo principale
        float textTop = bounds.getY() + (subtitle.isNotEmpty() ? 10.0f : 8.0f);
        float textH   = subtitle.isNotEmpty() ? 13.0f : 16.0f;
        auto mainTextRect = juce::Rectangle<float>(bounds.getX() + 1.0f, textTop, bounds.getWidth() - 2.0f, textH);

        const float fontSize = (mainLabel.length() >= 7) ? 8.0f : ((mainLabel.length() >= 5) ? 9.0f : 10.0f);
        g.setFont(juce::FontOptions(fontSize, juce::Font::bold));
        g.setColour(active ? neonColor : (shouldDrawButtonAsHighlighted ? juce::Colour(0xffffffff) : juce::Colour(0xffd1d5db)));
        g.drawText(mainLabel, mainTextRect, juce::Justification::centred, false);

        // 6. Serigrafia sottotitolo (se presente)
        if (subtitle.isNotEmpty()) {
            auto subRect = juce::Rectangle<float>(bounds.getX(), textTop + 12.0f, bounds.getWidth(), 10.0f);
            g.setFont(juce::FontOptions(7.5f, juce::Font::plain));
            g.setColour(active ? juce::Colour(0xffffffff) : juce::Colour(0x809ca3af));
            g.drawText(subtitle, subRect, juce::Justification::centred);
        }
    }

private:
    juce::String mainLabel;
    juce::String subtitle;
    juce::Colour neonColor;
};

} // namespace gui171
