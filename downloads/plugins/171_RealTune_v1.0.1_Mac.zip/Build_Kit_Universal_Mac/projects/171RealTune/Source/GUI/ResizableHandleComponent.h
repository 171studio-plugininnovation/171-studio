#pragma once
#include <juce_gui_basics/juce_gui_basics.h>

namespace gui171 {

// ==============================================================================
// BARRA E ANGOLARE DI RIDIMENSIONAMENTO DINAMICO (RESIZABLE BAR 171 STUDIO)
// ==============================================================================
class ResizableHandleComponent : public juce::Component {
public:
    std::function<void(float currentScale)> onScaleChanged;

    ResizableHandleComponent() {
        setMouseCursor(juce::MouseCursor::BottomRightCornerResizeCursor);
    }

    ~ResizableHandleComponent() override = default;

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat();
        if (bounds.isEmpty()) return;

        // Micro scanalature zigrinate diagonali in ottone/titanio a 45 gradi
        const float w = bounds.getWidth();
        const float h = bounds.getHeight();

        // Ombre scanalature
        g.setColour(juce::Colour(0x60000000));
        g.drawLine(w - 4.0f, h, w, h - 4.0f, 1.5f);
        g.drawLine(w - 8.0f, h, w, h - 8.0f, 1.5f);
        g.drawLine(w - 12.0f, h, w, h - 12.0f, 1.5f);
        g.drawLine(w - 16.0f, h, w, h - 16.0f, 1.5f);

        // Rilievi lucidi in ottone dorato cesellato
        g.setColour(isHovered ? juce::Colour(0xffffe082) : juce::Colour(0xffc5a059));
        g.drawLine(w - 5.0f, h, w, h - 5.0f, 1.2f);
        g.drawLine(w - 9.0f, h, w, h - 9.0f, 1.2f);
        g.drawLine(w - 13.0f, h, w, h - 13.0f, 1.2f);
        g.drawLine(w - 17.0f, h, w, h - 17.0f, 1.2f);

        // Se in hover o trascinamento, mostra piccolo tooltip con percentuale di zoom
        if (isDragging || isHovered) {
            drawScaleTooltip(g);
        }
    }

    void mouseEnter(const juce::MouseEvent&) override {
        isHovered = true;
        repaint();
    }

    void mouseExit(const juce::MouseEvent&) override {
        isHovered = false;
        repaint();
    }

    void mouseDown(const juce::MouseEvent& e) override {
        if (auto* parent = getParentComponent()) {
            originalSize = parent->getBounds();
            dragStartPos = e.getScreenPosition();
            isDragging = true;
            repaint();
        }
    }

    void mouseDrag(const juce::MouseEvent& e) override {
        if (!isDragging) return;
        if (auto* parent = getParentComponent()) {
            auto delta = e.getScreenPosition() - dragStartPos;

            // Mantieni proporzioni 16:10 standard 171 Studio (base 1100 x 680)
            constexpr float baseWidth  = 1100.0f;
            constexpr float baseHeight = 680.0f;
            constexpr float aspectRatio = baseWidth / baseHeight;

            int newWidth = originalSize.getWidth() + delta.x;
            newWidth = std::clamp(newWidth, 880, 2200); // 80% a 200%
            int newHeight = juce::roundToInt(static_cast<float>(newWidth) / aspectRatio);

            parent->setSize(newWidth, newHeight);

            currentScaleRatio = static_cast<float>(newWidth) / baseWidth;
            if (onScaleChanged) {
                onScaleChanged(currentScaleRatio);
            }
            repaint();
        }
    }

    void mouseUp(const juce::MouseEvent&) override {
        isDragging = false;
        repaint();
    }

    float getCurrentScale() const noexcept { return currentScaleRatio; }

private:
    void drawScaleTooltip(juce::Graphics& g) {
        int percent = juce::roundToInt(currentScaleRatio * 100.0f);
        juce::String text = juce::String(percent) + "%";

        auto tooltipRect = juce::Rectangle<float>(0.0f, 0.0f, 38.0f, 14.0f);
        g.setColour(juce::Colour(0xf016181f));
        g.fillRoundedRectangle(tooltipRect, 3.0f);
        g.setColour(juce::Colour(0xffc5a059));
        g.drawRoundedRectangle(tooltipRect, 3.0f, 1.0f);

        g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
        g.setColour(juce::Colour(0xffffe082));
        g.drawText(text, tooltipRect, juce::Justification::centred);
    }

    bool isHovered = false;
    bool isDragging = false;
    juce::Rectangle<int> originalSize;
    juce::Point<int> dragStartPos;
    float currentScaleRatio = 1.0f;
};

} // namespace gui171
