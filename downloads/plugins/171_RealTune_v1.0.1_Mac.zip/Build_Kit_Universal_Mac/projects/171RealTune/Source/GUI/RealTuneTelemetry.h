#pragma once
#include <atomic>
#include <array>
#include <cstddef>
#include <cstdint>
#include <algorithm>
#include <cmath>

namespace dsp171 {

// ==============================================================================
// 1. FRAME TELEMETRICO PITCH REAL-TIME (Lock-Free, Cacheline Aligned)
// ==============================================================================
struct alignas(64) RealTuneVisualFrame {
    // Pitch & Frequenza rilevata dal pitch tracker (YIN / MPMP / Autocorrelazione)
    float detectedPitchHz     = 0.0f;  // Frequenza fondamentale rilevata (Hz)
    float detectedMidiPitch  = 0.0f;  // Nota MIDI frazionaria (es. 60.35 = C4 + 35 cents)
    float targetMidiPitch    = 0.0f;  // Nota MIDI target corretta post-quantizzazione
    
    // Deviazione in Cents rispetto alla nota target (-50.0 .. +50.0 cents)
    float centsDeviation     = 0.0f;  
    
    // Confidenza e stato dell'algoritmo di tracking
    float confidence         = 0.0f;  // 0.0f (rumore/fricativa) .. 1.0f (voce periodica stabile)
    bool  isVoiced           = false; // Flag Voiced/Unvoiced (true = intonabile)
    
    // Indici delle note musicali (0 = C, 1 = C#, 2 = D, ..., 11 = B)
    uint8_t detectedNoteIndex = 0;    // Nota cantata più vicina
    uint8_t targetNoteIndex   = 0;    // Nota target impostata dalla scala
    
    // Maschera di stato delle 12 note cromatiche (Bitmask per UI Matrix)
    uint16_t activeScaleMask  = 0x0FFF; // 1 = Nota attiva nella scala, 0 = Esclusa
    uint16_t bypassedScaleMask = 0x0000; // 1 = Nota in bypass (lasciata naturale)
    
    // Livelli di segnale per metering e gating ottico
    float inputRMS           = 0.0f;  // Livello RMS d'ingresso lineare
    float inputPeak          = 0.0f;  // Peak d'ingresso lineare
    float retuneCorrectionAmt = 0.0f; // Grado istantaneo di correzione applicato (0..1)

    // Telemetria profonda dei motori reverse-engineered (Waves Tune RT & Antares Auto-Tune Pro)
    float dpllSNRDb          = 0.0f;
    bool  isDPLLLocked       = false;
    float vibratoCents       = 0.0f;
    float throatLambda       = 0.0f;
    bool  classicModeActive  = false;
};

// ==============================================================================
// 2. FIFO SPSC LOCK-FREE TELEMETRIA (Audio Thread -> GUI Thread 60 FPS)
// ==============================================================================
template <typename T, size_t Capacity = 1024>
class LockFreeTelemetryFIFO {
    static_assert((Capacity & (Capacity - 1)) == 0, "Capacity must be a power of 2");

public:
    LockFreeTelemetryFIFO() : head(0), tail(0) {}

    // Chiamato dall'Audio Thread: push rapido senza allocazioni né mutex
    bool push(const T& item) noexcept {
        const size_t currentTail = tail.load(std::memory_order_relaxed);
        const size_t currentHead = head.load(std::memory_order_acquire);

        if ((currentTail - currentHead) >= Capacity) {
            return false; // Buffer pieno: scarta il frame senza bloccare l'elaborazione audio
        }

        buffer[currentTail & BufferMask] = item;
        tail.store(currentTail + 1, std::memory_order_release);
        return true;
    }

    // Chiamato dal GUI Thread (60 FPS): drena i dati per il rendering
    bool pop(T& item) noexcept {
        const size_t currentHead = head.load(std::memory_order_relaxed);
        const size_t currentTail = tail.load(std::memory_order_acquire);

        if (currentHead == currentTail) {
            return false; // Buffer vuoto
        }

        item = buffer[currentHead & BufferMask];
        head.store(currentHead + 1, std::memory_order_release);
        return true;
    }

    void reset() noexcept {
        head.store(0, std::memory_order_relaxed);
        tail.store(0, std::memory_order_relaxed);
    }

    bool isEmpty() const noexcept {
        return head.load(std::memory_order_relaxed) == tail.load(std::memory_order_relaxed);
    }

    size_t getNumAvailable() const noexcept {
        return tail.load(std::memory_order_relaxed) - head.load(std::memory_order_relaxed);
    }

private:
    static constexpr size_t BufferMask = Capacity - 1;
    alignas(64) std::array<T, Capacity> buffer{};
    alignas(64) std::atomic<size_t> head{0};
    alignas(64) std::atomic<size_t> tail{0};
};

using RealTuneVisualFIFO = LockFreeTelemetryFIFO<RealTuneVisualFrame, 1024>;

// ==============================================================================
// 3. BUFFER CIRCOLARE STORICO DEL PITCH (GUI Thread Rolling Display)
// ==============================================================================
// Mantiene gli ultimi N campioni visivi per lo scrolling orizzontale a 60 FPS
class PitchHistoryBuffer {
public:
    static constexpr size_t MaxHistoryPoints = 600; // ~10 secondi a 60 FPS o 5s a 120 FPS

    PitchHistoryBuffer() {
        for (auto& p : history) {
            p = {};
        }
    }

    void pushPoint(const RealTuneVisualFrame& frame) noexcept {
        history[writeIndex] = frame;
        writeIndex = (writeIndex + 1) % MaxHistoryPoints;
        if (numPoints < MaxHistoryPoints) {
            numPoints++;
        }
    }

    size_t getCount() const noexcept { return numPoints; }

    // Ritorna il punto all'offset ritardato (0 = più recente/adesso, count-1 = più vecchio)
    const RealTuneVisualFrame& getPointFromNewest(size_t offset) const noexcept {
        if (numPoints == 0) return emptyFrame;
        size_t idx = (writeIndex + MaxHistoryPoints - 1 - offset) % MaxHistoryPoints;
        return history[idx];
    }

    void clear() noexcept {
        writeIndex = 0;
        numPoints = 0;
    }

private:
    std::array<RealTuneVisualFrame, MaxHistoryPoints> history{};
    size_t writeIndex = 0;
    size_t numPoints  = 0;
    RealTuneVisualFrame emptyFrame{};
};

} // namespace dsp171
