#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <cmath>
#include <algorithm>

namespace gui171 {

// ==============================================================================
// LOOK AND FEEL PER I COMBOBOX BOUTIQUE (Key, Scale, Presets) 171 STUDIO
// ==============================================================================
class Studio171ComboBoxLookAndFeel : public juce::LookAndFeel_V4 {
public:
    Studio171ComboBoxLookAndFeel() {
        setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff14161d));
        setColour(juce::ComboBox::textColourId,       juce::Colour(0xfff1f5f9));
        setColour(juce::ComboBox::outlineColourId,    juce::Colour(0xffc5a059));
        setColour(juce::ComboBox::arrowColourId,      juce::Colour(0xffd4af37));

        setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xf80f1116));
        setColour(juce::PopupMenu::textColourId,       juce::Colour(0xfff1f5f9));
        setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xff2a2418));
        setColour(juce::PopupMenu::highlightedTextColourId,       juce::Colour(0xffffe082));
    }

    void drawComboBox(juce::Graphics& g, int width, int height, bool /*isButtonDown*/,
                      int buttonX, int buttonY, int buttonW, int buttonH, juce::ComboBox& box) override
    {
        auto bounds = juce::Rectangle<float>(0.0f, 0.0f, static_cast<float>(width), static_cast<float>(height)).reduced(1.0f);

        // 1. Ombra portata incassata
        g.setColour(juce::Colours::black.withAlpha(0.55f));
        g.fillRoundedRectangle(bounds.translated(1.0f, 2.0f), 4.0f);

        // 2. Corpo metallico in titanio scuro spazzolato
        juce::ColourGradient grad(juce::Colour(0xff222630), bounds.getX(), bounds.getY(),
                                  juce::Colour(0xff101217), bounds.getX(), bounds.getBottom(), false);
        g.setGradientFill(grad);
        g.fillRoundedRectangle(bounds, 4.0f);

        // 3. Bordo satinato in oro/bronzo cesellato
        g.setColour(box.hasKeyboardFocus(true) ? juce::Colour(0xffffe082) : juce::Colour(0xffc5a059));
        g.drawRoundedRectangle(bounds, 4.0f, 1.2f);

        // Micro-riflesso speculare sul bordo superiore
        g.setColour(juce::Colour(0x33ffffff));
        g.drawHorizontalLine(juce::roundToInt(bounds.getY() + 1.0f), bounds.getX() + 4.0f, bounds.getRight() - 4.0f);

        // Divisore verticale tra testo e freccia
        float divX = static_cast<float>(buttonX);
        g.setColour(juce::Colour(0x35c5a059));
        g.drawVerticalLine(juce::roundToInt(divX), bounds.getY() + 3.0f, bounds.getBottom() - 3.0f);

        // Freccia chevron dorata
        float arrowCx = static_cast<float>(buttonX) + static_cast<float>(buttonW) * 0.5f;
        float arrowCy = static_cast<float>(buttonY) + static_cast<float>(buttonH) * 0.5f;
        float arrowW = 8.0f;
        float arrowH = 5.0f;

        juce::Path arrow;
        arrow.startNewSubPath(arrowCx - arrowW * 0.5f, arrowCy - arrowH * 0.5f);
        arrow.lineTo(arrowCx, arrowCy + arrowH * 0.5f);
        arrow.lineTo(arrowCx + arrowW * 0.5f, arrowCy - arrowH * 0.5f);

        g.setColour(juce::Colour(0xffd4af37));
        g.strokePath(arrow, juce::PathStrokeType(2.0f, juce::PathStrokeType::mitered, juce::PathStrokeType::rounded));
    }

    juce::Font getComboBoxFont(juce::ComboBox&) override {
        return juce::FontOptions(11.5f, juce::Font::bold);
    }

    void positionComboBoxText(juce::ComboBox& box, juce::Label& label) override {
        label.setBounds(8, 1, box.getWidth() - 28, box.getHeight() - 2);
        label.setFont(getComboBoxFont(box));
    }

    juce::Component* getParentComponentForMenuOptions (const juce::PopupMenu::Options& options) override {
        if (auto* target = options.getTargetComponent()) {
            return target->getTopLevelComponent();
        }
        return options.getParentComponent();
    }
};

} // namespace gui171
