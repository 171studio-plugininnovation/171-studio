#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "RealTuneTelemetry.h"
#include <array>
#include <functional>

namespace gui171 {

// ==============================================================================
// STATO SINGOLA NOTA NELLA MATRICE
// ==============================================================================
enum class NoteCorrectionState {
    Tuned = 0,    // Attiva: intonata alla scala (LED Verde)
    Bypassed = 1, // Bypass: passa naturale (LED Ambra)
    Blocked = 2   // Esclusa: non è un target ammissibile (LED Spento/Rosso)
};

// ==============================================================================
// TASTIERA PIANOFORTE & MATRICE 12-NOTE CON TELEMETRIA LED DINAMICA (60 FPS)
// ==============================================================================
class ScaleKeyboardMatrixComponent : public juce::Component {
public:
    std::function<void(uint16_t activeMask, uint16_t bypassMask, uint16_t blockedMask)> onScaleChanged;

    ScaleKeyboardMatrixComponent() {
        setOpaque(false);
        noteStates.fill(NoteCorrectionState::Tuned);
        ledIntensity.fill(0.0f);
    }

    ~ScaleKeyboardMatrixComponent() override = default;

    void updateTelemetry(const dsp171::RealTuneVisualFrame& frame) {
        currentDetectedNote = frame.detectedNoteIndex;
        currentTargetNote  = frame.targetNoteIndex;
        isVoiced           = frame.isVoiced && (frame.confidence > 0.25f);

        // Bagliore LED cantato
        if (isVoiced && currentDetectedNote >= 0 && currentDetectedNote < 12) {
            ledIntensity[currentDetectedNote] = 1.0f;
        }

        constexpr float decay = 0.88f; // Decadimento morbido a 60 FPS
        for (int i = 0; i < 12; ++i) {
            if (!isVoiced || i != currentDetectedNote) {
                ledIntensity[i] *= decay;
            }
        }

        repaint();
    }

    void setNoteState(int noteIndex, NoteCorrectionState state) {
        if (noteIndex >= 0 && noteIndex < 12) {
            noteStates[noteIndex] = state;
            notifyScaleChange();
            repaint();
        }
    }

    NoteCorrectionState getNoteState(int noteIndex) const noexcept {
        return (noteIndex >= 0 && noteIndex < 12) ? noteStates[noteIndex] : NoteCorrectionState::Tuned;
    }

    void setScalePreset(uint16_t activeMask, uint16_t bypassMask = 0, bool sendNotification = true) {
        for (int i = 0; i < 12; ++i) {
            bool isActive   = (activeMask & (1 << i)) != 0;
            bool isBypassed = (bypassMask & (1 << i)) != 0;

            if (isBypassed)      noteStates[i] = NoteCorrectionState::Bypassed;
            else if (isActive)   noteStates[i] = NoteCorrectionState::Tuned;
            else                 noteStates[i] = NoteCorrectionState::Blocked;
        }
        if (sendNotification)
            notifyScaleChange();
        repaint();
    }

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat();
        if (bounds.isEmpty()) return;

        // 1. Telaio metallico in titanio/alluminio nero spazzolato
        juce::ColourGradient chassisGrad(juce::Colour(0xff181a22), bounds.getX(), bounds.getY(),
                                         juce::Colour(0xff0c0d12), bounds.getX(), bounds.getBottom(), false);
        g.setGradientFill(chassisGrad);
        g.fillRoundedRectangle(bounds, 6.0f);

        // Bordo in ottone satinato caldo
        g.setColour(juce::Colour(0xffc5a059));
        g.drawRoundedRectangle(bounds, 6.0f, 1.2f);

        // Ombra interna
        g.setColour(juce::Colour(0x60000000));
        g.drawRoundedRectangle(bounds.reduced(1.0f), 5.0f, 1.0f);

        // 2. Suddivisione altezza: Matrice LED (28 px sopra) e Tastiera (sotto)
        float matrixH = 26.0f;
        auto matrixArea   = bounds.removeFromTop(matrixH).reduced(4.0f, 2.0f);
        auto keyboardArea = bounds.reduced(5.0f, 4.0f);

        drawStateMatrixLEDs(g, matrixArea);
        drawPianoKeys(g, keyboardArea);
    }

    void mouseDown(const juce::MouseEvent& e) override {
        auto bounds = getLocalBounds().toFloat();
        float matrixH = 26.0f;
        auto matrixArea   = bounds.removeFromTop(matrixH);
        auto keyboardArea = bounds;

        auto pos = e.position;

        // Click sulla matrice dei bottoni LED di stato (Tuned -> Bypassed -> Blocked -> Tuned)
        if (matrixArea.contains(pos)) {
            float colW = matrixArea.getWidth() / 12.0f;
            int noteIdx = std::clamp(static_cast<int>((pos.getX() - matrixArea.getX()) / colW), 0, 11);

            int nextState = (static_cast<int>(noteStates[noteIdx]) + 1) % 3;
            noteStates[noteIdx] = static_cast<NoteCorrectionState>(nextState);
            notifyScaleChange();
            repaint();
            return;
        }

        // Click sui tasti del pianoforte (Toggle rapido Attivo / Muto)
        if (keyboardArea.contains(pos)) {
            int clickedKey = getKeyAtPosition(pos, keyboardArea);
            if (clickedKey >= 0 && clickedKey < 12) {
                if (noteStates[clickedKey] == NoteCorrectionState::Tuned)
                    noteStates[clickedKey] = NoteCorrectionState::Blocked;
                else
                    noteStates[clickedKey] = NoteCorrectionState::Tuned;

                notifyScaleChange();
                repaint();
            }
        }
    }

private:
    void notifyScaleChange() {
        uint16_t activeMask = 0;
        uint16_t bypassMask = 0;
        uint16_t blockedMask = 0;

        for (int i = 0; i < 12; ++i) {
            if (noteStates[i] == NoteCorrectionState::Tuned)
                activeMask |= (1 << i);
            else if (noteStates[i] == NoteCorrectionState::Bypassed)
                bypassMask |= (1 << i);
            else if (noteStates[i] == NoteCorrectionState::Blocked)
                blockedMask |= (1 << i);
        }

        if (onScaleChanged)
            onScaleChanged(activeMask, bypassMask, blockedMask);
    }

    void drawStateMatrixLEDs(juce::Graphics& g, const juce::Rectangle<float>& area) {
        static const char* noteLabels[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
        float colW = area.getWidth() / 12.0f;

        for (int i = 0; i < 12; ++i) {
            auto cell = juce::Rectangle<float>(area.getX() + i * colW, area.getY(), colW, area.getHeight()).reduced(1.5f, 1.0f);

            // Fondo incassato pulsante cella
            g.setColour(juce::Colour(0xff090a0d));
            g.fillRoundedRectangle(cell, 3.0f);
            g.setColour(juce::Colour(0xff22252e));
            g.drawRoundedRectangle(cell, 3.0f, 0.8f);

            // Micro-LED orizzontale in cima alla cella
            float ledW = cell.getWidth() * 0.55f;
            float ledH = 2.4f;
            auto ledRect = juce::Rectangle<float>(cell.getCentreX() - ledW * 0.5f, cell.getY() + 2.5f, ledW, ledH);

            juce::Colour ledCol;
            switch (noteStates[i]) {
                case NoteCorrectionState::Tuned:    ledCol = juce::Colour(0xff00ffaa); break; // Verde/Menta
                case NoteCorrectionState::Bypassed: ledCol = juce::Colour(0xffffaa00); break; // Ambra/Giallo
                case NoteCorrectionState::Blocked:  ledCol = juce::Colour(0x35ff3b30); break; // Spento/Rosso cupo
            }

            // Bagliore extra se la nota è cantata
            float sungGlow = ledIntensity[i];
            if (sungGlow > 0.05f) {
                g.setColour(ledCol.withAlpha(0.6f * sungGlow));
                g.fillRoundedRectangle(ledRect.expanded(2.0f, 1.0f), 2.0f);
            }

            g.setColour(ledCol);
            g.fillRoundedRectangle(ledRect, 1.2f);

            // Testo etichetta nota
            g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
            if (noteStates[i] == NoteCorrectionState::Blocked) {
                g.setColour(juce::Colour(0x60808a9d));
            } else if (noteStates[i] == NoteCorrectionState::Bypassed) {
                g.setColour(juce::Colour(0xffffaa00));
            } else {
                g.setColour(juce::Colour(0xfff1f5f9));
            }

            g.drawText(noteLabels[i], cell.getX(), cell.getY() + 5.0f, cell.getWidth(), cell.getHeight() - 5.0f, juce::Justification::centred);

            // Barra barrata rossa se bloccata
            if (noteStates[i] == NoteCorrectionState::Blocked) {
                g.setColour(juce::Colour(0x80ff3b30));
                g.drawLine(cell.getX() + 3.0f, cell.getBottom() - 3.0f, cell.getRight() - 3.0f, cell.getY() + 7.0f, 1.2f);
            }
        }
    }

    void drawPianoKeys(juce::Graphics& g, const juce::Rectangle<float>& area) {
        static const int whiteNotes[] = { 0, 2, 4, 5, 7, 9, 11 };
        static const int blackNotes[] = { 1, 3, 6, 8, 10 };
        static const int blackKeyPositions[] = { 0, 1, 3, 4, 5 };

        const int numWhiteKeys = 7;
        const float whiteKeyW = area.getWidth() / static_cast<float>(numWhiteKeys);
        const float blackKeyW = whiteKeyW * 0.62f;
        const float blackKeyH = area.getHeight() * 0.62f;

        // 1. Disegna i tasti bianchi (avorio/madreperla da studio)
        for (int i = 0; i < numWhiteKeys; ++i) {
            int noteIdx = whiteNotes[i];
            auto keyRect = juce::Rectangle<float>(area.getX() + i * whiteKeyW, area.getY(), whiteKeyW, area.getHeight()).reduced(0.8f, 0.0f);

            // Gradiente avorio / metallo chiaro satinato
            juce::Colour topCol = juce::Colour(0xffe8ecef);
            juce::Colour botCol = juce::Colour(0xffb8c0c8);

            // Bagliore cantato istantaneo
            float glow = ledIntensity[noteIdx];
            if (glow > 0.05f) {
                topCol = topCol.interpolatedWith(juce::Colour(0xff00ffcc), glow * 0.7f);
                botCol = botCol.interpolatedWith(juce::Colour(0xff00aa88), glow * 0.7f);
            }

            if (noteStates[noteIdx] == NoteCorrectionState::Blocked) {
                topCol = topCol.interpolatedWith(juce::Colour(0xff555a66), 0.65f);
                botCol = botCol.interpolatedWith(juce::Colour(0xff333640), 0.65f);
            }

            juce::ColourGradient keyGrad(topCol, keyRect.getX(), keyRect.getY(),
                                        botCol, keyRect.getX(), keyRect.getBottom(), false);
            g.setGradientFill(keyGrad);
            g.fillRoundedRectangle(keyRect, 2.0f);

            // Bordo tasto
            g.setColour(juce::Colour(0x501a1c24));
            g.drawRoundedRectangle(keyRect, 2.0f, 0.8f);

            // Ombra sottile al fondo
            g.setColour(juce::Colour(0x40000000));
            g.drawHorizontalLine(juce::roundToInt(keyRect.getBottom() - 1.0f), keyRect.getX() + 1.0f, keyRect.getRight() - 1.0f);
        }

        // 2. Disegna i tasti neri (ebano / grafite opaca)
        for (int i = 0; i < 5; ++i) {
            int noteIdx = blackNotes[i];
            int whitePos = blackKeyPositions[i];
            float blackX = area.getX() + (whitePos + 1) * whiteKeyW - blackKeyW * 0.5f;
            auto keyRect = juce::Rectangle<float>(blackX, area.getY(), blackKeyW, blackKeyH);

            // Ombra portata del tasto nero verso destra
            g.setColour(juce::Colour(0x80000000));
            g.fillRoundedRectangle(keyRect.translated(1.5f, 2.0f), 2.5f);

            juce::Colour topCol = juce::Colour(0xff2a2d36);
            juce::Colour botCol = juce::Colour(0xff121318);

            float glow = ledIntensity[noteIdx];
            if (glow > 0.05f) {
                topCol = topCol.interpolatedWith(juce::Colour(0xff00e5ff), glow * 0.75f);
                botCol = botCol.interpolatedWith(juce::Colour(0xff006688), glow * 0.75f);
            }

            if (noteStates[noteIdx] == NoteCorrectionState::Blocked) {
                topCol = topCol.interpolatedWith(juce::Colour(0xff181a20), 0.7f);
                botCol = botCol.interpolatedWith(juce::Colour(0xff0a0b0e), 0.7f);
            }

            juce::ColourGradient keyGrad(topCol, keyRect.getX(), keyRect.getY(),
                                        botCol, keyRect.getX(), keyRect.getBottom(), false);
            g.setGradientFill(keyGrad);
            g.fillRoundedRectangle(keyRect, 2.5f);

            g.setColour(juce::Colour(0xff3f4452));
            g.drawRoundedRectangle(keyRect, 2.5f, 0.8f);
        }
    }

    int getKeyAtPosition(juce::Point<float> pos, const juce::Rectangle<float>& area) const {
        if (area.getWidth() <= 1.0f || area.getHeight() <= 1.0f)
            return -1;

        static const int whiteNotes[] = { 0, 2, 4, 5, 7, 9, 11 };
        static const int blackNotes[] = { 1, 3, 6, 8, 10 };
        static const int blackKeyPositions[] = { 0, 1, 3, 4, 5 };

        const int numWhiteKeys = 7;
        const float whiteKeyW = area.getWidth() / static_cast<float>(numWhiteKeys);
        const float blackKeyW = whiteKeyW * 0.62f;
        const float blackKeyH = area.getHeight() * 0.62f;

        // Controlla prima i tasti neri (sono sopra)
        if (pos.getY() <= area.getY() + blackKeyH) {
            for (int i = 0; i < 5; ++i) {
                int whitePos = blackKeyPositions[i];
                float blackX = area.getX() + (whitePos + 1) * whiteKeyW - blackKeyW * 0.5f;
                auto keyRect = juce::Rectangle<float>(blackX, area.getY(), blackKeyW, blackKeyH);
                if (keyRect.contains(pos))
                    return blackNotes[i];
            }
        }

        // Altrimenti tasto bianco
        int whiteIdx = std::clamp(static_cast<int>((pos.getX() - area.getX()) / whiteKeyW), 0, 6);
        return whiteNotes[whiteIdx];
    }

    std::array<NoteCorrectionState, 12> noteStates;
    std::array<float, 12> ledIntensity;
    int currentDetectedNote = -1;
    int currentTargetNote   = -1;
    bool isVoiced = false;
};

} // namespace gui171
