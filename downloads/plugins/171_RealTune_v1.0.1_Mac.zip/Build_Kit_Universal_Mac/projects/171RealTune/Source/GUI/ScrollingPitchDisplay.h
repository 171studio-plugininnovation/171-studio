#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <BinaryData.h>
#include "RealTuneTelemetry.h"
#include <vector>
#include <cmath>

namespace gui171 {

// ==============================================================================
// DISPLAY CENTRALE A SCROLLING CRT CON VETRO POLARIZZATO DA STUDIO (60 FPS)
// CHASSIS OSCILLOSCOPIO RACKMOUNT FOTOREALISTICO IN TITANIO E PHOSPHOR GRID
// ==============================================================================
class ScrollingPitchDisplay : public juce::Component {
public:
    ScrollingPitchDisplay() {
        setOpaque(false);
        minMidiNote = 48.0f; // C3
        maxMidiNote = 72.0f; // C5

        if (BinaryData::namedResourceListSize > 0) {
            crtBezelImg = juce::ImageCache::getFromMemory(BinaryData::crt_pitch_display_bezel_photoreal_png,
                                                          BinaryData::crt_pitch_display_bezel_photoreal_pngSize);
            glassOverlayImg = juce::ImageCache::getFromMemory(BinaryData::display_glass_overlay_png,
                                                              BinaryData::display_glass_overlay_pngSize);
            logoWatermarkImg = juce::ImageCache::getFromMemory(BinaryData::logo_171_gold_png,
                                                               BinaryData::logo_171_gold_pngSize);
        }

    }

    ~ScrollingPitchDisplay() override = default;

    void resized() override {
        auto bounds = getLocalBounds().toFloat().reduced(1.0f);
        if (bounds.getWidth() <= 1.0f || bounds.getHeight() <= 1.0f) return;
        if (crtBezelImg.isValid()) {
            int w = juce::roundToInt(bounds.getWidth());
            int h = juce::roundToInt(bounds.getHeight());
            cachedCrtBezel = juce::Image(juce::Image::ARGB, w, h, true);
            juce::Graphics bgG(cachedCrtBezel);
            float srcW = static_cast<float>(crtBezelImg.getWidth());
            float srcH = static_cast<float>(crtBezelImg.getHeight());
            bgG.drawImage(crtBezelImg,
                          0, 0, w, h,
                          juce::roundToInt(srcW * 0.055f), 0,
                          juce::roundToInt(srcW * 0.89f), juce::roundToInt(srcH));
        }
    }

    void updateTelemetry(dsp171::RealTuneVisualFIFO& fifo) {
        dsp171::RealTuneVisualFrame frame;
        bool hasNewData = false;

        while (fifo.pop(frame)) {
            historyBuffer.pushPoint(frame);
            latestFrame = frame;
            hasNewData = true;
        }

        if (hasNewData) {
            // Auto-tracking morbido del range verticale
            if (latestFrame.isVoiced && latestFrame.confidence > 0.4f) {
                float currentNote = latestFrame.detectedMidiPitch;
                if (currentNote < minMidiNote + 2.0f) {
                    minMidiNote = std::max(24.0f, minMidiNote - 0.2f);
                    maxMidiNote = minMidiNote + 24.0f;
                } else if (currentNote > maxMidiNote - 2.0f) {
                    maxMidiNote = std::min(108.0f, maxMidiNote + 0.2f);
                    minMidiNote = maxMidiNote - 24.0f;
                }
            }
            repaint();
        }
    }

    void setMidiRange(float minNote, float maxNote) {
        minMidiNote = minNote;
        maxMidiNote = maxNote;
        repaint();
    }

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat().reduced(1.0f);
        if (bounds.isEmpty()) return;

        // 1. Disegno dello Chassis Oscilloscopio Fotorealistico (Pre-cached blit per 60 FPS costanti)
        if (cachedCrtBezel.isValid()) {
            g.drawImageAt(cachedCrtBezel, juce::roundToInt(bounds.getX()), juce::roundToInt(bounds.getY()));
        } else if (crtBezelImg.isValid()) {
            float srcW = static_cast<float>(crtBezelImg.getWidth());
            float srcH = static_cast<float>(crtBezelImg.getHeight());
            // Ritaglia le alette rack laterali per integrare la cornice massiccia nel pannello
            g.drawImage(crtBezelImg,
                        juce::roundToInt(bounds.getX()), juce::roundToInt(bounds.getY()),
                        juce::roundToInt(bounds.getWidth()), juce::roundToInt(bounds.getHeight()),
                        juce::roundToInt(srcW * 0.055f), 0,
                        juce::roundToInt(srcW * 0.89f), juce::roundToInt(srcH));
        } else {
            // Fallback chassis procedurale
            g.setColour(juce::Colour(0xff12141a));
            g.fillRoundedRectangle(bounds, 6.0f);
            g.setColour(juce::Colour(0xff080a0d));
            g.fillRoundedRectangle(bounds.reduced(14.0f, 10.0f), 4.0f);
        }

        // Calcolo area utile dello schermo CRT interno (incassato nel pozzetto del bezel)
        float padX = crtBezelImg.isValid() ? bounds.getWidth() * 0.130f : 16.0f;
        float padY = crtBezelImg.isValid() ? bounds.getHeight() * 0.145f : 12.0f;
        auto screenArea = bounds.reduced(padX, padY);

        // 2. Logo 171 Studio in background DIETRO lo schermo (traslucido)
        if (logoWatermarkImg.isValid()) {
            g.saveState();
            g.setOpacity(0.18f);
            float logoH = screenArea.getHeight() * 0.70f;
            float logoW = logoH * (static_cast<float>(logoWatermarkImg.getWidth()) / static_cast<float>(logoWatermarkImg.getHeight()));
            auto logoRect = screenArea.withSizeKeepingCentre(logoW, logoH);
            g.drawImage(logoWatermarkImg, logoRect, juce::RectanglePlacement::centred);
            g.restoreState();
        }

        // 3. Griglia Semitoni / Piano Roll Reticle Orizzontale
        drawSemitoneGrid(g, screenArea);

        // 3. Traccia Pitch Rilevato (Raw Singing Pitch - Warm Studio Amber Phosphor)
        drawPitchCurve(g, screenArea, false);

        // 4. Traccia Pitch Target Corretto (Tuned Quantized Pitch - Electric Laser Cyan Phosphor)
        drawPitchCurve(g, screenArea, true);

        // 5. Cursore / Playhead "NOW" sul bordo destro dello schermo
        drawPlayhead(g, screenArea);

        // 6. Overlay Vetro Antiriflesso Polarizzato con Riflessi Speculari da Studio
        if (glassOverlayImg.isValid()) {
            g.saveState();
            g.setOpacity(0.40f);
            g.drawImage(glassOverlayImg, screenArea, juce::RectanglePlacement::stretchToFit);
            g.restoreState();
        }

        // 7. Bordo sottile dorato di raccordo perimetro tubo catodico
        g.setColour(juce::Colour(0x30c5a059));
        g.drawRoundedRectangle(screenArea, 4.0f, 1.0f);
    }

private:
    float midiToY(float midiNote, const juce::Rectangle<float>& area) const noexcept {
        if (!std::isfinite(midiNote)) return area.getBottom();
        const float span = std::max(1.0f, maxMidiNote - minMidiNote);
        float normalized = (midiNote - minMidiNote) / span;
        normalized = std::clamp(normalized, 0.0f, 1.0f);
        return area.getBottom() - normalized * area.getHeight();
    }

    bool isBlackKey(int midiNote) const noexcept {
        int noteInOctave = ((midiNote % 12) + 12) % 12;
        return (noteInOctave == 1 || noteInOctave == 3 || noteInOctave == 6 || 
                noteInOctave == 8 || noteInOctave == 10);
    }

    juce::String getNoteName(int midiNote) const {
        static const char* noteNames[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
        int octave = (midiNote / 12) - 1;
        int note = ((midiNote % 12) + 12) % 12;
        return juce::String(noteNames[note]) + juce::String(octave);
    }

    void drawSemitoneGrid(juce::Graphics& g, const juce::Rectangle<float>& area) {
        int startNote = static_cast<int>(std::floor(minMidiNote));
        int endNote   = static_cast<int>(std::ceil(maxMidiNote));

        for (int note = startNote; note <= endNote; ++note) {
            float y = midiToY(static_cast<float>(note), area);

            bool isRootC = (note % 12 == 0);

            if (isRootC) {
                // Linea separatrice d'ottava in oro/ambra
                g.setColour(juce::Colour(0x60c5a059));
                g.drawLine(area.getX(), y, area.getRight(), y, 1.0f);

                g.setFont(juce::FontOptions(9.0f, juce::Font::bold));
                g.setColour(juce::Colour(0xa0ffe082));
                g.drawText(getNoteName(note), area.getX() + 6.0f, y - 6.0f, 28.0f, 12.0f, juce::Justification::left);
            } else if (!crtBezelImg.isValid()) {
                // Tacche semitonali leggere se non c'è il graticule fotorealistico
                g.setColour(juce::Colour(0x18ffffff));
                g.drawHorizontalLine(juce::roundToInt(y), area.getX(), area.getRight());
            }
        }
    }

    void drawPitchCurve(juce::Graphics& g, const juce::Rectangle<float>& area, bool isTuned) {
        const size_t count = historyBuffer.getCount();
        if (count < 2) return;

        // Riuso buffer path preallocato (Zero allocazioni heap a 60 FPS)
        juce::Path& path = isTuned ? tunedPitchPath : rawPitchPath;
        path.clear();
        bool inVoicedSegment = false;

        const float stepX = area.getWidth() / static_cast<float>(dsp171::PitchHistoryBuffer::MaxHistoryPoints);
        const float startX = area.getRight() - static_cast<float>(count) * stepX;

        for (size_t i = 0; i < count; ++i) {
            size_t offset = count - 1 - i;
            const auto& pt = historyBuffer.getPointFromNewest(offset);

            float x = startX + static_cast<float>(i) * stepX;
            float note = isTuned ? pt.targetMidiPitch : pt.detectedMidiPitch;

            if (pt.isVoiced && pt.confidence > 0.25f && note > 0.0f) {
                float y = midiToY(note, area);
                if (!inVoicedSegment) {
                    path.startNewSubPath(x, y);
                    inVoicedSegment = true;
                } else {
                    path.lineTo(x, y);
                }
            } else {
                inVoicedSegment = false;
            }
        }

        if (path.isEmpty()) return;

        if (isTuned) {
            // Tuned Quantized Pitch: Ciano Elettrico Fosfori ad alta emissione
            g.setColour(juce::Colour(0x5000f0ff));
            g.strokePath(path, juce::PathStrokeType(6.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            g.setColour(juce::Colour(0xff00f0ff));
            g.strokePath(path, juce::PathStrokeType(2.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            g.setColour(juce::Colours::white);
            g.strokePath(path, juce::PathStrokeType(1.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        } else {
            // Raw Singing Pitch: Ambra analogico caldo vintage
            g.setColour(juce::Colour(0x35ffaa00));
            g.strokePath(path, juce::PathStrokeType(4.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            g.setColour(juce::Colour(0xd0ffaa00));
            g.strokePath(path, juce::PathStrokeType(1.8f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }
    }

    void drawPlayhead(juce::Graphics& g, const juce::Rectangle<float>& area) {
        float x = area.getRight() - 1.0f;

        // Linea playhead NOW in ciano fosforo
        g.setColour(juce::Colour(0x4000f0ff));
        g.drawLine(x, area.getY(), x, area.getBottom(), 3.0f);

        g.setColour(juce::Colour(0xff00f0ff));
        g.drawLine(x, area.getY(), x, area.getBottom(), 1.0f);

        if (latestFrame.isVoiced && latestFrame.confidence > 0.25f) {
            float yTuned = midiToY(latestFrame.targetMidiPitch, area);
            float yRaw   = midiToY(latestFrame.detectedMidiPitch, area);

            // Cursore raw (Ambra)
            g.setColour(juce::Colour(0xffffaa00));
            g.fillEllipse(x - 3.5f, yRaw - 3.5f, 7.0f, 7.0f);

            // Cursore tuned (Ciano brillante con corona)
            g.setColour(juce::Colour(0x6000f0ff));
            g.fillEllipse(x - 5.5f, yTuned - 5.5f, 11.0f, 11.0f);
            g.setColour(juce::Colours::white);
            g.fillEllipse(x - 2.5f, yTuned - 2.5f, 5.0f, 5.0f);
        }
    }

public:
    dsp171::PitchHistoryBuffer historyBuffer;
    dsp171::RealTuneVisualFrame latestFrame;

private:
    float minMidiNote = 48.0f;
    float maxMidiNote = 72.0f;

    juce::Image crtBezelImg;
    juce::Image glassOverlayImg;
    juce::Image logoWatermarkImg;
    juce::Image cachedCrtBezel;

    // Buffer preallocati per zero allocazioni heap in paint
    juce::Path rawPitchPath;
    juce::Path tunedPitchPath;
};

} // namespace gui171
