#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <BinaryData.h>

namespace gui171 {

struct RealTuneAssets {
    static juce::Image getDialScale() {
        return juce::ImageCache::getFromMemory(BinaryData::dial_scale_calibrated_png, BinaryData::dial_scale_calibrated_pngSize);
    }

    static juce::Image getGlassOverlay() {
        return juce::ImageCache::getFromMemory(BinaryData::display_glass_overlay_png, BinaryData::display_glass_overlay_pngSize);
    }

    static juce::Image getSpadeNeedle() {
        return juce::ImageCache::getFromMemory(BinaryData::meter_needle_spade_png, BinaryData::meter_needle_spade_pngSize);
    }

    static juce::Image getKnobGunmetal() {
        return juce::ImageCache::getFromMemory(BinaryData::knob_gunmetal_makeup_png, BinaryData::knob_gunmetal_makeup_pngSize);
    }

    static juce::Image getFaderCap() {
        return juce::ImageCache::getFromMemory(BinaryData::Fader_Cap_Boutique_Gunmetal_AmberLED_Master_png, BinaryData::Fader_Cap_Boutique_Gunmetal_AmberLED_Master_pngSize);
    }

    static juce::Image getFaderTrack() {
        return juce::ImageCache::getFromMemory(BinaryData::Fader_Track_Boutique_AgedBrass_Slot_Master_png, BinaryData::Fader_Track_Boutique_AgedBrass_Slot_Master_pngSize);
    }

    static juce::Image getFaderScale() {
        return juce::ImageCache::getFromMemory(BinaryData::Fader_Scale_Precision_dB_Calibrated_Master_240x980_png, BinaryData::Fader_Scale_Precision_dB_Calibrated_Master_240x980_pngSize);
    }

    static juce::Image getJewelRuby() {
        return juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_ruby_on_png, BinaryData::lamp_jewel_ruby_on_pngSize);
    }

    static juce::Image getJewelGreen() {
        return juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_green_on_png, BinaryData::lamp_jewel_green_on_pngSize);
    }

    static juce::Image getJewelAmber() {
        return juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_amber_on_png, BinaryData::lamp_jewel_amber_on_pngSize);
    }

    static juce::Image getJewelDark() {
        return juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_dark_off_png, BinaryData::lamp_jewel_dark_off_pngSize);
    }
};

} // namespace gui171
