#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <BinaryData.h>
#include <cmath>
#include <algorithm>

namespace gui171 {

// ==============================================================================
// LOOK AND FEEL PER LE MANOPOLE BOUTIQUE IN OTTONE ZIGRINATO 171 STUDIO
// ==============================================================================
class BoutiqueMachinedKnobLookAndFeel : public juce::LookAndFeel_V4 {
public:
    enum class KnurlStyle {
        MachinedBrass_Cyan,     // Retune Speed
        MachinedBrass_Emerald,  // Humanize
        MachinedBrass_Magenta,  // Formant Shift (Bipolare da centro)
        MachinedBrass_Gold      // Default / Reference
    };

    explicit BoutiqueMachinedKnobLookAndFeel(KnurlStyle style = KnurlStyle::MachinedBrass_Cyan)
        : currentStyle(style)
    {
        // 1. Carica texture fotografica tornita in ottone zigrinato dal pieno
        if (BinaryData::namedResourceListSize > 0) {
            knobImg = juce::ImageCache::getFromMemory(BinaryData::Knob_171_MachinedBrass_KnurledTeeth_256x256_png,
                                                      BinaryData::Knob_171_MachinedBrass_KnurledTeeth_256x256_pngSize);
            scaleImg = juce::ImageCache::getFromMemory(BinaryData::dial_scale_calibrated_png,
                                                       BinaryData::dial_scale_calibrated_pngSize);
        }

        // 2. Colori al neon coordinati 171 Studio
        switch (style) {
            case KnurlStyle::MachinedBrass_Cyan:
                neonColor = juce::Colour(0xff00f0ff);
                isBipolar = false;
                break;
            case KnurlStyle::MachinedBrass_Emerald:
                neonColor = juce::Colour(0xff00ffaa);
                isBipolar = false;
                break;
            case KnurlStyle::MachinedBrass_Magenta:
                neonColor = juce::Colour(0xffff0088);
                isBipolar = true; // Centro a 0 st
                break;
            case KnurlStyle::MachinedBrass_Gold:
                neonColor = juce::Colour(0xffffaa00);
                isBipolar = false;
                break;
        }
    }

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPosProportional, float rotaryStartAngle,
                          float rotaryEndAngle, juce::Slider& /*slider*/) override
    {
        const float size = static_cast<float>(juce::jmin(width, height));
        const float cx = static_cast<float>(x) + static_cast<float>(width) * 0.5f;
        const float cy = static_cast<float>(y) + static_cast<float>(height) * 0.5f;

        const float radius = size * 0.5f - 2.0f;
        const float arcRadius = radius - 4.0f;
        const float capRadius = radius * 0.69f;

        // Calcolo angolo cursore (rotazione fisica -140° a +140°)
        const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

        // 1. Quadrante graduato calibrato fotografico (Scale Plate)
        if (scaleImg.isValid()) {
            const float imgW = static_cast<float>(scaleImg.getWidth());
            const float imgH = static_cast<float>(scaleImg.getHeight());
            const float scale = (radius * 2.02f) / imgW;

            auto xform = juce::AffineTransform::translation(-imgW * 0.5f, -imgH * 0.5f)
                            .scaled(scale)
                            .translated(cx, cy);
            g.drawImageTransformed(scaleImg, xform);
        } else {
            // Fallback serigrafico procedurale
            const int numTicks = 11;
            for (int i = 0; i < numTicks; ++i) {
                float normT = (float)i / (float)(numTicks - 1);
                float tickAngle = rotaryStartAngle + normT * (rotaryEndAngle - rotaryStartAngle);
                float rInner = radius - 3.0f;
                float rOuter = radius + 2.0f;
                float tx1 = cx + rInner * std::sin(tickAngle);
                float ty1 = cy - rInner * std::cos(tickAngle);
                float tx2 = cx + rOuter * std::sin(tickAngle);
                float ty2 = cy - rOuter * std::cos(tickAngle);

                bool isMajor = (i == 0 || i == 5 || i == 10);
                g.setColour(isMajor ? juce::Colour(0xffc59c52) : juce::Colour(0x608c7042));
                g.drawLine(tx1, ty1, tx2, ty2, isMajor ? 1.5f : 0.8f);
            }
        }

        // 2. Traccia circolare scura incassata nel pannello
        juce::Path trackBg;
        trackBg.addCentredArc(cx, cy, arcRadius, arcRadius, 0.0f,
                              rotaryStartAngle, rotaryEndAngle, true);
        g.setColour(juce::Colour(0x70090a0d));
        g.strokePath(trackBg, juce::PathStrokeType(4.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // 3. Micro-Bloom Radiale Neon a 4 stadi
        float arcStart = rotaryStartAngle;
        float arcEnd = angle;
        if (isBipolar) {
            float midAngle = (rotaryStartAngle + rotaryEndAngle) * 0.5f;
            arcStart = juce::jmin(midAngle, angle);
            arcEnd   = juce::jmax(midAngle, angle);
        }

        if (std::abs(arcEnd - arcStart) > 0.015f) {
            juce::Path activeArc;
            activeArc.addCentredArc(cx, cy, arcRadius, arcRadius, 0.0f,
                                    arcStart, arcEnd, true);

            // Pass 1: Diffuse Soft Glow
            g.setColour(neonColor.withAlpha(0.22f));
            g.strokePath(activeArc, juce::PathStrokeType(13.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Pass 2: Medium Halation
            g.setColour(neonColor.withAlpha(0.50f));
            g.strokePath(activeArc, juce::PathStrokeType(6.8f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Pass 3: Saturated Core
            g.setColour(neonColor.withAlpha(0.95f));
            g.strokePath(activeArc, juce::PathStrokeType(3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Pass 4: White Hot Center Filament
            g.setColour(juce::Colours::white.withAlpha(0.85f));
            g.strokePath(activeArc, juce::PathStrokeType(1.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }

        // 4. Ombra portata del pomello metallico orientata a ore 4 (luce fissa a 105°)
        g.setColour(juce::Colour(0x80000000));
        g.fillEllipse(cx - capRadius + 1.8f, cy - capRadius + 3.2f, capRadius * 2.0f, capRadius * 2.0f);

        // 5. Pomello in ottone dentato con rotazione concentrica
        if (knobImg.isValid()) {
            const float imgW = static_cast<float>(knobImg.getWidth());
            const float imgH = static_cast<float>(knobImg.getHeight());
            const float scale = (capRadius * 2.0f) / imgW;

            auto xform = juce::AffineTransform::translation(-imgW * 0.5f, -imgH * 0.5f)
                            .scaled(scale)
                            .rotated(angle)
                            .translated(cx, cy);
            g.drawImageTransformed(knobImg, xform);
        } else {
            // Fallback procedurale di alta qualità se l'immagine non è caricata
            juce::ColourGradient knobGrad(juce::Colour(0xff2d313b), cx - capRadius * 0.5f, cy - capRadius * 0.5f,
                                         juce::Colour(0xff121419), cx + capRadius, cy + capRadius, false);
            g.setGradientFill(knobGrad);
            g.fillEllipse(cx - capRadius, cy - capRadius, capRadius * 2.0f, capRadius * 2.0f);

            g.setColour(juce::Colour(0xffc5a059));
            g.drawEllipse(cx - capRadius, cy - capRadius, capRadius * 2.0f, capRadius * 2.0f, 1.5f);

            // Tacca cursore
            float pX = cx + (capRadius - 4.0f) * std::sin(angle);
            float pY = cy - (capRadius - 4.0f) * std::cos(angle);
            g.setColour(juce::Colour(0xffffe082));
            g.drawLine(cx, cy, pX, pY, 2.0f);
        }
    }

private:
    KnurlStyle currentStyle;
    juce::Colour neonColor;
    bool isBipolar = false;
    juce::Image knobImg;
    juce::Image scaleImg;
};

// ==============================================================================
// COMPONENTE MODULO MANOPOLA BOUTIQUE (Titolo + Knob + Pill Display)
// ==============================================================================
class BoutiqueMachinedKnobComponent : public juce::Component {
public:
    enum class DisplayFormat {
        TimeMs,       // es. 15.0 ms
        Percentage,   // es. 35 %
        Semitones,    // es. +0.0 st
        Decibels,     // es. +0.0 dB
        Hertz         // es. 440.0 Hz
    };

    BoutiqueMachinedKnobComponent(const juce::String& name,
                                  BoutiqueMachinedKnobLookAndFeel::KnurlStyle style,
                                  DisplayFormat format)
        : knobName(name), dispFormat(format), lookAndFeel(style)
    {
        setOpaque(false);

        slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        slider.setLookAndFeel(&lookAndFeel);
        slider.setRotaryParameters(juce::MathConstants<float>::pi * 1.25f,
                                   juce::MathConstants<float>::pi * 2.75f, true);
        addAndMakeVisible(slider);

        slider.onValueChange = [this]() {
            updatePillText();
            repaint();
        };
    }

    ~BoutiqueMachinedKnobComponent() override {
        slider.setLookAndFeel(nullptr);
    }

    void resized() override {
        auto area = getLocalBounds();
        
        // Header con titolo del controllo (16 px)
        titleArea = area.removeFromTop(18);

        // Readout pill container in basso (20 px)
        pillArea = area.removeFromBottom(22).reduced(juce::jmax(2, (area.getWidth() - 72) / 2), 2).toFloat();

        // Area slider centrale quadrata
        int side = juce::jmin(area.getWidth(), area.getHeight());
        slider.setBounds(area.getCentreX() - side / 2, area.getY() + (area.getHeight() - side) / 2, side, side);
    }

    void paint(juce::Graphics& g) override {
        updatePillText();

        // 1. Serigrafia Titolo Controllo in Oro Satinato 171 Studio
        g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xffffe082));
        g.drawText(knobName, titleArea, juce::Justification::centred);

        // 2. Fondo incassato del Display Pill
        g.setColour(juce::Colour(0xff090a0d));
        g.fillRoundedRectangle(pillArea, 4.0f);

        // Bordo bisellato in ottone/oro caldo
        g.setColour(juce::Colour(0xffc5a059));
        g.drawRoundedRectangle(pillArea, 4.0f, 1.0f);

        // 3. Testo Valore formattato nel pill
        g.setFont(juce::FontOptions(10.5f, juce::Font::bold));
        g.setColour(juce::Colour(0xfff1f5f9));
        g.drawText(cachedValueText, pillArea, juce::Justification::centred);
    }

    void updatePillText() {
        double val = slider.getValue();
        char buf[32];
        switch (dispFormat) {
            case DisplayFormat::TimeMs:
                std::snprintf(buf, sizeof(buf), "%.1f ms", val);
                break;
            case DisplayFormat::Percentage:
                std::snprintf(buf, sizeof(buf), "%d %%", juce::roundToInt(val));
                break;
            case DisplayFormat::Semitones:
                std::snprintf(buf, sizeof(buf), "%+.1f st", val);
                break;
            case DisplayFormat::Decibels:
                std::snprintf(buf, sizeof(buf), "%+.1f dB", val);
                break;
            case DisplayFormat::Hertz:
                std::snprintf(buf, sizeof(buf), "%.1f Hz", val);
                break;
        }
        cachedValueText = buf;
    }

    juce::Slider slider;

private:
    juce::String knobName;
    DisplayFormat dispFormat;
    BoutiqueMachinedKnobLookAndFeel lookAndFeel;
    juce::Rectangle<int> titleArea;
    juce::Rectangle<float> pillArea;
    juce::String cachedValueText = "0.0";
};

} // namespace gui171
