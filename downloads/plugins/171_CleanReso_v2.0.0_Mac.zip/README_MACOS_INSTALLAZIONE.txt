================================================================================
171 STUDIO INNOVATIO — 171 CleanReso v2.0.0 (macOS)
Rilascio Ufficiale: Patch 2.0.0 (4 Novembre 2026)
Architetture Supportate: Apple Silicon (ARM64: M1, M2, M3, M4) & Intel (x86_64)
================================================================================

CONTENUTO DEL PACCHETTO MAC:
1. 171CleanReso.component   (AudioUnit v2 per Logic Pro, GarageBand, Final Cut Pro)
2. 171CleanReso.vst3        (VST3 a 64-bit per Ableton Live, FL Studio, Cubase, Studio One, Reaper)
3. 171CleanReso.app         (Applicazione Standalone nativa macOS)
4. INSTALLA_SU_MAC.command (Installatore rapido a doppio clic con rimozione quarantena)
5. Build_Kit_Universal_Mac/ (Sorgenti C++ JUCE e build toolchain vDSP / NEON)
6. 171CleanReso_Retina_GUI.png (Anteprima interfaccia grafica HD Retina)

ISTRUZIONI DI INSTALLAZIONE RAPIDA:
Metodo 1 (Consigliato - Automatico):
- Fai doppio clic sul file 'INSTALLA_SU_MAC.command'.
- Lo script installerà automaticamente i bundle nelle directory audio corrette del tuo Mac:
    * AudioUnit: ~/Library/Audio/Plug-Ins/Components/
    * VST3:      ~/Library/Audio/Plug-Ins/VST3/
    * Standalone: /Applications/171 Studio/
- Rimuoverà automaticamente il blocco di sicurezza Apple Gatekeeper (quarantena).

Metodo 2 (Manuale):
- Copia '171CleanReso.component' in: ~/Library/Audio/Plug-Ins/Components/
- Copia '171CleanReso.vst3' in:      ~/Library/Audio/Plug-Ins/VST3/
- Rimuovi l'attributo quarantine aprendo il Terminale e digitando:
    xattr -dr com.apple.quarantine ~/Library/Audio/Plug-Ins/Components/171CleanReso.component
    xattr -dr com.apple.quarantine ~/Library/Audio/Plug-Ins/VST3/171CleanReso.vst3
- Riavvia Logic Pro o la tua DAW preferita.

COMPILAZIONE NATIVA DA SORGENTI (OPZIONALE PER MASSIME PRESTAZIONI):
Se desideri ricompilare il plugin con ottimizzazioni SIMD NEON e Apple Accelerate vDSP
specifiche per il processore del tuo Mac (M1-M4 o Intel):
1. Apri il Terminale ed entra nella cartella 'Build_Kit_Universal_Mac'.
2. Esegui: chmod +x build_mac.sh && ./build_mac.sh --install
3. I binari compilati verranno generati e installati direttamente nelle cartelle di sistema.

VALIDAZIONE AUDIOUNIT IN APPLE LOGIC PRO:
Per verificare la corretta registrazione AU in Logic Pro, digita nel Terminale:
    auval -v aufx 171S 171P

NOVITÀ DELLA PATCH v2.0.0 (4.11.2026):
- Motore DSP Core dsp171 interamente ricompilato in C++20 con ottimizzazioni SIMD e zero heap allocations nel thread audio.
- Risoluzione analitica esatta del vertice parabolico True-Peak ITU-R BS.1770 per azzeramento assoluto di ISP sottostimati.
- Protezione totale anti-denormale a livello campionario (< -144 dBFS) su tutti gli stadi IIR e filtri allpass.
- Saturazione analogica a trasferimento Classe-A asintotico strettamente monotono.
- Spiegazioni interattive e consigli pratici di studio in lingua italiana integrati per ciascun parametro.

Sito Ufficiale: https://171studio.it
Supporto Tecnico: 171studioinnovatio@gmail.com
================================================================================
