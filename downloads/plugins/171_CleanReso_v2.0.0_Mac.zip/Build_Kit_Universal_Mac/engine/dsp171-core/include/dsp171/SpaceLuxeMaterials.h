#pragma once

#include <cmath>
#include <array>
#include <algorithm>
#include <string_view>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>

namespace dsp171 {

// =============================================================================
// 171 SpaceLuxe - Acoustic Materials & Boundary Physics Engine
// 171 Studio Innovatio - High Precision Physical Acoustics C++20 Header
//
// Compliant with International Standards:
// - ISO 354: Measurement of sound absorption in a reverberation room
//   Octave bands: 125 Hz, 250 Hz, 500 Hz, 1000 Hz, 2000 Hz, 4000 Hz, 8000 Hz
// - ISO 17497-1 / 17497-2: Sound scattering & random-incidence diffusion coefficients
// - ISO 9613-1: Calculation of the attenuation of sound by atmospheric absorption
// - Sabine & Eyring-Norris extended reverberation decay theory for FDN-16
// =============================================================================

enum class RoomMaterialType : uint8_t {
    WoodBoiserie = 0,     // Legno / Boiserie & Parquet (Pannello risonante su intercapedine)
    MarbleStone = 1,      // Marmo Lucido / Granito Levigato (Rigido anelastico speculare)
    ArchitecturalGlass = 2,// Vetro Singolo / Stratificato (Riflettente brillante, minima diffusione)
    HeavyVelvet = 3,      // Velluto Pesante / Tendaggio Arricciato (Assorbitore poroso resistivo)
    SteelPlate = 4,       // Metallo / Piastra Acciaio (EMT 140 cold-rolled plate equivalent)
    SmoothConcrete = 5,   // Calcestruzzo / Cemento Liscio (Monumento cattedrale / chiesa)
    PorousAbsorber = 6,   // Fibra di Vetro / Lana Minerale 100mm (Assorbitore a larga banda)
    DrywallStud = 7,      // Cartongesso su montanti con intercapedine (Studio standard)
    NumMaterials = 8
};

// 7 Standard Octave Bands (ISO 354)
inline constexpr size_t kNumOctaveBands = 7;
inline constexpr std::array<float, kNumOctaveBands> kOctaveBandFrequencies = {
    125.0f, 250.0f, 500.0f, 1000.0f, 2000.0f, 4000.0f, 8000.0f
};

// =============================================================================
// MaterialAcousticProfile
// Physical properties representing boundary interaction:
// - Absorption alpha(f) [0.0, 1.0] across 7 octave bands (ISO 354)
// - Scattering s(f) [0.0, 1.0] across 7 octave bands (ISO 17497)
// - Normalized wall specific acoustic impedance Zw / Z0 (where Z0 = rho0 * c0 ~ 415 Pa*s/m)
// - Rigidity / harshness index (controls sibilance anti-splash in diffusers)
// =============================================================================
struct MaterialAcousticProfile {
    std::string_view name;
    std::string_view description;

    // ISO 354 sound absorption coefficients [125, 250, 500, 1k, 2k, 4k, 8k Hz]
    std::array<float, kNumOctaveBands> alpha;

    // ISO 17497 sound scattering coefficients [125, 250, 500, 1k, 2k, 4k, 8k Hz]
    std::array<float, kNumOctaveBands> scattering;

    // Characteristic specific wall impedance Zw normalized to air impedance Z0 (rho * c)
    // Real resistive component (radiation resistance)
    float normalizedResistiveZw;
    // Imaginary reactive component at mid frequencies (stiffness / mass reactance)
    float normalizedReactiveZw;

    // Surface acoustic rigidity index (1.0 = highly rigid/brittle, 0.0 = soft porous)
    float rigidityFactor;

    // Bass absorption bias (panel resonance vs porous damping)
    float bassAbsorptionRatio;

    // Nominal mid-band absorption average (500 Hz - 1000 Hz)
    [[nodiscard]] constexpr float getAverageMidAlpha() const noexcept {
        return 0.5f * (alpha[2] + alpha[3]);
    }

    // Nominal mid-band scattering average (500 Hz - 1000 Hz)
    [[nodiscard]] constexpr float getAverageMidScattering() const noexcept {
        return 0.5f * (scattering[2] + scattering[3]);
    }

    // Pressure reflection coefficient at normal incidence: R0 = (Zw - Z0) / (Zw + Z0)
    [[nodiscard]] inline float getNormalReflectionCoefficient(size_t bandIdx) const noexcept {
        const float a = (bandIdx < kNumOctaveBands) ? alpha[bandIdx] : 0.05f;
        const float clampedA = std::clamp(a, 0.0f, 0.999f);
        return std::sqrt(1.0f - clampedA);
    }
};

// =============================================================================
// Acoustic Materials Database (Calibrated according to ISO 354 & ISO 17497)
// =============================================================================
namespace materials_db {

    // 1. Legno / Boiserie & Parquet (Panel Absorber, Warm Intelligibility)
    static constexpr MaterialAcousticProfile kWoodBoiserie = {
        "Legno / Boiserie",
        "Pannello in legno nobile su intercapedine 50mm, calore organico e scattering naturale",
        /* alpha ISO 354: */       { 0.28f, 0.22f, 0.17f, 0.10f, 0.10f, 0.11f, 0.12f },
        /* scattering ISO 17497: */ { 0.05f, 0.08f, 0.15f, 0.25f, 0.35f, 0.45f, 0.50f },
        /* Zw resistive: */        4.5f,
        /* Zw reactive: */         1.2f,
        /* rigidity: */            0.45f,
        /* bassAbsorptionRatio: */ 2.50f
    };

    // 2. Marmo Lucido / Granito Levigato (Monumental Specular Stone)
    static constexpr MaterialAcousticProfile kMarbleStone = {
        "Marmo / Pietra",
        "Marmo lucido monolitico, riflettanza speculare estrema, decadimento monumentale cattedrale",
        /* alpha ISO 354: */       { 0.010f, 0.010f, 0.012f, 0.015f, 0.020f, 0.025f, 0.035f },
        /* scattering ISO 17497: */ { 0.010f, 0.015f, 0.020f, 0.025f, 0.030f, 0.035f, 0.040f },
        /* Zw resistive: */        950.0f,
        /* Zw reactive: */         40.0f,
        /* rigidity: */            0.98f,
        /* bassAbsorptionRatio: */ 0.80f
    };

    // 3. Vetro Architettonico (Single / Double Glazing 6mm)
    static constexpr MaterialAcousticProfile kArchitecturalGlass = {
        "Vetro Architettonico",
        "Lastra di vetro 6mm, riflessione brillante ad alto q, freddo e tagliente",
        /* alpha ISO 354: */       { 0.18f, 0.06f, 0.04f, 0.03f, 0.02f, 0.02f, 0.03f },
        /* scattering ISO 17497: */ { 0.01f, 0.01f, 0.015f, 0.02f, 0.02f, 0.025f, 0.03f },
        /* Zw resistive: */        320.0f,
        /* Zw reactive: */         15.0f,
        /* rigidity: */            0.95f,
        /* bassAbsorptionRatio: */ 4.50f
    };

    // 4. Velluto Pesante / Tendaggio Arricciato (Heavy Drapes 500g/m²)
    static constexpr MaterialAcousticProfile kHeavyVelvet = {
        "Velluto / Tendaggio",
        "Velluto acustico pesante 500 g/m2 al 100% di pienezza, elevatissimo assorbimento alte frequenze",
        /* alpha ISO 354: */       { 0.14f, 0.35f, 0.55f, 0.72f, 0.85f, 0.90f, 0.92f },
        /* scattering ISO 17497: */ { 0.10f, 0.20f, 0.35f, 0.45f, 0.55f, 0.60f, 0.65f },
        /* Zw resistive: */        1.45f,
        /* Zw reactive: */         -0.40f,
        /* rigidity: */            0.05f,
        /* bassAbsorptionRatio: */ 0.20f
    };

    // 5. Metallo / Piastra in Acciaio (EMT 140 Cold-Rolled Steel Plate)
    static constexpr MaterialAcousticProfile kSteelPlate = {
        "Metallo / Plate",
        "Lamiera d'acciaio laminata a freddo 1mm, dispersione flessionale a piastra EMT, lucentezza metallica",
        /* alpha ISO 354: */       { 0.05f, 0.04f, 0.03f, 0.03f, 0.04f, 0.06f, 0.09f },
        /* scattering ISO 17497: */ { 0.50f, 0.55f, 0.65f, 0.75f, 0.80f, 0.85f, 0.88f },
        /* Zw resistive: */        120.0f,
        /* Zw reactive: */         25.0f,
        /* rigidity: */            0.92f,
        /* bassAbsorptionRatio: */ 1.50f
    };

    // 6. Calcestruzzo / Cemento Liscio Non Verniciato (Smooth Unpainted Concrete)
    static constexpr MaterialAcousticProfile kSmoothConcrete = {
        "Calcestruzzo / Cemento",
        "Cemento armato liscio, pareti massive per grandi sale monumentali, bassi lunghi e compatti",
        /* alpha ISO 354: */       { 0.02f, 0.02f, 0.03f, 0.04f, 0.05f, 0.06f, 0.08f },
        /* scattering ISO 17497: */ { 0.03f, 0.05f, 0.08f, 0.12f, 0.18f, 0.22f, 0.25f },
        /* Zw resistive: */        210.0f,
        /* Zw reactive: */         18.0f,
        /* rigidity: */            0.88f,
        /* bassAbsorptionRatio: */ 0.50f
    };

    // 7. Fibra di Vetro / Lana Minerale Porosa (Rockwool 100mm 70 kg/m³)
    static constexpr MaterialAcousticProfile kPorousAbsorber = {
        "Fibra di Vetro / Poroso",
        "Lana minerale ad alta densita 100mm, anecoico su banda vocale, decadimento rapido controllato",
        /* alpha ISO 354: */       { 0.35f, 0.70f, 0.92f, 0.98f, 0.98f, 0.95f, 0.92f },
        /* scattering ISO 17497: */ { 0.08f, 0.12f, 0.15f, 0.18f, 0.20f, 0.22f, 0.25f },
        /* Zw resistive: */        1.08f,
        /* Zw reactive: */         -0.15f,
        /* rigidity: */            0.02f,
        /* bassAbsorptionRatio: */ 0.38f
    };

    // 8. Cartongesso su montanti con intercapedine 50mm (Plasterboard / Drywall)
    static constexpr MaterialAcousticProfile kDrywallStud = {
        "Cartongesso / Drywall",
        "Pannello in gesso 13mm su montanti metallici con lana interna, standard studio moderno",
        /* alpha ISO 354: */       { 0.29f, 0.10f, 0.06f, 0.05f, 0.04f, 0.04f, 0.05f },
        /* scattering ISO 17497: */ { 0.03f, 0.04f, 0.05f, 0.06f, 0.08f, 0.09f, 0.10f },
        /* Zw resistive: */        16.0f,
        /* Zw reactive: */         3.5f,
        /* rigidity: */            0.60f,
        /* bassAbsorptionRatio: */ 4.80f
    };

    // Tabella cumulativa per accesso diretto
    static constexpr std::array<MaterialAcousticProfile, static_cast<size_t>(RoomMaterialType::NumMaterials)> kAllMaterials = {
        kWoodBoiserie,
        kMarbleStone,
        kArchitecturalGlass,
        kHeavyVelvet,
        kSteelPlate,
        kSmoothConcrete,
        kPorousAbsorber,
        kDrywallStud
    };

    [[nodiscard]] constexpr const MaterialAcousticProfile& getMaterialProfile(RoomMaterialType type) noexcept {
        const size_t idx = static_cast<size_t>(type);
        if (idx < kAllMaterials.size()) {
            return kAllMaterials[idx];
        }
        return kWoodBoiserie;
    }

} // namespace materials_db

// =============================================================================
// Physical Acoustic Calculations Engine (Sabine-Eyring, ISM, FDN-16 Loop Gains)
// =============================================================================
class SpaceLuxeAcousticCalculator {
public:
    static constexpr float kSpeedOfSound = 343.0f; // m/s a 20 gradi C in aria secca

    // Attenuazione atmosferica dell'aria m(f) [m^-1] secondo ISO 9613-1 a 20 gradi C, 50% UR
    static constexpr std::array<float, kNumOctaveBands> kAirAbsorptionM = {
        0.00005f, // 125 Hz
        0.00020f, // 250 Hz
        0.00060f, // 500 Hz
        0.00120f, // 1000 Hz
        0.00280f, // 2000 Hz
        0.00750f, // 4000 Hz
        0.02400f  // 8000 Hz
    };

    // =========================================================================
    // Formula di Sabine-Eyring Estesa con Assorbimento dell'Aria (ISO 9613-1):
    // T60(f) = [24 * ln(10) * V] / [c * (-S * ln(1 - alpha_bar(f)) + 4 * m(f) * V)]
    // =========================================================================
    static inline float calculateT60Eyring(float volumeM3, float surfaceAreaM2,
                                           float averageAlpha, float airAttenM) noexcept
    {
        if (volumeM3 <= 1.0f || surfaceAreaM2 <= 1.0f)
            return 0.5f;

        const float safeAlpha = std::clamp(averageAlpha, 0.005f, 0.985f);
        const float c = kSpeedOfSound;

        // Eyring boundary dissipation term: -S * ln(1 - alpha)
        const float eyringSurfaceTerm = -surfaceAreaM2 * std::log(1.0f - safeAlpha);

        // Volumetric atmospheric absorption term: 4 * m * V
        const float airTerm = 4.0f * airAttenM * volumeM3;

        const float totalDenominator = c * (eyringSurfaceTerm + airTerm);
        if (totalDenominator <= 1.0e-5f)
            return 30.0f;

        // 24 * ln(10) ~ 55.26204f
        constexpr float k24Ln10 = 55.26204223f;
        const float t60 = (k24Ln10 * volumeM3) / totalDenominator;
        return std::clamp(t60, 0.05f, 45.0f);
    }

    // Calcolo del profilo di decadimento completo T60(f) su tutte le 7 bande d'ottava
    static inline std::array<float, kNumOctaveBands> computeSpectralT60(
        RoomMaterialType material, float volumeM3, float surfaceAreaM2) noexcept
    {
        const auto& profile = materials_db::getMaterialProfile(material);
        std::array<float, kNumOctaveBands> t60Bands{};

        for (size_t b = 0; b < kNumOctaveBands; ++b) {
            t60Bands[b] = calculateT60Eyring(volumeM3, surfaceAreaM2,
                                             profile.alpha[b], kAirAbsorptionM[b]);
        }
        return t60Bands;
    }

    // =========================================================================
    // Calcolo del Guadagno di Feedback FDN per una linea di ritardo tau_i:
    // g_i(f) = 10^( -3 * tau_i / T60(f) )
    // dove tau_i = delaySamples_i / sampleRate
    // =========================================================================
    static inline float computeFdnLoopGain(float delayTimeSec, float t60Seconds) noexcept {
        if (t60Seconds <= 0.01f || delayTimeSec <= 0.0f)
            return 0.0f;
        const float exponent = -3.0f * (delayTimeSec / t60Seconds);
        return std::clamp(std::pow(10.0f, exponent), 0.0f, 0.999f);
    }

    // =========================================================================
    // Decomposizione Early Reflections (Image Source Method):
    // E_specular(f) = [1 - s(f)] * [1 - alpha(f)] * E_incident
    // E_diffuse(f)  = s(f) * [1 - alpha(f)] * E_incident
    // =========================================================================
    struct EarlyReflectionEnergies {
        float specularGainLinear;
        float diffuseGainLinear;
        float absorptionLossDb;
    };

    static inline EarlyReflectionEnergies computeReflectionGains(
        RoomMaterialType material, size_t bandIdx = 3 /* 1 kHz standard */) noexcept
    {
        const auto& profile = materials_db::getMaterialProfile(material);
        const size_t b = std::min(bandIdx, kNumOctaveBands - 1);

        const float alpha = profile.alpha[b];
        const float s = profile.scattering[b];

        const float reflectedEnergyRatio = std::clamp(1.0f - alpha, 0.0f, 1.0f);
        const float specEnergyRatio = (1.0f - s) * reflectedEnergyRatio;
        const float diffEnergyRatio = s * reflectedEnergyRatio;

        const float specGain = std::sqrt(specEnergyRatio);
        const float diffGain = std::sqrt(diffEnergyRatio);

        const float lossDb = (reflectedEnergyRatio > 1.0e-5f)
            ? (-10.0f * std::log10(reflectedEnergyRatio))
            : 60.0f;

        return { specGain, diffGain, lossDb };
    }

    // =========================================================================
    // Intermodulazione Intelligente con SpaceLuxeNeuralBrain:
    // Calcola fattori di compensazione acustica fisica per guidare l'AI Brain:
    // - duckingCompensationFactor: incrementa il ducking su materiali risonanti duri
    // - antiSplashCutFactor: amplifica l'anti-splash su materiali riflettenti rigidi
    // - tailBloomTargetDb: adatta il gain del bloom al T60 del materiale
    // - widthBloomScale: amplifica l'espansione stereo su materiali ad alto scattering
    // - preDelayOffsetMs: distanzia le riflessioni precoci su superfici dure speculari
    // =========================================================================
    struct BrainMaterialModulation {
        float duckingCompensationFactor; // Moltiplicatore ducking [0.8x a 1.6x]
        float antiSplashCutFactor;       // Moltiplicatore anti-splash 6.8 kHz [0.1x a 1.5x]
        float tailBloomTargetDb;         // Target bloom raccomandato [+2.5 a +5.8 dB]
        float widthBloomScale;           // Moltiplicatore allargamento stereo [0.9x a 1.35x]
        float recommendedPreDelayMs;     // Offset pre-delay fisico [8.0 a 26.0 ms]
    };

    static inline BrainMaterialModulation computeBrainModulation(RoomMaterialType material) noexcept {
        const auto& p = materials_db::getMaterialProfile(material);

        const float midAlpha = p.getAverageMidAlpha();
        const float midScat = p.getAverageMidScattering();
        const float rigidity = p.rigidityFactor;

        // 1. Ducking Compensation:
        // Materiali a basso assorbimento (Marmo, Metallo, Cemento) accumulano energia nella stanza
        // richiedendo un ducking piu profondo per proteggere l'intelligibilita della voce secca.
        const float duckComp = 1.0f + 0.6f * (1.0f - std::clamp(midAlpha, 0.0f, 1.0f));

        // 2. Anti-Splash Cut:
        // Superfici rigide levigate (Vetro, Metallo, Marmo) generano forte sferzata metallica ("fzzz")
        // nel network di diffusione. Materiali porosi/velluto assorbono naturalmente le sibilanti.
        const float sibilantAlpha = p.alpha[5]; // 4 kHz - 8 kHz
        const float antiSplashComp = std::clamp(rigidity * 1.4f * (1.0f - 0.7f * sibilantAlpha), 0.10f, 1.50f);

        // 3. Tail Bloom Target Db:
        // Materiali con T60 naturale bilanciato (Legno, Cemento, Metallo) supportano bloom generosi (+4.5 to +6.0 dB);
        // materiali anecoici (Fibra porosa, velluto pesante) richiedono bloom piu contenuto (+2.5 to +3.5 dB).
        const float bloomDb = 2.5f + 3.0f * (1.0f - 0.7f * midAlpha);

        // 4. Stereo Width Bloom:
        // Materiali ad alto scattering s(f) (Legno, Piastra) distruggono la coerenza IACC permettendo
        // una fioritura stereofonica fino al 180% senza problemi di fase in mono.
        const float widthScale = 0.95f + 0.40f * midScat;

        // 5. Pre-Delay Fisico Adattivo:
        // Superfici dure speculari (Vetro, Marmo) proiettano riflessioni immediate ad ampiezza elevata
        // che invadono la finestra di Haas (< 15 ms). Richiedono pre-delay maggiore (20-25 ms).
        const float preDelayMs = 8.0f + 16.0f * rigidity * (1.0f - 0.5f * midAlpha);

        return {
            std::clamp(duckComp, 0.8f, 1.6f),
            std::clamp(antiSplashComp, 0.1f, 1.5f),
            std::clamp(bloomDb, 2.5f, 5.8f),
            std::clamp(widthScale, 0.9f, 1.35f),
            std::clamp(preDelayMs, 8.0f, 26.0f)
        };
    }
};

} // namespace dsp171
