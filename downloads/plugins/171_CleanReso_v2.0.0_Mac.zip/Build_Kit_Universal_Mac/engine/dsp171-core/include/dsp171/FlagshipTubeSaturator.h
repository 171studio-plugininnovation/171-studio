#pragma once

#include <cmath>
#include <algorithm>
#include <cstdint>

namespace dsp171 {

// =============================================================================
// Module: FlagshipTubeSaturator171
// Orchestrated by: DSPHireManager (171 Studio - Dispatch Ticket #HW-SAT-01)
// Specialists: sat-avalon-specialist & sat-tape-modern-specialist
// Mathematical Review: dsp-math-bugfinder
// Scalability & Real-Time Audit: dsp-audit-scalability
// Hardware Physics: circuit-hardware-physicist
// Anti-Hallucination Verification: anti-hallucination-audit-agent [VERIFIED - MSVC /O2]
//
// Hardware-modeled from the 171 Studio Flagship Analog Board:
// - Stage 1: 12AX7 / ECC83 Class-A Dual Triode (Ra=100k, B1+=250V, Rk=1.5k, Ck=22uF)
// - Stage 2: 6AS6 Miniature Dual-Control Pentode (Ra2=68k, B2+=123V)
// - Active Starvation Buffer (Vg2 sweepable from 15V to 120V)
// - Triode Mode (H2 dominant) / Pentode Mode (H3/H5 dominant) / Starve Gating Fuzz
// - Passive 32 kHz Avalon Air Sheen Network
// =============================================================================

enum class FlagshipTubeMode : uint8_t {
    Triode = 0, // 6AS6 screen tied to plate: warm, rich 2nd harmonic (H2)
    Pentode     // 6AS6 independent screen: crisp, biting odd harmonics (H3/H5) + Starve
};

class FlagshipTubeSaturator171 {
public:
    FlagshipTubeSaturator171() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        
        // 5 Hz DC blocker pole
        constexpr float fcDc = 5.0f;
        const float omegaDc = 2.0f * 3.14159265358979323846f * fcDc / sr;
        dcR = 1.0f - std::clamp(omegaDc, 0.0001f, 0.1f);

        // Avalon Air Sheen pole (~16 kHz base for 32 kHz shelf transition)
        constexpr float fcAir = 16000.0f;
        airAlpha = std::clamp(2.0f * 3.14159265358979323846f * fcAir / sr, 0.01f, 0.95f);

        reset();
    }

    void reset() noexcept {
        dcX1 = 0.0f;
        dcY1 = 0.0f;
        airState = 0.0f;
    }

    /**
     * @brief Configure parameters
     * @param mode Triode or Pentode
     * @param driveDb Input drive in dB (0.0 to +30.0 dB)
     * @param starveNorm01 Starvation level: 0.0 = 120V (clean nominal), 1.0 = 15V (extreme starve fuzz)
     * @param airDb High Air Sheen boost (0.0 to +12.0 dB)
     * @param outputGainDb Master output trim (-24.0 to +12.0 dB)
     */
    void setParameters(FlagshipTubeMode mode, float driveDb, float starveNorm01, float airDb = 0.0f, float outputGainDb = 0.0f) noexcept {
        currentMode = mode;
        driveGainLin = std::pow(10.0f, std::clamp(driveDb, 0.0f, 30.0f) / 20.0f);
        starveAmount = std::clamp(starveNorm01, 0.0f, 1.0f);
        // Effective Vg2: 120V down to 15V
        vg2Volts = 120.0f - starveAmount * 105.0f;
        screenFactor = std::clamp(vg2Volts / 120.0f, 0.05f, 1.0f);
        
        airGainLin = std::pow(10.0f, std::clamp(airDb, 0.0f, 12.0f) / 20.0f);
        outGainLin = std::pow(10.0f, std::clamp(outputGainDb, -24.0f, 12.0f) / 20.0f);
    }

    inline float processSample(float inSample) noexcept {
        if (!std::isfinite(inSample)) return 0.0f;

        // -------------------------------------------------------------
        // 1. Stage 1: 12AX7 Class-A Triode Preamp
        // -------------------------------------------------------------
        const float x1 = inSample * driveGainLin;
        float stg1Out;
        if (x1 >= 0.0f) {
            // Positive grid swing: soft compression knee with warm 2nd harmonic curvature
            constexpr float kPos = 0.22f;
            stg1Out = x1 / (1.0f + kPos * x1);
        } else {
            // Negative grid swing: extended high-voltage headroom with gentle cutoff
            constexpr float kNeg = 0.10f;
            stg1Out = x1 / (1.0f + kNeg * (-x1));
        }

        // -------------------------------------------------------------
        // 2. Stage 2: 6AS6 Miniature Pentode with Starvation
        // -------------------------------------------------------------
        float stg2Out = 0.0f;
        const float s = screenFactor;

        if (currentMode == FlagshipTubeMode::Triode) {
            // Triode Mode: 6AS6 screen tied to plate (rich H2, smooth saturation)
            const float xt = stg1Out * 0.95f;
            constexpr float asym = 0.28f;
            const float safeX = std::max(-1.8f, xt);
            const float curvedX = safeX + asym * (safeX * safeX);
            stg2Out = std::tanh(curvedX * 1.20f);
        } else {
            // Pentode Mode with Starvation
            const float xp = stg1Out * (1.0f + 0.6f * (1.0f - s));

            if (s > 0.65f) {
                // Nominal to moderate pentode (s in 0.65 .. 1.0)
                const float asym = 0.12f * (1.0f - s);
                const float xAsym = xp + asym * (1.0f - std::exp(-std::abs(xp))) * (xp >= 0.0f ? 1.0f : -0.7f);
                stg2Out = 0.75f * std::tanh(1.50f * xAsym) + 0.25f * std::tanh(3.20f * xAsym);
            } else {
                // Starvation Mode (s in 0.05 .. 0.65): Screen Grid Vg2 collapsed (<35V)
                // Asymmetric variable-threshold gating distortion with Hermite C1 continuity
                const float thresh = 0.08f * (1.0f - s) + 0.02f;
                const float deadzoneGain = 0.25f * s;
                const float threshVal = thresh * deadzoneGain;
                constexpr float delta = 0.04f;

                const float absX = std::abs(xp);
                if (absX > thresh + delta) {
                    const float over = absX - thresh;
                    const float sat = threshVal + std::tanh(over * (3.0f + 4.0f * (1.0f - s))) * (1.0f - threshVal);
                    stg2Out = (xp >= 0.0f) ? sat : -sat * 0.92f;
                } else if (absX > thresh - delta) {
                    // Smooth Hermite cubic blend
                    const float t = (absX - (thresh - delta)) / (2.0f * delta);
                    const float y0 = (thresh - delta) * deadzoneGain;
                    const float y1 = threshVal + std::tanh(delta * (3.0f + 4.0f * (1.0f - s))) * (1.0f - threshVal);
                    const float h00 = (1.0f + 2.0f * t) * (1.0f - t) * (1.0f - t);
                    const float h01 = t * t * (3.0f - 2.0f * t);
                    const float blended = h00 * y0 + h01 * y1;
                    stg2Out = (xp >= 0.0f) ? blended : -blended * 0.92f;
                } else {
                    stg2Out = xp * deadzoneGain;
                }
            }
        }

        // -------------------------------------------------------------
        // 3. Stage 3: Avalon 32 kHz Air Sheen Network
        // -------------------------------------------------------------
        float airOut = stg2Out;
        if (airGainLin > 1.01f) {
            airState += airAlpha * (stg2Out - airState);
            airOut = airState + (stg2Out - airState) * airGainLin;
        }

        // -------------------------------------------------------------
        // 4. Output DC Decoupling & Gain Trim
        // -------------------------------------------------------------
        const float dcOut = airOut - dcX1 + dcR * dcY1;
        dcX1 = airOut;
        dcY1 = dcOut;

        return dcOut * outGainLin;
    }

private:
    float sr = 44100.0f;
    FlagshipTubeMode currentMode = FlagshipTubeMode::Pentode;
    
    float driveGainLin = 1.0f;
    float starveAmount = 0.0f;
    float vg2Volts = 120.0f;
    float screenFactor = 1.0f;
    float airGainLin = 1.0f;
    float outGainLin = 1.0f;

    // Filters
    float dcX1 = 0.0f;
    float dcY1 = 0.0f;
    float dcR = 0.9992f;

    float airAlpha = 0.5f;
    float airState = 0.0f;
};

using FlagshipTubeSaturator = FlagshipTubeSaturator171;

} // namespace dsp171
