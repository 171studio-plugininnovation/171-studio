#pragma once
#include <cmath>
#include <algorithm>
#include <cstdint>
#include "Common.h"
#include "ZDFTiltFilter.h"

namespace dsp171 {

// =============================================================================
// ZDFSVFBell64
// Filtro a Variabili di Stato a Retroazione Istantanea a 64-bit (ZDF SVF Bell)
// Topologia Cytomic / Zavalishin con integratori trapezoidali a doppia precisione.
// Modello parametrico Bell/Peaking simmetrico con stabilita' incondizionata di Lyapunov
// e passthrough bit-exact a 0 dB gain.
// =============================================================================
class ZDFSVFBell64 {
public:
    void reset() noexcept {
        s1 = 0.0;
        s2 = 0.0;
    }

    // fc: frequenza centrale in Hz
    // Q: fattore di merito di risonanza (tipico 1.5 .. 4.5 per formanti vocali)
    // gainDb: guadagno/attenuazione in dB (-24.0 dB .. +24.0 dB)
    // sampleRate: frequenza di campionamento in Hz
    void setParameters(float fc, float Q, float gainDb, float sampleRate) noexcept {
        const double sr = sampleRate > 0.0 ? static_cast<double>(sampleRate) : 48000.0;
        const double clampedFc = std::clamp(static_cast<double>(fc), 15.0, sr * 0.49);
        g = std::tan(PI_D * clampedFc / sr);
        const double safeQ = std::clamp(static_cast<double>(Q), 0.1, 30.0);

        // Guadagno simmetrico in scala dB (A = 10^(gainDb / 40))
        A = std::pow(10.0, static_cast<double>(gainDb) * 0.025);

        R_den = 1.0 / (2.0 * A * safeQ);
        R_num = A / (2.0 * safeQ);

        h = 1.0 / (1.0 + 2.0 * R_den * g + g * g);
        coeff = 2.0 * (R_num - R_den);

        // Zero-Delay Feedback Cytomic Bell: when gain is 0 dB, coeff == 0.0,
        // yielding mathematical bit-exact passthrough (out = in) while preserving
        // C-infinity continuous state evolution without impulse pops.
        isActive = (std::abs(gainDb) >= 0.005f);
    }

    inline float process(float in) noexcept {
        if (!std::isfinite(in)) {
            s1 = 0.0;
            s2 = 0.0;
            return 0.0f;
        }

        // Fast path: if completely inactive (0 dB), update integrators to track signal continuously
        if (!isActive) {
            const double inD = static_cast<double>(in);
            const double hp = (inD - (2.0 * R_den + g) * s1 - s2) * h;
            const double v1 = g * hp;
            const double bp = v1 + s1;
            s1 = v1 + bp;
            const double v2 = g * bp;
            const double lp = v2 + s2;
            s2 = v2 + lp;
            if (!std::isfinite(s1) || std::abs(s1) < 1.0e-25) s1 = 0.0;
            if (!std::isfinite(s2) || std::abs(s2) < 1.0e-25) s2 = 0.0;
            return in;
        }

        const double inD = static_cast<double>(in);
        const double hp = (inD - (2.0 * R_den + g) * s1 - s2) * h;
        const double v1 = g * hp;
        const double bp = v1 + s1;
        s1 = v1 + bp;
        const double v2 = g * bp;
        const double lp = v2 + s2;
        s2 = v2 + lp;

        // Protezione hardware attiva anti-denormal e anti-poisoning
        if (!std::isfinite(s1) || std::abs(s1) < 1.0e-25) s1 = 0.0;
        if (!std::isfinite(s2) || std::abs(s2) < 1.0e-25) s2 = 0.0;

        const double outD = inD + coeff * bp;
        return static_cast<float>(outD);
    }

    [[nodiscard]] bool getIsActive() const noexcept { return isActive; }

private:
    static constexpr double PI_D = 3.14159265358979323846;
    double s1 = 0.0;
    double s2 = 0.0;
    double g = 0.0;
    double A = 1.0;
    double R_den = 0.5;
    double R_num = 0.5;
    double h = 1.0;
    double coeff = 0.0;
    bool isActive = false;
};

// =============================================================================
// FormantShaperZDF
// Motore di Formant Tracking e Spectral Reshaping vocale a Zero-Delay Feedback (ZDF)
// a doppio polo per la preservazione delle formanti F1 e F2 del tratto vocale.
//
// Architettura specialistica per dsp171-core:
// 1. Modalita' "Keep Formants" (in stile Melda MAutoPitch):
//    Quando attiva, compensa automaticamente il pitch ratio applicato:
//      FormantShift_auto = -12.0f * log2(pitchRatio)
//    Neutralizza l'effetto "chipmunk" (voce sottile e nasale sulle note alte)
//    e l'effetto "orco/troll" (voce cavernosa e scura sulle note basse).
// 2. Formant Shift bipolare manuale [-12.0 st .. +12.0 st] cumulabile con la
//    compensazione automatica:
//      FormantShift_effective = FormantShift_manual + (keepFormants ? FormantShift_auto : 0.0f)
// 3. Reshaping spettrale a doppio polo ZDF (Zero-Delay Feedback):
//    - Banco di risonatori ZDF SVF a 64-bit per Formante F1 e Formante F2,
//      piu' Formante F3 (Singer's Formant / Epilaryngeal resonance).
//    - Formant Tracking dinamico legato alla fondamentale vocale F0: adatta
//      l'acustica del tratto vocale affinche' F1 non collassi al di sotto di F0.
//    - Filtro ZDF Tilt Baxandall invariante a 850 Hz per compensazione della
//      pendenza glottica (spectral slope).
// 4. Zero allocazioni dinamiche nel process thread, 0 latenza algoritmica, noexcept.
// =============================================================================
class FormantShaperZDF {
public:
    FormantShaperZDF() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        tiltFilter.prepare(sampleRate);
        reset();
    }

    void reset() noexcept {
        f1TargetBell.reset();
        f1BaseBell.reset();
        f2TargetBell.reset();
        f2BaseBell.reset();
        f3TargetBell.reset();
        tiltFilter.reset();

        manualShiftSemitones = 0.0f;
        autoShiftSemitones = 0.0f;
        targetEffectiveShift = 0.0f;
        smoothedEffectiveShift = 0.0f;

        targetPitchHz = 0.0f;
        smoothedPitchHz = 0.0f;

        trackedF1 = 650.0f;
        trackedF2 = 1750.0f;
        trackedF3 = 2900.0f;

        targetF1 = 650.0f;
        targetF2 = 1750.0f;
        targetF3 = 2900.0f;

        keepFormantsEnabled = false;
        hasActiveShaping = false;
        subSampleCount = 0;
    }

    // Modalita' "Keep Formants" (in stile Melda):
    // Quando attiva, compensa automaticamente il pitch ratio
    void setKeepFormants(bool enabled) noexcept {
        keepFormantsEnabled = enabled;
        updateTargetShift();
    }

    [[nodiscard]] bool isKeepFormantsEnabled() const noexcept {
        return keepFormantsEnabled;
    }

    // Formant Shift bipolare manuale [-12.0 st .. +12.0 st]
    void setManualFormantShift(float semitones) noexcept {
        manualShiftSemitones = std::clamp(semitones, -12.0f, 12.0f);
        updateTargetShift();
    }

    [[nodiscard]] float getManualFormantShift() const noexcept {
        return manualShiftSemitones;
    }

    // Aggiornamento dello stato di intonazione e tracking vocale
    // currentPitchHz: frequenza fondamentale F0 rilevata dall'MPM
    // pitchRatio: rapporto di correzione del pitch applicato da RetuneFilter
    // isVoiced: stato di vocalizzazione
    void updateTracking(float currentPitchHz, float pitchRatio, bool isVoiced) noexcept {
        if (keepFormantsEnabled && isVoiced && pitchRatio > 0.05f) {
            // Melda-style automatic compensation: FormantShift_auto = -12.0f * log2(pitchRatio)
            autoShiftSemitones = -12.0f * std::log2(pitchRatio);
            // Limitazione di sicurezza per pitch shift estremi
            autoShiftSemitones = std::clamp(autoShiftSemitones, -24.0f, 24.0f);
        } else if (!keepFormantsEnabled) {
            autoShiftSemitones = 0.0f;
        }
        // Se keepFormantsEnabled è attivo ma isVoiced è temporaneamente false (es. consonante),
        // conserva l'ultimo autoShiftSemitones evitando salti a gradino sui filtri

        updateTargetShift();

        if (isVoiced && currentPitchHz > 30.0f) {
            targetPitchHz = currentPitchHz;
        }
    }

    // Telemetria Formanti per GUI / Monitoraggio
    [[nodiscard]] float getEffectiveFormantShift() const noexcept { return smoothedEffectiveShift; }
    [[nodiscard]] float getAutoFormantShift() const noexcept { return autoShiftSemitones; }
    [[nodiscard]] float getTrackedF1Hz() const noexcept { return trackedF1; }
    [[nodiscard]] float getTrackedF2Hz() const noexcept { return trackedF2; }
    [[nodiscard]] float getTargetF1Hz() const noexcept { return targetF1; }
    [[nodiscard]] float getTargetF2Hz() const noexcept { return targetF2; }

    // Elaborazione audio campione per campione (Zero latency, noexcept)
    inline float processSample(float inSample) noexcept {
        // 1. Interpolazione continua esponenziale anti-click per shift e pitch (tau ~ 3.5 ms a 48 kHz)
        const float alpha = std::clamp(1.0f - std::exp(-1.0f / (0.0035f * sr)), 0.001f, 0.1f);
        smoothedEffectiveShift += alpha * (targetEffectiveShift - smoothedEffectiveShift);
        smoothedPitchHz += alpha * (targetPitchHz - smoothedPitchHz);

        // 2. Ricalcolo dei coefficienti dei filtri ZDF a sub-blocco (ogni 16 campioni ~ 0.33 ms)
        if ((subSampleCount++ & 15) == 0) {
            updateFilterCoefficients();
        }

        // Fast path bit-exact a 0 dB (Waves Tune Real-Time & Auto-Tune Pro standard):
        // Se non vi è shaping attivo (< 40 cents), restituisci inSample al 100% bit-exact senza filtri né ritardi di fase
        if (!hasActiveShaping) {
            return inSample;
        }

        // 3. Elaborazione della cascata spettrale a doppio polo ZDF (solo per salti ampi > 40 cents)
        float s = inSample;
        s = f1TargetBell.process(s);
        s = f2TargetBell.process(s);
        s = f3TargetBell.process(s);
        s = tiltFilter.processSample(s);

        return s;
    }

private:
    void updateTargetShift() noexcept {
        const float combined = manualShiftSemitones + (keepFormantsEnabled ? autoShiftSemitones : 0.0f);
        targetEffectiveShift = std::clamp(combined, -24.0f, 24.0f);
    }

    void updateFilterCoefficients() noexcept {
        // 1. Formant Tracking: adatta le frequenze di base al registro vocale in modo rigorosamente continuo
        if (smoothedPitchHz > 50.0f) {
            // Per voci alte / registro di testa / belt, F1 segue F0 affinché la cavità risuoni
            const float pitchRef = std::max(550.0f, smoothedPitchHz * 1.18f);
            trackedF1 = std::clamp(pitchRef, 600.0f, 1200.0f);
            trackedF2 = std::max(1700.0f, trackedF1 * 2.35f);
            trackedF3 = std::max(2850.0f, trackedF2 * 1.50f);
        } else {
            // Registro neutro vocale maschile/femminile
            trackedF1 = 650.0f;
            trackedF2 = 1750.0f;
            trackedF3 = 2900.0f;
        }

        const float absShift = std::abs(smoothedEffectiveShift);
        hasActiveShaping = (absShift >= 0.40f);

        if (!hasActiveShaping) {
            targetF1 = trackedF1;
            targetF2 = trackedF2;
            targetF3 = trackedF3;
            f1TargetBell.setParameters(trackedF1, 0.70f, 0.0f, sr);
            f2TargetBell.setParameters(trackedF2, 0.75f, 0.0f, sr);
            f3TargetBell.setParameters(trackedF3, 0.90f, 0.0f, sr);
            tiltFilter.setTilt(0.0f);
            return;
        }

        // 2. Modulazione del fattore di scala del tratto vocale (M = 2^(shift / 12))
        const float M = std::exp2(smoothedEffectiveShift * (1.0f / 12.0f));
        const float nyquistMargin = sr * 0.485f;

        targetF1 = std::clamp(trackedF1 * M, 60.0f, nyquistMargin);
        targetF2 = std::clamp(trackedF2 * M, 150.0f, nyquistMargin);
        targetF3 = std::clamp(trackedF3 * M, 400.0f, nyquistMargin);

        // Guadagni di risonanza ZDF delicati senza intaccare presenza e aria (zero negative notch filtering)
        const float gainRamp = std::clamp((absShift - 0.40f) / 0.60f, 0.0f, 1.0f);

        float boostF1 = 0.0f;
        float boostF2 = 0.0f;
        float boostF3 = 0.0f;

        if (smoothedEffectiveShift < 0.0f) {
            // Pitch sale: preservazione naturale anti-chipmunk senza buchi di presenza
            boostF1 = std::min(0.8f, (absShift - 0.40f) * 0.15f) * gainRamp;
            boostF2 = std::min(0.6f, (absShift - 0.40f) * 0.10f) * gainRamp;
            boostF3 = 0.0f;
        } else {
            // Pitch scende: calore naturale setoso
            boostF1 = std::min(0.7f, (absShift - 0.40f) * 0.12f) * gainRamp;
            boostF2 = std::min(0.5f, (absShift - 0.40f) * 0.08f) * gainRamp;
            boostF3 = 0.0f;
        }

        f1TargetBell.setParameters(targetF1, 0.70f, boostF1, sr);
        f2TargetBell.setParameters(targetF2, 0.75f, boostF2, sr);
        f3TargetBell.setParameters(targetF3, 0.90f, boostF3, sr);
        tiltFilter.setTilt(0.0f);
    }

    float sr = 48000.0f;

    // Risonatori ZDF SVF a doppio polo per formanti F1, F2, F3
    ZDFSVFBell64 f1TargetBell;
    ZDFSVFBell64 f1BaseBell;
    ZDFSVFBell64 f2TargetBell;
    ZDFSVFBell64 f2BaseBell;
    ZDFSVFBell64 f3TargetBell;

    // Compensatore di pendenza spettrale glottica
    ZDFTiltFilter tiltFilter;

    // Parametri di controllo
    float manualShiftSemitones = 0.0f;
    float autoShiftSemitones = 0.0f;
    float targetEffectiveShift = 0.0f;
    float smoothedEffectiveShift = 0.0f;

    float targetPitchHz = 0.0f;
    float smoothedPitchHz = 0.0f;

    float trackedF1 = 650.0f;
    float trackedF2 = 1750.0f;
    float trackedF3 = 2900.0f;

    float targetF1 = 650.0f;
    float targetF2 = 1750.0f;
    float targetF3 = 2900.0f;

    bool keepFormantsEnabled = false;
    bool hasActiveShaping = false;
    uint32_t subSampleCount = 0;
};

} // namespace dsp171
