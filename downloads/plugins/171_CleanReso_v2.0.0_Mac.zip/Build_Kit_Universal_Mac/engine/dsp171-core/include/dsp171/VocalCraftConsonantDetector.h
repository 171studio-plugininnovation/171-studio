#pragma once
#include <cmath>
#include <algorithm>
#include <atomic>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include <dsp171/ZDFSVF.h>

namespace dsp171 {

// =============================================================================
// 171 VocalCraft - AI Transient & Consonant Phoneme Detector
//
// Real-time phoneme extraction engine separating fast percussive/fricative
// consonants (P, T, K, B, D, G, S, Z, F, V) from sustained harmonic vowels.
// Uses High-Frequency Spectral Flux, Zero-Crossing Rate, and dual fast/slow
// envelope dynamics to produce a continuous consonant punch weight [0.0, 1.0].
// =============================================================================
class VocalCraftConsonantDetector {
public:
    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 0.0 ? sampleRate : 44100.0;
        hpf.reset();
        hpf.setParameters(2200.0f, 0.707f, static_cast<float>(sr));

        // Time constants
        fastAttackCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.002 * sr)));  // 2ms
        fastReleaseCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.020 * sr))); // 20ms

        slowAttackCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.015 * sr)));  // 15ms
        slowReleaseCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.120 * sr))); // 120ms
        zcrSmoothCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (0.005 * sr)));   // 5ms

        holdSamplesMax = static_cast<int>(sr * 0.060); // 60ms consonant punch hold window for full affricates

        reset();
    }

    void reset() noexcept {
        hpf.reset();
        fastEnv = 0.0f;
        slowEnv = 0.0f;
        prevHfSample = 0.0f;
        prevSign = 0;
        zcrAccumulator = 0.0f;
        holdCounter = 0;
        smoothedConsonant = 0.0f;
        consonantActivity.store(0.0f, std::memory_order_relaxed);
    }

    // Process a single sample and return consonant confidence [0.0, 1.0]
    inline float processSample(float input) noexcept {
        // 1. High-frequency filtering (> 2.8 kHz where plosives and fricatives live)
        const auto outputs = hpf.process(input);
        const float hfSample = outputs.hp;
        const float absHf = std::abs(hfSample);

        // 2. High-Frequency Spectral Flux (forward energy difference with pitch-snap spike guard)
        const float rawDelta = std::max(0.0f, absHf - prevHfSample);
        prevHfSample = absHf;
        hfDeltaSmoothed += (rawDelta - hfDeltaSmoothed) * 0.45f;
        const float hfDelta = hfDeltaSmoothed;

        // 3. Zero-Crossing Density
        const int currentSign = (hfSample >= 0.0f) ? 1 : -1;
        const float isZeroCross = (currentSign != prevSign && prevSign != 0) ? 1.0f : 0.0f;
        prevSign = currentSign;

        // Smooth ZCR estimation over ~5ms window
        zcrAccumulator += (isZeroCross - zcrAccumulator) * zcrSmoothCoeff;

        // 4. Dual Fast/Slow Envelope Ratio
        const float targetFast = absHf;
        if (targetFast > fastEnv)
            fastEnv += (targetFast - fastEnv) * fastAttackCoeff;
        else
            fastEnv += (targetFast - fastEnv) * fastReleaseCoeff;

        const float targetSlow = std::abs(input);
        if (targetSlow > slowEnv)
            slowEnv += (targetSlow - slowEnv) * slowAttackCoeff;
        else
            slowEnv += (targetSlow - slowEnv) * slowReleaseCoeff;

        // Transient Crest Ratio: fast HF burst over general broadband body
        const float broadbandFloor = std::max(0.0001f, slowEnv);
        const float transientRatio = fastEnv / broadbandFloor;

        // 5. Composite Phoneme Score
        // High HF flux + High ZCR + High transient ratio = definitive consonant burst
        float rawScore = (hfDelta * 6.0f) + (zcrAccumulator * 0.4f) + std::max(0.0f, (transientRatio - 0.8f) * 0.8f);

        // Acoustic Phonetic Rule: Consonants (fricatives/plosives) MUST have significant HF energy (> 2.8 kHz).
        // If high-frequency envelope is low, the sound is purely a low-frequency vowel (A, E, I, O, U) or silence.
        if (fastEnv < 0.004f) {
            rawScore = 0.0f;
        } else {
            rawScore = std::clamp(rawScore, 0.0f, 1.0f);
        }

        // 6. Hold Window: Keep consonant punch gate open for ~30ms to let the full syllable through
        if (rawScore > 0.35f) {
            holdCounter = holdSamplesMax;
        } else if (holdCounter > 0) {
            holdCounter--;
            rawScore = std::max(rawScore, 0.5f);
        }

        // Smooth output to prevent jagged envelope jumps
        const float smoothCoeff = (rawScore > smoothedConsonant) ? 0.3f : 0.05f;
        smoothedConsonant += (rawScore - smoothedConsonant) * smoothCoeff;

        // Update atomic for 60 FPS GUI telemetry
        consonantActivity.store(smoothedConsonant, std::memory_order_relaxed);

        return smoothedConsonant;
    }

    // Telemetry query for 60 FPS Oscilloscope highlight
    float getConsonantActivity() const noexcept {
        return consonantActivity.load(std::memory_order_relaxed);
    }

private:
    double sr = 44100.0;
    ZDFSVF64 hpf;

    float fastEnv = 0.0f;
    float slowEnv = 0.0f;
    float prevHfSample = 0.0f;
    float hfDeltaSmoothed = 0.0f;
    int prevSign = 0;
    float zcrAccumulator = 0.0f;

    int holdSamplesMax = 1323;
    int holdCounter = 0;
    float smoothedConsonant = 0.0f;

    float fastAttackCoeff = 0.1f;
    float fastReleaseCoeff = 0.01f;
    float slowAttackCoeff = 0.05f;
    float slowReleaseCoeff = 0.001f;
    float zcrSmoothCoeff = 0.01f;

    std::atomic<float> consonantActivity{0.0f};
};

} // namespace dsp171
