#pragma once
#include <atomic>
#include <array>
#include <cstddef>
#include <algorithm>

namespace dsp171 {

// Coda SPSC (Single-Producer Single-Consumer) Lock-Free con bitmasking ultra-veloce e zero allocazioni
template <typename T, size_t Capacity = 512>
class LockFreeFIFO {
    static_assert((Capacity & (Capacity - 1)) == 0, "Capacity must be a power of 2");

public:
    LockFreeFIFO() : head(0), tail(0) {}

    bool push(const T& item) noexcept {
        const size_t currentTail = tail.load(std::memory_order_relaxed);
        const size_t currentHead = head.load(std::memory_order_acquire);

        if ((currentTail - currentHead) >= Capacity) {
            return false; // Buffer pieno: scarta senza bloccare il thread audio
        }

        buffer[currentTail & BufferMask] = item;
        tail.store(currentTail + 1, std::memory_order_release);
        return true;
    }

    bool pop(T& item) noexcept {
        const size_t currentHead = head.load(std::memory_order_relaxed);
        const size_t currentTail = tail.load(std::memory_order_acquire);

        if (currentHead == currentTail) {
            return false; // Buffer vuoto
        }

        item = buffer[currentHead & BufferMask];
        head.store(currentHead + 1, std::memory_order_release);
        return true;
    }

    void reset() noexcept {
        head.store(0, std::memory_order_relaxed);
        tail.store(0, std::memory_order_relaxed);
    }

    bool isEmpty() const noexcept {
        return head.load(std::memory_order_relaxed) == tail.load(std::memory_order_relaxed);
    }

private:
    static constexpr size_t BufferMask = Capacity - 1;
    alignas(64) std::array<T, Capacity> buffer{};
    alignas(64) std::atomic<size_t> head{0};
    alignas(64) std::atomic<size_t> tail{0};
};

// ==============================================================================
// FRAME VISUALI COMPATIBILI E AD ALTE PRESTAZIONI
// ==============================================================================

// Frame unificato per CleanDrive e DriveOptocom (VU meters, LED meters, Scope, Dynamics)
struct alignas(16) VisualFrame {
    float inRMS = 0.0f;
    float outRMS_L = 0.0f;
    float outRMS_R = 0.0f;
    float peak_L = 0.0f;
    float peak_R = 0.0f;

    // Metriche di saturazione e transienza (CleanDrive)
    float transientRatio = 0.0f;
    float tonalRatio = 0.0f;

    // Metriche di compressione (DriveOptocom)
    float gainReduction_L = 0.0f; // dB di riduzione (0 a -24)
    float gainReduction_R = 0.0f;
    float compressionEnv = 0.0f;

    static constexpr size_t FrameSamples = 64;
    std::array<float, FrameSamples> samplesIn{};
    std::array<float, FrameSamples> samplesOut{};
    std::array<float, FrameSamples> samplesOut_L{};
    std::array<float, FrameSamples> samplesOut_R{};
    std::array<float, FrameSamples> samplesGR{};
};

using CleanDriveVisualFrame = VisualFrame;
using OptocomVisualFrame = VisualFrame;

template <size_t Capacity = 512>
using LockFreeVisualFIFO = LockFreeFIFO<VisualFrame, Capacity>;

// Frame spettrale per CleanReso
struct alignas(64) ResoVisualFrame {
    static constexpr size_t NumBands = 32;

    std::array<float, NumBands> inSpectrum{};
    std::array<float, NumBands> grSpectrum{};

    float peakResoHz = 0.0f;
    float maxReductionDb = 0.0f;
    float transientActivity = 0.0f;

    float outRMS_L = 0.0f;
    float outRMS_R = 0.0f;
    float peak_L   = 0.0f;
    float peak_R   = 0.0f;

    // Smart Brain Telemetria
    bool smartBrainActive = true;
    float smartBrainHarmonicMask = 0.0f;
    float neuralInferenceUs = 0.0f;
};

template <size_t Capacity = 512>
using LockFreeResoFIFO = LockFreeFIFO<ResoVisualFrame, Capacity>;

} // namespace dsp171
