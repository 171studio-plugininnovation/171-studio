#pragma once
#include <cmath>
#include <array>
#include <algorithm>
#include <cstdint>
#include "Common.h"

namespace dsp171 {

// Tabella di lookup precalcolata per dB -> linear gain (-60 dB a +24 dB con risoluzione 0.1 dB)
class FastDbToGainTable {
public:
    static constexpr float MinDb = -60.0f;
    static constexpr float MaxDb = 24.0f;
    static constexpr float StepDb = 0.1f;
    static constexpr size_t TableSize = static_cast<size_t>((MaxDb - MinDb) / StepDb) + 1;

    FastDbToGainTable() {
        for (size_t i = 0; i < TableSize; ++i) {
            const float db = MinDb + static_cast<float>(i) * StepDb;
            table[i] = std::pow(10.0f, db / 20.0f);
        }
    }

    inline float lookup(float db) const noexcept {
        if (!std::isfinite(db) || db <= MinDb) return table[0];
        if (db >= MaxDb) return table[TableSize - 1];

        const float indexFloat = (db - MinDb) / StepDb;
        const size_t idx = static_cast<size_t>(indexFloat);
        const float frac = indexFloat - static_cast<float>(idx);

        if (idx + 1 < TableSize) {
            return table[idx] * (1.0f - frac) + table[idx + 1] * frac;
        }
        return table[idx];
    }

private:
    std::array<float, TableSize> table{};
};

inline const FastDbToGainTable& getGlobalDbToGainTable() {
    static const FastDbToGainTable instance;
    return instance;
}

// Fast branchless exp(x) approximation using 2^(x * log2(e))
// Constrained minimax polynomial guaranteed P(0)=1 and P(1)=2 (zero boundary gap at x=0)
inline float fastExp(float x) noexcept {
    if (!std::isfinite(x) || x < -87.3365f) return 0.0f;
    if (x > 88.0f) x = 88.0f;

    const float t = x * 1.4426950408889634f; // x * log2(e)
    const float floorT = std::floor(t);
    const int i = static_cast<int>(floorT);
    const float f = t - floorT; // [0.0, 1.0)

    // Constrained polynomial: c1 = ln(2), c2 = ln(2)^2 / 2, c3 = 1 - c1 - c2
    constexpr float c1 = 0.69314718f;
    constexpr float c2 = 0.24022650f;
    constexpr float c3 = 0.06662632f;
    const float p = 1.0f + f * (c1 + f * (c2 + f * c3));

    // Multiply by 2^i using IEEE-754 bit manipulation
    union { float f; uint32_t u; } res;
    res.u = static_cast<uint32_t>((i + 127) << 23);
    return p * res.f;
}

// Ultra-fast and high-precision 1 - exp(x) for negative time constants (x <= 0)
// Resolves sub-millisecond and 100ms ballistic time constants with 6 decimal place precision
inline float fastOneMinusExpNeg(float negX) noexcept {
    if (negX >= -0.02f) {
        // High-precision Maclaurin series: -x - x^2/2 - x^3/6
        return -negX * (1.0f + negX * (0.5f + negX * 0.16666667f));
    }
    return 1.0f - fastExp(negX);
}

// Fast IEEE-754 log2(x) approximation with Remez polynomial correction on mantissa
// Accurate to within 0.005 for x > 0
inline float fastLog2(float x) noexcept {
    if (!std::isfinite(x) || x <= 1.0e-15f) return -50.0f;

    union { float f; uint32_t u; } vx;
    vx.f = x;
    const uint32_t exp = (vx.u >> 23) & 0xFF;
    const int e = static_cast<int>(exp) - 127;
    vx.u = (vx.u & 0x7FFFFF) | 0x3F800000;
    const float m = vx.f; // m in [1.0, 2.0)

    // Polynomial approximation of log2(m) on [1, 2)
    const float log2m = (-0.34484843f * m + 2.02466578f) * m - 1.67981735f;
    return static_cast<float>(e) + log2m;
}

// Fast log10(x)
inline float fastLog10(float x) noexcept {
    return fastLog2(x) * 0.3010299956639812f;
}

// Fast Linear to dB: 20 * log10(x) = 6.0205999 * log2(x)
inline float fastLinearToDb(float x) noexcept {
    if (!std::isfinite(x) || x <= 1.0e-7f) return -140.0f;
    return 6.020599913279624f * fastLog2(x);
}

// Fast dB to Linear: exp(db * ln(10)/20)
inline float fastDbToLinear(float db) noexcept {
    if (!std::isfinite(db) || db <= -144.0f) return 0.0f;
    if (db >= 48.0f) db = 48.0f;
    return fastExp(db * 0.1151292546497022842f); // ln(10) / 20 = 0.1151292546497022842
}

} // namespace dsp171
