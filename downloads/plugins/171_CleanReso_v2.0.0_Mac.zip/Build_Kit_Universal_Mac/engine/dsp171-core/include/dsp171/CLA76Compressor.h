#pragma once
#include <cmath>
#include <algorithm>
#include <array>
#include <cstdint>
#include "Common.h"
#include "FastMath.h"
#include "ZDFSVF.h"

namespace dsp171 {

// =============================================================================
// CLA76Compressor
// Emulatore dell'amplificatore limitatore FET Universal Audio 1176LN / Waves CLA-76
//
// Caratteristiche Modellistiche & Retro-Ingegneria Circuitale Autentica:
// 1. Topologia Feedback Gain Reduction (Feedback Loop con FET 2N5457 come VCR):
//    - Il detector riceve il segnale post-FET attenuatore, garantendo stabilità
//      naturale e il caratteristico knee musicale dell'1176.
// 2. Raddrizzatore Analogico a Condensatore di Timing (Peak Detector C11):
//    - Carica rapida (20 us - 800 us) e scarica esponenziale (50 ms - 1100 ms).
//    - Elimina completamente l'audio-rate ripple (zero-crossing drop), impedendo
//      la distorsione da modulazione AM incontrollata e l'aliasing.
// 3. 4 Rapporti con Soglie e Ginocchio Morbido Interattivo:
//    - 4:1 (Soglia -18 dBFS), 8:1 (-16 dBFS), 12:1 (-14 dBFS), 20:1 (-12 dBFS).
// 4. Modalità "ALL BUTTONS IN" (British Mode):
//    - Collasso del partitore di bias del FET (soglia a -22 dBFS, ratio ~24:1),
//      overshoot sui primi transienti, pumping e saturazione aggressiva.
// 5. Due Revisioni Hardware Vintage:
//    - Blackface (LN Rev D/E): amplificatore di linea Classe A Low-Noise con
//      trasformatore B11148 ultra-trasparente e soft saturation armonica oltre -1 dBFS.
//    - Blue Stripe (Rev A): stadio di preamplificazione più spinto con mordente
//      e ricchezza di 2ª e 3ª armonica sulle medie frequenze.
// 6. Calibrazione DAW Studio Standard:
//    - Input nominale centrato a -18 dBFS per 2-4 dB di gain reduction musicale.
// 7. Sidechain High-Pass Filter 100 Hz implementato con ZDF SVF a 64-bit.
// =============================================================================
class CLA76Compressor {
public:
    enum class Ratio : uint8_t {
        Ratio4  = 0, // 4:1
        Ratio8  = 1, // 8:1
        Ratio12 = 2, // 12:1
        Ratio20 = 3, // 20:1
        AllButtons = 4 // All Buttons In / British Mode
    };

    enum class Revision : uint8_t {
        Blackface = 0, // LN Revision D/E
        BlueStripe = 1  // Revision A (più armoniche e mordente sulle medie)
    };

    enum class AnalogHum : uint8_t {
        Off  = 0,
        Hum50Hz = 1,
        Hum60Hz = 2
    };

    CLA76Compressor() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        invSr = 1.0f / sr;
        dt = invSr;

        // Filtro Passa-Alto 100 Hz per Sidechain ZDF SVF 64-bit
        scHpFilterL.setParameters(100.0f, 0.707f, sr);
        scHpFilterR.setParameters(100.0f, 0.707f, sr);

        updateTimeConstants();
        reset();
    }

    void reset() noexcept {
        peakDetectorL = 0.0f;
        peakDetectorR = 0.0f;
        currentGRL_dB = 0.0f;
        currentGRR_dB = 0.0f;
        humPhase = 0.0f;
        scHpFilterL.reset();
        scHpFilterR.reset();
    }

    // Input Control: da -60.0 dB a 0.0 dB (determina la spinta nel circuito FET)
    // Calibrato per punto di lavoro ottimale a -18 dBFS
    void setInputDb(float inDb) noexcept {
        inputDb = std::clamp(inDb, -60.0f, 0.0f);
        inputGainLin = std::pow(10.0f, (inputDb + 18.0f) * 0.05f);
    }

    // Output Control: da -60.0 dB a 0.0 dB (make-up gain pulito fino a +12 dB)
    void setOutputDb(float outDb) noexcept {
        outputDb = std::clamp(outDb, -60.0f, 0.0f);
        outputGainLin = std::pow(10.0f, (outputDb + 12.0f) * 0.05f);
    }

    // Attack: da 1 (più lento, ~800 us) a 7 (più veloce, 20 microsecondi)
    void setAttackKnob(float att1To7) noexcept {
        attackKnob = std::clamp(att1To7, 1.0f, 7.0f);
        updateTimeConstants();
    }

    // Release: da 1 (più lento, 1100 ms) a 7 (più veloce, 50 ms)
    void setReleaseKnob(float rel1To7) noexcept {
        releaseKnob = std::clamp(rel1To7, 1.0f, 7.0f);
        updateTimeConstants();
    }

    // Ratio: 4:1, 8:1, 12:1, 20:1 o All Buttons In
    void setRatio(Ratio r) noexcept {
        ratio = r;
    }

    void setAllButtons(bool enabled) noexcept {
        ratio = enabled ? Ratio::AllButtons : Ratio::Ratio4;
    }

    // Revisione: Blackface vs Blue Stripe
    void setRevision(Revision rev) noexcept {
        revision = rev;
    }

    void setBlueStripe(bool isBlue) noexcept {
        revision = isBlue ? Revision::BlueStripe : Revision::Blackface;
    }

    // Comp Off (disabilita il Gain Reduction preservando il preamplificatore FET)
    void setCompOff(bool off) noexcept {
        compOff = off;
    }

    // Analog Hum (Off, 50Hz, 60Hz)
    void setAnalogHum(AnalogHum hum) noexcept {
        analogHum = hum;
    }

    // Mix Parallelo [0% .. 100%]
    void setMix(float mix0To100) noexcept {
        mix = std::clamp(mix0To100 * 0.01f, 0.0f, 1.0f);
    }

    // Sidechain High-Pass Filter (100 Hz Studio Standard)
    void setSidechainHighPass(bool enabled) noexcept {
        scHighPass = enabled;
    }
    [[nodiscard]] bool isSidechainHighPass() const noexcept {
        return scHighPass;
    }

    // Telemetria Gain Reduction in dB
    [[nodiscard]] float getGainReductionL() const noexcept { return currentGRL_dB; }
    [[nodiscard]] float getGainReductionR() const noexcept { return currentGRR_dB; }

    // Elaborazione Audio Stereo Phase-Linked
    void process(float* inOutL, float* inOutR, size_t numSamples) noexcept {
        if (!inOutL || !inOutR || numSamples == 0) return;

        // Coefficiente di filtro passa-basso analogico CV (2.0 ms) per eliminare audio-rate ripple
        const float cvFilterCoeff = 1.0f - std::exp(-dt / 0.0020f);

        for (size_t i = 0; i < numSamples; ++i) {
            const float dryL = inOutL[i];
            const float dryR = inOutR[i];

            // 1. Preamplificatore d'ingresso con gain staging calibrato
            const float sigL = dryL * inputGainLin;
            const float sigR = dryR * inputGainLin;

            float wetL = sigL;
            float wetR = sigR;

            if (!compOff) {
                // 2. Sidechain Feedforward incondizionatamente stabile (Loop Gain = 0)
                float detL = sigL;
                float detR = sigR;

                if (scHighPass) {
                    detL = scHpFilterL.process(detL).hp;
                    detR = scHpFilterR.process(detR).hp;
                }

                // Raddrizzamento a onda intera con stereo linking di picco
                const float rectL = std::abs(detL);
                const float rectR = std::abs(detR);
                const float maxRect = std::max(rectL, rectR);

                // Rilevatore di picco analogico RC (condensatore di timing C11)
                // Carica rapida su transiente (attackCoeff) e scarica esponenziale (releaseCoeff)
                if (maxRect > peakDetectorL) {
                    peakDetectorL += attackCoeff * (maxRect - peakDetectorL);
                } else {
                    peakDetectorL += releaseCoeff * (maxRect - peakDetectorL);
                }
                peakDetectorR = peakDetectorL; // Stereo-link assoluto di fase

                // Calcolo target GR in dB dalla tensione di picco sul condensatore
                const float targetGrDb = computeTargetGR(peakDetectorL);

                // Filtraggio analogico di controllo tensione FET (CV Gate Filter)
                currentGRL_dB += cvFilterCoeff * (targetGrDb - currentGRL_dB);
                currentGRR_dB = currentGRL_dB;

                // 3. Attenuazione del partitore FET lineare controllato in tensione
                const float attenL = std::pow(10.0f, -currentGRL_dB * 0.05f);
                const float attenR = std::pow(10.0f, -currentGRR_dB * 0.05f);

                wetL = sigL * attenL;
                wetR = sigR * attenR;
            } else {
                currentGRL_dB = 0.0f;
                currentGRR_dB = 0.0f;
            }

            // 4. Output Line Stage (Make-up Gain)
            wetL *= outputGainLin;
            wetR *= outputGainLin;

            // 5. Saturazione del trasformatore e preamplificatore Classe A (Headroom estesa +24 dBu)
            wetL = saturateFET(wetL, revision, ratio == Ratio::AllButtons);
            wetR = saturateFET(wetR, revision, ratio == Ratio::AllButtons);

            // 6. Hum Analogico a 50/60 Hz
            if (analogHum != AnalogHum::Off) {
                const float humFreq = (analogHum == AnalogHum::Hum50Hz) ? 50.0f : 60.0f;
                humPhase += humFreq * invSr * 6.283185307f;
                if (humPhase > 6.283185307f) humPhase -= 6.283185307f;
                const float humSig = 0.00020f * (std::sin(humPhase) + 0.40f * std::sin(2.0f * humPhase));
                wetL += humSig;
                wetR += humSig;
            }

            // 7. Dry / Wet Mix
            inOutL[i] = (1.0f - mix) * dryL + mix * wetL;
            inOutR[i] = (1.0f - mix) * dryR + mix * wetR;
        }
    }

private:
    float computeTargetGR(float peakAmp) const noexcept {
        if (peakAmp <= 1.0e-5f) return 0.0f;
        const float peakDb = 20.0f * std::log10(peakAmp);

        // Parametri interattivi Ratio / Soglia / Ginocchio 1176LN
        float threshold = -18.0f;
        float rVal = 4.0f;
        float kneeWidth = 4.0f;

        switch (ratio) {
            case Ratio::Ratio4:
                threshold = -18.0f;
                rVal = 4.0f;
                kneeWidth = 4.0f;
                break;
            case Ratio::Ratio8:
                threshold = -16.0f;
                rVal = 8.0f;
                kneeWidth = 3.5f;
                break;
            case Ratio::Ratio12:
                threshold = -14.0f;
                rVal = 12.0f;
                kneeWidth = 3.0f;
                break;
            case Ratio::Ratio20:
                threshold = -12.0f;
                rVal = 20.0f;
                kneeWidth = 2.5f;
                break;
            case Ratio::AllButtons:
                // All Buttons In (British Mode): collasso della polarizzazione FET
                threshold = -22.0f;
                rVal = 24.0f;
                kneeWidth = 2.0f;
                break;
        }

        const float delta = peakDb - threshold;
        const float halfKnee = kneeWidth * 0.5f;
        const float slope = 1.0f - (1.0f / rVal); // Pendenza feedforward rigorosamente stabile

        if (delta <= -halfKnee) {
            return 0.0f;
        } else if (delta >= halfKnee) {
            float baseGr = slope * delta;
            if (ratio == Ratio::AllButtons) {
                baseGr *= 1.15f; // All Buttons In: overshoot aggressivo e pumping musicale
            }
            return baseGr;
        } else {
            // Transizione parabolica continua C1
            const float kneeOver = (delta + halfKnee) * (delta + halfKnee) / (2.0f * kneeWidth);
            return slope * kneeOver;
        }
    }

    static float saturateFET(float x, Revision rev, bool allButtons) noexcept {
        if (allButtons) {
            // British Mode: saturazione calda asimmetrica progressiva con compressione dei picchi
            const float xAsym = x + 0.04f * x * std::abs(x);
            return 1.40f * std::tanh(xAsym / 1.40f);
        }

        const float absX = std::abs(x);

        if (rev == Revision::BlueStripe) {
            // Blue Stripe (Rev A): pre-amp con 2ª e 3ª armonica e mordente sulle medie
            const float xAsym = x + 0.035f * x * absX;
            const float absAsym = std::abs(xAsym);
            if (absAsym < 1.05f) {
                return xAsym;
            } else {
                return (xAsym >= 0.0f ? 1.0f : -1.0f) * (1.05f + 0.60f * std::tanh((absAsym - 1.05f) / 0.60f));
            }
        } else {
            // Blackface (Rev D/E): Classe A Low-Noise con trasformatore ultra-trasparente
            // Trasparenza totale (0.00% THD) fino a +1 dBFS (1.12), poi morbida saturazione analogica
            if (absX < 1.12f) {
                return x;
            } else {
                return (x >= 0.0f ? 1.0f : -1.0f) * (1.12f + 0.65f * std::tanh((absX - 1.12f) / 0.65f));
            }
        }
    }

    void updateTimeConstants() noexcept {
        // Attack: 1 (~800 us) a 7 (20 microsecondi)
        const float expAtt = (7.0f - attackKnob) / 6.0f;
        const float attackSeconds = 0.000020f * std::pow(40.0f, expAtt);
        attackCoeff = 1.0f - std::exp(-dt / attackSeconds);

        // Release: 1 (1100 ms) a 7 (50 ms)
        const float expRel = (7.0f - releaseKnob) / 6.0f;
        const float releaseSeconds = 0.050f * std::pow(22.0f, expRel);
        releaseCoeff = 1.0f - std::exp(-dt / releaseSeconds);
    }

    float sr{44100.0f};
    float invSr{1.0f / 44100.0f};
    float dt{1.0f / 44100.0f};

    float inputDb{-18.0f};
    float outputDb{-12.0f};
    float inputGainLin{1.0f};
    float outputGainLin{1.0f};

    float attackKnob{3.0f};  // Default standard 1176
    float releaseKnob{5.0f}; // Default rapido CLA-76
    float attackCoeff{0.1f};
    float releaseCoeff{0.01f};

    Ratio ratio{Ratio::Ratio4};
    Revision revision{Revision::Blackface};
    bool compOff{false};
    AnalogHum analogHum{AnalogHum::Off};
    float mix{1.0f};

    float peakDetectorL{0.0f};
    float peakDetectorR{0.0f};
    float currentGRL_dB{0.0f};
    float currentGRR_dB{0.0f};
    float humPhase{0.0f};

    // Sidechain High-Pass Filter ZDF SVF 64-bit
    bool scHighPass{false};
    ZDFSVF64 scHpFilterL;
    ZDFSVF64 scHpFilterR;
};

} // namespace dsp171
