#pragma once

#include <cmath>
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include "Common.h"
#include "FastMath.h"
#include "ADAA2HardClipper.h"
#include "ADAA2Clipper.h"
#include "AcousticThermalDiodeClipper.h"
#include "TransDetailMatrix.h"
#include "SafetyCeiling.h"
#include "ZDFSVF.h"
#include "DCBlocker.h"

namespace dsp171 {

// =============================================================================
// 171PerfectClipEngine
// Master Audio Engine for 171PerfectClip VST3 / AU / Standalone
//
// Unifies:
// 1. Multi-Topology ADAA-2 Clipping (Precision Digital, Gold Converter, Tube, Diode).
// 2. 171 TransDetail™ Matrix: Zero-latency transient preservation & Alchemy air.
// 3. Continuously Variable Soft Knee [0% (Brickwall) to 100% (Pure Smooth)].
// 4. Stereo & Mid/Side Processing with Sub-Bass Mono-Maker (< 80 Hz).
// 5. ITU-R BS.1770-4 Compliant True-Peak / Inter-Sample Peak Safety Ceiling.
// 6. Delta Audition Mode (solo clipped content).
// 7. 60 FPS Lock-Free Atomic Telemetry & Bipolar Scope Ringbuffer.
// =============================================================================

enum class ClipperMode : uint32_t {
    PrecisionDigital = 0, // Analytical ADAA-2 Piecewise Hard Clip (Max RMS)
    GoldConverter122,     // Lavry Gold 122-96 ADC Soft Knee & Harmonic Mojo
    TubeTriodeClassA,     // Asymmetric Class-A Tube Warmth (H2/H3 morphing)
    GermaniumDiode        // Organic Germanium Diode Knee (Punchy & Gritty)
};

enum class ChannelRouting : uint32_t {
    StereoLR = 0,
    MidSideSplit,
    MidOnly,
    SideOnly
};

class PerfectClipEngine {
public:
    static constexpr size_t SCOPE_BUFFER_SIZE = 1024;

    struct TelemetryData {
        float inPeakDbL = -100.0f;
        float inPeakDbR = -100.0f;
        float outPeakDbL = -100.0f;
        float outPeakDbR = -100.0f;
        float maxGainReductionDb = 0.0f;
        float crestFactorDb = 0.0f;
        bool isClippingNow = false;
    };

    struct ScopeSample {
        float inSample;
        float outSample;
        float deltaSample;
        bool clipped;
    };

    PerfectClipEngine() noexcept {
        reset();
    }

    PerfectClipEngine(const PerfectClipEngine&) = delete;
    PerfectClipEngine& operator=(const PerfectClipEngine&) = delete;

    void prepare(double sampleRate, size_t /*maxBlockSize*/ = 512) noexcept {
        sr = (sampleRate > 0.0) ? static_cast<float>(sampleRate) : 44100.0f;

        for (int ch = 0; ch < 2; ++ch) {
            hardClippers[ch].reset();
            analogClippers[ch].reset();
            goldClippers[ch].prepare(sr);
            transDetail[ch].prepare(sr);
            dcBlockers[ch].prepare(sr, 5.0f);
            ispLimiters[ch].prepare(sr, 2.0f); // 2 ms transparent release without pumping
            monoMakerFilters[ch].setParameters(monoMakerFreqHz, 0.7071f, sr);
        }

        reset();
    }

    void reset() noexcept {
        for (int ch = 0; ch < 2; ++ch) {
            hardClippers[ch].reset();
            analogClippers[ch].reset();
            goldClippers[ch].reset();
            transDetail[ch].reset();
            dcBlockers[ch].reset();
            ispLimiters[ch].reset();
            monoMakerFilters[ch].reset();
        }

        scopeWriteIndex.store(0, std::memory_order_relaxed);
        for (auto& s : scopeRingBuffer) {
            s = { 0.0f, 0.0f, 0.0f, false };
        }

        deltaDelayL.fill(0.0f);
        deltaDelayR.fill(0.0f);
        deltaDelayIdx = 0;
        inPrevL = 0.0f;
        inPrevR = 0.0f;

        peakInL = 0.0f;
        peakInR = 0.0f;
        peakOutL = 0.0f;
        peakOutR = 0.0f;
        maxGR = 0.0f;
        smoothMeanSq = 0.0f;

        atomicInPeakL.store(0.0f, std::memory_order_relaxed);
        atomicInPeakR.store(0.0f, std::memory_order_relaxed);
        atomicOutPeakL.store(0.0f, std::memory_order_relaxed);
        atomicOutPeakR.store(0.0f, std::memory_order_relaxed);
        atomicMaxGR.store(0.0f, std::memory_order_relaxed);
        atomicCrestFactorDb.store(0.0f, std::memory_order_relaxed);
        isClippingFlag.store(false, std::memory_order_relaxed);
    }

    // --- Parameter Setters ---
    void setInputGainDb(float gainDb) noexcept {
        inGainDb = gainDb;
        inGainLinear = dbToGain(gainDb);
    }

    void setCeilingDb(float ceilingDbVal) noexcept {
        ceilingDb = std::clamp(ceilingDbVal, -24.0f, 0.0f);
        ceilingLinear = dbToGain(ceilingDb);
    }

    void setOutputGainDb(float gainDb) noexcept {
        outGainDb = gainDb;
        outGainLinear = dbToGain(gainDb);
    }

    void setClipperMode(ClipperMode mode) noexcept {
        currentMode = mode;
    }

    void setSoftKnee(float knee) noexcept {
        softKnee = std::clamp(knee, 0.0f, 1.0f);
    }

    void setDetailPreservation(float amount) noexcept {
        const float clamped = std::clamp(amount, 0.0f, 1.0f);
        if (std::abs(clamped - detailPreserve) > 1.0e-5f) {
            detailPreserve = clamped;
            for (int ch = 0; ch < 2; ++ch) {
                transDetail[ch].setDetailPreservation(detailPreserve);
            }
        }
    }

    void setAlchemyAirDb(float gainDb) noexcept {
        const float clamped = std::clamp(gainDb, -6.0f, 6.0f);
        if (std::abs(clamped - alchemyAirDb) > 1.0e-4f) {
            alchemyAirDb = clamped;
            for (int ch = 0; ch < 2; ++ch) {
                transDetail[ch].setAlchemyAirDb(alchemyAirDb);
            }
        }
    }

    void setRouting(ChannelRouting routing) noexcept {
        currentRouting = routing;
    }

    void setMonoMaker(bool enable, float freqHz = 80.0f) noexcept {
        const float clampedFreq = std::clamp(freqHz, 20.0f, 300.0f);
        if (enable != monoMakerEnabled || std::abs(clampedFreq - monoMakerFreqHz) > 0.05f) {
            monoMakerEnabled = enable;
            monoMakerFreqHz = clampedFreq;
            for (int ch = 0; ch < 2; ++ch) {
                monoMakerFilters[ch].setParameters(monoMakerFreqHz, 0.7071f, sr);
            }
        }
    }

    void setTruePeakGuard(bool enable) noexcept {
        truePeakGuardEnabled = enable;
    }

    void setDeltaAudition(bool enable) noexcept {
        deltaAudition = enable;
    }

    [[nodiscard]] size_t getLatencySamples() const noexcept {
        return truePeakGuardEnabled ? TruePeakLimiter::LookaheadLatency : 0;
    }

    // --- Core Stereo Audio Processing Block ---
    void processBlock(float* leftChannel, float* rightChannel, size_t numSamples) noexcept {
        if (numSamples == 0 || leftChannel == nullptr) return;
        const bool isStereo = (rightChannel != nullptr);

        float blockMaxGR = 0.0f;
        float blockMaxInL = 0.0f;
        float blockMaxInR = 0.0f;
        float blockMaxOutL = 0.0f;
        float blockMaxOutR = 0.0f;
        float blockSumSq = 0.0f;
        bool anyClipping = false;

        size_t writeIdx = scopeWriteIndex.load(std::memory_order_relaxed);

        for (size_t i = 0; i < numSamples; ++i) {
            const float inL = leftChannel[i] * inGainLinear;
            const float inR = isStereo ? (rightChannel[i] * inGainLinear) : inL;

            const float alignedInL = inPrevL;
            const float alignedInR = inPrevR;
            inPrevL = inL;
            inPrevR = inR;

            blockMaxInL = std::max(blockMaxInL, std::abs(inL));
            blockMaxInR = std::max(blockMaxInR, std::abs(inR));

            // 1. Channel Routing (Stereo L/R vs Mid/Side)
            float ch1 = inL;
            float ch2 = inR;

            if (currentRouting != ChannelRouting::StereoLR && isStereo) {
                // MS Encoding: M = (L+R)*0.7071, S = (L-R)*0.7071
                constexpr float invSqrt2 = 0.7071067811865475f;
                ch1 = (inL + inR) * invSqrt2; // Mid
                ch2 = (inL - inR) * invSqrt2; // Side

                // MonoMaker: highpass filter on Side channel (<80 Hz mono bass)
                if (monoMakerEnabled) {
                    const auto svfOut = monoMakerFilters[1].process(ch2);
                    ch2 = svfOut.hp;
                }
            }

            // 2. Process Channel 1 (Left or Mid)
            bool clippedCh1 = false;
            float grCh1 = 0.0f;
            float out1 = processSingleChannel(ch1, 0, clippedCh1, grCh1);

            // 3. Process Channel 2 (Right or Side)
            bool clippedCh2 = false;
            float grCh2 = 0.0f;
            float out2 = out1;
            if (isStereo) {
                if (currentRouting == ChannelRouting::MidOnly) {
                    // Mid clipped and DC-blocked; Side passes through matching DC blocker to preserve exact phase symmetry
                    out1 = dcBlockers[0].processSample(out1);
                    out2 = dcBlockers[1].processSample(ch2);
                } else if (currentRouting == ChannelRouting::SideOnly) {
                    // Side clipped and DC-blocked; Mid passes through matching DC blocker to preserve exact phase symmetry
                    out1 = dcBlockers[0].processSample(ch1);
                    out2 = processSingleChannel(ch2, 1, clippedCh2, grCh2);
                    out2 = dcBlockers[1].processSample(out2);
                } else if (currentRouting == ChannelRouting::MidSideSplit) {
                    out2 = processSingleChannel(ch2, 1, clippedCh2, grCh2);
                    out1 = dcBlockers[0].processSample(out1);
                    out2 = dcBlockers[1].processSample(out2);
                } else {
                    out2 = processSingleChannel(ch2, 1, clippedCh2, grCh2);
                }
            }

            // 4. MS Decoding back to L/R if needed
            float clippedL = out1;
            float clippedR = out2;

            if (currentRouting != ChannelRouting::StereoLR && isStereo) {
                constexpr float invSqrt2 = 0.7071067811865475f;
                clippedL = (out1 + out2) * invSqrt2;
                clippedR = (out1 - out2) * invSqrt2;
            }

            const bool sampleClipped = (clippedCh1 || clippedCh2);
            if (sampleClipped) anyClipping = true;

            const float sampleGR = std::max(grCh1, grCh2);
            blockMaxGR = std::max(blockMaxGR, sampleGR);

            // 5. Shaved Peak Delta (pure pre-clip minus post-clip material)
            // Psychoacoustic Continuous Linear Subtraction:
            // Eliminates rectangular Dirac impulse clicks at clipping boundaries while maintaining
            // pure silence below threshold when unclipped.
            const float diffL = alignedInL - clippedL;
            const float diffR = alignedInR - clippedR;
            float deltaRawL = (std::abs(diffL) > 1.0e-5f) ? diffL : 0.0f;
            float deltaRawR = (std::abs(diffR) > 1.0e-5f) ? diffR : 0.0f;

            // Delta delay compensation to align with ISP lookahead (4 samples)
            constexpr size_t ISP_LATENCY = TruePeakLimiter::LookaheadLatency;
            const float deltaDelayedL = deltaDelayL[deltaDelayIdx];
            const float deltaDelayedR = deltaDelayR[deltaDelayIdx];
            deltaDelayL[deltaDelayIdx] = deltaRawL;
            deltaDelayR[deltaDelayIdx] = deltaRawR;
            deltaDelayIdx = (deltaDelayIdx + 1) % ISP_LATENCY;

            const float finalDeltaL = truePeakGuardEnabled ? deltaDelayedL : deltaRawL;
            const float finalDeltaR = truePeakGuardEnabled ? deltaDelayedR : deltaRawR;

            // 6. Apply Output Makeup Gain
            float finalL = clippedL * outGainLinear;
            float finalR = clippedR * outGainLinear;

            // 7. DC Blocking for Stereo L/R mode (MS modes handled domain-neutrally above)
            if (currentRouting == ChannelRouting::StereoLR) {
                finalL = dcBlockers[0].processSample(finalL);
                if (isStereo) finalR = dcBlockers[1].processSample(finalR);
            }

            // 8. True Peak Inter-Sample Peak Guard (or strict ceiling safety clamp)
            if (truePeakGuardEnabled) {
                if (isStereo) {
                    TruePeakLimiter::processStereoPair(ispLimiters[0], ispLimiters[1], finalL, finalR, finalL, finalR, ceilingDb);
                } else {
                    finalL = ispLimiters[0].processSample(finalL, ceilingDb);
                    finalR = finalL;
                }
            } else {
                if (outGainLinear <= 1.001f && currentRouting != ChannelRouting::MidOnly && currentRouting != ChannelRouting::SideOnly) {
                    finalL = std::clamp(finalL, -ceilingLinear, ceilingLinear);
                    if (isStereo) finalR = std::clamp(finalR, -ceilingLinear, ceilingLinear);
                }
            }

            // 9. Delta Audition Mode (Output = isolated shaved peaks)
            float outSampleL = finalL;
            float outSampleR = finalR;

            if (deltaAudition) {
                outSampleL = finalDeltaL;
                outSampleR = finalDeltaR;
            }

            leftChannel[i] = outSampleL;
            if (isStereo) rightChannel[i] = outSampleR;

            blockMaxOutL = std::max(blockMaxOutL, std::abs(outSampleL));
            blockMaxOutR = std::max(blockMaxOutR, std::abs(outSampleR));

            // 10. Scope Snapshot Streaming (Lock-free triple-ring)
            scopeRingBuffer[writeIdx] = {
                (inL + inR) * 0.5f,
                (outSampleL + outSampleR) * 0.5f,
                (finalDeltaL + finalDeltaR) * 0.5f,
                sampleClipped
            };
            writeIdx = (writeIdx + 1) % SCOPE_BUFFER_SIZE;

            // RMS accumulation local to block
            const float sumSq = outSampleL * outSampleL + outSampleR * outSampleR;
            blockSumSq += sumSq;
        }

        // Release fence: ensure all writes to scopeRingBuffer are visible before updating write index
        scopeWriteIndex.store(writeIdx, std::memory_order_release);

        // Buffer-size invariant ballistics decay:
        // Decay time constant tau = 0.050s (50 ms). dt = numSamples / sr.
        const float dt = static_cast<float>(numSamples) / sr;
        const float blockDecayAlpha = 1.0f - std::exp(-dt / 0.050f);

        // Instant attack, exponential decay for true peak meters
        peakInL  = (blockMaxInL  > peakInL)  ? blockMaxInL  : (peakInL  + blockDecayAlpha * (blockMaxInL  - peakInL));
        peakInR  = (blockMaxInR  > peakInR)  ? blockMaxInR  : (peakInR  + blockDecayAlpha * (blockMaxInR  - peakInR));
        peakOutL = (blockMaxOutL > peakOutL) ? blockMaxOutL : (peakOutL + blockDecayAlpha * (blockMaxOutL - peakOutL));
        peakOutR = (blockMaxOutR > peakOutR) ? blockMaxOutR : (peakOutR + blockDecayAlpha * (blockMaxOutR - peakOutR));
        maxGR    = (blockMaxGR   > maxGR)    ? blockMaxGR   : (maxGR    + blockDecayAlpha * (blockMaxGR   - maxGR));

        // Smooth RMS power
        const float blockMeanSq = blockSumSq / static_cast<float>(numSamples * 2);
        smoothMeanSq += blockDecayAlpha * (blockMeanSq - smoothMeanSq);
        const float rms = std::sqrt(std::max(1.0e-8f, smoothMeanSq));
        const float peak = std::max(peakOutL, peakOutR);
        const float crestFactorDb = std::max(0.0f, gainToDb(peak) - gainToDb(rms));

        // Atomic publish to GUI thread (lock-free)
        atomicInPeakL.store(peakInL, std::memory_order_relaxed);
        atomicInPeakR.store(peakInR, std::memory_order_relaxed);
        atomicOutPeakL.store(peakOutL, std::memory_order_relaxed);
        atomicOutPeakR.store(peakOutR, std::memory_order_relaxed);
        atomicMaxGR.store(maxGR, std::memory_order_relaxed);
        atomicCrestFactorDb.store(crestFactorDb, std::memory_order_relaxed);
        isClippingFlag.store(anyClipping, std::memory_order_relaxed);
    }

    // Read thread-safe telemetry metrics for 60 FPS GUI rendering (Zero engine state modifications!)
    [[nodiscard]] TelemetryData getTelemetry() const noexcept {
        TelemetryData d;
        d.inPeakDbL = gainToDb(std::max(1.0e-5f, atomicInPeakL.load(std::memory_order_relaxed)));
        d.inPeakDbR = gainToDb(std::max(1.0e-5f, atomicInPeakR.load(std::memory_order_relaxed)));
        d.outPeakDbL = gainToDb(std::max(1.0e-5f, atomicOutPeakL.load(std::memory_order_relaxed)));
        d.outPeakDbR = gainToDb(std::max(1.0e-5f, atomicOutPeakR.load(std::memory_order_relaxed)));
        d.maxGainReductionDb = atomicMaxGR.load(std::memory_order_relaxed);
        d.isClippingNow = isClippingFlag.load(std::memory_order_relaxed);
        d.crestFactorDb = atomicCrestFactorDb.load(std::memory_order_relaxed);
        return d;
    }

    // Read a coherent snapshot of the scope buffer for 60 FPS GUI rendering
    void copyScopeSnapshot(std::array<ScopeSample, SCOPE_BUFFER_SIZE>& dest) const noexcept {
        const size_t currentWrite = scopeWriteIndex.load(std::memory_order_acquire);
        for (size_t i = 0; i < SCOPE_BUFFER_SIZE; ++i) {
            const size_t srcIdx = (currentWrite + i) % SCOPE_BUFFER_SIZE;
            dest[i] = scopeRingBuffer[srcIdx];
        }
    }

private:
    // Process a single channel through TransDetail + Selected Clipper Engine
    inline float processSingleChannel(float in, int chIdx, bool& outClipped, float& outGR) noexcept {
        const float absIn = std::abs(in);
        outClipped = (absIn > ceilingLinear);

        if (outClipped) {
            outGR = gainToDb(absIn) - ceilingDb;
        } else {
            outGR = 0.0f;
        }

        // 1. TransDetail Orthogonal Carrier / Detail Split
        const auto split = transDetail[chIdx].split(in);

        // 2. Apply Selected Clipper Topology to Carrier
        float clippedCarrier = split.carrier;

        switch (currentMode) {
            case ClipperMode::PrecisionDigital: {
                // ADAA-2 Bit-exact piecewise Hard Clip
                const float digitalOut = hardClippers[chIdx].processSample(split.carrier, ceilingLinear);
                // Blend with C2-continuous quintic acoustic corridor if soft knee is engaged
                if (softKnee > 0.001f) {
                    const float c2AcousticOut = goldClippers[chIdx].processSample(split.carrier, ceilingLinear, false);
                    clippedCarrier = (1.0f - softKnee) * digitalOut + softKnee * c2AcousticOut;
                } else {
                    clippedCarrier = digitalOut;
                }
                break;
            }

            case ClipperMode::GoldConverter122: {
                // Lavry Gold 122-96 ADC Authentic Physical Emulation:
                // 1. Discrete JFET input buffer with calibrated musical H2 @ -52 dBFS
                // 2. Dynamic Joule heating thermal memory sag (tau = 35 ms)
                // 3. C2-continuous quintic smoothing eliminating acoustic shockwaves & transducer jerk
                goldClippers[chIdx].setDiodeProfile(AcousticThermalDiodeClipper::DiodeProfile::Silicon_1N4148);
                clippedCarrier = goldClippers[chIdx].processSample(split.carrier, ceilingLinear, true);
                break;
            }

            case ClipperMode::TubeTriodeClassA: {
                // Asymmetric Class-A Tube warmth with musical 2nd harmonic and soft saturation
                const float scaled = split.carrier / ceilingLinear;
                const float tubeIn = scaled + 0.04f * std::tanh(scaled * scaled) * (scaled >= 0.0f ? 1.0f : -0.5f);
                const float tubeOut = analogClippers[chIdx].processSample(tubeIn, 1.0f);
                clippedCarrier = std::clamp(tubeOut * ceilingLinear, -ceilingLinear, ceilingLinear);
                break;
            }

            case ClipperMode::GermaniumDiode: {
                // Vintage Germanium diode conduction with authentic Shockley curve & organic knee
                goldClippers[chIdx].setDiodeProfile(AcousticThermalDiodeClipper::DiodeProfile::Germanium_1N34A);
                clippedCarrier = goldClippers[chIdx].processSample(split.carrier, ceilingLinear, true);
                break;
            }
        }

        // 3. Recombine Carrier and Detail with Dynamic Transient Protection
        return transDetail[chIdx].recombine(split.rawIn, clippedCarrier, split.detail, split.transientWeight, ceilingLinear);
    }

    float sr = 44100.0f;
    float inGainDb = 0.0f;
    float inGainLinear = 1.0f;
    float ceilingDb = 0.0f;
    float ceilingLinear = 1.0f;
    float outGainDb = 0.0f;
    float outGainLinear = 1.0f;
    float softKnee = 0.0f;
    float detailPreserve = 1.0f;
    float alchemyAirDb = 0.0f;
    float monoMakerFreqHz = 80.0f;

    bool monoMakerEnabled = true;
    bool truePeakGuardEnabled = true;
    bool deltaAudition = false;

    ClipperMode currentMode = ClipperMode::PrecisionDigital;
    ChannelRouting currentRouting = ChannelRouting::StereoLR;

    // Channels
    ADAA2HardClipper hardClippers[2];
    ADAA2Clipper analogClippers[2];
    AcousticThermalDiodeClipper goldClippers[2];
    TransDetailMatrix transDetail[2];
    DCBlocker dcBlockers[2];
    TruePeakLimiter ispLimiters[2];
    ZDFSVF64 monoMakerFilters[2];

    // Delta latency alignment delay buffers (4 samples matching TruePeak lookahead)
    static constexpr size_t DELTA_LOOKAHEAD = TruePeakLimiter::LookaheadLatency;
    std::array<float, DELTA_LOOKAHEAD> deltaDelayL{};
    std::array<float, DELTA_LOOKAHEAD> deltaDelayR{};
    size_t deltaDelayIdx = 0;
    float inPrevL = 0.0f;
    float inPrevR = 0.0f;

    // Telemetry & Scope (Audio-thread local states)
    float peakInL = 0.0f;
    float peakInR = 0.0f;
    float peakOutL = 0.0f;
    float peakOutR = 0.0f;
    float maxGR = 0.0f;
    float smoothMeanSq = 0.0f;

    // Lock-free atomic telemetry published to GUI thread
    std::atomic<float> atomicInPeakL{ 0.0f };
    std::atomic<float> atomicInPeakR{ 0.0f };
    std::atomic<float> atomicOutPeakL{ 0.0f };
    std::atomic<float> atomicOutPeakR{ 0.0f };
    std::atomic<float> atomicMaxGR{ 0.0f };
    std::atomic<float> atomicCrestFactorDb{ 0.0f };
    std::atomic<bool>  isClippingFlag{ false };

    alignas(64) std::array<ScopeSample, SCOPE_BUFFER_SIZE> scopeRingBuffer{};
    std::atomic<size_t> scopeWriteIndex{ 0 };
};

} // namespace dsp171
