#pragma once
#include <cmath>
#include <algorithm>
#include <atomic>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include <dsp171/ZDFSVF.h>

namespace dsp171 {

// =============================================================================
// 171 VocalCraft - Style-Conditioned Adaptive Dynamic Compressor
//
// Automatically adapts dynamic envelope topologies and ballistic time constants
// to match the selected musical style (Hip-Hop, Pop, Trap, R&B).
//
// - In Hip-Hop Mode: "Consonant Punch-Through" dynamically extends attack
//   (15-35 ms) on consonant bursts to let lyrics and percussive articulation
//   cut through, then instantly snaps down to sub-millisecond attack on vowels
//   with high ratio (6:1-10:1) and fast release (45 ms) to pin the vocal body.
// - In Pop Mode: Dual-stage Opto+FET behavior with progressive 6 dB soft knee
//   and smooth, invisible leveling.
// - In Trap Mode: Aggressive crest-factor reduction and 120 Hz sidechain HPF.
// - In R&B Mode: Transparent micro-dynamics with musical breathing envelope.
//
// Operator controls ONLY the single macro: "Compression Amount" (0% to 100%).
// =============================================================================
class VocalCraftAdaptiveCompressor {
public:
    enum class Style {
        HipHop = 0,
        Pop,
        Trap,
        RnB
    };

    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 0.0 ? sampleRate : 44100.0;
        scHpfL.reset();
        scHpfL.setParameters(110.0f, 0.707f, static_cast<float>(sr));
        scHpfR.reset();
        scHpfR.setParameters(110.0f, 0.707f, static_cast<float>(sr));

        // Sidechain envelope follower: 1.0 ms peak attack, 25 ms release
        // Filters out zero-crossing AC ripple to eliminate intermodulation distortion (IMD)
        envAttackCoeff  = fastOneMinusExpNeg(static_cast<float>(-1000.0 / (1.0 * sr)));
        envReleaseCoeff = fastOneMinusExpNeg(static_cast<float>(-1000.0 / (25.0 * sr)));

        reset();
    }

    void reset() noexcept {
        scHpfL.reset();
        scHpfR.reset();
        scEnvelope = 0.0001f;
        detectorEnvelopeDb = 0.0f;
        optoMemoryEnvelopeDb = 0.0f;
        currentGrDb.store(0.0f, std::memory_order_relaxed);
        neuralTargetRatio = 0.0f;
    }

    void setStyle(Style newStyle) noexcept {
        currentStyle = newStyle;
    }

    void setCompressionAmount(float amount0To1) noexcept {
        compressionAmount = std::clamp(amount0To1, 0.0f, 1.0f);
    }

    void setConsonantPunchOverride(float trimDb) noexcept {
        consonantPunchOffsetDb = std::clamp(trimDb, -6.0f, 6.0f);
    }

    void setNeuralRatio(float neuralRatio) noexcept {
        if (neuralRatio >= 1.0f) {
            neuralTargetRatio = std::clamp(neuralRatio, 1.2f, 16.0f);
        }
    }

    // Process a single sample with consonant punch weighting (Mono)
    inline float processSample(float input, float consonantWeight) noexcept {
        if (compressionAmount <= 0.001f) {
            currentGrDb.store(0.0f, std::memory_order_relaxed);
            return input;
        }

        const float scSample = scHpfL.process(input).hp;
        const float scAbs = std::abs(scSample);

        // Peak envelope follower: smooths across wave cycles, preventing audio-rate ripple & IMD
        if (scAbs > scEnvelope) {
            scEnvelope += (scAbs - scEnvelope) * envAttackCoeff;
        } else {
            scEnvelope += (scAbs - scEnvelope) * envReleaseCoeff;
        }

        const float scDb = (scEnvelope > 1e-6f) ? fastLinearToDb(scEnvelope) : -120.0f;

        float attackMs = 8.0f;
        float releaseMs = 60.0f;
        const float targetGrDb = computeTargetReduction(scDb, consonantWeight, attackMs, releaseMs);

        updateDetectorBallistics(targetGrDb, attackMs, releaseMs);

        const float vcaGain = fastDbToLinear(detectorEnvelopeDb);
        return input * vcaGain;
    }

    // Process a stereo pair with linked sidechain (preserves stereo phantom center image)
    inline void processStereo(float& left, float& right, float consonantWeight) noexcept {
        if (compressionAmount <= 0.001f) {
            currentGrDb.store(0.0f, std::memory_order_relaxed);
            return;
        }

        const float scSampleL = scHpfL.process(left).hp;
        const float scSampleR = scHpfR.process(right).hp;
        const float scAbs = std::max(std::abs(scSampleL), std::abs(scSampleR));

        if (scAbs > scEnvelope) {
            scEnvelope += (scAbs - scEnvelope) * envAttackCoeff;
        } else {
            scEnvelope += (scAbs - scEnvelope) * envReleaseCoeff;
        }

        const float scDb = (scEnvelope > 1e-6f) ? fastLinearToDb(scEnvelope) : -120.0f;

        float attackMs = 8.0f;
        float releaseMs = 60.0f;
        const float targetGrDb = computeTargetReduction(scDb, consonantWeight, attackMs, releaseMs);

        updateDetectorBallistics(targetGrDb, attackMs, releaseMs);

        const float vcaGain = fastDbToLinear(detectorEnvelopeDb);
        left *= vcaGain;
        right *= vcaGain;
    }

    // Telemetry getter for GUI
    float getGainReductionDb() const noexcept {
        return currentGrDb.load(std::memory_order_relaxed);
    }

private:
    inline float computeTargetReduction(float scDb, float consonantWeight, float& attackMs, float& releaseMs) const noexcept {
        const float thresholdDb = -4.0f - (compressionAmount * 32.0f);
        float ratio = 4.0f;
        float kneeWidthDb = 4.0f;
        attackMs = 8.0f;
        releaseMs = 60.0f;

        switch (currentStyle) {
            case Style::HipHop:
                ratio = 4.0f + (compressionAmount * 6.0f); // 4:1 to 10:1
                kneeWidthDb = 2.5f;                         // Punchy tight knee
                releaseMs = 45.0f;                          // Fast recovery for groove
                // CONSONANT PUNCH-THROUGH:
                // Opens attack (25-35ms) on consonants, snaps to 1.5ms on vowels
                attackMs = std::lerp(1.5f, 28.0f + consonantPunchOffsetDb, std::clamp(consonantWeight, 0.0f, 1.0f));
                break;

            case Style::Pop:
                ratio = 2.5f + (compressionAmount * 2.5f); // 2.5:1 to 5:1
                kneeWidthDb = 7.0f;                        // Wide, musical soft knee
                attackMs = 12.0f;                          // Gentle attack
                releaseMs = 160.0f;                        // Smooth release
                break;

            case Style::Trap:
                ratio = 6.0f + (compressionAmount * 8.0f); // 6:1 to 14:1
                kneeWidthDb = 1.5f;                        // Hard knee
                attackMs = std::lerp(2.0f, 22.0f, std::clamp(consonantWeight * 0.7f, 0.0f, 1.0f));
                releaseMs = 38.0f;                         // Ultra-fast recovery
                break;

            case Style::RnB:
                ratio = 2.0f + (compressionAmount * 2.0f); // 2:1 to 4:1
                kneeWidthDb = 9.0f;                        // Ultra-smooth knee
                attackMs = 15.0f;
                releaseMs = 220.0f;                        // Musical slow decay
                break;
        }

        if (neuralTargetRatio > 1.0f) {
            // Musically fuse style preset ratio with neural network's dynamic acoustic prediction
            ratio = std::lerp(ratio, neuralTargetRatio, 0.35f);
        }

        float overThresholdDb = 0.0f;
        const float delta = scDb - thresholdDb;

        if (delta <= -kneeWidthDb * 0.5f) {
            overThresholdDb = 0.0f;
        } else if (delta >= kneeWidthDb * 0.5f) {
            overThresholdDb = delta;
        } else {
            const float k = delta + (kneeWidthDb * 0.5f);
            overThresholdDb = (k * k) / (2.0f * kneeWidthDb);
        }

        return -overThresholdDb * (1.0f - (1.0f / ratio));
    }

    inline void updateDetectorBallistics(float targetGrDb, float attackMs, float releaseMs) noexcept {
        const float attackCoeff = fastOneMinusExpNeg(static_cast<float>(-1000.0 / (attackMs * sr)));
        const float releaseCoeff = fastOneMinusExpNeg(static_cast<float>(-1000.0 / (releaseMs * sr)));

        if (targetGrDb < detectorEnvelopeDb) {
            // Attack (reducing gain further)
            detectorEnvelopeDb += (targetGrDb - detectorEnvelopeDb) * attackCoeff;
        } else {
            // Release (recovering gain)
            if (currentStyle == Style::Pop) {
                const float slowCoeff = fastOneMinusExpNeg(static_cast<float>(-1.0 / (0.800 * sr)));
                optoMemoryEnvelopeDb += (targetGrDb - optoMemoryEnvelopeDb) * slowCoeff;
                const float blendedRecovery = 0.65f * releaseCoeff + 0.35f * slowCoeff;
                detectorEnvelopeDb += (targetGrDb - detectorEnvelopeDb) * blendedRecovery;
            } else {
                detectorEnvelopeDb += (targetGrDb - detectorEnvelopeDb) * releaseCoeff;
            }
        }

        detectorEnvelopeDb = std::clamp(detectorEnvelopeDb, -36.0f, 0.0f);
        currentGrDb.store(detectorEnvelopeDb, std::memory_order_relaxed);
    }

    double sr = 44100.0;
    Style currentStyle = Style::HipHop;
    float compressionAmount = 0.5f;
    float consonantPunchOffsetDb = 0.0f;
    float neuralTargetRatio = 0.0f;

    ZDFSVF64 scHpfL;
    ZDFSVF64 scHpfR;
    float scEnvelope = 0.0001f;
    float envAttackCoeff = 0.05f;
    float envReleaseCoeff = 0.005f;
    float detectorEnvelopeDb = 0.0f;
    float optoMemoryEnvelopeDb = 0.0f;

    std::atomic<float> currentGrDb{0.0f};
};

} // namespace dsp171
