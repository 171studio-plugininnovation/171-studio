#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <BinaryData.h>

namespace gui171 {

// ==============================================================================
// VINTAGE BOUTIQUE JEWEL LAMP BUTTON (Ruby / Amber)
// Toggle Button fotorealistico con gemma sfaccettata, ghiera in ottone e alone radiante
// ==============================================================================
class BoutiqueJewelLampButton : public juce::ToggleButton {
public:
    enum class LampType {
        Ruby,    // Master Bypass
        Amber,   // Delta Listen
        Emerald  // Smart Brain
    };

    BoutiqueJewelLampButton(LampType type, const juce::String& text)
        : lampType(type), labelText(text)
    {
        setOpaque(false);
        setMouseCursor(juce::MouseCursor::PointingHandCursor);

        switch (type) {
            case LampType::Ruby:
                imgOn = juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_ruby_on_png, BinaryData::lamp_jewel_ruby_on_pngSize);
                glowColor = juce::Colour(0xffff283b); // Ruby Red
                break;
            case LampType::Amber:
                imgOn = juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_amber_on_png, BinaryData::lamp_jewel_amber_on_pngSize);
                glowColor = juce::Colour(0xffffa020); // Warm Amber
                break;
            case LampType::Emerald:
                imgOn = juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_green_on_png, BinaryData::lamp_jewel_green_on_pngSize);
                glowColor = juce::Colour(0xff00e5a3); // Radiant Emerald Jade
                break;
        }

        imgOff = juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_dark_off_png, BinaryData::lamp_jewel_dark_off_pngSize);
    }

    void paintButton(juce::Graphics& g, bool shouldDrawButtonAsHighlighted, bool /*shouldDrawButtonAsDown*/) override
    {
        auto bounds = getLocalBounds().toFloat();
        if (bounds.isEmpty()) return;

        const bool isLit = getToggleState();

        // 1. Divisione layout: gemma in alto, etichetta serigrafata in basso (13 px)
        const float labelH = 13.0f;
        auto lampArea = bounds.removeFromTop(bounds.getHeight() - labelH).reduced(2.0f);
        auto textRect = bounds;

        const float lampSize = juce::jmin(lampArea.getWidth(), lampArea.getHeight());
        const float cx = lampArea.getCentreX();
        const float cy = lampArea.getCentreY();
        auto lampSquare = juce::Rectangle<float>(cx - lampSize * 0.5f, cy - lampSize * 0.5f, lampSize, lampSize);

        // 2. Ombra portata della ghiera in ottone
        g.setColour(juce::Colour(0x90000000));
        g.fillEllipse(lampSquare.translated(1.0f, 2.0f));

        // 3. Disegno della gemma scura (spenta)
        if (imgOff.isValid()) {
            g.drawImage(imgOff, lampSquare, juce::RectanglePlacement::centred);
        }

        // 4. Sovrapposizione gemma accesa con alone di bloom radiante
        if (isLit) {
            // Radiant bloom esterno
            juce::ColourGradient bloom(glowColor.withAlpha(0.48f), cx, cy,
                                       glowColor.withAlpha(0.0f), cx - lampSize * 0.95f, cy - lampSize * 0.95f, true);
            g.setGradientFill(bloom);
            g.fillEllipse(cx - lampSize * 0.90f, cy - lampSize * 0.90f, lampSize * 1.80f, lampSize * 1.80f);

            // Gemma ON illuminata ad alta saturazione
            if (imgOn.isValid()) {
                g.drawImage(imgOn, lampSquare, juce::RectanglePlacement::centred);
            }
        }

        // Highlight bordo ghiera se mouse hover
        if (shouldDrawButtonAsHighlighted) {
            g.setColour(juce::Colour(0x40ffe082));
            g.drawEllipse(lampSquare.reduced(1.0f), 1.2f);
        }

        // 5. Etichetta incisa laser in oro satinato / rubino / ambra
        if (labelText.isNotEmpty()) {
            g.setFont(juce::FontOptions(9.0f, juce::Font::bold));
            if (isLit) {
                g.setColour(glowColor.interpolatedWith(juce::Colour(0xffffe082), 0.55f));
            } else {
                g.setColour(shouldDrawButtonAsHighlighted ? juce::Colour(0xffffe082) : juce::Colour(0x99c5a059));
            }
            g.drawText(labelText, textRect, juce::Justification::centred);
        }
    }

private:
    LampType lampType;
    juce::String labelText;
    juce::Image imgOn;
    juce::Image imgOff;
    juce::Colour glowColor;
};

} // namespace gui171
