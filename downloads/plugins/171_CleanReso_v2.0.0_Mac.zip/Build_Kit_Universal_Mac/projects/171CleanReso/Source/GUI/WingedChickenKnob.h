#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <BinaryData.h>
#include <cmath>
#include <algorithm>

namespace gui171 {

// ==============================================================================
// LOOK AND FEEL PER LE MANOPOLE CHICKEN HEAD ALATE (171 PERFECTPRE STYLE)
// 6 COLORI BOUTIQUE: COBALT BLUE, WARM BRONZE, NEVE RED, EMERALD JADE, AMBER GOLD, LIGHT STEEL
// ==============================================================================
class WingedChickenKnobLookAndFeel : public juce::LookAndFeel_V4 {
public:
    enum class KnobColor {
        CobaltBlue,  // DEPTH: Cobalt Blue (#00b4ff)
        WarmBronze,  // TARGET FREQ: Warm Bronze (#d4af37)
        NeveRed,     // SELECTIVITY: Neve Red (#ff3344)
        EmeraldJade, // TRANS SHIELD: Emerald Jade (#00ff88)
        AmberGold,   // ANALOG SILK: Amber Gold (#ffaa00)
        LightSteel   // OUTPUT TRIM: White Porcelain / Light Steel (#f0f4f8)
    };

    explicit WingedChickenKnobLookAndFeel(KnobColor color = KnobColor::CobaltBlue,
                                          bool bipolar = false,
                                          float bipolarZeroNormalized = 0.5f)
        : currentColor(color), isBipolar(bipolar), bipolarZero(bipolarZeroNormalized)
    {
        switch (color) {
            case KnobColor::CobaltBlue:
                knobImg = juce::ImageCache::getFromMemory(BinaryData::knob_winged_blue_png, BinaryData::knob_winged_blue_pngSize);
                neonColor = juce::Colour(0xff00b4ff); // Cobalt Blue
                break;
            case KnobColor::WarmBronze:
                knobImg = juce::ImageCache::getFromMemory(BinaryData::knob_winged_bronze_png, BinaryData::knob_winged_bronze_pngSize);
                neonColor = juce::Colour(0xffd4af37); // Warm Bronze
                break;
            case KnobColor::NeveRed:
                knobImg = juce::ImageCache::getFromMemory(BinaryData::knob_winged_red_png, BinaryData::knob_winged_red_pngSize);
                neonColor = juce::Colour(0xffff3344); // Neve Red
                break;
            case KnobColor::EmeraldJade:
                knobImg = juce::ImageCache::getFromMemory(BinaryData::knob_winged_steel_png, BinaryData::knob_winged_steel_pngSize);
                neonColor = juce::Colour(0xff00ff88); // Emerald Jade
                break;
            case KnobColor::AmberGold:
                knobImg = juce::ImageCache::getFromMemory(BinaryData::knob_winged_bronze_png, BinaryData::knob_winged_bronze_pngSize);
                neonColor = juce::Colour(0xffffaa00); // Amber Gold
                break;
            case KnobColor::LightSteel:
                knobImg = juce::ImageCache::getFromMemory(BinaryData::knob_winged_steel_png, BinaryData::knob_winged_steel_pngSize);
                neonColor = juce::Colour(0xfff0f4f8); // White Porcelain / Light Steel
                break;
        }

        collarImg = juce::ImageCache::getFromMemory(BinaryData::collar_knurled_png, BinaryData::collar_knurled_pngSize);
    }

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPosProportional, float rotaryStartAngle,
                          float rotaryEndAngle, juce::Slider& /*slider*/) override
    {
        const float size = static_cast<float>(juce::jmin(width, height));
        const float cx = static_cast<float>(x) + static_cast<float>(width) * 0.5f;
        const float cy = static_cast<float>(y) + static_cast<float>(height) * 0.5f;

        const float radius = size * 0.5f - 2.0f;
        const float arcRadius = radius - 3.0f;
        const float knobSize = size * 0.72f;

        // Angolo fisico cursore
        const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

        // 1. Collare zigrinato metallico sul fondo
        if (collarImg.isValid()) {
            auto collarRect = juce::Rectangle<float>(cx - radius * 0.96f, cy - radius * 0.96f, radius * 1.92f, radius * 1.92f);
            g.drawImage(collarImg, collarRect, juce::RectanglePlacement::centred);
        }

        // 2. Tacche serigrafate circolari calibrate in oro satinato 171 Studio
        const int numTicks = 11;
        for (int i = 0; i < numTicks; ++i) {
            float normT = (float)i / (float)(numTicks - 1);
            float tickAngle = rotaryStartAngle + normT * (rotaryEndAngle - rotaryStartAngle);
            float rInner = (i == 0 || i == 5 || i == 10) ? radius - 5.0f : radius - 3.0f;
            float rOuter = radius + 1.0f;

            float tx1 = cx + rInner * std::sin(tickAngle);
            float ty1 = cy - rInner * std::cos(tickAngle);
            float tx2 = cx + rOuter * std::sin(tickAngle);
            float ty2 = cy - rOuter * std::cos(tickAngle);

            bool isMajor = (i == 0 || i == 5 || i == 10);
            g.setColour(isMajor ? juce::Colour(0xffc5a059) : juce::Colour(0x608c7042));
            g.drawLine(tx1, ty1, tx2, ty2, isMajor ? 1.4f : 0.8f);
        }

        // 3. Traccia circolare scura incassata nel pannello
        juce::Path trackBg;
        trackBg.addCentredArc(cx, cy, arcRadius, arcRadius, 0.0f, rotaryStartAngle, rotaryEndAngle, true);
        g.setColour(juce::Colour(0x40000000));
        g.strokePath(trackBg, juce::PathStrokeType(4.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        g.setColour(juce::Colour(0x25c5a059));
        g.strokePath(trackBg, juce::PathStrokeType(2.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // 4. Traccia neon luminescente attiva
        juce::Path activeArc;
        if (isBipolar) {
            float centerAngle = rotaryStartAngle + bipolarZero * (rotaryEndAngle - rotaryStartAngle);
            float a1 = std::min(centerAngle, angle);
            float a2 = std::max(centerAngle, angle);
            if (std::abs(a2 - a1) > 0.02f)
                activeArc.addCentredArc(cx, cy, arcRadius, arcRadius, 0.0f, a1, a2, true);
        } else {
            if (sliderPosProportional > 0.005f)
                activeArc.addCentredArc(cx, cy, arcRadius, arcRadius, 0.0f, rotaryStartAngle, angle, true);
        }

        if (!activeArc.isEmpty()) {
            // Radiant bloom esterno
            g.setColour(neonColor.withAlpha(0.25f));
            g.strokePath(activeArc, juce::PathStrokeType(6.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Core neon saturo brillante
            g.setColour(neonColor.withAlpha(0.90f));
            g.strokePath(activeArc, juce::PathStrokeType(2.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Specular bianco
            g.setColour(juce::Colours::white.withAlpha(0.6f));
            g.strokePath(activeArc, juce::PathStrokeType(1.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Perla luminosa terminale all'estremità del cursore
            float beadX = cx + arcRadius * std::sin(angle);
            float beadY = cy - arcRadius * std::cos(angle);
            g.setColour(neonColor.withAlpha(0.7f));
            g.fillEllipse(beadX - 3.5f, beadY - 3.5f, 7.0f, 7.0f);
            g.setColour(juce::Colours::white);
            g.fillEllipse(beadX - 1.5f, beadY - 1.5f, 3.0f, 3.0f);
        }

        // 5. Disegno della manopola Chicken Head fotografica rotante
        auto knobRect = juce::Rectangle<float>(cx - knobSize * 0.5f, cy - knobSize * 0.5f, knobSize, knobSize);

        if (knobImg.isValid()) {
            // Ombra portata morbida sotto la manopola
            g.setColour(juce::Colour(0x95000000));
            g.fillEllipse(knobRect.translated(2.0f, 3.5f).reduced(knobSize * 0.12f));

            juce::Graphics::ScopedSaveState state(g);
            g.addTransform(juce::AffineTransform::rotation(angle, cx, cy));
            g.drawImage(knobImg, knobRect, juce::RectanglePlacement::centred);
        } else {
            // Fallback procedurale elegante
            juce::Graphics::ScopedSaveState state(g);
            g.addTransform(juce::AffineTransform::rotation(angle, cx, cy));

            juce::ColourGradient grad(juce::Colour(0xff2d333f), cx - knobSize * 0.5f, cy - knobSize * 0.5f,
                                      juce::Colour(0xff12151c), cx + knobSize * 0.5f, cy + knobSize * 0.5f, false);
            g.setGradientFill(grad);
            g.fillEllipse(knobRect);
            g.setColour(neonColor);
            g.drawLine(cx, cy - knobSize * 0.45f, cx, cy - knobSize * 0.1f, 2.5f);
        }
    }

private:
    KnobColor currentColor;
    juce::Colour neonColor;
    bool isBipolar = false;
    float bipolarZero = 0.5f;
    juce::Image knobImg;
    juce::Image collarImg;
};

// ==============================================================================
// COMPONENTE CONTROLLO MANOPOLA CHICKEN HEAD (Header + Chicken + Pill Readout)
// ==============================================================================
class WingedChickenKnobComponent : public juce::Component, public juce::SettableTooltipClient {
public:
    void setTooltip(const juce::String& newTooltip) override {
        juce::SettableTooltipClient::setTooltip(newTooltip);
        slider.setTooltip(newTooltip);
    }
    enum class DisplayFormat {
        Percentage,   // 0 .. 100 % (o 0.0 .. 1.0 moltiplicato 100)
        Hertz,        // 1.0k .. 12.0k Hz
        Decibels      // -18.0 .. +12.0 dB
    };

    WingedChickenKnobComponent(const juce::String& name,
                               WingedChickenKnobLookAndFeel::KnobColor color,
                               DisplayFormat format,
                               bool bipolar = false,
                               float bipolarZeroNormalized = 0.5f,
                               bool isNormalizedPercentage = true)
        : knobName(name), dispFormat(format), isNormalized(isNormalizedPercentage),
          lookAndFeel(color, bipolar, bipolarZeroNormalized)
    {
        setOpaque(false);

        slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        slider.setLookAndFeel(&lookAndFeel);
        // Range di rotazione standard -144° .. +144° (come in 171 PerfectPre)
        slider.setRotaryParameters(-juce::MathConstants<float>::pi * 0.80f,
                                    juce::MathConstants<float>::pi * 0.80f, true);
        addAndMakeVisible(slider);

        slider.onValueChange = [this]() {
            updatePillText();
            repaint();
        };

        updatePillText();
    }

    ~WingedChickenKnobComponent() override {
        slider.setLookAndFeel(nullptr);
    }

    void resized() override {
        auto area = getLocalBounds();

        // Header con titolo del controllo (16 px)
        titleArea = area.removeFromTop(16);

        // Readout pill container in basso (20 px)
        pillArea = area.removeFromBottom(20).reduced(juce::jmax(2, (area.getWidth() - 68) / 2), 1).toFloat();

        // Area slider centrale quadrata
        int side = juce::jmin(area.getWidth(), area.getHeight());
        slider.setBounds(area.getCentreX() - side / 2, area.getY() + (area.getHeight() - side) / 2, side, side);
    }

    void paint(juce::Graphics& g) override {
        // 1. Serigrafia Titolo Controllo in Oro Satinato 171 Studio
        g.setFont(juce::FontOptions(9.5f, juce::Font::bold));
        g.setColour(juce::Colour(0xffffe082));
        g.drawText(knobName, titleArea, juce::Justification::centred);

        // 2. Fondo incassato del Display Pill
        g.setColour(juce::Colour(0xff090a0d));
        g.fillRoundedRectangle(pillArea, 4.0f);

        // Bordo bisellato in ottone/oro caldo
        g.setColour(juce::Colour(0xffc5a059));
        g.drawRoundedRectangle(pillArea, 4.0f, 1.0f);

        // 3. Testo Valore formattato nel pill
        g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xfff1f5f9));
        g.drawText(cachedValueText, pillArea, juce::Justification::centred);
    }

    void updatePillText() {
        double val = slider.getValue();
        char buf[32];
        switch (dispFormat) {
            case DisplayFormat::Percentage:
                if (isNormalized)
                    std::snprintf(buf, sizeof(buf), "%d %%", juce::roundToInt(val * 100.0));
                else
                    std::snprintf(buf, sizeof(buf), "%d %%", juce::roundToInt(val));
                break;
            case DisplayFormat::Hertz:
                if (val >= 1000.0)
                    std::snprintf(buf, sizeof(buf), "%.2f kHz", val / 1000.0);
                else
                    std::snprintf(buf, sizeof(buf), "%d Hz", juce::roundToInt(val));
                break;
            case DisplayFormat::Decibels:
                std::snprintf(buf, sizeof(buf), "%+.1f dB", val);
                break;
        }
        cachedValueText = buf;
    }

    juce::Slider slider;

private:
    juce::String knobName;
    DisplayFormat dispFormat;
    bool isNormalized = true;
    WingedChickenKnobLookAndFeel lookAndFeel;
    juce::Rectangle<int> titleArea;
    juce::Rectangle<float> pillArea;
    juce::String cachedValueText = "0.0";
};

} // namespace gui171
