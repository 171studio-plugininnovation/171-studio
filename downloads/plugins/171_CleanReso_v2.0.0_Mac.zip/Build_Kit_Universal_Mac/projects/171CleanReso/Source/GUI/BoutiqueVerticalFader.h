#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <BinaryData.h>
#include <cmath>
#include <algorithm>

namespace gui171 {

// ==============================================================================
// LOOK AND FEEL PER IL FADER VERTICALE SLIM BOUTIQUE (171 STUDIO CONSOLE)
// PISTA SNELLA IN OTTONE INVECCHIATO & CAP GUNMETAL SOLIDO CON LED AMBRA (ZERO TRASPARENZA)
// ==============================================================================
class BoutiqueVerticalFaderLookAndFeel : public juce::LookAndFeel_V4 {
public:
    BoutiqueVerticalFaderLookAndFeel() {
        trackImg = juce::ImageCache::getFromMemory(BinaryData::Fader_Track_Boutique_AgedBrass_Slot_Master_png,
                                                   BinaryData::Fader_Track_Boutique_AgedBrass_Slot_Master_pngSize);
        capImg   = juce::ImageCache::getFromMemory(BinaryData::Fader_Cap_Boutique_Gunmetal_AmberLED_Master_png,
                                                   BinaryData::Fader_Cap_Boutique_Gunmetal_AmberLED_Master_pngSize);
    }

    void drawLinearSlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPos, float /*minSliderPos*/, float /*maxSliderPos*/,
                          juce::Slider::SliderStyle /*style*/, juce::Slider& /*slider*/) override
    {
        const float boundsX = static_cast<float>(x);
        const float boundsY = static_cast<float>(y);
        const float boundsW = static_cast<float>(width);
        const float boundsH = static_cast<float>(height);
        const float cx = boundsX + boundsW * 0.5f;

        // 1. Canale di scorrimento snello (Aged Brass Slot - Proporzione elegante da console boutique)
        float trackW = juce::jmin(boundsW * 0.22f, 26.0f);
        float trackH = boundsH * 0.88f;
        auto trackRect = juce::Rectangle<float>(cx - trackW * 0.5f, boundsY + (boundsH - trackH) * 0.5f, trackW, trackH);

        // Tacche serigrafate calibrate sui due lati del canale in oro satinato
        static const float percentTicks[] = { 1.0f, 0.75f, 0.50f, 0.25f, 0.0f };
        static const char* percentLabels[] = { "100", "75", "50", "25", "0" };
        float topY = trackRect.getY() + 10.0f;
        float botY = trackRect.getBottom() - 10.0f;

        for (size_t i = 0; i < 5; ++i) {
            float ty = botY - percentTicks[i] * (botY - topY);
            bool isMajor = (i == 0 || i == 2 || i == 4);

            // Tacche serigrafate a sinistra
            g.setColour(isMajor ? juce::Colour(0xffc5a059) : juce::Colour(0x608c7042));
            g.drawLine(cx - trackW * 0.5f - 8.0f, ty, cx - trackW * 0.5f - 2.0f, ty, isMajor ? 1.2f : 0.8f);

            // Tacche e label numeriche a destra
            g.drawLine(cx + trackW * 0.5f + 2.0f, ty, cx + trackW * 0.5f + 8.0f, ty, isMajor ? 1.2f : 0.8f);
            g.setFont(juce::FontOptions(7.5f, isMajor ? juce::Font::bold : juce::Font::plain));
            g.drawText(percentLabels[i], cx + trackW * 0.5f + 10.0f, ty - 5.0f, 20.0f, 10.0f, juce::Justification::left);
        }

        // 2. Rendering della pista in ottone invecchiato (Aged Brass Channel)
        if (trackImg.isValid()) {
            g.drawImage(trackImg, trackRect, juce::RectanglePlacement::centred);
        } else {
            // Fallback procedurale elegante
            g.setColour(juce::Colour(0x80000000));
            g.fillRoundedRectangle(trackRect.translated(1.0f, 1.5f), 4.0f);

            juce::ColourGradient brassGrad(juce::Colour(0xffc5a059), trackRect.getX(), trackRect.getY(),
                                          juce::Colour(0xff4a3712), trackRect.getRight(), trackRect.getBottom(), false);
            g.setGradientFill(brassGrad);
            g.fillRoundedRectangle(trackRect, 4.0f);

            // Fessura scura interna
            auto slotRect = trackRect.reduced(trackW * 0.35f, 10.0f);
            g.setColour(juce::Colour(0xff08090d));
            g.fillRoundedRectangle(slotRect, 2.0f);
        }

        // 3. Fader Cap snello ed ergonomico (Solid Gunmetal, NESSUNA trasparenza spuria)
        float capW = juce::jmin(boundsW * 0.36f, 38.0f);
        float capH = capW * 1.62f;
        float cy = sliderPos;

        // Ombra portata solida sotto il cursore
        g.setColour(juce::Colour(0xa8000000));
        g.fillRoundedRectangle(cx - capW * 0.5f + 1.5f, cy - capH * 0.5f + 3.0f, capW, capH, 3.5f);

        // Disegno fader cap fotorealistico completamente opaco e nitido
        auto capRect = juce::Rectangle<float>(cx - capW * 0.5f, cy - capH * 0.5f, capW, capH);
        if (capImg.isValid()) {
            g.drawImage(capImg, capRect, juce::RectanglePlacement::centred);
        } else {
            // Fallback procedurale solido
            juce::ColourGradient capGrad(juce::Colour(0xff3f434d), capRect.getX(), capRect.getY(),
                                         juce::Colour(0xff181a1f), capRect.getX(), capRect.getBottom(), false);
            g.setGradientFill(capGrad);
            g.fillRoundedRectangle(capRect, 3.0f);

            g.setColour(juce::Colour(0xff68707f));
            g.drawRoundedRectangle(capRect, 3.0f, 1.0f);

            // Feritoia LED solida ambra
            auto ledSlit = juce::Rectangle<float>(capRect.getX() + 3.0f, cy - 1.2f, capRect.getWidth() - 6.0f, 2.4f);
            g.setColour(juce::Colour(0xffffaa00));
            g.fillRect(ledSlit);
            g.setColour(juce::Colours::white);
            g.fillRect(ledSlit.reduced(1.0f, 0.5f));
        }
    }

private:
    juce::Image trackImg;
    juce::Image capImg;
};

// ==============================================================================
// COMPONENTE MODULO FADER VERTICALE SLIM BOUTIQUE (Titolo + Fader + Pill Display)
// ==============================================================================
class BoutiqueVerticalFaderComponent : public juce::Component, public juce::SettableTooltipClient {
public:
    void setTooltip(const juce::String& newTooltip) override {
        juce::SettableTooltipClient::setTooltip(newTooltip);
        slider.setTooltip(newTooltip);
    }
    explicit BoutiqueVerticalFaderComponent(const juce::String& name = "MIX")
        : faderTitle(name)
    {
        setOpaque(false);

        slider.setSliderStyle(juce::Slider::LinearVertical);
        slider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        slider.setLookAndFeel(&lookAndFeel);
        addAndMakeVisible(slider);

        slider.onValueChange = [this]() {
            updatePillText();
            repaint();
        };
    }

    ~BoutiqueVerticalFaderComponent() override {
        slider.setLookAndFeel(nullptr);
    }

    void resized() override {
        auto area = getLocalBounds();

        // Titolo superiore (16 px)
        titleArea = area.removeFromTop(16);

        // Readout pill container in basso (20 px)
        pillArea = area.removeFromBottom(20).reduced(juce::jmax(2, (area.getWidth() - 64) / 2), 1).toFloat();

        // Area fader centrale
        slider.setBounds(area.reduced(2, 4));
    }

    void paint(juce::Graphics& g) override {
        // 1. Serigrafia Titolo Controllo in Oro Satinato 171 Studio
        g.setFont(juce::FontOptions(9.5f, juce::Font::bold));
        g.setColour(juce::Colour(0xffffe082));
        g.drawText(faderTitle, titleArea, juce::Justification::centred);

        // 2. Fondo incassato del Display Pill
        g.setColour(juce::Colour(0xff090a0d));
        g.fillRoundedRectangle(pillArea, 4.0f);

        // Bordo bisellato in ottone/oro caldo
        g.setColour(juce::Colour(0xffc5a059));
        g.drawRoundedRectangle(pillArea, 4.0f, 1.0f);

        // 3. Testo Valore formattato nel pill (0 .. 100 %)
        g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xfff1f5f9));
        g.drawText(cachedValueText, pillArea, juce::Justification::centred);
    }

    void updatePillText() {
        double val = slider.getValue();
        char buf[32];
        // APVTS mix va da 0.0 a 1.0
        std::snprintf(buf, sizeof(buf), "%d %%", juce::roundToInt(val * 100.0));
        cachedValueText = buf;
    }

    juce::Slider slider;

private:
    juce::String faderTitle;
    BoutiqueVerticalFaderLookAndFeel lookAndFeel;
    juce::Rectangle<int> titleArea;
    juce::Rectangle<float> pillArea;
    juce::String cachedValueText = "100 %";
};

} // namespace gui171
