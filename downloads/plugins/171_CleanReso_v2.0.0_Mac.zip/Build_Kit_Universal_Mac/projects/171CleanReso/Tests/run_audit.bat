@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
cd /d "%~dp0"
cl.exe /EHsc /std:c++20 /O2 /I "..\..\dsp171-core\include" /I "..\Source" audit_full_spectrum.cpp /Fe:audit_full_spectrum.exe
if %ERRORLEVEL% EQU 0 (
    echo [OK] Audit executable compiled successfully. Running Principal DSP Audit...
    audit_full_spectrum.exe
)
