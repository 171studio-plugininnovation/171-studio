171CleanReso - Transient-Aware Dynamic Resonance Suppressor & Spectral Shaper
Version 1.0.0 PRO (Studio Innovation Edition)
171PluginInnovation - All Rights Reserved

============================================================
1. PERCHE' 171CleanReso E' RIVOLUZIONARIO:
============================================================
Nei tradizionali soppressori spettrali (come Soothe 2), gli algoritmi 
scambiano gli attacchi delle percussioni e delle consonanti vocali per picchi 
risonanti, smussando e mangiando l'energia dei colpi (time-smearing).

171CleanReso introduce il "TRANSIENT SHIELD":
- Riconosce in tempo reale con doppio inseguitore balistico se l'energia 
  appartiene a un attacco impulsivo o a una risonanza stazionaria.
- Scherma i transienti lasciandoli passare al 100% intatti (punch e snap preservati).
- Applica i notch dinamici con ponderazione psicoacustica ISO 226 (sensibilita' 
  fino a 3x sull'asprezza 2.5 kHz - 5 kHz) esclusivamente sulle risonanze fischianti.

============================================================
2. I CONTROLLI DELLA CONSOLE:
============================================================
- SOFT / HARD TOGGLE: 
  * SOFT: Intervento progressivo, organico e musicale per voci, chitarre acustiche e master bus.
  * HARD: Intervento chirurgico ad aggancio rapido per piatti metallici, sibilanti taglienti e ring di rullante.
- PRESET SELECTOR: 8 preset calibrati di fabbrica per ogni scenario di mix e mastering.
- DELTA LISTEN (Spia Jewel Ambra): Ascolto isolato delle sole frequenze aspre e risonanze rimosse.
- MASTER BYPASS (Spia LED Verde/Rosso): Dissolvenza incrociata continua a 15 ms pop-free.
- DEPTH: Intensita' globale della soppressione dinamica (0% - 100%).
- SHARPNESS: Fattore Q delle campane di soppressione (da largo a chirurgico ultra-stretto).
- SELECTIVITY: Soglia di discriminazione tra risonanza dannosa e corpo timbrico naturale dello strumento.
- TRANS SHIELD (Manopola Hero Centrale): Grado di schermatura e protezione degli attacchi impulsivi.
- ANALOG SILK: Stadio di lucidatura post-pulizia con High-Air Baxandall a 12 kHz e calore valvolare da 2a armonica.
- MIX: Bilanciamento Dry / Wet a fase lineare e coerente.
- OUTPUT: Regolazione del guadagno d'uscita finale (-18 dB a +12 dB).

============================================================
3. DISPLAY SPETTRALE E METER DE-HARSH DEDICATO (60 FPS):
============================================================
- DISPLAY SPETTRALE PRINCIPALE (Cornice Dorata Sinistra):
  * Curva Ciano / Blu con sfumatura: Spettro audio in ingresso ad alta risoluzione.
  * Curva Dips Arancio / Rosso: Attenuazione dinamica in tempo reale delle 32 bande logaritmiche.
  * Readout Digitale: Frequenza dominante della risonanza (Hz) e valore di Gain Reduction massimo (dB).
  * Badge Transient Shield: Segnala quando gli attacchi sono protetti dalla soppressione.

- METER DEDICATO DE-HARSH (Cornice Dorata Destra):
  * Colonna verticale a 20 segmenti LED con codice colore graduato (Verde -> Oro -> Arancio -> Rosso).
  * Indicatore Peak-Hold ad alta intensita' con decadimento balistico gravitazionale.
  * Scala serigrafata da 0 dB a -30 dB di riduzione.
  * Display numerico digitale dedicato alla base del meter.

============================================================
4. SPECIFICHE TECNICHE ED INGEGNERISTICHE:
============================================================
- Architettura: JUCE 8.0.4, C++20 nativo, MSVC 2022 con ottimizzazioni /fp:fast e /O2.
- Sicurezza: Analog Safety Brickwall Ceil a -0.09 dBFS (zero clipping inter-sample).
- Latenza & Threading: Coda SPSC Lock-Free cache-aligned a 64 byte, zero allocazioni sull'audio thread.
- Standard Formati: VST3 (64-bit) e Standalone Windows nativo.

============================================================
5. COLLAUDO SU TRACCE REALI (BEAT & REC ALBUM):
============================================================
I test di laboratorio dinamico sono stati eseguiti con successo al 100%
sui file master e multitraccia dello studio (cartella 'beat mixtape'):
Cartella file renderizzati per l'ascolto comparativo:
C:\Users\171Studio\Desktop\beat mixtape\171CleanReso_Test_Outputs\

1. 01_Brother_Beat_MasterTamer_Soft.wav:
   - Controllo morbido e trasparente delle risonanze sul beat intero (Max GR -10.1 dB).
2. 02_Brother_Beat_SurgicalHunter_Hard.wav:
   - Intervento chirurgico aggressivo sulle frequenze faticanti (Max GR -28.0 dB, 0.0 clipping).
3. 03_Drums_SnareRing_TransShield85.wav:
   - Stem batteria con Transient Shield all'85%: attacco di cassa e rullante preservato al 95.5%,
     abbattimento del ring risonante a -18.0 dB.
4. 04_Drums_Cymbals_Tamed.wav:
   - Addomesticamento dell'asprezza su piatti e charleston.
5. 05_Vocal_DeHarsh_Silk_Soft.wav:
   - Voce principale 'REC ALBUM' de-harshata con morbidezza analogica e aria a 12 kHz (Max GR -16.1 dB).
6. 06_Vocal_DeltaListen_IsolatedHarshness.wav:
   - Modalita' Delta Listen: ascolto isolato di tutto il fischio e le sibilanti rimosse dalla voce.
7. 07_VocalTake_HardClamp.wav:
   - Aggancio immediato e bloccaggio sibilanti taglienti su take vocale rapido.

============================================================
INSTALLAZIONE:
============================================================
- VST3: La cartella '171CleanReso.vst3' e' gia' installata in:
  C:\Program Files\Common Files\VST3\171CleanReso.vst3
- Standalone: Avvia '171CleanReso_Standalone.exe' per uso diretto senza DAW.
