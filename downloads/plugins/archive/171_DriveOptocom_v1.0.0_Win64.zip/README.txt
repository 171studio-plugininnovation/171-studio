======================================================================
  171PluginInnovation - DRIVE OPTOCOM (v1.1.0 Boutique Modern Edition)
======================================================================

CONTENUTO DEL PACCHETTO:
  - DRIVE OPTOCOM.exe         -> Applicazione Standalone per Windows (64-bit)
  - DRIVE OPTOCOM.vst3/       -> Plugin VST3 a 64-bit per tutte le DAW
                                 (Cubase, Ableton, FL Studio, Reaper, Studio One, ecc.)
  - README.txt                -> Questo file informativo

CARATTERISTICHE DSP & ARCHITETTURA DI LABORATORIO:
  1. MODELLAZIONE FISICA DELLA CELLA ELETTRO-OTTICA T4B:
     - Doppia trappola di decadimento con risposta temporale asimmetrica dipendente dalla storia del segnale.
     - Isteresi foto-chimica reale LA-2A con memoria profonda per un livellamento vocale e di bus setoso.
     - Circuito Stereo Link dinamico e filtro Sidechain a 100 Hz selezionabile.

  2. PREAMP VALVOLARE IN CLASSE A & SATURATORE TRI-BAND:
     - Saturazione a triodo con esaltazione delle seconde armoniche calde e filtro DC blocker ZDF a 5 Hz.
     - Tri-Band Saturator con crossover Linkwitz-Riley LR-4 e compensazione allpass AP2 a fase rigorosamente piatta (0.00 dB).
     - Routing flessibile pre/post compressione e Punch Mode dinamico.

  3. CMF DIFFERENZIATO & MANOPOLE BOUTIQUE FOTOREALISTICHE:
     - PREAMP & DRIVE: manopole Teardrop Bronze con colletto in ottone e ghiera graduata calibrata.
     - OPTO DYNAMICS: pomelli vintage scanalati in bachelite Teletronix LA-2A con ghiera vintage originale.
     - SATURATION: pomello classico Neve Marconi Ruby Red.
     - MAKEUP: pomello Gunmetal Diamond Knurled ad alta aderenza.

  4. DOPPIO SCHERMO INCASSATO CON VETRO POLARIZZATO ANTIRIFLESSO:
     - Galvanometro Analogico VU / GR con ago a spada ad alta definizione, perno in ottone e lampada al tungsteno.
     - CRT Oscilloscopio telemetrico con visualizzazione forma d'onda, curva di compressione Knee e riga ducking T4B.
     - Spia reattiva Opto Cell Jewel Lamp ambra che brilla dinamicamente in tempo reale proporzionalmente alla compressione.

  5. INTERFACCIA GRAFICA MODERNA, RESIZE BAR & LOOKANDFEEL STUDIO 171:
     - Barra di ridimensionamento fluido (Resizable Bar) con vincolo di proporzione fisso 1024x571.
     - Selettore Preset metallico con corpo titanio scuro, bordo satinato oro e freccia chevron.
     - Modulo Heavy-Duty Bypass con LED rubino di stato.

  6. SICUREZZA AUDIO & LATENZA:
     - BS.1770-4 True-Peak Limiter a -0.10 dBTP (zero clipping inter-sample).
     - Latenza host di soli 4 campioni con compensazione millimetrica di fase nel bypass.

GUIDA ALL'INSTALLAZIONE VST3:
  1. Copia l'intera cartella 'DRIVE OPTOCOM.vst3' nella directory standard dei plugin VST3:
     C:\Program Files\Common Files\VST3\
  2. Apri la tua DAW ed effettua la scansione dei nuovi plugin VST3.
  3. L'applicazione 'DRIVE OPTOCOM.exe' puo' essere eseguita direttamente senza DAW.

(C) 2026 171PluginInnovation - 171 Studio. Tutti i diritti riservati.
======================================================================
