# 🎚️ DOSSIER TECNICO DI TRASPOSIZIONE — 171 EASYVOICE
### Master Vocal Channel Strip & Multi-Engine Suite per Apple macOS

**Progetto:** 171 EasyVoice (`v1.0.0`)  
**Architettura:** Universal Binary Fat (`arm64` Apple Silicon M1-M4 + `x86_64` Intel)  
**Deployment Target Minimo:** macOS 11.0 Big Sur  
**Approvato da:** Il Direttore  
**Coordinamento:** `dsp-hire-manager`, `comp-optical-universal` & `apple-macos-engineer`  

---

## 1. SPECIFICHE FORMATI & METADATI APPLE AUDIOUNIT

| Parametro | Valore Configurato | Specifiche per DAW macOS |
|---|---|---|
| **AudioUnit Type** | `kAudioUnitType_Effect` (`'aufx'`) | Inseribile come master vocal channel strip in **Logic Pro** e GarageBand |
| **Manufacturer Code** | `'171P'` | Conforme alle specifiche Apple (include almeno una maiuscola) |
| **Plugin Code / Subtype** | `'171E'` | Identificativo univoco a 4 caratteri per scansione AU |
| **Target Formati Mac** | **AU (`.component`)**, **VST3 (`.vst3`)**, **Standalone (`.app`)** | AU per Logic Pro; VST3 per Ableton, Cubase, Reaper, Studio One, FL |
| **Sicurezza Gatekeeper** | Hardened Runtime attivo | Flag `--options runtime` + entitlements JIT, Unsigned Memory e Audio Input |

---

## 2. ARCHITETTURA MULTI-ENGINE SU APPLE SILICON (M1–M4)

171 EasyVoice integra 7 sezioni di processing analogico in un unico motore coerente:

1. **Preamp & British EQ**:
   - Stadio di ingresso Neve/SSL con filtri ad alta pendenza e campane musicali proportional-Q.
2. **De-Esser Dinamico con Lookahead**:
   - Tracking delle sibilanti foniche a fase lineare (4.5 kHz - 9.5 kHz) con rilascio adattivo.
3. **Doppia Compressione Ottica & FET**:
   - **Opto T4B (LA-2A Style)**: Doppio decadimento foto-resistivo non lineare per controllo RMS musicale.
   - **FET Ultra-Fast (1176 Style)**: Attacco da 20 a 800 microsecondi per domare i picchi transienti vocali.
4. **Vocal Doubler & Micro-Pitch Detune**:
   - Decorrelazione stereo microfonica (+/- 9 cent) mono-compatibile al 100%.
5. **Air Band High-Shelf (Maag Style)**:
   - Respiro serico a 20 kHz e 40 kHz modellato senza asimmetrie di fase.
6. **Smart Loudness Matching (ITU-R BS.1770 / EBU R128)**:
   - Normalizzazione istantanea del livello d'ascolto (A/B) per confrontare il suono processato con il segnale raw a parità di volume percepito.

### 2.1 Efficienza di Calcolo su Unified Memory Architecture (UMA)
L'intera catena a 7 stadi lavora **in-place** nella cache L2/L3 dei processori Apple Silicon. Grazie alla memoria unificata ad altissima larghezza di banda (fino a 800 GB/s su M3/M4 Max), la latenza tra stadi successivi è pari a **0 campioni aggiuntivi** oltre al lookahead opzionale del de-esser.

---

## 3. INTERFACCIA RETINA A 4 BAIE (BOUTIQUE CONSOLE)

- **Chassis Master Serigrafato in Oro Satinato**: Telaio blueprint 2480x1400 renderizzato su display Liquid Retina con nitidezza assoluta.
- **Modulo SerumV VU & GR Meter**: Galvanometro analogico con quadrante color avorio, ago a spillo e riflessi in vetro temperato fotorealistici.
- **Tasti Push-Button Retroilluminati ad Ambra**: Risposta tattile grafica con stato acceso/spento a transizione fluida a 60 FPS.

---

## 4. COMANDO DI COMPILAZIONE RAPIDA

```bash
# Esegui da terminale Mac:
./scripts/build_171easyvoice_mac.sh

# Validazione Apple auval per Logic Pro:
auval -v aufx 171E 171P
```
