import os
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

def create_metal_texture(w, h, base_color, noise_intensity=0.035, brushed_h=True, seed=171):
    np.random.seed(seed)
    r_base, g_base, b_base = base_color
    
    # 1. Base gradient (top slightly lighter, bottom slightly darker)
    y = np.linspace(1.05, 0.95, h)[:, None]
    
    # 2. Brushed noise
    if brushed_h:
        noise = np.random.randn(h, w).astype(np.float32)
        hairlines = cv2.GaussianBlur(noise, (65, 1), 18, 0)
        noise_med = np.random.randn(h, w // 4).astype(np.float32)
        noise_med = cv2.resize(noise_med, (w, h), interpolation=cv2.INTER_LINEAR)
        banding = cv2.GaussianBlur(noise_med, (129, 1), 35, 0)
        tex = hairlines * 0.6 + banding * 0.4
    else:
        noise = np.random.randn(h, w).astype(np.float32)
        hairlines = cv2.GaussianBlur(noise, (1, 65), 0, 18)
        tex = hairlines
        
    tex = (tex - tex.mean()) / (tex.std() + 1e-6)
    mod = y + tex * noise_intensity
    
    r = np.clip(r_base * mod, 0, 255).astype(np.uint8)
    g = np.clip(g_base * mod, 0, 255).astype(np.uint8)
    b = np.clip(b_base * mod, 0, 255).astype(np.uint8)
    
    img = np.dstack([r, g, b, np.full((h, w), 255, dtype=np.uint8)])
    return Image.fromarray(img, mode='RGBA')

def draw_cnc_bevel(draw, box, radius=12, bevel_depth=3, is_recessed=True):
    x1, y1, x2, y2 = box
    if is_recessed:
        top_color = (10, 12, 16, 220)       # Deep inner shadow top
        bot_color = (200, 185, 150, 140)   # Specular crest rim bottom
    else:
        top_color = (240, 225, 180, 180)   # Raised crest top
        bot_color = (15, 18, 22, 220)      # Cast shadow bottom
        
    for i in range(bevel_depth):
        d = float(i)
        r = max(2.0, radius - d)
        alpha_t = int(top_color[3] * (1.0 - d / bevel_depth))
        alpha_b = int(bot_color[3] * (1.0 - d / bevel_depth))
        
        draw.rounded_rectangle([x1 + d, y1 + d, x2 - d, y2 - d], radius=r,
                               outline=(top_color[0], top_color[1], top_color[2], alpha_t), width=1)
        draw.rounded_rectangle([x1 + d, y1 + d, x2 - d, y2 - d], radius=r,
                               outline=(bot_color[0], bot_color[1], bot_color[2], alpha_b), width=1)

def draw_hex_screw(img, center, radius=14, is_brass=True):
    draw = ImageDraw.Draw(img)
    cx, cy = center
    
    draw.ellipse([cx - radius - 2, cy - radius - 2, cx + radius + 2, cy + radius + 2],
                 fill=(12, 14, 18, 255), outline=(210, 180, 120, 100), width=1)
    
    if is_brass:
        base_col = (205, 165, 80)
        hi_col   = (255, 235, 160)
    else:
        base_col = (140, 145, 155)
        hi_col   = (220, 225, 235)
        
    dome = Image.new('RGBA', (radius*2, radius*2), (0,0,0,0))
    d_draw = ImageDraw.Draw(dome)
    for r in range(radius, 0, -1):
        t = float(r) / radius
        cr = int(hi_col[0] * (1-t) + base_col[0] * t)
        cg = int(hi_col[1] * (1-t) + base_col[1] * t)
        cb = int(hi_col[2] * (1-t) + base_col[2] * t)
        d_draw.ellipse([radius - r, radius - r, radius + r, radius + r], fill=(cr, cg, cb, 255))
        
    slot_w = max(2, radius // 3)
    slot_len = radius * 1.3
    d_draw.line([radius - slot_len//2, radius, radius + slot_len//2, radius], fill=(30, 24, 15, 255), width=slot_w)
    d_draw.line([radius, radius - slot_len//2, radius, radius + slot_len//2], fill=(30, 24, 15, 255), width=slot_w)
    
    img.alpha_composite(dome, (int(cx - radius), int(cy - radius)))

def draw_dial_arc_ticks(draw, center, radius, min_deg=220, max_deg=-40, num_ticks=11,
                        color=(210, 180, 120, 200), tick_len=6, tick_w=2):
    cx, cy = center
    angles = np.linspace(min_deg, max_deg, num_ticks)
    for ang in angles:
        rad = np.radians(ang - 90)
        x1 = cx + (radius - tick_len) * np.cos(rad)
        y1 = cy + (radius - tick_len) * np.sin(rad)
        x2 = cx + radius * np.cos(rad)
        y2 = cy + radius * np.sin(rad)
        draw.line([x1, y1, x2, y2], fill=color, width=tick_w)

def generate_full_master_chassis(output_path, branding_badge_path, master_logo_path):
    # Total Master dimensions: 2480 x 1400 (@2x Retina for 1240 x 700 GUI)
    W, H = 2480, 1400
    
    # 1. Base Main Chassis: Deep Space Grey Brushed Aluminum (#181B20)
    chassis = create_metal_texture(W, H, base_color=(24, 27, 32), noise_intensity=0.030, brushed_h=True, seed=171)
    draw = ImageDraw.Draw(chassis)
    
    # Outer chassis heavy CNC perimeter bevel
    draw_cnc_bevel(draw, [8, 8, W - 8, H - 8], radius=16, bevel_depth=6, is_recessed=False)
    
    # 4 Corner Chassis Hex Screws
    for cx, cy in [(48, 48), (W - 48, 48), (48, H - 48), (W - 48, H - 48)]:
        draw_hex_screw(chassis, (cx, cy), radius=18, is_brass=True)
        
    # Top Header Divider Line (y = 132 @2x -> y = 66 @1x)
    draw.line([24, 128, W - 24, 128], fill=(10, 12, 15, 255), width=3)
    draw.line([24, 131, W - 24, 131], fill=(195, 160, 85, 160), width=1) # gold pinstripe
    
    # Master Footer Divider Line (y = 1236 @2x -> y = 618 @1x)
    draw.line([24, 1234, W - 24, 1234], fill=(195, 160, 85, 140), width=1)
    draw.line([24, 1236, W - 24, 1236], fill=(8, 10, 14, 255), width=4)
    
    # -------------------------------------------------------------
    # 2. BAY CAVITIES GEOMETRIES (@2x)
    # Bay 1: x=36,  w=568, y=134, h=1098 (NLS Neve Preamp & Gate)
    # Bay 2: x=620, w=568, y=134, h=1098 (R-DeEsser & Maag Air)
    # Bay 3: x=1204,w=712, y=134, h=1098 (SSL 242 4-Band EQ & Spectrum)
    # Bay 4: x=1932,w=512, y=134, h=1098 (CLA Dual Dynamics & SerumV Meter)
    # -------------------------------------------------------------
    bays = [
        {"name": "Bay1_NLS",    "box": [36, 134, 604, 1232],   "color": (28, 38, 36), "brass": True},
        {"name": "Bay2_DeEss",  "box": [620, 134, 1188, 1232], "color": (22, 28, 38), "brass": False},
        {"name": "Bay3_SSLEQ",  "box": [1204, 134, 1916, 1232],"color": (32, 35, 38), "brass": True},
        {"name": "Bay4_CLA",    "box": [1932, 134, 2444, 1232],"color": (26, 28, 30), "brass": True}
    ]
    
    # Load fonts
    try:
        font_title = ImageFont.truetype("arialbd.ttf", 24)
        font_sub   = ImageFont.truetype("arialbd.ttf", 17)
        font_micro = ImageFont.truetype("arial.ttf", 14)
        font_tiny  = ImageFont.truetype("arial.ttf", 12)
        font_brand = ImageFont.truetype("timesbd.ttf", 34)
    except:
        font_title = font_sub = font_micro = font_tiny = font_brand = ImageFont.load_default()

    # Draw individual bay panels
    for bay in bays:
        bx1, by1, bx2, by2 = bay["box"]
        bw = bx2 - bx1
        bh = by2 - by1
        
        # 1. Recessed drop shadow inside chassis
        draw.rounded_rectangle([bx1 - 2, by1 - 2, bx2 + 2, by2 + 2], radius=14, fill=(10, 12, 16, 255))
        
        # 2. Bay Plate Texture
        plate = create_metal_texture(bw, bh, base_color=bay["color"], noise_intensity=0.038,
                                     brushed_h=(bay["name"] != "Bay3_SSLEQ"), seed=100 + bx1)
        p_draw = ImageDraw.Draw(plate)
        
        # Inner CNC chamfer
        draw_cnc_bevel(p_draw, [2, 2, bw - 2, bh - 2], radius=12, bevel_depth=4, is_recessed=True)
        
        # Corner micro screws for bay plate
        for sx, sy in [(16, 16), (bw - 16, 16), (16, bh - 16), (bw - 16, bh - 16)]:
            draw_hex_screw(plate, (sx, sy), radius=9, is_brass=bay["brass"])
            
        # Top Header Bar within Bay Plate (Height 70 @2x -> 35 @1x)
        p_draw.rectangle([6, 6, bw - 6, 72], fill=(12, 14, 18, 180))
        p_draw.line([6, 72, bw - 6, 72], fill=(195, 160, 85, 180), width=2)
        
        # =========================================================
        # BAY 1: VINTAGE ANALOG CONSOLES & GATE
        # =========================================================
        if bay["name"] == "Bay1_NLS":
            # Header Title on Left (leaving right side open for preampSwitch)
            p_draw.text((24, 24), "171 VINTAGE PREAMP", fill=(240, 215, 135, 255), font=font_title)
            p_draw.text((24, 48), "SNOW, SPIKEPROTEIN & MAIK CONSOLES", fill=(175, 155, 110, 220), font=font_tiny)
            
            # Sub-Section 1: VCA Noise Gate (y = 80 .. 320 @2x -> y = 106 .. 226 @1x)
            p_draw.rounded_rectangle([14, 80, bw - 14, 320], radius=8, outline=(45, 55, 55, 200), width=1)
            p_draw.text((24, 92), "VCA NOISE GATE", fill=(140, 175, 210, 240), font=font_sub)
            
            # Sub-Section 2: Console Drive (y = 330 .. 750 @2x -> y = 232 .. 442 @1x)
            p_draw.rounded_rectangle([14, 330, bw - 14, 750], radius=8, outline=(60, 45, 30, 200), width=1)
            p_draw.text((24, 342), "ANALOG CONSOLE COLORATION & DRIVE", fill=(240, 90, 70, 255), font=font_sub)
            
            # Large Drive Dial Calibrated Ring (center perfectly aligned with preampDriveKnob: cx = 250, cy = 560 @2x)
            draw_dial_arc_ticks(p_draw, (250, 560), radius=112, min_deg=220, max_deg=-40, num_ticks=13,
                                color=(240, 80, 60, 240), tick_len=10, tick_w=2)
            p_draw.text((138, 624), "0 dB", fill=(220, 200, 170, 220), font=font_micro, anchor="mm")
            p_draw.text((250, 436), "+6 dB", fill=(240, 100, 80, 240), font=font_tiny, anchor="mm")
            p_draw.text((362, 624), "+12 dB", fill=(255, 80, 60, 240), font=font_micro, anchor="mm")
            
            # Sub-Section 3: Warmth & Output Trim (y = 760 .. 1080 @2x -> y = 448 .. 608 @1x)
            p_draw.rounded_rectangle([14, 760, bw - 14, 1080], radius=8, outline=(50, 45, 35, 200), width=1)
            p_draw.text((24, 772), "CONSOLE HARMONICS & OUTPUT TRIM", fill=(210, 180, 120, 240), font=font_sub)

            # Warmth Dial Ticks (cx = 138, cy = 886)
            draw_dial_arc_ticks(p_draw, (138, 886), radius=56, min_deg=220, max_deg=-40, num_ticks=11,
                                color=(255, 149, 0, 200), tick_len=6, tick_w=1)
            p_draw.text((88, 930), "0", fill=(180, 160, 130, 200), font=font_tiny, anchor="mm")
            p_draw.text((188, 930), "10", fill=(255, 160, 40, 220), font=font_tiny, anchor="mm")

            # Pre Trim Dial Ticks (cx = 398, cy = 886)
            draw_dial_arc_ticks(p_draw, (398, 886), radius=56, min_deg=220, max_deg=-40, num_ticks=13,
                                color=(197, 160, 89, 200), tick_len=6, tick_w=1)
            p_draw.text((346, 930), "-12dB", fill=(180, 160, 130, 200), font=font_tiny, anchor="mm")
            p_draw.text((398, 822), "0dB", fill=(240, 215, 135, 220), font=font_tiny, anchor="mm")
            p_draw.text((450, 930), "+12dB", fill=(180, 160, 130, 200), font=font_tiny, anchor="mm")
            
            # Bottom Studio Emblem
            p_draw.text((bw // 2, 1060), "171 AUDIO LABS - ANALOG CONSOLE COLORATION", fill=(130, 145, 140, 200),
                        font=font_tiny, anchor="mm")

        # =========================================================
        # BAY 2: R-DEESSER & MAAG AIR BAND
        # =========================================================
        elif bay["name"] == "Bay2_DeEss":
            # Header Title on Left
            p_draw.text((24, 24), "171 R-DEESSER LABS", fill=(240, 215, 135, 255), font=font_title)
            p_draw.text((24, 48), "DYNAMIC SIBILANCE CONTROL & 40kHz RESONATOR", fill=(175, 155, 110, 220), font=font_tiny)
            
            # De-Esser Section (y = 80 .. 520 @2x)
            p_draw.rounded_rectangle([14, 80, bw - 14, 520], radius=8, outline=(40, 50, 70, 200), width=1)
            p_draw.text((24, 92), "DYNAMIC DE-ESSING", fill=(100, 180, 240, 240), font=font_sub)
            
            # De-Ess Freq Knob Ring (cx = 100, cy = 202)
            draw_dial_arc_ticks(p_draw, (100, 202), radius=48, min_deg=220, max_deg=-40, num_ticks=11,
                                color=(0, 213, 229, 220), tick_len=6, tick_w=1)
            p_draw.text((62, 240), "1k", fill=(140, 200, 220, 220), font=font_tiny, anchor="mm")
            p_draw.text((100, 146), "6k", fill=(0, 230, 255, 240), font=font_tiny, anchor="mm")
            p_draw.text((138, 240), "12k", fill=(140, 200, 220, 220), font=font_tiny, anchor="mm")

            # De-Ess Threshold Ring (cx = 280, cy = 202)
            draw_dial_arc_ticks(p_draw, (280, 202), radius=48, min_deg=220, max_deg=-40, num_ticks=11,
                                color=(0, 213, 229, 200), tick_len=6, tick_w=1)
            p_draw.text((242, 240), "-48dB", fill=(140, 200, 220, 200), font=font_tiny, anchor="mm")
            p_draw.text((318, 240), "0dB", fill=(140, 200, 220, 200), font=font_tiny, anchor="mm")

            # De-Ess Range Ring (cx = 100, cy = 362)
            draw_dial_arc_ticks(p_draw, (100, 362), radius=48, min_deg=220, max_deg=-40, num_ticks=11,
                                color=(0, 213, 229, 200), tick_len=6, tick_w=1)
            p_draw.text((62, 400), "0dB", fill=(140, 200, 220, 200), font=font_tiny, anchor="mm")
            p_draw.text((138, 400), "24dB", fill=(140, 200, 220, 200), font=font_tiny, anchor="mm")

            # 14-Segment LED Ladder Cavity (Recessed slot at x=392, y=134, w=48, h=320 @2x)
            p_draw.rounded_rectangle([390, 134, 442, 458], radius=6, fill=(10, 12, 16, 255),
                                    outline=(40, 50, 65, 200), width=1)
            p_draw.text((416, 120), "GR (dB)", fill=(240, 160, 60, 220), font=font_tiny, anchor="mm")
            p_draw.text((416, 474), "14-LED", fill=(130, 150, 170, 200), font=font_tiny, anchor="mm")
            
            # Maag Air Band Section (y = 530 .. 1080 @2x)
            p_draw.rounded_rectangle([14, 530, bw - 14, 1080], radius=8, outline=(30, 60, 80, 200), width=1)
            p_draw.text((24, 544), "MAAG AIR BAND (40 kHz)", fill=(60, 220, 240, 255), font=font_sub)
            
            # Large Air Band Knob Dial (center perfectly aligned with airGainKnob: cx = 276, cy = 704 @2x)
            draw_dial_arc_ticks(p_draw, (276, 704), radius=88, min_deg=220, max_deg=-40, num_ticks=11,
                                color=(45, 215, 235, 240), tick_len=8, tick_w=2)
            p_draw.text((192, 756), "0 dB", fill=(180, 225, 235, 220), font=font_micro, anchor="mm")
            p_draw.text((276, 604), "+6 dB", fill=(50, 230, 250, 255), font=font_tiny, anchor="mm")
            p_draw.text((360, 756), "+12 dB", fill=(180, 225, 235, 220), font=font_micro, anchor="mm")

        # =========================================================
        # BAY 3: 171 SUPERSOLIDLINE CONSOLE EQ
        # =========================================================
        elif bay["name"] == "Bay3_SSLEQ":
            # Header Title on Left
            p_draw.text((24, 24), "171 SUPERSOLIDLINE EQ", fill=(240, 215, 135, 255), font=font_title)
            p_draw.text((24, 48), "242 4-BAND PARAMETRIC & FILTERS",
                        fill=(175, 155, 110, 220), font=font_tiny)
            
            # CRT FFT Screen Recessed Bezel (x=16, y=88, w=480, h=228 @2x -> x=612, y=110, w=240, h=114 @1x)
            p_draw.rounded_rectangle([16, 88, 496, 316], radius=8, fill=(8, 10, 14, 255),
                                    outline=(195, 160, 85, 180), width=2)
            p_draw.text((256, 102), "REAL-TIME SPECTRUM ANALYZER & EQ CURVE", fill=(52, 211, 153, 220),
                        font=font_tiny, anchor="mm")
            
            # HPF & LPF Section on the right of CRT (x=516 .. bw-14)
            p_draw.rounded_rectangle([514, 88, bw - 14, 316], radius=8, outline=(60, 65, 75, 200), width=1)
            
            # 4 Discrete Parametric EQ Bands (HF, HMF, LMF, LF)
            bands = [
                {"name": "HF BAND (1.5k - 16kHz)", "col": (225, 45, 95),  "y": 334},
                {"name": "HMF BAND (600 - 7kHz)",  "col": (45, 185, 75),  "y": 520},
                {"name": "LMF BAND (200 - 2.5k)",  "col": (40, 135, 215), "y": 706},
                {"name": "LF BAND (30 - 450Hz)",   "col": (225, 45, 45),  "y": 892}
            ]
            
            for band in bands:
                by = band["y"]
                c_rgb = band["col"]
                p_draw.rounded_rectangle([14, by, bw - 14, by + 176], radius=6, outline=c_rgb + (140,), width=1)
                p_draw.text((24, by + 8), band["name"], fill=c_rgb + (255,), font=font_tiny)
                
            p_draw.text((bw // 2, 1076), "171 AUDIO LABS - SuperSolidLine G-SERIES 242 REPRODUCTION",
                        fill=(160, 170, 180, 200), font=font_tiny, anchor="mm")

        # =========================================================
        # BAY 4: 171-2A & 171-76 DUAL DYNAMICS
        # =========================================================
        elif bay["name"] == "Bay4_CLA":
            # Header Title on Left (leaving right side open for 171-2A and 171-76 switches)
            p_draw.text((20, 24), "171 DYNAMICS", fill=(240, 215, 135, 255), font=font_title)
            p_draw.text((20, 48), "DUAL 171-2A & 171-76", fill=(175, 155, 110, 220), font=font_tiny)
            
            # --- 171METER VU/GR HOUSING CAVITY (x=16, y=84, w=480, h=228 @2x) ---
            m_box = [16, 84, bw - 16, 312]
            p_draw.rounded_rectangle(m_box, radius=10, fill=(12, 14, 18, 255), outline=(195, 160, 85, 200), width=2)
            draw_cnc_bevel(p_draw, m_box, radius=10, bevel_depth=4, is_recessed=True)
            
            # Sub-Section 1: 171-2A Opto Limiter (y = 316 .. 484 @2x -> y = 225 .. 309 @1x)
            p_draw.rounded_rectangle([14, 316, bw - 14, 484], radius=8,
                                    fill=(170, 172, 168, 50), outline=(200, 200, 190, 180), width=1)
            p_draw.text((22, 326), "171-2A VINTAGE OPTO LIMITER (R37 ACID SC)", fill=(225, 228, 230, 255), font=font_sub)
            
            # Sub-Section 2: 171-76 Solid-State FET Limiter (y = 492 .. 948 @2x -> y = 313 .. 541 @1x - EXPANDED!)
            p_draw.rounded_rectangle([14, 492, bw - 14, 948], radius=8, outline=(45, 48, 52, 200), width=1)
            p_draw.text((22, 502), "171-76 SOLID-STATE FET LIMITER", fill=(230, 235, 240, 255), font=font_sub)
            
            # Sub-Section 3: Stereo Vocal Doubler (y = 956 .. 1084 @2x -> y = 545 .. 609 @1x - COMPACT!)
            p_draw.rounded_rectangle([14, 956, bw - 14, 1084], radius=8, outline=(40, 45, 55, 200), width=1)

        # Composite bay plate into main chassis
        chassis.alpha_composite(plate, (bx1, by1))
        
        # Save individual bay faceplate in Assets/Faceplates/
        individual_path = output_path.replace("Master_Chassis_Backplate_171EasyVoice_2480x1400.png",
                                              f"{bay['name']}_Faceplate_171Studio.png")
        plate.save(individual_path, 'PNG', optimize=True)
        print(f"Saved individual faceplate: {individual_path}")

    # -------------------------------------------------------------
    # 3. HEADER & MASTER FOOTER BRANDING (171 STUDIO SATIN GOLD)
    # -------------------------------------------------------------
    # Composite Official Satin Gold Branding Badge into Header (x = 48, y = 18)
    if os.path.exists(branding_badge_path):
        badge = Image.open(branding_badge_path).convert('RGBA')
        badge_w, badge_h = badge.size
        target_h = 84
        target_w = int(badge_w * (target_h / badge_h))
        badge_resized = badge.resize((target_w, target_h), Image.Resampling.LANCZOS)
        chassis.alpha_composite(badge_resized, (48, 20))
        print("Composite 171 Studio satin gold badge onto header")
        
    # Main Title on Header (Next to badge)
    chassis_draw = ImageDraw.Draw(chassis)
    chassis_draw.text((370, 42), "EASY VOICE PRO", fill=(245, 225, 160, 255), font=font_brand)
    chassis_draw.text((372, 82), "BOUTIQUE ALL-IN-ONE VOCAL PRODUCTION SUITE", fill=(180, 160, 110, 220), font=font_sub)
    
    # Master Footer Controls
    # Recessed True Peak & LUFS Display Track (x=500, y=1264, w=1360, h=76 @2x -> x=250, y=632, w=680, h=38 @1x)
    chassis_draw.rounded_rectangle([492, 1264, 1852, 1340], radius=8, fill=(10, 12, 16, 255),
                                   outline=(195, 160, 85, 180), width=1)
    
    # 171 Studio Engineering Insignia on the right of footer
    chassis_draw.text((2140, 1286), "171 PLUGIN INNOVATION", fill=(240, 215, 140, 255), font=font_sub, anchor="mm")
    chassis_draw.text((2140, 1316), "HIGH-PRECISION HARDWARE DSP ENGINE", fill=(140, 130, 110, 200), font=font_tiny, anchor="mm")

    # Save Master Chassis
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    chassis.save(output_path, 'PNG', optimize=True)
    print(f"Master Chassis Backplate successfully generated: {output_path}")

if __name__ == '__main__':
    script_dir = os.path.dirname(os.path.abspath(__file__))
    out_master = os.path.join(script_dir, 'Assets', 'Faceplates', 'Master_Chassis_Backplate_171EasyVoice_2480x1400.png')
    badge_p    = os.path.join(script_dir, 'Assets', 'Branding', '171studio_satin_gold_badge_360x120.png')
    logo_p     = os.path.join(script_dir, 'Assets', 'Branding', '171studio_satin_gold_master_1024x1024.png')
    generate_full_master_chassis(out_master, badge_p, logo_p)

    # Also sync to shared CleanDrive assets if exists
    clean_drive_plate = os.path.abspath(os.path.join(script_dir, '..', '171CleanDrive', 'Source', 'GUI', 'Assets', 'Faceplates', 'Master_Chassis_Backplate_171EasyVoice_2480x1400.png'))
    if os.path.exists(os.path.dirname(clean_drive_plate)):
        import shutil
        shutil.copy2(out_master, clean_drive_plate)
        print(f"Synced backplate to CleanDrive assets: {clean_drive_plate}")
