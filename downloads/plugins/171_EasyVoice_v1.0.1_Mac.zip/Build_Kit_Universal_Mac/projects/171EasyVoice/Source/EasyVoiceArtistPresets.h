#pragma once

#include <vector>
#include <string>
#include <cmath>

namespace dsp171 {

// ==============================================================================
// 171EasyVoice Boutique Vocal Preset Definition
// Engineered for Studio 171 Artists based on Spectral & Envelope Auditioning
// ==============================================================================
struct EasyVoiceBoutiquePreset {
    const char* presetName;
    const char* artistName;
    const char* genreDescription;

    // 1. Vocal Noise Expander / Gate
    bool  gateEnable;
    float gateThreshDb;        // -60.0 to 0.0 dB
    float gateRangeDb;         // -48.0 to -6.0 dB

    // 2. Analog Preamp (Neve / SSL / EMI)
    bool  preampEnable;
    int   preampConsole;       // 0 = Snow (Neve 5116), 1 = SpikeProtein (SSL 4000), 2 = Maik (EMI TG12345)
    float preampDrive;         // 0.0 to 12.0
    float preampWarmth;        // 0.0 to 10.0 (Marinair LO1166 saturation)
    float preampTrimDb;        // -12.0 to +12.0 dB

    // 3. Renaissance Vocal De-Esser & De-Harsh
    bool  deEsserEnable;
    float deEsserFreqHz;       // 1000.0 to 12000.0 Hz
    float deEsserThreshDb;     // -48.0 to 0.0 dB
    float deEsserRangeDb;      // 0.0 to 24.0 dB
    int   deEsserMode;         // 0 = Split-Band, 1 = Wideband
    int   deEsserSidechainType;// 0 = Bell, 1 = High-Pass
    bool  deHarshEnable;
    float deHarshThreshDb;     // -48.0 to 0.0 dB

    // 4. SuperSolidLine 4-Band G-Series Console EQ
    bool  eqEnable;
    float hpfFreqHz;           // 16.0 to 350.0 Hz (18 dB/oct)
    float lpfFreqHz;           // 3000.0 to 22000.0 Hz (12 dB/oct)
    float lfFreqHz;            // 30.0 to 450.0 Hz
    float lfGainDb;            // -15.0 to +15.0 dB
    int   lfType;              // 0 = Shelf, 1 = Bell
    float lmfFreqHz;           // 200.0 to 2500.0 Hz
    float lmfGainDb;           // -15.0 to +15.0 dB
    float lmfQ;                // 0.5 to 2.5
    float hmfFreqHz;           // 600.0 to 7000.0 Hz
    float hmfGainDb;           // -15.0 to +15.0 dB
    float hmfQ;                // 0.5 to 2.5
    float hfFreqHz;            // 1500.0 to 16000.0 Hz
    float hfGainDb;            // -15.0 to +15.0 dB
    int   hfType;              // 0 = Shelf, 1 = Bell

    // 5. Maag Audio EQ4 Air Band
    bool  airEnable;
    float airGainDb;           // 0.0 to 12.0 dB
    int   airFreqTarget;       // 0 = 2.5kHz, 1 = 5kHz, 2 = 10kHz, 3 = 20kHz, 4 = 40kHz

    // 6. Dual-Stage Dynamics (171-2A Opto vs 171-76 FET)
    bool  optoEnable;
    float optoPeakReduction;   // 0.0 to 100.0
    float optoMakeupGain;      // 0.0 to 100.0
    float optoHiFreqAcidSC;    // 0.0 to 100.0

    bool  fetCompEnable;
    float fetInputDb;          // -60.0 to 0.0 dB
    float fetOutputDb;         // -60.0 to 0.0 dB
    float fetAttackKnob;       // 1.0 to 7.0 (1=slow ~800us, 7=fast ~20us)
    float fetReleaseKnob;      // 1.0 to 7.0 (1=slow ~1100ms, 7=fast ~50ms)
    int   fetRatio;            // 0 = 4:1, 1 = 8:1, 2 = 12:1, 3 = 20:1, 4 = All-Buttons
    int   fetRevision;         // 0 = Blackface (Rev E), 1 = Blue Stripe (Rev A)
    bool  fetSidechainHPF100;  // 100 Hz HPF sidechain filter
    float fetParallelMix;      // 0.0 to 100.0 %

    // 7. Micro-Pitch Vocal Doubler & Spatial Width
    bool  doublerEnable;
    float doublerMix;          // 0.0 to 100.0 %
    float doublerWidth;        // 0.0 to 200.0 %

    // 8. Master Output Section
    float masterTrimDb;        // -24.0 to +12.0 dB
    float globalMixPercent;    // 0.0 to 100.0 %
};

// ==============================================================================
// 10 Studio 171 Boutique Factory Presets
// ==============================================================================
inline const std::vector<EasyVoiceBoutiquePreset>& getStudio171BoutiquePresets() {
    static const std::vector<EasyVoiceBoutiquePreset> presets = {
        // ----------------------------------------------------------------------
        // 01. ADRIANO - Raw Street Velvet
        // ----------------------------------------------------------------------
        {
            "01. Adriano - Raw Street Velvet",
            "Adriano",
            "Aggressive Street Rap / Gritty Trap Velvet",
            /*gate*/ true, -44.0f, -24.0f,
            /*preamp*/ true, 0 /*Snow/Neve*/, 3.5f, 4.5f, -1.0f,
            /*deesser*/ true, 5220.0f, -22.0f, 10.0f, 0 /*Split*/, 0 /*Bell*/, true, -24.0f,
            /*eq*/ true, 80.0f, 20000.0f, 110.0f, 1.2f, 0 /*Shelf*/, 520.0f, -3.2f, 1.8f, 3200.0f, 2.5f, 1.1f, 9500.0f, 3.5f, 0 /*Shelf*/,
            /*air*/ true, 4.0f, 3 /*20kHz*/,
            /*opto*/ false, 0.0f, 0.0f, 0.0f,
            /*fet*/ true, -20.0f, -12.0f, 3.5f, 5.5f, 0 /*4:1*/, 1 /*Blue Stripe*/, true, 100.0f,
            /*doubler*/ true, 12.0f, 85.0f,
            /*master*/ -0.5f, 100.0f
        },

        // ----------------------------------------------------------------------
        // 02. CH4PO - Hyperpop In-Your-Face
        // ----------------------------------------------------------------------
        {
            "02. Ch4po - Hyperpop In-Your-Face",
            "Ch4po",
            "Upfront Hyperpop / Fast Trapcadence",
            /*gate*/ true, -48.0f, -28.0f,
            /*preamp*/ true, 1 /*SpikeProtein/SSL*/, 6.8f, 2.5f, 6.0f,
            /*deesser*/ true, 5320.0f, -24.0f, 12.0f, 0 /*Split*/, 0 /*Bell*/, true, -20.0f,
            /*eq*/ true, 85.0f, 21000.0f, 140.0f, -2.5f, 1 /*Bell*/, 245.0f, -4.5f, 1.6f, 2800.0f, 4.0f, 1.2f, 8500.0f, 5.0f, 0 /*Shelf*/,
            /*air*/ true, 5.5f, 4 /*40kHz*/,
            /*opto*/ false, 0.0f, 0.0f, 0.0f,
            /*fet*/ true, -14.0f, -10.0f, 3.0f, 6.5f, 1 /*8:1*/, 1 /*Blue Stripe*/, true, 90.0f,
            /*doubler*/ true, 22.0f, 110.0f,
            /*master*/ 0.5f, 100.0f
        },

        // ----------------------------------------------------------------------
        // 03. DANKLE - Dark Drill Iron Core
        // ----------------------------------------------------------------------
        {
            "03. Dankle - Dark Drill Iron Core",
            "Dankle",
            "Dark Acoustic Baritone Drill / Heavy Mud Tamer",
            /*gate*/ true, -45.0f, -30.0f,
            /*preamp*/ true, 0 /*Snow/Neve*/, 4.5f, 6.0f, 3.5f,
            /*deesser*/ true, 4540.0f, -20.0f, 9.0f, 0 /*Split*/, 0 /*Bell*/, false, -24.0f,
            /*eq*/ true, 105.0f, 19000.0f, 230.0f, -3.8f, 1 /*Bell*/, 480.0f, -1.8f, 1.0f, 2400.0f, 3.5f, 1.3f, 8000.0f, 3.8f, 0 /*Shelf*/,
            /*air*/ true, 4.5f, 3 /*20kHz*/,
            /*opto*/ true, 48.0f, 42.0f, 25.0f,
            /*fet*/ false, -18.0f, -12.0f, 3.0f, 5.0f, 0 /*4:1*/, 0 /*Blackface*/, true, 100.0f,
            /*doubler*/ true, 15.0f, 90.0f,
            /*master*/ -0.5f, 100.0f
        },

        // ----------------------------------------------------------------------
        // 04. IGOR - Aggressive Blue Punch
        // ----------------------------------------------------------------------
        {
            "04. Igor - Aggressive Blue Punch",
            "Igor",
            "High-Octane Modern Trap / Hard Transient Edge",
            /*gate*/ true, -42.0f, -26.0f,
            /*preamp*/ true, 1 /*SpikeProtein/SSL*/, 7.2f, 2.0f, 0.0f,
            /*deesser*/ true, 5480.0f, -25.0f, 13.0f, 0 /*Split*/, 0 /*Bell*/, true, -22.0f,
            /*eq*/ true, 75.0f, 22000.0f, 160.0f, 2.5f, 1 /*Bell*/, 560.0f, -3.0f, 1.8f, 3400.0f, 2.0f, 1.0f, 8500.0f, 4.0f, 0 /*Shelf*/,
            /*air*/ true, 3.0f, 3 /*20kHz*/,
            /*opto*/ false, 0.0f, 0.0f, 0.0f,
            /*fet*/ true, -16.0f, -11.0f, 4.0f, 6.0f, 1 /*8:1*/, 1 /*Blue Stripe*/, true, 100.0f,
            /*doubler*/ true, 10.0f, 75.0f,
            /*master*/ -0.5f, 100.0f
        },

        // ----------------------------------------------------------------------
        // 05. LELE - Dynamic Freestyle Tamer
        // ----------------------------------------------------------------------
        {
            "05. Lele - Dynamic Freestyle Tamer",
            "Lele",
            "Wide-Dynamic Freestyle / Cavity Reso Surgical Cut",
            /*gate*/ true, -40.0f, -28.0f,
            /*preamp*/ true, 0 /*Snow/Neve*/, 4.0f, 4.0f, 2.5f,
            /*deesser*/ true, 5700.0f, -26.0f, 14.0f, 0 /*Split*/, 0 /*Bell*/, true, -26.0f,
            /*eq*/ true, 85.0f, 20000.0f, 120.0f, 1.0f, 0 /*Shelf*/, 390.0f, -5.5f, 2.2f, 2200.0f, 2.8f, 1.2f, 9000.0f, 3.2f, 0 /*Shelf*/,
            /*air*/ true, 3.5f, 3 /*20kHz*/,
            /*opto*/ false, 0.0f, 0.0f, 0.0f,
            /*fet*/ true, -15.0f, -12.0f, 3.5f, 5.0f, 0 /*4:1*/, 0 /*Blackface*/, true, 95.0f,
            /*doubler*/ true, 16.0f, 95.0f,
            /*master*/ -0.2f, 100.0f
        },

        // ----------------------------------------------------------------------
        // 06. LIL KROW - Glossy Melodic Auto-Trap
        // ----------------------------------------------------------------------
        {
            "06. Lil Krow - Glossy Melodic Auto-Trap",
            "Lil Krow",
            "Glossy Emo-Trap / Microplastic Melodic Sheen",
            /*gate*/ false, -50.0f, -18.0f,
            /*preamp*/ true, 2 /*Maik/EMI*/, 5.5f, 4.0f, 8.0f,
            /*deesser*/ true, 4560.0f, -28.0f, 8.0f, 0 /*Split*/, 0 /*Bell*/, true, -24.0f,
            /*eq*/ true, 80.0f, 22000.0f, 180.0f, 1.5f, 0 /*Shelf*/, 360.0f, -3.5f, 1.6f, 3000.0f, 3.5f, 1.0f, 10000.0f, 4.8f, 0 /*Shelf*/,
            /*air*/ true, 6.0f, 3 /*20kHz*/,
            /*opto*/ true, 38.0f, 48.0f, 10.0f,
            /*fet*/ false, -18.0f, -12.0f, 3.0f, 5.0f, 0 /*4:1*/, 0 /*Blackface*/, false, 100.0f,
            /*doubler*/ true, 28.0f, 130.0f,
            /*master*/ 1.0f, 100.0f
        },

        // ----------------------------------------------------------------------
        // 07. MAURITO - Vintage Sheen Latin Flow
        // ----------------------------------------------------------------------
        {
            "07. Maurito - Vintage Sheen Latin Flow",
            "Maurito",
            "Smooth Latin Rap / Warm British Tube Velvet",
            /*gate*/ true, -46.0f, -24.0f,
            /*preamp*/ true, 2 /*Maik/EMI*/, 4.8f, 5.2f, 4.0f,
            /*deesser*/ true, 4540.0f, -22.0f, 9.0f, 0 /*Split*/, 0 /*Bell*/, true, -20.0f,
            /*eq*/ true, 80.0f, 21000.0f, 120.0f, 1.8f, 0 /*Shelf*/, 600.0f, -3.8f, 1.5f, 2600.0f, 3.0f, 1.1f, 9000.0f, 3.5f, 0 /*Shelf*/,
            /*air*/ true, 4.0f, 3 /*20kHz*/,
            /*opto*/ true, 44.0f, 38.0f, 30.0f,
            /*fet*/ false, -18.0f, -12.0f, 3.0f, 5.0f, 0 /*4:1*/, 0 /*Blackface*/, false, 100.0f,
            /*doubler*/ true, 18.0f, 100.0f,
            /*master*/ 0.0f, 100.0f
        },

        // ----------------------------------------------------------------------
        // 08. PIOTRE - Hardcore Clarity Cut
        // ----------------------------------------------------------------------
        {
            "08. Piotre - Hardcore Clarity Cut",
            "Piotre",
            "Hardcore Street Rap / Heavy 400Hz Box Notcher",
            /*gate*/ true, -45.0f, -28.0f,
            /*preamp*/ true, 0 /*Snow/Neve*/, 5.0f, 6.5f, 4.5f,
            /*deesser*/ true, 5400.0f, -24.0f, 10.0f, 0 /*Split*/, 0 /*Bell*/, true, -22.0f,
            /*eq*/ true, 75.0f, 20000.0f, 160.0f, 3.5f, 1 /*Bell*/, 400.0f, -6.0f, 2.0f, 2200.0f, 3.2f, 1.2f, 8500.0f, 4.0f, 0 /*Shelf*/,
            /*air*/ true, 4.5f, 3 /*20kHz*/,
            /*opto*/ false, 0.0f, 0.0f, 0.0f,
            /*fet*/ true, -16.0f, -11.0f, 3.0f, 6.0f, 0 /*4:1*/, 1 /*Blue Stripe*/, true, 100.0f,
            /*doubler*/ true, 14.0f, 85.0f,
            /*master*/ 0.0f, 100.0f
        },

        // ----------------------------------------------------------------------
        // 09. SKIETTO - High-Speed Silk De-Esser
        // ----------------------------------------------------------------------
        {
            "09. Skietto - High-Speed Silk De-Esser",
            "Skietto",
            "High-Speed Melodic Drill / 7.6kHz Sibilance Tamer",
            /*gate*/ true, -47.0f, -24.0f,
            /*preamp*/ true, 0 /*Snow/Neve*/, 3.0f, 6.8f, 5.0f,
            /*deesser*/ true, 7640.0f, -28.0f, 16.0f, 0 /*Split*/, 0 /*Bell*/, true, -26.0f,
            /*eq*/ true, 85.0f, 18000.0f, 130.0f, 1.5f, 0 /*Shelf*/, 200.0f, -2.5f, 1.4f, 3600.0f, 1.5f, 1.0f, 7500.0f, -1.5f, 1 /*Bell*/,
            /*air*/ true, 3.0f, 4 /*40kHz*/,
            /*opto*/ true, 42.0f, 36.0f, 50.0f,
            /*fet*/ false, -18.0f, -12.0f, 3.0f, 5.0f, 0 /*4:1*/, 0 /*Blackface*/, false, 100.0f,
            /*doubler*/ true, 20.0f, 110.0f,
            /*master*/ -0.5f, 100.0f
        },

        // ----------------------------------------------------------------------
        // 10. ZAIKO - Cloudy Drill Re-Bite
        // ----------------------------------------------------------------------
        {
            "10. Zaiko - Cloudy Drill Re-Bite",
            "Zaiko",
            "Cloudy Atmospheric Drill / Forward Presence Bite",
            /*gate*/ true, -43.0f, -26.0f,
            /*preamp*/ true, 1 /*SpikeProtein/SSL*/, 5.8f, 2.0f, 3.0f,
            /*deesser*/ true, 5480.0f, -22.0f, 8.0f, 0 /*Split*/, 0 /*Bell*/, false, -24.0f,
            /*eq*/ true, 80.0f, 21000.0f, 110.0f, 1.0f, 0 /*Shelf*/, 400.0f, -5.0f, 1.8f, 3200.0f, 4.2f, 1.2f, 9500.0f, 4.5f, 0 /*Shelf*/,
            /*air*/ true, 5.0f, 3 /*20kHz*/,
            /*opto*/ false, 0.0f, 0.0f, 0.0f,
            /*fet*/ true, -18.0f, -12.0f, 3.5f, 6.0f, 0 /*4:1*/, 1 /*Blue Stripe*/, true, 90.0f,
            /*doubler*/ true, 16.0f, 95.0f,
            /*master*/ 0.0f, 100.0f
        }
    };

    return presets;
}

} // namespace dsp171
