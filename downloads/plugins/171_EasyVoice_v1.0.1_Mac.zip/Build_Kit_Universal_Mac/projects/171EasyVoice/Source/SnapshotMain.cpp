#include <juce_gui_basics/juce_gui_basics.h>
#include "PluginProcessor.h"
#include "PluginEditor.h"

int main()
{
    juce::ScopedJuceInitialiser_GUI juceInit;

    EasyVoiceAudioProcessor processor;
    processor.prepareToPlay(48000.0, 512);

    std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
    if (editor == nullptr)
        return 1;

    auto* voiceEditor = dynamic_cast<EasyVoiceAudioProcessorEditor*>(editor.get());
    editor->setSize(1240, 700);

    // Feed synthetic audio block to generate FFT spectrum and needle deflections
    juce::AudioBuffer<float> testBuffer(2, 512);
    for (int block = 0; block < 40; ++block) {
        for (int ch = 0; ch < 2; ++ch) {
            float* w = testBuffer.getWritePointer(ch);
            for (int i = 0; i < 512; ++i) {
                float t = static_cast<float>(block * 512 + i) / 48000.0f;
                // Vocal harmonic & sibilance synthesis (180Hz fundamental, formants, 6kHz presence)
                w[i] = std::sin(2.0f * juce::MathConstants<float>::pi * 180.0f * t) * 0.45f
                     + std::sin(2.0f * juce::MathConstants<float>::pi * 540.0f * t) * 0.30f
                     + std::sin(2.0f * juce::MathConstants<float>::pi * 2200.0f * t) * 0.20f
                     + std::sin(2.0f * juce::MathConstants<float>::pi * 5800.0f * t) * 0.25f
                     + std::sin(2.0f * juce::MathConstants<float>::pi * 11000.0f * t) * 0.15f;
            }
        }
        juce::MidiBuffer midi;
        processor.processBlock(testBuffer, midi);
        if (voiceEditor != nullptr)
            voiceEditor->timerCallback();
    }

    editor->resized();

    // Pixel-perfect snapshot
    juce::Image snapshot = editor->createComponentSnapshot(editor->getLocalBounds());

    const char* paths[] = {
        R"(171EasyVoice_Live_Snapshot.png)",
        R"(..\..\plugin\171EasyVoice\171EasyVoice_Live_Snapshot.png)",
        R"(C:\Users\171Studio\.gemini\antigravity\brain\ce10cd5b-ad81-4f2a-86f8-e665784199d3\171EasyVoice_Live_Snapshot.png)"
    };

    for (const char* p : paths) {
        juce::File outFile(p);
        outFile.getParentDirectory().createDirectory();
        outFile.deleteFile();
        juce::FileOutputStream stream(outFile);
        if (stream.openedOk()) {
            juce::PNGImageFormat png;
            png.writeImageToStream(snapshot, stream);
            std::cout << "[+] Snapshot saved to: " << outFile.getFullPathName() << std::endl;
        }
    }

    return 0;
}
