#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include <dsp171/Common.h>
#include <dsp171/EasyVoiceChannelStrip.h>
#include <dsp171/LockFreeFIFO.h>
#include <vector>

struct VocalPreset {
    const char* name;
    // Expander / Gate
    bool gateEnable;
    float gateThresh;
    float gateRange;
    // Preamp
    bool preampEnable;
    int preampConsole;   // 0=Snow (Neve 5116), 1=SpikeProtein (SSL), 2=Maik (EMI TG12345)
    float preampDrive;   // 0 to 12
    float preampWarmth;  // 0 to 10
    float preampTrim;    // -12 to +12 dB
    // De-Esser
    bool deEsserEnable;
    float deEsserFreq;    // 1000 to 12000 Hz
    float deEsserThresh;  // -48 to 0 dB
    float deEsserRange;   // 0 to 24 dB
    int deEsserMode;      // 0=Split, 1=Wide
    int deEsserType;      // 0=Bell, 1=High-Pass
    // EQ
    bool eqEnable;
    float hpfFreq;        // 16 to 350 Hz
    float lpfFreq;        // 3000 to 22000 Hz
    float lfFreq;         // 30 to 450 Hz
    float lfGain;         // -15 to +15 dB
    int lfType;           // 0=Shelf, 1=Bell
    float lmfFreq;        // 200 to 2500 Hz
    float lmfGain;        // -15 to +15 dB
    float lmfQ;           // 0.5 to 2.5
    float hmfFreq;        // 600 to 7000 Hz
    float hmfGain;        // -15 to +15 dB
    float hmfQ;           // 0.5 to 2.5
    float hfFreq;         // 1500 to 16000 Hz
    float hfGain;         // -15 to +15 dB
    int hfType;           // 0=Shelf, 1=Bell
    // Air & De-Harsh
    bool airEnable;
    float airGain;        // 0 to 12 dB
    int airFreq;          // 0=2.5k, 1=5k, 2=10k, 3=20k, 4=40k
    bool deHarshEnable;
    float deHarshThresh;  // -48 to 0 dB
    // Dual Dynamics
    bool optoEnable;
    float optoPeakRed;    // 0 to 100
    float optoGain;       // 0 to 100
    float optoHiFreq;     // 0 to 100
    bool compEnable;
    float compInput;      // -60 to 0 dB
    float compOutput;     // -60 to 0 dB
    float compAttack;     // 1 to 7
    float compRelease;    // 1 to 7
    int compRatio;        // 0=4:1, 1=8:1, 2=12:1, 3=20:1, 4=AllButtons
    int compRev;          // 0=Blackface, 1=BlueStripe
    bool compSCFilter;    // 100 Hz HPF sidechain
    float compMix;        // 0 to 100 %
    // Doubler
    bool doublerEnable;
    float doublerMix;     // 0 to 100 %
    float doublerWidth;   // 0 to 150 %
    // Master
    float masterTrim;     // -24 to +12 dB
    float globalMix;      // 0 to 100 %
};

class EasyVoiceAudioProcessor : public juce::AudioProcessor {
public:
    EasyVoiceAudioProcessor();
    ~EasyVoiceAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;

    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "171EasyVoice"; }

    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int index, const juce::String& newName) override;

    juce::AudioProcessorParameter* getBypassParameter() const override {
        return apvts.getParameter("bypass");
    }

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }

    // Telemetry for 60 FPS Visual Metering
    float getExpanderGR_dB() const noexcept { return expanderGR; }
    float getDeEsserGR_dB() const noexcept { return deEsserGR; }
    float getDeHarshGR_dB() const noexcept { return deHarshGR; }
    float getOptoGR_dB() const noexcept { return optoGR; }
    float getCompressorGR_dB() const noexcept { return compressorGR; }
    float getInputLUFS() const noexcept { return inputLUFS; }
    float getOutputLUFS() const noexcept { return outputLUFS; }
    float getAppliedAutoGainDb() const noexcept { return autoGainDb; }
    float getInputMeter() const noexcept { return inputMeter; }
    float getOutputMeter() const noexcept { return outputMeter; }

    // Lock-Free FIFO for FFT Spectral Visualizer (Agente 21)
    dsp171::LockFreeFIFO<float, 4096>& getFftFIFO() noexcept { return fftFIFO; }

    static const std::vector<VocalPreset>& getFactoryPresets();

private:
    juce::AudioProcessorValueTreeState apvts;
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    void updateDSPParameters() noexcept;

    dsp171::EasyVoiceChannelStrip channelStrip;
    dsp171::LockFreeFIFO<float, 4096> fftFIFO;

    int currentProgramIndex = 0;

    std::atomic<float> expanderGR{ 0.0f };
    std::atomic<float> deEsserGR{ 0.0f };
    std::atomic<float> deHarshGR{ 0.0f };
    std::atomic<float> optoGR{ 0.0f };
    std::atomic<float> compressorGR{ 0.0f };
    std::atomic<float> inputLUFS{ -70.0f };
    std::atomic<float> outputLUFS{ -70.0f };
    std::atomic<float> autoGainDb{ 0.0f };
    std::atomic<float> inputMeter{ 0.0f };
    std::atomic<float> outputMeter{ 0.0f };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(EasyVoiceAudioProcessor)
};
