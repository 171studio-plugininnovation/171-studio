#include "PluginProcessor.h"
#include "PluginEditor.h"

EasyVoiceAudioProcessorEditor::EasyVoiceAudioProcessorEditor(EasyVoiceAudioProcessor& p)
    : AudioProcessorEditor(&p), audioProcessor(p)
{
    // ==============================================================================
    // 1. CARICAMENTO DEL BACKPLATE CHASSIS MASTER PULITO E DEGLI ASSET CONDIVISI
    // ==============================================================================
    masterBackplateImg = juce::ImageCache::getFromMemory(BinaryData::Master_Chassis_Backplate_171EasyVoice_2480x1400_png,
                                                         BinaryData::Master_Chassis_Backplate_171EasyVoice_2480x1400_pngSize);

    btnAmberLitImg     = juce::ImageCache::getFromMemory(BinaryData::Button_Console_Square_Blank_Amber_Lit_ON_128x128_png,
                                                         BinaryData::Button_Console_Square_Blank_Amber_Lit_ON_128x128_pngSize);
    btnDarkUnlitImg    = juce::ImageCache::getFromMemory(BinaryData::Button_Console_Square_Blank_Dark_Unlit_OFF_128x128_png,
                                                         BinaryData::Button_Console_Square_Blank_Dark_Unlit_OFF_128x128_pngSize);
    swBypassActiveImg  = juce::ImageCache::getFromMemory(BinaryData::sw_bypass_active_png,
                                                         BinaryData::sw_bypass_active_pngSize);
    swBypassEngagedImg = juce::ImageCache::getFromMemory(BinaryData::sw_bypass_engaged_png,
                                                         BinaryData::sw_bypass_engaged_pngSize);
    optoCellCanisterImg= juce::ImageCache::getFromMemory(BinaryData::OptoCell_T4B_171AudioLabs_Canister_128x128_png,
                                                         BinaryData::OptoCell_T4B_171AudioLabs_Canister_128x128_pngSize);

    // ==============================================================================
    // 2. CONFIGURAZIONE LOOKANDFEEL PER I KNOB WAVES REVERSE-ENGINEERED
    // ==============================================================================
    neveDriveLaf.setFilmstrip(juce::ImageCache::getFromMemory(BinaryData::knob_neve_drive_71f_png, BinaryData::knob_neve_drive_71f_pngSize), 71, juce::Colour(0xffff2030));
    neveVcaLaf.setFilmstrip(juce::ImageCache::getFromMemory(BinaryData::knob_neve_vca_51f_png, BinaryData::knob_neve_vca_51f_pngSize), 51, juce::Colour(0xffc5a059));
    
    sslLfLaf.setFilmstrip(juce::ImageCache::getFromMemory(BinaryData::knob_ssl_lf_101f_png, BinaryData::knob_ssl_lf_101f_pngSize), 101, juce::Colour(0xffef4444));
    sslLmfLaf.setFilmstrip(juce::ImageCache::getFromMemory(BinaryData::knob_ssl_lmf_101f_png, BinaryData::knob_ssl_lmf_101f_pngSize), 101, juce::Colour(0xff3b82f6));
    sslHmfLaf.setFilmstrip(juce::ImageCache::getFromMemory(BinaryData::knob_ssl_hmf_101f_png, BinaryData::knob_ssl_hmf_101f_pngSize), 101, juce::Colour(0xff22c55e));
    sslHfLaf.setFilmstrip(juce::ImageCache::getFromMemory(BinaryData::knob_ssl_hf_101f_png, BinaryData::knob_ssl_hf_101f_pngSize), 101, juce::Colour(0xfff43f5e));
    sslHpfLaf.setFilmstrip(juce::ImageCache::getFromMemory(BinaryData::knob_ssl_hpf_101f_png, BinaryData::knob_ssl_hpf_101f_pngSize), 101, juce::Colour(0xff94a3b8));
    
    rdeesserFreqLaf.setFilmstrip(juce::ImageCache::getFromMemory(BinaryData::knob_rdeesser_freq_87f_png, BinaryData::knob_rdeesser_freq_87f_pngSize), 87, juce::Colour(0xff38bdf8));
    la2aBakeliteLaf.setFilmstrip(juce::ImageCache::getFromMemory(BinaryData::knob_la2a_bakelite_69f_png, BinaryData::knob_la2a_bakelite_69f_pngSize), 69, juce::Colour(0xff181818));
    cla76LargeLaf.setFilmstrip(juce::ImageCache::getFromMemory(BinaryData::knob_1176_large_69f_png, BinaryData::knob_1176_large_69f_pngSize), 69, juce::Colour(0xffcbd5e1));
    cla76SmallLaf.setFilmstrip(juce::ImageCache::getFromMemory(BinaryData::knob_1176_small_51f_png, BinaryData::knob_1176_small_51f_pngSize), 51, juce::Colour(0xffcbd5e1));

    // ==============================================================================
    // 3. CREAZIONE HEADER & MASTER CONTROLS
    // ==============================================================================
    presetBox.setLookAndFeel(&comboBoxLookAndFeel);
    presetBox.setTextWhenNothingSelected("Select Factory Preset...");
    for (int i = 0; i < audioProcessor.getNumPrograms(); ++i) {
        presetBox.addItem(audioProcessor.getProgramName(i), i + 1);
    }
    presetBox.setSelectedId(audioProcessor.getCurrentProgram() + 1, juce::dontSendNotification);
    presetBox.addListener(this);
    addAndMakeVisible(presetBox);

    prevPresetBtn = std::make_unique<gui171::BoutiqueStepperButton>(gui171::BoutiqueStepperButton::Direction::Previous);
    prevPresetBtn->setOnClick([this]() {
        int cur = presetBox.getSelectedId() - 1;
        int num = audioProcessor.getNumPrograms();
        if (num > 0) {
            int prev = (cur - 1 + num) % num;
            presetBox.setSelectedId(prev + 1, juce::sendNotification);
        }
    });
    addAndMakeVisible(*prevPresetBtn);

    nextPresetBtn = std::make_unique<gui171::BoutiqueStepperButton>(gui171::BoutiqueStepperButton::Direction::Next);
    nextPresetBtn->setOnClick([this]() {
        int cur = presetBox.getSelectedId() - 1;
        int num = audioProcessor.getNumPrograms();
        if (num > 0) {
            int next = (cur + 1) % num;
            presetBox.setSelectedId(next + 1, juce::sendNotification);
        }
    });
    addAndMakeVisible(*nextPresetBtn);

    bypassModule = std::make_unique<gui171::HeavyDutyBypassModule>(swBypassActiveImg, swBypassEngagedImg);
    addAndMakeVisible(*bypassModule);

    autoGainButton = std::make_unique<gui171::SquareConsoleButton>("SMART GAIN", "OFF", "ON", btnAmberLitImg, btnDarkUnlitImg);
    addAndMakeVisible(*autoGainButton);

    deltaListenButton = std::make_unique<gui171::SquareConsoleButton>("DELTA AUDITION", "OFF", "ON", btnAmberLitImg, btnDarkUnlitImg);
    addAndMakeVisible(*deltaListenButton);

    // ==============================================================================
    // 4. PULSANTI CONSOLE DI ATTIVAZIONE SEZIONE (AMBRA LIT / DARK UNLIT)
    // ==============================================================================
    gateSwitch    = std::make_unique<gui171::SquareConsoleButton>("GATE",      "OFF", "IN", btnAmberLitImg, btnDarkUnlitImg);
    preampSwitch  = std::make_unique<gui171::SquareConsoleButton>("PREAMP",    "OFF", "IN", btnAmberLitImg, btnDarkUnlitImg);
    deEsserSwitch = std::make_unique<gui171::SquareConsoleButton>("DE-ESS",    "OFF", "IN", btnAmberLitImg, btnDarkUnlitImg);
    airSwitch     = std::make_unique<gui171::SquareConsoleButton>("AIR BAND",  "OFF", "IN", btnAmberLitImg, btnDarkUnlitImg);
    eqSwitch      = std::make_unique<gui171::SquareConsoleButton>("SuperSolidLine", "OFF", "IN", btnAmberLitImg, btnDarkUnlitImg);
    optoSwitch    = std::make_unique<gui171::SquareConsoleButton>("171-2A",    "OFF", "IN", btnAmberLitImg, btnDarkUnlitImg);
    compSwitch    = std::make_unique<gui171::SquareConsoleButton>("171-76",    "OFF", "IN", btnAmberLitImg, btnDarkUnlitImg);
    doublerSwitch = std::make_unique<gui171::SquareConsoleButton>("DOUBLER",   "OFF", "IN", btnAmberLitImg, btnDarkUnlitImg);

    addAndMakeVisible(*gateSwitch);
    addAndMakeVisible(*preampSwitch);
    addAndMakeVisible(*deEsserSwitch);
    addAndMakeVisible(*airSwitch);
    addAndMakeVisible(*eqSwitch);
    addAndMakeVisible(*optoSwitch);
    addAndMakeVisible(*compSwitch);
    addAndMakeVisible(*doublerSwitch);

    // ==============================================================================
    // 5. BAIA 1: 171 NLS BRITISH PREAMP (NEVE 5116 CLASS-A)
    // ==============================================================================
    consolePushBank = std::make_unique<gui171::VintageConsolePushBank>();
    auto* preConsoleParam = audioProcessor.getAPVTS().getRawParameterValue("preampConsole");
    if (preConsoleParam != nullptr) {
        consolePushBank->setSelectedConsole(static_cast<int>(preConsoleParam->load()), juce::dontSendNotification);
    }
    consolePushBank->setOnSelectionChanged([this](int consoleIdx) {
        if (auto* param = audioProcessor.getAPVTS().getParameter("preampConsole")) {
            param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(consoleIdx)));
        }
    });
    addAndMakeVisible(*consolePushBank);

    gateThreshKnob = std::make_unique<gui171::AnalogStyledKnob>("GATE THRESH", juce::Colour(0xff60a5fa), juce::Image(),
                                                               gui171::AnalogStyledKnob::ValueFormat::Decibels, -60.0f, 0.0f, -42.0f);
    gateRangeKnob  = std::make_unique<gui171::AnalogStyledKnob>("GATE RANGE",  juce::Colour(0xff60a5fa), juce::Image(),
                                                               gui171::AnalogStyledKnob::ValueFormat::Decibels, -48.0f, -6.0f, -24.0f);

    preampDriveKnob  = std::make_unique<gui171::AnalogStyledKnob>("DRIVE", juce::Colour(0xffff2030), juce::Image(),
                                                                 gui171::AnalogStyledKnob::ValueFormat::Decibels, 0.0f, 12.0f, 4.0f);
    preampWarmthKnob = std::make_unique<gui171::AnalogStyledKnob>("WARMTH",     juce::Colour(0xffff9500), juce::Image(),
                                                                 gui171::AnalogStyledKnob::ValueFormat::Decimal, 0.0f, 10.0f, 3.0f);
    preampTrimKnob   = std::make_unique<gui171::AnalogStyledKnob>("PRE TRIM",   juce::Colour(0xffc5a059), juce::Image(),
                                                                 gui171::AnalogStyledKnob::ValueFormat::Decibels, -12.0f, 12.0f, 0.0f);

    preampDriveKnob->setCustomLookAndFeel(&neveDriveLaf);
    gateThreshKnob->setCustomLookAndFeel(&neveVcaLaf);
    gateRangeKnob->setCustomLookAndFeel(&neveVcaLaf);
    preampWarmthKnob->setCustomLookAndFeel(&neveVcaLaf);
    preampTrimKnob->setCustomLookAndFeel(&neveVcaLaf);

    addAndMakeVisible(*gateThreshKnob);
    addAndMakeVisible(*gateRangeKnob);
    addAndMakeVisible(*preampDriveKnob);
    addAndMakeVisible(*preampWarmthKnob);
    addAndMakeVisible(*preampTrimKnob);

    // ==============================================================================
    // 6. BAIA 2: 171 R-DEESSER LABS & MAAG AIR
    // ==============================================================================
    deEsserFreqKnob   = std::make_unique<gui171::AnalogStyledKnob>("DE-ESS FREQ", juce::Colour(0xff00d5e5), juce::Image(),
                                                                  gui171::AnalogStyledKnob::ValueFormat::Hertz, 1000.0f, 12000.0f, 5800.0f);
    deEsserThreshKnob = std::make_unique<gui171::AnalogStyledKnob>("THRESHOLD",   juce::Colour(0xff00d5e5), juce::Image(),
                                                                  gui171::AnalogStyledKnob::ValueFormat::Decibels, -48.0f, 0.0f, -20.0f);
    deEsserRangeKnob  = std::make_unique<gui171::AnalogStyledKnob>("RANGE",       juce::Colour(0xff00d5e5), juce::Image(),
                                                                  gui171::AnalogStyledKnob::ValueFormat::Decibels, 0.0f, 24.0f, 12.0f);

    deEsserFreqKnob->setCustomLookAndFeel(&rdeesserFreqLaf);
    deEsserThreshKnob->setCustomLookAndFeel(&neveVcaLaf);
    deEsserRangeKnob->setCustomLookAndFeel(&neveVcaLaf);

    deEsserModeBox.setLookAndFeel(&comboBoxLookAndFeel);
    deEsserModeBox.addItemList({ "Split-Band", "Wideband" }, 1);
    addAndMakeVisible(deEsserModeBox);

    deEsserTypeBox.setLookAndFeel(&comboBoxLookAndFeel);
    deEsserTypeBox.addItemList({ "Bell SC", "High-Pass SC" }, 1);
    addAndMakeVisible(deEsserTypeBox);

    deEsserListenBox.setLookAndFeel(&comboBoxLookAndFeel);
    deEsserListenBox.addItemList({ "Audio", "Sidechain", "Delta" }, 1);
    addAndMakeVisible(deEsserListenBox);

    airGainKnob = std::make_unique<gui171::AnalogStyledKnob>("AIR GAIN", juce::Colour(0xff00d5e5), juce::Image(),
                                                            gui171::AnalogStyledKnob::ValueFormat::Decibels, 0.0f, 12.0f, 3.0f);
    airGainKnob->setCustomLookAndFeel(&neveDriveLaf);

    airFreqBox.setLookAndFeel(&comboBoxLookAndFeel);
    airFreqBox.addItemList({ "2.5 kHz", "5 kHz", "10 kHz", "20 kHz", "40 kHz" }, 1);
    addAndMakeVisible(airFreqBox);

    deHarshThreshKnob = std::make_unique<gui171::AnalogStyledKnob>("DE-HARSH", juce::Colour(0xff00d5e5), juce::Image(),
                                                                  gui171::AnalogStyledKnob::ValueFormat::Decibels, -48.0f, 0.0f, -24.0f);
    deHarshThreshKnob->setCustomLookAndFeel(&neveVcaLaf);

    addAndMakeVisible(*deEsserFreqKnob);
    addAndMakeVisible(*deEsserThreshKnob);
    addAndMakeVisible(*deEsserRangeKnob);
    addAndMakeVisible(*airGainKnob);
    addAndMakeVisible(*deHarshThreshKnob);

    // ==============================================================================
    // 7. BAIA 3: 171 SSL 242 OXFORD CONSOLE EQ & CRT SPECTRUM
    // ==============================================================================
    hpfKnob = std::make_unique<gui171::AnalogStyledKnob>("HPF", juce::Colour(0xffcbd5e1), juce::Image(),
                                                        gui171::AnalogStyledKnob::ValueFormat::Hertz, 16.0f, 350.0f, 16.0f);
    lpfKnob = std::make_unique<gui171::AnalogStyledKnob>("LPF", juce::Colour(0xffcbd5e1), juce::Image(),
                                                        gui171::AnalogStyledKnob::ValueFormat::Hertz, 3000.0f, 22000.0f, 22000.0f);
    hpfKnob->setCustomLookAndFeel(&sslHpfLaf);
    lpfKnob->setCustomLookAndFeel(&sslHpfLaf);

    // HF Band (Rosso / Magenta)
    hfFreqKnob = std::make_unique<gui171::AnalogStyledKnob>("FREQ", juce::Colour(0xfff43f5e), juce::Image(),
                                                           gui171::AnalogStyledKnob::ValueFormat::Hertz, 1500.0f, 16000.0f, 8000.0f);
    hfGainKnob = std::make_unique<gui171::AnalogStyledKnob>("GAIN", juce::Colour(0xfff43f5e), juce::Image(),
                                                           gui171::AnalogStyledKnob::ValueFormat::Decibels, -15.0f, 15.0f, 0.0f);
    hfFreqKnob->setCustomLookAndFeel(&sslHfLaf);
    hfGainKnob->setCustomLookAndFeel(&sslHfLaf);

    hfBellToggle.setColour(juce::ToggleButton::textColourId, juce::Colour(0xfff43f5e));
    addAndMakeVisible(hfBellToggle);

    // HMF Band (Verde)
    hmfFreqKnob = std::make_unique<gui171::AnalogStyledKnob>("FREQ", juce::Colour(0xff22c55e), juce::Image(),
                                                            gui171::AnalogStyledKnob::ValueFormat::Hertz, 600.0f, 7000.0f, 2400.0f);
    hmfGainKnob = std::make_unique<gui171::AnalogStyledKnob>("GAIN", juce::Colour(0xff22c55e), juce::Image(),
                                                            gui171::AnalogStyledKnob::ValueFormat::Decibels, -15.0f, 15.0f, 0.0f);
    hmfQKnob    = std::make_unique<gui171::AnalogStyledKnob>("Q",    juce::Colour(0xff22c55e), juce::Image(),
                                                            gui171::AnalogStyledKnob::ValueFormat::Decimal, 0.5f, 2.5f, 1.0f);
    hmfFreqKnob->setCustomLookAndFeel(&sslHmfLaf);
    hmfGainKnob->setCustomLookAndFeel(&sslHmfLaf);
    hmfQKnob->setCustomLookAndFeel(&sslHmfLaf);

    // LMF Band (Blu)
    lmfFreqKnob = std::make_unique<gui171::AnalogStyledKnob>("FREQ", juce::Colour(0xff3b82f6), juce::Image(),
                                                            gui171::AnalogStyledKnob::ValueFormat::Hertz, 200.0f, 2500.0f, 450.0f);
    lmfGainKnob = std::make_unique<gui171::AnalogStyledKnob>("GAIN", juce::Colour(0xff3b82f6), juce::Image(),
                                                            gui171::AnalogStyledKnob::ValueFormat::Decibels, -15.0f, 15.0f, 0.0f);
    lmfQKnob    = std::make_unique<gui171::AnalogStyledKnob>("Q",    juce::Colour(0xff3b82f6), juce::Image(),
                                                            gui171::AnalogStyledKnob::ValueFormat::Decimal, 0.5f, 2.5f, 1.0f);
    lmfFreqKnob->setCustomLookAndFeel(&sslLmfLaf);
    lmfGainKnob->setCustomLookAndFeel(&sslLmfLaf);
    lmfQKnob->setCustomLookAndFeel(&sslLmfLaf);

    // LF Band (Rosso)
    lfFreqKnob = std::make_unique<gui171::AnalogStyledKnob>("FREQ", juce::Colour(0xffef4444), juce::Image(),
                                                           gui171::AnalogStyledKnob::ValueFormat::Hertz, 30.0f, 450.0f, 80.0f);
    lfGainKnob = std::make_unique<gui171::AnalogStyledKnob>("GAIN", juce::Colour(0xffef4444), juce::Image(),
                                                           gui171::AnalogStyledKnob::ValueFormat::Decibels, -15.0f, 15.0f, 0.0f);
    lfFreqKnob->setCustomLookAndFeel(&sslLfLaf);
    lfGainKnob->setCustomLookAndFeel(&sslLfLaf);

    lfBellToggle.setColour(juce::ToggleButton::textColourId, juce::Colour(0xffef4444));
    addAndMakeVisible(lfBellToggle);

    addAndMakeVisible(*hpfKnob);
    addAndMakeVisible(*lpfKnob);
    addAndMakeVisible(*hfFreqKnob);
    addAndMakeVisible(*hfGainKnob);
    addAndMakeVisible(*hmfFreqKnob);
    addAndMakeVisible(*hmfGainKnob);
    addAndMakeVisible(*hmfQKnob);
    addAndMakeVisible(*lmfFreqKnob);
    addAndMakeVisible(*lmfGainKnob);
    addAndMakeVisible(*lmfQKnob);
    addAndMakeVisible(*lfFreqKnob);
    addAndMakeVisible(*lfGainKnob);

    // ==============================================================================
    // 8. BAIA 4: 171 CLA DUAL DYNAMICS (TELETRONIX LA-2A + UREI 1176) & SERUMV METER
    // ==============================================================================
    optoPeakRedKnob = std::make_unique<gui171::AnalogStyledKnob>("PEAK REDUCT", juce::Colour(0xfffbbf24), juce::Image(),
                                                                gui171::AnalogStyledKnob::ValueFormat::Percentage, 0.0f, 100.0f, 35.0f);
    optoGainKnob    = std::make_unique<gui171::AnalogStyledKnob>("OUTPUT GAIN", juce::Colour(0xfffbbf24), juce::Image(),
                                                                gui171::AnalogStyledKnob::ValueFormat::Percentage, 0.0f, 100.0f, 40.0f);
    optoHiFreqKnob  = std::make_unique<gui171::AnalogStyledKnob>("HF / ACID", juce::Colour(0xfffbbf24), juce::Image(),
                                                                gui171::AnalogStyledKnob::ValueFormat::Percentage, 0.0f, 100.0f, 0.0f);
    optoPeakRedKnob->setCustomLookAndFeel(&la2aBakeliteLaf);
    optoGainKnob->setCustomLookAndFeel(&la2aBakeliteLaf);
    optoHiFreqKnob->setCustomLookAndFeel(&la2aBakeliteLaf);

    compInputKnob   = std::make_unique<gui171::AnalogStyledKnob>("INPUT",      juce::Colour(0xffcbd5e1), juce::Image(),
                                                                gui171::AnalogStyledKnob::ValueFormat::Decimal, 0.0f, 40.0f, 18.0f);
    compOutputKnob  = std::make_unique<gui171::AnalogStyledKnob>("OUTPUT",     juce::Colour(0xffcbd5e1), juce::Image(),
                                                                gui171::AnalogStyledKnob::ValueFormat::Decimal, 0.0f, 40.0f, 18.0f);
    compAttackKnob  = std::make_unique<gui171::AnalogStyledKnob>("ATTACK",     juce::Colour(0xffcbd5e1), juce::Image(),
                                                                gui171::AnalogStyledKnob::ValueFormat::Decimal, 1.0f, 7.0f, 3.0f);
    compReleaseKnob = std::make_unique<gui171::AnalogStyledKnob>("RELEASE",    juce::Colour(0xffcbd5e1), juce::Image(),
                                                                gui171::AnalogStyledKnob::ValueFormat::Decimal, 1.0f, 7.0f, 5.0f);

    compInputKnob->setCustomLookAndFeel(&cla76LargeLaf);
    compOutputKnob->setCustomLookAndFeel(&cla76LargeLaf);
    compAttackKnob->setCustomLookAndFeel(&cla76SmallLaf);
    compReleaseKnob->setCustomLookAndFeel(&cla76SmallLaf);

    compRatioPushBank = std::make_unique<gui171::VintageMechanicalPushBank>(
        juce::StringArray{ "4:1", "8:1", "12:1", "20:1", "ALL" });
    auto* ratioParam = audioProcessor.getAPVTS().getRawParameterValue("compRatio");
    if (ratioParam != nullptr) {
        compRatioPushBank->setSelectedRatio(static_cast<int>(ratioParam->load()), juce::dontSendNotification);
    }
    compRatioPushBank->setOnSelectionChanged([this](int ratioIdx) {
        if (auto* param = audioProcessor.getAPVTS().getParameter("compRatio")) {
            param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(ratioIdx)));
        }
        compRatioBox.setSelectedId(ratioIdx + 1, juce::dontSendNotification);
    });
    addAndMakeVisible(*compRatioPushBank);

    compSCFilterSwitch = std::make_unique<gui171::SquareConsoleButton>("SC 100Hz", "OFF", "ON", btnAmberLitImg, btnDarkUnlitImg);
    addAndMakeVisible(*compSCFilterSwitch);

    compRatioBox.setLookAndFeel(&comboBoxLookAndFeel);
    compRatioBox.addItemList({ "Ratio 4:1", "Ratio 8:1", "Ratio 12:1", "Ratio 20:1", "ALL-IN (British)" }, 1);
    addChildComponent(compRatioBox); // synchronized in background

    compRevBox.setLookAndFeel(&comboBoxLookAndFeel);
    compRevBox.addItemList({ "171-76 Rev E (Blackface)", "171-76 Rev A (Blue Stripe)" }, 1);
    addAndMakeVisible(compRevBox);

    compMixKnob     = std::make_unique<gui171::AnalogStyledKnob>("COMP MIX",   juce::Colour(0xfffbbf24), juce::Image(),
                                                                gui171::AnalogStyledKnob::ValueFormat::Percentage, 0.0f, 1.0f, 1.0f);
    compMixKnob->setCustomLookAndFeel(&neveVcaLaf);

    doublerMixKnob  = std::make_unique<gui171::AnalogStyledKnob>("DOUBLER",    juce::Colour(0xff60a5fa), juce::Image(),
                                                                gui171::AnalogStyledKnob::ValueFormat::Percentage, 0.0f, 1.0f, 0.0f);
    doublerWidthKnob= std::make_unique<gui171::AnalogStyledKnob>("WIDTH",      juce::Colour(0xff60a5fa), juce::Image(),
                                                                gui171::AnalogStyledKnob::ValueFormat::Percentage, 0.0f, 2.0f, 1.0f);
    doublerMixKnob->setCustomLookAndFeel(&neveVcaLaf);
    doublerWidthKnob->setCustomLookAndFeel(&neveVcaLaf);

    // Integrazione Componente SerumV VU & Gain Reduction Meter
    serumVMeter.setMeterMode(dsp171::MeterMode::GainReduction);
    addAndMakeVisible(serumVMeter);

    addAndMakeVisible(*optoPeakRedKnob);
    addAndMakeVisible(*optoGainKnob);
    addAndMakeVisible(*optoHiFreqKnob);
    addAndMakeVisible(*compInputKnob);
    addAndMakeVisible(*compOutputKnob);
    addAndMakeVisible(*compAttackKnob);
    addAndMakeVisible(*compReleaseKnob);
    addAndMakeVisible(*compMixKnob);
    addAndMakeVisible(*doublerMixKnob);
    addAndMakeVisible(*doublerWidthKnob);

    // ==============================================================================
    // 9. MASTER SECTION
    // ==============================================================================
    masterTrimKnob = std::make_unique<gui171::AnalogStyledKnob>("MASTER TRIM", juce::Colour(0xffd4af37), juce::Image(),
                                                               gui171::AnalogStyledKnob::ValueFormat::Decibels, -18.0f, 18.0f, 0.0f);
    globalMixKnob  = std::make_unique<gui171::AnalogStyledKnob>("GLOBAL MIX",  juce::Colour(0xffd4af37), juce::Image(),
                                                               gui171::AnalogStyledKnob::ValueFormat::Percentage, 0.0f, 1.0f, 1.0f);
    masterTrimKnob->setCustomLookAndFeel(&neveVcaLaf);
    globalMixKnob->setCustomLookAndFeel(&neveVcaLaf);

    addAndMakeVisible(*masterTrimKnob);
    addAndMakeVisible(*globalMixKnob);

    // ==============================================================================
    // 10. ATTACHMENTS APVTS
    // ==============================================================================
    auto& apvts = audioProcessor.getAPVTS();

    buttonAttachments.push_back(std::make_unique<ButtonAttachment>(apvts, "bypass", bypassModule->getButton()));
    buttonAttachments.push_back(std::make_unique<ButtonAttachment>(apvts, "autoGain", autoGainButton->getButton()));
    buttonAttachments.push_back(std::make_unique<ButtonAttachment>(apvts, "deltaAudition", deltaListenButton->getButton()));

    buttonAttachments.push_back(std::make_unique<ButtonAttachment>(apvts, "gateEnable", gateSwitch->getButton()));
    buttonAttachments.push_back(std::make_unique<ButtonAttachment>(apvts, "preampEnable", preampSwitch->getButton()));
    buttonAttachments.push_back(std::make_unique<ButtonAttachment>(apvts, "deEsserEnable", deEsserSwitch->getButton()));
    buttonAttachments.push_back(std::make_unique<ButtonAttachment>(apvts, "airEnable", airSwitch->getButton()));
    buttonAttachments.push_back(std::make_unique<ButtonAttachment>(apvts, "eqEnable", eqSwitch->getButton()));
    buttonAttachments.push_back(std::make_unique<ButtonAttachment>(apvts, "optoEnable", optoSwitch->getButton()));
    buttonAttachments.push_back(std::make_unique<ButtonAttachment>(apvts, "compEnable", compSwitch->getButton()));

    optoSwitch->getButton().onClick = [this]() {
        if (optoSwitch->getButton().getToggleState()) {
            compSwitch->getButton().setToggleState(false, juce::sendNotification);
        }
    };
    compSwitch->getButton().onClick = [this]() {
        if (compSwitch->getButton().getToggleState()) {
            optoSwitch->getButton().setToggleState(false, juce::sendNotification);
        }
    };
    buttonAttachments.push_back(std::make_unique<ButtonAttachment>(apvts, "compSCFilter", compSCFilterSwitch->getButton()));
    buttonAttachments.push_back(std::make_unique<ButtonAttachment>(apvts, "doublerEnable", doublerSwitch->getButton()));

    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "gateThresh", gateThreshKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "gateRange", gateRangeKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "preampDrive", preampDriveKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "preampWarmth", preampWarmthKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "preampTrim", preampTrimKnob->getSlider()));

    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "deEsserFreq", deEsserFreqKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "deEsserThresh", deEsserThreshKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "deEsserRange", deEsserRangeKnob->getSlider()));
    comboAttachments.push_back(std::make_unique<ComboBoxAttachment>(apvts, "deEsserMode", deEsserModeBox));
    comboAttachments.push_back(std::make_unique<ComboBoxAttachment>(apvts, "deEsserType", deEsserTypeBox));
    comboAttachments.push_back(std::make_unique<ComboBoxAttachment>(apvts, "deEsserListen", deEsserListenBox));

    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "airGain", airGainKnob->getSlider()));
    comboAttachments.push_back(std::make_unique<ComboBoxAttachment>(apvts, "airFreq", airFreqBox));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "deHarshThresh", deHarshThreshKnob->getSlider()));

    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "hpfFreq", hpfKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "lpfFreq", lpfKnob->getSlider()));

    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "hfFreq", hfFreqKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "hfGain", hfGainKnob->getSlider()));
    buttonAttachments.push_back(std::make_unique<ButtonAttachment>(apvts, "hfType", hfBellToggle));

    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "hmfFreq", hmfFreqKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "hmfGain", hmfGainKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "hmfQ", hmfQKnob->getSlider()));

    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "lmfFreq", lmfFreqKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "lmfGain", lmfGainKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "lmfQ", lmfQKnob->getSlider()));

    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "lfFreq", lfFreqKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "lfGain", lfGainKnob->getSlider()));
    buttonAttachments.push_back(std::make_unique<ButtonAttachment>(apvts, "lfType", lfBellToggle));

    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "optoPeakRed", optoPeakRedKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "optoGain", optoGainKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "optoHiFreq", optoHiFreqKnob->getSlider()));

    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "compInput", compInputKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "compOutput", compOutputKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "compAttack", compAttackKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "compRelease", compReleaseKnob->getSlider()));
    comboAttachments.push_back(std::make_unique<ComboBoxAttachment>(apvts, "compRatio", compRatioBox));
    comboAttachments.push_back(std::make_unique<ComboBoxAttachment>(apvts, "compRev", compRevBox));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "compMix", compMixKnob->getSlider()));

    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "doublerMix", doublerMixKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "doublerWidth", doublerWidthKnob->getSlider()));

    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "masterTrim", masterTrimKnob->getSlider()));
    sliderAttachments.push_back(std::make_unique<SliderAttachment>(apvts, "globalMix", globalMixKnob->getSlider()));

    // ==============================================================================
    // 11. SETUP DIMENSIONI MASTER & RESIZABLE DI DEFAULT & 60 FPS TIMER
    // ==============================================================================
    setResizable(true, true);
    setResizeLimits(930, 525, 2480, 1400);
    getConstrainer()->setFixedAspectRatio(1240.0 / 700.0);
    setSize(1240, 700);
    startTimerHz(60);
}

EasyVoiceAudioProcessorEditor::~EasyVoiceAudioProcessorEditor() {
    stopTimer();
    presetBox.setLookAndFeel(nullptr);
    presetBox.removeListener(this);
    deEsserModeBox.setLookAndFeel(nullptr);
    deEsserTypeBox.setLookAndFeel(nullptr);
    deEsserListenBox.setLookAndFeel(nullptr);
    airFreqBox.setLookAndFeel(nullptr);
    compRatioBox.setLookAndFeel(nullptr);
    compRevBox.setLookAndFeel(nullptr);

    // Reset LookAndFeels dei knob
    preampDriveKnob->setCustomLookAndFeel(nullptr);
    gateThreshKnob->setCustomLookAndFeel(nullptr);
    gateRangeKnob->setCustomLookAndFeel(nullptr);
    preampWarmthKnob->setCustomLookAndFeel(nullptr);
    preampTrimKnob->setCustomLookAndFeel(nullptr);
    deEsserFreqKnob->setCustomLookAndFeel(nullptr);
    deEsserThreshKnob->setCustomLookAndFeel(nullptr);
    deEsserRangeKnob->setCustomLookAndFeel(nullptr);
    airGainKnob->setCustomLookAndFeel(nullptr);
    deHarshThreshKnob->setCustomLookAndFeel(nullptr);
    hpfKnob->setCustomLookAndFeel(nullptr);
    lpfKnob->setCustomLookAndFeel(nullptr);
    hfFreqKnob->setCustomLookAndFeel(nullptr);
    hfGainKnob->setCustomLookAndFeel(nullptr);
    hmfFreqKnob->setCustomLookAndFeel(nullptr);
    hmfGainKnob->setCustomLookAndFeel(nullptr);
    hmfQKnob->setCustomLookAndFeel(nullptr);
    lmfFreqKnob->setCustomLookAndFeel(nullptr);
    lmfGainKnob->setCustomLookAndFeel(nullptr);
    lmfQKnob->setCustomLookAndFeel(nullptr);
    lfFreqKnob->setCustomLookAndFeel(nullptr);
    lfGainKnob->setCustomLookAndFeel(nullptr);
    optoPeakRedKnob->setCustomLookAndFeel(nullptr);
    optoGainKnob->setCustomLookAndFeel(nullptr);
    optoHiFreqKnob->setCustomLookAndFeel(nullptr);
    compInputKnob->setCustomLookAndFeel(nullptr);
    compOutputKnob->setCustomLookAndFeel(nullptr);
    compAttackKnob->setCustomLookAndFeel(nullptr);
    compReleaseKnob->setCustomLookAndFeel(nullptr);
    compMixKnob->setCustomLookAndFeel(nullptr);
    doublerMixKnob->setCustomLookAndFeel(nullptr);
    doublerWidthKnob->setCustomLookAndFeel(nullptr);
    masterTrimKnob->setCustomLookAndFeel(nullptr);
    globalMixKnob->setCustomLookAndFeel(nullptr);
}

void EasyVoiceAudioProcessorEditor::comboBoxChanged(juce::ComboBox* box) {
    if (box == &presetBox) {
        const int selectedIdx = presetBox.getSelectedId() - 1;
        if (selectedIdx >= 0) {
            audioProcessor.setCurrentProgram(selectedIdx);
        }
    }
}

void EasyVoiceAudioProcessorEditor::pushNextSampleIntoFifo(float sample) noexcept {
    if (fifoIndex == FFT_SIZE) {
        std::copy(fifoBuffer.begin(), fifoBuffer.end(), fftData.begin());
        std::fill(fftData.begin() + FFT_SIZE, fftData.end(), 0.0f);
        window.multiplyWithWindowingTable(fftData.data(), FFT_SIZE);
        forwardFFT.performFrequencyOnlyForwardTransform(fftData.data());

        for (int i = 0; i < 512; ++i) {
            float val = fftData[static_cast<size_t>(i)];
            float db = juce::Decibels::gainToDecibels(val, -100.0f);
            float norm = juce::jmap(db, -80.0f, 0.0f, 0.0f, 1.0f);
            spectrumPoints[static_cast<size_t>(i)] += 0.35f * (norm - spectrumPoints[static_cast<size_t>(i)]);
        }
        fifoIndex = 0;
    }
    fifoBuffer[static_cast<size_t>(fifoIndex++)] = sample;
}

void EasyVoiceAudioProcessorEditor::timerCallback() {
    float sample = 0.0f;
    while (audioProcessor.getFftFIFO().pop(sample)) {
        pushNextSampleIntoFifo(sample);
    }

    const float alpha = 0.25f;
    smoothedExpanderGR += alpha * (audioProcessor.getExpanderGR_dB() - smoothedExpanderGR);
    smoothedDeEsserGR  += alpha * (audioProcessor.getDeEsserGR_dB() - smoothedDeEsserGR);
    smoothedDeHarshGR  += alpha * (audioProcessor.getDeHarshGR_dB() - smoothedDeHarshGR);
    smoothedOptoGR     += alpha * (audioProcessor.getOptoGR_dB() - smoothedOptoGR);
    smoothedCompGR     += alpha * (audioProcessor.getCompressorGR_dB() - smoothedCompGR);
    smoothedInputPeak  += alpha * (audioProcessor.getInputMeter() - smoothedInputPeak);
    smoothedOutputPeak += alpha * (audioProcessor.getOutputMeter() - smoothedOutputPeak);
    smoothedInLUFS     += 0.05f * (audioProcessor.getInputLUFS() - smoothedInLUFS);
    smoothedOutLUFS    += 0.05f * (audioProcessor.getOutputLUFS() - smoothedOutLUFS);

    // Aggiornamento telemetrico in tempo reale per 171Meter: Gain Reduction del compressore attivo
    const bool optoActive = (audioProcessor.getAPVTS().getRawParameterValue("optoEnable")->load() > 0.5f);
    const bool compActive = (audioProcessor.getAPVTS().getRawParameterValue("compEnable")->load() > 0.5f);
    float currentDynamicsGR = 0.0f;
    if (optoActive) {
        currentDynamicsGR = smoothedOptoGR;
    } else if (compActive) {
        currentDynamicsGR = smoothedCompGR;
    }
    serumVMeter.updateGainReduction(currentDynamicsGR);

    // Sincronizzazione controlli selettori se modificati dall'Host DAW o Preset
    if (consolePushBank != nullptr) {
        if (auto* p = audioProcessor.getAPVTS().getRawParameterValue("preampConsole")) {
            int c = static_cast<int>(p->load());
            if (consolePushBank->getSelectedConsole() != c)
                consolePushBank->setSelectedConsole(c, juce::dontSendNotification);
        }
    }
    if (compRatioPushBank != nullptr) {
        if (auto* p = audioProcessor.getAPVTS().getRawParameterValue("compRatio")) {
            int r = static_cast<int>(p->load());
            if (compRatioPushBank->getSelectedRatio() != r)
                compRatioPushBank->setSelectedRatio(r, juce::dontSendNotification);
        }
    }

    // Invalida selettivamente solo le dirty regions dinamiche a 60 FPS scalate
    const float scaleX = (float)getWidth()  / 1240.0f;
    const float scaleY = (float)getHeight() / 700.0f;
    repaint(juce::roundToInt(504.0f * scaleX), juce::roundToInt(132.0f * scaleY),
            juce::roundToInt(30.0f  * scaleX), juce::roundToInt(166.0f * scaleY));  // 1. Barra LED De-Esser (Baia 2)
    repaint(juce::roundToInt(610.0f * scaleX), juce::roundToInt(110.0f * scaleY),
            juce::roundToInt(242.0f * scaleX), juce::roundToInt(116.0f * scaleY));  // 2. Schermo CRT FFT (Baia 3)
    repaint(juce::roundToInt(246.0f * scaleX), juce::roundToInt(630.0f * scaleY),
            juce::roundToInt(684.0f * scaleX), juce::roundToInt(42.0f  * scaleY));  // 3. Output Peak Meter & LUFS (Footer)
}

void EasyVoiceAudioProcessorEditor::paint(juce::Graphics& g) {
    const float scaleX = (float)getWidth()  / 1240.0f;
    const float scaleY = (float)getHeight() / 700.0f;
    auto S_f = [scaleX, scaleY](float x, float y, float w, float h) -> juce::Rectangle<float> {
        return { x * scaleX, y * scaleY, w * scaleX, h * scaleY };
    };

    // 1. Disegna il backplate chassis pulito fotorealistico scalato
    if (masterBackplateImg.isValid()) {
        g.drawImage(masterBackplateImg, getLocalBounds().toFloat());
    } else {
        g.fillAll(juce::Colour(0xff12141a));
    }

    // 2. Disegna i visualizzatori dinamici in tempo reale scalati proporzionalmente
    drawDeEsserLEDBar(g, S_f(506.0f, 135.0f, 24.0f, 160.0f));
    drawSpectrumDisplay(g, S_f(610.0f, 111.0f, 240.0f, 114.0f));
    drawMasterPeakMeter(g, S_f(250.0f, 634.0f, 672.0f, 34.0f));
}

void EasyVoiceAudioProcessorEditor::drawSpectrumDisplay(juce::Graphics& g, juce::Rectangle<float> bounds) {
    // Sfondo CRT incassato
    g.setColour(juce::Colour(0xff090c12));
    g.fillRoundedRectangle(bounds, 5.0f);

    // Griglia logaritmica serigrafica (100Hz, 500Hz, 1kHz, 5kHz, 10kHz)
    g.setColour(juce::Colour(0x18ffffff));
    for (float f : { 100.0f, 500.0f, 1000.0f, 5000.0f, 10000.0f }) {
        float x = bounds.getX() + bounds.getWidth() * (std::log10(f / 20.0f) / std::log10(20000.0f / 20.0f));
        g.drawVerticalLine(juce::roundToInt(x), bounds.getY(), bounds.getBottom());
    }
    g.drawHorizontalLine(juce::roundToInt(bounds.getBottom() - bounds.getHeight() * 0.75f), bounds.getX(), bounds.getRight());

    // Curva Spettro FFT Verde Smeraldo
    spectrumPath.clear();
    spectrumPath.startNewSubPath(bounds.getX(), bounds.getBottom());
    for (int i = 1; i < 512; ++i) {
        float normX = static_cast<float>(i) / 512.0f;
        float x = bounds.getX() + normX * bounds.getWidth();
        float y = bounds.getBottom() - std::clamp(spectrumPoints[static_cast<size_t>(i)], 0.0f, 1.0f) * bounds.getHeight();
        spectrumPath.lineTo(x, y);
    }
    spectrumPath.lineTo(bounds.getRight(), bounds.getBottom());
    spectrumPath.closeSubPath();

    juce::ColourGradient grad(juce::Colour(0x5010b981), bounds.getX(), bounds.getY(),
                              juce::Colour(0x0a10b981), bounds.getX(), bounds.getBottom(), false);
    g.setGradientFill(grad);
    g.fillPath(spectrumPath);
    g.setColour(juce::Colour(0xff34d399));
    g.strokePath(spectrumPath, juce::PathStrokeType(1.4f));

    // Curva dinamica di Gain Reduction (Arancio / Rosso)
    float totalGR = smoothedDeEsserGR + smoothedDeHarshGR;
    if (totalGR > 0.5f) {
        float grH = std::clamp(totalGR / 24.0f, 0.0f, 1.0f) * (bounds.getHeight() * 0.45f);
        grCurvePath.clear();
        float grX1 = bounds.getX() + bounds.getWidth() * 0.55f;
        float grX2 = bounds.getX() + bounds.getWidth() * 0.95f;
        grCurvePath.startNewSubPath(grX1, bounds.getY());
        grCurvePath.quadraticTo((grX1 + grX2) * 0.5f, bounds.getY() + grH, grX2, bounds.getY());
        g.setColour(juce::Colour(0x60f59e0b));
        g.fillPath(grCurvePath);
        g.setColour(juce::Colour(0xffef4444));
        g.strokePath(grCurvePath, juce::PathStrokeType(1.6f));
    }

    // Bordo metallico dello schermo
    g.setColour(juce::Colour(0xff334155));
    g.drawRoundedRectangle(bounds, 5.0f, 1.5f);
}

void EasyVoiceAudioProcessorEditor::drawDeEsserLEDBar(juce::Graphics& g, juce::Rectangle<float> bounds) {
    g.setColour(juce::Colour(0xff090b10));
    g.fillRoundedRectangle(bounds, 3.0f);
    g.setColour(juce::Colour(0x35c5a059));
    g.drawRoundedRectangle(bounds, 3.0f, 1.0f);

    const int numLeds = 14;
    const float marginY = 3.0f;
    const float totalH = bounds.getHeight() - marginY * 2.0f;
    const float ledSpacing = 2.0f;
    const float ledH = (totalH - (numLeds - 1) * ledSpacing) / static_cast<float>(numLeds);
    const float ledW = bounds.getWidth() - 4.0f;
    const float ledX = bounds.getX() + 2.0f;

    const float grNorm = std::clamp(smoothedDeEsserGR / 24.0f, 0.0f, 1.0f);
    const int activeLeds = static_cast<int>(std::round(grNorm * static_cast<float>(numLeds)));

    for (int i = 0; i < numLeds; ++i) {
        float ly = bounds.getY() + marginY + static_cast<float>(i) * (ledH + ledSpacing);
        auto ledRect = juce::Rectangle<float>(ledX, ly, ledW, ledH);
        bool isLit = (i < activeLeds);

        juce::Colour ledCol = (i < 3) ? juce::Colour(0xfffbbf24) :
                              (i < 9) ? juce::Colour(0xfff59e0b) : juce::Colour(0xffef4444);

        if (isLit) {
            g.setColour(ledCol.withAlpha(0.35f));
            g.fillRoundedRectangle(ledRect.expanded(1.2f, 0.6f), 1.5f);
            g.setColour(ledCol);
            g.fillRoundedRectangle(ledRect, 1.2f);
            g.setColour(juce::Colours::white.withAlpha(0.60f));
            g.fillRect(ledX + 1.0f, ly + 0.5f, ledW - 2.0f, 1.0f);
        } else {
            g.setColour(juce::Colour(0xff161410));
            g.fillRoundedRectangle(ledRect, 1.2f);
            g.setColour(juce::Colour(0x18ffffff));
            g.drawRoundedRectangle(ledRect, 1.2f, 0.6f);
        }
    }
}

void EasyVoiceAudioProcessorEditor::drawMasterPeakMeter(juce::Graphics& g, juce::Rectangle<float> bounds) {
    const float mX = bounds.getX();
    const float mY = bounds.getY();
    const float mW = bounds.getWidth();

    g.setColour(juce::Colour(0xff090c12));
    g.fillRoundedRectangle(mX, mY, mW, 14.0f, 3.0f);
    g.setColour(juce::Colour(0x35ffffff));
    g.drawRoundedRectangle(mX, mY, mW, 14.0f, 3.0f, 1.0f);

    const float normPeak = std::clamp(smoothedOutputPeak, 0.0f, 1.0f);
    const float fillW = normPeak * (mW - 2.0f);

    if (fillW > 1.0f) {
        juce::ColourGradient peakGrad(juce::Colour(0xff10b981), mX, mY,
                                      juce::Colour(0xffef4444), mX + mW, mY, false);
        g.setGradientFill(peakGrad);
        g.fillRoundedRectangle(mX + 1.0f, mY + 1.0f, fillW, 12.0f, 2.0f);
    }

    g.setFont(juce::FontOptions(9.5f, juce::Font::bold));
    g.setColour(juce::Colour(0xff94a3b8));
    juce::String txt = juce::String::formatted("PEAK (-0.09 CEILING) | IN: %.1f LUFS | OUT: %.1f LUFS",
                                               smoothedInLUFS, smoothedOutLUFS);
    g.drawText(txt, static_cast<int>(mX), static_cast<int>(mY + 18.0f), static_cast<int>(mW), 16, juce::Justification::centred);
}

void EasyVoiceAudioProcessorEditor::resized() {
    const float scaleX = (float)getWidth()  / 1240.0f;
    const float scaleY = (float)getHeight() / 700.0f;
    auto S = [scaleX, scaleY](int x, int y, int w, int h) -> juce::Rectangle<int> {
        return { juce::roundToInt(x * scaleX),
                 juce::roundToInt(y * scaleY),
                 juce::roundToInt(w * scaleX),
                 juce::roundToInt(h * scaleY) };
    };

    // ==============================================================================
    // 1. TOP HEADER (y = 0 .. 66)
    // ==============================================================================
    if (prevPresetBtn != nullptr) prevPresetBtn->setBounds(S(486, 16, 26, 28));
    presetBox.setBounds(S(516, 16, 240, 28));
    if (nextPresetBtn != nullptr) nextPresetBtn->setBounds(S(760, 16, 26, 28));
    autoGainButton->setBounds(S(798, 14, 102, 32));
    deltaListenButton->setBounds(S(910, 14, 118, 32));
    bypassModule->setBounds(S(1040, 12, 38, 38));

    // ==============================================================================
    // 2. BAIA 1: 171 NLS BRITISH PREAMP (x: 18 .. 302, w: 284)
    // ==============================================================================
    preampSwitch->setBounds(S(220, 72, 74, 24));

    // Sub 1: VCA Noise Gate
    gateSwitch->setBounds(S(220, 108, 74, 22));
    gateThreshKnob->setBounds(S(24, 134, 126, 82));
    gateRangeKnob->setBounds(S(154, 134, 126, 82));

    // Sub 2: Neve 5116 Drive
    if (consolePushBank != nullptr) consolePushBank->setBounds(S(38, 252, 210, 24));
    preampDriveKnob->setBounds(S(68, 280, 150, 142));

    // Sub 3: Warmth & Output Trim
    preampWarmthKnob->setBounds(S(24, 466, 126, 88));
    preampTrimKnob->setBounds(S(154, 466, 126, 88));

    // ==============================================================================
    // 3. BAIA 2: 171 R-DEESSER LABS & MAAG AIR (x: 310 .. 594, w: 284)
    // ==============================================================================
    deEsserSwitch->setBounds(S(512, 72, 74, 24));

    // Sub 1: Dynamic De-Esser
    deEsserFreqKnob->setBounds(S(318, 130, 84, 76));
    deEsserThreshKnob->setBounds(S(408, 130, 84, 76));
    deEsserRangeKnob->setBounds(S(318, 210, 84, 76));

    deEsserModeBox.setBounds(S(408, 212, 84, 22));
    deEsserTypeBox.setBounds(S(408, 238, 84, 22));
    deEsserListenBox.setBounds(S(408, 264, 84, 22));

    // Sub 2: Maag Air Band & De-Harsh
    airSwitch->setBounds(S(512, 336, 74, 22));
    airGainKnob->setBounds(S(380, 366, 136, 114));
    airFreqBox.setBounds(S(386, 482, 124, 24));
    deHarshThreshKnob->setBounds(S(380, 510, 136, 84));

    // ==============================================================================
    // 4. BAIA 3: 171 SUPERSOLIDLINE CONSOLE EQ (x: 602 .. 958, w: 356)
    // ==============================================================================
    eqSwitch->setBounds(S(848, 72, 104, 24));

    hpfKnob->setBounds(S(862, 110, 86, 54));
    lpfKnob->setBounds(S(862, 168, 86, 54));

    // HF Band (Rosso)
    hfFreqKnob->setBounds(S(612, 248, 104, 72));
    hfGainKnob->setBounds(S(724, 248, 104, 72));
    hfBellToggle.setBounds(S(838, 266, 58, 22));

    // HMF Band (Verde)
    hmfFreqKnob->setBounds(S(612, 340, 104, 72));
    hmfGainKnob->setBounds(S(724, 340, 104, 72));
    hmfQKnob->setBounds(S(836, 340, 104, 72));

    // LMF Band (Blu)
    lmfFreqKnob->setBounds(S(612, 432, 104, 72));
    lmfGainKnob->setBounds(S(724, 432, 104, 72));
    lmfQKnob->setBounds(S(836, 432, 104, 72));

    // LF Band (Rosso)
    lfFreqKnob->setBounds(S(612, 524, 104, 72));
    lfGainKnob->setBounds(S(724, 524, 104, 72));
    lfBellToggle.setBounds(S(838, 542, 58, 22));

    // ==============================================================================
    // 5. BAIA 4: 171-2A & 171-76 DUAL DYNAMICS (x: 966 .. 1222, w: 256)
    // ==============================================================================
    optoSwitch->setBounds(S(1080, 72, 66, 24));
    compSwitch->setBounds(S(1150, 72, 66, 24));

    // Integrazione 171Meter VU & GR Meter in Baia 4
    serumVMeter.setBounds(S(974, 109, 240, 114));

    // Sub 1: 171-2A Knobs (3 knobs: Peak Reduct, Output Gain, HF/Acid SC)
    optoPeakRedKnob->setBounds(S(972, 238, 78, 74));
    optoGainKnob->setBounds(S(1052, 238, 78, 74));
    optoHiFreqKnob->setBounds(S(1132, 238, 78, 74));

    // Sub 2: 171-76 Controls (ENLARGED & PROMINENT!)
    // Row 1: Large Input & Output Knobs (114x94)
    compInputKnob->setBounds(S(974, 324, 114, 94));
    compOutputKnob->setBounds(S(1096, 324, 114, 94));

    // Row 2: Attack, Release & Mix
    compAttackKnob->setBounds(S(972, 420, 76, 68));
    compReleaseKnob->setBounds(S(1050, 420, 76, 68));
    compMixKnob->setBounds(S(1128, 420, 84, 68));

    // Row 3: Push Bank, SC Filter & Revision Box
    if (compRatioPushBank != nullptr) compRatioPushBank->setBounds(S(972, 492, 172, 24));
    if (compSCFilterSwitch != nullptr) compSCFilterSwitch->setBounds(S(1148, 490, 66, 26));
    compRevBox.setBounds(S(972, 518, 140, 20));

    // Sub 3: Stereo Doubler (COMPACT at bottom!)
    doublerSwitch->setBounds(S(972, 552, 68, 20));
    doublerMixKnob->setBounds(S(1048, 544, 82, 60));
    doublerWidthKnob->setBounds(S(1134, 544, 82, 60));

    // ==============================================================================
    // 6. MASTER FOOTER (y = 618 .. 694)
    // ==============================================================================
    globalMixKnob->setBounds(S(30, 624, 96, 66));
    masterTrimKnob->setBounds(S(136, 624, 96, 66));
}
