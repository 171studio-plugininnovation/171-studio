#include "PluginProcessor.h"
#include "PluginEditor.h"

static const std::vector<VocalPreset> gFactoryPresets = {
    // 01. ADRIANO - Raw Street Velvet
    // Dense lower-mid vocal energy (50.9% in 500-1500Hz), nasal resonance at 522 Hz, 1.68 kHz harshness, hot recording (-6.96 dBFS peak).
    {
        "01. Adriano - Raw Street Velvet",
        /*gateEnable=*/ true, /*gateThresh=*/ -44.0f, /*gateRange=*/ -24.0f,
        /*preampEnable=*/ true, /*preampConsole=*/ 0, /*preampDrive=*/ 3.5f, /*preampWarmth=*/ 4.5f, /*preampTrim=*/ -1.0f,
        /*deEsserEnable=*/ true, /*deEsserFreq=*/ 5220.0f, /*deEsserThresh=*/ -22.0f, /*deEsserRange=*/ 10.0f, /*deEsserMode=*/ 0, /*deEsserType=*/ 0,
        /*eqEnable=*/ true, /*hpfFreq=*/ 80.0f, /*lpfFreq=*/ 20000.0f,
        /*lfFreq=*/ 110.0f, /*lfGain=*/ 1.2f, /*lfType=*/ 0,
        /*lmfFreq=*/ 520.0f, /*lmfGain=*/ -3.2f, /*lmfQ=*/ 1.8f,
        /*hmfFreq=*/ 3200.0f, /*hmfGain=*/ 2.5f, /*hmfQ=*/ 1.1f,
        /*hfFreq=*/ 9500.0f, /*hfGain=*/ 3.5f, /*hfType=*/ 0,
        /*airEnable=*/ true, /*airGain=*/ 4.0f, /*airFreq=*/ 3, /*deHarshEnable=*/ true, /*deHarshThresh=*/ -24.0f,
        /*optoEnable=*/ false, /*optoPeakRed=*/ 0.0f, /*optoGain=*/ 0.0f, /*optoHiFreq=*/ 0.0f,
        /*compEnable=*/ true, /*compInput=*/ -20.0f, /*compOutput=*/ -12.0f, /*compAttack=*/ 3.5f, /*compRelease=*/ 5.5f,
        /*compRatio=*/ 0, /*compRev=*/ 1, /*compSCFilter=*/ true, /*compMix=*/ 100.0f,
        /*doublerEnable=*/ true, /*doublerMix=*/ 12.0f, /*doublerWidth=*/ 85.0f,
        /*masterTrim=*/ -0.5f, /*globalMix=*/ 100.0f
    },

    // 02. CH4PO - Hyperpop In-Your-Face
    // Low recorded gain (-20.27 dBFS peak), extreme low-mid proximity boom at 243 Hz (70.8% < 500Hz), needs forward punch and top sizzle.
    {
        "02. Ch4po - Hyperpop In-Your-Face",
        /*gateEnable=*/ true, /*gateThresh=*/ -48.0f, /*gateRange=*/ -28.0f,
        /*preampEnable=*/ true, /*preampConsole=*/ 1, /*preampDrive=*/ 6.8f, /*preampWarmth=*/ 2.5f, /*preampTrim=*/ 6.0f,
        /*deEsserEnable=*/ true, /*deEsserFreq=*/ 5320.0f, /*deEsserThresh=*/ -24.0f, /*deEsserRange=*/ 12.0f, /*deEsserMode=*/ 0, /*deEsserType=*/ 0,
        /*eqEnable=*/ true, /*hpfFreq=*/ 85.0f, /*lpfFreq=*/ 21000.0f,
        /*lfFreq=*/ 140.0f, /*lfGain=*/ -2.5f, /*lfType=*/ 1,
        /*lmfFreq=*/ 245.0f, /*lmfGain=*/ -4.5f, /*lmfQ=*/ 1.6f,
        /*hmfFreq=*/ 2800.0f, /*hmfGain=*/ 4.0f, /*hmfQ=*/ 1.2f,
        /*hfFreq=*/ 8500.0f, /*hfGain=*/ 5.0f, /*hfType=*/ 0,
        /*airEnable=*/ true, /*airGain=*/ 5.5f, /*airFreq=*/ 4, /*deHarshEnable=*/ true, /*deHarshThresh=*/ -20.0f,
        /*optoEnable=*/ false, /*optoPeakRed=*/ 0.0f, /*optoGain=*/ 0.0f, /*optoHiFreq=*/ 0.0f,
        /*compEnable=*/ true, /*compInput=*/ -14.0f, /*compOutput=*/ -10.0f, /*compAttack=*/ 3.0f, /*compRelease=*/ 6.5f,
        /*compRatio=*/ 1, /*compRev=*/ 1, /*compSCFilter=*/ true, /*compMix=*/ 90.0f,
        /*doublerEnable=*/ true, /*doublerMix=*/ 22.0f, /*doublerWidth=*/ 110.0f,
        /*masterTrim=*/ 0.5f, /*globalMix=*/ 100.0f
    },

    // 03. DANKLE - Dark Drill Iron Core
    // Dark baritone timbre (Centroid 354 Hz), massive chest energy (58.9% in 80-220Hz), sub-bass plosives (3.46%), boxiness at 234 Hz.
    {
        "03. Dankle - Dark Drill Iron Core",
        /*gateEnable=*/ true, /*gateThresh=*/ -45.0f, /*gateRange=*/ -30.0f,
        /*preampEnable=*/ true, /*preampConsole=*/ 0, /*preampDrive=*/ 4.5f, /*preampWarmth=*/ 6.0f, /*preampTrim=*/ 3.5f,
        /*deEsserEnable=*/ true, /*deEsserFreq=*/ 4540.0f, /*deEsserThresh=*/ -20.0f, /*deEsserRange=*/ 9.0f, /*deEsserMode=*/ 0, /*deEsserType=*/ 0,
        /*eqEnable=*/ true, /*hpfFreq=*/ 105.0f, /*lpfFreq=*/ 19000.0f,
        /*lfFreq=*/ 230.0f, /*lfGain=*/ -3.8f, /*lfType=*/ 1,
        /*lmfFreq=*/ 480.0f, /*lmfGain=*/ -1.8f, /*lmfQ=*/ 1.0f,
        /*hmfFreq=*/ 2400.0f, /*hmfGain=*/ 3.5f, /*hmfQ=*/ 1.3f,
        /*hfFreq=*/ 8000.0f, /*hfGain=*/ 3.8f, /*hfType=*/ 0,
        /*airEnable=*/ true, /*airGain=*/ 4.5f, /*airFreq=*/ 3, /*deHarshEnable=*/ false, /*deHarshThresh=*/ -24.0f,
        /*optoEnable=*/ true, /*optoPeakRed=*/ 48.0f, /*optoGain=*/ 42.0f, /*optoHiFreq=*/ 25.0f,
        /*compEnable=*/ false, /*compInput=*/ -18.0f, /*compOutput=*/ -12.0f, /*compAttack=*/ 3.0f, /*compRelease=*/ 5.0f,
        /*compRatio=*/ 0, /*compRev=*/ 0, /*compSCFilter=*/ true, /*compMix=*/ 100.0f,
        /*doublerEnable=*/ true, /*doublerMix=*/ 15.0f, /*doublerWidth=*/ 90.0f,
        /*masterTrim=*/ -0.5f, /*globalMix=*/ 100.0f
    },

    // 04. IGOR - Aggressive Blue Punch
    // Piercing rap transients (Crest Factor 23.1 dB), lean chest body (6.3%), nasal boxiness at 557 Hz, sharp consonant bite at 5.48 kHz.
    {
        "04. Igor - Aggressive Blue Punch",
        /*gateEnable=*/ true, /*gateThresh=*/ -42.0f, /*gateRange=*/ -26.0f,
        /*preampEnable=*/ true, /*preampConsole=*/ 1, /*preampDrive=*/ 7.2f, /*preampWarmth=*/ 2.0f, /*preampTrim=*/ 0.0f,
        /*deEsserEnable=*/ true, /*deEsserFreq=*/ 5480.0f, /*deEsserThresh=*/ -25.0f, /*deEsserRange=*/ 13.0f, /*deEsserMode=*/ 0, /*deEsserType=*/ 0,
        /*eqEnable=*/ true, /*hpfFreq=*/ 75.0f, /*lpfFreq=*/ 22000.0f,
        /*lfFreq=*/ 160.0f, /*lfGain=*/ 2.5f, /*lfType=*/ 1,
        /*lmfFreq=*/ 560.0f, /*lmfGain=*/ -3.0f, /*lmfQ=*/ 1.8f,
        /*hmfFreq=*/ 3400.0f, /*hmfGain=*/ 2.0f, /*hmfQ=*/ 1.0f,
        /*hfFreq=*/ 8500.0f, /*hfGain=*/ 4.0f, /*hfType=*/ 0,
        /*airEnable=*/ true, /*airGain=*/ 3.0f, /*airFreq=*/ 3, /*deHarshEnable=*/ true, /*deHarshThresh=*/ -22.0f,
        /*optoEnable=*/ false, /*optoPeakRed=*/ 0.0f, /*optoGain=*/ 0.0f, /*optoHiFreq=*/ 0.0f,
        /*compEnable=*/ true, /*compInput=*/ -16.0f, /*compOutput=*/ -11.0f, /*compAttack=*/ 4.0f, /*compRelease=*/ 6.0f,
        /*compRatio=*/ 1, /*compRev=*/ 1, /*compSCFilter=*/ true, /*compMix=*/ 100.0f,
        /*doublerEnable=*/ true, /*doublerMix=*/ 10.0f, /*doublerWidth=*/ 75.0f,
        /*masterTrim=*/ -0.5f, /*globalMix=*/ 100.0f
    },

    // 05. LELE - Dynamic Freestyle Tamer
    // Extreme dynamic crest factor (26.2 dB), hollow room acoustic resonance at 392.6 Hz (65.1% in 220-500Hz), sibilance spike at 5.7 kHz.
    {
        "05. Lele - Dynamic Freestyle Tamer",
        /*gateEnable=*/ true, /*gateThresh=*/ -40.0f, /*gateRange=*/ -28.0f,
        /*preampEnable=*/ true, /*preampConsole=*/ 0, /*preampDrive=*/ 4.0f, /*preampWarmth=*/ 4.0f, /*preampTrim=*/ 2.5f,
        /*deEsserEnable=*/ true, /*deEsserFreq=*/ 5700.0f, /*deEsserThresh=*/ -26.0f, /*deEsserRange=*/ 14.0f, /*deEsserMode=*/ 0, /*deEsserType=*/ 0,
        /*eqEnable=*/ true, /*hpfFreq=*/ 85.0f, /*lpfFreq=*/ 20000.0f,
        /*lfFreq=*/ 120.0f, /*lfGain=*/ 1.0f, /*lfType=*/ 0,
        /*lmfFreq=*/ 390.0f, /*lmfGain=*/ -5.5f, /*lmfQ=*/ 2.2f,
        /*hmfFreq=*/ 2200.0f, /*hmfGain=*/ 2.8f, /*hmfQ=*/ 1.2f,
        /*hfFreq=*/ 9000.0f, /*hfGain=*/ 3.2f, /*hfType=*/ 0,
        /*airEnable=*/ true, /*airGain=*/ 3.5f, /*airFreq=*/ 3, /*deHarshEnable=*/ true, /*deHarshThresh=*/ -26.0f,
        /*optoEnable=*/ false, /*optoPeakRed=*/ 0.0f, /*optoGain=*/ 0.0f, /*optoHiFreq=*/ 0.0f,
        /*compEnable=*/ true, /*compInput=*/ -15.0f, /*compOutput=*/ -12.0f, /*compAttack=*/ 3.5f, /*compRelease=*/ 5.0f,
        /*compRatio=*/ 0, /*compRev=*/ 0, /*compSCFilter=*/ true, /*compMix=*/ 95.0f,
        /*doublerEnable=*/ true, /*doublerMix=*/ 16.0f, /*doublerWidth=*/ 95.0f,
        /*masterTrim=*/ -0.2f, /*globalMix=*/ 100.0f
    },

    // 06. LIL KROW - Glossy Melodic Auto-Trap
    // Melodic emo-rap aesthetic, low level (-26.28 dBFS peak), flat dynamic swing (10.1 dB), cardboard boxiness at 358 Hz, dark top-end.
    {
        "06. Lil Krow - Glossy Melodic Auto-Trap",
        /*gateEnable=*/ false, /*gateThresh=*/ -50.0f, /*gateRange=*/ -18.0f,
        /*preampEnable=*/ true, /*preampConsole=*/ 2, /*preampDrive=*/ 5.5f, /*preampWarmth=*/ 4.0f, /*preampTrim=*/ 8.0f,
        /*deEsserEnable=*/ true, /*deEsserFreq=*/ 4560.0f, /*deEsserThresh=*/ -28.0f, /*deEsserRange=*/ 8.0f, /*deEsserMode=*/ 0, /*deEsserType=*/ 0,
        /*eqEnable=*/ true, /*hpfFreq=*/ 80.0f, /*lpfFreq=*/ 22000.0f,
        /*lfFreq=*/ 180.0f, /*lfGain=*/ 1.5f, /*lfType=*/ 0,
        /*lmfFreq=*/ 360.0f, /*lmfGain=*/ -3.5f, /*lmfQ=*/ 1.6f,
        /*hmfFreq=*/ 3000.0f, /*hmfGain=*/ 3.5f, /*hmfQ=*/ 1.0f,
        /*hfFreq=*/ 10000.0f, /*hfGain=*/ 4.8f, /*hfType=*/ 0,
        /*airEnable=*/ true, /*airGain=*/ 6.0f, /*airFreq=*/ 3, /*deHarshEnable=*/ true, /*deHarshThresh=*/ -24.0f,
        /*optoEnable=*/ true, /*optoPeakRed=*/ 38.0f, /*optoGain=*/ 48.0f, /*optoHiFreq=*/ 10.0f,
        /*compEnable=*/ false, /*compInput=*/ -18.0f, /*compOutput=*/ -12.0f, /*compAttack=*/ 3.0f, /*compRelease=*/ 5.0f,
        /*compRatio=*/ 0, /*compRev=*/ 0, /*compSCFilter=*/ false, /*compMix=*/ 100.0f,
        /*doublerEnable=*/ true, /*doublerMix=*/ 28.0f, /*doublerWidth=*/ 130.0f,
        /*masterTrim=*/ 1.0f, /*globalMix=*/ 100.0f
    },

    // 07. MAURITO - Vintage Sheen Latin Flow
    // Rich vocal tone with heavy mid-presence (55.9% in 500-1500Hz), boxiness at 598 Hz, consonant rasp at 4535 Hz.
    {
        "07. Maurito - Vintage Sheen Latin Flow",
        /*gateEnable=*/ true, /*gateThresh=*/ -46.0f, /*gateRange=*/ -24.0f,
        /*preampEnable=*/ true, /*preampConsole=*/ 2, /*preampDrive=*/ 4.8f, /*preampWarmth=*/ 5.2f, /*preampTrim=*/ 4.0f,
        /*deEsserEnable=*/ true, /*deEsserFreq=*/ 4540.0f, /*deEsserThresh=*/ -22.0f, /*deEsserRange=*/ 9.0f, /*deEsserMode=*/ 0, /*deEsserType=*/ 0,
        /*eqEnable=*/ true, /*hpfFreq=*/ 80.0f, /*lpfFreq=*/ 21000.0f,
        /*lfFreq=*/ 120.0f, /*lfGain=*/ 1.8f, /*lfType=*/ 0,
        /*lmfFreq=*/ 600.0f, /*lmfGain=*/ -3.8f, /*lmfQ=*/ 1.5f,
        /*hmfFreq=*/ 2600.0f, /*hmfGain=*/ 3.0f, /*hmfQ=*/ 1.1f,
        /*hfFreq=*/ 9000.0f, /*hfGain=*/ 3.5f, /*hfType=*/ 0,
        /*airEnable=*/ true, /*airGain=*/ 4.0f, /*airFreq=*/ 3, /*deHarshEnable=*/ true, /*deHarshThresh=*/ -20.0f,
        /*optoEnable=*/ true, /*optoPeakRed=*/ 44.0f, /*optoGain=*/ 38.0f, /*optoHiFreq=*/ 30.0f,
        /*compEnable=*/ false, /*compInput=*/ -18.0f, /*compOutput=*/ -12.0f, /*compAttack=*/ 3.0f, /*compRelease=*/ 5.0f,
        /*compRatio=*/ 0, /*compRev=*/ 0, /*compSCFilter=*/ false, /*compMix=*/ 100.0f,
        /*doublerEnable=*/ true, /*doublerMix=*/ 18.0f, /*doublerWidth=*/ 100.0f,
        /*masterTrim=*/ 0.0f, /*globalMix=*/ 100.0f
    },

    // 08. PIOTRE - Hardcore Clarity Cut
    // Extreme acoustic boxiness at 398.4 Hz (82.55% in 220-500Hz), deficient fundamental chest body (1.14%), wide dynamic swing (23.6 dB).
    {
        "08. Piotre - Hardcore Clarity Cut",
        /*gateEnable=*/ true, /*gateThresh=*/ -45.0f, /*gateRange=*/ -28.0f,
        /*preampEnable=*/ true, /*preampConsole=*/ 0, /*preampDrive=*/ 5.0f, /*preampWarmth=*/ 6.5f, /*preampTrim=*/ 4.5f,
        /*deEsserEnable=*/ true, /*deEsserFreq=*/ 5400.0f, /*deEsserThresh=*/ -24.0f, /*deEsserRange=*/ 10.0f, /*deEsserMode=*/ 0, /*deEsserType=*/ 0,
        /*eqEnable=*/ true, /*hpfFreq=*/ 75.0f, /*lpfFreq=*/ 20000.0f,
        /*lfFreq=*/ 160.0f, /*lfGain=*/ 3.5f, /*lfType=*/ 1,
        /*lmfFreq=*/ 400.0f, /*lmfGain=*/ -6.0f, /*lmfQ=*/ 2.0f,
        /*hmfFreq=*/ 2200.0f, /*hmfGain=*/ 3.2f, /*hmfQ=*/ 1.2f,
        /*hfFreq=*/ 8500.0f, /*hfGain=*/ 4.0f, /*hfType=*/ 0,
        /*airEnable=*/ true, /*airGain=*/ 4.5f, /*airFreq=*/ 3, /*deHarshEnable=*/ true, /*deHarshThresh=*/ -22.0f,
        /*optoEnable=*/ false, /*optoPeakRed=*/ 0.0f, /*optoGain=*/ 0.0f, /*optoHiFreq=*/ 0.0f,
        /*compEnable=*/ true, /*compInput=*/ -16.0f, /*compOutput=*/ -11.0f, /*compAttack=*/ 3.0f, /*compRelease=*/ 6.0f,
        /*compRatio=*/ 0, /*compRev=*/ 1, /*compSCFilter=*/ true, /*compMix=*/ 100.0f,
        /*doublerEnable=*/ true, /*doublerMix=*/ 14.0f, /*doublerWidth=*/ 85.0f,
        /*masterTrim=*/ 0.0f, /*globalMix=*/ 100.0f
    },

    // 09. SKIETTO - High-Speed Silk De-Esser
    // Ultra-bright delivery (Centroid 1018 Hz), acute piercing sibilance peak at 7640.6 Hz (3.4% sibilant energy, highest in studio).
    {
        "09. Skietto - High-Speed Silk De-Esser",
        /*gateEnable=*/ true, /*gateThresh=*/ -47.0f, /*gateRange=*/ -24.0f,
        /*preampEnable=*/ true, /*preampConsole=*/ 0, /*preampDrive=*/ 3.0f, /*preampWarmth=*/ 6.8f, /*preampTrim=*/ 5.0f,
        /*deEsserEnable=*/ true, /*deEsserFreq=*/ 7640.0f, /*deEsserThresh=*/ -28.0f, /*deEsserRange=*/ 16.0f, /*deEsserMode=*/ 0, /*deEsserType=*/ 0,
        /*eqEnable=*/ true, /*hpfFreq=*/ 85.0f, /*lpfFreq=*/ 18000.0f,
        /*lfFreq=*/ 130.0f, /*lfGain=*/ 1.5f, /*lfType=*/ 0,
        /*lmfFreq=*/ 200.0f, /*lmfGain=*/ -2.5f, /*lmfQ=*/ 1.4f,
        /*hmfFreq=*/ 3600.0f, /*hmfGain=*/ 1.5f, /*hmfQ=*/ 1.0f,
        /*hfFreq=*/ 7500.0f, /*hfGain=*/ -1.5f, /*hfType=*/ 1,
        /*airEnable=*/ true, /*airGain=*/ 3.0f, /*airFreq=*/ 4, /*deHarshEnable=*/ true, /*deHarshThresh=*/ -26.0f,
        /*optoEnable=*/ true, /*optoPeakRed=*/ 42.0f, /*optoGain=*/ 36.0f, /*optoHiFreq=*/ 50.0f,
        /*compEnable=*/ false, /*compInput=*/ -18.0f, /*compOutput=*/ -12.0f, /*compAttack=*/ 3.0f, /*compRelease=*/ 5.0f,
        /*compRatio=*/ 0, /*compRev=*/ 0, /*compSCFilter=*/ false, /*compMix=*/ 100.0f,
        /*doublerEnable=*/ true, /*doublerMix=*/ 20.0f, /*doublerWidth=*/ 110.0f,
        /*masterTrim=*/ -0.5f, /*globalMix=*/ 100.0f
    },

    // 10. ZAIKO - Cloudy Drill Re-Bite
    // Deep acoustic trap tone, heavy box resonance at 401.4 Hz (53.2% in 220-500Hz), almost no top presence (1.35%), dynamic crest swing (23.5 dB).
    {
        "10. Zaiko - Cloudy Drill Re-Bite",
        /*gateEnable=*/ true, /*gateThresh=*/ -43.0f, /*gateRange=*/ -26.0f,
        /*preampEnable=*/ true, /*preampConsole=*/ 1, /*preampDrive=*/ 5.8f, /*preampWarmth=*/ 2.0f, /*preampTrim=*/ 3.0f,
        /*deEsserEnable=*/ true, /*deEsserFreq=*/ 5480.0f, /*deEsserThresh=*/ -22.0f, /*deEsserRange=*/ 8.0f, /*deEsserMode=*/ 0, /*deEsserType=*/ 0,
        /*eqEnable=*/ true, /*hpfFreq=*/ 80.0f, /*lpfFreq=*/ 21000.0f,
        /*lfFreq=*/ 110.0f, /*lfGain=*/ 1.0f, /*lfType=*/ 0,
        /*lmfFreq=*/ 400.0f, /*lmfGain=*/ -5.0f, /*lmfQ=*/ 1.8f,
        /*hmfFreq=*/ 3200.0f, /*hmfGain=*/ 4.2f, /*hmfQ=*/ 1.2f,
        /*hfFreq=*/ 9500.0f, /*hfGain=*/ 4.5f, /*hfType=*/ 0,
        /*airEnable=*/ true, /*airGain=*/ 5.0f, /*airFreq=*/ 3, /*deHarshEnable=*/ false, /*deHarshThresh=*/ -24.0f,
        /*optoEnable=*/ false, /*optoPeakRed=*/ 0.0f, /*optoGain=*/ 0.0f, /*optoHiFreq=*/ 0.0f,
        /*compEnable=*/ true, /*compInput=*/ -18.0f, /*compOutput=*/ -12.0f, /*compAttack=*/ 3.5f, /*compRelease=*/ 6.0f,
        /*compRatio=*/ 0, /*compRev=*/ 1, /*compSCFilter=*/ true, /*compMix=*/ 90.0f,
        /*doublerEnable=*/ true, /*doublerMix=*/ 16.0f, /*doublerWidth=*/ 95.0f,
        /*masterTrim=*/ 0.0f, /*globalMix=*/ 100.0f
    }
};

const std::vector<VocalPreset>& EasyVoiceAudioProcessor::getFactoryPresets() {
    return gFactoryPresets;
}

EasyVoiceAudioProcessor::EasyVoiceAudioProcessor()
    : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "Parameters", createParameterLayout())
{
}

EasyVoiceAudioProcessor::~EasyVoiceAudioProcessor() {}

juce::AudioProcessorValueTreeState::ParameterLayout EasyVoiceAudioProcessor::createParameterLayout() {
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // --- Global Bypass ---
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        "bypass", "Master Bypass", false));

    // --- 1. Vocal Noise Expander / Gate ---
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        "gateEnable", "Gate Enable", false));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "gateThresh", "Gate Threshold",
        juce::NormalisableRange<float>(-60.0f, 0.0f, 0.5f), -42.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "gateRange", "Gate Range",
        juce::NormalisableRange<float>(-48.0f, -6.0f, 0.5f), -24.0f));

    // --- 2. Preamp (Neve 5116 + Marinair LO1166) ---
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        "preampEnable", "Preamp Enable", true));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "preampDrive", "Preamp Drive",
        juce::NormalisableRange<float>(0.0f, 12.0f, 0.1f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "preampWarmth", "Marinair Warmth",
        juce::NormalisableRange<float>(0.0f, 10.0f, 0.1f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "preampTrim", "Preamp Trim",
        juce::NormalisableRange<float>(-12.0f, 12.0f, 0.1f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        "preampConsole", "Preamp Console Type",
        juce::StringArray{ "Snow (Neve 5116)", "SpikeProtein (SuperSolidLine)", "Maik (EMI TG12345)" }, 0));

    // --- 3. De-Esser (Waves Renaissance DeEsser) ---
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        "deEsserEnable", "De-Esser Enable", true));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "deEsserFreq", "De-Esser Frequency",
        juce::NormalisableRange<float>(1000.0f, 12000.0f, 1.0f, 0.35f), 5800.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "deEsserThresh", "De-Esser Threshold",
        juce::NormalisableRange<float>(-48.0f, 0.0f, 0.5f), -20.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "deEsserRange", "De-Esser Range",
        juce::NormalisableRange<float>(0.0f, 24.0f, 0.5f), 12.0f));
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        "deEsserMode", "De-Esser Mode",
        juce::StringArray{ "Split-Band", "Wideband" }, 0));
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        "deEsserType", "De-Esser Sidechain Type",
        juce::StringArray{ "Bell", "High-Pass" }, 0));
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        "deEsserListen", "De-Esser Listen Mode",
        juce::StringArray{ "Audio", "Sidechain", "Delta" }, 0));

    // --- 4. EQ (SSL 4000 G-Series Black Knob 242) ---
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        "eqEnable", "EQ Enable", true));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "hpfFreq", "HPF Frequency",
        juce::NormalisableRange<float>(16.0f, 350.0f, 1.0f, 0.45f), 16.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "lpfFreq", "LPF Frequency",
        juce::NormalisableRange<float>(3000.0f, 22000.0f, 1.0f, 0.45f), 22000.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "lfFreq", "LF Frequency",
        juce::NormalisableRange<float>(30.0f, 450.0f, 1.0f, 0.45f), 80.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "lfGain", "LF Gain",
        juce::NormalisableRange<float>(-15.0f, 15.0f, 0.1f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        "lfType", "LF Band Type",
        juce::StringArray{ "Shelf", "Bell" }, 0));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "lmfFreq", "LMF Frequency",
        juce::NormalisableRange<float>(200.0f, 2500.0f, 1.0f, 0.45f), 450.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "lmfGain", "LMF Gain",
        juce::NormalisableRange<float>(-15.0f, 15.0f, 0.1f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "lmfQ", "LMF Q",
        juce::NormalisableRange<float>(0.5f, 2.5f, 0.05f), 1.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "hmfFreq", "HMF Frequency",
        juce::NormalisableRange<float>(600.0f, 7000.0f, 1.0f, 0.45f), 2400.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "hmfGain", "HMF Gain",
        juce::NormalisableRange<float>(-15.0f, 15.0f, 0.1f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "hmfQ", "HMF Q",
        juce::NormalisableRange<float>(0.5f, 2.5f, 0.05f), 1.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "hfFreq", "HF Frequency",
        juce::NormalisableRange<float>(1500.0f, 16000.0f, 1.0f, 0.45f), 8000.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "hfGain", "HF Gain",
        juce::NormalisableRange<float>(-15.0f, 15.0f, 0.1f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        "hfType", "HF Band Type",
        juce::StringArray{ "Shelf", "Bell" }, 0));

    // --- 5. Air Band & De-Harsh ---
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        "airEnable", "Air Band Enable", true));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "airGain", "Air Gain",
        juce::NormalisableRange<float>(0.0f, 12.0f, 0.1f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        "airFreq", "Air Frequency",
        juce::StringArray{ "2.5 kHz", "5 kHz", "10 kHz", "20 kHz", "40 kHz" }, 3));
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        "deHarshEnable", "De-Harsh Tamer Enable", false));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "deHarshThresh", "De-Harsh Threshold",
        juce::NormalisableRange<float>(-48.0f, 0.0f, 0.5f), -24.0f));

    // --- 6. Dual Dynamics (171-2A Opto + 171-76 FET) ---
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        "optoEnable", "171-2A Opto Enable", false));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "optoPeakRed", "171-2A Peak Reduction",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.5f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "optoGain", "171-2A Makeup Gain",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.5f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "optoHiFreq", "171-2A HF Acid SC Filter",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.5f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        "compEnable", "171-76 FET Enable", false));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "compInput", "1176 Input",
        juce::NormalisableRange<float>(-60.0f, 0.0f, 0.1f), -18.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "compOutput", "1176 Output",
        juce::NormalisableRange<float>(-60.0f, 0.0f, 0.1f), -12.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "compAttack", "1176 Attack",
        juce::NormalisableRange<float>(1.0f, 7.0f, 0.05f), 3.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "compRelease", "1176 Release",
        juce::NormalisableRange<float>(1.0f, 7.0f, 0.05f), 5.0f));
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        "compRatio", "1176 Ratio",
        juce::StringArray{ "4:1", "8:1", "12:1", "20:1", "ALL BUTTONS" }, 0));
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        "compRev", "1176 Revision",
        juce::StringArray{ "Blackface (Rev E)", "Blue Stripe (Rev A)" }, 1));
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        "compSCFilter", "1176 SC Filter (100 Hz)", false));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "compMix", "1176 Parallel Mix",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.5f), 100.0f));

    // --- 7. Vocal Doubler & Spatial ---
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        "doublerEnable", "Doubler Enable", false));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "doublerMix", "Doubler Mix",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.5f), 20.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "doublerWidth", "Doubler Width",
        juce::NormalisableRange<float>(0.0f, 150.0f, 1.0f), 100.0f));

    // --- 8. Master & Workflow ---
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "masterTrim", "Master Output Trim",
        juce::NormalisableRange<float>(-24.0f, 12.0f, 0.1f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "globalMix", "Global Dry/Wet Mix",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.5f), 100.0f));
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        "autoGain", "Smart Auto-Gain (LUFS Match)", false));
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        "deltaListen", "Delta Audition (Solo Difference)", false));

    return { params.begin(), params.end() };
}

void EasyVoiceAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock) {
    juce::ignoreUnused(samplesPerBlock);
    channelStrip.prepare(sampleRate);
    updateDSPParameters();
    setLatencySamples(channelStrip.getLatencyInSamples());
}

void EasyVoiceAudioProcessor::releaseResources() {
    channelStrip.reset();
}

bool EasyVoiceAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const {
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;

    return true;
}

void EasyVoiceAudioProcessor::updateDSPParameters() noexcept {
    // 0. Global Bypass
    const bool masterByp = apvts.getRawParameterValue("bypass")->load() > 0.5f;
    channelStrip.setBypass(masterByp);

    // 1. Expander / Gate
    const bool gateEn = apvts.getRawParameterValue("gateEnable")->load() > 0.5f;
    channelStrip.setExpanderEnabled(gateEn);
    channelStrip.setExpanderThreshold(apvts.getRawParameterValue("gateThresh")->load());
    channelStrip.setExpanderRange(apvts.getRawParameterValue("gateRange")->load());

    // 2. Preamp
    const bool preEn = apvts.getRawParameterValue("preampEnable")->load() > 0.5f;
    channelStrip.setPreampEnabled(preEn);
    channelStrip.setPreampDrive(apvts.getRawParameterValue("preampDrive")->load());
    channelStrip.setPreampWarmth(apvts.getRawParameterValue("preampWarmth")->load());
    channelStrip.setPreampTrim(apvts.getRawParameterValue("preampTrim")->load());

    const int preConsoleIdx = static_cast<int>(apvts.getRawParameterValue("preampConsole")->load());
    dsp171::NLSSummingDSP::ConsoleType cType = dsp171::NLSSummingDSP::ConsoleType::Nevo;
    if (preConsoleIdx == 1) cType = dsp171::NLSSummingDSP::ConsoleType::Spike;
    else if (preConsoleIdx == 2) cType = dsp171::NLSSummingDSP::ConsoleType::Mike;
    channelStrip.setPreampConsole(cType);

    // 3. De-Esser
    const bool deEn = apvts.getRawParameterValue("deEsserEnable")->load() > 0.5f;
    channelStrip.setDeEsserEnabled(deEn);
    channelStrip.setDeEsserFrequency(apvts.getRawParameterValue("deEsserFreq")->load());
    channelStrip.setDeEsserThresholdDb(apvts.getRawParameterValue("deEsserThresh")->load());
    channelStrip.setDeEsserRangeDb(apvts.getRawParameterValue("deEsserRange")->load());

    const int dModeIdx = static_cast<int>(apvts.getRawParameterValue("deEsserMode")->load());
    channelStrip.setDeEsserMode(dModeIdx == 0 ? dsp171::RenaissanceDeEsser::DeEsserMode::SplitBand
                                              : dsp171::RenaissanceDeEsser::DeEsserMode::Wideband);

    const int dTypeIdx = static_cast<int>(apvts.getRawParameterValue("deEsserType")->load());
    channelStrip.setDeEsserSidechainType(dTypeIdx == 0 ? dsp171::RenaissanceDeEsser::SidechainType::Bell
                                                       : dsp171::RenaissanceDeEsser::SidechainType::HighPass);

    const int dListenIdx = static_cast<int>(apvts.getRawParameterValue("deEsserListen")->load());
    channelStrip.setDeEsserListenMode(static_cast<dsp171::RenaissanceDeEsser::ListenMode>(dListenIdx));

    // 4. EQ
    const bool eqEn = apvts.getRawParameterValue("eqEnable")->load() > 0.5f;
    channelStrip.setEQEnabled(eqEn);
    channelStrip.setHPFFreq(apvts.getRawParameterValue("hpfFreq")->load());
    channelStrip.setLPFFreq(apvts.getRawParameterValue("lpfFreq")->load());

    const int lfTypeIdx = static_cast<int>(apvts.getRawParameterValue("lfType")->load());
    channelStrip.setLF(apvts.getRawParameterValue("lfFreq")->load(),
                       apvts.getRawParameterValue("lfGain")->load(),
                       lfTypeIdx == 0 ? dsp171::SSLGChannelEQ::BandType::Shelf : dsp171::SSLGChannelEQ::BandType::Bell);

    channelStrip.setLMF(apvts.getRawParameterValue("lmfFreq")->load(),
                        apvts.getRawParameterValue("lmfGain")->load(),
                        apvts.getRawParameterValue("lmfQ")->load());

    channelStrip.setHMF(apvts.getRawParameterValue("hmfFreq")->load(),
                        apvts.getRawParameterValue("hmfGain")->load(),
                        apvts.getRawParameterValue("hmfQ")->load());

    const int hfTypeIdx = static_cast<int>(apvts.getRawParameterValue("hfType")->load());
    channelStrip.setHF(apvts.getRawParameterValue("hfFreq")->load(),
                       apvts.getRawParameterValue("hfGain")->load(),
                       hfTypeIdx == 0 ? dsp171::SSLGChannelEQ::BandType::Shelf : dsp171::SSLGChannelEQ::BandType::Bell);

    // 5. Air & De-Harsh
    const bool airEn = apvts.getRawParameterValue("airEnable")->load() > 0.5f;
    channelStrip.setAirEnabled(airEn);
    channelStrip.setAirGain(apvts.getRawParameterValue("airGain")->load());
    const int airFreqIdx = static_cast<int>(apvts.getRawParameterValue("airFreq")->load());
    channelStrip.setAirFrequency(static_cast<dsp171::MaagAirResonance::AirFreq>(airFreqIdx));

    const bool deHarshEn = apvts.getRawParameterValue("deHarshEnable")->load() > 0.5f;
    channelStrip.setDeHarshEnabled(deHarshEn);
    channelStrip.setDeHarshThreshold(apvts.getRawParameterValue("deHarshThresh")->load());

    // 6. Dual Dynamics (Exclusive: 171-2A vs 171-76)
    bool optoEn = apvts.getRawParameterValue("optoEnable")->load() > 0.5f;
    bool cEn = apvts.getRawParameterValue("compEnable")->load() > 0.5f;
    if (optoEn && cEn) {
        cEn = false; // Mutual exclusion
    }
    channelStrip.setOptoEnabled(optoEn);
    channelStrip.setOptoPeakReduction(apvts.getRawParameterValue("optoPeakRed")->load());
    channelStrip.setOptoGain(apvts.getRawParameterValue("optoGain")->load());
    channelStrip.setOptoHiFreq(apvts.getRawParameterValue("optoHiFreq")->load());

    channelStrip.setCompressorEnabled(cEn);
    channelStrip.setCompInputDb(apvts.getRawParameterValue("compInput")->load());
    channelStrip.setCompOutputDb(apvts.getRawParameterValue("compOutput")->load());
    channelStrip.setCompAttackKnob(apvts.getRawParameterValue("compAttack")->load());
    channelStrip.setCompReleaseKnob(apvts.getRawParameterValue("compRelease")->load());

    const int ratioIdx = static_cast<int>(apvts.getRawParameterValue("compRatio")->load());
    dsp171::CLA76Compressor::Ratio r = dsp171::CLA76Compressor::Ratio::Ratio4;
    switch (ratioIdx) {
        case 0: r = dsp171::CLA76Compressor::Ratio::Ratio4; break;
        case 1: r = dsp171::CLA76Compressor::Ratio::Ratio8; break;
        case 2: r = dsp171::CLA76Compressor::Ratio::Ratio12; break;
        case 3: r = dsp171::CLA76Compressor::Ratio::Ratio20; break;
        case 4: r = dsp171::CLA76Compressor::Ratio::AllButtons; break;
    }
    channelStrip.setCompRatio(r);

    const int revIdx = static_cast<int>(apvts.getRawParameterValue("compRev")->load());
    channelStrip.setCompRevision(revIdx == 0 ? dsp171::CLA76Compressor::Revision::Blackface
                                             : dsp171::CLA76Compressor::Revision::BlueStripe);

    const bool scFilt = apvts.getRawParameterValue("compSCFilter")->load() > 0.5f;
    channelStrip.setCompSCFilter(scFilt);

    channelStrip.setCompMix(apvts.getRawParameterValue("compMix")->load());

    // 7. Doubler
    const bool doublerEn = apvts.getRawParameterValue("doublerEnable")->load() > 0.5f;
    channelStrip.setDoublerEnabled(doublerEn);
    channelStrip.setDoublerMix(apvts.getRawParameterValue("doublerMix")->load());
    channelStrip.setDoublerWidth(apvts.getRawParameterValue("doublerWidth")->load() * 0.01f);

    // 8. Master
    channelStrip.setMasterTrim(apvts.getRawParameterValue("masterTrim")->load());
    channelStrip.setGlobalMix(apvts.getRawParameterValue("globalMix")->load());
    channelStrip.setAutoGainEnabled(apvts.getRawParameterValue("autoGain")->load() > 0.5f);
    channelStrip.setDeltaListenEnabled(apvts.getRawParameterValue("deltaListen")->load() > 0.5f);
}

void EasyVoiceAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages) {
    juce::ignoreUnused(midiMessages);
    juce::ScopedNoDenormals noDenormals;

    const int numChannels = buffer.getNumChannels();
    const int numSamples  = buffer.getNumSamples();

    if (numChannels == 0 || numSamples == 0) return;

    updateDSPParameters();

    float* inOutL = buffer.getWritePointer(0);
    float* inOutR = (numChannels > 1) ? buffer.getWritePointer(1) : inOutL;

    float* channelPointers[2] = { inOutL, inOutR };
    channelStrip.process(channelPointers, numChannels, numSamples);

    // Push audio block into LockFreeFIFO for 60 FPS Spectrum Visualizer
    for (int i = 0; i < numSamples; ++i) {
        float monoVal = 0.5f * (inOutL[i] + inOutR[i]);
        fftFIFO.push(monoVal);
    }

    // Telemetry updates (atomic, real-time safe)
    expanderGR   = channelStrip.getExpanderGR();
    deEsserGR    = channelStrip.getDeEsserGR();
    deHarshGR    = channelStrip.getDeHarshGR();
    optoGR       = channelStrip.getOptoGR();
    compressorGR = channelStrip.getCompGR();
    inputLUFS    = channelStrip.getInputLUFS();
    outputLUFS   = channelStrip.getOutputLUFS();
    inputMeter   = channelStrip.getInputPeak();
    outputMeter  = channelStrip.getOutputPeak();
}

juce::AudioProcessorEditor* EasyVoiceAudioProcessor::createEditor() {
    return new EasyVoiceAudioProcessorEditor(*this);
}

int EasyVoiceAudioProcessor::getNumPrograms() {
    return static_cast<int>(gFactoryPresets.size());
}

int EasyVoiceAudioProcessor::getCurrentProgram() {
    return currentProgramIndex;
}

void EasyVoiceAudioProcessor::setCurrentProgram(int index) {
    if (index >= 0 && index < static_cast<int>(gFactoryPresets.size())) {
        currentProgramIndex = index;
        const auto& p = gFactoryPresets[static_cast<size_t>(index)];

        // Expander / Gate
        apvts.getParameter("gateEnable")->setValueNotifyingHost(p.gateEnable ? 1.0f : 0.0f);
        apvts.getParameter("gateThresh")->setValueNotifyingHost(apvts.getParameterRange("gateThresh").convertTo0to1(p.gateThresh));
        apvts.getParameter("gateRange")->setValueNotifyingHost(apvts.getParameterRange("gateRange").convertTo0to1(p.gateRange));

        // Preamp
        apvts.getParameter("preampEnable")->setValueNotifyingHost(p.preampEnable ? 1.0f : 0.0f);
        apvts.getParameter("preampConsole")->setValueNotifyingHost(static_cast<float>(p.preampConsole) / 2.0f);
        apvts.getParameter("preampDrive")->setValueNotifyingHost(apvts.getParameterRange("preampDrive").convertTo0to1(p.preampDrive));
        apvts.getParameter("preampWarmth")->setValueNotifyingHost(apvts.getParameterRange("preampWarmth").convertTo0to1(p.preampWarmth));
        apvts.getParameter("preampTrim")->setValueNotifyingHost(apvts.getParameterRange("preampTrim").convertTo0to1(p.preampTrim));

        // De-Esser
        apvts.getParameter("deEsserEnable")->setValueNotifyingHost(p.deEsserEnable ? 1.0f : 0.0f);
        apvts.getParameter("deEsserFreq")->setValueNotifyingHost(apvts.getParameterRange("deEsserFreq").convertTo0to1(p.deEsserFreq));
        apvts.getParameter("deEsserThresh")->setValueNotifyingHost(apvts.getParameterRange("deEsserThresh").convertTo0to1(p.deEsserThresh));
        apvts.getParameter("deEsserRange")->setValueNotifyingHost(apvts.getParameterRange("deEsserRange").convertTo0to1(p.deEsserRange));
        apvts.getParameter("deEsserMode")->setValueNotifyingHost(p.deEsserMode == 0 ? 0.0f : 1.0f);
        apvts.getParameter("deEsserType")->setValueNotifyingHost(p.deEsserType == 0 ? 0.0f : 1.0f);

        // EQ
        apvts.getParameter("eqEnable")->setValueNotifyingHost(p.eqEnable ? 1.0f : 0.0f);
        apvts.getParameter("hpfFreq")->setValueNotifyingHost(apvts.getParameterRange("hpfFreq").convertTo0to1(p.hpfFreq));
        apvts.getParameter("lpfFreq")->setValueNotifyingHost(apvts.getParameterRange("lpfFreq").convertTo0to1(p.lpfFreq));
        apvts.getParameter("lfFreq")->setValueNotifyingHost(apvts.getParameterRange("lfFreq").convertTo0to1(p.lfFreq));
        apvts.getParameter("lfGain")->setValueNotifyingHost(apvts.getParameterRange("lfGain").convertTo0to1(p.lfGain));
        apvts.getParameter("lfType")->setValueNotifyingHost(p.lfType == 0 ? 0.0f : 1.0f);
        apvts.getParameter("lmfFreq")->setValueNotifyingHost(apvts.getParameterRange("lmfFreq").convertTo0to1(p.lmfFreq));
        apvts.getParameter("lmfGain")->setValueNotifyingHost(apvts.getParameterRange("lmfGain").convertTo0to1(p.lmfGain));
        apvts.getParameter("lmfQ")->setValueNotifyingHost(apvts.getParameterRange("lmfQ").convertTo0to1(p.lmfQ));
        apvts.getParameter("hmfFreq")->setValueNotifyingHost(apvts.getParameterRange("hmfFreq").convertTo0to1(p.hmfFreq));
        apvts.getParameter("hmfGain")->setValueNotifyingHost(apvts.getParameterRange("hmfGain").convertTo0to1(p.hmfGain));
        apvts.getParameter("hmfQ")->setValueNotifyingHost(apvts.getParameterRange("hmfQ").convertTo0to1(p.hmfQ));
        apvts.getParameter("hfFreq")->setValueNotifyingHost(apvts.getParameterRange("hfFreq").convertTo0to1(p.hfFreq));
        apvts.getParameter("hfGain")->setValueNotifyingHost(apvts.getParameterRange("hfGain").convertTo0to1(p.hfGain));
        apvts.getParameter("hfType")->setValueNotifyingHost(p.hfType == 0 ? 0.0f : 1.0f);

        // Air & De-Harsh
        apvts.getParameter("airEnable")->setValueNotifyingHost(p.airEnable ? 1.0f : 0.0f);
        apvts.getParameter("airGain")->setValueNotifyingHost(apvts.getParameterRange("airGain").convertTo0to1(p.airGain));
        apvts.getParameter("airFreq")->setValueNotifyingHost(static_cast<float>(p.airFreq) / 4.0f);
        apvts.getParameter("deHarshEnable")->setValueNotifyingHost(p.deHarshEnable ? 1.0f : 0.0f);
        apvts.getParameter("deHarshThresh")->setValueNotifyingHost(apvts.getParameterRange("deHarshThresh").convertTo0to1(p.deHarshThresh));

        // Dual Dynamics
        apvts.getParameter("optoEnable")->setValueNotifyingHost(p.optoEnable ? 1.0f : 0.0f);
        apvts.getParameter("optoPeakRed")->setValueNotifyingHost(apvts.getParameterRange("optoPeakRed").convertTo0to1(p.optoPeakRed));
        apvts.getParameter("optoGain")->setValueNotifyingHost(apvts.getParameterRange("optoGain").convertTo0to1(p.optoGain));
        apvts.getParameter("optoHiFreq")->setValueNotifyingHost(apvts.getParameterRange("optoHiFreq").convertTo0to1(p.optoHiFreq));

        apvts.getParameter("compEnable")->setValueNotifyingHost(p.compEnable ? 1.0f : 0.0f);
        apvts.getParameter("compInput")->setValueNotifyingHost(apvts.getParameterRange("compInput").convertTo0to1(p.compInput));
        apvts.getParameter("compOutput")->setValueNotifyingHost(apvts.getParameterRange("compOutput").convertTo0to1(p.compOutput));
        apvts.getParameter("compAttack")->setValueNotifyingHost(apvts.getParameterRange("compAttack").convertTo0to1(p.compAttack));
        apvts.getParameter("compRelease")->setValueNotifyingHost(apvts.getParameterRange("compRelease").convertTo0to1(p.compRelease));
        apvts.getParameter("compRatio")->setValueNotifyingHost(static_cast<float>(p.compRatio) / 4.0f);
        apvts.getParameter("compRev")->setValueNotifyingHost(p.compRev == 0 ? 0.0f : 1.0f);
        apvts.getParameter("compSCFilter")->setValueNotifyingHost(p.compSCFilter ? 1.0f : 0.0f);
        apvts.getParameter("compMix")->setValueNotifyingHost(apvts.getParameterRange("compMix").convertTo0to1(p.compMix));

        // Doubler
        apvts.getParameter("doublerEnable")->setValueNotifyingHost(p.doublerEnable ? 1.0f : 0.0f);
        apvts.getParameter("doublerMix")->setValueNotifyingHost(apvts.getParameterRange("doublerMix").convertTo0to1(p.doublerMix));
        apvts.getParameter("doublerWidth")->setValueNotifyingHost(apvts.getParameterRange("doublerWidth").convertTo0to1(p.doublerWidth));

        // Master
        apvts.getParameter("masterTrim")->setValueNotifyingHost(apvts.getParameterRange("masterTrim").convertTo0to1(p.masterTrim));
        apvts.getParameter("globalMix")->setValueNotifyingHost(apvts.getParameterRange("globalMix").convertTo0to1(p.globalMix));
    }
}

const juce::String EasyVoiceAudioProcessor::getProgramName(int index) {
    if (index >= 0 && index < static_cast<int>(gFactoryPresets.size())) {
        return gFactoryPresets[static_cast<size_t>(index)].name;
    }
    return {};
}

void EasyVoiceAudioProcessor::changeProgramName(int index, const juce::String& newName) {
    juce::ignoreUnused(index, newName);
}

void EasyVoiceAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void EasyVoiceAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType())) {
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
    }
}

// Juce Export
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new EasyVoiceAudioProcessor();
}
