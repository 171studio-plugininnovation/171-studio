#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include "PluginProcessor.h"
#include "SerumVMeterComponent.h"
#include <BinaryData.h>

#include "GUI/CustomKnob.h"
#include "GUI/HardwareSwitch.h"

// ==============================================================================
// LookAndFeel per i Selettori Dropdown 171 Studio Boutique
// ==============================================================================
class Studio171ComboBoxLookAndFeel : public juce::LookAndFeel_V4 {
public:
    Studio171ComboBoxLookAndFeel() {
        setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff16181f));
        setColour(juce::ComboBox::textColourId, juce::Colour(0xfff1f5f9));
        setColour(juce::ComboBox::outlineColourId, juce::Colour(0xffc5a059));
        setColour(juce::ComboBox::arrowColourId, juce::Colour(0xffd4af37));

        setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xf6101217));
        setColour(juce::PopupMenu::textColourId, juce::Colour(0xfff1f5f9));
        setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xff2d2417));
        setColour(juce::PopupMenu::highlightedTextColourId, juce::Colour(0xffffe082));
    }

    void drawComboBox(juce::Graphics& g, int width, int height, bool isButtonDown,
                      int buttonX, int buttonY, int buttonW, int buttonH, juce::ComboBox& box) override
    {
        juce::ignoreUnused(isButtonDown);
        auto bounds = juce::Rectangle<float>(0.0f, 0.0f, static_cast<float>(width), static_cast<float>(height)).reduced(1.0f);

        // Ombra incassata
        g.setColour(juce::Colours::black.withAlpha(0.50f));
        g.fillRoundedRectangle(bounds.translated(1.0f, 2.0f), 4.0f);

        // Metallo spazzolato scuro
        juce::ColourGradient grad(juce::Colour(0xff222630), bounds.getX(), bounds.getY(),
                                  juce::Colour(0xff101217), bounds.getX(), bounds.getBottom(), false);
        g.setGradientFill(grad);
        g.fillRoundedRectangle(bounds, 4.0f);

        // Bordo in oro cesellato
        g.setColour(box.hasKeyboardFocus(true) ? juce::Colour(0xffffe082) : juce::Colour(0xffc5a059));
        g.drawRoundedRectangle(bounds, 4.0f, 1.2f);

        // Freccia chevron dorata
        float arrowCx = static_cast<float>(buttonX) + static_cast<float>(buttonW) * 0.5f;
        float arrowCy = static_cast<float>(buttonY) + static_cast<float>(buttonH) * 0.5f;
        float arrowW = 7.0f;
        float arrowH = 4.5f;

        juce::Path arrow;
        arrow.startNewSubPath(arrowCx - arrowW * 0.5f, arrowCy - arrowH * 0.5f);
        arrow.lineTo(arrowCx, arrowCy + arrowH * 0.5f);
        arrow.lineTo(arrowCx + arrowW * 0.5f, arrowCy - arrowH * 0.5f);

        g.setColour(juce::Colour(0xffd4af37));
        g.strokePath(arrow, juce::PathStrokeType(1.8f, juce::PathStrokeType::mitered, juce::PathStrokeType::rounded));
    }

    juce::Font getComboBoxFont(juce::ComboBox&) override {
        return juce::FontOptions(10.5f, juce::Font::bold);
    }

    void positionComboBoxText(juce::ComboBox& box, juce::Label& label) override {
        label.setBounds(6, 1, box.getWidth() - 24, box.getHeight() - 2);
        label.setFont(getComboBoxFont(box));
    }
};

// ==============================================================================
// LookAndFeel per Manopole con Filmstrip Fotografici Multi-Frame (Waves Style)
// ==============================================================================
class BoutiqueFilmstripKnobLookAndFeel : public juce::LookAndFeel_V4 {
public:
    BoutiqueFilmstripKnobLookAndFeel() = default;

    void setFilmstrip(juce::Image strip, int numFrames, juce::Colour accentCol = juce::Colour(0xffd4af37))
    {
        filmstrip = strip;
        frames = numFrames;
        accent = accentCol;
    }

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPosProportional, float rotaryStartAngle, float rotaryEndAngle,
                          juce::Slider&) override
    {
        const float size = static_cast<float>(juce::jmin(width, height));
        const float centreX = static_cast<float>(x) + static_cast<float>(width) * 0.5f;
        const float centreY = static_cast<float>(y) + static_cast<float>(height) * 0.5f;

        if (filmstrip.isValid() && frames > 1)
        {
            const int frameIdx = juce::jlimit(0, frames - 1,
                static_cast<int>(std::round(sliderPosProportional * static_cast<float>(frames - 1))));
            const int frameH = filmstrip.getHeight() / frames;
            const int frameW = filmstrip.getWidth();

            // Disegna fotogramma filmstrip nitido senza alcuna patina scura
            const float knobSize = size * 0.94f;
            g.drawImage(filmstrip,
                        juce::roundToInt(centreX - knobSize * 0.5f), juce::roundToInt(centreY - knobSize * 0.5f),
                        juce::roundToInt(knobSize), juce::roundToInt(knobSize),
                        0, frameIdx * frameH, frameW, frameH);
        }
        else
        {
            // Rendering vettoriale di fallback
            const float radius = size * 0.44f;
            juce::ColourGradient knobGrad(juce::Colour(0xff3a3d45), centreX - radius, centreY - radius,
                                         juce::Colour(0xff14161a), centreX + radius, centreY + radius, true);
            g.setGradientFill(knobGrad);
            g.fillEllipse(centreX - radius, centreY - radius, radius * 2.0f, radius * 2.0f);
            g.setColour(juce::Colour(0xffc5a059));
            g.drawEllipse(centreX - radius, centreY - radius, radius * 2.0f, radius * 2.0f, 1.2f);

            const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);
            g.setColour(accent);
            g.drawLine(centreX, centreY, centreX + radius * std::sin(angle), centreY - radius * std::cos(angle), 2.2f);
        }
    }

private:
    juce::Image filmstrip;
    int frames = 101;
    juce::Colour accent = juce::Colour(0xffd4af37);
};

// ==============================================================================
// 171 EasyVoice Pro Boutique Editor
// ==============================================================================
class EasyVoiceAudioProcessorEditor : public juce::AudioProcessorEditor,
                                      private juce::Timer,
                                      public juce::ComboBox::Listener {
public:
    explicit EasyVoiceAudioProcessorEditor(EasyVoiceAudioProcessor&);
    ~EasyVoiceAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;
    void comboBoxChanged(juce::ComboBox*) override;
    void timerCallback() override;

private:
    EasyVoiceAudioProcessor& audioProcessor;
    Studio171ComboBoxLookAndFeel comboBoxLookAndFeel;

    // --- Master Photorealistic Clean Chassis Backplate ---
    juce::Image masterBackplateImg;

    // --- Asset Pulsanti & Switch ---
    juce::Image btnAmberLitImg;
    juce::Image btnDarkUnlitImg;
    juce::Image swBypassActiveImg;
    juce::Image swBypassEngagedImg;
    juce::Image optoCellCanisterImg;

    // --- LookAndFeel per Filmstrip Knobs Waves Reverse-Engineered ---
    BoutiqueFilmstripKnobLookAndFeel neveDriveLaf;
    BoutiqueFilmstripKnobLookAndFeel neveVcaLaf;
    BoutiqueFilmstripKnobLookAndFeel sslLfLaf;
    BoutiqueFilmstripKnobLookAndFeel sslLmfLaf;
    BoutiqueFilmstripKnobLookAndFeel sslHmfLaf;
    BoutiqueFilmstripKnobLookAndFeel sslHfLaf;
    BoutiqueFilmstripKnobLookAndFeel sslHpfLaf;
    BoutiqueFilmstripKnobLookAndFeel rdeesserFreqLaf;
    BoutiqueFilmstripKnobLookAndFeel la2aBakeliteLaf;
    BoutiqueFilmstripKnobLookAndFeel cla76LargeLaf;
    BoutiqueFilmstripKnobLookAndFeel cla76SmallLaf;

    // --- Header & Master Controls ---
    juce::ComboBox presetBox;
    std::unique_ptr<gui171::BoutiqueStepperButton> prevPresetBtn;
    std::unique_ptr<gui171::BoutiqueStepperButton> nextPresetBtn;
    std::unique_ptr<gui171::HeavyDutyBypassModule> bypassModule;
    std::unique_ptr<gui171::SquareConsoleButton> autoGainButton;
    std::unique_ptr<gui171::SquareConsoleButton> deltaListenButton;

    // --- Section Enable Console Buttons (Ambra Vintage) ---
    std::unique_ptr<gui171::SquareConsoleButton> gateSwitch;
    std::unique_ptr<gui171::SquareConsoleButton> preampSwitch;
    std::unique_ptr<gui171::SquareConsoleButton> deEsserSwitch;
    std::unique_ptr<gui171::SquareConsoleButton> airSwitch;
    std::unique_ptr<gui171::SquareConsoleButton> eqSwitch;
    std::unique_ptr<gui171::SquareConsoleButton> optoSwitch;
    std::unique_ptr<gui171::SquareConsoleButton> compSwitch;
    std::unique_ptr<gui171::SquareConsoleButton> doublerSwitch;

    // --- Baia 1: 171 NLS British Preamp ---
    std::unique_ptr<gui171::VintageConsolePushBank> consolePushBank;
    std::unique_ptr<gui171::AnalogStyledKnob> gateThreshKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> gateRangeKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> preampDriveKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> preampWarmthKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> preampTrimKnob;

    // --- Baia 2: 171 R-DeEsser Labs & Maag Air ---
    std::unique_ptr<gui171::AnalogStyledKnob> deEsserFreqKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> deEsserThreshKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> deEsserRangeKnob;
    juce::ComboBox deEsserModeBox;
    juce::ComboBox deEsserTypeBox;
    juce::ComboBox deEsserListenBox;
    std::unique_ptr<gui171::AnalogStyledKnob> airGainKnob;
    juce::ComboBox airFreqBox;
    std::unique_ptr<gui171::AnalogStyledKnob> deHarshThreshKnob;

    // --- Baia 3: 171 SSL 242 Oxford Console EQ ---
    std::unique_ptr<gui171::AnalogStyledKnob> hpfKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> lpfKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> hfFreqKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> hfGainKnob;
    juce::ToggleButton hfBellToggle{ "BELL" };
    std::unique_ptr<gui171::AnalogStyledKnob> hmfFreqKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> hmfGainKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> hmfQKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> lmfFreqKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> lmfGainKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> lmfQKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> lfFreqKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> lfGainKnob;
    juce::ToggleButton lfBellToggle{ "BELL" };

    // --- Baia 4: 171 CLA Dual Dynamics & Doubler ---
    std::unique_ptr<gui171::AnalogStyledKnob> optoPeakRedKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> optoGainKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> optoHiFreqKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> compInputKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> compOutputKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> compAttackKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> compReleaseKnob;
    std::unique_ptr<gui171::VintageMechanicalPushBank> compRatioPushBank;
    std::unique_ptr<gui171::SquareConsoleButton> compSCFilterSwitch;
    juce::ComboBox compRatioBox;
    juce::ComboBox compRevBox;
    std::unique_ptr<gui171::AnalogStyledKnob> compMixKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> doublerMixKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> doublerWidthKnob;

    // --- SerumV VU & Gain Reduction Meter Component (Baia 4) ---
    studio171::SerumVMeterComponent serumVMeter;

    // --- Master Section ---
    std::unique_ptr<gui171::AnalogStyledKnob> masterTrimKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> globalMixKnob;

    // --- Telemetria Smooth a 60 FPS ---
    float smoothedExpanderGR = 0.0f;
    float smoothedDeEsserGR  = 0.0f;
    float smoothedDeHarshGR  = 0.0f;
    float smoothedOptoGR     = 0.0f;
    float smoothedCompGR     = 0.0f;
    float smoothedInputPeak  = 0.0f;
    float smoothedOutputPeak = 0.0f;
    float smoothedInLUFS     = -70.0f;
    float smoothedOutLUFS    = -70.0f;

    // --- FFT Real-Time Spectrum Analyzer ---
    static constexpr int FFT_ORDER = 10;
    static constexpr int FFT_SIZE = 1 << FFT_ORDER; // 1024
    juce::dsp::FFT forwardFFT{ FFT_ORDER };
    juce::dsp::WindowingFunction<float> window{ FFT_SIZE, juce::dsp::WindowingFunction<float>::blackmanHarris };
    std::array<float, FFT_SIZE * 2> fftData{};
    std::array<float, FFT_SIZE> fifoBuffer{};
    int fifoIndex = 0;
    std::array<float, 512> spectrumPoints{};

    // Buffer di percorso persistenti per zero allocazioni heap nel thread di disegno
    juce::Path spectrumPath;
    juce::Path grCurvePath;

    void pushNextSampleIntoFifo(float sample) noexcept;
    void drawSpectrumDisplay(juce::Graphics& g, juce::Rectangle<float> bounds);
    void drawDeEsserLEDBar(juce::Graphics& g, juce::Rectangle<float> bounds);
    void drawMasterPeakMeter(juce::Graphics& g, juce::Rectangle<float> bounds);

    // --- APVTS Attachments ---
    using SliderAttachment   = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment   = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using ComboBoxAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    std::vector<std::unique_ptr<SliderAttachment>>   sliderAttachments;
    std::vector<std::unique_ptr<ButtonAttachment>>   buttonAttachments;
    std::vector<std::unique_ptr<ComboBoxAttachment>> comboAttachments;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(EasyVoiceAudioProcessorEditor)
};
