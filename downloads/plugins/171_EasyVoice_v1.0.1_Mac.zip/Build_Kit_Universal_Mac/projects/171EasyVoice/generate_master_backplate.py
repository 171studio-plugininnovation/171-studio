import math
import os
from PIL import Image, ImageDraw, ImageFont

def create_master_chassis_backplate():
    # 2x Retina scale: 1240 x 700 -> 2480 x 1400
    scale = 2
    w_px, h_px = 1240, 700
    w, h = w_px * scale, h_px * scale

    # Base dark brushed slate canvas
    img = Image.new("RGBA", (w, h), (14, 16, 22, 255))
    draw = ImageDraw.Draw(img)

    # Load high quality fonts
    try:
        font_brand = ImageFont.truetype("arialbd.ttf", 15 * scale)
        font_subbrand = ImageFont.truetype("arial.ttf", 8 * scale)
        font_bay_title = ImageFont.truetype("arialbd.ttf", 10 * scale)
        font_bay_sub = ImageFont.truetype("arial.ttf", 7 * scale)
        font_section = ImageFont.truetype("arialbd.ttf", 7 * scale)
        font_footer = ImageFont.truetype("arial.ttf", 6 * scale)
    except:
        font_brand = font_subbrand = font_bay_title = font_bay_sub = font_section = font_footer = ImageFont.load_default()

    # 1. Brushed metal texture with directional micro-grain and subtle gradient
    for y in range(h):
        ratio = y / float(h)
        noise = (math.sin(y * 0.4) * 1.5 + math.cos(y * 1.1) * 1.0)
        r = int(min(255, max(0, 16 + (1.0 - ratio) * 10 + noise)))
        g = int(min(255, max(0, 18 + (1.0 - ratio) * 10 + noise)))
        b = int(min(255, max(0, 24 + (1.0 - ratio) * 12 + noise)))
        draw.line([(0, y), (w, y)], fill=(r, g, b, 255))

    # Add fine horizontal brushed hair lines
    for y in range(0, h, 3):
        alpha = int(4 + 4 * math.sin(y * 12.345))
        draw.line([(0, y), (w, y)], fill=(255, 255, 255, alpha))

    # Outer perimeter dark drop shadow & CNC chamfer
    draw.rectangle([0, 0, w - 1, h - 1], outline=(30, 35, 48, 255), width=2 * scale)
    draw.rectangle([2 * scale, 2 * scale, w - 2 * scale - 1, h - 2 * scale - 1], outline=(8, 10, 14, 255), width=scale)

    # 2. TOP HEADER BAR (y = 0 .. 66) -> (0 .. 132 at 2x)
    head_h = 64 * scale
    draw.rectangle([0, 0, w, head_h], fill=(12, 14, 18, 255))
    # Upper specular line
    draw.line([(0, 1 * scale), (w, 1 * scale)], fill=(255, 255, 255, 30), width=scale)
    # Lower gold accent divider
    draw.line([(0, head_h - 2 * scale), (w, head_h - 2 * scale)], fill=(197, 160, 89, 70), width=scale)
    draw.line([(0, head_h - 1 * scale), (w, head_h - 1 * scale)], fill=(5, 6, 8, 255), width=scale)

    # Center Brand Title: EASY VOICE PRO
    title_x = 210 * scale
    draw.text((title_x, 14 * scale), "EASY VOICE PRO", fill=(241, 245, 249, 255), font=font_brand)
    draw.text((title_x, 38 * scale), "BOUTIQUE ALL-IN-ONE VOCAL PRODUCTION SUITE", fill=(197, 160, 89, 240), font=font_subbrand)

    # Paste 171 Studio Satin Gold Badge at Top-Left if available
    badge_path = R"C:\Users\171Studio\Desktop\171 dsp and gui engine\projects\171EasyVoice\Assets\Branding\171studio_satin_gold_badge_180x60.png"
    if os.path.exists(badge_path):
        badge_img = Image.open(badge_path).convert("RGBA")
        badge_w, badge_h = badge_img.size
        dest_h = int(46 * scale)
        dest_w = int(badge_w * (dest_h / float(badge_h)))
        badge_resized = badge_img.resize((dest_w, dest_h), Image.Resampling.LANCZOS)
        img.alpha_composite(badge_resized, (int(18 * scale), int(9 * scale)))

    # Screw helper
    def draw_phillips_screw(cx, cy, radius):
        draw.ellipse([cx - radius - scale, cy - radius - scale, cx + radius + scale, cy + radius + scale],
                     fill=(6, 8, 10, 255))
        draw.ellipse([cx - radius, cy - radius, cx + radius, cy + radius],
                     fill=(45, 50, 62, 255), outline=(75, 85, 105, 255), width=scale)
        draw.arc([cx - radius, cy - radius, cx + radius, cy + radius], start=220, end=320, fill=(200, 210, 230, 180), width=scale)
        cross_len = radius * 0.58
        for angle in [45, 135]:
            rad = math.radians(angle)
            dx = cross_len * math.cos(rad)
            dy = cross_len * math.sin(rad)
            draw.line([(cx - dx, cy - dy), (cx + dx, cy + dy)], fill=(12, 14, 18, 255), width=int(1.8 * scale))

    # Corner machine screws for outer master chassis
    outer_screws = [
        (10 * scale, 10 * scale),
        (w - 10 * scale, 10 * scale),
        (10 * scale, h - 10 * scale),
        (w - 10 * scale, h - 10 * scale)
    ]
    for sx, sy in outer_screws:
        draw_phillips_screw(sx, sy, 5 * scale)

    # 3. THE 4 MAIN HARDWARE BAYS (Coordinates perfectly matching resized() in PluginEditor.cpp)
    bay_y1 = 68 * scale
    bay_y2 = 612 * scale
    bay_h = bay_y2 - bay_y1

    bays_config = [
        {
            "id": 1,
            "x1": 18 * scale,
            "x2": 302 * scale,
            "title": "171 VINTAGE PREAMP",
            "sub": "SNOW, SPIKEPROTEIN & MAIK ANALOG CONSOLES",
            "footer": "171 AUDIO LABS · ANALOG CONSOLE COLORATION",
            "accent": (255, 32, 48, 255), # Red Neve
            "sections": [
                {"y": 102 * scale, "label": "VCA NOISE GATE"},
                {"y": 220 * scale, "label": "ANALOG CONSOLE COLORATION & DRIVE"}
            ]
        },
        {
            "id": 2,
            "x1": 310 * scale,
            "x2": 594 * scale,
            "title": "171 R-DEESSER & MAAG AIR",
            "sub": "SPLIT-BAND DYNAMICS & 40kHz RESONATOR",
            "footer": "PRECISION SIBILANCE & HARMONIC AIR MATRIX",
            "accent": (0, 213, 229, 255), # Cyan De-Ess
            "sections": [
                {"y": 102 * scale, "label": "DYNAMIC DE-ESSING"},
                {"y": 326 * scale, "label": "MAAG AIR BAND & DE-HARSH TAMER"}
            ]
        },
        {
            "id": 3,
            "x1": 602 * scale,
            "x2": 958 * scale,
            "title": "171 SUPERSOLIDLINE EQ",
            "sub": "242 4-BAND PARAMETRIC & FILTERS",
            "footer": "SUPERSOLIDLINE 4000 G-SERIES BLACK KNOB REPRODUCTION",
            "accent": (197, 160, 89, 255), # Gold SSL
            "sections": [
                {"y": 102 * scale, "label": "SUPERSOLIDLINE FILTERS & ANALYZER"},
                {"y": 236 * scale, "label": "4-BAND PARAMETRIC EQ"}
            ]
        },
        {
            "id": 4,
            "x1": 966 * scale,
            "x2": 1222 * scale,
            "title": "171 DYNAMICS",
            "sub": "DUAL 171-2A & 171-76",
            "footer": "STUDIO DUAL-STAGE 171-2A / 171-76 SERIAL COMPRESSION",
            "accent": (251, 191, 36, 255), # Amber CLA
            "sections": [
                {"y": 228 * scale, "label": "171-2A VINTAGE OPTO LIMITER"},
                {"y": 326 * scale, "label": "171-76 SOLID-STATE FET LIMITER"},
                {"y": 486 * scale, "label": "VOCAL DOUBLER & STEREO SPREAD"}
            ]
        }
    ]

    for b in bays_config:
        bx1, bx2 = b["x1"], b["x2"]
        bw = bx2 - bx1

        # Drop shadow around bay
        draw.rounded_rectangle([bx1 + scale, bay_y1 + 2 * scale, bx2 + scale, bay_y2 + 2 * scale],
                               radius=5 * scale, fill=(4, 5, 8, 160))

        # Main bay interior plate
        draw.rounded_rectangle([bx1, bay_y1, bx2, bay_y2], radius=5 * scale, fill=(16, 19, 26, 255))

        # Fine gradient within bay
        for y_sub in range(bay_y1, bay_y2):
            norm = (y_sub - bay_y1) / float(bay_h)
            sub_r = int(18 - norm * 4)
            sub_g = int(21 - norm * 4)
            sub_b = int(28 - norm * 5)
            draw.line([(bx1 + 2 * scale, y_sub), (bx2 - 2 * scale, y_sub)], fill=(sub_r, sub_g, sub_b, 120))

        # Outer CNC beveled milled border
        draw.rounded_rectangle([bx1, bay_y1, bx2, bay_y2], radius=5 * scale, outline=(55, 65, 82, 255), width=scale)
        draw.rounded_rectangle([bx1 + scale, bay_y1 + scale, bx2 - scale, bay_y2 - scale],
                               radius=4 * scale, outline=(8, 10, 14, 255), width=scale)

        # Header Title Banner Strip (height = 30px -> 60px at 2x)
        banner_h = 30 * scale
        draw.rectangle([bx1 + 2 * scale, bay_y1 + 2 * scale, bx2 - 2 * scale, bay_y1 + banner_h],
                       fill=(22, 26, 36, 255))
        draw.line([(bx1 + 2 * scale, bay_y1 + banner_h), (bx2 - 2 * scale, bay_y1 + banner_h)],
                  fill=(197, 160, 89, 90), width=scale)

        # Bay Title & Subtitle Text (left aligned, leaving space on right for toggle buttons)
        draw.text((bx1 + 10 * scale, bay_y1 + 4 * scale), b["title"], fill=(241, 245, 249, 255), font=font_bay_title)
        draw.text((bx1 + 10 * scale, bay_y1 + 18 * scale), b["sub"], fill=(148, 163, 184, 255), font=font_bay_sub)

        # Section sub-header plates (very subtle, no text clash)
        for sec in b["sections"]:
            sy = sec["y"]
            draw.line([(bx1 + 8 * scale, sy), (bx2 - 8 * scale, sy)], fill=(35, 42, 56, 180), width=scale)
            draw.text((bx1 + 10 * scale, sy + 3 * scale), sec["label"], fill=(90, 105, 128, 200), font=font_section)

        # Bay Footer Serigraphy
        footer_cx = bx1 + bw // 2
        draw.text((footer_cx - 90 * scale, bay_y2 - 14 * scale), b["footer"], fill=(65, 78, 98, 220), font=font_footer)

        # Corner Phillips screws on each bay
        screw_margin = 8 * scale
        bay_screws = [
            (bx1 + screw_margin, bay_y1 + screw_margin + 24 * scale),
            (bx2 - screw_margin, bay_y1 + screw_margin + 24 * scale),
            (bx1 + screw_margin, bay_y2 - screw_margin),
            (bx2 - screw_margin, bay_y2 - screw_margin)
        ]
        for sx, sy in bay_screws:
            draw_phillips_screw(sx, sy, int(3.5 * scale))

    # Bay 2: Recessed Bezel slot for LED meter (x: 504 .. 532, y: 132 .. 298 at 1x)
    led_x1, led_y1 = 504 * scale, 132 * scale
    led_x2, led_y2 = 532 * scale, 298 * scale
    draw.rounded_rectangle([led_x1, led_y1, led_x2, led_y2], radius=3 * scale, fill=(8, 10, 14, 255), outline=(45, 55, 72, 255), width=scale)

    # Bay 3: Recessed Bezel cutout for CRT spectrum (x: 608 .. 852, y: 108 .. 228)
    crt_x1, crt_y1 = 608 * scale, 108 * scale
    crt_x2, crt_y2 = 852 * scale, 228 * scale
    draw.rounded_rectangle([crt_x1 - scale, crt_y1 - scale, crt_x2 + scale, crt_y2 + scale], radius=4 * scale, fill=(6, 8, 12, 255))
    draw.rounded_rectangle([crt_x1, crt_y1, crt_x2, crt_y2], radius=3 * scale, fill=(9, 12, 18, 255), outline=(50, 60, 80, 255), width=scale)

    # Bay 3: Filter plate cutout (x: 858 .. 952, y: 108 .. 228)
    flt_x1, flt_y1 = 858 * scale, 108 * scale
    flt_x2, flt_y2 = 952 * scale, 228 * scale
    draw.rounded_rectangle([flt_x1, flt_y1, flt_x2, flt_y2], radius=3 * scale, fill=(12, 14, 20, 255), outline=(40, 50, 68, 255), width=scale)

    # Bay 4: Recessed Bezel cutout for Dual VU Meter (x: 972 .. 1216, y: 107 .. 225)
    vu_x1, vu_y1 = 972 * scale, 107 * scale
    vu_x2, vu_y2 = 1216 * scale, 225 * scale
    draw.rounded_rectangle([vu_x1 - scale, vu_y1 - scale, vu_x2 + scale, vu_y2 + scale], radius=5 * scale, fill=(6, 7, 10, 255))
    draw.rounded_rectangle([vu_x1, vu_y1, vu_x2, vu_y2], radius=4 * scale, fill=(18, 20, 26, 255), outline=(60, 72, 92, 255), width=scale)

    # 4. MASTER FOOTER BAR (y = 618 .. 700) -> (1236 .. 1400 at 2x)
    foot_y1 = 618 * scale
    foot_y2 = h - 2 * scale
    draw.rectangle([0, foot_y1, w, foot_y2], fill=(12, 14, 18, 255))
    draw.line([(0, foot_y1), (w, foot_y1)], fill=(197, 160, 89, 70), width=scale)
    draw.line([(0, foot_y1 + scale), (w, foot_y1 + scale)], fill=(5, 6, 8, 255), width=scale)

    # Master Meter Slot (x = 248 .. 924, y = 630 .. 672)
    meter_x1, meter_y1 = 248 * scale, 630 * scale
    meter_x2, meter_y2 = 924 * scale, 672 * scale
    draw.rounded_rectangle([meter_x1, meter_y1, meter_x2, meter_y2], radius=4 * scale, fill=(8, 10, 14, 255), outline=(45, 55, 75, 255), width=scale)

    # Right side luxury brand footer: 171 PLUGIN INNOVATION
    right_x = 948 * scale
    draw.text((right_x, foot_y1 + 14 * scale), "171 PLUGIN INNOVATION", fill=(212, 175, 55, 240), font=font_brand)
    draw.text((right_x, foot_y1 + 36 * scale), "HIGH-PRECISION HARDWARE DSP ENGINE · 60 FPS ZERO HEAP ALLOCATIONS", fill=(148, 163, 184, 200), font=font_subbrand)

    # Save output to both project Assets and CleanDrive shared assets
    target_paths = [
        R"C:\Users\171Studio\Desktop\171 dsp and gui engine\projects\171EasyVoice\Assets\Faceplates\Master_Chassis_Backplate_171EasyVoice_2480x1400.png",
        R"C:\Users\171Studio\Desktop\171 dsp and gui engine\projects\171CleanDrive\Source\GUI\Assets\Faceplates\Master_Chassis_Backplate_171EasyVoice_2480x1400.png"
    ]

    for p in target_paths:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        img.save(p, "PNG")
        print(f"[+] Clean Master Chassis Backplate generated at: {p} ({w}x{h})")

if __name__ == "__main__":
    create_master_chassis_backplate()
