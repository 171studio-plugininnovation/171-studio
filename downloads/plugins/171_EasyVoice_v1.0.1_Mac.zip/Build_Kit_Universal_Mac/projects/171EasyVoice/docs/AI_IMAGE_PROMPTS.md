# 171EasyVoice Pro — AI Image Prompt Suite
**Autore:** Agente 26 (`ai-image-prompt-specialist`)  
**Data:** 27 Ottobre 2026  
**Versione:** 1.0.0 Hardware Prompt Archive  
**Target Engine:** Midjourney v6.1, Flux.1 Pro / Dev, Stable Diffusion XL

---

## 1. Linea Guida Stilistica Globale
Tutti i prompt seguono la formula fotorealistica PBR della suite boutique *171 Music Innovation*:
- **Illuminazione**: Fotografia di prodotto da studio 5000K, luce radente morbida (rim light), riflessi speculari metallici su alluminio spazzolato e ottone tornito.
- **Materiali**: Metallo fuso pesante, bachelite scura lavorata al tornio, incisioni laser bianche/avorio leggermente incassate, lenti convesse in vetro con polarizzazione antiriflesso.
- **Profondità di Campo**: Macro fotografia F/8 per garantire nitidezza totale dei dettagli superficiali, micro-graffi vintage e finitura anodizzata.

---

## 2. Specifiche dei Prompt per Asset Chiave

### Asset #1: Quadrante VU Meter "DUAL DYNAMICS GR" (1024x765 px)
*Descrizione: Quadrante vintage graduato per Gain Reduction con duplice indicazione di compressione ottica LA-2A e FET 1176.*

#### A. Midjourney v6.1 Prompt
```text
close-up macro product shot of a vintage analog dual VU meter faceplate for audio compressor, heavy cream-aged textured parchment paper dial background, precision engraved curved scale arcs ranging from 0 dB on right down to minus 30 dB on left, finely printed black numbers "0, 1, 3, 5, 7, 10, 15, 20, 30", subtle elegant golden serif lettering reading "DUAL GAIN REDUCTION: OPTO & FET", warm amber 3200K incandescent filament backlighting emitting a soft gentle glow, pristine studio lighting, zero needle, ultra-sharp 8k resolution, authentic 1970s Abbey Road console meter aesthetic, clean transparent bezel overlay area --ar 4:3 --v 6.1 --style raw --q 2
```

#### B. Flux.1 Pro Prompt
```text
A hyperrealistic front-facing studio photograph of a vintage 1970s dual gain-reduction VU meter dial face. The dial plate is made of aged cream cardstock with subtle fibrous texture. Sharp black silkscreen arc calibration marks indicating decibels from 0 down to -30 dB. Minimalist typography reading "171 AUDIO INNOVATION - DUAL DYNAMICS". Warm 3200K tungsten lamp glow illuminating the upper curved portion of the dial from behind. Crisp contrast, photorealistic product render, 8k resolution, no shadows, orthographic perspective.
```

---

### Asset #2: Bezel Massiccio in Fusione Metallica con 4 Viti (1024x765 px)
*Descrizione: Cornice esterna in ghisa brunita/gunmetal con viti Phillips per il montaggio su rack.*

#### A. Midjourney v6.1 Prompt
```text
front-view isolated industrial studio shot of a heavy cast-metal rectangular VU meter bezel frame, dark gunmetal antique bronze finish, brushed and slightly weathered metal bevels, four authentic Philips head steel screws securely fastened in the four rounded corners, perfectly transparent hollow center opening for meter glass, subtle metallic reflections and specular highlights along the outer chamfered rim, pure white background for easy alpha masking, hyperrealistic 8k product photography --ar 4:3 --v 6.1 --style raw --q 2
```

---

### Asset #3: Ago Galvanometrico Vermiglio con Calotta in Ottone
*Descrizione: Lancetta ultra-sottile galvanometrica con punta rosso vivo e perno rifinito al tornio.*

#### A. Midjourney v6.1 Prompt
```text
isolated macro shot of a single ultra-fine mechanical galvanometric meter needle, slender tapered black matte aluminum arm, precision vibrant vermilion red painted pointer tip, knurled cylindrical brass hub pivot cap at the base, perfectly sharp silhouette against a pure solid green background, zero motion blur, studio lighting catching a hairline reflection along the needle edge, 8k resolution --ar 1:4 --v 6.1 --style raw
```

---

### Asset #4: Capsula OptoCell T4B in Alluminio Tornito (128x128 px)
*Descrizione: Cilindro schermato per la cella fotoelettrica ottica del compressore LA-2A con logo cesellato.*

#### A. Midjourney v6.1 Prompt
```text
macro studio product shot of a cylindrical vintage T4B electro-optical attenuator canister, spun brushed aluminum metal casing with engraved vintage stamp "171 AUDIO LABS T4B-OPTO", soft orange electroluminescent amber glow leaking gently from small perforated base vents, photorealistic metal grain, studio rim light, isolated on dark gray background --ar 1:1 --v 6.1 --style raw
```

---

### Asset #5: Targa Serigrafata "171 EASY VOICE PRO" Incisa al Laser (480x120 px)
*Descrizione: Targhetta di identificazione per la fascia superiore dello chassis in alluminio spazzolato scuro.*

#### A. Midjourney v6.1 Prompt
```text
front view macro shot of a luxury vintage audio hardware faceplate nameplate, dark brushed titanium plate with crisp laser-engraved golden lettering reading "171 EASY VOICE PRO - BOUTIQUE VOCAL CHANNEL STRIP", bevelled brass edge perimeter, two miniature countersunk screws on far left and far right, soft studio softbox illumination, ultra-realistic mechanical texture --ar 4:1 --v 6.1 --style raw
```
