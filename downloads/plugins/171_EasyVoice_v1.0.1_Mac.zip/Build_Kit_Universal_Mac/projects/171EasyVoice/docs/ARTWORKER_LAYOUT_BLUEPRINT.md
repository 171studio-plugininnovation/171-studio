# 171EasyVoice Pro — Artworker Layout Blueprint
**Autore:** Agente 25 (`gui-artworker`)  
**Data:** 27 Ottobre 2026  
**Versione:** 1.0.0 Pixel-Perfect Blueprint  
**Destinatari:** Agente 27 (`juce-gui-implementer`), Chief Architect

---

## 1. Specifiche del Canvas & Griglia Geometrica
- **Dimensioni Finestra Principale**: `1080 x 640 px`
- **Finitura Perimetrale**: Pannello ottone massiccio cesellato (`paintBoutiqueBrassPanel`) con bordo smussato di `12 px`.
- **Viti da Rack Angolari**: 4 viti Phillips a croce (`Screw_Phillips_BoutiqueCorner_TL_64x64.png`) posizionate a:
  - Top-Left: `(6, 6, 28, 28)`
  - Top-Right: `(1046, 6, 28, 28)`
  - Bottom-Left: `(6, 606, 28, 28)`
  - Bottom-Right: `(1046, 606, 28, 28)`
- **Griglia di Ventilazione Chassis**: `(252, 14, 130, 22)`
- **Altezza Baie Hardware (Y)**: `bayY = 56 px`, `bayH = 512 px`
- **Separatori in Ottone tra le Baie**: Linee verticali cesellate a `X = 266`, `X = 520`, `X = 824` da `Y = 60` a `Y = 564`.

---

## 2. Tabella Coordinate Pixel-Perfect per Componente

### A. Top Bar (Header & Global Controls)
| Controllo | ID Componente | X (px) | Y (px) | Larghezza (px) | Altezza (px) | Note Grafiche |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Titolo Plugin** | Label Branding | 42 | 10 | 210 | 20 | Oro caldo 17pt bold |
| **Sottotitolo** | Label Subtitle | 42 | 30 | 480 | 14 | Ottone brunito 9.5pt bold |
| **Preset Dropdown** | `presetBox` | 365 | 10 | 290 | 28 | Titanio + oro, popup 8 preset |
| **Smart Gain Auto** | `autoGainButton` | 670 | 8 | 110 | 32 | Console button ambra |
| **Delta Audition** | `deltaListenButton`| 790 | 8 | 125 | 32 | Console button ambra |
| **Bypass Switch** | `bypassModule` | 926 | 6 | 38 | 38 | Levetta metallica boutique |

---

### B. Baia 1: Gate & Neve 1073 Preamp (`X: 16`, `W: 246`)
| Controllo | Parametro APVTS | X (px) | Y (px) | Larghezza (px) | Altezza (px) | Scala / Stile Manopola |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Gate In/Out** | `gateEnable` | 184 | 57 | 72 | 26 | Pulsante rettangolare ambra |
| **Gate Threshold**| `gateThresh` | 26 | 92 | 105 | 80 | Gunmetal 128x128, ring celeste |
| **Gate Range** | `gateRange` | 142 | 92 | 105 | 80 | Gunmetal 128x128, ring celeste |
| **Preamp In/Out** | `preampEnable` | 184 | 184 | 72 | 26 | Pulsante rettangolare ambra |
| **Neve Drive** | `preampDrive` | 55 | 218 | 168 | 128 | **Macro Teardrop Collet Gold** |
| **Warmth (THD)** | `preampWarmth` | 40 | 356 | 120 | 94 | Teardrop collet oro/rosso |
| **Pre Trim** | `preampTrim` | 146 | 446 | 105 | 86 | Gunmetal 128x128, scala dB |

---

### C. Baia 2: Renaissance De-Esser & Maag Air Band (`X: 270`, `W: 246`)
| Controllo | Parametro APVTS | X (px) | Y (px) | Larghezza (px) | Altezza (px) | Scala / Stile Manopola |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **De-Ess In/Out** | `deEsserEnable` | 438 | 57 | 72 | 26 | Pulsante rettangolare ambra |
| **De-Ess Freq** | `deEsserFreq` | 280 | 92 | 78 | 68 | Gunmetal 128x128, ring ambra |
| **Threshold** | `deEsserThresh` | 362 | 92 | 78 | 68 | Gunmetal 128x128, ring ambra |
| **Range** | `deEsserRange` | 280 | 166 | 78 | 68 | Gunmetal 128x128, ring ambra |
| **Mode Box** | `deEsserMode` | 362 | 168 | 78 | 22 | Split-Band / Wideband |
| **Type Box** | `deEsserType` | 362 | 194 | 78 | 22 | Bell SC / High-Pass SC |
| **Listen Box** | `deEsserListen` | 362 | 220 | 78 | 22 | Audio / Sidechain / Delta |
| **LED Bar GR** | *Visualizer* | 446 | 94 | 20 | 160 | 16 segmenti LED ambra/rosso |
| **Air In/Out** | `airEnable` | 438 | 276 | 72 | 26 | Pulsante rettangolare ambra |
| **Air Gain** | `airGain` | 300 | 312 | 130 | 105 | **Teardrop Collet Cyan Neon** |
| **Air Frequency**| `airFreq` | 325 | 424 | 85 | 24 | 2.5k / 5k / 10k / 20k / 40k |
| **De-Harsh Thresh**|`deHarshThresh` | 300 | 458 | 130 | 94 | Gunmetal 128x128, ring cyan |

---

### D. Baia 3: SSL 4000 G EQ & FFT Real-Time (`X: 524`, `W: 296`)
| Controllo | Parametro APVTS | X (px) | Y (px) | Larghezza (px) | Altezza (px) | Scala / Stile Manopola |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **EQ In/Out** | `eqEnable` | 742 | 57 | 72 | 26 | Pulsante rettangolare ambra |
| **FFT Display** | *Visualizer* | 536 | 92 | 272 | 88 | Display CRT logaritmico |
| **HPF Freq** | `hpfFreq` | 534 | 190 | 70 | 58 | Gunmetal, scala 16-350 Hz |
| **LPF Freq** | `lpfFreq` | 610 | 190 | 70 | 58 | Gunmetal, scala 3-22 kHz |
| **HF Freq** | `hfFreq` | 534 | 256 | 68 | 56 | Gunmetal, ring rosso carminio |
| **HF Gain** | `hfGain` | 608 | 256 | 68 | 56 | Gunmetal, ring rosso carminio |
| **HF Bell** | `hfType` | 684 | 272 | 56 | 20 | Toggle button retroilluminato |
| **HMF Freq** | `hmfFreq` | 534 | 320 | 66 | 54 | Gunmetal, ring verde smeraldo |
| **HMF Gain** | `hmfGain` | 606 | 320 | 66 | 54 | Gunmetal, ring verde smeraldo |
| **HMF Q** | `hmfQ` | 678 | 320 | 66 | 54 | Gunmetal, ring verde smeraldo |
| **LMF Freq** | `lmfFreq` | 534 | 382 | 66 | 54 | Gunmetal, ring blu cobalto |
| **LMF Gain** | `lmfGain` | 606 | 382 | 66 | 54 | Gunmetal, ring blu cobalto |
| **LMF Q** | `lmfQ` | 678 | 382 | 66 | 54 | Gunmetal, ring blu cobalto |
| **LF Freq** | `lfFreq` | 534 | 444 | 68 | 56 | Gunmetal, ring ambra caldo |
| **LF Gain** | `lfGain` | 608 | 444 | 68 | 56 | Gunmetal, ring ambra caldo |
| **LF Bell** | `lfType` | 684 | 460 | 56 | 20 | Toggle button retroilluminato |

---

### E. Baia 4: Dual Dynamics & Vocal Doubler (`X: 828`, `W: 236`)
| Controllo | Parametro APVTS | X (px) | Y (px) | Larghezza (px) | Altezza (px) | Scala / Stile Manopola |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **LA-2A In/Out** | `optoEnable` | 918 | 57 | 68 | 26 | Pulsante rettangolare ambra |
| **1176 In/Out** | `compEnable` | 990 | 57 | 68 | 26 | Pulsante rettangolare ambra |
| **DUAL VU METER**| *Visualizer* | **834** | **90** | **224** | **110** | **Bezel 4 Viti, Clean Dial, 2 Aghi** |
| **T4B OptoCell** | *Visualizer* | 1008 | 150 | 44 | 44 | Capsula metallica con glow |
| **LA-2A Peak Red**| `optoPeakRed` | 836 | 208 | 108 | 84 | Teardrop collet oro/ambra |
| **LA-2A Gain** | `optoGain` | 948 | 208 | 108 | 84 | Teardrop collet oro/ambra |
| **1176 Input** | `compInput` | 834 | 300 | 56 | 54 | Gunmetal scanalato bianco |
| **1176 Output** | `compOutput` | 892 | 300 | 56 | 54 | Gunmetal scanalato bianco |
| **1176 Attack** | `compAttack` | 950 | 300 | 54 | 54 | Gunmetal scanalato bianco |
| **1176 Release** | `compRelease` | 1006 | 300 | 54 | 54 | Gunmetal scanalato bianco |
| **1176 Ratio** | `compRatio` | 836 | 362 | 106 | 22 | 4:1 / 8:1 / 12:1 / 20:1 / ALL |
| **1176 Revision** | `compRev` | 948 | 362 | 114 | 22 | Blackface Rev E / Blue Stripe Rev A |
| **1176 Parallel** | `compMix` | 836 | 392 | 70 | 64 | Gunmetal scanalato bianco |
| **Doubler In/Out**| `doublerEnable`| 984 | 396 | 74 | 26 | Pulsante rettangolare ambra |
| **Doubler Mix** | `doublerMix` | 836 | 462 | 108 | 84 | Gunmetal con ring cyan |
| **Doubler Width** | `doublerWidth` | 948 | 462 | 108 | 84 | Gunmetal con ring cyan |

---

### F. Master Footer (`Y: 574` a `636`)
| Controllo | Parametro APVTS | X (px) | Y (px) | Larghezza (px) | Altezza (px) | Note Grafiche |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Global Mix** | `globalMix` | 26 | 572 | 90 | 64 | Teardrop Bronze Gold |
| **Master Trim** | `masterTrim` | 120 | 572 | 90 | 64 | Teardrop Bronze Gold |
| **Peak / LUFS Bar**| *Visualizer* | 360 | 582 | 420 | 44 | Barra gradiente verde->rosso |
| **Sigillo Studio**| Label | 840 | 592 | 200 | 24 | "171 AUDIO INNOVATION" |
