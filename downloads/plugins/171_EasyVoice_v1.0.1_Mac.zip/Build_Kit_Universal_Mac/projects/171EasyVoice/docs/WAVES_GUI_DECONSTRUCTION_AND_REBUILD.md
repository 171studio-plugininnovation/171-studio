# Decomposizione, Scorporamento & Ricostruzione GUI: Ispirazione Waves
## Moduli di Riferimento: Waves NLS, SSL G-Channel, Renaissance DeEsser, CLA-2A & CLA-76
**Plugin Target:** `171EasyVoice Pro` (Boutique Vocal Channel Strip)  
**Brand Identificativo Obbligatorio:** **171 Audio Innovation**  
**Data:** 27 Ottobre 2026  
**Autore:** Agente 24 (`gui-art-director`), Agente 25 (`gui-artworker`), Agente 27 (`juce-gui-implementer`)

---

## 1. Analisi Comparativa & Scorporamento dei 4 Moduli Waves

### A. Modulo 1: Waves NLS (Nev / British Channel Strip)
*Ispirazione: Banco di missaggio Neve 5116 / preamplificatore vintage 1073 (Mike Hedges / Abbey Road)*

| Elemento Originale Waves NLS | Decomposizione Visiva & Funzionale | Ricostruzione Boutique nel Motore 171 |
| :--- | :--- | :--- |
| **Finitura Chassis** | Alluminio verniciato in classico blu-grigio britannico opaco (*British RAF Blue-Gray*), con micro-graffi e finitura anodizzata. | Baia 1 rifinita con telaio in acciaio spazzolato e piastra Neve blu scuro satinato (`#1a2232`), con bordi beveled cesellati e 2 viti di montaggio. |
| **Controllo Drive** | Manopola centrale in bachelite nera con colletto godronato argentato e vite a brugola di bloccaggio. Scala 0..10 con tacche serigrafate. | Macro-knob Teardrop Collet con ghiera in ottone dorato 171 e scala circolare calibrata in dB (`Knob_Teardrop_Pointer_Collet_171Studio_GoldRim_128x128.png`). |
| **Commutatore Mic/Line / Amp Mode** | Commutatore rotativo stepped a scatti marcati per il tipo di amplificatore. | Selettore rotativo Neve Mode con feedback visivo e tasto console retroilluminato in ambra. |
| **Output Trim & THD Warmth** | Manopola secondaria per il bilanciamento del guadagno post-saturazione. | Controlli dedicati `WARMTH` (saturazione armonica di 2ª e 3ª) e `PRE TRIM` (-12..+12 dB) in finitura gunmetal. |
| **Branding Serigrafato** | Logo Waves NLS Channel in bianco incassato. | **Targa Ufficiale Incisa al Laser: "171 NLS BRITISH PREAMP" con stemma 171 dorato.** |

---

### B. Modulo 2: Waves Renaissance DeEsser (R-DeEsser)
*Ispirazione: De-Esser professionale ad alta trasparenza della serie Renaissance con display a curva dinamica*

| Elemento Originale Waves R-DeEsser | Decomposizione Visiva & Funzionale | Ricostruzione Boutique nel Motore 171 |
| :--- | :--- | :--- |
| **Display Grafico Crossover** | Finestra rettangolare centrale color grafite scuro con asse delle frequenze ($1\text{ kHz} - 16\text{ kHz}$), curva di taglio con banda sibilante ombreggiata in oro/ambra e linea verticale mobile per la Crossover Frequency. | **Display Interattivo R-DeEsser 171**: Schermo con cornice in titanio brunito, visualizzazione in tempo reale dello spettro di frequenza vocale, linea di frequenza sibilante con marker dorato a freccia e campana/shelf evidenziata in ambra trasparente luminescente. |
| **Selettore Split / Wide** | Tasto per alternare tra attenuazione chirurgica della sola banda alta (*Split-Band*) e ducking a banda intera (*Wideband*). | Dropdown e pulsante `Split-Band` vs `Wideband` con retroilluminazione analogica ambra calda. |
| **Sidechain Filtering (Bell / High-Pass)** | Scelta tra filtro passa-alto tradizionale e campana selettiva centrata sul picco sibilante. | Selettore `Bell SC` / `High-Pass SC` con pendenza 12 dB/ottava. |
| **Ascolto Monitor (Audio / SideChain / Diff)** | Modalità per ascoltare solo la distorsione rimossa (*Diff/Delta*). | Switch dedicati e pulsante Top-Bar `DELTA AUDITION` per isolare esattamente le sibilanti eliminate. |
| **Indicatore Gain Reduction** | LED bar verticale ad alta risoluzione con segmenti luminosi color ambra e rosso da 0 a -24 dB. | **LED Meter Bar Hardware 171**: 16 segmenti LED fisici a risposta rapida (con persistenza di picco) graduati da 0 a -24 dB. |
| **Branding Serigrafato** | Logo Renaissance dorato su fondo titanio. | **Targa Serigrafata: "171 R-DEESSER LABS - SIBILANCE SUPPRESSOR".** |

---

### C. Modulo 3: Waves SSL G-Channel (4000 G Console Strip)
*Ispirazione: La leggendaria console britannica SSL 4000 G-Series con l'equalizzatore "Black Knob" 242*

| Elemento Originale Waves SSL G-Channel | Decomposizione Visiva & Funzionale | Ricostruzione Boutique nel Motore 171 |
| :--- | :--- | :--- |
| **Finitura Console Strip** | Finitura grigio ardesia scura (*Oxford Dark Slate*) con linee divisorie sottili tra le sezioni. | Baia 3 con finitura grafite scura spazzolata (`#12151d`), cornici perimetrali beveled e separatori in ottone massiccio. |
| **Bande EQ "Black Knob" 242** | Manopole nere scanalate con calotte colorate secondo il codice originale SSL: <br/>• **HF**: Rosso <br/>• **HMF**: Verde <br/>• **LMF**: Blu <br/>• **LF**: Marrone/Ambra. | **Knob Set 242 Ufficiale 171**: Manopole gunmetal con calotta e indicatori LED ring identici alla console originale: <br/>• HF: `#ef4444` (Rosso carminio) <br/>• HMF: `#10b981` (Verde smeraldo) <br/>• LMF: `#3b82f6` (Blu cobalto) <br/>• LF: `#f59e0b` (Ambra caldo). |
| **Pulsanti "BELL" HF e LF** | Pulsanti push quadrati retroilluminati che commutano lo shelving in curva a campana. | Toggle button illuminati a giorno per HF Bell e LF Bell. |
| **Sezione Filtri Indipendenti** | HPF (18 dB/oct) e LPF (12 dB/oct) canna di fucile con grande escursione. | Manopole dedicate `HPF` ($16 - 350\text{ Hz}$) e `LPF` ($3 - 22\text{ kHz}$) in alluminio satinato. |
| **Analizzatore di Spettro** | Integrato in versione moderna con curva EQ in overlay. | Schermo CRT antiriflesso a fosfori verdi a 60 FPS con curva spettrale FFT e indicazione continua delle formanti. |
| **Branding Serigrafato** | Logo SSL G-Channel. | **Targa Serigrafata: "171 SSL 242 OXFORD CONSOLE EQ".** |

---

### D. Modulo 4: Waves CLA-2A & CLA-76 (Compressori Dinamici)
*Ispirazione: I due compressori vocali più usati della storia della musica, modellati con Chris Lord-Alge*

| Elemento Originale Waves CLA-2A / CLA-76 | Decomposizione Visiva & Funzionale | Ricostruzione Boutique nel Motore 171 |
| :--- | :--- | :--- |
| **CLA-2A: Frontale Teletronix & Macro-Knobs** | Frontale argentato/grigio bicolore con le grandi manopole `GAIN` e `PEAK REDUCTION` numerate 0..100 con scala ad arco continuo. | Macro-knob Teardrop collet oro/ambra (`optoPeakRedKnob` e `optoGainKnob`) con scale serigrafate calibrate 0..100. |
| **CLA-2A: Cella Elettro-Ottica T4B** | Canestro metallico schermato forato con lampada al neon arancione che pulsa. | Asset fotorealistico `OptoCell_T4B_171AudioLabs_Canister_128x128.png` con bagliore ottico dinamico modulato in tempo reale dal Gain Reduction. |
| **CLA-76: Frontale Blackface / Blue Stripe** | Chassis in alluminio spazzolato nero o con striscia blu, manopole Input/Output, Attack/Release ultra-rapide e tasti Ratio. | Manopole micrometriche scanalate bianche, selettore `Rev E Blackface` vs `Rev A Blue Stripe`, e commutatore `Ratio` con modalità British `ALL BUTTONS IN`. |
| **VU Meter Analogico a Specchio** | Grande quadrante analogico illuminato con ago galvanometrico reattivo per visualizzare il Gain Reduction. | **Master Dual VU Meter 171**: Bezel in fusione di ghisa a 4 viti, quadrante Gain Reduction Master ad alta risoluzione logato **171 AUDIO INNOVATION**, retroilluminazione calda 3200K lampada al tungsteno, doppio ago analogico con balistica reale differenziata (Opto ambra lento + FET vermiglio rapido) e vetro curvo antiriflesso. |
| **Branding Serigrafato** | Loghi CLA-2A e CLA-76. | **Targa Serigrafata: "171 CLA-2A & 171 CLA-76 DUAL DYNAMICS".** |

---

## 2. Standard di Branding Obbligatorio "171"

Tutti i nuovi componenti visivi implementati nel motore e renderizzati a video incorporano il marchio **171**:
1. **Header Top Bar**: `"171 EASY VOICE PRO"` in lettere dorate cesellate + stemma `"171 AUDIO INNOVATION"`.
2. **Baia 1**: `"171 NLS BRITISH PREAMP"` inciso al laser sopra la manopola Neve Drive.
3. **Baia 2**: `"171 R-DEESSER LABS"` inciso sopra il display crossover interattivo.
4. **Baia 3**: `"171 SSL 242 OXFORD CONSOLE"` serigrafato sulla testata del canale EQ.
5. **Baia 4**: `"171 DUAL DYNAMICS (CLA-2A + 1176)"` serigrafato sopra il Dual VU Meter, con stemma centrale 171 inciso sulla piastra del quadrante.
6. **Footer Master**: Sigillo ufficiale `"171 AUDIO INNOVATION · BOUTIQUE HARDWARE LABS"`.
