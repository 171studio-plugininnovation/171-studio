# 171EasyVoice Pro — Visual Style Guide
**Autore:** Agente 24 (`gui-art-director`)  
**Data:** 27 Ottobre 2026  
**Versione:** 1.0.0 Boutique Hardware Edition  
**Destinatari:** Agente 25 (`gui-artworker`), Agente 26 (`ai-image-prompt-specialist`), Agente 27 (`juce-gui-implementer`)

---

## 1. Visione Artistica & Coerenza di Suite
**171EasyVoice Pro** è il channel strip vocale definitivo della suite analogica *171 Music Innovation*. Il design visivo incarna l'estetica dei grandi banchi da studio britannici e americani degli anni '70 e '80, fusi con l'eleganza boutique in ottone cesellato e metallo massiccio che caratterizza `171CleanDrive`, `171DriveOptocom` e `171RealTune`.

L'interfaccia deve comunicare immediatamente:
1. **Solidità Meccanica**: Telai in fusione metallica, viti a croce Phillips brunite agli angoli, manopole godronate con colletto dorato e perno tornito.
2. **Precisione di Calibrazione**: Scale serigrafiche ad arco bianco e avorio su fondo alluminio anodizzato scuro.
3. **Calore Analogico Dinamico**: Bagliore ottico della cella T4B in incandescenza reale, retroilluminazione al tungsteno a 3200K per il VU meter, e LED console ambrati soffusi.

---

## 2. Palette Cromatica Ufficiale delle Baie Hardware

L'architettura dello strip vocale è suddivisa in **4 Baie Operative Hardware** incassate in un telaio portante in ottone boutique (`paintBoutiqueBrassPanel`), più le sezioni di Header e Master Footer.

| Baia | Modulo Audio | Colore Primario (HEX) | JUCE Colour | Tinta Accento / Retroilluminazione | Ispirazione Hardware |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Chassis** | Struttura Principale | `#8B6914` / `#5C4410` | `0xff8b6914` | Ottone cesellato / Bronzo brunito | Console Boutique Custom 1978 |
| **Baia 1** | Gate & Neve 1073 Preamp | `#60A5FA` / `#EF4444` | `0xff60a5fa` / `0xffef4444` | Vintage British Blue-Gray & Neve Red Drive | Neve 1073 / NLS British Console |
| **Baia 2** | De-Esser & Maag Air EQ | `#00D5E5` / `#F59E0B` | `0xff00d5e5` / `0xfff59e0b` | Cyan Silk Neon & Warm Amber OLED | Maag Audio EQ4 Air Band + Waves R-DeEsser |
| **Baia 3** | SSL 4000 G EQ & FFT | `#10B981` / `#CBD5E1` | `0xff10b981` / `0xffcbd5e1` | Oxford Emerald & Black 242 Classic Caps | SSL 4000 G-Series Black Knob (242 EQ) |
| **Baia 4** | Dual Dynamics & Doubler | `#FBBF24` / `#DC2626` | `0xfffbbf24` / `0xffdc2626` | Teletronix Amber Opto + 1176 Crimson FET | Teletronix LA-2A + UREI 1176LN Peak Limiter |
| **Master** | Output, Mix & LUFS Bar | `#D4AF37` / `#94A3B8` | `0xffd4af37` / `0xff94a3b8` | Imperial Studio Gold & Precision Titanium | BS.1770-4 EBU R128 Master Section |

### Dettaglio Tonalità per Baia:
1. **Baia 1 (Gate & Neve Preamp)**:
   - Sfondo baia: Alluminio scuro spazzolato `#141720` con satinatura verticale.
   - Knob Gate: Alluminio diamantato gunmetal con LED ring azzurro cielo (`#60a5fa`).
   - Knob Neve Drive: Colletto in bachelite tornita con bordo dorato (`Knob_Teardrop_Pointer_Collet_171Studio_GoldRim_128x128.png`) e indicatore rosso fuoco (`#ff2030`).
   - Pulsanti Console: Ambra vintage (`Button_Console_Square_Blank_Amber_Lit_ON_128x128.png`).

2. **Baia 2 (Renaissance De-Esser & Maag Air Band)**:
   - Sfondo baia: Grafite profonda `#12151c`.
   - LED Bar De-Esser: Segmenti graduati da -1 dB (ambra morbido `#f59e0b`) fino a -24 dB (ambra profondo `#b45309`).
   - Knob Maag Air: Teardrop bronze con anello cyan fluorescente (`#00d5e5`) per evocare la brillantezza della banda a 40 kHz.
   - Dropdown ComboBox: Titanio scuro con cornice in ottone cesellato e chevron dorato (`Studio171ComboBoxLookAndFeel`).

3. **Baia 3 (SSL 4000 G 4-Band EQ & Real-Time Spectrum)**:
   - Sfondo baia: Telaio nero anodizzato SSL `#0d0f15`.
   - Schermo FFT: Finestra CRT antiriflesso con griglia logaritmica serigrafica e curva spettrale smeraldo fosforoso (`#10b981`) a risposta rapida.
   - Manopole EQ codificate per banda originale SSL:
     - HPF/LPF: Cappuccio canna di fucile (`#cbd5e1`)
     - HF: Rosso carminio (`#ef4444`)
     - HMF: Verde Oxford (`#10b981`)
     - LMF: Blu cobalto (`#3b82f6`)
     - LF: Ambra dorata (`#f59e0b`)

4. **Baia 4 (Dual Dynamics: LA-2A Opto + 1176 FET)**:
   - Centro focale del plugin.
   - **Doppio Indicatore VU Meter Fotorealistico**: Bezel in fusione metallica a 4 viti con doppio ago e quadrante vintage Gain Reduction.
   - OptoCell T4B: Cilindro metallico con incandescenza luminescente ambra modulata in tempo reale dalla riduzione di guadagno dell'opto.
   - Manopole LA-2A: Manopole collet vintage bronze per Peak Reduction e Gain.
   - Manopole 1176: Manopole alluminio scanalate ad alta precisione (Input, Output, Attack, Release).

---

## 3. Specifiche Tecniche del Dual VU Meter Fotorealistico

### A. Elementi Visivi & Layering Grafico
Il Dual VU Meter non è un rendering sintetico con primitive grafiche `drawLine`, ma un assemblato composito a 5 layer fisici:
1. **Layer 1 (Sfondo Quadrante Calibrato)**:  
   Asset: `Display_VU_Meter_Dial_GainReduction_Clean_Master_1024x765.png`.  
   Scala ad arco serigrafata da **0 dB (riposo a destra)** fino a **-20 dB / -30 dB (piena compressione a sinistra)**.
2. **Layer 2 (Retroilluminazione e Lampada Ruby)**:  
   Asset: `Meter_Sweeper_VintageRadio_IlluminatedRuby_512x383.png` in overlay additivo a bassa opacità per simulare la luce calda della lampadina pilota retro-quadrante.
3. **Layer 3 (Ago 1: LA-2A Opto)**:  
   Ago dorato/ambrato (`#d97706` con ombra portata analogica sfalsata di +2.5px, +3.5px).  
   Balistica ottica: Risposta lenta e vellutata (Release T4B multi-fase: 60ms iniziale, poi fino a 2 secondi per il recupero completo).
4. **Layer 4 (Ago 2: 1176 FET)**:  
   Asset: `Meter_Needle_VintageRedTip_IsolatedSprite.png` (punta rosso vivo vermiglio `#c5221f`).  
   Balistica FET: Risposta ultra-rapida (20µs - 800µs attack) con leggero overshoot meccanico realistico (1.5%).
5. **Layer 5 (Bezel in Fusione Metallica)**:  
   Asset: `Display_VU_Meter_Bezel_CastMetal_4Screws_Master_1024x765.png`.  
   Cornice massiccia con 4 viti angolari a stella e riflessi speculari metallici.
6. **Layer 6 (Vetro Curvo Antiriflesso con Riflessi di Studio)**:  
   Asset: `Display_VU_Meter_171Studio_GlassOverlay_570x281.png`.  
   Riflesso satinato polarizzato che conferisce profondità ottica 3D.

### B. Calibrazione Geometrica e Coordinate di Rotazione
- **Dimensioni Quadrante Master**: 1024 x 765 px (proporzione 4:3).
- **Pivot Centrale**:  
  \(CX = 52.913\%\) della larghezza del quadrante.  
  \(CY = 66.769\%\) dell'altezza del quadrante.
- **Deflessione Angolare Gain Reduction**:  
  - Riposo a \(0\text{ dB}\): \(+34.50^\circ\) (\(+0.602\text{ rad}\), a destra).  
  - Riduzione di \(-5\text{ dB}\): \(+12.00^\circ\) (\(+0.209\text{ rad}\)).  
  - Riduzione di \(-10\text{ dB}\): \(-4.50^\circ\) (\(-0.078\text{ rad}\)).  
  - Riduzione di \(-20\text{ dB}\): \(-26.10^\circ\) (\(-0.455\text{ rad}\), a sinistra).  
  - Massima deflessione a \(-30\text{ dB}\): \(-35.00^\circ\) (\(-0.610\text{ rad}\)).

---

## 4. Tipografia Ufficiale JUCE
- **Titolo Master**: `juce::FontOptions(17.0f, juce::Font::bold)` — Oro caldo `#f6e6cb`.
- **Sottotitolo Sub-Branding**: `juce::FontOptions(9.5f, juce::Font::bold)` — Ottone brunito `#c5a059`.
- **Intestazioni Baie (1..4)**: `juce::FontOptions(11.0f, juce::Font::bold)` — Colore distintivo baia.
- **Etichette Manopole**: `juce::FontOptions(8.5f, juce::Font::bold)` — Titanio satinato `#94a3b8`.
- **Valori e Unità di Misura**: `juce::FontOptions(8.0f, juce::Font::plain)` — Oro pallido `#ffe082`.
- **Serigrafie Meccaniche**: `juce::FontOptions(7.5f, juce::Font::bold)` — Grigio vintage `#262626`.

---

## 5. Gerarchia Visiva e Flusso dello Sguardo
1. **Punto Focale Primario**: Il **Dual VU Meter** in Baia 4 e il **Neve Drive Knob** in Baia 1 attirano immediatamente lo sguardo, indicando il guadagno analogico e la dinamica in azione.
2. **Punto Focale Secondario**: Il **Display FFT** in Baia 3 e la **LED Bar del De-Esser** in Baia 2 forniscono monitoraggio in tempo reale della pulizia spettrale.
3. **Flusso di Lavoro da Sinistra a Destra**:
   - **Step 1**: Pulizia del silenzio con Gate & colorazione con Neve Drive.
   - **Step 2**: Controllo delle sibilanti (De-Esser) & apertura delle armoniche alte (Maag Air).
   - **Step 3**: Modellazione tonale chirurgica a 4 bande SSL 242.
   - **Step 4**: Livellamento dinamico ottico (LA-2A) seguito da limitazione di picco FET (1176) & Vocal Doubler stereo.
   - **Step 5**: Calibrazione del livello master (LUFS BS.1770-4) e bilanciamento Wet/Dry.
