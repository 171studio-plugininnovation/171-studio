$buildVst3 = 'C:\Users\171Studio\.gemini\antigravity\scratch\171DriveOptocom\build\171DriveOptocom_artefacts\Release\VST3\DRIVE OPTOCOM.vst3'
$buildExe  = 'C:\Users\171Studio\.gemini\antigravity\scratch\171DriveOptocom\build\171DriveOptocom_artefacts\Release\Standalone\DRIVE OPTOCOM.exe'
$guiSnap   = 'C:\Users\171Studio\.gemini\antigravity\brain\09083e63-7efb-4e38-b54a-484d18d4fb1f\171DriveOptocom_Stereo_GUI.png'

$sysVst3Dir = 'C:\Program Files\Common Files\VST3'
$desktopPkg = 'C:\Users\171Studio\Desktop\171PluginInnovation - DriveOptocom'
$desktopZip = 'C:\Users\171Studio\Desktop\171DriveOptocom_v1.1.0_StereoUpgrade.zip'

# 1. Atomic Deploy to System VST3
$tmpSys = Join-Path $sysVst3Dir 'DRIVE OPTOCOM.vst3.tmp'
$finalSys = Join-Path $sysVst3Dir 'DRIVE OPTOCOM.vst3'
if (Test-Path $tmpSys) { Remove-Item -Path $tmpSys -Recurse -Force }
Copy-Item -Path $buildVst3 -Destination $tmpSys -Recurse -Force
if (Test-Path $finalSys) { Remove-Item -Path $finalSys -Recurse -Force }
Rename-Item -Path $tmpSys -NewName 'DRIVE OPTOCOM.vst3' -Force
Write-Output '[+] VST3 deployed atomically to System VST3 folder'

# 2. Sync to Desktop Package
if (!(Test-Path $desktopPkg)) { New-Item -ItemType Directory -Path $desktopPkg -Force }
$destVst3 = Join-Path $desktopPkg 'DRIVE OPTOCOM.vst3'
if (Test-Path $destVst3) { Remove-Item -Path $destVst3 -Recurse -Force }
Copy-Item -Path $buildVst3 -Destination $desktopPkg -Recurse -Force
Copy-Item -Path $buildExe -Destination $desktopPkg -Force
Copy-Item -Path $guiSnap -Destination $desktopPkg -Force
Write-Output '[+] Desktop package updated'

# 3. Create fresh Release ZIP
if (Test-Path $desktopZip) { Remove-Item -Path $desktopZip -Force }
Compress-Archive -Path $desktopPkg -DestinationPath $desktopZip -CompressionLevel Optimal
Write-Output ('[+] Desktop ZIP generated: ' + (Get-Item $desktopZip).Length + ' bytes')
