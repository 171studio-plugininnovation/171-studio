# DRIVE OPTOCOM (171CUMPressor) – Regole & Linee Guida di Sviluppo
**Target:** Agente di Sviluppo Software & DSP  
**Progetto:** DRIVE OPTOCOM (171CUMPressor) VST3 / Standalone  
**Standard Tecnico:** Studio Pro Audio Grade (UAD, Shadow Hills, Soundtoys, FabFilter)

---

## Indice dei Documenti di Regola nella Cartella `rules/`

L'agente al lavoro su questo plugin **DEVE consultare e seguire rigorosamente** i seguenti moduli di specifica:

1. [01_REALTIME_THREAD_SAFETY.md](file:///C:/Users/171Studio/.gemini/antigravity/scratch/171CUMPressor/rules/01_REALTIME_THREAD_SAFETY.md)
   * Le 4 regole ferree per il thread audio (`processBlock`): zero allocazioni, zero lock, gestione denormali e immunità ai `NaN`.
2. [02_OPTO_DSP_ARCHITECTURE.md](file:///C:/Users/171Studio/.gemini/antigravity/scratch/171CUMPressor/rules/02_OPTO_DSP_ARCHITECTURE.md)
   * Architettura DSP completa: Smoothing a 20 ms, Crossover Linkwitz-Riley LR-4 a fase coerente, saturazione anti-aliasata ADAA-2 e Soft-Ceiling a $-0.09\text{ dBFS}$.
3. [03_T4_PHOTOCELL_MODELS.md](file:///C:/Users/171Studio/.gemini/antigravity/scratch/171CUMPressor/rules/03_T4_PHOTOCELL_MODELS.md)
   * Fisica della cella T4B fotochimica: doppio stadio di rilascio con Memory Lag, le 3 modalità (LA-2A Tube, LA-3A Solid-State, Shadow Hills) e l'Auto-Makeup Gain.
4. [04_GUI_BALLISTICS_AND_METERING.md](file:///C:/Users/171Studio/.gemini/antigravity/scratch/171CUMPressor/rules/04_GUI_BALLISTICS_AND_METERING.md)
   * Interfaccia grafica a 60 FPS, balistica IEC 60268-17 per il Gain Reduction VU Meter, Dual Screen Visualizer e disaccoppiamento Lock-Free FIFO.
5. [05_DAW_LIFECYCLE_AND_VERSIONING.md](file:///C:/Users/171Studio/.gemini/antigravity/scratch/171CUMPressor/rules/05_DAW_LIFECYCLE_AND_VERSIONING.md)
   * Ciclo di vita della DAW, ricalcolo costanti al cambio di Sample Rate e retrocompatibilità totale dei preset tramite XML Versioning.

---

## Tabella dei Vincoli Fondamentali

| Vincolo | Requisito Assoluto | Azione Correttiva Obbligatoria |
| :--- | :--- | :--- |
| **Allocazioni Heap** | `0` byte in `processBlock()` | Pre-allocare in `prepareToPlay()` |
| **Smoothing Parametri**| $20\text{ ms}$ campione per campione | Usare `juce::SmoothedValue` su tutti i controlli |
| **Fase Crossover** | Somma piatta $0\text{ dB}$ | Sostituire Butterworth con Linkwitz-Riley LR-4 |
| **Anti-Aliasing** | Zero ripple nella banda audio | ADAA-2 su saturazione cubica e trasformatore |
| **Picco Massimo** | $\le -0.09\text{ dBFS}$ ($0.9900$) | Analog Safety Soft-Ceiling asintotico su Preamp |
| **Balistica Meter** | Standard IEC 60268-17 | Equazione 2° ordine smorzata ($\zeta = 0.707$, $300\text{ ms}$) |
