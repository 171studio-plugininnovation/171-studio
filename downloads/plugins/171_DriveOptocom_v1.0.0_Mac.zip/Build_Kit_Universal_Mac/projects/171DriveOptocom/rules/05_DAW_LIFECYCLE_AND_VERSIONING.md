# Modulo 05: Ciclo di Vita DAW & Versioning Preset
**Plugin:** DRIVE OPTOCOM (171CUMPressor)  
**Standard:** VST3 / AU Standard Architecture

---

## 1. Gestione del Cambio di Sample Rate a Caldo

Le DAW (Reaper, Cubase, Ableton, Studio One, Logic) possono cambiare frequenza di campionamento o buffer size in qualsiasi momento durante la sessione.

### Procedura Obbligatoria in `prepareToPlay(double sampleRate, int samplesPerBlock)`:
1. Verificare che `sampleRate > 1000.0`.
2. Ricalcolare tutti i coefficienti dipendenti da $f_s$:
   * Costanti di tempo dei filtri: $\alpha = 1.0 - \exp\left(-\frac{1.0}{\tau \cdot f_s}\right)$
   * Coefficienti dei filtri IIR di crossover (Linkwitz-Riley LR-4 a 200 Hz e 2500 Hz).
   * Filtro Sidechain passa-alto (100 Hz).
   * DC-Blocker passa-alto (10 Hz).
3. Inizializzare gli interpolatori continui (`smoothedValue.reset(sampleRate, 0.020)`).
4. Eseguire `reset()` su tutti i moduli DSP per azzerare gli storici degli integratori ed evitare picchi esplosivi (`Inf` / `NaN`).

---

## 2. Versioning e Retrocompatibilità dello Stato

I metodi `getStateInformation()` e `setStateInformation()` **non devono mai usare strutture binarie piatte (`memcpy`)**, perché l'aggiunta di un parametro corromperebbe i progetti vecchi salvati dagli utenti.

### Formato XML Versionato:
```cpp
void AudioPluginAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    auto state = apvts.copyState();
    state.setProperty("version", 2, nullptr);
    state.setProperty("currentPreset", currentProgramIndex, nullptr);
    
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void AudioPluginAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType())) {
        const int version = xmlState->getIntAttribute("version", 1);
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
        currentProgramIndex = apvts.state.getProperty("currentPreset", 0);
        
        // Se si caricano progetti creati con la versione 1, assegna valori predefiniti sicuri ai nuovi parametri
        if (version < 2) {
            // inizializzazioni di compatibilità
        }
    }
}
```
