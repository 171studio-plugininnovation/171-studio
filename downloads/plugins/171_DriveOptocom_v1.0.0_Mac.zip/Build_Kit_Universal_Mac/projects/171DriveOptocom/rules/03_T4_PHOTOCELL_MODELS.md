# Modulo 03: Modellazione Cella T4B & Modalità Opto
**Plugin:** DRIVE OPTOCOM (171CUMPressor)  
**Riferimento:** UAD Teletronix LA-2A, UREI LA-3A, Shadow Hills Mastering Compressor

---

## 1. Fisica Fotochimica della Cella Ottica T4B

La cella ottica T4B (usata in LA-2A e LA-3A) è composta da un pannello elettroluminescente (EL) che emette luce proporzionale all'ampiezza audio e fotoresistenze al solfuro di cadmio (CdS).

### La Legge del Doppio Rilascio Fotochimico (Memory Lag)
Il rilascio non è un singolo decadimento lineare o esponenziale:
1. **Fase 1 (Rilascio Rapido):** I primi $50\%$ della riduzione di guadagno decadono rapidamente in circa $60\text{ ms}$.
2. **Fase 2 (Rilascio Lento con Memoria):** Il restante $50\%$ impiega da $0.5$ a $5\text{ secondi}$. Più a lungo il segnale rimane compresso (es. su una traccia vocale o un mix bus denso), più la cella assorbe carica, rallentando esponenzialmente il recupero finale.

### Equazione di Stato Implementativa in `OptoDynamics.h`:
```cpp
// 1. Integrazione della memoria fotoelettrica (Long-Term Charge)
if (desiredReduction > env) {
    // Attacco: accensione rapida del pannello EL
    env += alphaAttack * (desiredReduction - env);
    memory += dt * 1.8f * desiredReduction; // accumulo di fotoni
} else {
    // Rilascio: decadimento a due costanti di tempo
    const float memoryNormalized = std::clamp(memory / 15.0f, 0.0f, 1.0f);
    
    // Mix dinamico tra rilascio rapido (60 ms) e rilascio lento (1.5 - 3 s)
    const float currentAlphaRelease = (1.0f - memoryNormalized) * alphaRelFast + memoryNormalized * alphaRelSlow;
    env += currentAlphaRelease * (desiredReduction - env);
    
    // Scarica graduale della cella
    memory = std::max(0.0f, memory - dt * 1.2f);
}
```

---

## 2. Le Tre Modalità Operative "Opto Character"

Per rendere DRIVE OPTOCOM uno strumento universale, implementare un commutatore a 3 posizioni (`opto_mode`):

```
+---------------+------------------------+-------------------+------------------------------------------+
| Modalità      | Emulazione Hardware    | Tempo Attacco     | Comportamento Acustico                   |
+---------------+------------------------+-------------------+------------------------------------------+
| 1. VINTAGE    | Teletronix LA-2A Tube  | 10 ms (Morbido)   | Caldo, valvolare, rilascio musicale lento|
| 2. PUNCH      | UREI LA-3A Solid-State | 1.5 ms (Veloce)   | Attacco a transistor, schiaccia le drum  |
| 3. MODERN     | Shadow Hills Opto/VCA  | 5 ms + Transformer| Peso sui bassi, precisione da mastering  |
+---------------+------------------------+-------------------+------------------------------------------+
```

---

## 3. Algoritmo di Auto-Makeup Gain

Per evitare dislivelli improvvisi di volume durante l'impostazione della compressione:
$$\text{AutoMakeup}_{\text{dB}} \approx \left( -\text{Threshold}_{\text{dB}} \right) \cdot \left( 1.0 - \frac{1}{\text{Ratio}} \right) \cdot 0.55$$
* Quando il pulsante `Auto Gain` è attivo, l'abbassamento della soglia inietta automaticamente il guadagno compensativo stimato, mantenendo costante il volume percepito.
