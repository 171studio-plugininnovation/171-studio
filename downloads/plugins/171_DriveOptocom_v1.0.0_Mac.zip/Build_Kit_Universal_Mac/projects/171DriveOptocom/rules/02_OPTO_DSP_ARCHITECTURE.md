# Modulo 02: Architettura DSP & Catena del Segnale
**Plugin:** DRIVE OPTOCOM (171CUMPressor)  
**Standard:** Pro Audio DSP

---

## 1. La Catena di Elaborazione (Signal Flow)

```
[In L/R] 
   |
   v
[1. Preamp Stage] ----------> Input Drive & DC-Blocker (10 Hz)
   |
   v
[2. Opto Compressor] -------> Cella T4B con Sidechain HPF (100 Hz) & Memory Lag
   |
   v
[3. Tri-Band Crossover] ----> Crossover Linkwitz-Riley LR-4 (200 Hz & 2500 Hz)
   |                                |               |
   |                                v               v
   |                              [Low]           [Mid]          [High]
   |                              (Tube 2f)      (ADAA-2 Clip)  (Silk Tape)
   v                                |               |               |
[4. Recombination] <----------------+---------------+---------------+ (Fase 0 dB)
   |
   v
[5. Output Makeup] ---------> Auto-Gain / Trim & Analog Safety Soft-Ceiling (-0.09 dBFS)
   |
   v
[Out L/R]
```

---

## 2. Regola 1: Smoothing Continuo dei Parametri (Anti-Zipper)
Tutti i parametri devono essere interpolati campione per campione per eliminare i click:
* Aggiungere a `PluginProcessor.h` le istanze di interpolazione:
  ```cpp
  juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedDrive;
  juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedThreshold;
  juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedRatio;
  juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedAttack;
  juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedRelease;
  juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedSaturation;
  juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedOutGain;
  ```
* In `prepareToPlay()`, inizializzare con tempo di rampa a $20\text{ ms}$:
  ```cpp
  constexpr double rampTimeSec = 0.020;
  smoothedDrive.reset(sampleRate, rampTimeSec);
  // ... per tutti i parametri
  ```

---

## 3. Regola 2: Sostituzione Crossover Butterworth con Linkwitz-Riley LR-4
In `TriBandSaturator.h`:
* I filtri Butterworth a 2 poli sfasano le bande provocando buchi acustici.
* Sostituire con **Linkwitz-Riley del 4° ordine (LR-4)**, ottenuto mettendo in cascata due biquad Butterworth del 2° ordine identici:
  $$H_{\text{LR4-LP}}(s) = \left( H_{\text{Butterworth-LP}}(s) \right)^2$$
  $$H_{\text{LR4-HP}}(s) = \left( H_{\text{Butterworth-HP}}(s) \right)^2$$
* **Proprietà fondamentale:** La somma in ampiezza $|H_{\text{LP}} + H_{\text{HP}}| \equiv 1.000$ a tutte le frequenze, eliminando le cancellazioni di fase sul mix Dry/Wet.

---

## 4. Regola 3: Anti-Aliasing ADAA-2 sulla Saturazione
Sulla banda dei medi, la saturazione cubica deve implementare l'Antiderivative Antialiasing di 2° ordine (ADAA-2 a 64-bit):
* Funzione: $f(x) = x - \frac{x^3}{3}$
* Prima primitiva: $F_1(x) = \frac{x^2}{2} - \frac{x^4}{12}$
* Seconda primitiva: $F_2(x) = \frac{x^3}{6} - \frac{x^5}{60}$
* Previene l'accumulo di aliasing metallico nei transienti medio-alti.

---

## 5. Regola 4: Analog Safety Soft-Ceiling (-0.09 dBFS)
Sullo stadio d'uscita (`PreampStage.h`), sostituire la formula a pendenza ripida con la curva continua asintotica a $-0.09\text{ dBFS}$ ($0.9900$ di picco massimo):
```cpp
inline float applySafetyCeiling(float x) noexcept {
    constexpr float threshold = 0.85f;
    const float absVal = std::abs(x);
    if (absVal <= threshold) return x;
    
    // Curva a gomito morbido asintotica a 0.9900
    const float satMag = 0.85f + 0.14f * std::tanh((absVal - 0.85f) / 0.14f);
    return (x > 0.0f) ? satMag : -satMag;
}
```
* **Garanzia:** Nessun campione digitale a $0\text{ dBFS}$ o oltre. Zero distorsione inter-sample sui convertitori DAC.
