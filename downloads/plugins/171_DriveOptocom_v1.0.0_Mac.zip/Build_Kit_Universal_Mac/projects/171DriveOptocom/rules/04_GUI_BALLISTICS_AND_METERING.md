# Modulo 04: Balistica Grafica & Metering
**Plugin:** DRIVE OPTOCOM (171CUMPressor)  
**Standard:** IEC 60268-17 (Analog VU-Meter) & 60 FPS Lock-Free

---

## 1. Disaccoppiamento Audio/GUI tramite FIFO
* Il thread grafico a 60 Hz non deve mai leggere direttamente le variabili del DSP audio.
* `processBlock()` scrive i campioni decimati e i valori di picco/RMS nella struttura `VisualFrame` e li spinge nella `LockFreeVisualFIFO`.
* Il metodo `timerCallback()` della GUI (a 60 Hz) svuota la FIFO ed esegue il repainting.

---

## 2. Balistica Meccanica Reale dell'Ago VU Meter (IEC 60268-17)

Un vero ago a galvanometro analogico possiede massa inerziale, momento meccanico e smorzamento. Non deve muoversi con un banale filtro a un polo.

### Equazione Differenziale del 2° Ordine con Smorzamento Critico:
$$\frac{d^2 \theta}{dt^2} + 2 \zeta \omega_n \frac{d\theta}{dt} + \omega_n^2 \theta = \omega_n^2 \theta_{\text{target}}$$

* **Parametri di Calibrazione:**
  * Coefficiente di smorzamento: $\zeta = 0.707$
  * Frequenza angolare naturale: $\omega_n \approx 11.5\text{ rad/s}$
  * Tempo di salita: $300\text{ ms}$ per raggiungere il $99\%$ del valore
  * Overshoot controllato: tra $1.0\%$ e $1.5\%$

### Codice di Aggiornamento nella GUI (`DualScreenVisualizer.h`):
```cpp
void updateNeedleBallistics(float targetDb, float dt) noexcept {
    // targetDb tipicamente da 0 a -20 dB GR
    const float delta = targetDb - needleAngleDb;
    const float springForce = omegaN * omegaN * delta;
    const float dampingForce = 2.0f * dampingZeta * omegaN * needleVelocity;
    
    needleVelocity += (springForce - dampingForce) * dt;
    needleAngleDb  += needleVelocity * dt;
}
```

---

## 3. Dual Screen Display
* **Schermo Sinistro (Gain Reduction & VU Meter):**
  * Fondo scala analogico da $0\text{ dB}$ a $-20\text{ dB}$ di riduzione del guadagno.
  * Scala grafica con numerazione vintage e ago ad alta definizione.
* **Schermo Destro (Oscilloscopio / Spectrum):**
  * Visualizzazione in tempo reale della forma d'onda d'ingresso (grigio/blu) a confronto con l'uscita compressa e saturata (ambra/oro).
  * Persistenza CRT a decadimento fosforico per evitare sfarfallii ad alta frequenza.
