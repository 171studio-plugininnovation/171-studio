# Modulo 01: Sicurezza Real-Time e Threading
**Plugin:** DRIVE OPTOCOM (171CUMPressor)  
**Riferimento:** Ross Bencina Real-Time Audio Programming Standards

---

## 1. Divieto Assoluto di Operazioni Bloccanti
Nel thread audio (`processBlock()`, `processSample()`, e qualsiasi metodo della catena DSP):

1. **NO ALLOCAZIONI MEMORIA SULL'HEAP:**
   - È tassativamente vietato l'uso di `new`, `delete`, `malloc`, `free`.
   - È vietato l'uso di `std::vector::push_back`, `std::vector::resize`, `std::string` o qualsiasi contenitore che possa causare riallocazione.
   - Tutti i buffer audio e le variabili di stato devono essere pre-dimensionati durante `prepareToPlay(sampleRate, samplesPerBlock)`.

2. **NO MUTEX O PRIMITIVE DI SINCRONIZZAZIONE:**
   - Mai usare `std::mutex`, `std::unique_lock`, `std::condition_variable` nel thread audio.
   - Il thread audio non deve MAI attendere il thread grafico o il message thread della DAW (*Priority Inversion Protection*).

3. **DISACCOPPIAMENTO TRAMITE LOCK-FREE FIFO:**
   - Lo scambio dati verso la GUI deve avvenire esclusivamente tramite `dsp171::LockFreeVisualFIFO` (SPSC Lock-Free Single-Producer Single-Consumer).
   - Se la coda è piena, il thread audio sovrascrive o scarta il frame senza bloccare.

4. **GUARDIA DAI NUMERI DENORMALI (FTZ/DAZ):**
   - Inserire tassativamente all'inizio di `processBlock()`:
     ```cpp
     juce::ScopedNoDenormals noDenormals;
     ```
   - Nei filtri di feedback e negli integratori della cella fotochimica, impedire valori denormali clampando a zero se $|x| < 1.0\times 10^{-15}$.

5. **PROTEZIONE TOTALE DA NAN E INF:**
   - Tutte le conversioni logaritmiche di guadagno ($20 \log_{10}(x)$) devono avere una protezione dal valore zero:
     ```cpp
     float db = 20.0f * std::log10(std::max(level, 1.0e-5f));
     ```
   - Nessuna divisione matematica senza epsilon di salvaguardia ($\epsilon \ge 1.0 \times 10^{-5}$).
