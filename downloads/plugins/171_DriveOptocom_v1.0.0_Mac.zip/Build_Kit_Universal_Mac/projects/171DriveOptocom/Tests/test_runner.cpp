// ==============================================================================
//  171DriveOptocom - Test Runner: Collaudo DSP su Audio Reale
//  Verifica scientifica mastering-grade su stem dell'album
// ==============================================================================
#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <chrono>
#include <juce_core/juce_core.h>
#include <juce_events/juce_events.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "../Source/PluginProcessor.h"

struct TestResult {
    juce::String testName;
    juce::String inputFileName;
    double durationSec     = 0.0;
    float peakInDb         = -100.0f;
    float peakOutDb        = -100.0f;
    float rmsInDb          = -100.0f;
    float rmsOutDb         = -100.0f;
    float maxGRDb          = 0.0f;
    int   safetyCeilingClips = 0;
    int   nanOrInfCount    = 0;
    juce::File outputFile;
};

static void setParam(juce::AudioProcessorValueTreeState& apvts,
                     const juce::String& id, float realValue)
{
    if (auto* p = apvts.getParameter(id))
        p->setValueNotifyingHost(p->convertTo0to1(realValue));
}

static void setBoolParam(juce::AudioProcessorValueTreeState& apvts,
                         const juce::String& id, bool val)
{
    if (auto* p = apvts.getParameter(id))
        p->setValueNotifyingHost(val ? 1.0f : 0.0f);
}

TestResult runAudioTest(const juce::File& inputFile,
                        const juce::File& outputDir,
                        const juce::String& testName,
                        int presetIndex,
                        float customDrive = -999.0f,
                        float customThresh = -999.0f,
                        float customSat = -999.0f,
                        int punchModeOverride = -1)
{
    TestResult res;
    res.testName = testName;
    res.inputFileName = inputFile.getFileName();

    juce::AudioFormatManager formatManager;
    formatManager.registerBasicFormats();

    std::unique_ptr<juce::AudioFormatReader> reader(formatManager.createReaderFor(inputFile));
    if (!reader) {
        std::cerr << "[-] ERRORE: Impossibile leggere il file audio: " << inputFile.getFullPathName() << std::endl;
        return res;
    }

    const double sampleRate = reader->sampleRate;
    const int numChannels   = static_cast<int>(reader->numChannels);
    const int totalLength   = static_cast<int>(reader->lengthInSamples);
    res.durationSec         = static_cast<double>(totalLength) / sampleRate;

    juce::AudioBuffer<float> inBuffer(numChannels, totalLength);
    reader->read(&inBuffer, 0, totalLength, 0, true, true);

    AudioPluginAudioProcessor processor;
    constexpr int blockSize = 512;
    processor.prepareToPlay(sampleRate, blockSize);

    if (presetIndex >= 0) {
        processor.setCurrentProgram(presetIndex);
    }

    auto& apvts = processor.getAPVTS();
    if (customDrive > -900.0f)  setParam(apvts, "drive", customDrive);
    if (customThresh > -900.0f) setParam(apvts, "threshold", customThresh);
    if (customSat > -900.0f)    setParam(apvts, "saturation", customSat);
    if (punchModeOverride >= 0) setBoolParam(apvts, "punch_mode", punchModeOverride == 1);

    juce::AudioBuffer<float> outBuffer(numChannels, totalLength);
    juce::MidiBuffer midi;

    double sumSqIn = 0.0;
    double sumSqOut = 0.0;
    float peakIn = 0.0f;
    float peakOut = 0.0f;
    float maxGR = 0.0f;

    const int numBlocks = (totalLength + blockSize - 1) / blockSize;

    for (int b = 0; b < numBlocks; ++b) {
        const int startSample = b * blockSize;
        const int currentBlockSize = std::min(blockSize, totalLength - startSample);

        juce::AudioBuffer<float> blockBuffer(2, currentBlockSize);
        for (int ch = 0; ch < 2; ++ch) {
            const int inCh = std::min(ch, numChannels - 1);
            blockBuffer.copyFrom(ch, 0, inBuffer, inCh, startSample, currentBlockSize);
        }

        for (int ch = 0; ch < 2; ++ch) {
            for (int i = 0; i < currentBlockSize; ++i) {
                float s = blockBuffer.getSample(ch, i);
                float a = std::abs(s);
                if (a > peakIn) peakIn = a;
                sumSqIn += s * s;
            }
        }

        processor.processBlock(blockBuffer, midi);

        dsp171::VisualFrame vFrame;
        while (processor.getVisualFIFO().pop(vFrame)) {
            const float grL = std::abs(vFrame.gainReduction_L);
            const float grR = std::abs(vFrame.gainReduction_R);
            const float m = std::max(grL, grR);
            if (m > maxGR) maxGR = m;
        }

        for (int ch = 0; ch < 2; ++ch) {
            for (int i = 0; i < currentBlockSize; ++i) {
                float s = blockBuffer.getSample(ch, i);
                if (std::isnan(s) || std::isinf(s)) {
                    res.nanOrInfCount++;
                    s = 0.0f;
                }
                float a = std::abs(s);
                if (a > peakOut) peakOut = a;
                if (a > 1.0f) res.safetyCeilingClips++;
                sumSqOut += s * s;
            }
            const int outCh = std::min(ch, numChannels - 1);
            outBuffer.copyFrom(outCh, startSample, blockBuffer, ch, 0, currentBlockSize);
        }
    }

    const double totalInSamples = static_cast<double>(totalLength * 2);
    const double rmsIn = std::sqrt(sumSqIn / std::max(1.0, totalInSamples));
    const double rmsOut = std::sqrt(sumSqOut / std::max(1.0, totalInSamples));

    res.peakInDb   = peakIn > 1.0e-5f ? 20.0f * std::log10(peakIn) : -100.0f;
    res.peakOutDb  = peakOut > 1.0e-5f ? 20.0f * std::log10(peakOut) : -100.0f;
    res.rmsInDb    = rmsIn > 1.0e-5 ? static_cast<float>(20.0 * std::log10(rmsIn)) : -100.0f;
    res.rmsOutDb   = rmsOut > 1.0e-5 ? static_cast<float>(20.0 * std::log10(rmsOut)) : -100.0f;
    res.maxGRDb    = -maxGR;

    outputDir.createDirectory();
    res.outputFile = outputDir.getChildFile(testName + ".wav");
    res.outputFile.deleteFile();

    std::unique_ptr<juce::AudioFormatWriter> writer;
    juce::WavAudioFormat wavFormat;
    auto stream = res.outputFile.createOutputStream();
    if (stream) {
        writer.reset(wavFormat.createWriterFor(stream.get(), sampleRate, numChannels, 24, {}, 0));
        if (writer) {
            stream.release();
            writer->writeFromAudioSampleBuffer(outBuffer, 0, totalLength);
        }
    }

    return res;
}

int main(int argc, char* argv[])
{
    juce::MessageManager::getInstance();

    std::cout << "====================================================================\n";
    std::cout << " 171DriveOptocom - COLLAUDO DINAMICO SU AUDIO REALE (BEAT & REC ALBUM)\n";
    std::cout << "====================================================================\n\n";

    const juce::File beatMixtapeDir(R"(C:\Users\171Studio\Desktop\beat mixtape)");
    const juce::File outputDir     (R"(C:\Users\171Studio\Desktop\beat mixtape\171DriveOptocom_Test_Outputs)");

    std::vector<TestResult> results;

    // 1. BEAT COMPLETO (Brother.wav)
    juce::File beatFile = beatMixtapeDir.getChildFile("brother").getChildFile("Brother.wav");
    if (beatFile.existsAsFile()) {
        std::cout << "[*] Test 1: BEAT COMPLETO (" << beatFile.getFileName() << ")\n";
        std::cout << "    -> 1A: Master Glue Opto (Preset 01 - Opto Vocal Classic)...\n";
        results.push_back(runAudioTest(beatFile, outputDir, "01A_Brother_OptoGlue", 0));

        std::cout << "    -> 1B: Heavy Tube Drive (Preset 07 - Heavy Tube Overdrive)...\n";
        results.push_back(runAudioTest(beatFile, outputDir, "01B_Brother_HeavyTubeDrive", 6));
    }

    // 2. STEM BATTERIA (0 Drums.wav)
    juce::File drumsFile = beatMixtapeDir.getChildFile("brother").getChildFile("0 Drums.wav");
    if (drumsFile.existsAsFile()) {
        std::cout << "\n[*] Test 2: STEM BATTERIA (0 Drums.wav)\n";
        std::cout << "    -> 2A: Drum Bus Punch (Preset 03 - Drum Bus Puncher)...\n";
        results.push_back(runAudioTest(drumsFile, outputDir, "02A_Drums_BusPuncher", 2));

        std::cout << "    -> 2B: Parallel Drum Crush (Preset 05 - Parallel Fat Slam)...\n";
        results.push_back(runAudioTest(drumsFile, outputDir, "02B_Drums_ParallelFatSlam", 4));
    }

    // 3. VOCE LEAD REC ALBUM (04-251202_1939.wav)
    juce::File vocalFile1 = beatMixtapeDir.getChildFile("REC ALBUM").getChildFile("REC BROTHER").getChildFile("Media").getChildFile("04-251202_1939.wav");
    if (vocalFile1.existsAsFile()) {
        std::cout << "\n[*] Test 3: VOCE REC ALBUM (" << vocalFile1.getFileName() << ")\n";
        std::cout << "    -> 3A: LA-2A Style Vocal Leveling (Preset 02 - LA-2A Leveler)...\n";
        results.push_back(runAudioTest(vocalFile1, outputDir, "03A_Vocal_LA2A_Leveler", 1));

        std::cout << "    -> 3B: Warm Tube Vocal (Preset 08 - Warm Tape & Tube Glue)...\n";
        results.push_back(runAudioTest(vocalFile1, outputDir, "03B_Vocal_WarmTubeTapeGlue", 7));
    }

    // 4. BEAT NICARAGUA (nicaragua BEAT.wav)
    juce::File beatNicFile = beatMixtapeDir.getChildFile("nicaragua BEAT.wav");
    if (beatNicFile.existsAsFile()) {
        std::cout << "\n[*] Test 4: BEAT NICARAGUA (nicaragua BEAT.wav)\n";
        std::cout << "    -> 4A: Master Mix Tape Glue (Preset 04 - Bass Thickener)...\n";
        results.push_back(runAudioTest(beatNicFile, outputDir, "04A_Nicaragua_MasterGlue", 3));
    }

    // STAMPA DELLA TABELLA FINALE
    std::cout << "\n========================================================================================================================\n";
    std::cout << " TABELLA RISULTATI COLLAUDO E VERIFICA INGEGNERISTICA 171DriveOptocom\n";
    std::cout << "========================================================================================================================\n";
    std::cout << std::left
              << std::setw(36) << "Test ID / Modalita"
              << std::setw(10) << "Dur(s)"
              << std::setw(12) << "Peak In"
              << std::setw(12) << "Peak Out"
              << std::setw(12) << "RMS In"
              << std::setw(12) << "RMS Out"
              << std::setw(12) << "Max GR"
              << std::setw(12) << "SafetyCeil"
              << std::setw(8)  << "NaN/Inf"
              << "Esito\n";
    std::cout << "------------------------------------------------------------------------------------------------------------------------\n";

    bool allPassed = true;
    for (const auto& r : results) {
        bool pass = (r.safetyCeilingClips == 0) && (r.nanOrInfCount == 0) && (r.peakOutDb <= 0.05f);
        if (!pass) allPassed = false;

        std::cout << std::left
                  << std::setw(36) << r.testName
                  << std::setw(10) << std::fixed << std::setprecision(1) << r.durationSec
                  << std::setw(12) << (juce::String(r.peakInDb, 1) + " dB").toStdString()
                  << std::setw(12) << (juce::String(r.peakOutDb, 1) + " dB").toStdString()
                  << std::setw(12) << (juce::String(r.rmsInDb, 1) + " dB").toStdString()
                  << std::setw(12) << (juce::String(r.rmsOutDb, 1) + " dB").toStdString()
                  << std::setw(12) << (juce::String(r.maxGRDb, 1) + " dB").toStdString()
                  << std::setw(12) << (r.safetyCeilingClips == 0 ? "SICURO" : "CLIP!")
                  << std::setw(8)  << r.nanOrInfCount
                  << (pass ? "[SUPERATO]" : "[FALLITO]")
                  << "\n";
    }

    std::cout << "------------------------------------------------------------------------------------------------------------------------\n";
    std::cout << "Esito complessivo: " << (allPassed ? "TUTTI I TEST SUPERATI CON SUCCESSO (100% PASS)" : "TEST NON SUPERATI") << "\n";
    std::cout << "File audio esportati in: " << outputDir.getFullPathName() << "\n";
    std::cout << "========================================================================================================================\n\n";

    return allPassed ? 0 : 1;
}
