#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <iomanip>
#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "../Source/PluginProcessor.h"

static void setParam(juce::AudioProcessorValueTreeState& apvts, const juce::String& id, float val) {
    if (auto* p = apvts.getParameter(id))
        p->setValueNotifyingHost(p->convertTo0to1(val));
}

static void setBool(juce::AudioProcessorValueTreeState& apvts, const juce::String& id, bool val) {
    if (auto* p = apvts.getParameter(id))
        p->setValueNotifyingHost(val ? 1.0f : 0.0f);
}

static void processAudio(AudioPluginAudioProcessor& proc, juce::AudioBuffer<float>& buffer, int blockSize = 512) {
    juce::MidiBuffer midi;
    const int numSamples = buffer.getNumSamples();
    const int numChannels = buffer.getNumChannels();
    for (int i = 0; i < numSamples; i += blockSize) {
        const int curBlock = std::min(blockSize, numSamples - i);
        juce::AudioBuffer<float> sub(buffer.getArrayOfWritePointers(), numChannels, i, curBlock);
        proc.processBlock(sub, midi);
    }
}

int main(int argc, char* argv[]) {
    juce::ScopedJuceInitialiser_GUI gui;
    constexpr double sr = 44100.0;
    constexpr int bs = 512;

    std::cout << "====================================================================" << std::endl;
    std::cout << "   171DriveOptocom - RIGOROUS DSP & SCIENTIFIC AUDIT ENGINE         " << std::endl;
    std::cout << "====================================================================" << std::endl;

    AudioPluginAudioProcessor proc;
    proc.prepareToPlay(sr, bs);
    auto& apvts = proc.getAPVTS();

    // Reset default parameters
    setParam(apvts, "drive", 0.0f);
    setParam(apvts, "preamp_tone", 0.0f);
    setParam(apvts, "threshold", 0.0f);
    setParam(apvts, "ratio", 3.0f);
    setParam(apvts, "t4_memory", 0.50f);
    setParam(apvts, "saturation", 0.0f);
    setParam(apvts, "out_gain", 0.0f);
    setParam(apvts, "stereo_width", 1.0f);
    setBool(apvts, "bypass", false);
    setBool(apvts, "stereo_link", false);
    setBool(apvts, "punch_mode", false);
    setBool(apvts, "sat_routing", false);
    setBool(apvts, "sc_filter", false);

    // Settle smoothed values (100 ms)
    {
        juce::AudioBuffer<float> warmup(2, 4410);
        warmup.clear();
        processAudio(proc, warmup);
    }

    // -------------------------------------------------------------------------
    // TEST A1: Latency-Compensated True Bypass Null Test
    // -------------------------------------------------------------------------
    setBool(apvts, "bypass", true);
    {
        juce::AudioBuffer<float> warmup(2, 2205);
        warmup.clear();
        processAudio(proc, warmup);
    }

    int testSamples = 44100;
    juce::AudioBuffer<float> testBuf(2, testSamples);
    std::vector<float> dryL(testSamples), dryR(testSamples);
    for (int i = 0; i < testSamples; ++i) {
        float s = 0.25f * std::sin(2.0 * 3.14159265358979323846 * 1000.0 * i / sr);
        dryL[i] = s;
        dryR[i] = s;
        testBuf.setSample(0, i, s);
        testBuf.setSample(1, i, s);
    }
    processAudio(proc, testBuf);

    // Lookahead latency is 4 samples (dsp171::TruePeakLimiter::LookaheadLatency)
    constexpr int latency = 4;
    double bypassMaxDiff = 0.0;
    double bypassSumDiffSq = 0.0;
    int validCount = testSamples - latency - 100;
    for (int i = 100; i < testSamples - latency; ++i) {
        float dry = dryL[i];
        float wet = testBuf.getSample(0, i + latency);
        double diff = std::abs(dry - wet);
        if (diff > bypassMaxDiff) bypassMaxDiff = diff;
        bypassSumDiffSq += diff * diff;
    }
    double bypassRmsDiff = std::sqrt(bypassSumDiffSq / validCount);
    double bypassNullDepthDb = (bypassRmsDiff > 1e-15) ? 20.0 * std::log10(bypassRmsDiff) : -300.0;

    std::cout << "[Test A1 - Latency-Compensated True Bypass]" << std::endl;
    std::cout << "  Aligned Dry vs Wet Max Diff: " << bypassMaxDiff << std::endl;
    std::cout << "  Aligned Null Depth RMS:      " << bypassNullDepthDb << " dBFS" << std::endl;

    // -------------------------------------------------------------------------
    // TEST A2: Active Linear Transparency (Tone=0, Sat=0, Drive=0, Makeup=0, Thresh=0)
    // -------------------------------------------------------------------------
    setBool(apvts, "bypass", false);
    setParam(apvts, "drive", 0.0f);
    setParam(apvts, "preamp_tone", 0.0f);
    setParam(apvts, "threshold", 0.0f);
    setParam(apvts, "saturation", 0.0f);
    setParam(apvts, "out_gain", 0.0f);
    {
        juce::AudioBuffer<float> warmup(2, 4410);
        warmup.clear();
        processAudio(proc, warmup);
    }

    juce::AudioBuffer<float> activeBuf(2, testSamples);
    for (int i = 0; i < testSamples; ++i) {
        float s = 0.12589f * std::sin(2.0 * 3.14159265358979323846 * 1000.0 * i / sr); // -18 dBFS sine
        dryL[i] = s;
        activeBuf.setSample(0, i, s);
        activeBuf.setSample(1, i, s);
    }
    processAudio(proc, activeBuf);

    // Correlation and difference
    double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0, sumY2 = 0;
    double maxActiveDiff = 0.0;
    double sumActiveDiffSq = 0.0;
    for (int i = 500; i < testSamples - latency; ++i) {
        double x = dryL[i];
        double y = activeBuf.getSample(0, i + latency);
        double diff = std::abs(x - y);
        if (diff > maxActiveDiff) maxActiveDiff = diff;
        sumActiveDiffSq += diff * diff;
        sumXY += x * y;
        sumX2 += x * x;
        sumY2 += y * y;
    }
    int activeCount = (testSamples - latency) - 500;
    double activeRmsDiff = std::sqrt(sumActiveDiffSq / activeCount);
    double activeNullDepthDb = 20.0 * std::log10(activeRmsDiff);
    double phaseCoherence = sumXY / (std::sqrt(sumX2) * std::sqrt(sumY2));

    std::cout << "[Test A2 - Active Signal Path Transparency (1 kHz, -18 dBFS)]" << std::endl;
    std::cout << "  Residual Max Difference:     " << maxActiveDiff << std::endl;
    std::cout << "  Residual Null Depth RMS:     " << activeNullDepthDb << " dBFS" << std::endl;
    std::cout << "  Phase Coherence (Rxy):       " << std::setprecision(8) << phaseCoherence << std::endl;

    // -------------------------------------------------------------------------
    // TEST B: T4B Dynamic Release (Fast Stage 1 ~60ms vs Slow Stage 2 Memory)
    // -------------------------------------------------------------------------
    setBool(apvts, "bypass", false);
    setParam(apvts, "threshold", -20.0f);
    setParam(apvts, "ratio", 4.0f);
    setParam(apvts, "t4_memory", 0.50f);
    setBool(apvts, "punch_mode", false);
    {
        juce::AudioBuffer<float> warmup(2, 4410);
        warmup.clear();
        processAudio(proc, warmup);
    }

    // 1.5 seconds burst at 0 dBFS (peak 1.0), followed by 3.5 seconds silence
    int burstSamples = static_cast<int>(1.5 * sr);
    int releaseSamples = static_cast<int>(3.5 * sr);
    int totalDynSamples = burstSamples + releaseSamples;
    juce::AudioBuffer<float> dynBuf(2, totalDynSamples);
    dynBuf.clear();
    for (int i = 0; i < burstSamples; ++i) {
        float s = std::sin(2.0 * 3.14159265358979323846 * 1000.0 * i / sr);
        dynBuf.setSample(0, i, s);
        dynBuf.setSample(1, i, s);
    }

    // Process and collect envelope
    std::vector<float> envOut(totalDynSamples);
    juce::MidiBuffer midi;
    for (int i = 0; i < totalDynSamples; i += bs) {
        int cur = std::min(bs, totalDynSamples - i);
        juce::AudioBuffer<float> sub(dynBuf.getArrayOfWritePointers(), 2, i, cur);
        proc.processBlock(sub, midi);
        for (int k = 0; k < cur; ++k) {
            envOut[i + k] = sub.getSample(0, k);
        }
    }

    // Measure peak compression at end of burst
    float peakBurstEnd = 0.0f;
    for (int i = burstSamples - 2000; i < burstSamples; ++i) {
        float a = std::abs(envOut[i]);
        if (a > peakBurstEnd) peakBurstEnd = a;
    }
    float maxGRDb = 20.0f * std::log10(std::max(1e-5f, peakBurstEnd)); // GR is negative

    // Now track release using internal cell from OptoDynamics via test tone probing or envelope
    // To measure pure release stage 1 and stage 2:
    // Let's probe the gain recovery by sending a low-level test probe (-40 dBFS) during release!
    juce::AudioBuffer<float> probeBuf(2, totalDynSamples);
    probeBuf.clear();
    for (int i = 0; i < burstSamples; ++i) {
        float s = std::sin(2.0 * 3.14159265358979323846 * 1000.0 * i / sr);
        probeBuf.setSample(0, i, s);
        probeBuf.setSample(1, i, s);
    }
    // Low level probe during release (-35 dBFS sine)
    for (int i = burstSamples; i < totalDynSamples; ++i) {
        float s = 0.01778f * std::sin(2.0 * 3.14159265358979323846 * 1000.0 * i / sr);
        probeBuf.setSample(0, i, s);
        probeBuf.setSample(1, i, s);
    }

    proc.prepareToPlay(sr, bs);
    setParam(apvts, "threshold", -20.0f);
    setParam(apvts, "ratio", 4.0f);
    setParam(apvts, "t4_memory", 0.50f);
    {
        juce::AudioBuffer<float> warmup(2, 4410);
        warmup.clear();
        processAudio(proc, warmup);
    }
    processAudio(proc, probeBuf);

    std::cout << "[Test B - T4B Optical Dynamics & Dual-Stage Release]" << std::endl;
    std::cout << "  Burst Compression Peak GR:   " << maxGRDb << " dB" << std::endl;

    // Save summary JSON
    std::ofstream jsonOut("C:/Users/171Studio/Desktop/171 dsp and gui engine/tools-and-analysis/vst_harness/optocom_audit_results.json");
    jsonOut << "{\n";
    jsonOut << "  \"test_a1_bypass\": {\n";
    jsonOut << "    \"max_diff\": " << bypassMaxDiff << ",\n";
    jsonOut << "    \"null_depth_dbfs\": " << bypassNullDepthDb << "\n";
    jsonOut << "  },\n";
    jsonOut << "  \"test_a2_linear\": {\n";
    jsonOut << "    \"null_depth_dbfs\": " << activeNullDepthDb << ",\n";
    jsonOut << "    \"phase_coherence\": " << phaseCoherence << "\n";
    jsonOut << "  },\n";
    jsonOut << "  \"test_b_optodynamics\": {\n";
    jsonOut << "    \"burst_peak_gr_db\": " << maxGRDb << "\n";
    jsonOut << "  }\n";
    jsonOut << "}\n";
    jsonOut.close();

    std::cout << "  Results saved to optocom_audit_results.json" << std::endl;
    std::cout << "====================================================================" << std::endl;
    return 0;
}
