#include <iostream>
#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "../Source/PluginProcessor.h"

int main() {
    juce::ScopedJuceInitialiser_GUI gui;
    AudioPluginAudioProcessor proc;
    proc.prepareToPlay(44100.0, 512);

    juce::AudioBuffer<float> buffer(2, 512);
    // Channel 0 (Left): 1.0f sine, Channel 1 (Right): 0.0f silence
    for (int i = 0; i < 512; ++i) {
        buffer.setSample(0, i, std::sin(2.0 * 3.14159265 * 440.0 * i / 44100.0));
        buffer.setSample(1, i, 0.0f);
    }

    juce::MidiBuffer midi;
    proc.processBlock(buffer, midi);

    float maxL = buffer.getMagnitude(0, 0, 512);
    float maxR = buffer.getMagnitude(1, 0, 512);

    std::cout << "Max L: " << maxL << " | Max R: " << maxR << std::endl;
    return 0;
}
