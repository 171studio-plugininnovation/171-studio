#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "PluginProcessor.h"
#include "SerumVMeterComponent.h"
#include "GUI/CustomKnob.h"
#include "GUI/DualScreenVisualizer.h"
#include "GUI/HardwareSwitch.h"
#include "GUI/RotarySwitchKnob.h"
#include "GUI/BatonToggleSwitch.h"

// ==============================================================================
// LookAndFeel per il Selettore Preset Master (in stile 171 Studio Boutique)
// ==============================================================================
class Studio171ComboBoxLookAndFeel : public juce::LookAndFeel_V4 {
public:
    Studio171ComboBoxLookAndFeel() {
        setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff16181f));
        setColour(juce::ComboBox::textColourId, juce::Colour(0xfff1f5f9));
        setColour(juce::ComboBox::outlineColourId, juce::Colour(0xffc5a059));
        setColour(juce::ComboBox::arrowColourId, juce::Colour(0xffd4af37));

        setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xf40f1116));
        setColour(juce::PopupMenu::textColourId, juce::Colour(0xfff1f5f9));
        setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xff2a2418));
        setColour(juce::PopupMenu::highlightedTextColourId, juce::Colour(0xffffe082));
    }

    void drawComboBox(juce::Graphics& g, int width, int height, bool isButtonDown,
                      int buttonX, int buttonY, int buttonW, int buttonH, juce::ComboBox& box) override
    {
        juce::ignoreUnused(isButtonDown);
        auto bounds = juce::Rectangle<float>(0.0f, 0.0f, static_cast<float>(width), static_cast<float>(height)).reduced(1.0f);

        // 1. Ombra portata incassata
        g.setColour(juce::Colours::black.withAlpha(0.50f));
        g.fillRoundedRectangle(bounds.translated(1.0f, 2.0f), 4.0f);

        // 2. Corpo metallico in titanio scuro spazzolato
        juce::ColourGradient grad(juce::Colour(0xff222630), bounds.getX(), bounds.getY(),
                                  juce::Colour(0xff101217), bounds.getX(), bounds.getBottom(), false);
        g.setGradientFill(grad);
        g.fillRoundedRectangle(bounds, 4.0f);

        // 3. Bordo satinato in oro/bronzo cesellato
        g.setColour(box.hasKeyboardFocus(true) ? juce::Colour(0xffffe082) : juce::Colour(0xffc5a059));
        g.drawRoundedRectangle(bounds, 4.0f, 1.3f);

        // Micro-riflesso speculare sul bordo superiore
        g.setColour(juce::Colour(0x33ffffff));
        g.drawHorizontalLine(juce::roundToInt(bounds.getY() + 1.0f), bounds.getX() + 4.0f, bounds.getRight() - 4.0f);

        // Divisore verticale tra testo e freccia
        float divX = static_cast<float>(buttonX);
        g.setColour(juce::Colour(0x35c5a059));
        g.drawVerticalLine(juce::roundToInt(divX), bounds.getY() + 4.0f, bounds.getBottom() - 4.0f);

        // Freccia chevron dorata
        float arrowCx = static_cast<float>(buttonX) + static_cast<float>(buttonW) * 0.5f;
        float arrowCy = static_cast<float>(buttonY) + static_cast<float>(buttonH) * 0.5f;
        float arrowW = 8.0f;
        float arrowH = 5.0f;

        juce::Path arrow;
        arrow.startNewSubPath(arrowCx - arrowW * 0.5f, arrowCy - arrowH * 0.5f);
        arrow.lineTo(arrowCx, arrowCy + arrowH * 0.5f);
        arrow.lineTo(arrowCx + arrowW * 0.5f, arrowCy - arrowH * 0.5f);

        g.setColour(juce::Colour(0xffd4af37));
        g.strokePath(arrow, juce::PathStrokeType(2.0f, juce::PathStrokeType::mitered, juce::PathStrokeType::rounded));
    }

    juce::Font getComboBoxFont(juce::ComboBox&) override {
        return juce::FontOptions(11.5f, juce::Font::bold);
    }

    void positionComboBoxText(juce::ComboBox& box, juce::Label& label) override {
        label.setBounds(8, 1, box.getWidth() - 30, box.getHeight() - 2);
        label.setFont(getComboBoxFont(box));
    }
};

// ==============================================================================
// Editor Principale DRIVE OPTOCOM
// ==============================================================================
class AudioPluginAudioProcessorEditor : public juce::AudioProcessorEditor,
                                        public juce::Timer,
                                        private juce::ComboBox::Listener
{
public:
    explicit AudioPluginAudioProcessorEditor(AudioPluginAudioProcessor&);
    ~AudioPluginAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;
    void timerCallback() override;

private:
    void comboBoxChanged(juce::ComboBox* box) override;

    AudioPluginAudioProcessor& processorRef;

    // Immagini di sfondo e componenti boutique
    juce::Image backgroundImage;
    juce::Image knobTeardropBronzeImg;
    juce::Image knobBakeliteOptoImg;
    juce::Image knobMarconiRubyImg;
    juce::Image knobGunmetalMakeupImg;
    juce::Image dialScaleCalibratedImg;
    juce::Image dialScaleVintageImg;
    juce::Image lampJewelAmberImg;
    juce::Image lampJewelDarkImg;
    juce::Image lampJewelRubyImg;

    // Modulo SerumV VU & Gain Reduction Meter (Studio 171)
    studio171::SerumVMeterComponent serumVMeter;
    std::unique_ptr<gui171::VintageConsolePushBank> meterModePushBank;
    std::unique_ptr<gui171::VintageConsolePushBank> channelModePushBank;
    std::unique_ptr<gui171::AnalogStyledKnob> headroomKnob;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> headroomAttach;

    // Componente schermo incassato destro (Scope)
    gui171::WaveformScopeComponent scopeView;

    // 7 Manopole Superiori con CMF differenziato e quadranti graduati dedicati
    std::unique_ptr<gui171::AnalogStyledKnob> driveKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> preampToneKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> threshKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> ratioKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> t4MemoryKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> satKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> outputKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> widthKnob;

    // Controlli inferiori: Modulo Heavy-Duty Bypass con LED + 4 Switch a Levetta 3D (Baton Toggle)
    std::unique_ptr<gui171::HeavyDutyBypassModule> bypassSwitch;
    std::unique_ptr<gui171::SquareConsoleButton> linkSwitch;
    std::unique_ptr<gui171::SquareConsoleButton> modeSwitch;
    std::unique_ptr<gui171::SquareConsoleButton> routingSwitch;
    std::unique_ptr<gui171::SquareConsoleButton> scFilterSwitch;

    // Menu Preset, LookAndFeel e Stepper Boutique
    Studio171ComboBoxLookAndFeel presetLookAndFeel;
    juce::ComboBox presetComboBox;
    std::unique_ptr<gui171::BoutiqueStepperButton> prevPresetBtn;
    std::unique_ptr<gui171::BoutiqueStepperButton> nextPresetBtn;

    // Tracciamento reattivo dell'attività foto-chimica T4 per la lampada a gioiello
    float optoGlowIntensity = 0.0f;

    // Attachments APVTS
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;

    std::unique_ptr<SliderAttachment> driveAttach;
    std::unique_ptr<SliderAttachment> preampToneAttach;
    std::unique_ptr<SliderAttachment> threshAttach;
    std::unique_ptr<SliderAttachment> ratioAttach;
    std::unique_ptr<SliderAttachment> t4MemoryAttach;
    std::unique_ptr<SliderAttachment> satAttach;
    std::unique_ptr<SliderAttachment> outputAttach;
    std::unique_ptr<SliderAttachment> widthAttach;

    std::unique_ptr<ButtonAttachment> bypassAttach;
    std::unique_ptr<ButtonAttachment> linkAttach;
    std::unique_ptr<ButtonAttachment> modeAttach;
    std::unique_ptr<ButtonAttachment> routingAttach;
    std::unique_ptr<ButtonAttachment> scFilterAttach;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AudioPluginAudioProcessorEditor)
};
