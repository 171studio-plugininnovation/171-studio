#include "SerumVMeterComponent.h"

#if __has_include("BinaryData.h")
    #include "BinaryData.h"
#endif

namespace studio171
{

SerumVMeterComponent::SerumVMeterComponent()
{
    setOpaque(false);
    loadBinaryDataAssets();
    startTimerHz(60); // 60 FPS smooth GUI refresh
}

SerumVMeterComponent::~SerumVMeterComponent()
{
    stopTimer();
}

void SerumVMeterComponent::loadBinaryDataAssets()
{
#if __has_include("BinaryData.h")
    if (BinaryData::meter_face_ivory_pngSize > 0)
    {
        dialFaceImage = juce::ImageCache::getFromMemory(BinaryData::meter_face_ivory_png,
                                                        BinaryData::meter_face_ivory_pngSize);
    }
    if (BinaryData::meter_needle_spade_pngSize > 0)
    {
        needleImage = juce::ImageCache::getFromMemory(BinaryData::meter_needle_spade_png,
                                                      BinaryData::meter_needle_spade_pngSize);
    }
    if (BinaryData::meter_glass_reflection_pngSize > 0)
    {
        glassReflectionImage = juce::ImageCache::getFromMemory(BinaryData::meter_glass_reflection_png,
                                                              BinaryData::meter_glass_reflection_pngSize);
    }
#endif
}

void SerumVMeterComponent::setCustomImages(const juce::Image& dial, const juce::Image& needle, const juce::Image& glass)
{
    dialFaceImage = dial;
    needleImage = needle;
    glassReflectionImage = glass;
    repaint();
}

void SerumVMeterComponent::setMeterMode(dsp171::MeterMode mode) noexcept
{
    if (currentMode != mode)
    {
        currentMode = mode;
        if (currentMode == dsp171::MeterMode::GainReduction)
        {
            targetAngleDeg = 18.0f; // 0 dB GR mark
            smoothedAngleDeg = 18.0f;
            ballisticsPos = 1.0f;
        }
        else
        {
            targetAngleDeg = -36.0f;
            smoothedAngleDeg = -36.0f;
            ballisticsPos = 0.0f;
        }
        ballisticsVel = 0.0f;
        repaint();
    }
}

void SerumVMeterComponent::setHeadroom(float headroomDb) noexcept
{
    currentHeadroomDb = juce::jlimit(4.0f, 26.0f, headroomDb);
}

void SerumVMeterComponent::setPhysicalDeflection(float deflection) noexcept
{
    hasDirectDeflection = true;
    currentDeflection = deflection;

    if (currentMode == dsp171::MeterMode::GainReduction)
    {
        // In GR mode: deflection is gain linear (1.0 = 0 dB GR, 0.1 = -20 dB GR)
        // Convert to dB of reduction: 20*log10(deflection)
        float grDb = 0.0f;
        if (deflection >= 1.0f)
            grDb = 0.0f;
        else if (deflection <= 0.0001f)
            grDb = 40.0f;
        else
            grDb = -20.0f * std::log10(deflection);

        targetAngleDeg = gainReductionToAngleDeg(grDb);
    }
    else
    {
        targetAngleDeg = deflectionToAngleDeg(deflection);
    }

    // Direct synchronization with audio-rate ZDF SVF continuous ODE
    smoothedAngleDeg = targetAngleDeg;
    repaint();
}

void SerumVMeterComponent::updateLevel(float instantaneousLinearLevel) noexcept
{
    hasDirectDeflection = false;
    if (instantaneousLinearLevel < 1e-5f)
    {
        currentDeflection = 0.0f;
    }
    else
    {
        float dbfs = 20.0f * std::log10(instantaneousLinearLevel);
        float vuDb = dbfs + currentHeadroomDb;
        currentDeflection = std::pow(10.0f, vuDb / 20.0f);
    }
}

void SerumVMeterComponent::updateGainReduction(float reductionDb) noexcept
{
    hasDirectDeflection = false;
    targetAngleDeg = gainReductionToAngleDeg(juce::jlimit(0.0f, 30.0f, reductionDb));
}

void SerumVMeterComponent::timerCallback()
{
    if (hasDirectDeflection)
    {
        // When driven by SerumVMeterEngine, the ODE ballistics are already calculated in the DSP!
        // We track targetAngleDeg with a very responsive filter for 60/120 Hz display interpolation
        float diff = targetAngleDeg - smoothedAngleDeg;
        smoothedAngleDeg += diff * 0.75f;
    }
    else
    {
        // Fallback mass-spring-damper ballistics at 60 Hz
        if (currentMode == dsp171::MeterMode::GainReduction)
        {
            float diff = targetAngleDeg - smoothedAngleDeg;
            if (diff < 0.0f) // Compressing (moving left)
                smoothedAngleDeg += diff * 0.45f;
            else // Releasing (moving right back to 0 dB)
                smoothedAngleDeg += diff * 0.10f;
        }
        else
        {
            // ANSI C16.5 2nd order simulation
            constexpr float dt = 1.0f / 60.0f;
            constexpr float omega0 = 13.63f;
            constexpr float zeta = 0.816f;
            constexpr float omega0Sq = omega0 * omega0;

            float force = (currentDeflection - ballisticsPos) * omega0Sq;
            float damping = -2.0f * zeta * omega0 * ballisticsVel;
            float accel = force + damping;

            ballisticsVel += accel * dt;
            ballisticsPos += ballisticsVel * dt;

            if (ballisticsPos < -0.02f)
            {
                ballisticsPos = -0.02f;
                ballisticsVel = -ballisticsVel * 0.15f;
            }
            else if (ballisticsPos > 2.0f)
            {
                ballisticsPos = 2.0f;
                ballisticsVel = -ballisticsVel * 0.15f;
            }

            smoothedAngleDeg = deflectionToAngleDeg(ballisticsPos);
        }
    }

    repaint();
}

float SerumVMeterComponent::deflectionToAngleDeg(float deflection) const noexcept
{
    // Calibrated piece-wise nonlinear mapping conforming to Waves VU and ANSI C16.5 dial:
    // def 0.000 (-inf dB) -> -36.0 deg (rest stop pin)
    // def 0.100 (-20 VU)  -> -30.6 deg
    // def 0.316 (-10 VU)  -> -18.9 deg
    // def 0.447 (-7 VU)   -> -11.9 deg
    // def 0.562 (-5 VU)   -> -5.6 deg
    // def 0.708 (-3 VU)   -> +2.2 deg
    // def 1.000 (0 VU)    -> +18.0 deg (Red zone start)
    // def 1.122 (+1 VU)   -> +23.3 deg
    // def 1.259 (+2 VU)   -> +29.3 deg
    // def 1.413 (+3 VU)   -> +36.0 deg (Scale end)
    // def > 1.413         -> up to +37.0 deg (hard stop bumper)
    if (deflection <= 0.0f) return -36.0f;
    if (deflection < 0.100f) return -36.0f + (deflection / 0.100f) * 5.4f;
    if (deflection < 0.316f) return -30.6f + ((deflection - 0.100f) / 0.216f) * 11.7f;
    if (deflection < 0.447f) return -18.9f + ((deflection - 0.316f) / 0.131f) * 7.0f;
    if (deflection < 0.562f) return -11.9f + ((deflection - 0.447f) / 0.115f) * 6.3f;
    if (deflection < 0.708f) return -5.6f  + ((deflection - 0.562f) / 0.146f) * 7.8f;
    if (deflection < 1.000f) return 2.2f   + ((deflection - 0.708f) / 0.292f) * 15.8f;
    if (deflection < 1.122f) return 18.0f  + ((deflection - 1.000f) / 0.122f) * 5.3f;
    if (deflection < 1.259f) return 23.3f  + ((deflection - 1.122f) / 0.137f) * 6.0f;
    if (deflection < 1.413f) return 29.3f  + ((deflection - 1.259f) / 0.154f) * 6.7f;
    return juce::jmin(37.0f, 36.0f + (deflection - 1.413f) * 2.5f);
}

float SerumVMeterComponent::gainReductionToAngleDeg(float grDb) const noexcept
{
    // Calibrated against red Gain Reduction scale on ivory face:
    // 0 dB GR  -> +18.0 deg (aligns with 0 VU mark)
    // 1 dB GR  -> +14.5 deg
    // 2 dB GR  -> +11.2 deg
    // 3 dB GR  -> +8.0 deg
    // 4 dB GR  -> +5.0 deg
    // 6 dB GR  -> -0.5 deg
    // 8 dB GR  -> -5.0 deg
    // 10 dB GR -> -10.0 deg
    // 15 dB GR -> -19.0 deg
    // 20 dB GR -> -28.0 deg
    // > 20 dB  -> extends smoothly toward -35.0 deg
    if (grDb <= 0.0f)  return 18.0f;
    if (grDb <= 1.0f)  return 18.0f - grDb * 3.5f;
    if (grDb <= 2.0f)  return 14.5f - (grDb - 1.0f) * 3.3f;
    if (grDb <= 3.0f)  return 11.2f - (grDb - 2.0f) * 3.2f;
    if (grDb <= 4.0f)  return 8.0f  - (grDb - 3.0f) * 3.0f;
    if (grDb <= 6.0f)  return 5.0f  - ((grDb - 4.0f) / 2.0f) * 5.5f;
    if (grDb <= 8.0f)  return -0.5f - ((grDb - 6.0f) / 2.0f) * 4.5f;
    if (grDb <= 10.0f) return -5.0f - ((grDb - 8.0f) / 2.0f) * 5.0f;
    if (grDb <= 15.0f) return -10.0f - ((grDb - 10.0f) / 5.0f) * 9.0f;
    if (grDb <= 20.0f) return -19.0f - ((grDb - 15.0f) / 5.0f) * 9.0f;
    return juce::jmax(-35.0f, -28.0f - (grDb - 20.0f) * 0.7f);
}

void SerumVMeterComponent::paint(juce::Graphics& g)
{
    const auto bounds = getLocalBounds().toFloat();
    const float w = bounds.getWidth();
    const float h = bounds.getHeight();

    // Clip to rounded chassis window (4.0f radius)
    {
        juce::Path clipPath;
        clipPath.addRoundedRectangle(bounds, 4.0f);
        g.reduceClipRegion(clipPath);
    }

    // Step A: Draw ivory dial face background
    if (dialFaceImage.isValid())
    {
        g.drawImage(dialFaceImage, bounds, juce::RectanglePlacement::stretchToFit);
    }
    else
    {
        // Fallback procedural background
        g.setColour(juce::Colour(0xFFFAF5E8));
        g.fillRoundedRectangle(bounds, 4.0f);
        g.setColour(juce::Colour(0xFF282828));
        g.drawText("VU", bounds.withHeight(40.0f), juce::Justification::centred);
    }

    // Step B: Draw Galvanometric Spade Needle
    const float pivotX = w * kPivotXNorm;
    const float pivotY = h * kPivotYNorm;

    if (needleImage.isValid())
    {
        // In needleImage (40x195), pivot center is at (20, 177)
        const float nw = needleImage.getWidth() * (w / 292.0f);
        const float nh = needleImage.getHeight() * (h / 168.0f);
        const float npivX = 20.0f * (w / 292.0f);
        const float npivY = 177.0f * (h / 168.0f);

        juce::Graphics::ScopedSaveState state(g);
        
        // Needle soft drop shadow
        {
            juce::Graphics::ScopedSaveState shadowState(g);
            g.addTransform(juce::AffineTransform::rotation(juce::degreesToRadians(smoothedAngleDeg), pivotX, pivotY)
                                                 .translated(2.0f, 2.0f));
            g.setOpacity(0.35f);
            g.drawImage(needleImage,
                        static_cast<int>(pivotX - npivX), static_cast<int>(pivotY - npivY),
                        static_cast<int>(nw), static_cast<int>(nh),
                        0, 0, needleImage.getWidth(), needleImage.getHeight());
        }

        // Needle body
        g.addTransform(juce::AffineTransform::rotation(juce::degreesToRadians(smoothedAngleDeg), pivotX, pivotY));
        g.drawImage(needleImage,
                    static_cast<int>(pivotX - npivX), static_cast<int>(pivotY - npivY),
                    static_cast<int>(nw), static_cast<int>(nh),
                    0, 0, needleImage.getWidth(), needleImage.getHeight());
    }
    else
    {
        // Procedural vector needle fallback
        juce::Graphics::ScopedSaveState state(g);
        g.addTransform(juce::AffineTransform::rotation(juce::degreesToRadians(smoothedAngleDeg), pivotX, pivotY));

        const float needleLength = 162.0f * (h / 168.0f);
        juce::Path needlePath;
        needlePath.startNewSubPath(pivotX, pivotY - needleLength);
        needlePath.lineTo(pivotX + 1.2f, pivotY - needleLength + 14.0f);
        needlePath.lineTo(pivotX + 0.8f, pivotY - 20.0f);
        needlePath.lineTo(pivotX + 2.0f, pivotY);
        needlePath.lineTo(pivotX - 2.0f, pivotY);
        needlePath.lineTo(pivotX - 0.8f, pivotY - 20.0f);
        needlePath.lineTo(pivotX - 1.2f, pivotY - needleLength + 14.0f);
        needlePath.closeSubPath();

        // Shadow
        g.setColour(juce::Colours::black.withAlpha(0.35f));
        g.fillPath(needlePath, juce::AffineTransform::translation(1.5f, 1.5f));

        // Body
        g.setColour(juce::Colour(0xFF181818));
        g.fillPath(needlePath);

        // Brass Hub
        const float hubR = 12.0f * (h / 168.0f);
        g.setColour(juce::Colour(0xFFA08040));
        g.fillEllipse(pivotX - hubR, pivotY - hubR, hubR * 2.0f, hubR * 2.0f);
        g.setColour(juce::Colour(0xFFC3A055));
        g.fillEllipse(pivotX - hubR + 2.0f, pivotY - hubR + 2.0f, (hubR - 2.0f) * 2.0f, (hubR - 2.0f) * 2.0f);
        g.setColour(juce::Colour(0xFF282828));
        g.fillEllipse(pivotX - 3.0f, pivotY - 3.0f, 6.0f, 6.0f);
    }

    // Step C: Draw Studio Glass Reflection Overlay (on top of needle)
    if (glassReflectionImage.isValid())
    {
        g.drawImage(glassReflectionImage, bounds, juce::RectanglePlacement::stretchToFit);
    }

    // Step D: Outer Bezel Rim and CNC Chamfer
    g.setColour(juce::Colour(0x50c5a059));
    g.drawRoundedRectangle(bounds, 4.0f, 1.2f);
    g.setColour(juce::Colour(0x35000000));
    g.drawRoundedRectangle(bounds.reduced(1.0f), 3.0f, 1.0f);
}

void SerumVMeterComponent::resized()
{
}

} // namespace studio171
