#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_graphics/juce_graphics.h>
#include <cmath>
#include <vector>

namespace plugin_171
{
    // ==============================================================================
    // 3. MODULO TOGGLE SWITCH, PULSANTI QUADRATI E MICRO-LED ("Vintage Toggle & Push Stage")
    // ==============================================================================
    class VintageToggleAndPushStageLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        VintageToggleAndPushStageLookAndFeel() {}

        void drawToggleButton(juce::Graphics& g, juce::ToggleButton& button,
                              bool isHighlighted, bool isDown) override
        {
            auto bounds = button.getLocalBounds().toFloat();
            auto compId = button.getComponentID();
            bool isOn = button.getToggleState();

            // A. MICRO-LED CIRCOLARE INCASSATO
            if (compId.containsIgnoreCase("led"))
            {
                drawMicroLed(g, bounds, isOn);
                return;
            }

            // B. PULSANTE QUADRATO IN CORNICE D'OTTONE (Retroilluminato o Plastica Colorata)
            if (compId.containsIgnoreCase("square") || button.getButtonText().isNotEmpty())
            {
                drawSquarePushButton(g, button, bounds, isHighlighted, isDown);
                return;
            }

            // C. TOGGLE SWITCH VINTAGE CON LEVETTA CROMATA
            drawVintageToggleSwitch(g, bounds, isOn, isDown);
        }

        void drawVintageToggleSwitch(juce::Graphics& g, juce::Rectangle<float> bounds, bool isUp, bool isDown)
        {
            const float cx = bounds.getCentreX();
            const float cy = bounds.getCentreY();
            const float rBase = juce::jmin(bounds.getWidth(), bounds.getHeight()) * 0.42f;

            // Ombra portata fissa ghiera verso ore 5
            g.setColour(juce::Colours::black.withAlpha(0.65f));
            g.fillEllipse(cx - rBase + 1.5f, cy - rBase + 3.0f, rBase * 2.0f, rBase * 2.0f);

            // Ghiera zigrinata in ottone (24 denti)
            juce::Path knurl;
            const int numTeeth = 24;
            const float rInnerTooth = rBase * 0.88f;
            for (int i = 0; i < numTeeth; ++i)
            {
                float a1 = (float)i * juce::MathConstants<float>::twoPi / 24.0f;
                float a2 = a1 + (juce::MathConstants<float>::twoPi / 24.0f) * 0.5f;
                float x1 = cx + std::cos(a1) * rBase,      y1 = cy + std::sin(a1) * rBase;
                float x2 = cx + std::cos(a2) * rInnerTooth, y2 = cy + std::sin(a2) * rInnerTooth;
                if (i == 0) knurl.startNewSubPath(x1, y1);
                else        knurl.lineTo(x1, y1);
                knurl.lineTo(x2, y2);
            }
            knurl.closeSubPath();

            juce::ColourGradient knurlGrad(
                juce::Colour::fromString("ffdeb868"), cx - rBase, cy - rBase,
                juce::Colour::fromString("ff4a371c"), cx + rBase, cy + rBase, false);
            g.setGradientFill(knurlGrad);
            g.fillPath(knurl);

            // Incasso interno concavo nero profondo
            const float rConcave = rBase * 0.74f;
            juce::ColourGradient concaveGrad(
                juce::Colour::fromString("ff14100c"), cx, cy - rConcave,
                juce::Colour::fromString("ff2e2417"), cx, cy + rConcave, false);
            g.setGradientFill(concaveGrad);
            g.fillEllipse(cx - rConcave, cy - rConcave, rConcave * 2.0f, rConcave * 2.0f);

            // Bullone centrale dorato
            const float rBolt = rConcave * 0.55f;
            g.setColour(juce::Colour::fromString("ffa3803c"));
            g.fillEllipse(cx - rBolt, cy - rBolt, rBolt * 2.0f, rBolt * 2.0f);
            g.setColour(juce::Colour::fromString("fffff3b0").withAlpha(0.7f));
            g.drawEllipse(cx - rBolt, cy - rBolt, rBolt * 2.0f, rBolt * 2.0f, 0.8f);

            // Levetta cromata rastremata con punta sferica
            const float batLen = rBase * 1.55f;
            const float batTipR = rBolt * 0.42f;
            const float angle = isUp ? -0.55f : 0.55f; // UP (-31°) vs DOWN (+31°)

            float tipX = cx + std::sin(angle) * batLen;
            float tipY = cy - std::cos(angle) * batLen * 0.72f;

            // Ombra portata della levetta
            juce::Path shadowPath;
            shadowPath.startNewSubPath(cx + 3.0f, cy + 2.0f);
            shadowPath.lineTo(tipX + 6.0f, tipY + 8.0f);
            shadowPath.lineTo(tipX + 2.0f, tipY + 8.0f);
            shadowPath.closeSubPath();
            g.setColour(juce::Colours::black.withAlpha(0.45f));
            g.strokePath(shadowPath, juce::PathStrokeType(batTipR * 2.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Corpo cromo rastremato
            juce::Path baton;
            float perpX = std::cos(angle) * (rBolt * 0.38f);
            float perpY = std::sin(angle) * (rBolt * 0.38f);
            baton.startNewSubPath(cx - perpX, cy - perpY);
            baton.lineTo(tipX - perpX * 0.6f, tipY - perpY * 0.6f);
            baton.lineTo(tipX + perpX * 0.6f, tipY + perpY * 0.6f);
            baton.lineTo(cx + perpX, cy + perpY);
            baton.closeSubPath();

            juce::ColourGradient chromeGrad(
                juce::Colour::fromString("ffffffff"), cx - perpX, cy,
                juce::Colour::fromString("ff545b63"), cx + perpX, cy, false);
            chromeGrad.addColour(0.35, juce::Colour::fromString("ffd6dde6"));
            g.setGradientFill(chromeGrad);
            g.fillPath(baton);

            // Testa sferica cromo lucido
            juce::ColourGradient sphereGrad(
                juce::Colour::fromString("ffffffff"), tipX - batTipR * 0.35f, tipY - batTipR * 0.35f,
                juce::Colour::fromString("ff383d42"), tipX + batTipR, tipY + batTipR, true);
            g.setGradientFill(sphereGrad);
            g.fillEllipse(tipX - batTipR, tipY - batTipR, batTipR * 2.0f, batTipR * 2.0f);
        }

        void drawSquarePushButton(juce::Graphics& g, juce::Button& button, juce::Rectangle<float> bounds,
                                  bool isHighlighted, bool isDown)
        {
            auto b = bounds.reduced(2.0f);
            bool isOn = button.getToggleState();
            juce::String text = button.getButtonText();

            // Ombra esterna
            g.setColour(juce::Colours::black.withAlpha(0.60f));
            g.fillRoundedRectangle(b.translated(1.5f, 2.5f), 5.0f);

            // Cornice d'ottone con bevel dorato
            juce::ColourGradient frameGrad(
                juce::Colour::fromString("ffdeb868"), b.getX(), b.getY(),
                juce::Colour::fromString("ff422f16"), b.getRight(), b.getBottom(), false);
            g.setGradientFill(frameGrad);
            g.drawRoundedRectangle(b, 5.0f, 2.2f);

            // Incasso interno nero profondo
            auto innerBounds = b.reduced(3.2f);
            g.setColour(juce::Colour::fromString("ff12100d"));
            g.fillRoundedRectangle(innerBounds, 3.0f);

            // Corsa meccanica del tasto (1px verso il basso se premuto)
            auto capBounds = innerBounds.reduced(isDown ? 1.5f : 1.0f);
            if (isDown) capBounds.translate(0.0f, 1.0f);

            if (text.isNotEmpty())
            {
                // VARIANTE RETROILLUMINATA AMBRA (#ffbe55)
                if (isOn)
                {
                    auto gc = capBounds.getCentre();
                    juce::ColourGradient amberGlow(
                        juce::Colour::fromString("ffffbe55"), gc.x, gc.y,
                        juce::Colour::fromString("ffc45d0e"), gc.x, gc.y + capBounds.getHeight() * 0.65f, true);
                    g.setGradientFill(amberGlow);
                    g.fillRoundedRectangle(capBounds, 2.5f);

                    g.setColour(juce::Colour::fromString("fffff1b8").withAlpha(0.75f));
                    g.drawRoundedRectangle(capBounds, 2.5f, 1.0f);

                    // Testo nero nitido centrato
                    g.setColour(juce::Colour::fromString("ff121212"));
                    g.setFont(juce::Font("Arial", 11.5f, juce::Font::bold));
                    g.drawText(text, capBounds, juce::Justification::centred, false);
                }
                else
                {
                    // Stato spento: plastica grigio-bruno opaca
                    juce::ColourGradient dimPlastic(
                        juce::Colour::fromString("ff36312c"), capBounds.getX(), capBounds.getY(),
                        juce::Colour::fromString("ff1f1c19"), capBounds.getX(), capBounds.getBottom(), false);
                    g.setGradientFill(dimPlastic);
                    g.fillRoundedRectangle(capBounds, 2.5f);

                    g.setColour(juce::Colour::fromString("ff5c534a"));
                    g.drawLine(capBounds.getX() + 2.0f, capBounds.getY() + 1.0f, capBounds.getRight() - 2.0f, capBounds.getY() + 1.0f, 1.0f);

                    g.setColour(juce::Colour::fromString("ff7a736a"));
                    g.setFont(juce::Font("Arial", 11.5f, juce::Font::bold));
                    g.drawText(text, capBounds, juce::Justification::centred, false);
                }
            }
            else
            {
                // VARIANTE PLASTICA COLORATA CON BEVEL 3D (Rosso, Blu, Grigio)
                juce::Colour baseColour = button.findColour(juce::TextButton::buttonColourId);
                if (baseColour.isTransparent()) baseColour = juce::Colour::fromString("ffb82c2c"); // Rosso vintage

                juce::Colour topCol = isOn ? baseColour.brighter(0.35f) : baseColour;
                juce::ColourGradient plasticGrad(
                    topCol, capBounds.getX(), capBounds.getY(),
                    topCol.darker(0.65f), capBounds.getX(), capBounds.getBottom(), false);
                g.setGradientFill(plasticGrad);
                g.fillRoundedRectangle(capBounds, 2.5f);

                // Bevel 3D: bordo superiore chiaro, bordo inferiore scuro
                g.setColour(topCol.brighter(0.50f));
                g.drawLine(capBounds.getX() + 2.0f, capBounds.getY() + 1.0f, capBounds.getRight() - 2.0f, capBounds.getY() + 1.0f, 1.2f);
                g.setColour(topCol.darker(0.80f));
                g.drawLine(capBounds.getX() + 2.0f, capBounds.getBottom() - 1.0f, capBounds.getRight() - 2.0f, capBounds.getBottom() - 1.0f, 1.2f);
            }
        }

        void drawMicroLed(juce::Graphics& g, juce::Rectangle<float> bounds, bool isOn)
        {
            const float size = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx = bounds.getCentreX();
            const float cy = bounds.getCentreY();
            const float r = size * 0.38f;

            // Pozzetto metallico incassato
            g.setColour(juce::Colour::fromString("ff14100c"));
            g.fillEllipse(cx - r - 1.5f, cy - r - 1.5f, (r + 1.5f) * 2.0f, (r + 1.5f) * 2.0f);
            g.setColour(juce::Colour::fromString("ffd6b467"));
            g.drawEllipse(cx - r - 1.5f, cy - r - 1.5f, (r + 1.5f) * 2.0f, (r + 1.5f) * 2.0f, 1.0f);

            if (isOn)
            {
                // Glow ambra diffuso
                juce::ColourGradient ledBloom(
                    juce::Colour::fromString("ffffa824").withAlpha(0.65f), cx, cy,
                    juce::Colour::fromString("ffff4800").withAlpha(0.0f), cx, cy + r * 2.2f, true);
                g.setGradientFill(ledBloom);
                g.fillEllipse(cx - r * 2.2f, cy - r * 2.2f, r * 4.4f, r * 4.4f);

                // Punto luce incandescente giallo/ambra
                juce::ColourGradient ledCore(
                    juce::Colour::fromString("fffff5c2"), cx - r * 0.3f, cy - r * 0.3f,
                    juce::Colour::fromString("ffff8c12"), cx, cy + r, true);
                g.setGradientFill(ledCore);
                g.fillEllipse(cx - r, cy - r, r * 2.0f, r * 2.0f);
            }
            else
            {
                // LED spento (lente opaca ambra scuro)
                g.setColour(juce::Colour::fromString("ff3d2208"));
                g.fillEllipse(cx - r, cy - r, r * 2.0f, r * 2.0f);
                g.setColour(juce::Colours::white.withAlpha(0.25f));
                g.fillEllipse(cx - r * 0.5f, cy - r * 0.5f, r * 0.6f, r * 0.35f);
            }
        }
    };


    // ==============================================================================
    // 4. DOPPIO VU METER CIRCOLARE CON TRIM KNOBS ("CircularVuMeter")
    // ==============================================================================
    class CircularVuMeter : public juce::Component
    {
    public:
        CircularVuMeter(juce::String channelLabel = "L")
            : channel(channelLabel)
        {
            setOpaque(false);
        }

        /**
         * @brief Imposta il valore VU da visualizzare (-30.0 dB a +3.0 dB).
         */
        void setValue(float vuDb)
        {
            currentDb = juce::jlimit(-30.0f, 3.0f, vuDb);
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float size  = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx    = bounds.getCentreX();
            const float cy    = bounds.getCentreY();
            const float rOut  = size * 0.48f;

            // 1. CORNICE ROTONDA SPESSA IN CANNA DI FUCILE SPAZZOLATO CON FILETTO DORATO
            // Ombra esterna telaio
            g.setColour(juce::Colours::black.withAlpha(0.68f));
            g.fillEllipse(cx - rOut + 2.5f, cy - rOut + 5.0f, rOut * 2.0f, rOut * 2.0f);

            // Gradiente circolare canna di fucile
            juce::ColourGradient frameGrad(
                juce::Colour::fromString("ff423e3b"), cx - rOut, cy - rOut,
                juce::Colour::fromString("ff191716"), cx + rOut, cy + rOut, false);
            g.setGradientFill(frameGrad);
            g.fillEllipse(cx - rOut, cy - rOut, rOut * 2.0f, rOut * 2.0f);

            // Filetto esterno dorato
            g.setColour(juce::Colour::fromString("ffd6b467"));
            g.drawEllipse(cx - rOut + 1.5f, cy - rOut + 1.5f, (rOut - 1.5f) * 2.0f, (rOut - 1.5f) * 2.0f, 1.8f);

            // Spazzolatura concentrica
            for (float cr = rOut * 0.85f; cr < rOut; cr += 2.2f)
            {
                g.setColour(juce::Colours::white.withAlpha(0.04f));
                g.drawEllipse(cx - cr, cy - cr, cr * 2.0f, cr * 2.0f, 0.6f);
            }

            // 2. QUADRANTE INTERNO CREMA (#f2e6c9) CON ILLUMINAZIONE DAL BASSO
            const float rDial = rOut * 0.82f;
            g.setColour(juce::Colour::fromString("ff14110e"));
            g.fillEllipse(cx - rDial, cy - rDial, rDial * 2.0f, rDial * 2.0f);

            // Fondo crema vintage con luce calda incandescente dal basso
            juce::ColourGradient dialGrad(
                juce::Colour::fromString("ffe0d0aa"), cx, cy - rDial,
                juce::Colour::fromString("ffffebba"), cx, cy + rDial, false);
            dialGrad.addColour(0.60, juce::Colour::fromString("fff2e6c9"));
            g.setGradientFill(dialGrad);
            g.fillEllipse(cx - rDial + 1.5f, cy - rDial + 1.5f, (rDial - 1.5f) * 2.0f, (rDial - 1.5f) * 2.0f);

            // Ombra interna superiore quadrante
            g.setColour(juce::Colours::black.withAlpha(0.35f));
            g.drawEllipse(cx - rDial + 1.5f, cy - rDial + 1.5f, (rDial - 1.5f) * 2.0f, (rDial - 1.5f) * 2.0f, 3.0f);

            // 3. SCALE AD ARCO DA -30 A +3 dB (Arco nero e arco rosso oltre 0 VU)
            const float scaleR = rDial * 0.72f;
            const float angleMin = -juce::MathConstants<float>::pi * 0.32f; // -57.6°
            const float angleMax =  juce::MathConstants<float>::pi * 0.32f; // +57.6°
            const float angleZero = angleMin + 0.82f * (angleMax - angleMin); // 0 VU all'82%

            // Arco scala normale nero
            juce::Path arcBlack;
            arcBlack.addCentredArc(cx, cy + rDial * 0.28f, scaleR, scaleR, 0.0f, angleMin, angleZero, true);
            g.setColour(juce::Colour::fromString("ff211d18"));
            g.strokePath(arcBlack, juce::PathStrokeType(1.5f));

            // Arco rosso sopra 0 VU
            juce::Path arcRed;
            arcRed.addCentredArc(cx, cy + rDial * 0.28f, scaleR, scaleR, 0.0f, angleZero, angleMax, true);
            g.setColour(juce::Colour::fromString("ffd12a2a"));
            g.strokePath(arcRed, juce::PathStrokeType(2.5f));

            // Tacche della scala VU: -20, -10, -7, -5, -3, -1, 0, +1, +2, +3
            const struct { float db; const char* label; } vuTicks[] = {
                { -20.0f, "20" }, { -10.0f, "10" }, { -7.0f, "7" }, { -5.0f, "5" },
                { -3.0f,  "3"  }, { -1.0f,  "1"  }, { 0.0f,  "0" }, { +1.0f, "1" },
                { +2.0f,  "2"  }, { +3.0f,  "3"  }
            };

            const float pivotY = cy + rDial * 0.28f;
            g.setFont(juce::Font("Arial", 8.0f, juce::Font::bold));

            for (const auto& tk : vuTicks)
            {
                // Mappatura non-lineare standard scala VU analogica
                float norm = 0.0f;
                if (tk.db <= 0.0f) norm = (tk.db + 20.0f) / 20.0f * 0.82f;
                else               norm = 0.82f + (tk.db / 3.0f) * 0.18f;

                float a = angleMin + norm * (angleMax - angleMin) - juce::MathConstants<float>::halfPi;
                float tx1 = cx + std::cos(a) * (scaleR - 5.0f);
                float ty1 = pivotY + std::sin(a) * (scaleR - 5.0f);
                float tx2 = cx + std::cos(a) * (scaleR + 2.0f);
                float ty2 = pivotY + std::sin(a) * (scaleR + 2.0f);

                bool isRed = (tk.db > 0.0f);
                g.setColour(isRed ? juce::Colour::fromString("ffd12a2a") : juce::Colour::fromString("ff211d18"));
                g.drawLine(tx1, ty1, tx2, ty2, 1.2f);

                // Testo decibel
                float lx = cx + std::cos(a) * (scaleR - 12.0f);
                float ly = pivotY + std::sin(a) * (scaleR - 12.0f);
                g.drawText(tk.label, lx - 10.0f, ly - 6.0f, 20.0f, 12.0f, juce::Justification::centred);
            }

            // Scritta "VU" centrata
            g.setFont(juce::Font("Arial", 11.0f, juce::Font::bold));
            g.setColour(juce::Colour::fromString("ff26211c"));
            g.drawText("VU", cx - 25.0f, cy - rDial * 0.35f, 50.0f, 14.0f, juce::Justification::centred);

            // 4. AGO NERO A LANCIA CON OMBRA PORTATA DINAMICA
            float currentNorm = 0.0f;
            if (currentDb <= 0.0f) currentNorm = (currentDb + 20.0f) / 20.0f * 0.82f;
            else                  currentNorm = 0.82f + (currentDb / 3.0f) * 0.18f;
            currentNorm = juce::jlimit(0.0f, 1.0f, currentNorm);

            const float needleAngle = angleMin + currentNorm * (angleMax - angleMin) - juce::MathConstants<float>::halfPi;
            const float needleLen   = scaleR + 4.0f;
            const float tipX        = cx + std::cos(needleAngle) * needleLen;
            const float tipY        = pivotY + std::sin(needleAngle) * needleLen;

            // Ombra portata dell'ago (proiettata verso ore 5)
            g.setColour(juce::Colours::black.withAlpha(0.35f));
            g.drawLine(cx + 3.0f, pivotY + 4.0f, tipX + 4.0f, tipY + 4.0f, 2.0f);

            // Ago nero affusolato a lancia
            juce::Path needle;
            float perpA = needleAngle + juce::MathConstants<float>::halfPi;
            needle.startNewSubPath(cx - std::cos(perpA) * 2.0f, pivotY - std::sin(perpA) * 2.0f);
            needle.lineTo(tipX, tipY);
            needle.lineTo(cx + std::cos(perpA) * 2.0f, pivotY + std::sin(perpA) * 2.0f);
            needle.closeSubPath();
            g.setColour(juce::Colour::fromString("ff1a1714"));
            g.fillPath(needle);

            // 5. SCUDO INFERIORE SAGOMATO A ONDA (COPEN-PERNO) CON LETTERA "L" / "R" INCISA
            juce::Path shieldPath;
            const float sW = rDial * 1.05f;
            const float sH = rDial * 0.65f;
            shieldPath.startNewSubPath(cx - sW * 0.5f, cy + rDial * 0.95f);
            shieldPath.cubicTo(cx - sW * 0.35f, pivotY - 10.0f,
                               cx - sW * 0.15f, pivotY - 14.0f,
                               cx, pivotY - 14.0f);
            shieldPath.cubicTo(cx + sW * 0.15f, pivotY - 14.0f,
                               cx + sW * 0.35f, pivotY - 10.0f,
                               cx + sW * 0.5f, cy + rDial * 0.95f);
            shieldPath.closeSubPath();

            // Ombra e corpo dello scudo in canna di fucile
            g.setColour(juce::Colours::black.withAlpha(0.60f));
            juce::Path sShadow = shieldPath;
            sShadow.applyTransform(juce::AffineTransform::translation(0.0f, 2.0f));
            g.fillPath(sShadow);

            juce::ColourGradient shieldGrad(
                juce::Colour::fromString("ff38332e"), cx, pivotY - 14.0f,
                juce::Colour::fromString("ff1a1714"), cx, cy + rDial, false);
            g.setGradientFill(shieldGrad);
            g.fillPath(shieldPath);

            g.setColour(juce::Colour::fromString("ffd6b467"));
            g.strokePath(shieldPath, juce::PathStrokeType(1.2f));

            // Lettera "L" o "R" incisa dorata
            g.setFont(juce::Font("Arial", 14.0f, juce::Font::bold));
            g.setColour(juce::Colour::fromString("ff110e0a"));
            g.drawText(channel, cx - 15.0f, pivotY + 2.0f, 30.0f, 18.0f, juce::Justification::centred);
            g.setColour(juce::Colour::fromString("ffd6b467"));
            g.drawText(channel, cx - 15.0f, pivotY + 1.0f, 30.0f, 18.0f, juce::Justification::centred);

            // 6. RIFLESSO CURVO DEL VETRO NELLA METÀ SUPERIORE
            juce::Path glassReflection;
            glassReflection.addCentredArc(cx, cy, rDial - 2.0f, rDial - 2.0f, 0.0f,
                                          -juce::MathConstants<float>::pi * 0.45f,
                                           juce::MathConstants<float>::pi * 0.45f, true);
            glassReflection.cubicTo(cx + rDial * 0.6f, cy - rDial * 0.1f,
                                   cx - rDial * 0.6f, cy - rDial * 0.1f,
                                   cx - rDial * 0.7f, cy - rDial * 0.35f);
            glassReflection.closeSubPath();

            juce::ColourGradient glassGrad(
                juce::Colours::white.withAlpha(0.18f), cx, cy - rDial,
                juce::Colours::white.withAlpha(0.01f), cx, cy, false);
            g.setGradientFill(glassGrad);
            g.fillPath(glassReflection);
        }

    private:
        float currentDb = -20.0f;
        juce::String channel = "L";
    };

    // Micro-manopole nere zigrinate di taratura (Trim Knobs)
    class MiniTrimKnobLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        MiniTrimKnobLookAndFeel() {}

        void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                              float sliderPosProportional, float rotaryStartAngle, float rotaryEndAngle,
                              juce::Slider& slider) override
        {
            const auto bounds = juce::Rectangle<float>((float)x, (float)y, (float)width, (float)height);
            const float cx = bounds.getCentreX(), cy = bounds.getCentreY();
            const float r = juce::jmin(bounds.getWidth(), bounds.getHeight()) * 0.42f;
            const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

            g.setColour(juce::Colours::black.withAlpha(0.55f));
            g.fillEllipse(cx - r + 1.0f, cy - r + 2.0f, r * 2.0f, r * 2.0f);

            // Zigrinatura laterale nera
            juce::Path knurl;
            for (int i = 0; i < 20; ++i)
            {
                float a = (float)i * juce::MathConstants<float>::twoPi / 20.0f;
                float px = cx + std::cos(a) * r;
                float py = cy + std::sin(a) * r;
                if (i == 0) knurl.startNewSubPath(px, py);
                else        knurl.lineTo(px, py);
            }
            knurl.closeSubPath();
            g.setColour(juce::Colour::fromString("ff1f1d1b"));
            g.fillPath(knurl);

            // Faccia superiore e tacca
            const float rFace = r * 0.80f;
            g.setColour(juce::Colour::fromString("ff2e2b28"));
            g.fillEllipse(cx - rFace, cy - rFace, rFace * 2.0f, rFace * 2.0f);

            float tx = cx + std::cos(angle - juce::MathConstants<float>::halfPi) * (rFace - 1.0f);
            float ty = cy + std::sin(angle - juce::MathConstants<float>::halfPi) * (rFace - 1.0f);
            g.setColour(juce::Colour::fromString("ffd6b467"));
            g.drawLine(cx, cy, tx, ty, 1.2f);
        }
    };


    // ==============================================================================
    // 5. MANOPOLE MODERNE CON ANELLO NEON LUMINOSO ("Drive / Punch / Warmth")
    // ==============================================================================
    class NeonHaloKnobLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        NeonHaloKnobLookAndFeel(juce::Colour neonColour = juce::Colour::fromString("ffff7a00"))
            : haloColour(neonColour) {}

        void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                              float sliderPosProportional, float rotaryStartAngle, float rotaryEndAngle,
                              juce::Slider& slider) override
        {
            const auto bounds = juce::Rectangle<float>((float)x, (float)y, (float)width, (float)height);
            const float size  = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx    = bounds.getCentreX();
            const float cy    = bounds.getCentreY();
            const float rBase = size * 0.40f;
            const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

            // 1. ARCO LUMINOSO ESTERNO CON EFFETTO NEON (ALONE DIFFUSO SUL PANNELLO)
            const float arcR = rBase * 1.15f;
            juce::Path neonArc;
            neonArc.addCentredArc(cx, cy, arcR, arcR, 0.0f, rotaryStartAngle, angle, true);

            // Multi-stroke glow per effetto alone neon continuo
            g.setColour(haloColour.withAlpha(0.20f));
            g.strokePath(neonArc, juce::PathStrokeType(8.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            g.setColour(haloColour.withAlpha(0.50f));
            g.strokePath(neonArc, juce::PathStrokeType(4.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            g.setColour(haloColour.brighter(0.40f));
            g.strokePath(neonArc, juce::PathStrokeType(2.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            g.setColour(juce::Colours::white);
            g.strokePath(neonArc, juce::PathStrokeType(0.8f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // 2. CORPO MANOPOLA CILINDRICO NERO ZIGRINATO CON DROP SHADOW PROFONDA
            g.setColour(juce::Colours::black.withAlpha(0.75f));
            g.fillEllipse(cx - rBase + 2.0f, cy - rBase + 5.0f, rBase * 2.0f, rBase * 2.0f);

            // Parete zigrinata scura
            juce::ColourGradient knurlBody(
                juce::Colour::fromString("ff302d2a"), cx - rBase, cy - rBase,
                juce::Colour::fromString("ff121110"), cx + rBase, cy + rBase, false);
            g.setGradientFill(knurlBody);
            g.fillEllipse(cx - rBase, cy - rBase, rBase * 2.0f, rBase * 2.0f);

            // 3. CAPPUCCIO SUPERIORE IN ACCIAIO SCURO CON SPAZZOLATURA CONICA (Riflesso a farfalla)
            const float rCap = rBase * 0.88f;
            juce::ColourGradient butterflyGrad(
                juce::Colour::fromString("ff524e49"), cx, cy - rCap,
                juce::Colour::fromString("ff1f1d1b"), cx, cy + rCap, false);
            butterflyGrad.addColour(0.25, juce::Colour::fromString("ff3b3834"));
            butterflyGrad.addColour(0.50, juce::Colour::fromString("ff6b655f"));
            butterflyGrad.addColour(0.75, juce::Colour::fromString("ff292725"));
            g.setGradientFill(butterflyGrad);
            g.fillEllipse(cx - rCap, cy - rCap, rCap * 2.0f, rCap * 2.0f);

            g.setColour(juce::Colour::fromString("ff7a736a").withAlpha(0.6f));
            g.drawEllipse(cx - rCap, cy - rCap, rCap * 2.0f, rCap * 2.0f, 1.0f);

            // 4. TACCA A CAPSULA INCASSATA ILLUMINATA DELLO STESSO COLORE DELL'ANELLO
            const float capLen = rCap * 0.38f;
            const float capW   = 3.2f;
            juce::Path pillNotch;
            pillNotch.addRoundedRectangle(-capW * 0.5f, -rCap + 2.0f, capW, capLen, capW * 0.5f);

            juce::Path transformedPill = pillNotch;
            transformedPill.applyTransform(juce::AffineTransform::rotation(angle).translated(cx, cy));

            // Incasso scuro
            g.setColour(juce::Colour::fromString("ff0d0c0b"));
            g.strokePath(transformedPill, juce::PathStrokeType(1.2f));

            // Bagliore neon capsula
            g.setColour(haloColour);
            g.fillPath(transformedPill);
            g.setColour(juce::Colours::white.withAlpha(0.85f));
            g.fillEllipse(transformedPill.getBounds().getCentreX() - 1.0f, transformedPill.getBounds().getY() + 1.5f, 2.0f, 2.0f);
        }

    private:
        juce::Colour haloColour;
    };


    // ==============================================================================
    // 6. SEZIONE "THE GOD EQ – OUTPUT / TELEMETRY" (Knob + 3 Meter Verticali)
    // ==============================================================================
    class GodEqOutputKnobLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        GodEqOutputKnobLookAndFeel() {}

        void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                              float sliderPosProportional, float rotaryStartAngle, float rotaryEndAngle,
                              juce::Slider& slider) override
        {
            const auto bounds = juce::Rectangle<float>((float)x, (float)y, (float)width, (float)height);
            const float size  = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx    = bounds.getCentreX();
            const float cy    = bounds.getCentreY();
            const float rBase = size * 0.38f;
            const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

            // 1. SCALA GRADUATA ESTERNA IN ORO ROSA (#d69f85)
            const float scaleR = rBase * 1.18f;
            const int numTicks = 31;
            for (int i = 0; i < numTicks; ++i)
            {
                float norm = (float)i / (float)(numTicks - 1);
                float a = rotaryStartAngle + norm * (rotaryEndAngle - rotaryStartAngle) - juce::MathConstants<float>::halfPi;
                bool isMajor = (i % 5 == 0);
                float len = isMajor ? 5.5f : 3.0f;

                float x1 = cx + std::cos(a) * scaleR;
                float y1 = cy + std::sin(a) * scaleR;
                float x2 = cx + std::cos(a) * (scaleR + len);
                float y2 = cy + std::sin(a) * (scaleR + len);

                g.setColour(juce::Colour::fromString("ffd69f85").withAlpha(isMajor ? 0.90f : 0.50f));
                g.drawLine(x1, y1, x2, y2, isMajor ? 1.4f : 0.8f);
            }

            // 2. CORPO MANOPOLA NERA OPACA CON DOPPIO ANELLO DORATO SOTTILE
            g.setColour(juce::Colours::black.withAlpha(0.65f));
            g.fillEllipse(cx - rBase + 2.0f, cy - rBase + 4.0f, rBase * 2.0f, rBase * 2.0f);

            juce::ColourGradient knobGrad(
                juce::Colour::fromString("ff2e2b29"), cx - rBase, cy - rBase,
                juce::Colour::fromString("ff141312"), cx + rBase, cy + rBase, false);
            g.setGradientFill(knobGrad);
            g.fillEllipse(cx - rBase, cy - rBase, rBase * 2.0f, rBase * 2.0f);

            // Doppio anello concentrico dorato
            g.setColour(juce::Colour::fromString("ffd6b467"));
            g.drawEllipse(cx - rBase * 0.88f, cy - rBase * 0.88f, rBase * 1.76f, rBase * 1.76f, 0.9f);
            g.drawEllipse(cx - rBase * 0.76f, cy - rBase * 0.76f, rBase * 1.52f, rBase * 1.52f, 0.9f);

            // 3. TACCA VERTICALE IN RILIEVO
            float tx = cx + std::cos(angle - juce::MathConstants<float>::halfPi) * (rBase * 0.70f);
            float ty = cy + std::sin(angle - juce::MathConstants<float>::halfPi) * (rBase * 0.70f);
            g.setColour(juce::Colour::fromString("fffff0b8"));
            g.drawLine(cx, cy, tx, ty, 2.0f);
        }
    };

    class TelemetryMeterComponent : public juce::Component
    {
    public:
        TelemetryMeterComponent() { setOpaque(false); }

        void setLevels(float left0to1, float right0to1)
        {
            lvlL = juce::jlimit(0.0f, 1.0f, left0to1);
            lvlR = juce::jlimit(0.0f, 1.0f, right0to1);
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float w  = bounds.getWidth();
            const float h  = bounds.getHeight();

            // Finestra incassata nera
            g.setColour(juce::Colour::fromString("ff100f0e"));
            g.fillRoundedRectangle(bounds, 3.0f);
            g.setColour(juce::Colours::black.withAlpha(0.75f));
            g.drawRoundedRectangle(bounds, 3.0f, 2.0f);

            // Scala centrale da 0 a -60
            const float colW = w * 0.28f;
            const float midX = bounds.getX() + w * 0.5f;

            g.setFont(juce::Font("Arial", 7.5f, juce::Font::plain));
            g.setColour(juce::Colour::fromString("ff8c8278"));
            const char* dbs[] = { "0", "-6", "-12", "-18", "-24", "-36", "-48", "-60" };
            for (int i = 0; i < 8; ++i)
            {
                float y = bounds.getY() + 10.0f + ((float)i / 7.0f) * (h - 20.0f);
                g.drawText(dbs[i], midX - 12.0f, y - 5.0f, 24.0f, 10.0f, juce::Justification::centred);
            }

            // Doppia colonna di micro-segmenti LED fitti (32 segmenti)
            const int segCount = 32;
            const float segH = (h - 24.0f) / (float)segCount - 1.0f;

            auto drawColumn = [&](float x, float level)
            {
                int litSegs = juce::roundToInt(level * (float)segCount);
                for (int s = 0; s < segCount; ++s)
                {
                    float sy = bounds.getBottom() - 12.0f - (float)(s + 1) * (segH + 1.0f);
                    bool isLit = (s < litSegs);
                    juce::Colour col = (s > 26) ? juce::Colour::fromString("ffff3b14") :
                                       (s > 18) ? juce::Colour::fromString("ffffa824") :
                                                  juce::Colour::fromString("ff42d4f5");

                    if (isLit)
                    {
                        g.setColour(col);
                        g.fillRect(x, sy, colW, segH);
                    }
                    else
                    {
                        g.setColour(juce::Colour::fromString("ff1c1a17"));
                        g.fillRect(x, sy, colW, segH);
                    }
                }
            };

            drawColumn(bounds.getX() + 6.0f, lvlL);
            drawColumn(bounds.getRight() - colW - 6.0f, lvlR);

            // Riflesso diagonale in vetro
            juce::Path glass;
            glass.startNewSubPath(bounds.getX(), bounds.getBottom());
            glass.lineTo(bounds.getRight(), bounds.getY() + h * 0.35f);
            glass.lineTo(bounds.getRight(), bounds.getY());
            glass.lineTo(bounds.getX(), bounds.getY() + h * 0.25f);
            glass.closeSubPath();
            g.setColour(juce::Colours::white.withAlpha(0.08f));
            g.fillPath(glass);
        }

    private:
        float lvlL = 0.5f, lvlR = 0.5f;
    };


    // ==============================================================================
    // 7. EQUALIZZATORE IN ALLUMINIO CHIARO SPAZZOLATO ("The God EQ – Silver")
    // ==============================================================================
    class SilverMasterPanelRenderer
    {
    public:
        static void paintSilverPanel(juce::Graphics& g, juce::Rectangle<float> bounds)
        {
            // Sfondo argento (#c8cacd)
            juce::ColourGradient silverGrad(
                juce::Colour::fromString("ffd6d8db"), bounds.getX(), bounds.getY(),
                juce::Colour::fromString("ffb0b3b8"), bounds.getRight(), bounds.getBottom(), false);
            g.setGradientFill(silverGrad);
            g.fillRect(bounds);

            // Linee di spazzolatura orizzontale procedurali
            for (float y = bounds.getY() + 1.0f; y < bounds.getBottom(); y += 2.0f)
            {
                float a = (std::fmod(y, 4.0f) < 2.0f) ? 0.06f : 0.02f;
                g.setColour(juce::Colours::white.withAlpha(a));
                g.drawHorizontalLine((int)y, bounds.getX(), bounds.getRight());
            }

            // Doppia cornice smussata
            g.setColour(juce::Colour::fromString("ffffffff").withAlpha(0.7f));
            g.drawRect(bounds.reduced(2.0f), 1.0f);
            g.setColour(juce::Colour::fromString("ff7d8187"));
            g.drawRect(bounds.reduced(4.0f), 1.0f);

            // 8 Viti Torx incassate in pozzetti circolari
            const float pW = bounds.getWidth(), pH = bounds.getHeight();
            const struct { float x, y; } screws[8] = {
                { 18.0f, 18.0f }, { pW * 0.33f, 18.0f }, { pW * 0.67f, 18.0f }, { pW - 18.0f, 18.0f },
                { 18.0f, pH - 18.0f }, { pW * 0.33f, pH - 18.0f }, { pW * 0.67f, pH - 18.0f }, { pW - 18.0f, pH - 18.0f }
            };

            for (const auto& sc : screws)
            {
                // Pozzetto circolare tornito
                g.setColour(juce::Colour::fromString("ff8f9399"));
                g.fillEllipse(sc.x - 5.0f, sc.y - 5.0f, 10.0f, 10.0f);
                g.setColour(juce::Colour::fromString("ffe8ebed"));
                g.drawEllipse(sc.x - 5.0f, sc.y - 5.0f, 10.0f, 10.0f, 0.8f);

                // Testa vite Torx
                juce::ColourGradient screwGrad(
                    juce::Colour::fromString("ffffffff"), sc.x - 3.5f, sc.y - 3.5f,
                    juce::Colour::fromString("ff6b6f75"), sc.x + 3.5f, sc.y + 3.5f, false);
                g.setGradientFill(screwGrad);
                g.fillEllipse(sc.x - 3.5f, sc.y - 3.5f, 7.0f, 7.0f);

                // Stella Torx 6 punte
                juce::Path star;
                for (int p = 0; p < 12; ++p)
                {
                    float a = (float)p * juce::MathConstants<float>::pi / 6.0f;
                    float rStar = (p % 2 == 0) ? 2.0f : 1.0f;
                    float px = sc.x + std::cos(a) * rStar;
                    float py = sc.y + std::sin(a) * rStar;
                    if (p == 0) star.startNewSubPath(px, py);
                    else        star.lineTo(px, py);
                }
                star.closeSubPath();
                g.setColour(juce::Colour::fromString("ff36383b"));
                g.fillPath(star);
            }
        }
    };

    class SilverTornitoKnobLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        SilverTornitoKnobLookAndFeel() {}

        void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                              float sliderPosProportional, float rotaryStartAngle, float rotaryEndAngle,
                              juce::Slider& slider) override
        {
            const auto bounds = juce::Rectangle<float>((float)x, (float)y, (float)width, (float)height);
            const float size  = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx    = bounds.getCentreX();
            const float cy    = bounds.getCentreY();
            const float rBase = size * 0.40f;
            const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

            // 1. SCALA GRADUATA NERA AD ALTA DENSITÀ (7 tacche principali con testo + tacche corte)
            const float scaleR = rBase * 1.15f;
            const int numTicks = 41;
            g.setFont(juce::Font("Arial", 7.5f, juce::Font::bold));

            for (int i = 0; i < numTicks; ++i)
            {
                float norm = (float)i / (float)(numTicks - 1);
                float a = rotaryStartAngle + norm * (rotaryEndAngle - rotaryStartAngle) - juce::MathConstants<float>::halfPi;
                bool isMajor = (i % 6 == 0);
                float len = isMajor ? 5.5f : 2.5f;

                float x1 = cx + std::cos(a) * scaleR;
                float y1 = cy + std::sin(a) * scaleR;
                float x2 = cx + std::cos(a) * (scaleR + len);
                float y2 = cy + std::sin(a) * (scaleR + len);

                g.setColour(juce::Colour::fromString("ff212326").withAlpha(isMajor ? 0.90f : 0.45f));
                g.drawLine(x1, y1, x2, y2, isMajor ? 1.4f : 0.8f);
            }

            // 2. ANELLO DI FONDO NERO NELLA FESSURA E PARETE ZIGRINATA
            g.setColour(juce::Colours::black.withAlpha(0.60f));
            g.fillEllipse(cx - rBase + 1.5f, cy - rBase + 4.0f, rBase * 2.0f, rBase * 2.0f);

            g.setColour(juce::Colour::fromString("ff1a1c1e"));
            g.fillEllipse(cx - rBase, cy - rBase, rBase * 2.0f, rBase * 2.0f);

            // 3. CAPPUCCIO IN ALLUMINIO CHIARO CON EFFETTO TORNITO (4 quadranti)
            const float rCap = rBase * 0.88f;
            juce::ColourGradient tornitoGrad(
                juce::Colour::fromString("ffffffff"), cx, cy - rCap,
                juce::Colour::fromString("ff9aa0a6"), cx, cy + rCap, false);
            tornitoGrad.addColour(0.25, juce::Colour::fromString("ffc8cbcf"));
            tornitoGrad.addColour(0.50, juce::Colour::fromString("ffffffff"));
            tornitoGrad.addColour(0.75, juce::Colour::fromString("ffb0b5ba"));
            g.setGradientFill(tornitoGrad);
            g.fillEllipse(cx - rCap, cy - rCap, rCap * 2.0f, rCap * 2.0f);

            // Bordo lucido
            g.setColour(juce::Colours::white.withAlpha(0.85f));
            g.drawEllipse(cx - rCap, cy - rCap, rCap * 2.0f, rCap * 2.0f, 1.2f);

            // Micro-spazzolatura concentrica
            for (float cr = 6.0f; cr < rCap; cr += 2.5f)
            {
                g.setColour(juce::Colours::white.withAlpha(0.05f));
                g.drawEllipse(cx - cr, cy - cr, cr * 2.0f, cr * 2.0f, 0.6f);
            }

            // Tacca indicatrice nera fresata nel metallo
            float tx = cx + std::cos(angle - juce::MathConstants<float>::halfPi) * (rCap - 1.0f);
            float ty = cy + std::sin(angle - juce::MathConstants<float>::halfPi) * (rCap - 1.0f);
            g.setColour(juce::Colour::fromString("ff141617"));
            g.drawLine(cx, cy, tx, ty, 2.0f);
            g.setColour(juce::Colours::white.withAlpha(0.5f));
            g.drawLine(cx + 0.5f, cy + 0.5f, tx + 0.5f, ty + 0.5f, 0.8f);
        }
    };
}
