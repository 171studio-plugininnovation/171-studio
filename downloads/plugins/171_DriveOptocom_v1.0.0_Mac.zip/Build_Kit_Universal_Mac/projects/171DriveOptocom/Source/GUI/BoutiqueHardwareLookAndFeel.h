#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_graphics/juce_graphics.h>
#include <cmath>

namespace plugin_171
{
    // ==============================================================================
    // 1. PANNELLO OTTONE ANTICO ANISOTROPICO E CORNICE BEVELED
    // ==============================================================================
    class BoutiqueHardwareRenderer
    {
    public:
        /**
         * @brief Disegna il pannello frontale skeuomorfico in ottone antico spazzolato.
         * 
         * 1. Sfondo a gradiente radiale conico (bronzo scuro #2b231b e oro caldo #78562b)
         *    + anelli concentrici sottilissimi per la spazzolatura radiale.
         * 2. Cornice perimetrale a 45° con bordo dorato beveled e 4 viti Phillips agli angoli.
         * 3. Barre divisorie verticali in rilievo in ottone per separare le sezioni.
         */
        static void paintBoutiqueBrassPanel(juce::Graphics& g, juce::Rectangle<float> bounds)
        {
            auto w = bounds.getWidth();
            auto h = bounds.getHeight();
            auto cx = bounds.getCentreX();
            auto cy = bounds.getCentreY();

            // --- 1. SFONDO IN OTTONE CONICO / RADIALE SPUNTATO ---
            juce::Colour bronzeDark = juce::Colour::fromString("ff2b231b");
            juce::Colour goldWarm   = juce::Colour::fromString("ff78562b");
            juce::Colour goldShine  = juce::Colour::fromString("ffa87e42");

            float maxRadius = std::hypot(w * 0.5f, h * 0.5f);
            juce::ColourGradient radialGrad(goldWarm, cx, cy, bronzeDark, cx, cy + maxRadius, true);
            radialGrad.addColour(0.25, goldShine);
            radialGrad.addColour(0.65, goldWarm);
            radialGrad.addColour(0.90, bronzeDark);

            g.setGradientFill(radialGrad);
            g.fillRect(bounds);

            // Archi concentrici sottilissimi semitrasparenti (micro-spazzolatura circolare sunburst)
            float step = 3.5f;
            for (float r = 15.0f; r < maxRadius; r += step)
            {
                float alpha = (std::fmod(r, 7.0f) < 3.5f) ? 0.045f : 0.020f;
                g.setColour(juce::Colours::white.withAlpha(alpha));
                g.drawEllipse(cx - r, cy - r, r * 2.0f, r * 2.0f, 0.75f);

                g.setColour(juce::Colours::black.withAlpha(alpha * 1.5f));
                g.drawEllipse(cx - r - 0.5f, cy - r - 0.5f, (r + 0.5f) * 2.0f, (r + 0.5f) * 2.0f, 0.75f);
            }

            // --- 2. CORNICE PERIMETRALE A 45° E BORDO LUMINOSO DORATO ---
            float inset = 12.0f;
            float chamfer = 16.0f;
            auto fBounds = bounds.reduced(inset);

            juce::Path framePath;
            // 8 vertici con angoli tagliati a 45°
            framePath.startNewSubPath(fBounds.getX() + chamfer, fBounds.getY());
            framePath.lineTo(fBounds.getRight() - chamfer, fBounds.getY());
            framePath.lineTo(fBounds.getRight(), fBounds.getY() + chamfer);
            framePath.lineTo(fBounds.getRight(), fBounds.getBottom() - chamfer);
            framePath.lineTo(fBounds.getRight() - chamfer, fBounds.getBottom());
            framePath.lineTo(fBounds.getX() + chamfer, fBounds.getBottom());
            framePath.lineTo(fBounds.getX(), fBounds.getBottom() - chamfer);
            framePath.lineTo(fBounds.getX(), fBounds.getY() + chamfer);
            framePath.closeSubPath();

            // Ombra interna d'incasso
            g.setColour(juce::Colours::black.withAlpha(0.55f));
            g.strokePath(framePath, juce::PathStrokeType(3.0f));

            // Bordo metallico beveled dorato
            juce::ColourGradient goldBorderGrad(
                juce::Colour::fromString("ffffeb99"), fBounds.getX(), fBounds.getY(),
                juce::Colour::fromString("ff4a371c"), fBounds.getRight(), fBounds.getBottom(), false);
            g.setGradientFill(goldBorderGrad);
            g.strokePath(framePath, juce::PathStrokeType(1.5f));

            // --- 3. QUATTRO VITI PHILLIPS AGLI ANGOLI (LUCE FISSA 105°) ---
            float screwOffset = 24.0f;
            std::vector<juce::Point<float>> screwPositions = {
                { bounds.getX() + screwOffset, bounds.getY() + screwOffset },
                { bounds.getRight() - screwOffset, bounds.getY() + screwOffset },
                { bounds.getX() + screwOffset, bounds.getBottom() - screwOffset },
                { bounds.getRight() - screwOffset, bounds.getBottom() - screwOffset }
            };

            // Angolazioni diverse per ogni vite (evita l'effetto clone)
            float angles[] = { 18.0f, 52.0f, 76.0f, 112.0f };
            for (size_t i = 0; i < screwPositions.size(); ++i)
                paintPhillipsScrew(g, screwPositions[i].x, screwPositions[i].y, 7.5f, angles[i]);

            // --- 4. BARRE DIVISORIE VERTICALI IN RILIEVO IN OTTONE ---
            float sec1_x = bounds.getX() + w * 0.33f;
            float sec2_x = bounds.getX() + w * 0.67f;
            float topY   = fBounds.getY() + 18.0f;
            float botY   = fBounds.getBottom() - 18.0f;

            paintBrassDivider(g, sec1_x, topY, botY);
            paintBrassDivider(g, sec2_x, topY, botY);
        }

        static void paintPhillipsScrew(juce::Graphics& g, float cx, float cy, float radius, float angleDeg)
        {
            // Drop shadow fissa verso il basso-destra
            g.setColour(juce::Colours::black.withAlpha(0.60f));
            g.fillEllipse(cx - radius + 1.2f, cy - radius + 2.0f, radius * 2.0f, radius * 2.0f);

            // Cupola metallica con sfumatura d'ottone
            juce::ColourGradient screwGrad(
                juce::Colour::fromString("ffa8864c"), cx - radius, cy - radius,
                juce::Colour::fromString("ff362615"), cx + radius, cy + radius, false);
            g.setGradientFill(screwGrad);
            g.fillEllipse(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f);

            // Bordo luce superiore
            g.setColour(juce::Colour::fromString("fffff3b0").withAlpha(0.70f));
            g.drawEllipse(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f, 0.8f);

            // Taglio Phillips a croce inclinato
            float rad = juce::degreesToRadians(angleDeg);
            float len = radius * 0.70f;
            float thick = 1.6f;

            juce::Path cross;
            cross.startNewSubPath(cx - std::cos(rad) * len, cy - std::sin(rad) * len);
            cross.lineTo(cx + std::cos(rad) * len, cy + std::sin(rad) * len);
            cross.startNewSubPath(cx - std::cos(rad + juce::MathConstants<float>::halfPi) * len,
                                  cy - std::sin(rad + juce::MathConstants<float>::halfPi) * len);
            cross.lineTo(cx + std::cos(rad + juce::MathConstants<float>::halfPi) * len,
                         cy + std::sin(rad + juce::MathConstants<float>::halfPi) * len);

            // Ombra scura nel taglio + highlight
            g.setColour(juce::Colour::fromString("ff150f09"));
            g.strokePath(cross, juce::PathStrokeType(thick, juce::PathStrokeType::mitered, juce::PathStrokeType::butt));

            g.setColour(juce::Colour::fromString("fffff3b0").withAlpha(0.40f));
            g.strokePath(cross, juce::PathStrokeType(0.6f, juce::PathStrokeType::mitered, juce::PathStrokeType::butt));
        }

        static void paintBrassDivider(juce::Graphics& g, float x, float topY, float botY)
        {
            // Barra in rilievo: scanalatura nera a sinistra, highlight dorato a destra
            g.setColour(juce::Colour::fromString("ff140f0a").withAlpha(0.75f));
            g.drawLine(x - 1.0f, topY, x - 1.0f, botY, 1.2f);

            juce::ColourGradient barGrad(
                juce::Colour::fromString("ffcba358"), x, topY,
                juce::Colour::fromString("ff423019"), x, botY, false);
            g.setGradientFill(barGrad);
            g.drawLine(x, topY, x, botY, 1.5f);

            g.setColour(juce::Colour::fromString("fffff0a8").withAlpha(0.60f));
            g.drawLine(x + 1.0f, topY, x + 1.0f, botY, 0.8f);
        }
    };


    // ==============================================================================
    // 2. LOOKANDFEEL COMPLETO: TOGGLE SWITCH & PULSANTI QUADRATI
    // ==============================================================================
    class BoutiqueHardwareLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        BoutiqueHardwareLookAndFeel()
        {
            // Palette colori predefinita
            setColour(juce::ToggleButton::textColourId, juce::Colours::white);
        }

        // --------------------------------------------------------------------------
        // PROMPT 2: TOGGLE SWITCH CON GHIERA ZIGRINATA IN OTTONE
        // --------------------------------------------------------------------------
        void drawToggleButton(juce::Graphics& g, juce::ToggleButton& button,
                              bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override
        {
            // Se il pulsante è configurato con testo o proprietà speciale, possiamo reindirizzare
            if (button.getComponentID().containsIgnoreCase("square") || button.getButtonText().isNotEmpty())
            {
                drawSquareConsoleButton(g, button, shouldDrawButtonAsHighlighted, shouldDrawButtonAsDown);
                return;
            }

            drawVintageToggleSwitch(g, button, shouldDrawButtonAsHighlighted, shouldDrawButtonAsDown);
        }

        /**
         * @brief Disegna la levetta toggle con ghiera dentellata in ottone, anello concavo e leva cromata.
         */
        void drawVintageToggleSwitch(juce::Graphics& g, juce::ToggleButton& button,
                                     bool isHighlighted, bool isDown)
        {
            auto bounds = button.getLocalBounds().toFloat();
            auto cx = bounds.getCentreX();
            auto cy = bounds.getCentreY();
            bool isUp = button.getToggleState();

            // Raggio ghiera
            float rOuter = juce::jmin(bounds.getWidth(), bounds.getHeight()) * 0.40f;

            // --- A. GHIERA ESTERNA ZIGRINATA IN OTTONE (DENTELLATURA 360°) ---
            juce::Path knurledRing;
            int numTeeth = 24;
            float rInnerTooth = rOuter * 0.88f;

            for (int i = 0; i < numTeeth; ++i)
            {
                float a1 = (float)i * juce::MathConstants<float>::twoPi / (float)numTeeth;
                float a2 = a1 + (juce::MathConstants<float>::twoPi / (float)numTeeth) * 0.5f;

                float x1 = cx + std::cos(a1) * rOuter;
                float y1 = cy + std::sin(a1) * rOuter;
                float x2 = cx + std::cos(a2) * rInnerTooth;
                float y2 = cy + std::sin(a2) * rInnerTooth;

                if (i == 0) knurledRing.startNewSubPath(x1, y1);
                else        knurledRing.lineTo(x1, y1);
                knurledRing.lineTo(x2, y2);
            }
            knurledRing.closeSubPath();

            // Ombra di contatto sotto la ghiera
            g.setColour(juce::Colours::black.withAlpha(0.65f));
            g.fillEllipse(cx - rOuter + 1.5f, cy - rOuter + 3.0f, rOuter * 2.0f, rOuter * 2.0f);

            // Gradiente dorato ottone sulla zigrinatura
            juce::ColourGradient knurlGrad(
                juce::Colour::fromString("ffdeb868"), cx - rOuter, cy - rOuter,
                juce::Colour::fromString("ff5c401a"), cx + rOuter, cy + rOuter, false);
            g.setGradientFill(knurlGrad);
            g.fillPath(knurledRing);

            // --- B. ANELLO INTERNO CONCAVO SCURO E BULLONE CENTRALE ---
            float rConcave = rOuter * 0.76f;
            juce::ColourGradient concaveGrad(
                juce::Colour::fromString("ff181410"), cx, cy - rConcave,
                juce::Colour::fromString("ff3d3122"), cx, cy + rConcave, false);
            g.setGradientFill(concaveGrad);
            g.fillEllipse(cx - rConcave, cy - rConcave, rConcave * 2.0f, rConcave * 2.0f);

            // Colletto/Bullone centrale esagonale smussato
            float rBolt = rConcave * 0.58f;
            g.setColour(juce::Colour::fromString("ffa88648"));
            g.fillEllipse(cx - rBolt, cy - rBolt, rBolt * 2.0f, rBolt * 2.0f);
            g.setColour(juce::Colour::fromString("fffff5c2").withAlpha(0.8f));
            g.drawEllipse(cx - rBolt, cy - rBolt, rBolt * 2.0f, rBolt * 2.0f, 1.0f);

            // --- C. LEVETTA CROMATA CONICA E OMBRA PROIETTATA ---
            // Levetta: UP (inclinata verso l'alto a -35°) | DOWN (inclinata in basso a +35°)
            float batLen = rOuter * 1.55f;
            float batTipR = rBolt * 0.45f;
            float angle = isUp ? -0.55f : 0.55f;

            float tipX = cx + std::sin(angle) * batLen;
            float tipY = cy - std::cos(angle) * batLen * 0.70f;

            // Ombra portata della levetta sul pannello/colletto (fissa verso ore 5)
            juce::Path batonShadow;
            batonShadow.startNewSubPath(cx + 4.0f, cy + 2.0f);
            batonShadow.lineTo(tipX + 6.0f, tipY + 8.0f);
            batonShadow.lineTo(tipX + 2.0f, tipY + 8.0f);
            batonShadow.closeSubPath();
            g.setColour(juce::Colours::black.withAlpha(0.45f));
            g.strokePath(batonShadow, juce::PathStrokeType(batTipR * 2.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Corpo conico levetta cromata
            juce::Path baton;
            float perpX = std::cos(angle) * (rBolt * 0.40f);
            float perpY = std::sin(angle) * (rBolt * 0.40f);

            baton.startNewSubPath(cx - perpX, cy - perpY);
            baton.lineTo(tipX - perpX * 0.6f, tipY - perpY * 0.6f);
            baton.lineTo(tipX + perpX * 0.6f, tipY + perpY * 0.6f);
            baton.lineTo(cx + perpX, cy + perpY);
            baton.closeSubPath();

            juce::ColourGradient chromeGrad(
                juce::Colour::fromString("ffffffff"), cx - perpX, cy,
                juce::Colour::fromString("ff7a8288"), cx + perpX, cy, false);
            chromeGrad.addColour(0.40, juce::Colour::fromString("ffe0e8f0"));
            chromeGrad.addColour(0.75, juce::Colour::fromString("ff50555a"));

            g.setGradientFill(chromeGrad);
            g.fillPath(baton);

            // Punta sferica terminale del baton cromato
            juce::ColourGradient tipSphere(
                juce::Colour::fromString("ffffffff"), tipX - batTipR * 0.4f, tipY - batTipR * 0.4f,
                juce::Colour::fromString("ff40454a"), tipX + batTipR, tipY + batTipR, true);
            g.setGradientFill(tipSphere);
            g.fillEllipse(tipX - batTipR, tipY - batTipR, batTipR * 2.0f, batTipR * 2.0f);
        }

        // --------------------------------------------------------------------------
        // PROMPT 3: PULSANTI QUADRATI (RETROILLUMINATI E COLORATI)
        // --------------------------------------------------------------------------
        void drawSquareConsoleButton(juce::Graphics& g, juce::Button& button,
                                     bool isHighlighted, bool isDown)
        {
            auto bounds = button.getLocalBounds().toFloat().reduced(2.0f);
            bool isOn = button.getToggleState();
            juce::String text = button.getButtonText();

            // --- A. CORNICE ESTERNA IN OTTONE/BRONZO & INCASSO NERO ---
            // Ombra di contatto esterna
            g.setColour(juce::Colours::black.withAlpha(0.60f));
            g.fillRoundedRectangle(bounds.translated(1.5f, 2.5f), 5.0f);

            // Cornice smussata con gradiente metallico
            juce::ColourGradient frameGrad(
                juce::Colour::fromString("ffdeb868"), bounds.getX(), bounds.getY(),
                juce::Colour::fromString("ff422f16"), bounds.getRight(), bounds.getBottom(), false);
            g.setGradientFill(frameGrad);
            g.drawRoundedRectangle(bounds, 5.0f, 2.2f);

            // Incasso interno nero profondo
            auto innerBounds = bounds.reduced(3.2f);
            g.setColour(juce::Colour::fromString("ff12100d"));
            g.fillRoundedRectangle(innerBounds, 3.0f);

            // Area del tasto mobile (se premuto si sposta leggermente verso il basso)
            auto capBounds = innerBounds.reduced(isDown ? 1.5f : 1.0f);
            if (isDown)
                capBounds.translate(0.0f, 1.0f);

            // --- B. RENDERING CAP: TESTO VS COLORE PURO ---
            if (text.isNotEmpty())
            {
                if (isOn)
                {
                    // STATO ON: Radiale Ambra Luminoso (#ffcf70 al centro, #c86414 ai bordi)
                    auto glowCenter = capBounds.getCentre();
                    float glowRadius = capBounds.getWidth() * 0.70f;
                    juce::ColourGradient amberGlow(
                        juce::Colour::fromString("ffffcf70"), glowCenter.x, glowCenter.y,
                        juce::Colour::fromString("ffc86414"), glowCenter.x, glowCenter.y + glowRadius, true);
                    g.setGradientFill(amberGlow);
                    g.fillRoundedRectangle(capBounds, 2.5f);

                    // Bordo illuminato interno
                    g.setColour(juce::Colour::fromString("fffff2b8").withAlpha(0.70f));
                    g.drawRoundedRectangle(capBounds, 2.5f, 1.0f);

                    // Testo nero puro centrato
                    g.setColour(juce::Colour::fromString("ff121212"));
                    g.setFont(juce::Font("Arial", 12.0f, juce::Font::bold));
                    g.drawText(text, capBounds, juce::Justification::centred, false);
                }
                else
                {
                    // STATO OFF: Plastica grigio-bruno opaca
                    juce::ColourGradient dimPlastic(
                        juce::Colour::fromString("ff3a3530"), capBounds.getX(), capBounds.getY(),
                        juce::Colour::fromString("ff221f1c"), capBounds.getX(), capBounds.getBottom(), false);
                    g.setGradientFill(dimPlastic);
                    g.fillRoundedRectangle(capBounds, 2.5f);

                    // Bevel superiore 1px luce opaca
                    g.setColour(juce::Colour::fromString("ff5c544d"));
                    g.drawLine(capBounds.getX() + 2.0f, capBounds.getY() + 1.0f, capBounds.getRight() - 2.0f, capBounds.getY() + 1.0f, 1.0f);

                    // Testo grigio fioco spento
                    g.setColour(juce::Colour::fromString("ff7a736a"));
                    g.setFont(juce::Font("Arial", 12.0f, juce::Font::bold));
                    g.drawText(text, capBounds, juce::Justification::centred, false);
                }
            }
            else
            {
                // STATO SENZA TESTO: Usa buttonColourId (rosso, blu, grigio)
                juce::Colour baseColour = button.findColour(juce::TextButton::buttonColourId);
                if (baseColour.isTransparent())
                    baseColour = juce::Colour::fromString("ffb83232"); // Default rosso vintage

                juce::Colour litColour = isOn ? baseColour.brighter(0.40f) : baseColour.darker(0.35f);
                juce::ColourGradient colGrad(
                    litColour, capBounds.getX(), capBounds.getY(),
                    litColour.darker(0.60f), capBounds.getX(), capBounds.getBottom(), false);

                g.setGradientFill(colGrad);
                g.fillRoundedRectangle(capBounds, 2.5f);

                if (isOn)
                {
                    // Bagliore di saturazione se acceso
                    g.setColour(litColour.withAlpha(0.40f));
                    g.drawRoundedRectangle(capBounds.expanded(1.5f), 3.0f, 2.0f);
                }
            }
        }
    };
}
