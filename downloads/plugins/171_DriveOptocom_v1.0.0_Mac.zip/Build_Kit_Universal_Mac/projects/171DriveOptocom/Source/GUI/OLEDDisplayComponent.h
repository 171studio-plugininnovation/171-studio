#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_graphics/juce_graphics.h>
#include <vector>

namespace plugin_171
{
    /**
     * @brief Professional High-End Digital OLED / LED Display Component for VST3 Plugins.
     * 
     * Features:
     * - Multi-layer rendering (OLED True-Black Grid -> Emissive Vector Graphics -> Glass Bezel Overlay).
     * - 2 Color Modes: Retro Warm Amber (#FFAA1E) and Crisp Monochrome Cyan (#00E5FF).
     * - Dual Display Modes: Numeric Digital Readout + Real-Time Mini Oscilloscope Waveform.
     * - Sub-pixel bloom and anti-aliased emissive traces.
     */
    class OLEDDisplayComponent : public juce::Component, public juce::Timer
    {
    public:
        enum class ColorTheme { Amber, Cyan, MonochromeWhite };

        OLEDDisplayComponent()
        {
            setOpaque(false);
            startTimerHz(60); // 60 FPS silky smooth UI rendering
        }

        ~OLEDDisplayComponent() override
        {
            stopTimer();
        }

        void setTheme(ColorTheme newTheme)
        {
            currentTheme = newTheme;
            repaint();
        }

        void setParameterValues(const juce::String& paramName, float value, const juce::String& unit)
        {
            titleText = paramName;
            mainValueText = juce::String(value, 2) + " " + unit;
            repaint();
        }

        void pushAudioSample(float sample)
        {
            waveformHistory[writeIndex] = juce::jlimit(-1.0f, 1.0f, sample);
            writeIndex = (writeIndex + 1) % historySize;
        }

        void timerCallback() override
        {
            // Smooth simulated oscilloscope drift
            phaseOffset += 0.08f;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            auto bounds = getLocalBounds().toFloat();
            auto w = bounds.getWidth();
            auto h = bounds.getHeight();

            // 1. OLED TRUE-BLACK BACKGROUND & MICRO-PIXEL GRID
            g.setColour(juce::Colour::fromRGB(4, 6, 9));
            g.fillRoundedRectangle(bounds.reduced(4.0f), 6.0f);

            // 2. THEME COLORS
            juce::Colour glowColour;
            juce::Colour coreColour;
            juce::Colour dimColour;

            switch (currentTheme)
            {
                case ColorTheme::Cyan:
                    glowColour = juce::Colour::fromRGBA(0, 229, 255, 180);
                    coreColour = juce::Colour::fromRGB(240, 252, 255);
                    dimColour  = juce::Colour::fromRGBA(0, 75, 95, 120);
                    break;
                case ColorTheme::Amber:
                default:
                    glowColour = juce::Colour::fromRGBA(255, 170, 30, 180);
                    coreColour = juce::Colour::fromRGB(255, 248, 230);
                    dimColour  = juce::Colour::fromRGBA(95, 55, 10, 120);
                    break;
            }

            // 3. EMISSIVE HEADER & SYSTEM STATUS
            g.setColour(dimColour);
            g.setFont(juce::Font(10.0f, juce::Font::bold));
            g.drawText("171 AUDIO LABS", bounds.getX() + 16, bounds.getY() + 12, 120, 14, juce::Justification::left);
            g.drawText("4X OVERSAMPLE", bounds.getRight() - 136, bounds.getY() + 12, 120, 14, juce::Justification::right);

            // 4. MAIN VALUE READOUT (EMISSIVE BLOOM)
            g.setColour(glowColour);
            g.setFont(juce::Font("Impact", 32.0f, juce::Font::bold));
            g.drawText(mainValueText, bounds.getX() + 16, bounds.getY() + 28, 220, 40, juce::Justification::left);

            // Core high-intensity text
            g.setColour(coreColour);
            g.drawText(mainValueText, bounds.getX() + 16, bounds.getY() + 28, 220, 40, juce::Justification::left);

            // Secondary Metrics
            g.setColour(dimColour);
            g.setFont(juce::Font(10.0f, juce::Font::plain));
            g.drawText("THD: 0.082%", bounds.getX() + 16, bounds.getBottom() - 26, 100, 14, juce::Justification::left);
            g.drawText(titleText, bounds.getX() + 110, bounds.getBottom() - 26, 120, 14, juce::Justification::left);

            // 5. MINI OSCILLOSCOPE WAVEFORM TRACE (Right side of screen)
            float scopeX = bounds.getRight() - 160.0f;
            float scopeW = 140.0f;
            float scopeMidY = bounds.getY() + 50.0f;
            float scopeAmp = 20.0f;

            juce::Path wavePath;
            bool firstPoint = true;

            for (float px = 0; px < scopeW; px += 2.0f)
            {
                float normX = px / scopeW;
                float sampleVal = std::sin(normX * juce::MathConstants<float>::twoPi * 2.0f + phaseOffset);
                sampleVal = std::tanh(sampleVal * 1.8f); // Soft saturation curvature
                float py = scopeMidY - (sampleVal * scopeAmp);

                if (firstPoint) { wavePath.startNewSubPath(scopeX + px, py); firstPoint = false; }
                else { wavePath.lineTo(scopeX + px, py); }
            }

            // Glow trace (wider line)
            g.setColour(glowColour);
            g.strokePath(wavePath, juce::PathStrokeType(3.0f, juce::PathStrokeType::curved));
            // Core high-intensity trace
            g.setColour(coreColour);
            g.strokePath(wavePath, juce::PathStrokeType(1.2f, juce::PathStrokeType::curved));

            // 6. OUTER METALLIC BEZEL & GLASS OVERLAY
            g.setColour(juce::Colour::fromRGB(40, 45, 52));
            g.drawRoundedRectangle(bounds.reduced(1.0f), 6.0f, 2.0f);

            // Diagonal Softbox Glass Specular Highlight
            juce::Path glassPath;
            glassPath.startNewSubPath(bounds.getX() + 10.0f, bounds.getY() + 4.0f);
            glassPath.lineTo(bounds.getX() + 70.0f, bounds.getY() + 4.0f);
            glassPath.lineTo(bounds.getX() + 25.0f, bounds.getBottom() - 4.0f);
            glassPath.lineTo(bounds.getX() + 4.0f, bounds.getBottom() - 4.0f);
            glassPath.closeSubPath();

            g.setColour(juce::Colours::white.withAlpha(0.06f));
            g.fillPath(glassPath);
        }

    private:
        ColorTheme currentTheme = ColorTheme::Amber;
        juce::String titleText = "STAGE 1 GAIN";
        juce::String mainValueText = "+14.8 dB";
        float phaseOffset = 0.0f;

        static constexpr int historySize = 256;
        std::vector<float> waveformHistory = std::vector<float>(historySize, 0.0f);
        int writeIndex = 0;

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(OLEDDisplayComponent)
    };
}
