#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <dsp171/LockFreeFIFO.h>
#include <BinaryData.h>
#include <array>
#include <cmath>
#include <algorithm>

namespace gui171 {

// ==============================================================================
// 1. SCHERMO SINISTRO: DUAL STEREO ANALOG VU & T4B GAIN REDUCTION (DOPPIA LANCETTA L/R)
// ==============================================================================
class AnalogVUMeterComponent : public juce::Component {
public:
    enum class DisplayMode {
        AnalogVU_GR, // Dual Galvanometer con DOPPIA lancetta L (Rosso) e R (Oro/Ambra)
        StereoLED    // Stereo LED Tower indipendente per canali L e R
    };

    enum class PointerStyle {
        ClassicNeedle, // Lancette meccaniche calibrate
        RadioSweeper   // Sweeper radiofonico a rubino incandescente
    };

    explicit AnalogVUMeterComponent(dsp171::LockFreeVisualFIFO<512>& /*fifoToUse*/)
    {
        setOpaque(false);

        // Caricamento asset SVG ufficiali
        bezelImg = juce::ImageCache::getFromMemory(
            BinaryData::Display_VU_Meter_Bezel_CastMetal_4Screws_Master_1024x765_png,
            BinaryData::Display_VU_Meter_Bezel_CastMetal_4Screws_Master_1024x765_pngSize);

        vuDialImg = juce::ImageCache::getFromMemory(
            BinaryData::Display_VU_Meter_Dial_VUGain_Clean_Master_1024x765_png,
            BinaryData::Display_VU_Meter_Dial_VUGain_Clean_Master_1024x765_pngSize);

        grDialImg = juce::ImageCache::getFromMemory(
            BinaryData::Display_VU_Meter_Dial_GainReduction_Clean_Master_1024x765_png,
            BinaryData::Display_VU_Meter_Dial_GainReduction_Clean_Master_1024x765_pngSize);

        needleImg = juce::ImageCache::getFromMemory(
            BinaryData::Meter_Needle_VintageRedTip_MechanicalMovement_Master_1024x765_png,
            BinaryData::Meter_Needle_VintageRedTip_MechanicalMovement_Master_1024x765_pngSize);

        sweeperImg = juce::ImageCache::getFromMemory(
            BinaryData::Meter_Sweeper_VintageRadio_IlluminatedRuby_Master_1024x765_png,
            BinaryData::Meter_Sweeper_VintageRadio_IlluminatedRuby_Master_1024x765_pngSize);

        glassOverlayImg = juce::ImageCache::getFromMemory(
            BinaryData::display_glass_overlay_png,
            BinaryData::display_glass_overlay_pngSize);

        ledBoxImg = juce::ImageCache::getFromMemory(
            BinaryData::led_meter_clean_png,
            BinaryData::led_meter_clean_pngSize);
    }

    ~AnalogVUMeterComponent() override = default;

    void resized() override {
        rebuildMeterBackgrounds();
    }

    void mouseDown(const juce::MouseEvent& e) override {
        if (e.mods.isRightButtonDown() || e.mods.isShiftDown()) {
            mode = (mode == DisplayMode::AnalogVU_GR) ? DisplayMode::StereoLED : DisplayMode::AnalogVU_GR;
        } else {
            pointerStyle = (pointerStyle == PointerStyle::ClassicNeedle) ? PointerStyle::RadioSweeper : PointerStyle::ClassicNeedle;
        }
        repaint();
    }

    // Chiamato a 60 Hz direttamente dall'Editor principale (SPSC zero contention)
    void updateFrame(const dsp171::VisualFrame& frame, bool hasData) {
        if (hasData) {
            targetOutRMS_L = frame.outRMS_L;
            targetOutRMS_R = frame.outRMS_R;
            targetPeakL    = frame.peak_L;
            targetPeakR    = frame.peak_R;
            targetGR_L_dB  = frame.gainReduction_L;
            targetGR_R_dB  = frame.gainReduction_R;
        } else {
            targetOutRMS_L *= 0.90f;
            targetOutRMS_R *= 0.90f;
            targetPeakL    *= 0.88f;
            targetPeakR    *= 0.88f;
            targetGR_L_dB  *= 0.85f;
            targetGR_R_dB  *= 0.85f;
        }

        constexpr float dt = 1.0f / 60.0f;

        // 1. Calibrazione Angolo VU Meter (0% = -29.60°, 70% 0VU = +12.50°, 100% +3VU = +28.20°)
        auto toVUAngle = [](float linearRMS) noexcept -> float {
            float db = 20.0f * std::log10(std::max(linearRMS, 1.0e-5f));
            float vuNorm = std::clamp((db + 20.0f) / 23.0f, 0.0f, 1.0f);
            float deg = 0.0f;
            if (vuNorm <= 0.70f) {
                float t = vuNorm / 0.70f;
                deg = -29.60f + t * (12.50f - (-29.60f));
            } else {
                float t = (vuNorm - 0.70f) / 0.30f;
                deg = 12.50f + t * (28.20f - 12.50f);
            }
            return juce::degreesToRadians(deg);
        };

        const float targetAngleVU_L = toVUAngle(targetOutRMS_L);
        const float targetAngleVU_R = toVUAngle(targetOutRMS_R);
        constexpr float kSpring = 46.0f;
        constexpr float cDamping = 8.8f;

        // Ballistica molla smorzata Canale Sinistro (L)
        float forceVU_L = -kSpring * (needleAngleVU_L - targetAngleVU_L) - cDamping * needleVelVU_L;
        needleVelVU_L += forceVU_L * dt;
        needleAngleVU_L += needleVelVU_L * dt;

        // Ballistica molla smorzata Canale Destro (R)
        float forceVU_R = -kSpring * (needleAngleVU_R - targetAngleVU_R) - cDamping * needleVelVU_R;
        needleVelVU_R += forceVU_R * dt;
        needleAngleVU_R += needleVelVU_R * dt;

        // 2. Calibrazione Angolo Gain Reduction (0 dB Riposo = +34.50°, -20 dB GR = -26.10°)
        auto toGRAngle = [](float gr_dB) noexcept -> float {
            float mag = std::clamp(std::abs(gr_dB), 0.0f, 20.0f);
            float norm = mag / 20.0f;
            float deg = 34.50f - norm * (34.50f - (-26.10f));
            return juce::degreesToRadians(deg);
        };

        const float targetAngleGR_L = toGRAngle(targetGR_L_dB);
        const float targetAngleGR_R = toGRAngle(targetGR_R_dB);

        float forceGR_L = -kSpring * (needleAngleGR_L - targetAngleGR_L) - (cDamping * 1.15f) * needleVelGR_L;
        needleVelGR_L += forceGR_L * dt;
        needleAngleGR_L += needleVelGR_L * dt;

        float forceGR_R = -kSpring * (needleAngleGR_R - targetAngleGR_R) - (cDamping * 1.15f) * needleVelGR_R;
        needleVelGR_R += forceGR_R * dt;
        needleAngleGR_R += needleVelGR_R * dt;

        // Ballistica Stereo LED Tower indipendente per L e R
        float dbPeakL = 20.0f * std::log10(std::max(targetPeakL, 1.0e-5f));
        float dbPeakR = 20.0f * std::log10(std::max(targetPeakR, 1.0e-5f));
        float dbRmsL  = 20.0f * std::log10(std::max(targetOutRMS_L, 1.0e-5f));
        float dbRmsR  = 20.0f * std::log10(std::max(targetOutRMS_R, 1.0e-5f));

        dispRmsL += 0.25f * (dbRmsL - dispRmsL);
        dispRmsR += 0.25f * (dbRmsR - dispRmsR);
        dispPeakL = std::max(dispPeakL - 24.0f * dt, dbPeakL);
        dispPeakR = std::max(dispPeakR - 24.0f * dt, dbPeakR);

        repaint();
    }

    void paint(juce::Graphics& g) override {
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());

        if (mode == DisplayMode::AnalogVU_GR) {
            paintDualGalvanometer(g, w, h);
        } else {
            paintStereoLEDTower(g, w, h);
        }
    }

private:
    void rebuildMeterBackgrounds() {
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());
        if (w <= 1.0f || h <= 1.0f) return;

        const float halfW = w * 0.5f;
        constexpr float SVG_ASPECT = 1024.0f / 765.0f;
        float targetW = halfW;
        float targetH = h;
        if (targetW / targetH > SVG_ASPECT) {
            targetW = targetH * SVG_ASPECT;
        } else {
            targetH = targetW / SVG_ASPECT;
        }
        int wInt = juce::roundToInt(targetW);
        int hInt = juce::roundToInt(targetH);
        if (wInt <= 0 || hInt <= 0) return;

        auto renderBg = [this, wInt, hInt](const juce::Image& dial, const juce::String& title) -> juce::Image {
            juce::Image bg(juce::Image::ARGB, wInt, hInt, true);
            juce::Graphics bgG(bg);
            auto r = juce::Rectangle<float>(0.0f, 0.0f, static_cast<float>(wInt), static_cast<float>(hInt));

            // 1. Quadrante calibrato autentico
            if (dial.isValid()) {
                bgG.drawImage(dial, r, juce::RectanglePlacement::stretchToFit);
            } else {
                bgG.setColour(juce::Colour(0xff221d15));
                bgG.fillRoundedRectangle(r.reduced(6.0f), 6.0f);
            }

            // 2. Luce di fondo calda a incandescenza (filamento tungsteno)
            const float glowCx = r.getX() + r.getWidth() * 0.52913f;
            const float glowCy = r.getY() + r.getHeight() * 0.38000f;
            juce::ColourGradient bulbGlow(juce::Colour(0x35ffdf90), glowCx, glowCy,
                                         juce::Colours::transparentBlack, glowCx, glowCy + r.getHeight() * 0.45f, true);
            bgG.setGradientFill(bulbGlow);
            bgG.fillEllipse(r.reduced(r.getWidth() * 0.12f, r.getHeight() * 0.12f));

            // 3. Cornice fusa in metallo autentica
            if (bezelImg.isValid()) {
                bgG.drawImage(bezelImg, r, juce::RectanglePlacement::stretchToFit);
            }

            // 4. Didascalia serigrafata con indicatori di canale differenziati
            bgG.setFont(juce::FontOptions(10.0f, juce::Font::bold));
            bgG.setColour(juce::Colour(0xb8c59c52));
            bgG.drawText(title, r.getX(), r.getBottom() - 14.0f, r.getWidth(), 12.0f, juce::Justification::centred);

            // Badge L/R sotto la scala
            const float badgeY = r.getY() + r.getHeight() * 0.16f;
            const float badgeW = 28.0f;
            const float badgeH = 12.0f;

            // Badge L (Rosso)
            float bLx = r.getX() + r.getWidth() * 0.18f;
            bgG.setColour(juce::Colour(0x35ff2030));
            bgG.fillRoundedRectangle(bLx, badgeY, badgeW, badgeH, 2.0f);
            bgG.setColour(juce::Colour(0xffff5565));
            bgG.setFont(juce::FontOptions(8.5f, juce::Font::bold));
            bgG.drawText("L", bLx, badgeY, badgeW, badgeH, juce::Justification::centred);

            // Badge R (Oro/Ambra)
            float bRx = r.getRight() - r.getWidth() * 0.18f - badgeW;
            bgG.setColour(juce::Colour(0x35ffaa00));
            bgG.fillRoundedRectangle(bRx, badgeY, badgeW, badgeH, 2.0f);
            bgG.setColour(juce::Colour(0xffffcc40));
            bgG.setFont(juce::FontOptions(8.5f, juce::Font::bold));
            bgG.drawText("R", bRx, badgeY, badgeW, badgeH, juce::Justification::centred);

            return bg;
        };

        cachedVUBackground = renderBg(vuDialImg, "OUTPUT VU  (L: RED | R: GOLD)");
        cachedGRBackground = renderBg(grDialImg, "T4B GAIN REDUCTION");
    }

    void drawStereoCalibratedMeter(juce::Graphics& g, const juce::Rectangle<float>& area,
                                  const juce::Image& dialCard,
                                  float needleAngleRadL, float needleAngleRadR,
                                  const juce::String& titleText,
                                  bool isGR = false)
    {
        constexpr float SVG_ASPECT = 1024.0f / 765.0f;
        float targetW = area.getWidth();
        float targetH = area.getHeight();
        if (targetW / targetH > SVG_ASPECT) {
            targetW = targetH * SVG_ASPECT;
        } else {
            targetH = targetW / SVG_ASPECT;
        }
        auto meterRect = area.withSizeKeepingCentre(targetW, targetH);

        // 1. Sfondo prerenderizzato e cached per 60 FPS stabili (quadrante, luce incandescenza, bezel e serigrafie)
        const auto& cachedBg = isGR ? cachedGRBackground : cachedVUBackground;
        if (cachedBg.isValid() && cachedBg.getWidth() == juce::roundToInt(targetW) && cachedBg.getHeight() == juce::roundToInt(targetH)) {
            g.drawImageAt(cachedBg, juce::roundToInt(meterRect.getX()), juce::roundToInt(meterRect.getY()));
        } else {
            if (dialCard.isValid())
                g.drawImage(dialCard, meterRect, juce::RectanglePlacement::stretchToFit);
            if (bezelImg.isValid())
                g.drawImage(bezelImg, meterRect, juce::RectanglePlacement::stretchToFit);
        }

        // 2. Perno e traiettoria della punta
        const float pivotX = meterRect.getX() + meterRect.getWidth()  * 0.52913086f;
        const float pivotY = meterRect.getY() + meterRect.getHeight() * 0.66768627f;
        const float tipLen = meterRect.getWidth() * (318.94f / 1024.0f);

        // === LANCETTA CANALE SINISTRO (L): ROSSO RUBINO CON PUNTA CALIBRATA ===
        if (needleImg.isValid() && pointerStyle == PointerStyle::ClassicNeedle) {
            // Ombra portata
            juce::Graphics::ScopedSaveState stateShadowL(g);
            g.setOpacity(0.32f);
            g.addTransform(juce::AffineTransform::rotation(needleAngleRadL, pivotX, pivotY).translated(1.6f, 2.6f));
            g.drawImage(needleImg, meterRect, juce::RectanglePlacement::stretchToFit);

            // Lancetta L
            juce::Graphics::ScopedSaveState stateL(g);
            g.setOpacity(0.95f);
            g.addTransform(juce::AffineTransform::rotation(needleAngleRadL, pivotX, pivotY));
            g.drawImage(needleImg, meterRect, juce::RectanglePlacement::stretchToFit);
        } else {
            const float tipXL = pivotX + std::sin(needleAngleRadL) * tipLen;
            const float tipYL = pivotY - std::cos(needleAngleRadL) * tipLen;

            g.setColour(juce::Colours::black.withAlpha(0.35f));
            g.drawLine(pivotX + 1.5f, pivotY + 2.0f, tipXL + 1.5f, tipYL + 2.0f, 2.2f);

            g.setColour(juce::Colour(0xffd02830));
            g.drawLine(pivotX, pivotY, tipXL, tipYL, (pointerStyle == PointerStyle::RadioSweeper) ? 3.0f : 1.8f);
        }

        // === LANCETTA CANALE DESTRO (R): ORO CALDO / AMBRA CON PUNTA ILLUMINATA ===
        {
            const float tipXR = pivotX + std::sin(needleAngleRadR) * tipLen;
            const float tipYR = pivotY - std::cos(needleAngleRadR) * tipLen;
            const float counterXR = pivotX - std::sin(needleAngleRadR) * (tipLen * 0.22f);
            const float counterYR = pivotY + std::cos(needleAngleRadR) * (tipLen * 0.22f);

            // Ombra portata R
            g.setColour(juce::Colours::black.withAlpha(0.36f));
            g.drawLine(counterXR + 2.0f, counterYR + 2.8f, tipXR + 2.0f, tipYR + 2.8f, 2.4f);

            // Stelo ottone satinato oro
            g.setColour(juce::Colour(0xffdfb358));
            g.drawLine(counterXR, counterYR, tipXR, tipYR, 1.7f);

            // Punta incandescente Ambra / Oro Neon
            const float tipStartXR = pivotX + std::sin(needleAngleRadR) * (tipLen * 0.65f);
            const float tipStartYR = pivotY - std::cos(needleAngleRadR) * (tipLen * 0.65f);

            // Bloom fosforico ambra
            g.setColour(juce::Colour(0x55ff9a10));
            g.drawLine(tipStartXR, tipStartYR, tipXR, tipYR, 4.2f);
            g.setColour(juce::Colour(0xffffbf30));
            g.drawLine(tipStartXR, tipStartYR, tipXR, tipYR, 2.0f);
            g.setColour(juce::Colours::white);
            g.drawLine(tipStartXR + std::sin(needleAngleRadR) * (tipLen * 0.20f),
                       tipStartYR - std::cos(needleAngleRadR) * (tipLen * 0.20f),
                       tipXR, tipYR, 0.9f);
        }

        // Cupola del perno centrale in ottone tornito (sigilla entrambe le lancette)
        juce::ColourGradient hubGrad(juce::Colour(0xfff6dc94), pivotX - 2.0f, pivotY - 2.0f,
                                    juce::Colour(0xff4a300a), pivotX + 6.0f, pivotY + 6.0f, true);
        g.setGradientFill(hubGrad);
        g.fillEllipse(pivotX - 6.5f, pivotY - 6.5f, 13.0f, 13.0f);
        g.setColour(juce::Colour(0xff221404));
        g.drawEllipse(pivotX - 6.5f, pivotY - 6.5f, 13.0f, 13.0f, 1.0f);
        g.setColour(juce::Colour(0x70ffffff));
        g.fillEllipse(pivotX - 3.0f, pivotY - 4.5f, 3.5f, 2.2f);

        // 3. Riflesso vitreo antiriflesso polarizzato
        if (glassOverlayImg.isValid()) {
            g.setOpacity(0.24f);
            g.drawImage(glassOverlayImg, meterRect, juce::RectanglePlacement::stretchToFit);
            g.setOpacity(1.0f);
        }
    }

    void paintDualGalvanometer(juce::Graphics& g, float w, float h) {
        const float halfW = w * 0.5f;

        // Meter Sinistro: STEREO OUTPUT VU METER (L / R)
        drawStereoCalibratedMeter(g, juce::Rectangle<float>(0.0f, 0.0f, halfW, h),
                                  vuDialImg, needleAngleVU_L, needleAngleVU_R,
                                  "OUTPUT VU  (L: RED | R: GOLD)");

        // Meter Destro: T4B GAIN REDUCTION METER
        drawStereoCalibratedMeter(g, juce::Rectangle<float>(halfW, 0.0f, halfW, h),
                                  grDialImg, needleAngleGR_L, needleAngleGR_R,
                                  "T4B GAIN REDUCTION", true);

        // Info pill in alto a sinistra
        g.setFont(juce::FontOptions(9.5f, juce::Font::bold));
        g.setColour(juce::Colour(0x75d89f3c));
        const juce::String styleLabel = (pointerStyle == PointerStyle::ClassicNeedle) ? "DUAL MECHANICAL NEEDLES" : "RADIO SWEEPER";
        g.drawText("[MODE: " + styleLabel + " - CLICK TO TOGGLE]", 6, 4, 300, 12, juce::Justification::left);
    }

    void paintStereoLEDTower(juce::Graphics& g, float w, float h) {
        if (ledBoxImg.isValid()) {
            float imgScale = (h - 22.0f) / static_cast<float>(ledBoxImg.getHeight());
            float imgW = ledBoxImg.getWidth() * imgScale;
            float imgX = (w - imgW) * 0.5f;
            g.drawImage(ledBoxImg,
                        juce::roundToInt(imgX), 11,
                        juce::roundToInt(imgW), juce::roundToInt(h - 22.0f),
                        0, 0, ledBoxImg.getWidth(), ledBoxImg.getHeight());
        }

        const int numSegments = 28;
        const float barW = 20.0f;
        const float segH = 3.6f;
        const float startY = 32.0f;
        const float barH = h - 54.0f;

        auto drawBar = [&](float bx, float peakDb, float rmsDb, const juce::String& chLabel, juce::Colour labelCol) {
            for (int i = 0; i < numSegments; ++i) {
                float segDb = juce::jmap(static_cast<float>(i), 0.0f, static_cast<float>(numSegments - 1), -48.0f, 6.0f);
                float y = startY + barH - (i + 1) * (segH + 2.0f);

                bool isLit = (rmsDb >= segDb);
                bool isPeak = (std::abs(peakDb - segDb) < 2.5f);

                juce::Colour col;
                if (segDb > 0.0f)        col = juce::Colour(0xffff2030);
                else if (segDb > -10.0f) col = juce::Colour(0xffff9500);
                else                     col = juce::Colour(0xff20e060);

                if (isLit || isPeak) {
                    g.setColour(col);
                    g.fillRoundedRectangle(bx, y, barW, segH, 1.5f);
                } else {
                    g.setColour(col.withAlpha(0.12f));
                    g.fillRoundedRectangle(bx, y, barW, segH, 1.5f);
                }
            }

            // Etichetta del canale
            g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
            g.setColour(labelCol);
            g.drawText(chLabel, bx, startY + barH + 4.0f, barW, 12.0f, juce::Justification::centred);
        };

        drawBar(w * 0.5f - 40.0f, dispPeakL, dispRmsL, "L", juce::Colour(0xffff4050));
        drawBar(w * 0.5f + 14.0f, dispPeakR, dispRmsR, "R", juce::Colour(0xffffc040));

        g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xd0c59c52));
        g.drawText("STEREO LED TOWER (DUAL L/R)  [CLICK: VU]", 14, 11, 260, 12, juce::Justification::left);
    }

    DisplayMode mode = DisplayMode::AnalogVU_GR;
    PointerStyle pointerStyle = PointerStyle::ClassicNeedle;

    float targetOutRMS_L = 0.0f;
    float targetOutRMS_R = 0.0f;
    float targetPeakL    = 0.0f;
    float targetPeakR    = 0.0f;
    float targetGR_L_dB  = 0.0f;
    float targetGR_R_dB  = 0.0f;

    float needleAngleVU_L = -0.5166f;
    float needleVelVU_L   = 0.0f;
    float needleAngleVU_R = -0.5166f;
    float needleVelVU_R   = 0.0f;

    float needleAngleGR_L = 0.6021f;
    float needleVelGR_L   = 0.0f;
    float needleAngleGR_R = 0.6021f;
    float needleVelGR_R   = 0.0f;

    float dispRmsL  = -60.0f;
    float dispRmsR  = -60.0f;
    float dispPeakL = -60.0f;
    float dispPeakR = -60.0f;

    juce::Image bezelImg;
    juce::Image vuDialImg;
    juce::Image grDialImg;
    juce::Image needleImg;
    juce::Image sweeperImg;
    juce::Image glassOverlayImg;
    juce::Image ledBoxImg;
    juce::Image cachedVUBackground;
    juce::Image cachedGRBackground;
};

// ==============================================================================
// 2. SCHERMO DESTRO: DUAL STEREO SCOPE (CYAN L, AMBER R), LISSAJOUS & KNEE
// ==============================================================================
class WaveformScopeComponent : public juce::Component {
public:
    enum class DisplayMode {
        StereoWaveformScope, // Dual Traces: Cyan (L) e Amber (R) + Ducking line
        LissajousVectorScope, // Goniometro Stereo / Fase Lissajous
        DynamicKnee          // Curva di compressione T4B reattiva
    };

    explicit WaveformScopeComponent(dsp171::LockFreeVisualFIFO<512>& /*fifoToUse*/)
    {
        setOpaque(false);
        glassOverlayImg = juce::ImageCache::getFromMemory(BinaryData::display_glass_overlay_png, BinaryData::display_glass_overlay_pngSize);
        waveformHistoryL.fill(0.0f);
        waveformHistoryR.fill(0.0f);
        grHistory.fill(0.0f);
    }

    ~WaveformScopeComponent() override = default;

    void mouseDown(const juce::MouseEvent&) override {
        if (mode == DisplayMode::StereoWaveformScope)
            mode = DisplayMode::LissajousVectorScope;
        else if (mode == DisplayMode::LissajousVectorScope)
            mode = DisplayMode::DynamicKnee;
        else
            mode = DisplayMode::StereoWaveformScope;
        repaint();
    }

    // Riceve i dati sincroni dall'Editor (zero contention)
    void updateFrame(const dsp171::VisualFrame& frame, bool hasData) {
        if (hasData) {
            for (size_t s = 0; s < dsp171::VisualFrame::FrameSamples; s += 2) {
                waveformHistoryL[historyWriteIdx] = frame.samplesOut_L[s];
                waveformHistoryR[historyWriteIdx] = frame.samplesOut_R[s];
                grHistory[historyWriteIdx]        = frame.gainReduction_L;
                historyWriteIdx = (historyWriteIdx + 1) % HistorySize;
            }
            targetGR_dB  = frame.gainReduction_L;
            targetOutRMS = 0.5f * (frame.outRMS_L + frame.outRMS_R);

            // Calcolo coefficiente di correlazione di fase stereo in tempo reale
            float sumLR = 0.0f;
            float sumL2 = 0.0f;
            float sumR2 = 0.0f;
            for (size_t i = 0; i < 64; ++i) {
                float sl = frame.samplesOut_L[i];
                float sr = frame.samplesOut_R[i];
                sumLR += sl * sr;
                sumL2 += sl * sl;
                sumR2 += sr * sr;
            }
            float denom = std::sqrt(sumL2 * sumR2);
            if (denom > 1.0e-5f)
                phaseCorrelation = std::clamp(sumLR / denom, -1.0f, 1.0f);
            else
                phaseCorrelation = 1.0f;
        } else {
            targetGR_dB  *= 0.85f;
            targetOutRMS *= 0.90f;
        }

        repaint();
    }

    void paint(juce::Graphics& g) override {
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());

        // 1. Cornice dorata con smussatura CNC
        juce::ColourGradient goldGrad(juce::Colour(0xfff6dc94), 0.0f, 0.0f,
                                      juce::Colour(0xff7a531e), 0.0f, h, false);
        goldGrad.addColour(0.35, juce::Colour(0xffdfb358));
        goldGrad.addColour(0.65, juce::Colour(0xff9e732b));
        g.setGradientFill(goldGrad);
        g.drawRoundedRectangle(1.0f, 1.0f, w - 2.0f, h - 2.0f, 6.0f, 2.5f);

        // Ombra interna d'incasso
        g.setColour(juce::Colour(0xb0000000));
        g.drawRoundedRectangle(3.0f, 3.0f, w - 6.0f, h - 6.0f, 5.0f, 2.0f);

        // Sfondo fumé CRT ultra-nero
        g.setColour(juce::Colour(0xf405070a));
        g.fillRoundedRectangle(4.0f, 4.0f, w - 8.0f, h - 8.0f, 4.0f);

        // Watermark 171 Studio in background traslucido
        {
            juce::Graphics::ScopedSaveState stateWatermark(g);
            g.setFont(juce::FontOptions(42.0f, juce::Font::bold));
            g.setColour(juce::Colour(0x0affffff));
            g.drawText("171 STUDIO", 0, 0, juce::roundToInt(w), juce::roundToInt(h), juce::Justification::centred);
        }

        if (mode == DisplayMode::StereoWaveformScope) {
            paintStereoScope(g, w, h);
        } else if (mode == DisplayMode::LissajousVectorScope) {
            paintLissajousScope(g, w, h);
        } else {
            paintKnee(g, w, h);
        }

        // Overlay in vetro polarizzato
        if (glassOverlayImg.isValid()) {
            g.setOpacity(0.28f);
            g.drawImage(glassOverlayImg, 4.0f, 4.0f, w - 8.0f, h - 8.0f,
                        606, 124, 366, 158);
            g.setOpacity(1.0f);
        }
    }

private:
    void paintStereoScope(juce::Graphics& g, float w, float h) {
        // Griglia CRT dorata
        g.setColour(juce::Colour(0x18c59c52));
        for (float x = 16.0f; x < w - 10.0f; x += 36.0f) {
            g.drawVerticalLine(juce::roundToInt(x), 10.0f, h - 10.0f);
        }
        for (float y = 16.0f; y < h - 10.0f; y += 28.0f) {
            g.drawHorizontalLine(juce::roundToInt(y), 10.0f, w - 10.0f);
        }

        const float midY = h * 0.5f;
        const float maxAmp = h * 0.38f;
        const size_t numPoints = 160;
        const float stepX = (w - 24.0f) / static_cast<float>(numPoints);

        // --- TRACCIA 1: CANALE DESTRO (R) - AMBRA / ORO CALDO (Zero heap alloc)
        wavePathR.clear();
        bool startedR = false;
        for (size_t i = 0; i < numPoints; ++i) {
            const size_t idx = (historyWriteIdx + (i * (HistorySize / numPoints))) % HistorySize;
            float valR = std::clamp(waveformHistoryR[idx], -1.1f, 1.1f);
            float px = 12.0f + i * stepX;
            float py = midY - valR * maxAmp;

            if (!startedR) { wavePathR.startNewSubPath(px, py); startedR = true; }
            else { wavePathR.lineTo(px, py); }
        }
        // Bloom fosforo ambra
        g.setColour(juce::Colour(0x35ff9a10));
        g.strokePath(wavePathR, juce::PathStrokeType(5.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        // Traccia solida ambra
        g.setColour(juce::Colour(0xffffbf30));
        g.strokePath(wavePathR, juce::PathStrokeType(1.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // --- TRACCIA 2: CANALE SINISTRO (L) - CYAN ELETTRICO (Zero heap alloc)
        wavePathL.clear();
        bool startedL = false;
        for (size_t i = 0; i < numPoints; ++i) {
            const size_t idx = (historyWriteIdx + (i * (HistorySize / numPoints))) % HistorySize;
            float valL = std::clamp(waveformHistoryL[idx], -1.1f, 1.1f);
            float px = 12.0f + i * stepX;
            float py = midY - valL * maxAmp;

            if (!startedL) { wavePathL.startNewSubPath(px, py); startedL = true; }
            else { wavePathL.lineTo(px, py); }
        }
        // Bloom fosforo cyan
        g.setColour(juce::Colour(0x3500d5e5));
        g.strokePath(wavePathL, juce::PathStrokeType(5.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        // Traccia solida cyan
        g.setColour(juce::Colour(0xff20f5ff));
        g.strokePath(wavePathL, juce::PathStrokeType(1.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // Linea Gain Reduction (in alto in rosso rubino - Zero heap alloc)
        grPath.clear();
        bool grStarted = false;
        for (size_t i = 0; i < numPoints; ++i) {
            const size_t idx = (historyWriteIdx + (i * (HistorySize / numPoints))) % HistorySize;
            float gr_val = std::clamp(std::abs(grHistory[idx]), 0.0f, 18.0f);
            float px = 12.0f + i * stepX;
            float py = 22.0f + (gr_val / 18.0f) * (h * 0.30f);

            if (!grStarted) { grPath.startNewSubPath(px, py); grStarted = true; }
            else { grPath.lineTo(px, py); }
        }
        g.setColour(juce::Colour(0xa0ff2535));
        g.strokePath(grPath, juce::PathStrokeType(2.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // Header info: Stereo L/R indicator
        g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xff00d5e5));
        g.drawText("L: CYAN", 14, 10, 50, 14, juce::Justification::left);

        g.setColour(juce::Colour(0xffffbf30));
        g.drawText("R: AMBER", 70, 10, 58, 14, juce::Justification::left);

        g.setColour(juce::Colour(0xffffe099));
        g.drawText("| GR: " + juce::String(targetGR_dB, 1) + " dB", 132, 10, 120, 14, juce::Justification::left);

        g.setFont(juce::FontOptions(9.5f, juce::Font::plain));
        g.setColour(juce::Colour(0xa0c59c52));
        g.drawText("[CLICK: GONIOMETER]", juce::roundToInt(w - 130.0f), 10, 116, 14, juce::Justification::right);
    }

    void paintLissajousScope(juce::Graphics& g, float w, float h) {
        // Goniometro di fase stereo
        const float cx = w * 0.5f;
        const float cy = h * 0.5f + 4.0f;
        const float radius = std::min(w, h) * 0.40f;

        // Griglia circolare e assi di correlazione a 45 gradi
        g.setColour(juce::Colour(0x1ec59c52));
        g.drawEllipse(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f, 1.0f);
        g.drawEllipse(cx - radius * 0.5f, cy - radius * 0.5f, radius, radius, 0.8f);

        // Assi L (+45°) e R (-45°)
        g.setColour(juce::Colour(0x28c59c52));
        g.drawLine(cx - radius * 0.707f, cy + radius * 0.707f, cx + radius * 0.707f, cy - radius * 0.707f, 1.0f);
        g.drawLine(cx + radius * 0.707f, cy + radius * 0.707f, cx - radius * 0.707f, cy - radius * 0.707f, 1.0f);
        g.drawLine(cx, cy - radius, cx, cy + radius, 1.0f); // Asse Mid (Centro M)
        g.drawLine(cx - radius, cy, cx + radius, cy, 1.0f); // Asse Side (Laterale S)

        // Traccia Stereo Goniometer Lissajous (Zero heap alloc)
        gonioPath.clear();
        bool started = false;
        constexpr size_t numPoints = 128;

        for (size_t i = 0; i < numPoints; ++i) {
            const size_t idx = (historyWriteIdx + i * (HistorySize / numPoints)) % HistorySize;
            float l = waveformHistoryL[idx];
            float r = waveformHistoryR[idx];

            // M/S polar transform: X = (L - R) Side, Y = (L + R) Mid
            float sideX = (l - r) * 0.7071f;
            float midY  = (l + r) * 0.7071f;

            float px = cx + std::clamp(sideX * radius * 1.5f, -radius, radius);
            float py = cy - std::clamp(midY * radius * 1.5f, -radius, radius);

            if (!started) { gonioPath.startNewSubPath(px, py); started = true; }
            else { gonioPath.lineTo(px, py); }
        }

        // Bloom Lissajous Cyan / Gold
        g.setColour(juce::Colour(0x3000d5e5));
        g.strokePath(gonioPath, juce::PathStrokeType(4.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        g.setColour(juce::Colour(0xff20e8ff));
        g.strokePath(gonioPath, juce::PathStrokeType(1.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // Header info: Correlazione di fase
        g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xffffe099));
        juce::String corrStr = "PHASE CORRELATION: " + juce::String(phaseCorrelation, 2);
        if (phaseCorrelation > 0.85f) corrStr += " [FOCUSED]";
        else if (phaseCorrelation > 0.25f) corrStr += " [WIDE STEREO]";
        else corrStr += " [DIFFUSE]";

        g.drawText(corrStr, 14, 10, 240, 14, juce::Justification::left);

        g.setFont(juce::FontOptions(9.5f, juce::Font::plain));
        g.setColour(juce::Colour(0xa0c59c52));
        g.drawText("[CLICK: KNEE]", juce::roundToInt(w - 100.0f), 10, 86, 14, juce::Justification::right);
    }

    void paintKnee(juce::Graphics& g, float w, float h) {
        const float pad = 24.0f;
        const float graphW = w - pad * 2.0f;
        const float graphH = h - pad * 2.0f;
        const float ox = pad;
        const float oy = h - pad;

        g.setColour(juce::Colour(0x22c59c52));
        g.drawRect(ox, pad, graphW, graphH, 1.0f);

        // Linea 1:1 lineare
        g.setColour(juce::Colour(0x35ffffff));
        g.drawLine(ox, oy, ox + graphW, pad, 1.0f);

        // Curva Knee morbida ottica (Zero heap alloc)
        kneeCurve.clear();
        kneeCurve.startNewSubPath(ox, oy);

        const float threshNorm = 0.55f;
        const float kneeThreshX = ox + graphW * threshNorm;
        const float kneeThreshY = oy - graphH * threshNorm;

        kneeCurve.lineTo(kneeThreshX - 14.0f, kneeThreshY + 14.0f);
        kneeCurve.quadraticTo(kneeThreshX, kneeThreshY, kneeThreshX + 14.0f, kneeThreshY - 5.0f);
        kneeCurve.lineTo(ox + graphW, kneeThreshY - 16.0f);

        g.setColour(juce::Colour(0xffffdd70));
        g.strokePath(kneeCurve, juce::PathStrokeType(2.4f));

        // Pallina reattiva
        float currentInputNorm = std::clamp(std::pow(10.0f, (20.0f * std::log10(std::max(targetOutRMS, 1.0e-5f)) + 20.0f) / 40.0f), 0.05f, 0.95f);
        float ballX = ox + graphW * currentInputNorm;
        float ballY = (ballX < kneeThreshX) ? (oy - (ballX - ox)) : (kneeThreshY - (ballX - kneeThreshX) * 0.35f);

        g.setColour(juce::Colour(0xffff3040).withAlpha(0.35f));
        g.fillEllipse(ballX - 8.0f, ballY - 8.0f, 16.0f, 16.0f);
        g.setColour(juce::Colour(0xffff5060));
        g.fillEllipse(ballX - 4.0f, ballY - 4.0f, 8.0f, 8.0f);

        g.setFont(juce::FontOptions(10.5f, juce::Font::bold));
        g.setColour(juce::Colour(0xffffe099));
        g.drawText("T4B OPTO TRANSFER CURVE", 14, 10, 200, 14, juce::Justification::left);

        g.setFont(juce::FontOptions(9.5f, juce::Font::plain));
        g.setColour(juce::Colour(0xa0c59c52));
        g.drawText("[CLICK: SCOPE]", juce::roundToInt(w - 100.0f), 10, 86, 14, juce::Justification::right);
    }

    DisplayMode mode = DisplayMode::StereoWaveformScope;

    static constexpr size_t HistorySize = 512;
    std::array<float, HistorySize> waveformHistoryL{};
    std::array<float, HistorySize> waveformHistoryR{};
    std::array<float, HistorySize> grHistory{};
    size_t historyWriteIdx = 0;

    float targetGR_dB       = 0.0f;
    float targetOutRMS      = 0.0f;
    float phaseCorrelation  = 1.0f;

    juce::Image glassOverlayImg;

    // Buffer preallocati per zero allocazioni heap durante paint a 60 FPS
    juce::Path wavePathR;
    juce::Path wavePathL;
    juce::Path grPath;
    juce::Path gonioPath;
    juce::Path kneeCurve;
};

} // namespace gui171
