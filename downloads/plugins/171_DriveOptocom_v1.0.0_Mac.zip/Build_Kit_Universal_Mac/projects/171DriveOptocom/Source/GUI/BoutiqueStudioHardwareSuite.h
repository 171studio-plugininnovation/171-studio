#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_graphics/juce_graphics.h>
#include <cmath>

namespace plugin_171
{
    // ==============================================================================
    // 1. DISPLAY BEZEL WINDOW FRAME COMPONENT ("BoutiqueDisplayFrame")
    // ==============================================================================
    class BoutiqueDisplayFrame : public juce::Component
    {
    public:
        BoutiqueDisplayFrame()
        {
            setOpaque(false);
            setInterceptsMouseClicks(false, true);
        }

        void loadAssets(const juce::Image& hollowFrame, const juce::Image& glassOverlay)
        {
            frameImg = hollowFrame;
            glassImg = glassOverlay;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            if (frameImg.isValid())
            {
                g.drawImage(frameImg, bounds, juce::RectanglePlacement::stretchToFit);
            }
            else
            {
                const float chamfer = 14.0f;
                juce::Path p;
                p.startNewSubPath(bounds.getX() + chamfer, bounds.getY());
                p.lineTo(bounds.getRight() - chamfer, bounds.getY());
                p.lineTo(bounds.getRight(), bounds.getY() + chamfer);
                p.lineTo(bounds.getRight(), bounds.getBottom() - chamfer);
                p.lineTo(bounds.getRight() - chamfer, bounds.getBottom());
                p.lineTo(bounds.getX() + chamfer, bounds.getBottom());
                p.lineTo(bounds.getX(), bounds.getBottom() - chamfer);
                p.lineTo(bounds.getX(), bounds.getY() + chamfer);
                p.closeSubPath();

                g.setColour(juce::Colours::black.withAlpha(0.6f));
                g.fillPath(p, juce::AffineTransform::translation(2.0f, 3.0f));

                juce::ColourGradient grad(
                    juce::Colour::fromString("ff735c3a"), bounds.getX(), bounds.getY(),
                    juce::Colour::fromString("ff292014"), bounds.getRight(), bounds.getBottom(), false);
                grad.addColour(0.4, juce::Colour::fromString("ff8c7047"));
                g.setGradientFill(grad);
                g.fillPath(p);

                g.setColour(juce::Colour::fromString("ffd6b467"));
                g.strokePath(p, juce::PathStrokeType(1.6f));

                const float padX = bounds.getWidth() * 0.12f;
                const float padY = bounds.getHeight() * 0.16f;
                auto inner = bounds.reduced(padX, padY);

                g.setColour(juce::Colour::fromString("ff0a0806"));
                g.fillRoundedRectangle(inner, 8.0f);
            }
        }

        void paintOverChildren(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            if (glassImg.isValid())
            {
                g.drawImage(glassImg, bounds, juce::RectanglePlacement::stretchToFit);
            }
        }

        juce::Rectangle<int> getDisplayArea() const
        {
            auto b = getLocalBounds();
            int padX = (int)(b.getWidth() * 0.128f);
            int padY = (int)(b.getHeight() * 0.170f);
            return b.reduced(padX, padY);
        }

    private:
        juce::Image frameImg;
        juce::Image glassImg;
    };


    // ==============================================================================
    // 2. DUAL-CONCENTRIC MASTERING KNOB ("DualConcentricSlider")
    // ==============================================================================
    /**
     * @brief Manopola a doppio asse concentrico (Outer Ring in ottone zigrinato + Inner Knob canna di fucile).
     * Trascina normalmente per Inner Value (es. Gain); Tieni premuto SHIFT o usa tasto destro per Outer Value (es. Frequenza).
     */
    class DualConcentricSlider : public juce::Component
    {
    public:
        DualConcentricSlider()
        {
            setOpaque(false);
        }

        void loadAssets(const juce::Image& outerRing, const juce::Image& innerKnob)
        {
            outerImg = outerRing;
            innerImg = innerKnob;
            repaint();
        }

        void setInnerValue(float val0to1) { innerVal = juce::jlimit(0.0f, 1.0f, val0to1); repaint(); }
        void setOuterValue(float val0to1) { outerVal = juce::jlimit(0.0f, 1.0f, val0to1); repaint(); }
        float getInnerValue() const noexcept { return innerVal; }
        float getOuterValue() const noexcept { return outerVal; }

        void mouseDrag(const juce::MouseEvent& e) override
        {
            float delta = -(float)e.getDistanceFromDragStartY() * 0.005f;
            if (e.mods.isShiftDown() || e.mods.isRightButtonDown())
            {
                outerVal = juce::jlimit(0.0f, 1.0f, outerVal + delta);
                if (onOuterValueChanged) onOuterValueChanged(outerVal);
            }
            else
            {
                innerVal = juce::jlimit(0.0f, 1.0f, innerVal + delta);
                if (onInnerValueChanged) onInnerValueChanged(innerVal);
            }
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float size = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx = bounds.getCentreX();
            const float cy = bounds.getCentreY();
            auto knobRect = bounds.withSizeKeepingCentre(size, size);

            const float minA = -juce::MathConstants<float>::pi * 0.75f;
            const float maxA =  juce::MathConstants<float>::pi * 0.75f;
            const float angleOuter = minA + outerVal * (maxA - minA);
            const float angleInner = minA + innerVal * (maxA - minA);

            // 1. Ombra portata
            g.setColour(juce::Colours::black.withAlpha(0.6f));
            g.fillEllipse(knobRect.translated(2.0f, 4.0f));

            if (outerImg.isValid() && innerImg.isValid())
            {
                // A. Outer Ring con rotazione propria
                {
                    juce::Graphics::ScopedSaveState state(g);
                    g.addTransform(juce::AffineTransform::rotation(angleOuter, cx, cy));
                    g.drawImage(outerImg, knobRect, juce::RectanglePlacement::centred);
                }

                // B. Inner Knob con rotazione propria
                {
                    juce::Graphics::ScopedSaveState state(g);
                    g.addTransform(juce::AffineTransform::rotation(angleInner, cx, cy));
                    g.drawImage(innerImg, knobRect, juce::RectanglePlacement::centred);
                }
            }
            else
            {
                // Fallback procedurale vettoriale
                float rOut = size * 0.46f;
                float rIn  = size * 0.28f;

                // Anello esterno
                g.setColour(juce::Colour::fromString("ff5c4728"));
                g.fillEllipse(cx - rOut, cy - rOut, rOut * 2.0f, rOut * 2.0f);
                g.setColour(juce::Colour::fromString("ffd6b467"));
                g.drawEllipse(cx - rOut, cy - rOut, rOut * 2.0f, rOut * 2.0f, 1.4f);

                // Tacca anello esterno
                float ox = cx + (rOut - 8.0f) * std::sin(angleOuter);
                float oy = cy - (rOut - 8.0f) * std::cos(angleOuter);
                g.setColour(juce::Colour::fromString("ffffd470"));
                g.fillEllipse(ox - 2.5f, oy - 2.5f, 5.0f, 5.0f);

                // Manopola interna
                g.setColour(juce::Colour::fromString("ff211d1a"));
                g.fillEllipse(cx - rIn, cy - rIn, rIn * 2.0f, rIn * 2.0f);
                g.setColour(juce::Colour::fromString("ff8f8476"));
                g.drawEllipse(cx - rIn, cy - rIn, rIn * 2.0f, rIn * 2.0f, 1.2f);

                // Bead dorato interno
                float ix = cx + (rIn - 6.0f) * std::sin(angleInner);
                float iy = cy - (rIn - 6.0f) * std::cos(angleInner);
                g.setColour(juce::Colour::fromString("ffffa024"));
                g.fillEllipse(ix - 3.0f, iy - 3.0f, 6.0f, 6.0f);
            }
        }

        std::function<void(float)> onInnerValueChanged;
        std::function<void(float)> onOuterValueChanged;

    private:
        juce::Image outerImg;
        juce::Image innerImg;
        float innerVal = 0.5f;
        float outerVal = 0.2f;
    };


    // ==============================================================================
    // 3. VINTAGE BAKELITE CHICKEN-HEAD SELECTOR ("ChickenHeadRotarySwitch")
    // ==============================================================================
    class ChickenHeadRotarySwitch : public juce::Slider
    {
    public:
        ChickenHeadRotarySwitch(int numSteps = 6) : steps(numSteps)
        {
            setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
            setRange(0, steps - 1, 1);
        }

        void loadAsset(const juce::Image& chickenHeadImg)
        {
            chImg = chickenHeadImg;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float size = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx = bounds.getCentreX();
            const float cy = bounds.getCentreY();
            auto knobRect = bounds.withSizeKeepingCentre(size, size);

            float norm = (float)getValue() / (float)(steps - 1);
            const float minA = -juce::MathConstants<float>::pi * 0.70f;
            const float maxA =  juce::MathConstants<float>::pi * 0.70f;
            const float angle = minA + norm * (maxA - minA);

            // Ombra
            g.setColour(juce::Colours::black.withAlpha(0.6f));
            g.fillEllipse(knobRect.translated(2.0f, 4.0f));

            if (chImg.isValid())
            {
                juce::Graphics::ScopedSaveState state(g);
                g.addTransform(juce::AffineTransform::rotation(angle, cx, cy));
                g.drawImage(chImg, knobRect, juce::RectanglePlacement::centred);
            }
            else
            {
                // Fallback procedurale bakelite chicken head
                juce::Graphics::ScopedSaveState state(g);
                g.addTransform(juce::AffineTransform::rotation(angle, cx, cy));

                const float r = size * 0.40f;
                // Base circolare
                g.setColour(juce::Colour::fromString("ff1c1a17"));
                g.fillEllipse(cx - r, cy - r, r * 2.0f, r * 2.0f);

                // Becco puntatore
                juce::Path beak;
                beak.startNewSubPath(cx - r * 0.35f, cy);
                beak.lineTo(cx - r * 0.12f, cy - r * 1.15f);
                beak.lineTo(cx, cy - r * 1.25f);
                beak.lineTo(cx + r * 0.12f, cy - r * 1.15f);
                beak.lineTo(cx + r * 0.35f, cy);
                beak.closeSubPath();
                g.fillPath(beak);

                // Linea avorio
                g.setColour(juce::Colour::fromString("ffffeed1"));
                g.drawLine(cx, cy - r * 0.2f, cx, cy - r * 1.18f, 2.5f);
            }
        }

    private:
        int steps = 6;
        juce::Image chImg;
    };


    // ==============================================================================
    // 4. CALIBRATED DIAL SCALE SLIDER (0 TO 10) ("CalibratedDialSlider")
    // ==============================================================================
    class CalibratedDialSlider : public juce::Slider
    {
    public:
        CalibratedDialSlider()
        {
            setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
            setRange(0.0, 10.0, 0.05);
            setAngleRange(-150.0f, 150.0f);
        }

        void setAngleRange(float minDegrees, float maxDegrees)
        {
            minAngleRad = juce::degreesToRadians(minDegrees);
            maxAngleRad = juce::degreesToRadians(maxDegrees);
            repaint();
        }

        void setKnobScaleRatio(float ratio)
        {
            knobScaleRatio = juce::jlimit(0.1f, 1.5f, ratio);
            repaint();
        }

        void loadAssets(const juce::Image& stationaryScale, const juce::Image& centerKnob, float scaleRatio = 0.74f)
        {
            scaleImg = stationaryScale;
            knobImg = centerKnob;
            knobScaleRatio = scaleRatio;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float size = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx = bounds.getCentreX();
            const float cy = bounds.getCentreY();
            auto dialRect = bounds.withSizeKeepingCentre(size, size);

            const float norm = (float)(getValue() - getMinimum()) / (float)(getMaximum() - getMinimum());
            const float angle = minAngleRad + norm * (maxAngleRad - minAngleRad);

            if (scaleImg.isValid())
            {
                // 1. Layer base: Scala graduata fissa sul telaio (0 - 10)
                g.drawImage(scaleImg, dialRect, juce::RectanglePlacement::centred);

                // 2. Layer superiore: Manopola rotante con notch indicatore
                if (knobImg.isValid())
                {
                    const float knobSize = size * knobScaleRatio;
                    auto knobRect = bounds.withSizeKeepingCentre(knobSize, knobSize);

                    juce::Graphics::ScopedSaveState state(g);
                    g.addTransform(juce::AffineTransform::rotation(angle, cx, cy));
                    g.drawImage(knobImg, knobRect, juce::RectanglePlacement::centred);
                }
            }
            else
            {
                // Fallback procedurale di emergenza ad alta definizione
                g.setColour(juce::Colour::fromString("ff1a1714"));
                g.fillEllipse(dialRect);
                g.setColour(juce::Colour::fromString("ffd6b467"));
                g.drawEllipse(dialRect, 1.5f);

                // Manopola interna
                const float rCap = size * 0.28f;
                g.setColour(juce::Colour::fromString("ff29241f"));
                g.fillEllipse(cx - rCap, cy - rCap, rCap * 2.0f, rCap * 2.0f);

                // Tacca indicatore ad ore angle
                const float nx = cx + (rCap - 5.0f) * std::sin(angle);
                const float ny = cy - (rCap - 5.0f) * std::cos(angle);
                g.setColour(juce::Colour::fromString("ffffd470"));
                g.fillEllipse(nx - 2.5f, ny - 2.5f, 5.0f, 5.0f);
            }
        }

    private:
        juce::Image scaleImg;
        juce::Image knobImg;
        float knobScaleRatio = 0.74f;
        float minAngleRad = juce::degreesToRadians(-150.0f);
        float maxAngleRad = juce::degreesToRadians(150.0f);
    };


    // ==============================================================================
    // 5. ROCKER POWER SWITCH ("RockerPowerSwitch")
    // ==============================================================================
    class RockerPowerSwitchLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        void setCustomImages(const juce::Image& onImg, const juce::Image& offImg)
        {
            imgOn = onImg;
            imgOff = offImg;
            useBitmap = imgOn.isValid() && imgOff.isValid();
        }

        void drawToggleButton(juce::Graphics& g, juce::ToggleButton& button,
                              bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override
        {
            const auto bounds = button.getLocalBounds().toFloat();
            const bool isOn = button.getToggleState();

            if (useBitmap && imgOn.isValid() && imgOff.isValid())
            {
                g.drawImage(isOn ? imgOn : imgOff, bounds, juce::RectanglePlacement::centred);
            }
            else
            {
                const float size = juce::jmin(bounds.getWidth(), bounds.getHeight());
                auto box = bounds.withSizeKeepingCentre(size, size);

                g.setColour(juce::Colours::black.withAlpha(0.6f));
                g.fillRoundedRectangle(box.translated(1.5f, 2.5f), 6.0f);
                g.setColour(juce::Colour::fromString("ff141312"));
                g.fillRoundedRectangle(box, 6.0f);
                g.setColour(juce::Colour::fromString("ff38332d"));
                g.drawRoundedRectangle(box, 6.0f, 1.2f);

                const float padW = size * 0.42f;
                const float padH = size * 0.52f;
                auto paddleRect = box.withSizeKeepingCentre(padW, padH);

                if (isOn)
                {
                    juce::ColourGradient neon(
                        juce::Colour::fromString("ffff3344"), paddleRect.getCentreX(), paddleRect.getCentreY(),
                        juce::Colour::fromString("ff800010"), paddleRect.getX(), paddleRect.getY(), true);
                    g.setGradientFill(neon);
                    g.fillRoundedRectangle(paddleRect, 4.0f);

                    g.setColour(juce::Colours::white);
                    g.drawLine(paddleRect.getCentreX(), paddleRect.getY() + padH * 0.20f,
                               paddleRect.getCentreX(), paddleRect.getY() + padH * 0.45f, 2.0f);
                }
                else
                {
                    g.setColour(juce::Colour::fromString("ff4a0a10"));
                    g.fillRoundedRectangle(paddleRect, 4.0f);
                    g.setColour(juce::Colours::white.withAlpha(0.3f));
                    g.drawLine(paddleRect.getCentreX(), paddleRect.getY() + padH * 0.20f,
                               paddleRect.getCentreX(), paddleRect.getY() + padH * 0.45f, 1.5f);
                }
            }
        }

    private:
        juce::Image imgOn;
        juce::Image imgOff;
        bool useBitmap = false;
    };

    class RockerPowerSwitch : public juce::ToggleButton
    {
    public:
        RockerPowerSwitch()
        {
            setLookAndFeel(&switchLaf);
        }

        ~RockerPowerSwitch() override
        {
            setLookAndFeel(nullptr);
        }

        void loadAssets(const juce::Image& onImg, const juce::Image& offImg)
        {
            switchLaf.setCustomImages(onImg, offImg);
            repaint();
        }

    private:
        RockerPowerSwitchLookAndFeel switchLaf;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RockerPowerSwitch)
    };


    // ==============================================================================
    // 6. MODULO CELLA OTTICA T4B ("OptoCellModuleComponent")
    // ==============================================================================
    class OptoCellModuleComponent : public juce::Component
    {
    public:
        OptoCellModuleComponent()
        {
            setOpaque(false);
        }

        void loadAsset(const juce::Image& canisterImg)
        {
            canImg = canisterImg;
            repaint();
        }

        void setGainReduction(float grDb)
        {
            opticalGlow = juce::jlimit(0.0f, 1.0f, grDb / 15.0f);
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();

            if (opticalGlow > 0.01f)
            {
                const float glowY = bounds.getBottom() - bounds.getHeight() * 0.12f;
                juce::ColourGradient optoGlow(
                    juce::Colour::fromString("ffff8a1c").withAlpha(opticalGlow * 0.75f), bounds.getCentreX(), glowY,
                    juce::Colour::fromString("ffff3300").withAlpha(0.0f), bounds.getCentreX(), glowY + bounds.getHeight() * 0.25f, true);
                g.setGradientFill(optoGlow);
                g.fillEllipse(bounds.getCentreX() - bounds.getWidth() * 0.4f, glowY - 10.0f, bounds.getWidth() * 0.8f, bounds.getHeight() * 0.3f);
            }

            if (canImg.isValid())
            {
                g.drawImage(canImg, bounds, juce::RectanglePlacement::centred);
            }
            else
            {
                g.setColour(juce::Colours::black.withAlpha(0.5f));
                g.fillRoundedRectangle(bounds.translated(2.0f, 4.0f), 8.0f);

                juce::ColourGradient metal(
                    juce::Colour::fromString("ffc4c7cc"), bounds.getX(), bounds.getY(),
                    juce::Colour::fromString("ff52565c"), bounds.getRight(), bounds.getBottom(), false);
                metal.addColour(0.3, juce::Colour::fromString("ffe0e3e8"));
                metal.addColour(0.7, juce::Colour::fromString("ff7a7e85"));
                g.setGradientFill(metal);
                g.fillRoundedRectangle(bounds, 8.0f);
            }
        }

    private:
        juce::Image canImg;
        float opticalGlow = 0.0f;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(OptoCellModuleComponent)
    };


    // ==============================================================================
    // 7. PULSANTE CONSOLE A 3 STATI ("ThreeStateConsoleButton": OFF, ON, HOVER)
    // ==============================================================================
    class ThreeStateConsoleButton : public juce::Button
    {
    public:
        ThreeStateConsoleButton(const juce::String& name = {}) : juce::Button(name)
        {
            setClickingTogglesState(true);
        }

        void loadAssets(const juce::Image& offImg, const juce::Image& onImg, const juce::Image& hoverImg)
        {
            imgOff = offImg;
            imgOn = onImg;
            imgHover = hoverImg;
            repaint();
        }

        void paintButton(juce::Graphics& g, bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const bool isOn = getToggleState();

            if (shouldDrawButtonAsHighlighted && imgHover.isValid())
            {
                g.drawImage(imgHover, bounds, juce::RectanglePlacement::centred);
            }
            else if (isOn && imgOn.isValid())
            {
                g.drawImage(imgOn, bounds, juce::RectanglePlacement::centred);
            }
            else if (imgOff.isValid())
            {
                g.drawImage(imgOff, bounds, juce::RectanglePlacement::centred);
            }
            else
            {
                // Fallback procedurale
                g.setColour(juce::Colour::fromString("ff1a1714"));
                g.fillRoundedRectangle(bounds, 6.0f);
                g.setColour(isOn ? juce::Colour::fromString("ffffa024") : juce::Colour::fromString("ff473c2e"));
                g.drawRoundedRectangle(bounds, 6.0f, 2.0f);
            }
        }

    private:
        juce::Image imgOff, imgOn, imgHover;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ThreeStateConsoleButton)
    };


    // ==============================================================================
    // 8. TOGGLE SWITCH IN OTTONE A 3 STATI ("ThreeStateBrassToggle": OFF, ON, HOVER)
    // ==============================================================================
    class ThreeStateBrassToggle : public juce::Button
    {
    public:
        ThreeStateBrassToggle(const juce::String& name = {}) : juce::Button(name)
        {
            setClickingTogglesState(true);
        }

        void loadAssets(const juce::Image& offImg, const juce::Image& onImg, const juce::Image& hoverImg)
        {
            imgOff = offImg;
            imgOn = onImg;
            imgHover = hoverImg;
            repaint();
        }

        void paintButton(juce::Graphics& g, bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const bool isOn = getToggleState();

            if (shouldDrawButtonAsHighlighted && imgHover.isValid())
            {
                g.drawImage(imgHover, bounds, juce::RectanglePlacement::centred);
            }
            else if (isOn && imgOn.isValid())
            {
                g.drawImage(imgOn, bounds, juce::RectanglePlacement::centred);
            }
            else if (imgOff.isValid())
            {
                g.drawImage(imgOff, bounds, juce::RectanglePlacement::centred);
            }
            else
            {
                g.setColour(juce::Colour::fromString("ff141312"));
                g.fillRoundedRectangle(bounds, 6.0f);
            }
        }

    private:
        juce::Image imgOff, imgOn, imgHover;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ThreeStateBrassToggle)
    };


    // ==============================================================================
    // 9. MODULAR ANALOG VU & GAIN REDUCTION METER SUITE ("StudioVUMeterSuiteComponent" & "AnalogMeterNeedle")
    // ==============================================================================
    // Calibrated against User SVG Projects (viewBox 768x573.75 -> 1024x765):
    // Pivot Center: CX = 541.83 px (52.913%), CY = 510.78 px (66.769%)
    // Needle Tip Radius: 318.94 px (lands exactly in the inter-arc scale channel)
    // Dynamic Modes: Classic Mechanical Needle vs Vintage Radio-Style Sweeper Wand
    // ==============================================================================
    class AnalogMeterNeedle : public juce::Component
    {
    public:
        enum class PointerStyle
        {
            ClassicNeedle,      // Ago galvanometrico meccanico vintage con punta vermiglio
            RadioSweeper        // Sweeper luminoso stile sintonizzatore radio vintage a filamento incandescente
        };

        AnalogMeterNeedle()
        {
            setOpaque(false);
            setInterceptsMouseClicks(false, false);
        }

        void loadAssets(const juce::Image& needleImg, const juce::Image& sweeperImg = {})
        {
            imgNeedle = needleImg;
            imgSweeper = sweeperImg;
            repaint();
        }

        void setPointerStyle(PointerStyle style)
        {
            currentStyle = style;
            repaint();
        }

        /**
         * @brief Imposta l'angolo assoluto della lancetta/sweeper in radianti.
         * Pivot calibrato a CX=52.91%, CY=66.77%.
         */
        void setAngle(float angleRadians)
        {
            currentAngle = angleRadians;
            repaint();
        }

        /**
         * @brief Imposta il livello di metering secondo la calibrazione fisica IEC 60268-17:
         * In modalita VU: sweep da 0% (-20 VU, -29.60 deg) a 100% (+3 VU, +28.20 deg), con 0 VU a +12.50 deg.
         * In modalita GR: riposo a 0 dB (+34.50 deg a destra), deflette a sinistra verso -20 dB (-26.10 deg).
         */
        void setNormalizedValue(float normVal0to1, bool isGainReduction = false)
        {
            const float clamped = juce::jlimit(0.0f, 1.0f, normVal0to1);
            float targetDeg = 0.0f;
            if (isGainReduction)
            {
                // GR: a riposo norm=0 -> 0 dB (+34.5 deg), max compressione norm=1 -> -20 dB (-26.1 deg)
                targetDeg = 34.50f - clamped * (34.50f - (-26.10f));
            }
            else
            {
                // VU: 0% -> -29.60 deg, 100% -> +28.20 deg
                targetDeg = -29.60f + clamped * (28.20f - (-29.60f));
            }
            setAngle(juce::degreesToRadians(targetDeg));
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            // Coordinate pivot calibrate dal progetto SVG master (541.83 / 1024, 510.78 / 765)
            const float pivotX = bounds.getX() + bounds.getWidth() * 0.52913f;
            const float pivotY = bounds.getY() + bounds.getHeight() * 0.66769f;

            if (currentStyle == PointerStyle::RadioSweeper && imgSweeper.isValid())
            {
                // Sweeper stile radio: sorgente a 0.0 deg (verticale)
                juce::Graphics::ScopedSaveState state(g);
                g.addTransform(juce::AffineTransform::rotation(currentAngle, pivotX, pivotY));
                g.drawImage(imgSweeper, bounds, juce::RectanglePlacement::stretchToFit);
            }
            else if (imgNeedle.isValid())
            {
                // Lancetta classica: angolo sorgente dello sprite calibrato a +10.33 deg
                const float relAngle = currentAngle - juce::degreesToRadians(10.33f);

                // Ombra portata analogica sul quadrante
                {
                    juce::Graphics::ScopedSaveState state(g);
                    g.addTransform(juce::AffineTransform::rotation(relAngle, pivotX, pivotY).translated(2.5f, 3.5f));
                    g.setColour(juce::Colours::black.withAlpha(0.38f));
                    g.drawImage(imgNeedle, bounds, juce::RectanglePlacement::stretchToFit);
                }

                // Lancetta principale
                {
                    juce::Graphics::ScopedSaveState state(g);
                    g.addTransform(juce::AffineTransform::rotation(relAngle, pivotX, pivotY));
                    g.drawImage(imgNeedle, bounds, juce::RectanglePlacement::stretchToFit);
                }
            }
            else
            {
                // Fallback procedurale elegante
                juce::Graphics::ScopedSaveState state(g);
                g.addTransform(juce::AffineTransform::rotation(currentAngle, pivotX, pivotY));

                const float needleLen = bounds.getHeight() * 0.417f; // R = 318.94 / 765
                g.setColour(juce::Colours::black.withAlpha(0.92f));
                juce::Path p;
                p.startNewSubPath(pivotX - 2.0f, pivotY);
                p.lineTo(pivotX - 0.7f, pivotY - needleLen);
                p.lineTo(pivotX + 0.7f, pivotY - needleLen);
                p.lineTo(pivotX + 2.0f, pivotY);
                p.closeSubPath();
                g.fillPath(p);

                // Punta rossa di precisione
                g.setColour(juce::Colour::fromString("ffe02b1f"));
                g.fillRect(pivotX - 1.0f, pivotY - needleLen, 2.0f, needleLen * 0.32f);

                // Calotta perno dorata
                g.setColour(juce::Colour::fromString("ffd6b467"));
                g.fillEllipse(pivotX - 9.0f, pivotY - 9.0f, 18.0f, 18.0f);
            }
        }

    private:
        juce::Image imgNeedle;
        juce::Image imgSweeper;
        PointerStyle currentStyle = PointerStyle::ClassicNeedle;
        float currentAngle = juce::degreesToRadians(-29.60f); // Rest iniziale a 0%
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AnalogMeterNeedle)
    };


    // ==============================================================================
    // 10. GRIGLIA DI VENTILAZIONE CHASSIS ("ChassisGrilleComponent")
    // ==============================================================================
    class ChassisGrilleComponent : public juce::Component
    {
    public:
        ChassisGrilleComponent()
        {
            setOpaque(false);
            setInterceptsMouseClicks(false, false);
        }

        void loadAsset(const juce::Image& grilleHollowImg)
        {
            imgGrille = grilleHollowImg;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            if (imgGrille.isValid())
            {
                g.drawImage(imgGrille, bounds, juce::RectanglePlacement::stretchToFit);
            }
            else
            {
                g.setColour(juce::Colour::fromString("ff1f1d1a"));
                g.fillRoundedRectangle(bounds, 6.0f);
                g.setColour(juce::Colour::fromString("ff423b31"));
                g.drawRoundedRectangle(bounds, 6.0f, 1.4f);
            }
        }

    private:
        juce::Image imgGrille;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ChassisGrilleComponent)
    };


    // ==============================================================================
    // 11. VU METER COMPLETO RETTANGOLARE ("RectangularVuMeterAssembly")
    // ==============================================================================
    class RectangularVuMeterAssembly : public juce::Component, public juce::Timer
    {
    public:
        RectangularVuMeterAssembly()
        {
            setOpaque(false);
            startTimerHz(60); // 60 FPS smooth ballistics
        }

        ~RectangularVuMeterAssembly() override
        {
            stopTimer();
        }

        void loadAssets(const juce::Image& cleanDial, const juce::Image& needle, const juce::Image& glassOverlay)
        {
            imgDial = cleanDial;
            imgNeedle = needle;
            imgGlass = glassOverlay;
            repaint();
        }

        void setLevelDb(float db)
        {
            // VU calibration: -20 dB = -0.58 rad (~ -33 deg), 0 dB = 0.0 rad, +3 dB = +0.58 rad (~ +33 deg)
            float clampedDb = juce::jlimit(-20.0f, +3.0f, db);
            float norm0to1 = (clampedDb - (-20.0f)) / (3.0f - (-20.0f));
            targetAngle = -0.58f + norm0to1 * (0.58f - (-0.58f));
        }

        void timerCallback() override
        {
            // Analog ballistic damping: 300ms rise, exponential follow
            float delta = targetAngle - currentAngle;
            if (std::abs(delta) > 0.0005f)
            {
                currentAngle += delta * 0.22f;
                repaint();
            }
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();

            // 1. Dial Background
            if (imgDial.isValid())
            {
                g.drawImage(imgDial, bounds, juce::RectanglePlacement::stretchToFit);
            }
            else
            {
                g.setColour(juce::Colour::fromString("fff2e1bd"));
                g.fillRoundedRectangle(bounds, 6.0f);
            }

            // 2. Rotating Precision Needle
            if (imgNeedle.isValid())
            {
                // Pivot coordinates calibrated to lower center of dial arc
                const float pivotX = bounds.getX() + bounds.getWidth() * 0.50f;
                const float pivotY = bounds.getY() + bounds.getHeight() * 0.88f;

                const float needleW = bounds.getWidth() * 0.09f;
                const float needleH = bounds.getHeight() * 0.82f;

                // Center needle over pivot point
                juce::Rectangle<float> needleBounds(pivotX - needleW * 0.5f, pivotY - needleH * 0.88f, needleW, needleH);

                juce::AffineTransform tx = juce::AffineTransform::rotation(currentAngle, pivotX, pivotY);

                juce::Graphics::ScopedSaveState ss(g);
                g.addTransform(tx);
                g.drawImage(imgNeedle, needleBounds, juce::RectanglePlacement::stretchToFit);
            }

            // 3. Polarized Glass Overlay
            if (imgGlass.isValid())
            {
                g.drawImage(imgGlass, bounds, juce::RectanglePlacement::stretchToFit);
            }
        }

    private:
        juce::Image imgDial;
        juce::Image imgNeedle;
        juce::Image imgGlass;
        float currentAngle = -0.58f;
        float targetAngle = -0.58f;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RectangularVuMeterAssembly)
    };

    // ==============================================================================
    // 12. MANOPOLA SCALLOPED BAKELITE ("ScallopedBakeliteSlider")
    // ==============================================================================
    class ScallopedBakeliteSlider : public juce::Slider
    {
    public:
        ScallopedBakeliteSlider()
        {
            setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        }

        void loadAsset(const juce::Image& knobImg)
        {
            imgKnob = knobImg;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float diameter = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx = bounds.getCentreX();
            const float cy = bounds.getCentreY();
            const juce::Rectangle<float> knobBounds(cx - diameter * 0.5f, cy - diameter * 0.5f, diameter, diameter);

            const float minAngle = -2.35619449f; // -135 deg
            const float maxAngle = +2.35619449f; // +135 deg
            const float normVal = (float)valueToProportionOfLength(getValue());
            const float angle = minAngle + normVal * (maxAngle - minAngle);

            if (imgKnob.isValid())
            {
                juce::AffineTransform tx = juce::AffineTransform::rotation(angle, cx, cy);
                juce::Graphics::ScopedSaveState ss(g);
                g.addTransform(tx);
                g.drawImage(imgKnob, knobBounds, juce::RectanglePlacement::stretchToFit);
            }
            else
            {
                g.setColour(juce::Colour::fromString("ff261e16"));
                g.fillEllipse(knobBounds);
                g.setColour(juce::Colour::fromString("ffff9922"));
                g.fillEllipse(cx - 3.0f, cy - diameter * 0.38f, 6.0f, 6.0f);
            }
        }

    private:
        juce::Image imgKnob;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ScallopedBakeliteSlider)
    };


    // ==============================================================================
    // 13. MANOPOLA MODERNA GUNMETAL DIAMOND-KNURLED ("ModernGunmetalKnurledSlider")
    // ==============================================================================
    class ModernGunmetalKnurledSlider : public juce::Slider
    {
    public:
        ModernGunmetalKnurledSlider()
        {
            setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        }

        void loadAsset(const juce::Image& knobImg)
        {
            imgKnob = knobImg;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float diameter = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx = bounds.getCentreX();
            const float cy = bounds.getCentreY();
            const juce::Rectangle<float> knobBounds(cx - diameter * 0.5f, cy - diameter * 0.5f, diameter, diameter);

            const float minAngle = -2.35619449f; // -135 deg
            const float maxAngle = +2.35619449f; // +135 deg
            const float normVal = (float)valueToProportionOfLength(getValue());
            const float angle = minAngle + normVal * (maxAngle - minAngle);

            if (imgKnob.isValid())
            {
                juce::AffineTransform tx = juce::AffineTransform::rotation(angle, cx, cy);
                juce::Graphics::ScopedSaveState ss(g);
                g.addTransform(tx);
                g.drawImage(imgKnob, knobBounds, juce::RectanglePlacement::stretchToFit);
            }
            else
            {
                g.setColour(juce::Colour::fromString("ff1b1d22"));
                g.fillEllipse(knobBounds);
                g.setColour(juce::Colour::fromString("ffdedede"));
                g.fillRect(cx - 2.0f, cy - diameter * 0.42f, 4.0f, diameter * 0.12f);
            }
        }

    private:
        juce::Image imgKnob;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ModernGunmetalKnurledSlider)
    };


    // ==============================================================================
    // 14. BULLONE HARDWARE ESAGONALE IN OTTONE ("ChassisHexBoltComponent")
    // ==============================================================================
    class ChassisHexBoltComponent : public juce::Component
    {
    public:
        ChassisHexBoltComponent()
        {
            setOpaque(false);
            setInterceptsMouseClicks(false, false);
        }

        void loadAsset(const juce::Image& boltImg)
        {
            imgBolt = boltImg;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            if (imgBolt.isValid())
            {
                g.drawImage(imgBolt, bounds, juce::RectanglePlacement::stretchToFit);
            }
            else
            {
                g.setColour(juce::Colour::fromString("ff8c734b"));
                g.fillEllipse(bounds);
                g.setColour(juce::Colour::fromString("ff181512"));
                g.fillEllipse(bounds.reduced(bounds.getWidth() * 0.28f));
            }
        }
    private:
        juce::Image imgBolt;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ChassisHexBoltComponent)
    };

    // ==============================================================================
    // 15. MANOPOLA TEARDROP POINTER COLLET CON SCALA ("TeardropPointerColletSlider")
    // ==============================================================================
    class TeardropPointerColletSlider : public juce::Slider
    {
    public:
        enum class ScaleDialType
        {
            Frequency_20Hz_to_20kHz, // Calibrated exactly to 20Hz (-145 deg) and 20kHz (+145 deg)
            Percentage_0_to_100      // Calibrated exactly to 0% (-150 deg) and 100% (+150 deg)
        };

        TeardropPointerColletSlider()
        {
            setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        }

        void setScaleDialType(ScaleDialType type)
        {
            scaleType = type;
            if (scaleType == ScaleDialType::Frequency_20Hz_to_20kHz)
            {
                minAngleRad = -2.5307274f; // -145.0 deg
                maxAngleRad = +2.5307274f; // +145.0 deg
            }
            else
            {
                minAngleRad = -2.61799388f; // -150.0 deg
                maxAngleRad = +2.61799388f; // +150.0 deg
            }
            repaint();
        }

        void setCustomAngularRange(float minAngleDegrees, float maxAngleDegrees)
        {
            minAngleRad = juce::degreesToRadians(minAngleDegrees);
            maxAngleRad = juce::degreesToRadians(maxAngleDegrees);
            repaint();
        }

        void loadAssets(const juce::Image& dialScaleImg, const juce::Image& pointerKnobImg)
        {
            imgScale = dialScaleImg;
            imgKnob = pointerKnobImg;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float diameter = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx = bounds.getCentreX();
            const float cy = bounds.getCentreY();
            const juce::Rectangle<float> dialBounds(cx - diameter * 0.5f, cy - diameter * 0.5f, diameter, diameter);

            // 1. Draw Stationary Calibrated Dial Ring (Scale)
            if (imgScale.isValid())
            {
                g.drawImage(imgScale, dialBounds, juce::RectanglePlacement::stretchToFit);
            }

            // 2. Draw Rotating Teardrop Pointer Knob
            // Knob diameter matches the dial scale inner opening (~72% of dial bounds)
            const float knobDiameter = diameter * 0.72f;
            const juce::Rectangle<float> knobBounds(cx - knobDiameter * 0.5f, cy - knobDiameter * 0.5f, knobDiameter, knobDiameter);

            const float normVal = (float)valueToProportionOfLength(getValue());
            const float angle = minAngleRad + normVal * (maxAngleRad - minAngleRad);

            if (imgKnob.isValid())
            {
                juce::AffineTransform tx = juce::AffineTransform::rotation(angle, cx, cy);
                juce::Graphics::ScopedSaveState ss(g);
                g.addTransform(tx);
                g.drawImage(imgKnob, knobBounds, juce::RectanglePlacement::stretchToFit);
            }
            else
            {
                g.setColour(juce::Colour::fromString("ff1f1d1a"));
                g.fillEllipse(knobBounds);
                g.setColour(juce::Colour::fromString("ffffa033"));
                g.drawLine(cx, cy, cx + std::sin(angle) * (knobDiameter * 0.45f), cy - std::cos(angle) * (knobDiameter * 0.45f), 2.5f);
            }
        }

    private:
        ScaleDialType scaleType = ScaleDialType::Frequency_20Hz_to_20kHz;
        float minAngleRad = -2.5307274f; // -145.0 deg
        float maxAngleRad = +2.5307274f; // +145.0 deg
        juce::Image imgKnob;
        juce::Image imgScale;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TeardropPointerColletSlider)
    };

    // ==============================================================================
    // 16. MANOPOLA SELETTORE A FARFALLA / WINGED ("WingedSelectorKnobSlider")
    // ==============================================================================
    class WingedSelectorKnobSlider : public juce::Slider
    {
    public:
        WingedSelectorKnobSlider()
        {
            setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        }

        void loadAssets(const juce::Image& outerBezelImg, const juce::Image& wingedKnobImg)
        {
            imgBezel = outerBezelImg;
            imgKnob = wingedKnobImg;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float diameter = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx = bounds.getCentreX();
            const float cy = bounds.getCentreY();
            const juce::Rectangle<float> rect(cx - diameter * 0.5f, cy - diameter * 0.5f, diameter, diameter);

            // 1. Disegna la ghiera esterna fissa
            if (imgBezel.isValid())
            {
                g.drawImage(imgBezel, rect, juce::RectanglePlacement::stretchToFit);
            }

            // 2. Calcola angolo rotazione levetta a farfalla
            const float minAngle = -2.35619449f; // -135 deg
            const float maxAngle = +2.35619449f; // +135 deg
            const float normVal = (float)valueToProportionOfLength(getValue());
            const float angle = minAngle + normVal * (maxAngle - minAngle);

            if (imgKnob.isValid())
            {
                juce::AffineTransform tx = juce::AffineTransform::rotation(angle, cx, cy);
                juce::Graphics::ScopedSaveState ss(g);
                g.addTransform(tx);
                g.drawImage(imgKnob, rect, juce::RectanglePlacement::stretchToFit);
            }
            else
            {
                g.setColour(juce::Colour::fromString("ff1f1d1a"));
                g.fillEllipse(rect.reduced(diameter * 0.25f));
                g.setColour(juce::Colour::fromString("ffffa033"));
                g.drawLine(cx, cy, cx + std::sin(angle) * (diameter * 0.46f), cy - std::cos(angle) * (diameter * 0.46f), 3.0f);
            }
        }

    private:
        juce::Image imgBezel;
        juce::Image imgKnob;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(WingedSelectorKnobSlider)
    };


    // ==============================================================================
    // 17. STUDIO VU METER ROTARY MODE SELECTOR SWITCH ("StudioVuMeterModeSelectorSwitch")
    // ==============================================================================
    /**
     * @brief 4-Position Discrete Detented Rotary Mode Selector for Studio VU Meters.
     * Manages calibrated mechanical detents:
     *  - OFF        (-60.4 deg) : De-energized meter movement & lamps
     *  - GR         (-28.5 deg) : Gain Reduction attenuation scale
     *  - +4 dBm     (+15.6 deg) : Standard Studio VU Reference (0 VU = 1.228V RMS)
     *  - +8 dBm     (+59.5 deg) : High-Headroom Studio VU Reference (+4 dB pad)
     */
    class StudioVuMeterModeSelectorSwitch : public juce::Component, public juce::Timer
    {
    public:
        enum class Mode
        {
            Off = 0,
            GainReduction = 1,
            VuPlus4 = 2,
            VuPlus8 = 3
        };

        StudioVuMeterModeSelectorSwitch()
        {
            setOpaque(false);
            setMouseCursor(juce::MouseCursor::PointingHandCursor);
            startTimerHz(60);
        }

        ~StudioVuMeterModeSelectorSwitch() override { stopTimer(); }

        void loadAssets(const juce::Image& stationaryBezel, const juce::Image& rotatingKnob)
        {
            bezelImg = stationaryBezel;
            knobImg = rotatingKnob;
            repaint();
        }

        void setMode(Mode newMode, juce::NotificationType notification = juce::sendNotificationAsync)
        {
            currentMode = newMode;
            targetAngleDeg = getAngleForMode(newMode);

            if (notification != juce::dontSendNotification && onModeChanged)
                onModeChanged(currentMode);

            repaint();
        }

        Mode getMode() const noexcept { return currentMode; }

        static float getAngleForMode(Mode m) noexcept
        {
            switch (m)
            {
                case Mode::Off:           return -60.4f;
                case Mode::GainReduction: return -28.5f;
                case Mode::VuPlus4:       return  15.6f;
                case Mode::VuPlus8:       return  59.5f;
                default:                  return -28.5f;
            }
        }

        std::function<void(Mode)> onModeChanged;

        void mouseDown(const juce::MouseEvent& e) override
        {
            dragStartY = e.position.y;
            initialModeInt = static_cast<int>(currentMode);
        }

        void mouseDrag(const juce::MouseEvent& e) override
        {
            const float deltaY = dragStartY - e.position.y;
            int stepDelta = static_cast<int>(deltaY / 30.0f);
            int newModeInt = juce::jlimit(0, 3, initialModeInt + stepDelta);

            if (newModeInt != static_cast<int>(currentMode))
            {
                setMode(static_cast<Mode>(newModeInt), juce::sendNotificationAsync);
            }
        }

        void mouseUp(const juce::MouseEvent& e) override
        {
            if (e.getDistanceFromDragStart() < 4)
            {
                int nextInt = (static_cast<int>(currentMode) + 1) % 4;
                setMode(static_cast<Mode>(nextInt), juce::sendNotificationAsync);
            }
        }

        void timerCallback() override
        {
            const float diff = targetAngleDeg - currentAngleDeg;
            if (std::abs(diff) > 0.05f)
            {
                currentAngleDeg += diff * 0.35f;
                repaint();
            }
            else if (currentAngleDeg != targetAngleDeg)
            {
                currentAngleDeg = targetAngleDeg;
                repaint();
            }
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float size = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx = bounds.getCentreX();
            const float cy = bounds.getCentreY();
            auto dialRect = bounds.withSizeKeepingCentre(size, size);

            // 1. Layer base: Ghiera fissa in bronzo scuro con serigrafie ambra e viti
            if (bezelImg.isValid())
            {
                g.drawImage(bezelImg, dialRect, juce::RectanglePlacement::centred);
            }
            else
            {
                g.setColour(juce::Colour::fromString("ff23211c"));
                g.fillEllipse(dialRect);
                g.setColour(juce::Colour::fromString("ff967846"));
                g.drawEllipse(dialRect, 2.0f);
            }

            // 2. Layer superiore: Manopola sagomata 171 Studio rotante
            if (knobImg.isValid())
            {
                const float knobSize = size * 0.6603f;
                auto knobRect = bounds.withSizeKeepingCentre(knobSize, knobSize);

                juce::Graphics::ScopedSaveState state(g);
                g.addTransform(juce::AffineTransform::rotation(juce::degreesToRadians(currentAngleDeg), cx, cy));
                g.drawImage(knobImg, knobRect, juce::RectanglePlacement::centred);
            }
            else
            {
                const float rKnob = size * 0.24f;
                g.setColour(juce::Colour::fromString("ff151412"));
                g.fillEllipse(cx - rKnob, cy - rKnob, rKnob * 2.0f, rKnob * 2.0f);

                const float rad = juce::degreesToRadians(currentAngleDeg);
                const float nx = cx + (rKnob + 6.0f) * std::sin(rad);
                const float ny = cy - (rKnob + 6.0f) * std::cos(rad);
                g.setColour(juce::Colour::fromString("ffffb836"));
                g.drawLine(cx, cy, nx, ny, 2.5f);
            }
        }

    private:
        juce::Image bezelImg;
        juce::Image knobImg;
        Mode currentMode = Mode::GainReduction;
        float currentAngleDeg = -28.5f;
        float targetAngleDeg = -28.5f;
        float dragStartY = 0.0f;
        int initialModeInt = 1;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(StudioVuMeterModeSelectorSwitch)
    };

    // ==============================================================================
    // 18. MODULO VU METER DA STUDIO PERSONALIZZATO ("StudioAnalogVuMeterModule")
    // ==============================================================================
    class StudioAnalogVuMeterModule : public juce::Component, public juce::Timer
    {
    public:
        enum class MeterMode { Off, GainReduction, VU_Plus4, VU_Plus8 };

        StudioAnalogVuMeterModule()
        {
            setOpaque(false);
            startTimerHz(60);
            setMeterMode(MeterMode::GainReduction);
        }

        ~StudioAnalogVuMeterModule() override { stopTimer(); }

        void loadAssets(const juce::Image& dialVU, const juce::Image& dialGR, const juce::Image& needle, const juce::Image& bezel)
        {
            imgDialVU = dialVU;
            imgDialGR = dialGR;
            imgNeedle = needle;
            imgBezel = bezel;
            repaint();
        }

        void setMeterMode(MeterMode mode)
        {
            currentMode = mode;
            if (currentMode == MeterMode::Off)
            {
                targetAngleDeg = -38.0f; // Sotto scala a riposo senza alimentazione
            }
            else if (currentMode == MeterMode::GainReduction)
            {
                // In Gain Reduction a riposo (0 dB riduzione): lancetta a destra su 0 dB!
                targetAngleDeg = 29.3f;
            }
            else
            {
                // In VU Mode a riposo (silenzio): lancetta a sinistra su -20 VU!
                targetAngleDeg = -35.2f;
            }
            repaint();
        }

        void setLevelDb(float db)
        {
            if (currentMode == MeterMode::Off)
            {
                targetAngleDeg = -38.0f;
                return;
            }

            if (currentMode == MeterMode::GainReduction)
            {
                // Gain Reduction Mode:
                // Quando la compressione e' 0 dB (nessuna riduzione): lancetta a destra su 0 dB (+29.3 deg)
                // All'aumentare della compressione: devia verso SINISTRA verso -20 dB (-35.2 deg)
                const float grAmount = std::abs(db); // positiva: 0 .. 20 dB
                const float clamped = juce::jlimit(0.0f, 20.0f, grAmount);
                const float norm = clamped / 20.0f;
                targetAngleDeg = 29.3f - norm * (29.3f - (-35.2f));
            }
            else
            {
                // VU Signal Mode:
                // MeterMode::VU_Plus4: 0 VU = +4 dBu (1.228V RMS)
                // MeterMode::VU_Plus8: 0 VU = +8 dBu (+4 dB pad di attenuazione)
                const float adjustedDb = (currentMode == MeterMode::VU_Plus8) ? (db - 4.0f) : db;
                const float clamped = juce::jlimit(-20.0f, 3.0f, adjustedDb);
                const float norm = (clamped - (-20.0f)) / (3.0f - (-20.0f));
                targetAngleDeg = -35.2f + norm * (29.3f - (-35.2f));
            }
        }

        void timerCallback() override
        {
            const float delta = targetAngleDeg - currentAngleDeg;
            if (std::abs(delta) > 0.05f)
            {
                // Risposta balistica standard IEC 60268-17 (300 ms con leggero overshoot naturale)
                const float coeff = (delta > 0.0f) ? 0.22f : 0.16f;
                currentAngleDeg += delta * coeff;
                repaint();
            }
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();

            // 1. Layer 1: Scala graduata incassata (Clean VU o Clean GR, zero sbordature)
            const auto& activeDial = (currentMode == MeterMode::GainReduction) ? imgDialGR : imgDialVU;
            if (activeDial.isValid())
            {
                g.drawImage(activeDial, bounds, juce::RectanglePlacement::stretchToFit);
            }

            // 2. Layer 2: Lancetta meccanica rotante (accorciata a 455px, tip sempre dentro la finestra)
            if (imgNeedle.isValid())
            {
                const float pivotX = bounds.getX() + bounds.getWidth() * (504.26f / 1024.0f);
                const float pivotY = bounds.getY() + bounds.getHeight() * (618.72f / 765.0f);

                const float angle = (currentMode == MeterMode::Off) ? -38.0f : currentAngleDeg;
                const float rotationRad = juce::degreesToRadians(angle - 10.47f);

                juce::Graphics::ScopedSaveState ss(g);
                g.addTransform(juce::AffineTransform::rotation(rotationRad, pivotX, pivotY));
                g.drawImage(imgNeedle, bounds, juce::RectanglePlacement::stretchToFit);
            }

            // 3. Layer 3: Cornice in metallo fuso allargata con finestra a ventaglio (copre 100% i bordi)
            if (imgBezel.isValid())
            {
                g.drawImage(imgBezel, bounds, juce::RectanglePlacement::stretchToFit);
            }
        }

    private:
        juce::Image imgDialVU;
        juce::Image imgDialGR;
        juce::Image imgNeedle;
        juce::Image imgBezel;
        MeterMode currentMode = MeterMode::GainReduction;
        float currentAngleDeg = 29.3f; // Default a riposo in GR: 0 dB (a destra!)
        float targetAngleDeg = 29.3f;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(StudioAnalogVuMeterModule)
    };

    // ==============================================================================
    // 19. ANALOG VACUUM TUBE EMULATION MODULE ("StudioVacuumTubeModule")
    // ==============================================================================
    /**
     * @brief Studio Vacuum Tube Stage with dynamic thermal filament glow modulation.
     * Blends cold tube base (OFF) with pure emissive glow layer (ON) based on
     * saturation drive level and incoming audio dynamics at 60 FPS.
     */
    class StudioVacuumTubeModule : public juce::Component, public juce::Timer
    {
    public:
        enum class TubeModel
        {
            Model_12AX7,
            Model_EF86_Socket,
            Model_EF86_Glass,
            Model_300B_Power
        };

        StudioVacuumTubeModule()
        {
            setOpaque(false);
            startTimerHz(60);
        }

        ~StudioVacuumTubeModule() override { stopTimer(); }

        void loadAssets(const juce::Image& coldTube, const juce::Image& glowOverlay)
        {
            imgCold = coldTube;
            imgGlow = glowOverlay;
            repaint();
        }

        /**
         * @brief Sets the static/base drive saturation warmth (0.0f = cold/off, 1.0f = full incandescent glow).
         */
        void setDriveWarmth(float warmth0to1)
        {
            baseWarmth = juce::jlimit(0.0f, 1.0f, warmth0to1);
        }

        /**
         * @brief Feeds real-time audio peak/RMS to dynamically pulse the tube filament glow.
         */
        void setAudioPeak(float peakLinear)
        {
            audioPeak = juce::jlimit(0.0f, 1.0f, peakLinear);
        }

        void timerCallback() override
        {
            // Physical thermal inertia: filament heats up quickly (~40ms), cools down smoothly (~120ms)
            const float targetGlow = juce::jlimit(0.0f, 1.0f, baseWarmth + audioPeak * 0.35f);
            const float attackCoeff = 0.35f;
            const float decayCoeff  = 0.08f;

            if (targetGlow > currentGlow)
                currentGlow += (targetGlow - currentGlow) * attackCoeff;
            else
                currentGlow += (targetGlow - currentGlow) * decayCoeff;

            audioPeak *= 0.85f; // Exponential decay on audio peak
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();

            // 1. Layer 1: Cold Tube Base (Glass envelope, plates, getter, socket/pins)
            if (imgCold.isValid())
            {
                g.drawImage(imgCold, bounds, juce::RectanglePlacement::centred);
            }

            // 2. Layer 2: Additive Emissive Glow Overlay (Filament + internal radiation)
            if (imgGlow.isValid() && currentGlow > 0.01f)
            {
                juce::Graphics::ScopedSaveState state(g);
                g.setOpacity(currentGlow);
                g.drawImage(imgGlow, bounds, juce::RectanglePlacement::centred);
            }
        }

    private:
        juce::Image imgCold;
        juce::Image imgGlow;
        float baseWarmth = 0.5f;
        float audioPeak = 0.0f;
        float currentGlow = 0.5f;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(StudioVacuumTubeModule)
    };

    // ==============================================================================
    // 20. CHASSIS DUAL-STATE HARDWARE TOGGLE BUTTONS ("BoutiqueChassisSwitchComponent")
    // ==============================================================================
    /**
     * @brief Universal 2-state skeuomorphic chassis switch (Phase Inverter, Console Push-Button, Baton Bypass).
     * Renders normal (State 0 / Down / Unlit) vs engaged (State 1 / Up / LED On) with zero heap allocation.
     */
    class BoutiqueChassisSwitchComponent : public juce::ToggleButton
    {
    public:
        BoutiqueChassisSwitchComponent(const juce::String& componentName = "ChassisSwitch")
            : juce::ToggleButton(componentName)
        {
            setMouseCursor(juce::MouseCursor::PointingHandCursor);
        }

        void loadAssets(const juce::Image& normalStateImg, const juce::Image& activeStateImg)
        {
            imgNormal = normalStateImg;
            imgActive = activeStateImg;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const auto& targetImg = getToggleState() ? imgActive : imgNormal;

            if (targetImg.isValid())
            {
                g.drawImage(targetImg, bounds, juce::RectanglePlacement::centred);
            }
            else
            {
                // Fallback procedurale elegante
                const auto boxRect = bounds.reduced(4.0f);
                g.setColour(juce::Colour::fromString("ff18191c"));
                g.fillRoundedRectangle(boxRect, 8.0f);
                g.setColour(juce::Colour::fromString("ff383b44"));
                g.drawRoundedRectangle(boxRect, 8.0f, 1.5f);

                // LED / Status
                if (getToggleState())
                {
                    g.setColour(juce::Colour::fromString("ffff4030"));
                    g.fillEllipse(boxRect.getCentreX() - 5.0f, boxRect.getY() + 15.0f, 10.0f, 10.0f);
                }
            }
        }

    private:
        juce::Image imgNormal;
        juce::Image imgActive;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(BoutiqueChassisSwitchComponent)
    };

    //==============================================================================
    /**
     * @brief StudioChassisVentilationGrilleComponent - Batch 13 Boutique Hardware Component.
     * Renders modular vintage and modern audio rack ventilation grilles with optional
     * hollow slots exposing glowing vacuum tube stages or deep chassis dark cavities.
     * 100% compliant with JUCE zero-allocation realtime graphics standards.
     */
    class StudioChassisVentilationGrilleComponent : public juce::Component
    {
    public:
        enum class GrilleStyle
        {
            Horizontal4Bay_StainlessHandles,
            Vertical500Series_CastLouvres,
            Horizontal3Bay_MilledBlack
        };

        enum class BackingMode
        {
            HollowWithVacuumTubes,
            DarkCavity
        };

        StudioChassisVentilationGrilleComponent(const juce::String& name = "VentilationGrille")
            : juce::Component(name)
        {
            setOpaque(false);
        }

        void setGrilleStyle(GrilleStyle style)
        {
            currentStyle = style;
            repaint();
        }

        void setBackingMode(BackingMode mode)
        {
            currentBacking = mode;
            repaint();
        }

        /**
         * @brief Sets tube drive saturation warmth from 0.0f (cold idle) to 1.0f (full saturation glow).
         */
        void setTubeDrive(float normalizedDrive)
        {
            tubeDrive = juce::jlimit(0.0f, 1.0f, normalizedDrive);
            repaint();
        }

        void loadAssets(const juce::Image& hollowGrilleImg,
                        const juce::Image& darkCavityGrilleImg,
                        const juce::Image& tubeStageImg = {},
                        const juce::Image& tubeFilamentGlowImg = {})
        {
            imgHollowGrille = hollowGrilleImg;
            imgDarkCavityGrille = darkCavityGrilleImg;
            imgTubeStage = tubeStageImg;
            imgTubeFilamentGlow = tubeFilamentGlowImg;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();

            if (currentBacking == BackingMode::DarkCavity)
            {
                if (imgDarkCavityGrille.isValid())
                {
                    g.drawImage(imgDarkCavityGrille, bounds, juce::RectanglePlacement::centred);
                    return;
                }
            }

            // Tube Observation Mode:
            // 1. Deep internal chassis dark cavity
            g.setColour(juce::Colour::fromString("ff0a0b0e"));
            g.fillRoundedRectangle(bounds.reduced(2.0f), 8.0f);

            // 2. Dynamic filament heat glow & tube rendering
            if (currentBacking == BackingMode::HollowWithVacuumTubes)
            {
                // Ambient radial glow behind the slots
                const float glowAlpha = juce::jlimit(0.1f, 0.95f, 0.25f + tubeDrive * 0.70f);
                juce::Colour glowColour = juce::Colour::fromFloatRGBA(1.0f, 0.45f + tubeDrive * 0.15f, 0.10f, glowAlpha);

                juce::ColourGradient grad(glowColour, bounds.getCentreX(), bounds.getCentreY(),
                                          juce::Colours::transparentBlack, bounds.getCentreX(), bounds.getY(), true);
                g.setGradientFill(grad);
                g.fillRoundedRectangle(bounds.reduced(10.0f), 8.0f);

                // Tubes layer
                if (imgTubeStage.isValid())
                {
                    g.setOpacity(0.85f + tubeDrive * 0.15f);
                    g.drawImage(imgTubeStage, bounds.reduced(14.0f), juce::RectanglePlacement::centred);
                    g.setOpacity(1.0f);
                }

                if (imgTubeFilamentGlow.isValid() && tubeDrive > 0.05f)
                {
                    g.setOpacity(tubeDrive);
                    g.drawImage(imgTubeFilamentGlow, bounds.reduced(14.0f), juce::RectanglePlacement::centred);
                    g.setOpacity(1.0f);
                }
            }

            // 3. Foreground Grille overlay
            const auto& targetGrille = (currentBacking == BackingMode::DarkCavity && imgDarkCavityGrille.isValid())
                                           ? imgDarkCavityGrille
                                           : imgHollowGrille;

            if (targetGrille.isValid())
            {
                g.drawImage(targetGrille, bounds, juce::RectanglePlacement::centred);
            }
            else
            {
                // Elegant fallback
                g.setColour(juce::Colour::fromString("ff1a1b20"));
                g.drawRoundedRectangle(bounds.reduced(2.0f), 8.0f, 2.0f);
            }
        }

    private:
        GrilleStyle currentStyle = GrilleStyle::Horizontal4Bay_StainlessHandles;
        BackingMode currentBacking = BackingMode::HollowWithVacuumTubes;
        float tubeDrive = 0.5f;

        juce::Image imgHollowGrille;
        juce::Image imgDarkCavityGrille;
        juce::Image imgTubeStage;
        juce::Image imgTubeFilamentGlow;

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(StudioChassisVentilationGrilleComponent)
    };

    //==============================================================================
    /**
     * @brief StudioTubeStageBezelComponent - Batch 14 Boutique Hardware Component.
     * Renders modular vintage and modern audio chassis vacuum tube viewing bezels
     * (Circular TS-300B, Rectangular TS-86, Arched TS-86) with clean transparent cutouts,
     * dynamic rear chassis backplate illumination (Cold OFF vs Hot ON), and realistic
     * tube base concealment submerged behind the bottom bezel lip.
     * 100% compliant with JUCE zero-allocation realtime graphics standards.
     */
    class StudioTubeStageBezelComponent : public juce::Component
    {
    public:
        enum class BezelGeometry
        {
            Circular_TS300B,
            Rectangular_TS86,
            Arched_TS86
        };

        StudioTubeStageBezelComponent(const juce::String& name = "TubeStageBezel")
            : juce::Component(name)
        {
            setOpaque(false);
        }

        void setBezelGeometry(BezelGeometry geom)
        {
            currentGeom = geom;
            repaint();
        }

        void setPowerState(bool isPowerOn)
        {
            powerState = isPowerOn;
            repaint();
        }

        /**
         * @brief Sets tube saturation warmth from 0.0f (cold idle) to 1.0f (intense glow).
         */
        void setWarmth(float normalizedWarmth)
        {
            warmth = juce::jlimit(0.0f, 1.0f, normalizedWarmth);
            repaint();
        }

        void loadAssets(const juce::Image& bezelImg,
                        const juce::Image& backplateOffImg,
                        const juce::Image& backplateOnImg,
                        const juce::Image& tubeImg)
        {
            imgBezel = bezelImg;
            imgBackplateOff = backplateOffImg;
            imgBackplateOn = backplateOnImg;
            imgTube = tubeImg;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();

            // 1. Layer 1: Dynamic Chassis Backplate
            if (powerState)
            {
                if (imgBackplateOn.isValid())
                {
                    g.drawImage(imgBackplateOn, bounds, juce::RectanglePlacement::centred);
                }
                else
                {
                    g.setColour(juce::Colour::fromString("ff101114"));
                    g.fillRoundedRectangle(bounds, 8.0f);
                    // Fallback warm glow
                    juce::ColourGradient grad(juce::Colour::fromFloatRGBA(1.0f, 0.55f, 0.15f, 0.6f * warmth),
                                              bounds.getCentreX(), bounds.getCentreY() - 30.0f,
                                              juce::Colours::transparentBlack, bounds.getCentreX(), bounds.getY(), true);
                    g.setGradientFill(grad);
                    g.fillEllipse(bounds.getCentreX() - 150.0f, bounds.getCentreY() - 180.0f, 300.0f, 300.0f);
                }
            }
            else
            {
                if (imgBackplateOff.isValid())
                {
                    g.drawImage(imgBackplateOff, bounds, juce::RectanglePlacement::centred);
                }
                else
                {
                    g.setColour(juce::Colour::fromString("ff0a0b0d"));
                    g.fillRoundedRectangle(bounds, 8.0f);
                }
            }

            // 2. Layer 2: Tube Stage with Base Sunk Below Bezel
            if (imgTube.isValid())
            {
                // Tube bounds: centered horizontally, shifted down so socket/pins are concealed below bottom lip
                const float tubeWidth = bounds.getWidth() * 0.44f;
                const float tubeHeight = bounds.getHeight() * 0.88f;
                const float tubeX = (bounds.getWidth() - tubeWidth) * 0.5f;
                // Shift down so socket sits behind the bottom lip of the bezel (Y offset > 0)
                const float tubeY = bounds.getY() + bounds.getHeight() * 0.08f;
                const juce::Rectangle<float> tubeBounds(tubeX, tubeY, tubeWidth, tubeHeight);

                if (powerState)
                {
                    // Emissive brightness scaling with warmth
                    g.setOpacity(0.75f + warmth * 0.25f);
                    g.drawImage(imgTube, tubeBounds, juce::RectanglePlacement::centred);
                    g.setOpacity(1.0f);
                }
                else
                {
                    // Cold de-energized tube: slightly darker
                    g.setOpacity(0.65f);
                    g.drawImage(imgTube, tubeBounds, juce::RectanglePlacement::centred);
                    g.setOpacity(1.0f);
                }
            }

            // 3. Layer 3: Foreground Bezel with Clean Transparent Cutout
            if (imgBezel.isValid())
            {
                g.drawImage(imgBezel, bounds, juce::RectanglePlacement::centred);
            }
            else
            {
                // Elegant fallback
                g.setColour(juce::Colour::fromString("ff1a1b20"));
                g.drawRoundedRectangle(bounds.reduced(2.0f), 8.0f, 2.0f);
            }
        }

    private:
        BezelGeometry currentGeom = BezelGeometry::Circular_TS300B;
        bool powerState = true;
        float warmth = 0.75f;

        juce::Image imgBezel;
        juce::Image imgBackplateOff;
        juce::Image imgBackplateOn;
        juce::Image imgTube;

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(StudioTubeStageBezelComponent)
    };
}
