#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <cmath>
#include <algorithm>

namespace apge {

// ==============================================================================
// 1. Filmstrip Blitter (Sprite Sheet Animator per Manopole e Switch 3D)
// ==============================================================================
class FilmstripControl : public juce::Component {
public:
    FilmstripControl(const juce::Image& stripImage, int numFrames, bool isHorizontal = false)
        : filmstrip(stripImage), totalFrames(std::max(1, numFrames)), horizontal(isHorizontal)
    {
        setOpaque(false);
        if (filmstrip.isValid()) {
            if (horizontal) {
                frameWidth  = filmstrip.getWidth() / totalFrames;
                frameHeight = filmstrip.getHeight();
            } else {
                frameWidth  = filmstrip.getWidth();
                frameHeight = filmstrip.getHeight() / totalFrames;
            }
        }
    }

    void setValueNormalized(float norm01) noexcept {
        valueNormalized = std::clamp(norm01, 0.0f, 1.0f);
        repaint();
    }

    float getValueNormalized() const noexcept { return valueNormalized; }

    void paint(juce::Graphics& g) override {
        if (!filmstrip.isValid() || totalFrames <= 0) return;

        const int frameIndex = std::clamp(
            static_cast<int>(std::round(valueNormalized * static_cast<float>(totalFrames - 1))),
            0, totalFrames - 1
        );

        const int srcX = horizontal ? (frameIndex * frameWidth) : 0;
        const int srcY = horizontal ? 0 : (frameIndex * frameHeight);

        g.drawImage(filmstrip,
                    0, 0, getWidth(), getHeight(),
                    srcX, srcY, frameWidth, frameHeight);
    }

private:
    juce::Image filmstrip;
    int totalFrames = 1;
    bool horizontal = false;
    int frameWidth  = 0;
    int frameHeight = 0;
    float valueNormalized = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(FilmstripControl)
};

// ==============================================================================
// 2. Procedural Knob Renderer (Rotazione Texture Isolati + Glow Neon)
// ==============================================================================
class ProceduralNeonKnob : public juce::Component {
public:
    ProceduralNeonKnob(const juce::Image& knobCap, juce::Colour neonColour)
        : capImage(knobCap), themeColor(neonColour)
    {
        setOpaque(false);
    }

    void setValueNormalized(float norm01) noexcept {
        valueNormalized = std::clamp(norm01, 0.0f, 1.0f);
        repaint();
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const float size = std::min(bounds.getWidth(), bounds.getHeight());
        const float cx = bounds.getCentreX();
        const float cy = bounds.getCentreY();
        const float radius = size * 0.44f;

        constexpr float startAngle = -2.35619449f; // -135 gradi
        constexpr float endAngle   =  2.35619449f; // +135 gradi
        const float currentAngle   = startAngle + valueNormalized * (endAngle - startAngle);

        // 1. Tracciamento dell'Arco Neon di Fondo (Traccia Scanalata Spenta)
        juce::Path trackPath;
        trackPath.addCentredArc(cx, cy, radius, radius, 0.0f, startAngle, endAngle, true);
        g.setColour(juce::Colour(0x35101216));
        g.strokePath(trackPath, juce::PathStrokeType(4.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // 2. Arco Neon Attivo con Bagliore Additivo (2 Passate)
        if (valueNormalized > 0.005f) {
            juce::Path activePath;
            activePath.addCentredArc(cx, cy, radius, radius, 0.0f, startAngle, currentAngle, true);

            // Alone esterno (Glow)
            g.setColour(themeColor.withAlpha(0.35f));
            g.strokePath(activePath, juce::PathStrokeType(8.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Anima interna luminosa
            g.setColour(themeColor.brighter(0.4f));
            g.strokePath(activePath, juce::PathStrokeType(3.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }

        // 3. Ghiera Metallica Fotorealistica Ruotata al Volo
        if (capImage.isValid()) {
            const float capSize = size * 0.76f;
            const float capX = cx - capSize * 0.5f;
            const float capY = cy - capSize * 0.5f;

            auto transform = juce::AffineTransform::rotation(currentAngle, cx, cy);
            g.drawImageTransformed(capImage, transform);
        }
    }

private:
    juce::Image capImage;
    juce::Colour themeColor;
    float valueNormalized = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ProceduralNeonKnob)
};

// ==============================================================================
// 3. Simulatore Balistico Galvanometrico (IEC 60268-17 VU Needle Physics)
// ==============================================================================
class VUNeedlePhysics {
public:
    VUNeedlePhysics(float damping = 0.707f, float omega = 11.5f)
        : zeta(damping), omegaN(omega) {}

    void reset(float initialPos = 0.0f) noexcept {
        currentPosition = initialPos;
        velocity = 0.0f;
    }

    // Avanza di dt secondi (tipicamente 1/60s)
    float update(float targetPosition, float dt) noexcept {
        const float delta = targetPosition - currentPosition;
        const float spring = omegaN * omegaN * delta;
        const float damper = 2.0f * zeta * omegaN * velocity;

        velocity += (spring - damper) * dt;
        currentPosition += velocity * dt;

        return currentPosition;
    }

    float getPosition() const noexcept { return currentPosition; }

private:
    float zeta = 0.707f;
    float omegaN = 11.5f;
    float currentPosition = 0.0f;
    float velocity = 0.0f;
};

} // namespace apge
