#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <cmath>

namespace gui171 {

class RotarySwitchLookAndFeel : public juce::LookAndFeel_V4 {
public:
    RotarySwitchLookAndFeel(juce::Colour neonCol, juce::Image knobCapImg)
        : neonColor(neonCol), knobCap(knobCapImg) {}

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPosProportional, float rotaryStartAngle,
                          float rotaryEndAngle, juce::Slider&) override
    {
        const float size = static_cast<float>(juce::jmin(width, height));
        const float centreX = static_cast<float>(x) + static_cast<float>(width) * 0.5f;
        const float centreY = static_cast<float>(y) + static_cast<float>(height) * 0.5f;
        const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

        const float capRadius  = size * 0.5f - 7.0f; // Diametro ~36px
        const float tickRadius = capRadius + 4.5f;

        const bool isOn = (sliderPosProportional > 0.5f);

        // 1. Tacche incise a sinistra (OFF, rotaryStartAngle) e destra (ON, rotaryEndAngle)
        auto drawTick = [&](float tickAngle, bool active, juce::Colour col) {
            float tx1 = centreX + (tickRadius - 1.5f) * std::sin(tickAngle);
            float ty1 = centreY - (tickRadius - 1.5f) * std::cos(tickAngle);
            float tx2 = centreX + (tickRadius + 5.0f) * std::sin(tickAngle);
            float ty2 = centreY - (tickRadius + 5.0f) * std::cos(tickAngle);

            if (active) {
                // Alone luminoso
                g.setColour(col.withAlpha(0.40f));
                g.drawLine(tx1, ty1, tx2, ty2, 5.0f);
                g.setColour(col.brighter(0.2f));
                g.drawLine(tx1, ty1, tx2, ty2, 2.4f);
                g.setColour(juce::Colours::white);
                g.drawLine(tx1, ty1, tx2, ty2, 1.0f);
            } else {
                g.setColour(juce::Colour(0x65454a55));
                g.drawLine(tx1, ty1, tx2, ty2, 1.8f);
            }
        };

        drawTick(rotaryStartAngle, !isOn, juce::Colour(0xffffe099));
        drawTick(rotaryEndAngle,   isOn,  neonColor);

        // 2. Ombra cadente concentrica
        g.setColour(juce::Colour(0x80000000));
        g.fillEllipse(centreX - capRadius, centreY - capRadius + 1.5f, capRadius * 2.0f, capRadius * 2.0f);

        // 3. Rendering del pomello metallico identico alle manopole principali
        if (knobCap.isValid()) {
            const float imgW = static_cast<float>(knobCap.getWidth());
            const float imgH = static_cast<float>(knobCap.getHeight());
            const float scale = (capRadius * 2.0f) / imgW;

            auto xform = juce::AffineTransform::translation(-imgW * 0.5f, -imgH * 0.5f)
                            .scaled(scale)
                            .rotated(angle)
                            .translated(centreX, centreY);
            g.drawImageTransformed(knobCap, xform);
        } else {
            g.setColour(juce::Colour(0xff2d3035));
            g.fillEllipse(centreX - capRadius, centreY - capRadius, capRadius * 2.0f, capRadius * 2.0f);
            g.setColour(isOn ? neonColor : juce::Colour(0xffffe099));
            g.drawLine(centreX, centreY,
                       centreX + capRadius * std::sin(angle),
                       centreY - capRadius * std::cos(angle), 2.0f);
        }
    }

private:
    juce::Colour neonColor;
    juce::Image knobCap;
};

class RotarySwitchKnob : public juce::Component {
public:
    RotarySwitchKnob(const juce::String& title, const juce::String& offLabel, const juce::String& onLabel,
                     juce::Colour neonColor, juce::Image knobCap)
        : lookAndFeel(neonColor, knobCap),
          switchTitle(title),
          offText(offLabel),
          onText(onLabel),
          activeColor(neonColor)
    {
        setOpaque(false);

        // Angoli: Sinistra (-38°) per OFF, Destra (+38°) per ON
        constexpr float angleOff = -0.66f;
        constexpr float angleOn  =  0.66f;

        slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        slider.setRotaryParameters(angleOff, angleOn, true);
        slider.setLookAndFeel(&lookAndFeel);
        slider.setRange(0.0, 1.0, 1.0);
        slider.setValue(0.0, juce::dontSendNotification);

        slider.onValueChange = [this]() {
            repaint();
        };

        addAndMakeVisible(slider);
    }

    ~RotarySwitchKnob() override {
        slider.setLookAndFeel(nullptr);
    }

    void resized() override {
        const int w = getWidth();
        // Slider manopola rotativa al centro
        const int sliderDim = 46;
        slider.setBounds((w - sliderDim) / 2, 17, sliderDim, sliderDim);
    }

    void mouseDown(const juce::MouseEvent&) override {
        // Cliccando sull'intera area del componente si inverte lo switch
        slider.setValue(slider.getValue() > 0.5 ? 0.0 : 1.0, juce::sendNotification);
    }

    void paint(juce::Graphics& g) override {
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());
        const bool isOn = (slider.getValue() > 0.5);

        // 1. Titolo superiore in elegante oro/bronzo
        g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        g.setColour(activeColor.withAlpha(0.20f));
        g.drawText(switchTitle, 0, 1, static_cast<int>(w), 16, juce::Justification::centred, false);
        g.setColour(juce::Colour(0xffe6d2b5));
        g.drawText(switchTitle, 0, 0, static_cast<int>(w), 16, juce::Justification::centred, false);

        // 2. Etichette di posizione OFF (sinistra) e ON (destra) ad alto contrasto
        g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        const int labelY = static_cast<int>(h - 15.0f);
        const int halfW  = static_cast<int>(w * 0.5f);

        // Etichetta OFF (Sinistra)
        if (!isOn) {
            g.setColour(juce::Colour(0xffffe099).withAlpha(0.35f));
            g.drawText(offText, 0, labelY + 1, halfW - 4, 14, juce::Justification::centredRight, false);
            g.setColour(juce::Colour(0xffffe099));
            g.drawText(offText, 0, labelY, halfW - 4, 14, juce::Justification::centredRight, false);
        } else {
            g.setColour(juce::Colour(0x858c7c68));
            g.drawText(offText, 0, labelY, halfW - 4, 14, juce::Justification::centredRight, false);
        }

        // Etichetta ON (Destra)
        if (isOn) {
            g.setColour(activeColor.withAlpha(0.40f));
            g.drawText(onText, halfW + 4, labelY + 1, halfW - 4, 14, juce::Justification::centredLeft, false);
            g.setColour(activeColor.brighter(0.25f));
            g.drawText(onText, halfW + 4, labelY, halfW - 4, 14, juce::Justification::centredLeft, false);
        } else {
            g.setColour(juce::Colour(0x858c7c68));
            g.drawText(onText, halfW + 4, labelY, halfW - 4, 14, juce::Justification::centredLeft, false);
        }
    }

    juce::Slider& getSlider() noexcept { return slider; }

private:
    RotarySwitchLookAndFeel lookAndFeel;
    juce::Slider slider;
    juce::String switchTitle;
    juce::String offText;
    juce::String onText;
    juce::Colour activeColor;
};

} // namespace gui171
