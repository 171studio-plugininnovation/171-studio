#pragma once
#include <juce_gui_basics/juce_gui_basics.h>

namespace gui171 {

class BatonToggleSwitch : public juce::Component {
public:
    BatonToggleSwitch(const juce::String& title,
                      const juce::String& downLabel,
                      const juce::String& upLabel,
                      juce::Colour activeNeonColor,
                      juce::Image upImage,
                      juce::Image downImage)
        : switchTitle(title),
          offText(downLabel),
          onText(upLabel),
          themeColor(activeNeonColor),
          imgUp(upImage),
          imgDown(downImage)
    {
        setOpaque(false);

        slider.setSliderStyle(juce::Slider::LinearBarVertical);
        slider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        slider.setRange(0.0, 1.0, 1.0);
        slider.setValue(0.0, juce::dontSendNotification);

        slider.onValueChange = [this]() {
            repaint();
        };

        addAndMakeVisible(slider);
        slider.setAlpha(0.0f);
    }

    void resized() override {
        slider.setBounds(getLocalBounds());
    }

    void mouseDown(const juce::MouseEvent&) override {
        const double newVal = (slider.getValue() > 0.5) ? 0.0 : 1.0;
        slider.setValue(newVal, juce::sendNotification);
    }

    void paint(juce::Graphics& g) override {
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());
        const bool isUp = (slider.getValue() > 0.5);

        // 1. Titolo superiore in elegante oro/bronzo con alone luminoso
        g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        g.setColour(themeColor.withAlpha(0.20f));
        g.drawText(switchTitle, 0, 1, static_cast<int>(w), 16, juce::Justification::centred, false);
        g.setColour(juce::Colour(0xffe6d2b5));
        g.drawText(switchTitle, 0, 0, static_cast<int>(w), 16, juce::Justification::centred, false);

        // 2. Rendering del selettore a levetta 3D (UP o DOWN)
        const auto& currentImg = isUp ? imgUp : imgDown;
        if (currentImg.isValid()) {
            const float toggleSize = 46.0f;
            const float tx = (w - toggleSize) * 0.5f;
            const float ty = 16.0f;

            // Ombra cadente naturale
            g.setColour(juce::Colour(0x85000000));
            g.fillEllipse(tx + 2.0f, ty + 2.0f, toggleSize, toggleSize);

            // Diffusione morbida della luce solo se attivo (glow radiale sfumato)
            if (isUp) {
                juce::ColourGradient softGlow(themeColor.withAlpha(0.28f), tx + toggleSize * 0.5f, ty + toggleSize * 0.5f,
                                              themeColor.withAlpha(0.0f),  tx - 6.0f,               ty - 6.0f, true);
                g.setGradientFill(softGlow);
                g.fillEllipse(tx - 6.0f, ty - 6.0f, toggleSize + 12.0f, toggleSize + 12.0f);
            }

            g.drawImage(currentImg,
                        juce::roundToInt(tx), juce::roundToInt(ty),
                        juce::roundToInt(toggleSize), juce::roundToInt(toggleSize),
                        0, 0, currentImg.getWidth(), currentImg.getHeight());
        }

        // 3. Etichette di stato in basso: Down (sinistra) e Up (destra)
        g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        const int labelY = static_cast<int>(h - 15.0f);
        const int halfW  = static_cast<int>(w * 0.5f);

        // Etichetta DOWN / PRE / OFF (Sinistra)
        if (!isUp) {
            g.setColour(juce::Colour(0xffffe099).withAlpha(0.35f));
            g.drawText(offText, 0, labelY + 1, halfW - 4, 14, juce::Justification::centredRight, false);
            g.setColour(juce::Colour(0xffffe099));
            g.drawText(offText, 0, labelY, halfW - 4, 14, juce::Justification::centredRight, false);
        } else {
            g.setColour(juce::Colour(0x858c7c68));
            g.drawText(offText, 0, labelY, halfW - 4, 14, juce::Justification::centredRight, false);
        }

        // Etichetta UP / POST / ON (Destra)
        if (isUp) {
            g.setColour(themeColor.withAlpha(0.40f));
            g.drawText(onText, halfW + 4, labelY + 1, halfW - 4, 14, juce::Justification::centredLeft, false);
            g.setColour(themeColor.brighter(0.25f));
            g.drawText(onText, halfW + 4, labelY, halfW - 4, 14, juce::Justification::centredLeft, false);
        } else {
            g.setColour(juce::Colour(0x858c7c68));
            g.drawText(onText, halfW + 4, labelY, halfW - 4, 14, juce::Justification::centredLeft, false);
        }
    }

    juce::Slider& getSlider() noexcept { return slider; }

private:
    juce::Slider slider;
    juce::String switchTitle;
    juce::String offText;
    juce::String onText;
    juce::Colour themeColor;
    juce::Image imgUp;
    juce::Image imgDown;
};

} // namespace gui171
