#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_graphics/juce_graphics.h>
#include <cmath>

namespace plugin_171
{
    // ==============================================================================
    // LOOKANDFEEL COMPLETO PER FADER A CONSOLE BOUTIQUE SKEUOMORFICO (DUAL-MODE: VETTORIALE + BITMAP 3D)
    // ==============================================================================
    class BoutiqueFaderLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        BoutiqueFaderLookAndFeel()
        {
            setColour(juce::Slider::trackColourId, juce::Colours::transparentBlack);
            setColour(juce::Slider::thumbColourId, juce::Colours::transparentBlack);
        }

        void setCustomImages(const juce::Image& trackImg, const juce::Image& capImg)
        {
            trackImage = trackImg;
            capImage = capImg;
            useBitmapAssets = trackImage.isValid() && capImage.isValid();
        }

        void setUseBitmapAssets(bool shouldUse)
        {
            useBitmapAssets = shouldUse && trackImage.isValid() && capImage.isValid();
        }

        bool isUsingBitmapAssets() const noexcept { return useBitmapAssets; }

        void drawLinearSlider(juce::Graphics& g, int x, int y, int width, int height,
                              float sliderPos, float minSliderPos, float maxSliderPos,
                              const juce::Slider::SliderStyle style, juce::Slider& slider) override
        {
            if (slider.isBar())
            {
                juce::LookAndFeel_V4::drawLinearSlider(g, x, y, width, height, sliderPos, minSliderPos, maxSliderPos, style, slider);
                return;
            }

            const auto bounds = juce::Rectangle<float>((float)x, (float)y, (float)width, (float)height);

            if (useBitmapAssets && trackImage.isValid() && capImage.isValid())
            {
                const float cx = bounds.getCentreX();

                // 1. Disegna Track da Asset Fotografico 3D ad alta definizione
                const float trackAspect = (float)trackImage.getWidth() / (float)trackImage.getHeight();
                float trackH = bounds.getHeight() - 16.0f;
                float trackW = trackH * trackAspect;
                if (trackW > bounds.getWidth())
                {
                    trackW = bounds.getWidth();
                    trackH = trackW / trackAspect;
                }
                const float trackX = cx - trackW * 0.5f;
                const float trackY = bounds.getY() + (bounds.getHeight() - trackH) * 0.5f;
                auto trackRect = juce::Rectangle<float>(trackX, trackY, trackW, trackH);

                g.drawImage(trackImage, trackRect, juce::RectanglePlacement::centred);

                // 2. Disegna Cap da Asset Fotografico 3D con ombra proiettata
                const float capAspect = (float)capImage.getWidth() / (float)capImage.getHeight();
                float capW = juce::jmin(bounds.getWidth() * 0.85f, 68.0f);
                if (capW < 36.0f) capW = juce::jmin(bounds.getWidth() * 0.95f, 44.0f);
                const float capH = capW / capAspect;

                const float capX = cx - capW * 0.5f;
                const float capY = sliderPos - capH * 0.5f;
                auto capRect = juce::Rectangle<float>(capX, capY, capW, capH);

                // Ombra di contatto sotto il cap
                g.setColour(juce::Colours::black.withAlpha(0.60f));
                g.fillRoundedRectangle(capRect.translated(2.0f, 4.0f), 6.0f);

                g.drawImage(capImage, capRect, juce::RectanglePlacement::centred);
            }
            else
            {
                // 1. Disegna la Fader Track in ottone antico + scala graduata in decibel procedurale
                drawBoutiqueTrack(g, bounds, minSliderPos, maxSliderPos);

                // 2. Disegna il Fader Cap mobile con logo 171 inciso e LED ambra incandescente procedurale
                drawBoutiqueCap(g, bounds, sliderPos);
            }
        }

        void drawBoutiqueTrack(juce::Graphics& g, juce::Rectangle<float> bounds, float minPos, float maxPos)
        {
            const float cx = bounds.getCentreX();
            const float trackW = juce::jmin(bounds.getWidth() * 0.42f, 44.0f);
            const float trackH = bounds.getHeight() - 16.0f;
            const float trackX = cx - trackW * 0.5f;
            const float trackY = bounds.getY() + 8.0f;

            auto trackRect = juce::Rectangle<float>(trackX, trackY, trackW, trackH);

            // A. TELAIO ESTERNO IN OTTONE ANTICO CON SMUSSATURE A 45°
            const float chamfer = 8.0f;
            juce::Path framePath;
            framePath.startNewSubPath(trackRect.getX() + chamfer, trackRect.getY());
            framePath.lineTo(trackRect.getRight() - chamfer, trackRect.getY());
            framePath.lineTo(trackRect.getRight(), trackRect.getY() + chamfer);
            framePath.lineTo(trackRect.getRight(), trackRect.getBottom() - chamfer);
            framePath.lineTo(trackRect.getRight() - chamfer, trackRect.getBottom());
            framePath.lineTo(trackRect.getX() + chamfer, trackRect.getBottom());
            framePath.lineTo(trackRect.getX(), trackRect.getBottom() - chamfer);
            framePath.lineTo(trackRect.getX(), trackRect.getY() + chamfer);
            framePath.closeSubPath();

            // Ombra esterna del telaio fader
            g.setColour(juce::Colours::black.withAlpha(0.60f));
            juce::Path shadowPath = framePath;
            shadowPath.applyTransform(juce::AffineTransform::translation(1.5f, 2.5f));
            g.fillPath(shadowPath);

            // Gradiente ottone antico spazzolato
            juce::ColourGradient brassGrad(
                juce::Colour::fromString("ff967b4b"), trackRect.getX(), trackRect.getY(),
                juce::Colour::fromString("ff362915"), trackRect.getRight(), trackRect.getBottom(), false);
            brassGrad.addColour(0.35, juce::Colour::fromString("ffbfa26b"));
            brassGrad.addColour(0.70, juce::Colour::fromString("ff5c4623"));
            g.setGradientFill(brassGrad);
            g.fillPath(framePath);

            // Bordo metallico beveled dorato
            g.setColour(juce::Colour::fromString("ffd6b467"));
            g.strokePath(framePath, juce::PathStrokeType(1.4f));

            // B. FESSURA INTERNA SCAVATA (SLOT NERO PROFONDO)
            const float slotW = trackW * 0.40f;
            const float slotH = trackH - 24.0f;
            auto slotRect = juce::Rectangle<float>(cx - slotW * 0.5f, trackY + 12.0f, slotW, slotH);

            // Incasso interno nero profondo
            g.setColour(juce::Colour::fromString("ff0d0b09"));
            g.fillRoundedRectangle(slotRect, slotW * 0.5f);

            // Ombra interna marcata
            g.setColour(juce::Colours::black.withAlpha(0.75f));
            g.drawRoundedRectangle(slotRect, slotW * 0.5f, 2.0f);

            // Guida metallica interna del cursore
            g.setColour(juce::Colour::fromString("ff1f1a14"));
            g.drawLine(cx, slotRect.getY() + 4.0f, cx, slotRect.getBottom() - 4.0f, 1.5f);

            // C. SCALA GRADUATA IN DECIBEL SERIGRAFATA AI LATI
            const struct { float norm; const char* txt; bool isZero; } dBScale[] = {
                { 0.05f, "+10", false },
                { 0.15f, "+5",  false },
                { 0.28f, "0",   true  }, // Unity Gain (0 dB)
                { 0.40f, "-5",  false },
                { 0.52f, "-10", false },
                { 0.63f, "-15", false },
                { 0.73f, "-20", false },
                { 0.83f, "-30", false },
                { 0.91f, "-40", false },
                { 0.98f, "oo",  false }  // -inf dB
            };

            const float travelTop = slotRect.getY() + 6.0f;
            const float travelBot = slotRect.getBottom() - 6.0f;
            const float travelSpan = travelBot - travelTop;

            g.setFont(juce::Font("Arial", 8.0f, juce::Font::bold));

            for (const auto& pt : dBScale)
            {
                float sy = travelTop + pt.norm * travelSpan;
                float lineLen = pt.isZero ? 8.0f : 4.5f;

                // Tacca sinistra e destra
                juce::Colour tickCol = pt.isZero ? juce::Colour::fromString("ffffd166") : juce::Colour::fromString("ffc4a76c").withAlpha(0.75f);
                g.setColour(tickCol);
                g.drawLine(trackX - 2.0f - lineLen, sy, trackX - 2.0f, sy, pt.isZero ? 1.6f : 1.0f);
                g.drawLine(trackRect.getRight() + 2.0f, sy, trackRect.getRight() + 2.0f + lineLen, sy, pt.isZero ? 1.6f : 1.0f);

                // Testo decibel
                g.setColour(pt.isZero ? juce::Colour::fromString("ffffe6a3") : juce::Colour::fromString("ffa38c5b"));
                g.drawText(pt.txt, trackX - 28.0f, sy - 5.0f, 22.0f, 10.0f, juce::Justification::right, false);
                g.drawText(pt.txt, trackRect.getRight() + 6.0f, sy - 5.0f, 22.0f, 10.0f, juce::Justification::left, false);
            }
        }

        void drawBoutiqueCap(juce::Graphics& g, juce::Rectangle<float> bounds, float sliderPos)
        {
            const float cx = bounds.getCentreX();
            const float capW = juce::jmin(bounds.getWidth() * 0.72f, 68.0f);
            const float capH = capW * 1.80f; // Rapporto proporzionale classico 1:1.8

            const float capX = cx - capW * 0.5f;
            const float capY = sliderPos - capH * 0.5f;
            auto capRect = juce::Rectangle<float>(capX, capY, capW, capH);

            // 1. OMBRA DI CONTATTO PORTATA SULLA TRACK E SUL PANNELLO
            g.setColour(juce::Colours::black.withAlpha(0.65f));
            g.fillRoundedRectangle(capRect.translated(2.0f, 4.0f), 6.0f);

            // 2. CORPO PRINCIPALE IN METALLO CANNA DI FUCILE SPAZZOLATO
            juce::ColourGradient capGrad(
                juce::Colour::fromString("ff47433f"), capRect.getX(), capRect.getY(),
                juce::Colour::fromString("ff1c1a18"), capRect.getRight(), capRect.getBottom(), false);
            capGrad.addColour(0.30, juce::Colour::fromString("ff36322e"));
            capGrad.addColour(0.70, juce::Colour::fromString("ff262320"));
            g.setGradientFill(capGrad);
            g.fillRoundedRectangle(capRect, 6.0f);

            // Bevel e bordo metallico
            g.setColour(juce::Colour::fromString("ff8f8476").withAlpha(0.70f));
            g.drawRoundedRectangle(capRect, 6.0f, 1.2f);
            g.setColour(juce::Colour::fromString("fffff3cc").withAlpha(0.35f));
            g.drawLine(capRect.getX() + 4.0f, capRect.getY() + 1.0f, capRect.getRight() - 4.0f, capRect.getY() + 1.0f, 1.0f);

            // 3. TEXTURE ZIGRINATA PIRAMIDALE (PYRAMID KNURLING) IN ALTO E IN BASSO
            auto drawKnurlZone = [&](float topY, float hKnurl)
            {
                juce::Rectangle<float> kRect(capRect.getX() + 3.0f, topY, capRect.getWidth() - 6.0f, hKnurl);
                g.setColour(juce::Colour::fromString("ff151311"));
                g.fillRect(kRect);

                const int rows = 4, cols = 8;
                float dx = kRect.getWidth() / (float)cols;
                float dy = kRect.getHeight() / (float)rows;

                for (int r = 0; r < rows; ++r)
                {
                    for (int c = 0; c < cols; ++c)
                    {
                        float px = kRect.getX() + (float)c * dx + dx * 0.5f;
                        float py = kRect.getY() + (float)r * dy + dy * 0.5f;
                        g.setColour(juce::Colour::fromString("ff6b6256"));
                        g.fillEllipse(px - 1.2f, py - 1.2f, 2.4f, 2.4f);
                        g.setColour(juce::Colour::fromString("ff0e0d0c"));
                        g.fillEllipse(px - 0.6f, py + 0.6f, 1.4f, 1.4f);
                    }
                }
            };

            const float knurlH = capH * 0.16f;
            drawKnurlZone(capRect.getY() + 3.0f, knurlH);
            drawKnurlZone(capRect.getBottom() - knurlH - 3.0f, knurlH);

            // 4. STEMMA/LOGO WIREFRAME "171" INCISO IN ORO AL CENTRO
            const float logoSize = capW * 0.55f;
            const float logoY = capRect.getCentreY() - logoSize * 0.5f;

            // Incisione scura del logo
            g.setColour(juce::Colour::fromString("ffd6b467").withAlpha(0.85f));
            g.setFont(juce::Font("Arial", logoSize * 0.65f, juce::Font::bold));
            g.drawText("171", cx - logoSize * 0.5f, logoY, logoSize, logoSize, juce::Justification::centred, false);

            // 5. FESSURA ORIZZONTALE CON LED AMBRA INCANDESCENTE (#ffa024)
            const float ledW = capW - 8.0f;
            const float ledH = 3.2f;
            const float ledY = sliderPos - ledH * 0.5f;
            auto ledRect = juce::Rectangle<float>(cx - ledW * 0.5f, ledY, ledW, ledH);

            // Alone neon arancione diffuso
            juce::ColourGradient ledGlow(
                juce::Colour::fromString("ffff8c12").withAlpha(0.70f), cx, sliderPos,
                juce::Colour::fromString("ffff3b00").withAlpha(0.0f), cx, sliderPos + 12.0f, true);
            g.setGradientFill(ledGlow);
            g.fillEllipse(cx - ledW * 0.6f, sliderPos - 8.0f, ledW * 1.2f, 16.0f);

            // Fessura centrale a LED brillante
            juce::ColourGradient ledCore(
                juce::Colour::fromString("fffff7d6"), cx, sliderPos,
                juce::Colour::fromString("ffff9d1e"), cx, sliderPos + 2.0f, false);
            g.setGradientFill(ledCore);
            g.fillRoundedRectangle(ledRect, ledH * 0.5f);

            // Bordo luce incandescente
            g.setColour(juce::Colours::white);
            g.drawLine(ledRect.getX() + 2.0f, sliderPos, ledRect.getRight() - 2.0f, sliderPos, 1.0f);
        }

    private:
        juce::Image trackImage;
        juce::Image capImage;
        bool useBitmapAssets = false;
    };


    // ==============================================================================
    // COMPONENTE FADER COMPLETO PRONTO ALL'USO ("BoutiqueFaderSlider")
    // ==============================================================================
    class BoutiqueFaderSlider : public juce::Slider
    {
    public:
        BoutiqueFaderSlider()
        {
            setSliderStyle(juce::Slider::LinearVertical);
            setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
            setLookAndFeel(&faderLaf);

            // Range standard audio da -60.0 dB a +10.0 dB con 0 dB Unity al centro/alto
            setRange(-60.0, 10.0, 0.1);
            setValue(0.0);
            setSkewForCentre(0.0); // Risposta naturale con risoluzione fine attorno a 0 dB
        }

        ~BoutiqueFaderSlider() override
        {
            setLookAndFeel(nullptr);
        }

        /**
         * @brief Carica gli asset bitmap opzionali per un rendering fotografico 3D ultra-realistico.
         */
        void loadImages(const juce::Image& trackImg, const juce::Image& capImg)
        {
            faderLaf.setCustomImages(trackImg, capImg);
            repaint();
        }

        /**
         * @brief Attiva o disattiva il rendering da asset bitmap (se caricati) o vettoriale.
         */
        void setUseBitmap(bool useBitmap)
        {
            faderLaf.setUseBitmapAssets(useBitmap);
            repaint();
        }

    private:
        BoutiqueFaderLookAndFeel faderLaf;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(BoutiqueFaderSlider)
    };
}
