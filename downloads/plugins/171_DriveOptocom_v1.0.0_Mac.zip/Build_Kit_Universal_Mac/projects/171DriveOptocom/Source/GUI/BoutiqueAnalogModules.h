#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_graphics/juce_graphics.h>
#include <cmath>
#include <vector>

namespace plugin_171
{
    // ==============================================================================
    // 1. DISPLAY CURVA DI TRASFERIMENTO DINAMICA ("TransferCurveDisplay")
    // ==============================================================================
    class TransferCurveDisplay : public juce::Component
    {
    public:
        TransferCurveDisplay()
        {
            setOpaque(false);
        }

        /**
         * @brief Imposta i parametri di dinamica/saturazione per la visualizzazione real-time.
         * @param thresholdDb Soglia di compressione (-40.0 dB a 0.0 dB).
         * @param ratio Rapporto di compressione (1.0 = lineare, fino a 20.0 = limiter).
         * @param kneeDb Larghezza del ginocchio soft-knee in dB (0.0 a 20.0 dB).
         * @param currentGainReductionDb Attuale riduzione di guadagno istantanea (es. -4.5 dB).
         */
        void setCompressionParameters(float thresholdDb, float ratio, float kneeDb, float currentGainReductionDb)
        {
            thresh = juce::jlimit(-40.0f, 0.0f, thresholdDb);
            rat    = juce::jmax(1.0f, ratio);
            knee   = juce::jmax(0.1f, kneeDb);
            grDb   = juce::jmin(0.0f, currentGainReductionDb);
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float w  = bounds.getWidth();
            const float h  = bounds.getHeight();

            // --------------------------------------------------------------------------
            // 1. CORNICE ESTERNA CON ANGOLI A 45° IN OTTONE BRUNITO + 4 VITI TORX
            // --------------------------------------------------------------------------
            const float chamfer = 14.0f;
            juce::Path outerFrame;
            outerFrame.startNewSubPath(bounds.getX() + chamfer, bounds.getY());
            outerFrame.lineTo(bounds.getRight() - chamfer, bounds.getY());
            outerFrame.lineTo(bounds.getRight(), bounds.getY() + chamfer);
            outerFrame.lineTo(bounds.getRight(), bounds.getBottom() - chamfer);
            outerFrame.lineTo(bounds.getRight() - chamfer, bounds.getBottom());
            outerFrame.lineTo(bounds.getX() + chamfer, bounds.getBottom());
            outerFrame.lineTo(bounds.getX(), bounds.getBottom() - chamfer);
            outerFrame.lineTo(bounds.getX(), bounds.getY() + chamfer);
            outerFrame.closeSubPath();

            // Ombra esterna telaio
            g.setColour(juce::Colours::black.withAlpha(0.65f));
            juce::Path shadowFrame = outerFrame;
            shadowFrame.applyTransform(juce::AffineTransform::translation(1.5f, 2.5f));
            g.fillPath(shadowFrame);

            // Gradiente ottone brunito spazzolato
            juce::ColourGradient brassGrad(
                juce::Colour::fromString("ff7a633d"), bounds.getX(), bounds.getY(),
                juce::Colour::fromString("ff291f13"), bounds.getRight(), bounds.getBottom(), false);
            brassGrad.addColour(0.35, juce::Colour::fromString("ffa3834e"));
            brassGrad.addColour(0.70, juce::Colour::fromString("ff42331c"));
            g.setGradientFill(brassGrad);
            g.fillPath(outerFrame);

            // Bordo interno dorato in rilievo
            g.setColour(juce::Colour::fromString("ffd6b467"));
            g.strokePath(outerFrame, juce::PathStrokeType(1.6f));
            g.setColour(juce::Colour::fromString("ff1f170e"));
            g.strokePath(outerFrame, juce::PathStrokeType(0.8f));

            // 4 Viti Torx a stella a sei punte agli angoli
            const float screwOffset = 13.0f;
            const struct { float x, y; } torxScrews[] = {
                { bounds.getX() + screwOffset,     bounds.getY() + screwOffset },
                { bounds.getRight() - screwOffset, bounds.getY() + screwOffset },
                { bounds.getX() + screwOffset,     bounds.getBottom() - screwOffset },
                { bounds.getRight() - screwOffset, bounds.getBottom() - screwOffset }
            };

            for (const auto& ts : torxScrews)
            {
                // Svasatura scura
                g.setColour(juce::Colour::fromString("ff120d08"));
                g.fillEllipse(ts.x - 3.8f, ts.y - 3.8f, 7.6f, 7.6f);

                // Testa metallica
                juce::ColourGradient torxGrad(
                    juce::Colour::fromString("ffc2a261"), ts.x - 3.0f, ts.y - 3.0f,
                    juce::Colour::fromString("ff382813"), ts.x + 3.0f, ts.y + 3.0f, false);
                g.setGradientFill(torxGrad);
                g.fillEllipse(ts.x - 2.8f, ts.y - 2.8f, 5.6f, 5.6f);

                // Impronta Torx a stella a 6 punte
                juce::Path star;
                for (int p = 0; p < 12; ++p)
                {
                    float a = (float)p * juce::MathConstants<float>::pi / 6.0f;
                    float rStar = (p % 2 == 0) ? 1.8f : 0.9f;
                    float px = ts.x + std::cos(a) * rStar;
                    float py = ts.y + std::sin(a) * rStar;
                    if (p == 0) star.startNewSubPath(px, py);
                    else        star.lineTo(px, py);
                }
                star.closeSubPath();
                g.setColour(juce::Colour::fromString("ff0d0a06"));
                g.fillPath(star);
            }

            // --------------------------------------------------------------------------
            // 2. SCHERMO INTERNO SCURO, TEXTURE RADIALE & GRIGLIA CARTESIANA (-40 dB .. 0 dB)
            // --------------------------------------------------------------------------
            const float screenInset = 20.0f;
            auto screenRect = bounds.reduced(screenInset);

            // Sfondo scuro incassato (#121110)
            g.setColour(juce::Colour::fromString("ff121110"));
            g.fillRoundedRectangle(screenRect, 3.0f);

            // Micro-texture metallica radiale sottile
            const auto screenCenter = screenRect.getCentre();
            for (float r = 10.0f; r < screenRect.getWidth(); r += 6.0f)
            {
                g.setColour(juce::Colour::fromString("ffd6b467").withAlpha(0.015f));
                g.drawEllipse(screenCenter.x - r, screenCenter.y - r, r * 2.0f, r * 2.0f, 0.6f);
            }

            // Ombra interna profonda
            g.setColour(juce::Colours::black.withAlpha(0.70f));
            g.drawRoundedRectangle(screenRect, 3.0f, 2.5f);

            // Griglia cartesiana dorata semitrasparente (-40, -30, -20, -10, 0 dB)
            auto mapDbToX = [&](float db) -> float {
                return screenRect.getX() + ((db + 40.0f) / 40.0f) * screenRect.getWidth();
            };
            auto mapDbToY = [&](float db) -> float {
                return screenRect.getBottom() - ((db + 40.0f) / 40.0f) * screenRect.getHeight();
            };

            const float gridSteps[] = { -40.0f, -30.0f, -20.0f, -10.0f, 0.0f };
            g.setFont(juce::Font("Arial", 8.0f, juce::Font::plain));

            for (float db : gridSteps)
            {
                float gx = mapDbToX(db);
                float gy = mapDbToY(db);

                // Linee verticali e orizzontali
                g.setColour(juce::Colour::fromString("ffd6b467").withAlpha(0.12f));
                g.drawVerticalLine((int)gx, screenRect.getY(), screenRect.getBottom());
                g.drawHorizontalLine((int)gy, screenRect.getX(), screenRect.getRight());

                // Etichette decibel
                if (db > -40.0f && db < 0.0f)
                {
                    g.setColour(juce::Colour::fromString("ff9e875f").withAlpha(0.55f));
                    g.drawText(juce::String((int)db), gx - 14.0f, screenRect.getBottom() - 11.0f, 28.0f, 9.0f, juce::Justification::centred);
                    g.drawText(juce::String((int)db), screenRect.getX() + 2.0f, gy - 5.0f, 24.0f, 9.0f, juce::Justification::left);
                }
            }

            // Linea tratteggiata per la Threshold (THR)
            float thrX = mapDbToX(thresh);
            float thrY = mapDbToY(thresh);
            const float dashPattern[2] = { 3.0f, 3.0f };
            g.setColour(juce::Colour::fromString("ffffa834").withAlpha(0.40f));
            g.drawDashedLine(juce::Line<float>(thrX, screenRect.getY(), thrX, screenRect.getBottom()), dashPattern, 2, 1.0f);
            g.drawDashedLine(juce::Line<float>(screenRect.getX(), thrY, screenRect.getRight(), thrY), dashPattern, 2, 1.0f);

            // Annotazioni HUD in alto e in basso: RAT, KNE, THR, GR
            g.setFont(juce::Font("Arial", 8.5f, juce::Font::bold));
            g.setColour(juce::Colour::fromString("ffdeb868").withAlpha(0.85f));
            g.drawText("THR: " + juce::String(thresh, 1) + " dB", screenRect.getX() + 8.0f, screenRect.getY() + 4.0f, 80.0f, 10.0f, juce::Justification::left);
            g.drawText("RAT: " + (rat > 19.5f ? "INF:1" : juce::String(rat, 1) + ":1"), screenRect.getX() + 85.0f, screenRect.getY() + 4.0f, 60.0f, 10.0f, juce::Justification::left);
            g.drawText("KNE: " + juce::String(knee, 1) + " dB", screenRect.getRight() - 120.0f, screenRect.getY() + 4.0f, 55.0f, 10.0f, juce::Justification::right);

            // Gain Reduction meter HUD in rosso-arancio
            g.setColour(juce::Colour::fromString("ffff5226"));
            g.drawText("GR: " + juce::String(grDb, 1) + " dB", screenRect.getRight() - 65.0f, screenRect.getY() + 4.0f, 58.0f, 10.0f, juce::Justification::right);

            // --------------------------------------------------------------------------
            // 3. LINEA 1:1 DI RIFERIMENTO E CURVA SOFT-KNEE ANALITICA
            // --------------------------------------------------------------------------
            // Diagonale 1:1 di riferimento (non compressa)
            g.setColour(juce::Colour::fromString("ff544733").withAlpha(0.45f));
            g.drawLine(screenRect.getX(), screenRect.getBottom(), screenRect.getRight(), screenRect.getY(), 1.0f);

            // Calcolo curva di compressione analitica
            juce::Path curvePath;
            const int steps = 120;
            const float halfKnee = knee * 0.5f;

            for (int i = 0; i <= steps; ++i)
            {
                float inDb = -40.0f + ((float)i / (float)steps) * 40.0f;
                float outDb = inDb;

                if (inDb <= thresh - halfKnee)
                {
                    outDb = inDb; // Sotto il knee: guadagno unitario 1:1
                }
                else if (inDb >= thresh + halfKnee)
                {
                    outDb = thresh + (inDb - thresh) / rat; // Sopra il knee: compressione lineare
                }
                else
                {
                    // Transizione soft-knee quadratica continua C1
                    float delta = inDb - thresh + halfKnee;
                    outDb = inDb + ((1.0f / rat - 1.0f) * delta * delta) / (2.0f * knee);
                }

                float px = mapDbToX(inDb);
                float py = mapDbToY(outDb);

                if (i == 0) curvePath.startNewSubPath(px, py);
                else        curvePath.lineTo(px, py);
            }

            // --------------------------------------------------------------------------
            // 4. EFFETTO PLASMA/BAGLIORE INCANDESCENTE (3 PASSATE DI STROKE DECRESCENTI)
            // --------------------------------------------------------------------------
            // Passata 1: Bagliore arancione diffuso con trasparenza
            g.setColour(juce::Colour::fromString("ffcc4a00").withAlpha(0.45f));
            g.strokePath(curvePath, juce::PathStrokeType(6.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Passata 2: Ambra caldo
            g.setColour(juce::Colour::fromString("ffff9e24").withAlpha(0.85f));
            g.strokePath(curvePath, juce::PathStrokeType(3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Passata 3: Nucleo giallo-bianco incandescente brillante (#fff3a1)
            g.setColour(juce::Colour::fromString("fffff3a1"));
            g.strokePath(curvePath, juce::PathStrokeType(1.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Punto di lavoro dinamico corrente (indicatore Gain Reduction)
            if (grDb < -0.1f)
            {
                // Mappiamo il punto di riduzione corrente sulla curva
                float operatingInDb = thresh - grDb * (rat / (rat - 1.0f + 1e-5f));
                operatingInDb = juce::jlimit(-40.0f, 0.0f, operatingInDb);
                float operatingOutDb = operatingInDb + grDb;

                float opX = mapDbToX(operatingInDb);
                float opY = mapDbToY(operatingOutDb);

                // Alone del punto operativo
                g.setColour(juce::Colour::fromString("ffff3b00").withAlpha(0.6f));
                g.fillEllipse(opX - 6.0f, opY - 6.0f, 12.0f, 12.0f);
                g.setColour(juce::Colour::fromString("fffff5c2"));
                g.fillEllipse(opX - 2.5f, opY - 2.5f, 5.0f, 5.0f);
            }

            // --------------------------------------------------------------------------
            // 5. RIFLESSO DIAGONALE IN VETRO SEMITRASPARENTE
            // --------------------------------------------------------------------------
            juce::Path glassReflection;
            glassReflection.startNewSubPath(screenRect.getX(), screenRect.getBottom());
            glassReflection.lineTo(screenRect.getX() + screenRect.getWidth() * 0.45f, screenRect.getBottom());
            glassReflection.lineTo(screenRect.getRight(), screenRect.getY() + screenRect.getHeight() * 0.20f);
            glassReflection.lineTo(screenRect.getRight(), screenRect.getY());
            glassReflection.lineTo(screenRect.getX() + screenRect.getWidth() * 0.35f, screenRect.getY());
            glassReflection.closeSubPath();

            juce::ColourGradient glassGrad(
                juce::Colours::white.withAlpha(0.09f), screenRect.getX(), screenRect.getY(),
                juce::Colours::white.withAlpha(0.01f), screenRect.getRight(), screenRect.getBottom(), false);
            g.setGradientFill(glassGrad);
            g.fillPath(glassReflection);
        }

    private:
        float thresh = -18.0f;
        float rat    = 4.0f;
        float knee   = 6.0f;
        float grDb   = 0.0f;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TransferCurveDisplay)
    };


    // ==============================================================================
    // 2. MANOPOLA PIATTA IN OTTONE BRUNITO CON CORONA ZIGRINATA ("FlatBrassKnobLookAndFeel")
    // ==============================================================================
    class FlatBrassKnobLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        FlatBrassKnobLookAndFeel() {}

        void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                              float sliderPosProportional, float rotaryStartAngle, float rotaryEndAngle,
                              juce::Slider& slider) override
        {
            const auto bounds = juce::Rectangle<float>((float)x, (float)y, (float)width, (float)height);
            const float size  = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx    = bounds.getCentreX();
            const float cy    = bounds.getCentreY();
            const float rBase = size * 0.45f;
            const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

            // --------------------------------------------------------------------------
            // 1. SCORRIMENTO DI 11 MICRO-RIVETTI DORATI DISPOSTI AD ARCO SUL PANNELLO
            // --------------------------------------------------------------------------
            const float rivetTrackR = rBase * 1.08f;
            const int numRivets = 11;
            for (int i = 0; i < numRivets; ++i)
            {
                float normA = (float)i / (float)(numRivets - 1);
                float a = rotaryStartAngle + normA * (rotaryEndAngle - rotaryStartAngle) - juce::MathConstants<float>::halfPi;
                float rx = cx + std::cos(a) * rivetTrackR;
                float ry = cy + std::sin(a) * rivetTrackR;

                // Ombra rivetto
                g.setColour(juce::Colour::fromString("ff14100b"));
                g.fillEllipse(rx - 1.8f, ry - 1.8f + 1.0f, 3.6f, 3.6f);

                // Testa dorata bombata
                juce::ColourGradient rivetGrad(
                    juce::Colour::fromString("ffd6b467"), rx - 1.2f, ry - 1.2f,
                    juce::Colour::fromString("ff423214"), rx + 1.2f, ry + 1.2f, false);
                g.setGradientFill(rivetGrad);
                g.fillEllipse(rx - 1.4f, ry - 1.4f, 2.8f, 2.8f);

                // Highlight superiore 1px
                g.setColour(juce::Colour::fromString("fffff3ba").withAlpha(0.7f));
                g.fillEllipse(rx - 0.7f, ry - 0.9f, 1.4f, 1.0f);
            }

            // Ombra portata fissa della manopola verso il basso-destra (luce fissa a 105°)
            g.setColour(juce::Colours::black.withAlpha(0.68f));
            g.fillEllipse(cx - rBase + 2.0f, cy - rBase + 4.5f, rBase * 2.0f, rBase * 2.0f);

            // --------------------------------------------------------------------------
            // 2. CORONA ESTERNA SOTTILE FINEMENTE DENTELLATA (Knurled Ring in Oro/Ottone)
            // --------------------------------------------------------------------------
            const int numTeeth = 48;
            const float rKnurlOut = rBase;
            const float rKnurlIn  = rBase * 0.92f;

            juce::Path knurledRing;
            for (int i = 0; i < numTeeth; ++i)
            {
                float a1 = angle + (float)i * juce::MathConstants<float>::twoPi / (float)numTeeth;
                float a2 = a1 + (juce::MathConstants<float>::twoPi / (float)numTeeth) * 0.5f;

                float x1 = cx + std::cos(a1) * rKnurlOut;
                float y1 = cy + std::sin(a1) * rKnurlOut;
                float x2 = cx + std::cos(a2) * rKnurlIn;
                float y2 = cy + std::sin(a2) * rKnurlIn;

                if (i == 0) knurledRing.startNewSubPath(x1, y1);
                else        knurledRing.lineTo(x1, y1);
                knurledRing.lineTo(x2, y2);
            }
            knurledRing.closeSubPath();

            juce::ColourGradient knurlGrad(
                juce::Colour::fromString("ffdeb868"), cx - rBase, cy - rBase,
                juce::Colour::fromString("ff4a371c"), cx + rBase, cy + rBase, false);
            g.setGradientFill(knurlGrad);
            g.fillPath(knurledRing);

            // Bordo luce dentellatura
            g.setColour(juce::Colour::fromString("fffff5c2").withAlpha(0.40f));
            g.strokePath(knurledRing, juce::PathStrokeType(0.6f));

            // Anello interno di raccordo scuro
            const float rFace = rKnurlIn * 0.98f;
            g.setColour(juce::Colour::fromString("ff120e0a"));
            g.fillEllipse(cx - rFace, cy - rFace, rFace * 2.0f, rFace * 2.0f);

            // --------------------------------------------------------------------------
            // 3. FACCIA SUPERIORE PIATTA CON GRADIENTE CONICO/ANISOTROPICO
            // --------------------------------------------------------------------------
            // Simuliamo il riflesso conico a doppio raggio tipico dell'ottone tornito
            juce::ColourGradient conicalGrad(
                juce::Colour::fromString("ff8c6230"), cx, cy - rFace,
                juce::Colour::fromString("ff261e16"), cx, cy + rFace, false);
            conicalGrad.addColour(0.20, juce::Colour::fromString("ff3d2e1e"));
            conicalGrad.addColour(0.45, juce::Colour::fromString("ffa87b3f"));
            conicalGrad.addColour(0.70, juce::Colour::fromString("ff211811"));
            conicalGrad.addColour(0.85, juce::Colour::fromString("ff705128"));
            g.setGradientFill(conicalGrad);
            g.fillEllipse(cx - rFace, cy - rFace, rFace * 2.0f, rFace * 2.0f);

            // Micro-spazzolatura concentrica circolare (anelli sottilissimi)
            for (float cr = 10.0f; cr < rFace; cr += 2.8f)
            {
                float a = (std::fmod(cr, 5.6f) < 2.8f) ? 0.05f : 0.02f;
                g.setColour(juce::Colours::white.withAlpha(a));
                g.drawEllipse(cx - cr, cy - cr, cr * 2.0f, cr * 2.0f, 0.6f);
                g.setColour(juce::Colours::black.withAlpha(a * 1.5f));
                g.drawEllipse(cx - cr - 0.4f, cy - cr - 0.4f, (cr + 0.4f) * 2.0f, (cr + 0.4f) * 2.0f, 0.5f);
            }

            // Filetto dorato interno
            g.setColour(juce::Colour::fromString("ffd6b467"));
            g.drawEllipse(cx - rFace + 1.0f, cy - rFace + 1.0f, (rFace - 1.0f) * 2.0f, (rFace - 1.0f) * 2.0f, 1.2f);

            // --------------------------------------------------------------------------
            // 4. TACCA INDICATRICE METALLICA IN RILIEVO (RUOTA CON LA MANOPOLA)
            // --------------------------------------------------------------------------
            const float notchLen = rFace * 0.36f;
            const float notchW   = 2.8f;
            const float notchOuterR = rFace - 1.0f;
            const float notchInnerR = notchOuterR - notchLen;

            juce::Path notchPath;
            notchPath.startNewSubPath(-notchW * 0.5f, -notchOuterR);
            notchPath.lineTo(notchW * 0.5f, -notchOuterR);
            notchPath.lineTo(notchW * 0.5f, -notchInnerR);
            notchPath.lineTo(-notchW * 0.5f, -notchInnerR);
            notchPath.closeSubPath();

            juce::Path transformedNotch = notchPath;
            transformedNotch.applyTransform(juce::AffineTransform::rotation(angle).translated(cx, cy));

            // Ombra di rilievo della tacca
            juce::Path notchShadow = transformedNotch;
            notchShadow.applyTransform(juce::AffineTransform::translation(1.0f, 1.5f));
            g.setColour(juce::Colours::black.withAlpha(0.60f));
            g.fillPath(notchShadow);

            // Tacca metallica dorata lucida in rilievo
            juce::ColourGradient notchGrad(
                juce::Colour::fromString("fffff2b0"), cx, cy - rFace,
                juce::Colour::fromString("ff785623"), cx, cy, false);
            g.setGradientFill(notchGrad);
            g.fillPath(transformedNotch);

            g.setColour(juce::Colour::fromString("ffffffff").withAlpha(0.65f));
            g.strokePath(transformedNotch, juce::PathStrokeType(0.6f));

            // --------------------------------------------------------------------------
            // 5. LOGO GEOMETRICO "171" INCISO AL CENTRO (RESTA FISSO, NON RUOTA)
            // --------------------------------------------------------------------------
            const float rCenterBadge = rFace * 0.40f;

            // Inserto centrale concavo scuro per il logo
            juce::ColourGradient badgeGrad(
                juce::Colour::fromString("ff1a140e"), cx, cy - rCenterBadge,
                juce::Colour::fromString("ff2e241a"), cx, cy + rCenterBadge, false);
            g.setGradientFill(badgeGrad);
            g.fillEllipse(cx - rCenterBadge, cy - rCenterBadge, rCenterBadge * 2.0f, rCenterBadge * 2.0f);

            // Profilo dorato dell'inserto centrale
            g.setColour(juce::Colour::fromString("ffd6b467").withAlpha(0.75f));
            g.drawEllipse(cx - rCenterBadge, cy - rCenterBadge, rCenterBadge * 2.0f, rCenterBadge * 2.0f, 1.0f);

            // Logo monogramma "171" fisso orizzontale
            auto logoRect = juce::Rectangle<float>(cx - rCenterBadge, cy - rCenterBadge, rCenterBadge * 2.0f, rCenterBadge * 2.0f);

            // Incisione interna: ombra superiore scura + highlight dorato inferiore
            g.setColour(juce::Colour::fromString("ff0d0a06"));
            g.setFont(juce::Font("Arial", rCenterBadge * 0.72f, juce::Font::bold));
            g.drawText("171", logoRect.translated(0.0f, -0.8f), juce::Justification::centred, false);

            g.setColour(juce::Colour::fromString("ffd6b467").withAlpha(0.90f));
            g.drawText("171", logoRect, juce::Justification::centred, false);
        }
    };


    // ==============================================================================
    // 3. MODULO TOGGLE SWITCH E PULSANTI QUADRATI ("VintageToggleAndButtonCluster")
    // ==============================================================================
    class VintageToggleAndButtonCluster : public juce::Component
    {
    public:
        VintageToggleAndButtonCluster()
        {
            setOpaque(false);
            
            // Configurazione pulsanti interni
            addAndMakeVisible(toggleSwitch);
            addAndMakeVisible(button1);
            addAndMakeVisible(button2);

            button1.setButtonText("SC");     // Sidechain
            button2.setButtonText("OPTO");   // Opto Mode
        }

        juce::ToggleButton& getToggle()   { return toggleSwitch; }
        juce::ToggleButton& getButton1()  { return button1; }
        juce::ToggleButton& getButton2()  { return button2; }

        void resized() override
        {
            auto area = getLocalBounds().reduced(8);
            const int itemW = area.getWidth() / 3;

            toggleSwitch.setBounds(area.getX(), area.getY(), itemW, area.getHeight());
            button1.setBounds(area.getX() + itemW, area.getY() + 4, itemW - 6, area.getHeight() - 8);
            button2.setBounds(area.getX() + itemW * 2 + 2, area.getY() + 4, itemW - 6, area.getHeight() - 8);
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();

            // Placca di montaggio comune in ottone spazzolato
            g.setColour(juce::Colours::black.withAlpha(0.55f));
            g.fillRoundedRectangle(bounds.translated(1.5f, 2.0f), 4.0f);

            juce::ColourGradient plateGrad(
                juce::Colour::fromString("ff3a3024"), bounds.getX(), bounds.getY(),
                juce::Colour::fromString("ff1f1912"), bounds.getRight(), bounds.getBottom(), false);
            g.setGradientFill(plateGrad);
            g.fillRoundedRectangle(bounds, 4.0f);

            // Bordo filetto dorato
            g.setColour(juce::Colour::fromString("ffd6b467"));
            g.drawRoundedRectangle(bounds.reduced(1.0f), 4.0f, 1.0f);

            // 4 Micro-viti agli angoli
            const float sPad = 6.0f;
            for (float sx : { bounds.getX() + sPad, bounds.getRight() - sPad })
            {
                for (float sy : { bounds.getY() + sPad, bounds.getBottom() - sPad })
                {
                    g.setColour(juce::Colour::fromString("ff14100c"));
                    g.fillEllipse(sx - 2.0f, sy - 2.0f, 4.0f, 4.0f);
                    g.setColour(juce::Colour::fromString("ffd1b066"));
                    g.fillEllipse(sx - 1.4f, sy - 1.4f, 2.8f, 2.8f);
                    g.setColour(juce::Colour::fromString("ff26190a"));
                    g.drawLine(sx - 1.0f, sy, sx + 1.0f, sy, 0.8f);
                }
            }
        }

    private:
        juce::ToggleButton toggleSwitch;
        juce::ToggleButton button1;
        juce::ToggleButton button2;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VintageToggleAndButtonCluster)
    };
}
