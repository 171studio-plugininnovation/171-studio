#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <algorithm>
#include <cmath>

namespace gui171 {

class PhotorealisticNeonKnobLookAndFeel : public juce::LookAndFeel_V4 {
public:
    PhotorealisticNeonKnobLookAndFeel(juce::Colour neonCol, juce::Image knobCapImg, juce::Image scalePlateImg = {}, float capScaleRatio = 0.72f)
        : neonColor(neonCol), knobCap(knobCapImg), scalePlate(scalePlateImg), knobScale(capScaleRatio) {}

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPosProportional, float rotaryStartAngle,
                          float rotaryEndAngle, juce::Slider&) override
    {
        const float size = static_cast<float>(juce::jmin(width, height));
        const float centreX = static_cast<float>(x) + static_cast<float>(width) * 0.5f;
        const float centreY = static_cast<float>(y) + static_cast<float>(height) * 0.5f;
        const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

        const float radius = size * 0.5f - 4.0f;
        const float arcRadius = radius - 3.0f;
        const float capRadius = radius * knobScale;

        // 1. Disegna la ghiera / quadrante graduato statico (Scale Plate / Ring)
        if (scalePlate.isValid()) {
            const float plateW = static_cast<float>(scalePlate.getWidth());
            const float plateH = static_cast<float>(scalePlate.getHeight());
            const float plateScale = (radius * 2.05f) / plateW;

            auto plateXform = juce::AffineTransform::translation(-plateW * 0.5f, -plateH * 0.5f)
                                  .scaled(plateScale)
                                  .translated(centreX, centreY);
            g.drawImageTransformed(scalePlate, plateXform);
        } else {
            // Sfondo tacche procedurali se non c'è immagine di piastra
            const int numTicks = 11;
            for (int i = 0; i < numTicks; ++i) {
                float normT = (float)i / (float)(numTicks - 1);
                float tickAngle = rotaryStartAngle + normT * (rotaryEndAngle - rotaryStartAngle);
                float rInner = radius - 2.0f;
                float rOuter = radius + 2.0f;
                float tx1 = centreX + rInner * std::sin(tickAngle);
                float ty1 = centreY - rInner * std::cos(tickAngle);
                float tx2 = centreX + rOuter * std::sin(tickAngle);
                float ty2 = centreY - rOuter * std::cos(tickAngle);

                bool isMajor = (i == 0 || i == 5 || i == 10);
                g.setColour(isMajor ? juce::Colour(0xffc59c52) : juce::Colour(0x608c7042));
                g.drawLine(tx1, ty1, tx2, ty2, isMajor ? 1.6f : 1.0f);
            }
        }

        // 2. Ombra portata naturale del pomello metallico orientata a ore 4
        g.setColour(juce::Colour(0x7a000000));
        g.fillEllipse(centreX - capRadius + 1.5f, centreY - capRadius + 3.0f, capRadius * 2.0f, capRadius * 2.0f);

        // 3. Pomello fotorealistico con rotazione concentrica nel suo colore naturale puro
        if (knobCap.isValid()) {
            const float imgW = static_cast<float>(knobCap.getWidth());
            const float imgH = static_cast<float>(knobCap.getHeight());
            const float scale = (capRadius * 2.0f) / imgW;

            auto xform = juce::AffineTransform::translation(-imgW * 0.5f, -imgH * 0.5f)
                            .scaled(scale)
                            .rotated(angle)
                            .translated(centreX, centreY);
            g.drawImageTransformed(knobCap, xform);
        } else {
            // Fallback procedurale elegante in metallo tornito
            juce::ColourGradient knobGrad(juce::Colour(0xff3a3a40), centreX - capRadius, centreY - capRadius,
                                         juce::Colour(0xff18191c), centreX + capRadius, centreY + capRadius, true);
            g.setGradientFill(knobGrad);
            g.fillEllipse(centreX - capRadius, centreY - capRadius, capRadius * 2.0f, capRadius * 2.0f);

            g.setColour(juce::Colour(0xffc59c52));
            g.drawEllipse(centreX - capRadius, centreY - capRadius, capRadius * 2.0f, capRadius * 2.0f, 1.2f);

            // Indicatore tacca
            g.setColour(juce::Colour(0xffd4af37));
            g.drawLine(centreX, centreY,
                       centreX + capRadius * std::sin(angle),
                       centreY - capRadius * std::cos(angle), 2.2f);
        }
    }

private:
    juce::Colour neonColor;
    juce::Image knobCap;
    juce::Image scalePlate;
    float knobScale = 0.72f;
};

class AnalogStyledKnob : public juce::Component {
public:
    enum class ValueFormat {
        Multiplier,   // "1.30x"
        Decimal,      // "0.36"
        Percentage,   // "100%"
        Decibels,     // "-1.4 dB"
        Milliseconds, // "25.0 ms"
        Ratio,        // "4.0:1"
        Hertz         // "100 Hz"
    };

    AnalogStyledKnob(const juce::String& title, juce::Colour neonColor,
                     juce::Image capImage, ValueFormat formatType,
                     float minVal, float maxVal, float defaultVal,
                     juce::Image scalePlateImage = {}, float capScaleRatio = 0.72f)
        : lookAndFeel(neonColor, capImage, scalePlateImage, capScaleRatio),
          knobTitle(title),
          titleColor(neonColor),
          valFormat(formatType)
    {
        setOpaque(false);

        slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        slider.setLookAndFeel(&lookAndFeel);
        slider.setRange(minVal, maxVal);
        slider.setValue(defaultVal, juce::dontSendNotification);

        // Calibrazione cinematica angolare esatta (Batch 6 & specifiche utente):
        // Scale 0-100% e 0-10: arco calibrato da -150.0° a +150.0° (sweep 300°)
        // Scale Frequenza 20Hz-20kHz: arco calibrato da -145.0° a +145.0° (sweep 290°)
        const float startAngle = (formatType == ValueFormat::Hertz)
            ? -juce::MathConstants<float>::pi * (145.0f / 180.0f)
            : -juce::MathConstants<float>::pi * (150.0f / 180.0f);
        const float endAngle   = (formatType == ValueFormat::Hertz)
            ?  juce::MathConstants<float>::pi * (145.0f / 180.0f)
            :  juce::MathConstants<float>::pi * (150.0f / 180.0f);
        slider.setRotaryParameters(startAngle, endAngle, true);

        slider.onValueChange = [this]() {
            updateValueString();
            // Repaint selettivo (dirty region): invalida unicamente il rettangolo del badge numerico a fondo manopola
            const float w = static_cast<float>(getWidth());
            const float h = static_cast<float>(getHeight());
            const float badgeW = juce::jmin(w - 12.0f, 68.0f);
            const float badgeH = 17.0f;
            const float badgeX = (w - badgeW) * 0.5f;
            const float badgeY = h - badgeH - 2.0f;
            repaint(juce::Rectangle<int>(juce::roundToInt(badgeX - 1.0f), juce::roundToInt(badgeY - 1.0f),
                                         juce::roundToInt(badgeW + 2.0f), juce::roundToInt(badgeH + 2.0f)));
        };

        addAndMakeVisible(slider);
        updateValueString();
    }

    ~AnalogStyledKnob() override {
        slider.setLookAndFeel(nullptr);
    }

    void resized() override {
        const int w = getWidth();
        const int h = getHeight();
        const int sliderDim = juce::jmin(w, h - 38);
        slider.setBounds((w - sliderDim) / 2, 18, sliderDim, sliderDim);
    }

    void paint(juce::Graphics& g) override {
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());

        // 1. Titolo superiore con micro-rilievo dorato/bronzo
        g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        g.setColour(juce::Colour(0x90000000));
        g.drawText(knobTitle, 0, 2, static_cast<int>(w), 16, juce::Justification::centred, false);
        g.setColour(juce::Colour(0xffe6d2b5));
        g.drawText(knobTitle, 0, 1, static_cast<int>(w), 16, juce::Justification::centred, false);

        // 2. Valore numerico inferiore incassato in un badge nero anodizzato
        const float badgeW = juce::jmin(w - 12.0f, 68.0f);
        const float badgeH = 17.0f;
        const float badgeX = (w - badgeW) * 0.5f;
        const float badgeY = h - badgeH - 2.0f;

        // Ombra e sfondo del badge valore
        g.setColour(juce::Colour(0xd0080a0d));
        g.fillRoundedRectangle(badgeX, badgeY, badgeW, badgeH, 3.5f);
        g.setColour(juce::Colour(0x50c59c52));
        g.drawRoundedRectangle(badgeX, badgeY, badgeW, badgeH, 3.5f, 0.9f);

        // Testo del valore
        g.setFont(juce::FontOptions(11.5f, juce::Font::bold));
        g.setColour(juce::Colour(0xfff5eccd));
        g.drawText(displayValueStr, juce::roundToInt(badgeX), juce::roundToInt(badgeY),
                   juce::roundToInt(badgeW), juce::roundToInt(badgeH), juce::Justification::centred, false);
    }

    juce::Slider& getSlider() noexcept { return slider; }

    void updateValueString() {
        const float val = static_cast<float>(slider.getValue());
        switch (valFormat) {
            case ValueFormat::Multiplier:
                displayValueStr = juce::String(val, 2) + "x";
                break;
            case ValueFormat::Decimal:
                displayValueStr = juce::String(val, 2);
                break;
            case ValueFormat::Percentage:
                displayValueStr = juce::String(juce::roundToInt(val * 100.0f)) + "%";
                break;
            case ValueFormat::Decibels:
                displayValueStr = (val > 0.05f ? "+" : "") + juce::String(val, 1) + " dB";
                break;
            case ValueFormat::Milliseconds:
                if (val >= 100.0f)
                    displayValueStr = juce::String(juce::roundToInt(val)) + " ms";
                else
                    displayValueStr = juce::String(val, 1) + " ms";
                break;
            case ValueFormat::Ratio:
                displayValueStr = juce::String(val, 1) + ":1";
                break;
            case ValueFormat::Hertz:
                if (val >= 1000.0f)
                    displayValueStr = juce::String(val / 1000.0f, 1) + " kHz";
                else
                    displayValueStr = juce::String(juce::roundToInt(val)) + " Hz";
                break;
        }
    }

private:
    PhotorealisticNeonKnobLookAndFeel lookAndFeel;
    juce::Slider slider;
    juce::String knobTitle;
    juce::Colour titleColor;
    ValueFormat valFormat;
    juce::String displayValueStr;
};

} // namespace gui171
