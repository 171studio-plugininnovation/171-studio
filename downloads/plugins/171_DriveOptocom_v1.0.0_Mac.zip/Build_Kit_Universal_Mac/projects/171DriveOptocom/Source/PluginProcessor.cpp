#include "PluginProcessor.h"
#include "PluginEditor.h"

AudioPluginAudioProcessor::AudioPluginAudioProcessor()
    : AudioProcessor(BusesProperties().withInput ("Input",  juce::AudioChannelSet::stereo(), true)
                                      .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "Parameters", createParameterLayout())
{
    driveParam       = apvts.getRawParameterValue("drive");
    preampToneParam  = apvts.getRawParameterValue("preamp_tone");
    thresholdParam   = apvts.getRawParameterValue("threshold");
    ratioParam       = apvts.getRawParameterValue("ratio");
    t4MemoryParam    = apvts.getRawParameterValue("t4_memory");
    saturationParam  = apvts.getRawParameterValue("saturation");
    outGainParam     = apvts.getRawParameterValue("out_gain");
    widthParam       = apvts.getRawParameterValue("stereo_width");
    bypassParam      = apvts.getRawParameterValue("bypass");
    linkParam        = apvts.getRawParameterValue("stereo_link");
    punchParam       = apvts.getRawParameterValue("punch_mode");
    routingParam     = apvts.getRawParameterValue("sat_routing");
    scFilterParam    = apvts.getRawParameterValue("sc_filter");
    meterModeParam   = apvts.getRawParameterValue("meter_mode");
    channelModeParam = apvts.getRawParameterValue("channel_mode");
    headroomParam    = apvts.getRawParameterValue("headroom");
}

AudioPluginAudioProcessor::~AudioPluginAudioProcessor() {}

juce::AudioProcessorValueTreeState::ParameterLayout AudioPluginAudioProcessor::createParameterLayout() {
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // 1. PREAMP: Guadagno di ingresso analogico valvolare (-12 a +18 dB)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"drive", 1}, "Preamp",
        juce::NormalisableRange<float>(-12.0f, 18.0f, 0.1f), 0.0f));

    // 2. PREAMP TONE: Saturazione e calore valvolare del preamplificatore (0..100%)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"preamp_tone", 1}, "Preamp Tone",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.25f));

    // 3. THRESHOLD: Soglia di intervento della cella ottica (-40 a 0 dB)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"threshold", 1}, "Threshold",
        juce::NormalisableRange<float>(-40.0f, 0.0f, 0.1f), -18.0f));

    // 4. RATIO: Rapporto di compressione opto (1.5:1 a 10:1)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"ratio", 1}, "Ratio",
        juce::NormalisableRange<float>(1.5f, 10.0f, 0.1f), 3.0f));

    // 5. T4: Inerzia fotochimica e memory lag della cella CdS (0..100%)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"t4_memory", 1}, "T4 Cell",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.50f));

    // 6. SATURATION: Saturatore tri-band analogico (0..100%)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"saturation", 1}, "Saturation",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.25f));

    // 7. MAKEUP: Guadagno finale d'uscita (-18 a +18 dB)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"out_gain", 1}, "Makeup",
        juce::NormalisableRange<float>(-18.0f, 18.0f, 0.1f), 0.0f));

    // 8. STEREO WIDTH: Ampiezza stereo Mid/Side (0% Mono .. 100% Stereo .. 150% Wide)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"stereo_width", 1}, "Stereo Width",
        juce::NormalisableRange<float>(0.0f, 1.5f, 0.01f), 1.0f));

    // 9. BYPASS: True bypass hardware
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"bypass", 1}, "Bypass", false));

    // 10. STEREO LINK: Rilevazione linkata vs dual mono (default false: preserva la dinamica stereo autentica)
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"stereo_link", 1}, "Stereo Link", false));

    // 11. PUNCH MODE: Attacco a transistor rapido 1.5ms vs valvolare 10ms
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"punch_mode", 1}, "Punch Mode", false));

    // 12. ROUTING: PRE COMP (false) vs POST COMP (true)
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"sat_routing", 1}, "Routing (Pre/Post)", false));

    // 13. SC FILTER: Filtro passa-alto 100 Hz sul sidechain
    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"sc_filter", 1}, "SC Filter", true));

    // 14. METER MODE: Selezione visualizzazione SerumV (0=IN, 1=OUT, 2=GR)
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"meter_mode", 1}, "Meter Mode",
        juce::StringArray{ "IN", "OUT", "GR" }, 2));

    // 15. CHANNEL MODE: Selezione canale SerumV (0=STEREO, 1=MONO, 2=M/S)
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"channel_mode", 1}, "Channel Mode",
        juce::StringArray{ "STEREO", "MONO", "M/S" }, 0));

    // 16. HEADROOM: Calibrazione visualizzazione 0 VU (+4 a +26 dBFS)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"headroom", 1}, "Headroom",
        juce::NormalisableRange<float>(4.0f, 26.0f, 1.0f), 18.0f));

    return { params.begin(), params.end() };
}

void AudioPluginAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock) {
    setLatencySamples(static_cast<int>(dsp171::TruePeakLimiter::LookaheadLatency));
    preampStage.prepare(sampleRate, samplesPerBlock);
    optoDynamics.prepare(sampleRate, samplesPerBlock);
    triBandSaturator.prepare(sampleRate, samplesPerBlock);

    for (size_t ch = 0; ch < MaxChannels; ++ch) {
        truePeakLimiters[ch].prepare(sampleRate);
    }
    latencyBypass.reset();

    // Inizializzazione interpolatori continui a 20 ms (Modulo 02 - Anti-Zipper)
    constexpr double rampTimeSec = 0.020;
    smoothedDrive.reset(sampleRate, rampTimeSec);
    smoothedPreampTone.reset(sampleRate, rampTimeSec);
    smoothedThreshold.reset(sampleRate, rampTimeSec);
    smoothedRatio.reset(sampleRate, rampTimeSec);
    smoothedT4Memory.reset(sampleRate, rampTimeSec);
    smoothedSaturation.reset(sampleRate, rampTimeSec);
    smoothedOutGain.reset(sampleRate, rampTimeSec);

    smoothedDrive.setCurrentAndTargetValue(driveParam->load(std::memory_order_relaxed));
    smoothedPreampTone.setCurrentAndTargetValue(preampToneParam->load(std::memory_order_relaxed));
    smoothedThreshold.setCurrentAndTargetValue(thresholdParam->load(std::memory_order_relaxed));
    smoothedRatio.setCurrentAndTargetValue(ratioParam->load(std::memory_order_relaxed));
    smoothedT4Memory.setCurrentAndTargetValue(t4MemoryParam->load(std::memory_order_relaxed));
    smoothedSaturation.setCurrentAndTargetValue(saturationParam->load(std::memory_order_relaxed));
    smoothedOutGain.setCurrentAndTargetValue(outGainParam->load(std::memory_order_relaxed));
    smoothedWidth.reset(sampleRate, rampTimeSec);
    smoothedWidth.setCurrentAndTargetValue(widthParam != nullptr ? widthParam->load(std::memory_order_relaxed) : 1.0f);

    smoothedBypass.reset(sampleRate, 0.015); // 15 ms crossfade rampa
    smoothedBypass.setCurrentAndTargetValue(bypassParam->load(std::memory_order_relaxed) > 0.5f ? 1.0f : 0.0f);
}

void AudioPluginAudioProcessor::releaseResources() {
    preampStage.reset();
    optoDynamics.reset();
    triBandSaturator.reset();
    for (size_t ch = 0; ch < MaxChannels; ++ch) {
        truePeakLimiters[ch].reset();
    }
    latencyBypass.reset();
}

bool AudioPluginAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const {
    const auto& mainIn = layouts.getMainInputChannelSet();
    const auto& mainOut = layouts.getMainOutputChannelSet();

    if (mainOut != juce::AudioChannelSet::mono() && mainOut != juce::AudioChannelSet::stereo())
        return false;

    // Supporta configurazioni standard da studio: Mono -> Mono, Mono -> Stereo e Stereo -> Stereo
    if (mainIn == juce::AudioChannelSet::mono())
        return true;

    if (mainIn == juce::AudioChannelSet::stereo() && mainOut == juce::AudioChannelSet::stereo())
        return true;

    return false;
}

void AudioPluginAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) {
    juce::ScopedNoDenormals noDenormals;
    const int totalNumInputChannels  = getTotalNumInputChannels();
    const int totalNumOutputChannels = getTotalNumOutputChannels();
    const int numSamples = buffer.getNumSamples();

    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear(i, 0, numSamples);

    if (totalNumInputChannels < 1 || numSamples == 0)
        return;

    const bool isBypassed = bypassParam->load(std::memory_order_relaxed) > 0.5f;
    smoothedBypass.setTargetValue(isBypassed ? 1.0f : 0.0f);

    // Aggiornamento target parametri DSP con smoothing continuo (Modulo 02)
    smoothedDrive.setTargetValue(driveParam->load(std::memory_order_relaxed));
    smoothedPreampTone.setTargetValue(preampToneParam->load(std::memory_order_relaxed));
    smoothedThreshold.setTargetValue(thresholdParam->load(std::memory_order_relaxed));
    smoothedRatio.setTargetValue(ratioParam->load(std::memory_order_relaxed));
    smoothedT4Memory.setTargetValue(t4MemoryParam->load(std::memory_order_relaxed));
    smoothedSaturation.setTargetValue(saturationParam->load(std::memory_order_relaxed));
    smoothedOutGain.setTargetValue(outGainParam->load(std::memory_order_relaxed));
    smoothedWidth.setTargetValue(widthParam != nullptr ? widthParam->load(std::memory_order_relaxed) : 1.0f);

    const bool linkVal    = linkParam->load(std::memory_order_relaxed) > 0.5f;
    const bool punchVal   = punchParam->load(std::memory_order_relaxed) > 0.5f;
    const bool postComp   = routingParam->load(std::memory_order_relaxed) > 0.5f;
    const bool scFiltVal  = scFilterParam->load(std::memory_order_relaxed) > 0.5f;

    dsp171::VisualFrame frame;
    float sumInSquares = 0.0f;
    float sumOutSquaresL = 0.0f;
    float sumOutSquaresR = 0.0f;
    float peakL = 0.0f;
    float peakR = 0.0f;
    float minGRL_dB = 0.0f;
    float minGRR_dB = 0.0f;

    const int stride = std::max(1, numSamples / static_cast<int>(dsp171::VisualFrame::FrameSamples));

    for (int sample = 0; sample < numSamples; ++sample) {
        // Interpolazione continua dei parametri campione per campione (Anti-Zipper)
        const float curDrive   = smoothedDrive.getNextValue();
        const float curTone    = smoothedPreampTone.getNextValue();
        const float curThresh  = smoothedThreshold.getNextValue();
        const float curRatio   = smoothedRatio.getNextValue();
        const float curMemory  = smoothedT4Memory.getNextValue();
        const float curSat     = smoothedSaturation.getNextValue();
        const float curGain    = smoothedOutGain.getNextValue();
        const float curWidth   = smoothedWidth.getNextValue();
        const float curBypass  = smoothedBypass.getNextValue();

        preampStage.setInputDriveDb(curDrive);
        preampStage.setPreampTone(curTone);
        preampStage.setOutputGainDb(curGain);

        optoDynamics.setParameters(curThresh, curRatio, curMemory, scFiltVal, linkVal, punchVal);
        triBandSaturator.setSaturation(curSat);

        const float inL = buffer.getSample(0, sample);
        const float inR = (totalNumInputChannels > 1) ? buffer.getSample(1, sample) : inL;

        sumInSquares += inL * inL + inR * inR;

        // Memorizzazione campione dry per compensazione bit-exact della latenza di lookahead
        latencyBypass.pushDrySample(0, inL);
        latencyBypass.pushDrySample(1, inR);
        latencyBypass.advanceWriteIndex();

        const float alignedDryL = latencyBypass.getAlignedDrySample(0, dsp171::TruePeakLimiter::LookaheadLatency);
        const float alignedDryR = latencyBypass.getAlignedDrySample(1, dsp171::TruePeakLimiter::LookaheadLatency);

        // 1. Stadio di Preamplificazione (Drive & Tube Tone)
        float preL = inL;
        float preR = inR;
        preampStage.processPreamp(inL, inR, preL, preR);

        float outL = preL;
        float outR = preR;
        float grL = 0.0f;
        float grR = 0.0f;

        if (!postComp) {
            // === MODALITÀ PRE-COMP ===
            float satL = preL;
            float satR = preR;
            triBandSaturator.processStereo(preL, preR, satL, satR);

            float compL = satL;
            float compR = satR;
            optoDynamics.processSample(satL, satR, compL, compR, grL, grR);

            preampStage.processOutput(compL, compR, outL, outR);
        } else {
            // === MODALITÀ POST-COMP ===
            float compL = preL;
            float compR = preR;
            optoDynamics.processSample(preL, preR, compL, compR, grL, grR);

            float satL = compL;
            float satR = compR;
            triBandSaturator.processStereo(compL, compR, satL, satR);

            preampStage.processOutput(satL, satR, outL, outR);
        }

        if (grL < minGRL_dB) minGRL_dB = grL;
        if (grR < minGRR_dB) minGRR_dB = grR;

        // 2. Controllo di Ampiezza Stereo Mid-Side
        float wideL = outL;
        float wideR = outR;
        if (totalNumOutputChannels > 1) {
            const float mid  = 0.5f * (outL + outR);
            const float side = 0.5f * (outL - outR) * curWidth;
            wideL = mid + side;
            wideR = mid - side;
        }

        // 3. True-Peak Limiter a 4x oversampling sinc Kaiser conforme ITU-R BS.1770-4 (-0.10 dBTP)
        float safeL = wideL;
        float safeR = wideR;
        dsp171::TruePeakLimiter::processStereoPair(
            truePeakLimiters[0], truePeakLimiters[1],
            wideL, wideR, safeL, safeR, -0.10f);

        // 4. Crossfade continuo con il Master Bypass a fase compensata (zero comb filtering / flanger)
        const float finalL = (safeL * (1.0f - curBypass)) + (alignedDryL * curBypass);
        const float finalR = (safeR * (1.0f - curBypass)) + (alignedDryR * curBypass);

        if (totalNumOutputChannels > 0)
            buffer.setSample(0, sample, finalL);
        if (totalNumOutputChannels > 1)
            buffer.setSample(1, sample, finalR);

        sumOutSquaresL += finalL * finalL;
        sumOutSquaresR += finalR * finalR;

        float aL = std::abs(finalL);
        float aR = std::abs(finalR);
        if (aL > peakL) peakL = aL;
        if (aR > peakR) peakR = aR;

        if ((sample % stride) == 0) {
            size_t frameIdx = static_cast<size_t>(sample / stride);
            if (frameIdx < dsp171::VisualFrame::FrameSamples) {
                frame.samplesIn[frameIdx]    = 0.5f * (inL + inR);
                frame.samplesOut[frameIdx]   = 0.5f * (finalL + finalR);
                frame.samplesOut_L[frameIdx] = finalL;
                frame.samplesOut_R[frameIdx] = finalR;
                frame.samplesGR[frameIdx]    = 0.5f * (grL + grR);
            }
        }
    }

    frame.inRMS    = std::sqrt(sumInSquares / (2.0f * static_cast<float>(numSamples)));
    frame.outRMS_L = std::sqrt(sumOutSquaresL / static_cast<float>(numSamples));
    frame.outRMS_R = std::sqrt(sumOutSquaresR / static_cast<float>(numSamples));
    frame.peak_L   = peakL;
    frame.peak_R   = peakR;
    frame.gainReduction_L = minGRL_dB;
    frame.gainReduction_R = minGRR_dB;

    visualFIFO.push(frame);
}

const std::vector<PluginPreset>& AudioPluginAudioProcessor::getFactoryPresets() {
    static const std::vector<PluginPreset> presets = {
        // Name, Drive, PreampTone, Thresh, Ratio, T4Mem, Saturation, OutGain, StereoWidth, Bypass, Link, Punch, SatRouting, SCFilter
        { "Master Glue (Gentle)",      0.0f, 0.20f, -14.0f, 2.5f, 0.40f, 0.20f,  0.5f, 1.05f, false, false, false, true,  true  },
        { "Vocal Optical Warmth",      2.0f, 0.45f, -18.0f, 3.5f, 0.65f, 0.30f,  2.0f, 1.00f, false, false, false, false, true  },
        { "Drum Punch Aggressive",     3.5f, 0.35f, -22.0f, 4.5f, 0.15f, 0.40f,  3.0f, 1.10f, false, false, true,  false, true  },
        { "Bass Opto Fatness",         1.5f, 0.50f, -20.0f, 4.0f, 0.70f, 0.35f,  1.5f, 1.00f, false, false, false, false, false },
        { "Acoustic Guitar Leveller",  0.0f, 0.15f, -15.0f, 2.8f, 0.35f, 0.15f,  1.0f, 1.15f, false, false, false, true,  true  },
        { "Synth Bus Transformer",     2.5f, 0.60f, -16.0f, 3.2f, 0.50f, 0.50f,  1.5f, 1.25f, false, false, true,  true,  true  },
        { "Heavy Tube Drive Squash",   6.0f, 0.85f, -26.0f, 8.0f, 0.85f, 0.75f,  4.0f, 1.00f, false, false, false, false, false }
    };
    return presets;
}

int AudioPluginAudioProcessor::getNumPrograms() {
    return static_cast<int>(getFactoryPresets().size());
}

int AudioPluginAudioProcessor::getCurrentProgram() {
    return currentProgramIndex;
}

void AudioPluginAudioProcessor::setCurrentProgram(int index) {
    const auto& presets = getFactoryPresets();
    if (index >= 0 && index < static_cast<int>(presets.size())) {
        currentProgramIndex = index;
        const auto& p = presets[static_cast<size_t>(index)];

        if (auto* param = apvts.getParameter("drive"))        param->setValueNotifyingHost(param->convertTo0to1(p.drive));
        if (auto* param = apvts.getParameter("preamp_tone"))  param->setValueNotifyingHost(param->convertTo0to1(p.preampTone));
        if (auto* param = apvts.getParameter("threshold"))    param->setValueNotifyingHost(param->convertTo0to1(p.threshold));
        if (auto* param = apvts.getParameter("ratio"))        param->setValueNotifyingHost(param->convertTo0to1(p.ratio));
        if (auto* param = apvts.getParameter("t4_memory"))    param->setValueNotifyingHost(param->convertTo0to1(p.t4Memory));
        if (auto* param = apvts.getParameter("saturation"))   param->setValueNotifyingHost(param->convertTo0to1(p.saturation));
        if (auto* param = apvts.getParameter("out_gain"))     param->setValueNotifyingHost(param->convertTo0to1(p.outGain));
        if (auto* param = apvts.getParameter("stereo_width")) param->setValueNotifyingHost(param->convertTo0to1(p.stereoWidth));
        if (auto* param = apvts.getParameter("bypass"))       param->setValueNotifyingHost(p.bypass ? 1.0f : 0.0f);
        if (auto* param = apvts.getParameter("stereo_link"))  param->setValueNotifyingHost(p.stereoLink ? 1.0f : 0.0f);
        if (auto* param = apvts.getParameter("punch_mode"))   param->setValueNotifyingHost(p.punchMode ? 1.0f : 0.0f);
        if (auto* param = apvts.getParameter("sat_routing"))  param->setValueNotifyingHost(p.satRouting ? 1.0f : 0.0f);
        if (auto* param = apvts.getParameter("sc_filter"))    param->setValueNotifyingHost(p.scFilter ? 1.0f : 0.0f);
    }
}

const juce::String AudioPluginAudioProcessor::getProgramName(int index) {
    const auto& presets = getFactoryPresets();
    if (index >= 0 && index < static_cast<int>(presets.size()))
        return presets[static_cast<size_t>(index)].name;
    return {};
}

void AudioPluginAudioProcessor::changeProgramName(int, const juce::String&) {}

void AudioPluginAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    auto state = apvts.copyState();
    state.setProperty("version", 2, nullptr);
    state.setProperty("currentPreset", currentProgramIndex, nullptr);

    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void AudioPluginAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType())) {
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
        currentProgramIndex = apvts.state.getProperty("currentPreset", 0);
    }
}

juce::AudioProcessorEditor* AudioPluginAudioProcessor::createEditor() {
    return new AudioPluginAudioProcessorEditor(*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new AudioPluginAudioProcessor();
}
