#include <juce_gui_basics/juce_gui_basics.h>
#include "PluginProcessor.h"
#include "PluginEditor.h"

int main()
{
    juce::ScopedJuceInitialiser_GUI juceInit;

    AudioPluginAudioProcessor processor;
    processor.prepareToPlay(48000.0, 512);

    std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
    if (editor == nullptr)
        return 1;

    editor->setSize(1024, 571);

    // Imposta parametri musicali realistici con Stereo Link disattivato e Stereo Width a 1.15x
    if (auto* p = processor.getAPVTS().getParameter("drive"))
        p->setValueNotifyingHost(0.65f);
    if (auto* p = processor.getAPVTS().getParameter("preamp_tone"))
        p->setValueNotifyingHost(0.40f);
    if (auto* p = processor.getAPVTS().getParameter("threshold"))
        p->setValueNotifyingHost(0.45f);
    if (auto* p = processor.getAPVTS().getParameter("ratio"))
        p->setValueNotifyingHost(0.50f);
    if (auto* p = processor.getAPVTS().getParameter("t4_memory"))
        p->setValueNotifyingHost(0.70f);
    if (auto* p = processor.getAPVTS().getParameter("saturation"))
        p->setValueNotifyingHost(0.60f);
    if (auto* p = processor.getAPVTS().getParameter("out_gain"))
        p->setValueNotifyingHost(0.55f);
    if (auto* p = processor.getAPVTS().getParameter("stereo_width"))
        p->setValueNotifyingHost(0.767f); // ~1.15x Width
    if (auto* p = processor.getAPVTS().getParameter("stereo_link"))
        p->setValueNotifyingHost(0.0f);   // Dual Mono
    if (auto* p = processor.getAPVTS().getParameter("punch_mode"))
        p->setValueNotifyingHost(1.0f);
    if (auto* p = processor.getAPVTS().getParameter("sat_routing"))
        p->setValueNotifyingHost(0.0f);
    if (auto* p = processor.getAPVTS().getParameter("sc_filter"))
        p->setValueNotifyingHost(1.0f);
    if (auto* p = processor.getAPVTS().getParameter("bypass"))
        p->setValueNotifyingHost(0.0f);

    editor->resized();

    // Alimenta blocchi audio stereo realistici per visualizzare la separazione L / R
    for (int block = 0; block < 16; ++block) {
        juce::AudioBuffer<float> testBuffer(2, 512);
        float* wL = testBuffer.getWritePointer(0);
        float* wR = testBuffer.getWritePointer(1);
        for (int i = 0; i < 512; ++i) {
            float t = (block * 512 + i) / 48000.0f;
            // Canale L: basso e percussione calda (maggiore ampiezza)
            wL[i] = std::sin(2.0f * juce::MathConstants<float>::pi * 180.0f * t) * 0.75f
                  + std::sin(2.0f * juce::MathConstants<float>::pi * 540.0f * t) * 0.20f;
            // Canale R: armonici brillanti e modulazione differenziale (ampiezza e frequenza diversa)
            wR[i] = std::sin(2.0f * juce::MathConstants<float>::pi * 320.0f * t) * 0.45f
                  + std::sin(2.0f * juce::MathConstants<float>::pi * 960.0f * t) * 0.35f;
        }
        juce::MidiBuffer midi;
        processor.processBlock(testBuffer, midi);

        // Notifica l'editor a ogni blocco per aggiornare la telemetria stereo
        if (auto* edTimer = dynamic_cast<juce::Timer*>(editor.get())) {
            edTimer->timerCallback();
        }
    }

    // 1. Snapshot 1: Modalità Normale Stereo (Doppie lancette VU L/R + Doppio tracciato oscilloscopio Cyan/Ambra)
    juce::Image snapshotNormal = editor->createComponentSnapshot(editor->getLocalBounds());
    {
        const char* paths[] = {
            R"(C:\Users\171Studio\.gemini\antigravity\brain\09083e63-7efb-4e38-b54a-484d18d4fb1f\171DriveOptocom_Stereo_GUI.png)",
            R"(C:\Users\171Studio\.gemini\antigravity\scratch\171DriveOptocom\drive_optocom_latest.png)",
            R"(C:\Users\171Studio\.gemini\antigravity\scratch\171DriveOptocom\drive_optocom_verified.png)",
            R"(C:\Users\171Studio\.gemini\antigravity\brain\2f4a0ca7-5fa7-47eb-9a6a-f713f410d3de\driveoptocom_gui_render.png)"
        };
        for (const char* p : paths) {
            juce::File outFile(p);
            outFile.getParentDirectory().createDirectory();
            outFile.deleteFile();
            juce::FileOutputStream stream(outFile);
            if (stream.openedOk()) {
                juce::PNGImageFormat png;
                png.writeImageToStream(snapshotNormal, stream);
            }
        }
    }

    // 2. Snapshot 2: Con Bypass ON
    if (auto* p = processor.getAPVTS().getParameter("bypass"))
        p->setValueNotifyingHost(1.0f);
    if (auto* edTimer = dynamic_cast<juce::Timer*>(editor.get())) {
        edTimer->timerCallback();
    }
    juce::Image snapshotBypassed = editor->createComponentSnapshot(editor->getLocalBounds());
    {
        juce::File outFile(R"(C:\Users\171Studio\.gemini\antigravity\scratch\171DriveOptocom\driveoptocom_bypass_engaged.png)");
        outFile.deleteFile();
        juce::FileOutputStream stream(outFile);
        if (stream.openedOk()) {
            juce::PNGImageFormat png;
            png.writeImageToStream(snapshotBypassed, stream);
        }
    }

    return 0;
}
