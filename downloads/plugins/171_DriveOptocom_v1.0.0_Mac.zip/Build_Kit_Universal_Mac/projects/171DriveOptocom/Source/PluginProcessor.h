#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include <dsp171/Common.h>
#include <dsp171/LockFreeFIFO.h>
#include <dsp171/SafetyCeiling.h>
#include <dsp171/LatencyBypass.h>
#include <array>
#include "DSP/OptoDynamics.h"
#include "DSP/TriBandSaturator.h"
#include "DSP/PreampStage.h"

struct PluginPreset {
    const char* name;
    float drive;       // dB (-12..+18)
    float preampTone;  // 0..1 (0..100%)
    float threshold;   // dB (-40..0)
    float ratio;       // X:1 (1.5..10)
    float t4Memory;    // 0..1 (0..100%)
    float saturation;  // 0..1 (0..100%)
    float outGain;     // dB (-18..+18)
    float stereoWidth; // 0..1.5 (0..150%, default 1.0)
    bool bypass;
    bool stereoLink;
    bool punchMode;
    bool satRouting;   // false = PRE COMP, true = POST COMP
    bool scFilter;
};

class AudioPluginAudioProcessor : public juce::AudioProcessor {
public:
    AudioPluginAudioProcessor();
    ~AudioPluginAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;

    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "DRIVE OPTOCOM"; }

    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    // Gestione Preset di fabbrica
    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int index, const juce::String& newName) override;

    juce::AudioProcessorParameter* getBypassParameter() const override {
        return apvts.getParameter("bypass");
    }

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }
    dsp171::LockFreeVisualFIFO<512>& getVisualFIFO() noexcept { return visualFIFO; }

    static const std::vector<PluginPreset>& getFactoryPresets();

private:
    juce::AudioProcessorValueTreeState apvts;
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    dsp171::PreampStage preampStage;
    dsp171::OptoDynamics optoDynamics;
    dsp171::TriBandSaturator triBandSaturator;

    static constexpr size_t MaxChannels = 2;
    std::array<dsp171::TruePeakLimiter, MaxChannels> truePeakLimiters;
    dsp171::LatencyCompensatedBypass<MaxChannels, 64> latencyBypass;

    dsp171::LockFreeVisualFIFO<512> visualFIFO;

    std::atomic<float>* driveParam       = nullptr;
    std::atomic<float>* preampToneParam  = nullptr;
    std::atomic<float>* thresholdParam   = nullptr;
    std::atomic<float>* ratioParam       = nullptr;
    std::atomic<float>* t4MemoryParam    = nullptr;
    std::atomic<float>* saturationParam  = nullptr;
    std::atomic<float>* outGainParam     = nullptr;
    std::atomic<float>* widthParam       = nullptr;
    std::atomic<float>* bypassParam      = nullptr;
    std::atomic<float>* linkParam        = nullptr;
    std::atomic<float>* punchParam       = nullptr;
    std::atomic<float>* routingParam     = nullptr;
    std::atomic<float>* scFilterParam    = nullptr;
    std::atomic<float>* meterModeParam   = nullptr;
    std::atomic<float>* channelModeParam = nullptr;
    std::atomic<float>* headroomParam    = nullptr;

    int currentProgramIndex = 0;

    // Interpolatori continui a 20 ms (Modulo 02 - Anti-Zipper)
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedDrive;
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedPreampTone;
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedThreshold;
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedRatio;
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedT4Memory;
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedSaturation;
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedOutGain;
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedWidth;
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedBypass;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AudioPluginAudioProcessor)
};
