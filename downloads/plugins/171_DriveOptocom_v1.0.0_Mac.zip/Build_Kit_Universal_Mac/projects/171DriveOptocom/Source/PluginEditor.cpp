#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <BinaryData.h>

AudioPluginAudioProcessorEditor::AudioPluginAudioProcessorEditor(AudioPluginAudioProcessor& p)
    : AudioProcessorEditor(&p),
      processorRef(p),
      scopeView(p.getVisualFIFO())
{
    // 1. Carica il backplate DRIVE OPTOCOM pulito
    backgroundImage = juce::ImageCache::getFromMemory(BinaryData::driveoptocom_background_png,
                                                       BinaryData::driveoptocom_background_pngSize);

    // 2. Carica i componenti hardware boutique per CMF differenziato calibrati
    knobTeardropBronzeImg = juce::ImageCache::getFromMemory(BinaryData::Knob_Teardrop_Pointer_Collet_171Studio_GoldRim_256x256_png,
                                                           BinaryData::Knob_Teardrop_Pointer_Collet_171Studio_GoldRim_256x256_pngSize);
    knobBakeliteOptoImg   = juce::ImageCache::getFromMemory(BinaryData::knob_bakelite_opto_png,   BinaryData::knob_bakelite_opto_pngSize);
    knobMarconiRubyImg    = juce::ImageCache::getFromMemory(BinaryData::knob_marconi_ruby_png,    BinaryData::knob_marconi_ruby_pngSize);
    knobGunmetalMakeupImg = juce::ImageCache::getFromMemory(BinaryData::knob_gunmetal_makeup_png, BinaryData::knob_gunmetal_makeup_pngSize);

    dialScaleCalibratedImg = juce::ImageCache::getFromMemory(BinaryData::Dial_Scale_Calibrated_0_to_10_171Studio_256x256_png,
                                                            BinaryData::Dial_Scale_Calibrated_0_to_10_171Studio_256x256_pngSize);
    dialScaleVintageImg    = juce::ImageCache::getFromMemory(BinaryData::Dial_Scale_Percentage_0_to_100_171Studio_256x256_png,
                                                            BinaryData::Dial_Scale_Percentage_0_to_100_171Studio_256x256_pngSize);

    lampJewelAmberImg = juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_amber_on_png, BinaryData::lamp_jewel_amber_on_pngSize);
    lampJewelDarkImg  = juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_dark_off_png,  BinaryData::lamp_jewel_dark_off_pngSize);
    lampJewelRubyImg  = juce::ImageCache::getFromMemory(BinaryData::lamp_jewel_ruby_on_png,  BinaryData::lamp_jewel_ruby_on_pngSize);

    // 3. Carica le immagini per il Modulo Heavy-Duty Bypass e i Pulsanti Console Arancioni
    auto swBypassActiveImg  = juce::ImageCache::getFromMemory(BinaryData::sw_bypass_active_png, BinaryData::sw_bypass_active_pngSize);
    auto swBypassEngagedImg = juce::ImageCache::getFromMemory(BinaryData::sw_bypass_engaged_png, BinaryData::sw_bypass_engaged_pngSize);
    auto btnAmberLitImg     = juce::ImageCache::getFromMemory(BinaryData::Button_Console_Square_Blank_Amber_Lit_ON_png,
                                                              BinaryData::Button_Console_Square_Blank_Amber_Lit_ON_pngSize);
    auto btnDarkUnlitImg    = juce::ImageCache::getFromMemory(BinaryData::Button_Console_Square_Blank_Dark_Unlit_OFF_png,
                                                              BinaryData::Button_Console_Square_Blank_Dark_Unlit_OFF_pngSize);

    // 4. Creazione delle 7 manopole superiori uniformate con il logo 171 Studio e colori originali dell'asset
    // Sezione 1: PREAMP & DRIVE
    driveKnob      = std::make_unique<gui171::AnalogStyledKnob>("PREAMP DRIVE", juce::Colour(0xffc5a059),
                                                                knobTeardropBronzeImg, gui171::AnalogStyledKnob::ValueFormat::Decibels,
                                                                -12.0f, 18.0f, 0.0f, dialScaleCalibratedImg, 0.70f);

    preampToneKnob = std::make_unique<gui171::AnalogStyledKnob>("PREAMP TONE",  juce::Colour(0xffc5a059),
                                                                knobTeardropBronzeImg, gui171::AnalogStyledKnob::ValueFormat::Percentage,
                                                                0.0f, 1.0f, 0.25f, dialScaleVintageImg, 0.70f);

    // Sezione 2: T4B OPTICAL LEVELLER
    threshKnob     = std::make_unique<gui171::AnalogStyledKnob>("THRESHOLD",    juce::Colour(0xffc5a059),
                                                                knobTeardropBronzeImg, gui171::AnalogStyledKnob::ValueFormat::Decibels,
                                                                -40.0f, 0.0f, -18.0f, dialScaleCalibratedImg, 0.70f);

    ratioKnob      = std::make_unique<gui171::AnalogStyledKnob>("RATIO",        juce::Colour(0xffc5a059),
                                                                knobTeardropBronzeImg, gui171::AnalogStyledKnob::ValueFormat::Ratio,
                                                                1.5f, 10.0f, 3.0f, dialScaleCalibratedImg, 0.70f);

    t4MemoryKnob   = std::make_unique<gui171::AnalogStyledKnob>("T4 MEMORY",    juce::Colour(0xffc5a059),
                                                                knobTeardropBronzeImg, gui171::AnalogStyledKnob::ValueFormat::Percentage,
                                                                0.0f, 1.0f, 0.50f, dialScaleVintageImg, 0.70f);

    // Sezione 3: TRI-BAND SATURATOR
    satKnob        = std::make_unique<gui171::AnalogStyledKnob>("SATURATION",   juce::Colour(0xffc5a059),
                                                                knobTeardropBronzeImg, gui171::AnalogStyledKnob::ValueFormat::Percentage,
                                                                0.0f, 1.0f, 0.25f, dialScaleVintageImg, 0.70f);

    // Sezione 4: MASTER MAKEUP
    outputKnob     = std::make_unique<gui171::AnalogStyledKnob>("MAKEUP",       juce::Colour(0xffc5a059),
                                                                knobTeardropBronzeImg, gui171::AnalogStyledKnob::ValueFormat::Decibels,
                                                                -18.0f, 18.0f, 0.0f, dialScaleCalibratedImg, 0.70f);

    widthKnob      = std::make_unique<gui171::AnalogStyledKnob>("STEREO WIDTH", juce::Colour(0xff00d5e5),
                                                                knobTeardropBronzeImg, gui171::AnalogStyledKnob::ValueFormat::Percentage,
                                                                0.0f, 1.50f, 1.0f, dialScaleVintageImg, 0.65f);

    // 5. Creazione controlli inferiori: Modulo Heavy-Duty Bypass con LED autentico + 4 Pulsanti Console Arancioni
    bypassSwitch   = std::make_unique<gui171::HeavyDutyBypassModule>(swBypassActiveImg, swBypassEngagedImg);
    linkSwitch     = std::make_unique<gui171::SquareConsoleButton>("STEREO LINK", "OFF", "ON",   btnAmberLitImg, btnDarkUnlitImg);
    modeSwitch     = std::make_unique<gui171::SquareConsoleButton>("PUNCH MODE",  "OFF", "ON",   btnAmberLitImg, btnDarkUnlitImg);
    routingSwitch  = std::make_unique<gui171::SquareConsoleButton>("ROUTING",     "PRE", "POST", btnAmberLitImg, btnDarkUnlitImg);
    scFilterSwitch = std::make_unique<gui171::SquareConsoleButton>("SC 100Hz",    "OFF", "ON",   btnAmberLitImg, btnDarkUnlitImg);

    // 6. Aggiunta componenti a schermo
    // Modulo SerumV VU & Gain Reduction Meter (Studio 171)
    serumVMeter.setMeterMode(dsp171::MeterMode::GainReduction); // default to GR on optical compressor
    addAndMakeVisible(serumVMeter);

    // Mode Push Bank (IN, OUT, GR)
    meterModePushBank = std::make_unique<gui171::VintageConsolePushBank>(juce::StringArray{ "IN", "OUT", "GR" });
    auto* modeParam = processorRef.getAPVTS().getRawParameterValue("meter_mode");
    if (modeParam != nullptr) {
        int mIdx = std::clamp(static_cast<int>(modeParam->load()), 0, 2);
        meterModePushBank->setSelectedConsole(mIdx, juce::dontSendNotification);
        serumVMeter.setMeterMode(static_cast<dsp171::MeterMode>(mIdx));
    } else {
        meterModePushBank->setSelectedConsole(2, juce::dontSendNotification);
        serumVMeter.setMeterMode(dsp171::MeterMode::GainReduction);
    }
    meterModePushBank->setOnSelectionChanged([this](int idx) {
        if (auto* param = processorRef.getAPVTS().getParameter("meter_mode")) {
            param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(idx)));
        }
        serumVMeter.setMeterMode(static_cast<dsp171::MeterMode>(idx));
    });
    addAndMakeVisible(*meterModePushBank);

    // Channel Push Bank (ST, MONO, M/S)
    channelModePushBank = std::make_unique<gui171::VintageConsolePushBank>(juce::StringArray{ "ST", "MONO", "M/S" });
    auto* chParam = processorRef.getAPVTS().getRawParameterValue("channel_mode");
    if (chParam != nullptr) {
        channelModePushBank->setSelectedConsole(std::clamp(static_cast<int>(chParam->load()), 0, 2), juce::dontSendNotification);
    }
    channelModePushBank->setOnSelectionChanged([this](int idx) {
        if (auto* param = processorRef.getAPVTS().getParameter("channel_mode")) {
            param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(idx)));
        }
    });
    addAndMakeVisible(*channelModePushBank);

    // Headroom Knob (4 to 26 dB)
    headroomKnob = std::make_unique<gui171::AnalogStyledKnob>(
        "HEADROOM", juce::Colour(0xffc5a059),
        knobTeardropBronzeImg, gui171::AnalogStyledKnob::ValueFormat::Decibels,
        4.0f, 26.0f, 18.0f, dialScaleCalibratedImg, 0.70f);
    headroomAttach = std::make_unique<SliderAttachment>(processorRef.getAPVTS(), "headroom", headroomKnob->getSlider());
    headroomKnob->getSlider().onValueChange = [this]() {
        serumVMeter.setHeadroom(static_cast<float>(headroomKnob->getSlider().getValue()));
    };
    if (auto* hrParam = processorRef.getAPVTS().getRawParameterValue("headroom")) {
        serumVMeter.setHeadroom(hrParam->load());
    }
    addAndMakeVisible(*headroomKnob);

    addAndMakeVisible(scopeView);

    addAndMakeVisible(*driveKnob);
    addAndMakeVisible(*preampToneKnob);
    addAndMakeVisible(*threshKnob);
    addAndMakeVisible(*ratioKnob);
    addAndMakeVisible(*t4MemoryKnob);
    addAndMakeVisible(*satKnob);
    addAndMakeVisible(*outputKnob);
    addAndMakeVisible(*widthKnob);

    addAndMakeVisible(*bypassSwitch);
    addAndMakeVisible(*linkSwitch);
    addAndMakeVisible(*modeSwitch);
    addAndMakeVisible(*routingSwitch);
    addAndMakeVisible(*scFilterSwitch);

    // 7. Collegamento APVTS
    auto& apvts = processorRef.getAPVTS();
    driveAttach      = std::make_unique<SliderAttachment>(apvts, "drive",        driveKnob->getSlider());
    preampToneAttach = std::make_unique<SliderAttachment>(apvts, "preamp_tone",  preampToneKnob->getSlider());
    threshAttach     = std::make_unique<SliderAttachment>(apvts, "threshold",    threshKnob->getSlider());
    ratioAttach      = std::make_unique<SliderAttachment>(apvts, "ratio",        ratioKnob->getSlider());
    t4MemoryAttach   = std::make_unique<SliderAttachment>(apvts, "t4_memory",    t4MemoryKnob->getSlider());
    satAttach        = std::make_unique<SliderAttachment>(apvts, "saturation",   satKnob->getSlider());
    outputAttach     = std::make_unique<SliderAttachment>(apvts, "out_gain",     outputKnob->getSlider());
    widthAttach      = std::make_unique<SliderAttachment>(apvts, "stereo_width", widthKnob->getSlider());

    bypassAttach   = std::make_unique<ButtonAttachment>(apvts, "bypass",       bypassSwitch->getButton());
    linkAttach     = std::make_unique<ButtonAttachment>(apvts, "stereo_link",  linkSwitch->getButton());
    modeAttach     = std::make_unique<ButtonAttachment>(apvts, "punch_mode",   modeSwitch->getButton());
    routingAttach  = std::make_unique<ButtonAttachment>(apvts, "sat_routing",  routingSwitch->getButton());
    scFilterAttach = std::make_unique<ButtonAttachment>(apvts, "sc_filter",    scFilterSwitch->getButton());

    // 8. Selettore Preset al centro della testata con LookAndFeel personalizzato
    const auto& presets = AudioPluginAudioProcessor::getFactoryPresets();
    for (size_t i = 0; i < presets.size(); ++i) {
        presetComboBox.addItem(presets[i].name, static_cast<int>(i + 1));
    }
    presetComboBox.setLookAndFeel(&presetLookAndFeel);
    presetComboBox.setSelectedId(processorRef.getCurrentProgram() + 1, juce::dontSendNotification);
    presetComboBox.addListener(this);
    addAndMakeVisible(presetComboBox);

    // Stepper Button Boutique dorati per preset (< e >)
    prevPresetBtn = std::make_unique<gui171::BoutiqueStepperButton>(gui171::BoutiqueStepperButton::Direction::Previous);
    prevPresetBtn->setOnClick([this]() {
        int cur = presetComboBox.getSelectedId() - 1;
        int num = processorRef.getNumPrograms();
        if (num > 0) {
            int prev = (cur - 1 + num) % num;
            presetComboBox.setSelectedId(prev + 1, juce::sendNotification);
        }
    });
    addAndMakeVisible(*prevPresetBtn);

    nextPresetBtn = std::make_unique<gui171::BoutiqueStepperButton>(gui171::BoutiqueStepperButton::Direction::Next);
    nextPresetBtn->setOnClick([this]() {
        int cur = presetComboBox.getSelectedId() - 1;
        int num = processorRef.getNumPrograms();
        if (num > 0) {
            int next = (cur + 1) % num;
            presetComboBox.setSelectedId(next + 1, juce::sendNotification);
        }
    });
    addAndMakeVisible(*nextPresetBtn);

    // Supporto completo al resizing con mantenimento proporzioni e barra angolare di ridimensionamento
    setResizable(true, true);
    setResizeLimits(768, 428, 2048, 1142);
    getConstrainer()->setFixedAspectRatio(1024.0 / 571.0);
    setSize(1024, 571);

    startTimerHz(60);
}

AudioPluginAudioProcessorEditor::~AudioPluginAudioProcessorEditor() {
    stopTimer();
    presetComboBox.setLookAndFeel(nullptr);
    presetComboBox.removeListener(this);
}

void AudioPluginAudioProcessorEditor::timerCallback() {
    // Monitora la riduzione di guadagno live dal FIFO per modulare la spia Opto Cell
    dsp171::VisualFrame frame;
    bool hasData = false;
    dsp171::VisualFrame latestFrame;
    while (processorRef.getVisualFIFO().pop(frame)) {
        hasData = true;
        latestFrame = frame;
    }

    // Risposta balistica del meter SerumV ed oscilloscopio
    const int modeIdx = meterModePushBank != nullptr ? meterModePushBank->getSelectedConsole() : 2;
    const int chIdx   = channelModePushBank != nullptr ? channelModePushBank->getSelectedConsole() : 0;

    if (hasData) {
        if (modeIdx == 0) { // IN
            serumVMeter.updateLevel(latestFrame.inRMS);
        } else if (modeIdx == 1) { // OUT
            float outSig = (chIdx == 1) ? 0.5f * (latestFrame.outRMS_L + latestFrame.outRMS_R) : // Mono
                           (chIdx == 2) ? std::abs(latestFrame.outRMS_L - latestFrame.outRMS_R) : // M/S Side
                                          std::max(latestFrame.outRMS_L, latestFrame.outRMS_R);  // Stereo Peak RMS
            serumVMeter.updateLevel(outSig);
        } else { // GR (Gain Reduction)
            float gr = (chIdx == 1) ? 0.5f * (latestFrame.gainReduction_L + latestFrame.gainReduction_R) :
                                      std::min(latestFrame.gainReduction_L, latestFrame.gainReduction_R);
            serumVMeter.updateGainReduction(std::abs(gr));
        }
    }
    scopeView.updateFrame(latestFrame, hasData);

    const float currentGR = std::max(std::abs(latestFrame.gainReduction_L), std::abs(latestFrame.gainReduction_R));
    const float targetGlow = std::clamp(currentGR / 12.0f, 0.0f, 1.0f);
    const float prevGlow = optoGlowIntensity;
    if (targetGlow > optoGlowIntensity)
        optoGlowIntensity = targetGlow;
    else
        optoGlowIntensity += (targetGlow - optoGlowIntensity) * 0.12f;

    // Repaint selettivo a dirty regions: invalida UNICAMENTE la regione della spia Opto Cell (16x16 + alone diffuso)
    // eliminando il ridisegno totale della piastra metallica di sfondo, targhette e chassis ad ogni frame (60 FPS stabilizzati)
    if (std::abs(optoGlowIntensity - prevGlow) > 0.002f) {
        const float scaleX = (float)getWidth()  / 1024.0f;
        const float scaleY = (float)getHeight() / 571.0f;
        auto lampArea = juce::Rectangle<float>(672.0f * scaleX, 291.0f * scaleY, 16.0f * scaleX, 16.0f * scaleY);
        repaint(lampArea.expanded(10.0f * scaleX, 10.0f * scaleY).toNearestInt());
    }
}

void AudioPluginAudioProcessorEditor::comboBoxChanged(juce::ComboBox* box) {
    if (box == &presetComboBox) {
        const int selectedIdx = presetComboBox.getSelectedId() - 1;
        if (selectedIdx >= 0) {
            processorRef.setCurrentProgram(selectedIdx);
        }
    }
}

void AudioPluginAudioProcessorEditor::paint(juce::Graphics& g) {
    if (backgroundImage.isValid()) {
        g.drawImage(backgroundImage, getLocalBounds().toFloat());
    } else {
        g.fillAll(juce::Colour(0xff121316));
    }

    const float scaleX = (float)getWidth()  / 1024.0f;
    const float scaleY = (float)getHeight() / 571.0f;

    auto S = [scaleX, scaleY](float x, float y, float w, float h) -> juce::Rectangle<float> {
        return { x * scaleX, y * scaleY, w * scaleX, h * scaleY };
    };

    // Helper per disegnare targhette serigrafate in ottone incise sopra ciascuna sezione
    auto drawSectionHeader = [&](const juce::Rectangle<float>& r, const juce::String& text, juce::Colour accentCol) {
        // Fondo incassato brunito
        g.setColour(juce::Colour(0xd8090b0e));
        g.fillRoundedRectangle(r, 3.0f);

        // Filetto oro satinato coordinato
        g.setColour(accentCol.withAlpha(0.55f));
        g.drawRoundedRectangle(r, 3.0f, 1.0f);

        // Testo in micro-rilievo
        g.setFont(juce::FontOptions(10.0f * scaleY, juce::Font::bold));
        g.setColour(accentCol.brighter(0.35f));
        g.drawText(text, r, juce::Justification::centred, false);
    };

    // 0. Cornice unificata dorata CNC per la Baia Sinistra Display (52, 124, 532, 158)
    auto leftBay = S(52.0f, 124.0f, 532.0f, 158.0f);
    
    // Cornice dorata con smussatura CNC (uguale all'oscilloscopio)
    juce::ColourGradient goldGrad(juce::Colour(0xfff6dc94), leftBay.getX(), leftBay.getY(),
                                  juce::Colour(0xff7a531e), leftBay.getX(), leftBay.getBottom(), false);
    goldGrad.addColour(0.35, juce::Colour(0xffdfb358));
    goldGrad.addColour(0.65, juce::Colour(0xff9e732b));
    g.setGradientFill(goldGrad);
    g.drawRoundedRectangle(leftBay.getX() + 1.0f * scaleX, leftBay.getY() + 1.0f * scaleY,
                           leftBay.getWidth() - 2.0f * scaleX, leftBay.getHeight() - 2.0f * scaleY, 6.0f, 2.5f);

    // Ombra interna d'incasso
    g.setColour(juce::Colour(0xb0000000));
    g.drawRoundedRectangle(leftBay.getX() + 3.0f * scaleX, leftBay.getY() + 3.0f * scaleY,
                           leftBay.getWidth() - 6.0f * scaleX, leftBay.getHeight() - 6.0f * scaleY, 5.0f, 2.0f);

    // Sfondo telaio ultra-nero
    g.setColour(juce::Colour(0xf405070a));
    g.fillRoundedRectangle(leftBay.getX() + 4.0f * scaleX, leftBay.getY() + 4.0f * scaleY,
                           leftBay.getWidth() - 8.0f * scaleX, leftBay.getHeight() - 8.0f * scaleY, 4.0f);

    // Divisore verticale CNC in ottone tra quadrante e controlli
    g.setColour(juce::Colour(0x35c5a059));
    g.drawVerticalLine(juce::roundToInt(334.0f * scaleX), leftBay.getY() + 8.0f * scaleY, leftBay.getBottom() - 8.0f * scaleY);

    // Didascalie serigrafate
    g.setFont(juce::FontOptions(9.0f * scaleY, juce::Font::bold));
    g.setColour(juce::Colour(0xb8c5a059));
    g.drawText("METER MODE", S(346.0f, 130.0f, 140.0f, 14.0f), juce::Justification::centredLeft, false);
    g.drawText("CHANNEL", S(346.0f, 172.0f, 140.0f, 14.0f), juce::Justification::centredLeft, false);

    // Badge oro 171 Studio SerumV in basso nel control bay
    g.setFont(juce::FontOptions(8.5f * scaleY, juce::Font::bold));
    g.setColour(juce::Colour(0xd4af37));
    g.drawText("171 SERUM-V | IEC 60268-17", S(342.0f, 258.0f, 234.0f, 16.0f), juce::Justification::centred, false);

    // 1. Targhette delle 4 sezioni funzionali
    drawSectionHeader(S(52.0f, 290.0f, 236.0f, 18.0f),  "[ 01 PREAMP & DRIVE ]",       juce::Colour(0xffffa028));
    drawSectionHeader(S(316.0f, 290.0f, 382.0f, 18.0f), "[ 02 T4B OPTICAL LEVELLER ]",  juce::Colour(0xfffed030));
    drawSectionHeader(S(726.0f, 290.0f, 124.0f, 18.0f), "[ 03 SATURATOR ]",             juce::Colour(0xffff2040));
    drawSectionHeader(S(878.0f, 290.0f, 94.0f,  18.0f), "[ 04 OUTPUT ]",                juce::Colour(0xffffd700));

    // 2. Lampada spia attiva T4B Opto Cell Jewel Lamp (reattiva in tempo reale)
    auto lampRect = S(672.0f, 291.0f, 16.0f, 16.0f);
    if (lampJewelDarkImg.isValid()) {
        g.drawImage(lampJewelDarkImg, lampRect);
    }
    if (lampJewelAmberImg.isValid() && optoGlowIntensity > 0.02f) {
        // Alone diffusivo neon ambra
        juce::Colour neonAmber = juce::Colour(0xffff9a10).withAlpha(std::clamp(optoGlowIntensity * 0.45f, 0.0f, 0.45f));
        g.setColour(neonAmber);
        g.fillEllipse(lampRect.expanded(4.0f * scaleX, 4.0f * scaleY));

        g.setOpacity(std::clamp(optoGlowIntensity, 0.0f, 1.0f));
        g.drawImage(lampJewelAmberImg, lampRect);
        g.setOpacity(1.0f);
    }

    // 3. Serigrafia footer istituzionale
    g.setFont(juce::FontOptions(10.0f * scaleY, juce::Font::bold));
    g.setColour(juce::Colour(0x80c59c52));
    g.drawText("T4 OPTICAL CELL DYNAMICS | TRI-BAND ANALOG SATURATOR | ZERO-LATENCY 64-BIT DUAL-PRECISION",
               0, juce::roundToInt(550.0f * scaleY), getWidth(), juce::roundToInt(15.0f * scaleY), juce::Justification::centred);
}

void AudioPluginAudioProcessorEditor::resized() {
    const float scaleX = (float)getWidth()  / 1024.0f;
    const float scaleY = (float)getHeight() / 571.0f;
    auto S = [scaleX, scaleY](int x, int y, int w, int h) -> juce::Rectangle<int> {
        return { juce::roundToInt(x * scaleX),
                 juce::roundToInt(y * scaleY),
                 juce::roundToInt(w * scaleX),
                 juce::roundToInt(h * scaleY) };
    };

    // 1. Menu Preset centrale in alto nella testata
    if (prevPresetBtn != nullptr) prevPresetBtn->setBounds(S(380, 18, 24, 24));
    presetComboBox.setBounds(S(407, 18, 210, 24));
    if (nextPresetBtn != nullptr) nextPresetBtn->setBounds(S(620, 18, 24, 24));

    // 2. Schermi incassati: distanziati con margine d'aria sotto i loghi
    // Baia sinistra: Modulo SerumV VU & GR Meter + Control Bay
    serumVMeter.setBounds(S(57, 129, 272, 148));
    if (meterModePushBank != nullptr) meterModePushBank->setBounds(S(346, 144, 140, 24));
    if (channelModePushBank != nullptr) channelModePushBank->setBounds(S(346, 186, 140, 24));
    if (headroomKnob != nullptr) headroomKnob->setBounds(S(496, 138, 78, 118));

    // Baia destra: Oscilloscopio / Waveform scope
    scopeView.setBounds(S(606, 124, 366, 158));

    // 3. Le 7 Manopole Superiori perfettamente proporzionate
    driveKnob->setBounds(S(108 - 45, 312, 90, 134));
    preampToneKnob->setBounds(S(244 - 45, 312, 90, 134));
    threshKnob->setBounds(S(380 - 45, 312, 90, 134));
    ratioKnob->setBounds(S(516 - 45, 312, 90, 134));
    t4MemoryKnob->setBounds(S(652 - 45, 312, 90, 134));
    satKnob->setBounds(S(788 - 45, 312, 90, 134));
    outputKnob->setBounds(S(924 - 45, 312, 90, 134));

    // 4. Controlli Inferiori: allineati alle colonne verticali delle manopole
    bypassSwitch->setBounds(S(108 - 38, 464, 76, 76));
    linkSwitch->setBounds(S(380 - 46, 464, 92, 76));
    modeSwitch->setBounds(S(516 - 46, 464, 92, 76));
    widthKnob->setBounds(S(652 - 45, 452, 90, 102));
    routingSwitch->setBounds(S(788 - 46, 464, 92, 76));
    scFilterSwitch->setBounds(S(924 - 46, 464, 92, 76));
}
