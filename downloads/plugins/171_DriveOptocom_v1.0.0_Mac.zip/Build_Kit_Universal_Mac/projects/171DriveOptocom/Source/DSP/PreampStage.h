#pragma once
#include <cmath>
#include <algorithm>
#include <dsp171/Common.h>
#include <dsp171/DCBlocker.h>
#include <dsp171/FastMath.h>

namespace dsp171 {

// =============================================================================
// Stadio di Preamplificazione Analogica di Drive Optocom
// Modellazione autentica di stadio valvolare Class-A (triodo 12AX7 / 12BH7)
// con generazione dominante di 2ª armonica pari (calore e corpo), lieve 3ª armonica,
// DC-Blocker a 64-bit e linearità trasparente.
// =============================================================================
class PreampStage {
public:
    PreampStage() = default;

    void prepare(double sampleRate, int /*samplesPerBlock*/) {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        dcBlockerInL.prepare(sampleRate, 10.0f);
        dcBlockerInR.prepare(sampleRate, 10.0f);
        dcBlockerOutL.prepare(sampleRate, 5.0f);
        dcBlockerOutR.prepare(sampleRate, 5.0f);
        reset();
    }

    void reset() noexcept {
        dcBlockerInL.reset();
        dcBlockerInR.reset();
        dcBlockerOutL.reset();
        dcBlockerOutR.reset();
    }

    void setInputDriveDb(float driveDb) noexcept {
        inputGainLinear = dsp171::fastDbToLinear(driveDb);
    }

    void setPreampTone(float tone01) noexcept {
        preampTone = std::clamp(tone01, 0.0f, 1.0f);
    }

    void setOutputGainDb(float gainDb) noexcept {
        outputGainLinear = dsp171::fastDbToLinear(gainDb);
    }

    void processPreamp(float inL, float inR, float& outL, float& outR) noexcept {
        float l = inL * inputGainLinear;
        float r = inR * inputGainLinear;

        // Rimozione DC in ingresso
        l = dcBlockerInL.processSample(l);
        r = dcBlockerInR.processSample(r);

        // Saturazione e calore valvolare Class-A autentico
        if (preampTone > 0.001f) {
            const float k2 = 0.22f * preampTone; // 2ª armonica calda valvolare
            const float k3 = 0.06f * preampTone; // Lieve compressione di 3ª

            // Trasferimento non-lineare asimmetrico: y = x + k2 * x^2 - k3 * x^3
            const float satRawL = l + k2 * (l * l) - k3 * (l * l * l);
            const float satRawR = r + k2 * (r * r) - k3 * (r * r * r);

            // Rimozione offset generato dall'asimmetria pari
            const float satCleanL = dcBlockerOutL.processSample(satRawL);
            const float satCleanR = dcBlockerOutR.processSample(satRawR);

            const float mix = preampTone * 0.85f;
            l = (1.0f - mix) * l + mix * satCleanL;
            r = (1.0f - mix) * r + mix * satCleanR;
        }

        outL = l;
        outR = r;
    }

    void processOutput(float inL, float inR, float& outL, float& outR) noexcept {
        outL = inL * outputGainLinear;
        outR = inR * outputGainLinear;
    }

private:
    float sr = 44100.0f;
    float inputGainLinear = 1.0f;
    float preampTone = 0.25f;
    float outputGainLinear = 1.0f;

    DCBlocker dcBlockerInL;
    DCBlocker dcBlockerInR;
    DCBlocker dcBlockerOutL;
    DCBlocker dcBlockerOutR;
};

} // namespace dsp171
