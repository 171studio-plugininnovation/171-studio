#pragma once
#include <cmath>
#include <algorithm>
#include <juce_dsp/juce_dsp.h>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include <dsp171/DCBlocker.h>

namespace dsp171 {

// =============================================================================
// Saturatore Tri-Banda Analogico con Crossover Linkwitz-Riley LR-4 Rigoroso a Fase Coerente
// Elimina alla radice qualsiasi cancellazione o buco di fase nel blend Dry/Wet
// grazie all'allineamento allpass del ramo basse.
// Fisica differenziata per banda:
// - Low Band: Saturazione trasformatore / nucleo di ferro (2ª + 3ª armonica, corpo solido)
// - Mid Band: Calore valvolare Class-A triodo (2ª armonica setosa, presenza vocale)
// - High Band: Compressione e setosità da nastro analogico (tape silk air)
// =============================================================================
class TriBandSaturator {
public:
    TriBandSaturator() = default;

    void prepare(double sampleRate, int /*samplesPerBlock*/) {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        updateFilters();

        dcBlockerLowL.prepare(sampleRate, 10.0f);
        dcBlockerLowR.prepare(sampleRate, 10.0f);
        dcBlockerMidL.prepare(sampleRate, 15.0f);
        dcBlockerMidR.prepare(sampleRate, 15.0f);

        reset();
    }

    void reset() noexcept {
        // Crossover 1 (200 Hz)
        lowPass1aL.reset(); lowPass1bL.reset();
        lowPass1aR.reset(); lowPass1bR.reset();
        highPass1aL.reset(); highPass1bL.reset();
        highPass1aR.reset(); highPass1bR.reset();

        // Crossover 2 (2500 Hz)
        lowPass2aL.reset(); lowPass2bL.reset();
        lowPass2aR.reset(); lowPass2bR.reset();
        highPass2aL.reset(); highPass2bL.reset();
        highPass2aR.reset(); highPass2bR.reset();

        // Rete Allpass di allineamento fase a 2500 Hz per il ramo basse
        lowPass2aL_low.reset(); lowPass2bL_low.reset();
        lowPass2aR_low.reset(); lowPass2bR_low.reset();
        highPass2aL_low.reset(); highPass2bL_low.reset();
        highPass2aR_low.reset(); highPass2bR_low.reset();

        dcBlockerLowL.reset(); dcBlockerLowR.reset();
        dcBlockerMidL.reset(); dcBlockerMidR.reset();
    }

    void setSaturation(float amount01) noexcept {
        saturationAmount = std::clamp(amount01, 0.0f, 1.0f);
    }

    void processStereo(float inL, float inR, float& outL, float& outR) noexcept {
        // ==============================================================================
        // 1. Crossover Linkwitz-Riley LR-4 (200 Hz): Separa Low da (Mid + High)
        // ==============================================================================
        const float lowL_raw = lowPass1bL.processSample(lowPass1aL.processSample(inL));
        const float lowR_raw = lowPass1bR.processSample(lowPass1aR.processSample(inR));
        const float midHighL = highPass1bL.processSample(highPass1aL.processSample(inL));
        const float midHighR = highPass1bR.processSample(highPass1aR.processSample(inR));

        // ==============================================================================
        // 2. Crossover Linkwitz-Riley LR-4 (2500 Hz): Separa Mid da High
        // ==============================================================================
        const float midL = lowPass2bL.processSample(lowPass2aL.processSample(midHighL));
        const float midR = lowPass2bR.processSample(lowPass2aR.processSample(midHighR));
        const float highL = highPass2bL.processSample(highPass2aL.processSample(midHighL));
        const float highR = highPass2bR.processSample(highPass2aR.processSample(midHighR));

        // ==============================================================================
        // 3. Allineamento di Fase Matematico del Ramo Basse
        // Applica l'allpass AP2 (LP2 + HP2 a 2500 Hz) a lowL per garantire che
        // |lowL_aligned + midL + highL| == 1.00000000 su tutte le frequenze!
        // ==============================================================================
        const float lowL = lowPass2bL_low.processSample(lowPass2aL_low.processSample(lowL_raw))
                         + highPass2bL_low.processSample(highPass2aL_low.processSample(lowL_raw));
        const float lowR = lowPass2bR_low.processSample(lowPass2aR_low.processSample(lowR_raw))
                         + highPass2bR_low.processSample(highPass2aR_low.processSample(lowR_raw));

        const float cleanL = lowL + midL + highL;
        const float cleanR = lowR + midR + highR;

        if (saturationAmount <= 0.001f) {
            outL = cleanL;
            outR = cleanR;
            return;
        }

        // ==============================================================================
        // 4. Saturazione Analogica Differenziata per Banda
        // ==============================================================================

        // --- BANDA BASSA (<200 Hz): Saturazione Trasformatore / Flusso Magnetico ---
        // Generazione armonici pari e dispari controllati con saturazione graduale
        const float driveLow = 1.0f + saturationAmount * 2.8f;
        auto satTransformer = [](float x, float drive) -> float {
            const float xd = x * drive;
            // Curva asimmetrica di saturazione magnetica del ferro
            const float num = xd + 0.14f * (xd * xd);
            const float den = 1.0f + 0.14f * std::abs(xd) + 0.25f * (xd * xd);
            return num / den;
        };
        const float satLowRawL = satTransformer(lowL, driveLow);
        const float satLowRawR = satTransformer(lowR, driveLow);
        const float satLowL = dcBlockerLowL.processSample(satLowRawL);
        const float satLowR = dcBlockerLowR.processSample(satLowRawR);

        // --- BANDA MEDIA (200 - 2500 Hz): Calore Valvolare Triodo Class-A ---
        // 2ª armonica dominante (corpo e calore) + leggera 3ª
        const float driveMid = 1.0f + saturationAmount * 3.2f;
        auto satTubeMid = [](float x, float drive) -> float {
            const float xd = x * drive;
            constexpr float k2 = 0.20f;
            constexpr float k3 = 0.06f;
            return xd + k2 * (xd * xd) - k3 * (xd * xd * xd);
        };
        const float satMidRawL = satTubeMid(midL, driveMid);
        const float satMidRawR = satTubeMid(midR, driveMid);
        const float satMidL = dcBlockerMidL.processSample(satMidRawL);
        const float satMidR = dcBlockerMidR.processSample(satMidRawR);

        // --- BANDA ALTA (>2500 Hz): Tape Silk Sheen ---
        // Saturazione morbida per aria setosa senza asprezze o buzz di diodi
        const float driveHigh = 1.0f + saturationAmount * 2.2f;
        auto satTapeHigh = [](float x, float drive) -> float {
            const float xd = x * drive;
            return std::tanh(xd);
        };
        const float satHighL = satTapeHigh(highL, driveHigh);
        const float satHighR = satTapeHigh(highR, driveHigh);

        // 5. Somma Wet delle 3 bande
        const float wetL = satLowL + satMidL + satHighL;
        const float wetR = satLowR + satMidR + satHighR;

        // 6. Blending Dry/Wet a fase coerente
        const float wetMix = std::min(1.0f, saturationAmount * 1.25f);
        outL = (1.0f - wetMix) * cleanL + wetMix * wetL;
        outR = (1.0f - wetMix) * cleanR + wetMix * wetR;
    }

private:
    void updateFilters() {
        if (sr > 1000.0f) {
            auto lp1 = juce::dsp::IIR::Coefficients<float>::makeLowPass(sr, 200.0f, 0.7071f);
            auto hp1 = juce::dsp::IIR::Coefficients<float>::makeHighPass(sr, 200.0f, 0.7071f);
            auto lp2 = juce::dsp::IIR::Coefficients<float>::makeLowPass(sr, 2500.0f, 0.7071f);
            auto hp2 = juce::dsp::IIR::Coefficients<float>::makeHighPass(sr, 2500.0f, 0.7071f);

            lowPass1aL.coefficients = lp1; lowPass1bL.coefficients = lp1;
            lowPass1aR.coefficients = lp1; lowPass1bR.coefficients = lp1;
            highPass1aL.coefficients = hp1; highPass1bL.coefficients = hp1;
            highPass1aR.coefficients = hp1; highPass1bR.coefficients = hp1;

            lowPass2aL.coefficients = lp2; lowPass2bL.coefficients = lp2;
            lowPass2aR.coefficients = lp2; lowPass2bR.coefficients = lp2;
            highPass2aL.coefficients = hp2; highPass2bL.coefficients = hp2;
            highPass2aR.coefficients = hp2; highPass2bR.coefficients = hp2;

            lowPass2aL_low.coefficients = lp2; lowPass2bL_low.coefficients = lp2;
            lowPass2aR_low.coefficients = lp2; lowPass2bR_low.coefficients = lp2;
            highPass2aL_low.coefficients = hp2; highPass2bL_low.coefficients = hp2;
            highPass2aR_low.coefficients = hp2; highPass2bR_low.coefficients = hp2;
        }
    }

    float sr = 44100.0f;
    float saturationAmount = 0.0f;

    // Crossover 1 (200 Hz): LR-4
    juce::dsp::IIR::Filter<float> lowPass1aL, lowPass1bL;
    juce::dsp::IIR::Filter<float> lowPass1aR, lowPass1bR;
    juce::dsp::IIR::Filter<float> highPass1aL, highPass1bL;
    juce::dsp::IIR::Filter<float> highPass1aR, highPass1bR;

    // Crossover 2 (2500 Hz): LR-4
    juce::dsp::IIR::Filter<float> lowPass2aL, lowPass2bL;
    juce::dsp::IIR::Filter<float> lowPass2aR, lowPass2bR;
    juce::dsp::IIR::Filter<float> highPass2aL, highPass2bL;
    juce::dsp::IIR::Filter<float> highPass2aR, highPass2bR;

    // Rete allpass a 2500 Hz per il ramo basse
    juce::dsp::IIR::Filter<float> lowPass2aL_low, lowPass2bL_low;
    juce::dsp::IIR::Filter<float> lowPass2aR_low, lowPass2bR_low;
    juce::dsp::IIR::Filter<float> highPass2aL_low, highPass2bL_low;
    juce::dsp::IIR::Filter<float> highPass2aR_low, highPass2bR_low;

    DCBlocker dcBlockerLowL, dcBlockerLowR;
    DCBlocker dcBlockerMidL, dcBlockerMidR;
};

} // namespace dsp171
