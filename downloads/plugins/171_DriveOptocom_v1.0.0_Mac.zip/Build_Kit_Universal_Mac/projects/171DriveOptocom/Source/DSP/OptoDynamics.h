#pragma once
#include <cmath>
#include <algorithm>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include <dsp171/ZDFSVF.h>

namespace dsp171 {

// =============================================================================
// Motore di Compressione Opto-Dinamica (Modellazione Teletronix T4B / LA-2A)
// Fisica autentica a doppio stato fotoconduttivo (fast/slow dual-trap recombination),
// isteresi chimica di memoria, filtro Sidechain HPF ZDF a 64-bit e phase-lock stereo.
// =============================================================================
class OptoDynamics {
public:
    OptoDynamics() = default;

    void prepare(double sampleRate, int /*samplesPerBlock*/) {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        dt = 1.0f / sr;

        recalculateCoefficients();
        updateSidechainFilter();
        reset();
    }

    void reset() noexcept {
        cellL = {};
        cellR = {};
        currentGRL_dB = 0.0f;
        currentGRR_dB = 0.0f;
        scFilterL.reset();
        scFilterR.reset();
    }

    void setParameters(float thresholdDb, float ratioVal, float memoryAmount01,
                       bool sidechainHpf, bool stereoLink, bool fastPunchMode) noexcept
    {
        threshold = thresholdDb;
        ratio = std::max(1.0f, ratioVal);
        scHpfEnabled = sidechainHpf;
        linked = stereoLink;
        punchMode = fastPunchMode;
        t4MemoryScale = std::clamp(memoryAmount01, 0.0f, 1.0f);

        if (punchMode != lastPunchMode || std::abs(t4MemoryScale - lastT4Memory) > 0.002f) {
            recalculateCoefficients();
        }
    }

    // Conversione veloce e accurata da ampiezza a dB
    static inline float fastGainToDb(float g) noexcept {
        if (g <= 1.0e-6f) return -120.0f;
        union { float f; uint32_t i; } u = { g };
        const int exp = static_cast<int>((u.i >> 23) & 0xFF) - 127;
        u.i = (u.i & 0x007FFFFF) | 0x3F800000;
        const float m = u.f - 1.0f;
        const float log2Val = static_cast<float>(exp) + m * (1.442695f - 0.442695f * m);
        return log2Val * 6.020599913279624f;
    }

    void processSample(float inL, float inR, float& outL, float& outR, float& grL_dB, float& grR_dB) noexcept {
        float scL = inL;
        float scR = inR;

        // 1. Sidechain HPF 100 Hz ZDF a 64-bit (rimuove il pompaggio da sub-basse)
        if (scHpfEnabled) {
            scL = static_cast<float>(scFilterL.process(scL).hp);
            scR = static_cast<float>(scFilterR.process(scR).hp);
        }

        float levelL = std::abs(scL);
        float levelR = std::abs(scR);

        // 2. Calcolo Gain Reduction con autentico modello T4B a 2 stadi
        float grL = 0.0f;
        float grR = 0.0f;

        if (linked) {
            // Stereo linking rigoroso: pilotaggio comune della cella fotoconduttiva
            const float maxLevel = std::max(levelL, levelR);
            grL = updatePhotocell(maxLevel, cellL);
            cellR = cellL; // Sincronizzazione bit-exact dei due canali
            grR = grL;
        } else {
            // Dual mono indipendente
            grL = updatePhotocell(levelL, cellL);
            grR = updatePhotocell(levelR, cellR);
        }

        currentGRL_dB = -grL;
        currentGRR_dB = -grR;

        // 3. Applicazione del guadagno ottico non-lineare
        const float gainLinearL = dsp171::fastDbToLinear(-grL);
        const float gainLinearR = dsp171::fastDbToLinear(-grR);

        outL = inL * gainLinearL;
        outR = inR * gainLinearR;

        grL_dB = currentGRL_dB;
        grR_dB = currentGRR_dB;
    }

    float getCurrentGRL_dB() const noexcept { return currentGRL_dB; }
    float getCurrentGRR_dB() const noexcept { return currentGRR_dB; }

private:
    struct PhotocellState {
        float envFast = 0.0f; // Risposta termica primaria veloce (~60 ms)
        float envSlow = 0.0f; // Rilascio fotochimico profondo (0.5s - 5s)
        float memory  = 0.0f; // Carica fotochimica accumulata (isteresi CdS)
    };

    float updatePhotocell(float inputLevel, PhotocellState& cell) noexcept {
        const float targetDb = fastGainToDb(inputLevel);
        const float overDb = targetDb - threshold;

        float desiredReduction = 0.0f;
        constexpr float kneeWidth = 5.0f;

        if (overDb <= -kneeWidth * 0.5f) {
            desiredReduction = 0.0f;
        } else if (overDb >= kneeWidth * 0.5f) {
            desiredReduction = overDb * (1.0f - 1.0f / ratio);
        } else {
            const float x = overDb + kneeWidth * 0.5f;
            desiredReduction = (1.0f - 1.0f / ratio) * (x * x) / (2.0f * kneeWidth);
        }

        // --- ATTACCO ELETTROLUMINESCENTE ---
        if (desiredReduction > cell.envFast) {
            cell.envFast += (1.0f - attackCoeffFast) * (desiredReduction - cell.envFast);
            cell.envSlow += (1.0f - attackCoeffSlow) * (desiredReduction - cell.envSlow);
            cell.memory   = std::min(24.0f, cell.memory + dt * (1.2f + t4MemoryScale * 2.8f) * desiredReduction);
        }
        // --- RILASCIO FOTOCELLULA CdS CON ISTERESI DI MEMORIA ---
        else {
            cell.envFast += (1.0f - releaseCoeffFast) * (desiredReduction - cell.envFast);
            cell.envSlow += (1.0f - releaseCoeffSlow) * (desiredReduction - cell.envSlow);
            cell.memory   = std::max(0.0f, cell.memory - dt * (punchMode ? 3.0f : 1.2f));
        }

        // Miscela dual-stage in base alla carica fotochimica accumulata
        const float chargeNorm = std::clamp(cell.memory / 12.0f, 0.0f, 1.0f);
        const float slowWeight = punchMode ? (0.15f + 0.35f * chargeNorm * t4MemoryScale)
                                           : (0.30f + 0.55f * chargeNorm * t4MemoryScale);

        const float totalReduction = (1.0f - slowWeight) * cell.envFast + slowWeight * cell.envSlow;
        return totalReduction;
    }

    void recalculateCoefficients() noexcept {
        // Attacco veloce del pannello elettroluminescente: ~1.5ms in Punch, ~10ms in Classic
        const float attackMs = punchMode ? 1.5f : 10.0f;
        const float attSecFast = attackMs * 0.001f;
        const float attXFast = dt / attSecFast;
        attackCoeffFast = 1.0f - attXFast * (1.0f - 0.5f * attXFast);

        const float attSecSlow = std::max(attSecFast * 2.5f, 0.025f);
        const float attXSlow = dt / attSecSlow;
        attackCoeffSlow = 1.0f - attXSlow * (1.0f - 0.5f * attXSlow);

        // Rilascio primario veloce: ~60ms (la tipica prima metà del rilascio LA-2A)
        const float relSecFast = punchMode ? 0.040f : 0.065f;
        const float relXFast = dt / relSecFast;
        releaseCoeffFast = 1.0f - relXFast * (1.0f - 0.5f * relXFast);

        // Rilascio secondario lento a memoria profonda: 0.8s fino a 4.5s
        const float slowDecaySec = 0.8f + t4MemoryScale * 3.7f;
        const float relXSlow = dt / slowDecaySec;
        releaseCoeffSlow = 1.0f - relXSlow * (1.0f - 0.5f * relXSlow);

        lastPunchMode = punchMode;
        lastT4Memory = t4MemoryScale;
    }

    void updateSidechainFilter() {
        if (sr > 1000.0f) {
            scFilterL.setParameters(100.0f, 0.7071f, sr);
            scFilterR.setParameters(100.0f, 0.7071f, sr);
        }
    }

    float sr = 44100.0f;
    float dt = 1.0f / 44100.0f;

    float threshold = -18.0f;
    float ratio = 3.0f;
    float t4MemoryScale = 0.50f;

    float attackCoeffFast  = 0.95f;
    float attackCoeffSlow  = 0.98f;
    float releaseCoeffFast = 0.99f;
    float releaseCoeffSlow = 0.999f;

    bool lastPunchMode = false;
    float lastT4Memory = -1.0f;

    bool scHpfEnabled = true;
    bool linked = true;
    bool punchMode = false;

    PhotocellState cellL{};
    PhotocellState cellR{};

    float currentGRL_dB = 0.0f;
    float currentGRR_dB = 0.0f;

    ZDFSVF64 scFilterL;
    ZDFSVF64 scFilterR;
};

} // namespace dsp171
