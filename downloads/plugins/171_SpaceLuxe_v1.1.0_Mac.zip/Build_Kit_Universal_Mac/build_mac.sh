#!/usr/bin/env bash
# ==============================================================================
# 171 STUDIO INNOVATIO - DIVISIONE MAC
# Pipeline di Build Dedicata per 171 SpaceLuxe (Boutique Hybrid Reverb & Space Sculptor)
# Universal Binary Fat: Apple Silicon (ARM64: M1-M4) & Intel (x86_64)
# Formati: AudioUnit v2 (.component), VST3 (.vst3), Standalone (.app)
# ==============================================================================

set -euo pipefail

BOLD="\033[1m"
GREEN="\033[0;32m"
CYAN="\033[0;36m"
YELLOW="\033[1;33m"
RED="\033[0;31m"
MAGENTA="\033[0;35m"
RESET="\033[0m"

echo -e "${CYAN}${BOLD}====================================================================${RESET}"
echo -e "${YELLOW}${BOLD} 🌌 171 STUDIO INNOVATIO — 171 SPACELUXE macOS BUILD PIPELINE       ${RESET}"
echo -e "${CYAN}${BOLD}====================================================================${RESET}"

if [[ "$(uname -s)" != "Darwin" ]]; then
    echo -e "${RED}[ERRORE] Questo script deve essere eseguito su ambiente macOS (Darwin).${RESET}"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAC_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
ROOT_DIR="$(cd "${MAC_DIR}/.." && pwd)"
PROJECTS_DIR="${ROOT_DIR}/projects"
DIST_DIR="${MAC_DIR}/dist"
ENTITLEMENTS_FILE="${MAC_DIR}/config/entitlements.plist"

BUILD_CONFIG="Release"
SIGN_IDENTITY=""
DO_INSTALL=true
DO_AUVAL=true
CMAKE_GENERATOR="Ninja"

if ! command -v ninja &> /dev/null; then
    CMAKE_GENERATOR="Xcode"
fi

while [[ $# -gt 0 ]]; do
    case "$1" in
        --config)
            BUILD_CONFIG="$2"
            shift 2
            ;;
        --sign)
            SIGN_IDENTITY="$2"
            shift 2
            ;;
        --no-install)
            DO_INSTALL=false
            shift
            ;;
        --no-auval)
            DO_AUVAL=false
            shift
            ;;
        --generator)
            CMAKE_GENERATOR="$2"
            shift 2
            ;;
        --help|-h)
            echo "Uso: ./build_171spaceluxe_mac.sh [opzioni]"
            echo ""
            echo "Opzioni:"
            echo "  --config <Release|Debug>    Configurazione di compilazione (default: Release)"
            echo "  --sign \"<Identity>\"         Firma con Developer ID Application"
            echo "  --no-install                Non installare nei plugin utente"
            echo "  --no-auval                  Salta la validazione con auval"
            exit 0
            ;;
        *)
            shift
            ;;
    esac
done

echo -e " Configurazione:  ${GREEN}${BUILD_CONFIG}${RESET}"
echo -e " Generatore:      ${GREEN}${CMAKE_GENERATOR}${RESET}"
echo -e " Installazione:   ${GREEN}${DO_INSTALL}${RESET}"
echo -e " Test auval:      ${GREEN}${DO_AUVAL}${RESET}"
echo -e "${CYAN}--------------------------------------------------------------------${RESET}"

BUILD_DIR="${MAC_DIR}/build_cache/171SpaceLuxe"
mkdir -p "${BUILD_DIR}"
mkdir -p "${DIST_DIR}/Components" "${DIST_DIR}/VST3" "${DIST_DIR}/Standalone"

# 1. Configurazione CMake per 171SpaceLuxe Universal Binary
echo -e "\n${CYAN}[1/4] Configurazione CMake Universal (arm64 + x86_64)...${RESET}"
cmake -B "${BUILD_DIR}" \
      -S "${PROJECTS_DIR}/171SpaceLuxe" \
      -G "${CMAKE_GENERATOR}" \
      -DCMAKE_BUILD_TYPE="${BUILD_CONFIG}" \
      -DCMAKE_OSX_ARCHITECTURES="arm64;x86_64" \
      -DCMAKE_OSX_DEPLOYMENT_TARGET="11.0"

# 2. Compilazione dei Target (AU, VST3, Standalone)
echo -e "\n${GREEN}[2/4] Compilazione ad alte prestazioni di 171SpaceLuxe...${RESET}"
cmake --build "${BUILD_DIR}" --config "${BUILD_CONFIG}" --target 171SpaceLuxe_AU 171SpaceLuxe_VST3 171SpaceLuxe_Standalone --parallel $(sysctl -n hw.ncpu)

# 3. Raccolta Artefatti
echo -e "\n${CYAN}[3/4] Raccolta Bundle e Archiviazione in dist/...${RESET}"
AU_PATH=$(find "${BUILD_DIR}" -name "171SpaceLuxe.component" -type d | head -n 1)
VST3_PATH=$(find "${BUILD_DIR}" -name "171SpaceLuxe.vst3" -type d | head -n 1)
APP_PATH=$(find "${BUILD_DIR}" -name "171SpaceLuxe.app" -type d | head -n 1)

if [[ -n "${AU_PATH}" ]]; then
    cp -R "${AU_PATH}" "${DIST_DIR}/Components/"
    echo -e " -> ${GREEN}AudioUnit (.component) pronto in dist/Components/${RESET}"
fi

if [[ -n "${VST3_PATH}" ]]; then
    cp -R "${VST3_PATH}" "${DIST_DIR}/VST3/"
    echo -e " -> ${GREEN}VST3 (.vst3) pronto in dist/VST3/${RESET}"
fi

if [[ -n "${APP_PATH}" ]]; then
    cp -R "${APP_PATH}" "${DIST_DIR}/Standalone/"
    echo -e " -> ${GREEN}Standalone (.app) pronto in dist/Standalone/${RESET}"
fi

# Firma opzionale
if [[ -n "${SIGN_IDENTITY}" ]]; then
    echo -e "\n${YELLOW}[CODESIGN] Applicazione firma Hardened Runtime...${RESET}"
    codesign --force --timestamp --options runtime --entitlements "${ENTITLEMENTS_FILE}" --sign "${SIGN_IDENTITY}" "${DIST_DIR}/Components/171SpaceLuxe.component"
    codesign --force --timestamp --options runtime --entitlements "${ENTITLEMENTS_FILE}" --sign "${SIGN_IDENTITY}" "${DIST_DIR}/VST3/171SpaceLuxe.vst3"
    codesign --force --timestamp --options runtime --entitlements "${ENTITLEMENTS_FILE}" --sign "${SIGN_IDENTITY}" "${DIST_DIR}/Standalone/171SpaceLuxe.app"
fi

# 4. Installazione Locale
if [[ "${DO_INSTALL}" == true ]]; then
    echo -e "\n${CYAN}[4/4] Installazione automatica nelle cartelle DAW di sistema...${RESET}"
    USER_COMP="${HOME}/Library/Audio/Plug-Ins/Components"
    USER_VST3="${HOME}/Library/Audio/Plug-Ins/VST3"
    mkdir -p "${USER_COMP}" "${USER_VST3}"

    cp -R "${DIST_DIR}/Components/171SpaceLuxe.component" "${USER_COMP}/"
    cp -R "${DIST_DIR}/VST3/171SpaceLuxe.vst3" "${USER_VST3}/"
    echo -e " -> ${GREEN}Installato in ${USER_COMP}/171SpaceLuxe.component${RESET}"
    echo -e " -> ${GREEN}Installato in ${USER_VST3}/171SpaceLuxe.vst3${RESET}"
fi

# Validazione auval per Logic Pro
if [[ "${DO_AUVAL}" == true ]]; then
    echo -e "\n${MAGENTA}[AUVAL] Validazione AudioUnit per Logic Pro (auval -v aufx 171L 171P)...${RESET}"
    killall -9 AudioComponentRegistrar 2>/dev/null || true
    auval -v aufx 171L 171P || {
        echo -e "${YELLOW}[INFO] Se il test fallisce in terminale headless, verificalo all'avvio di Logic Pro.${RESET}"
    }
fi

echo -e "\n${GREEN}${BOLD}====================================================================${RESET}"
echo -e "${GREEN}${BOLD} 🎉 171 SPACELUXE TRASPOSTO E COMPILATO CON SUCCESSO PER macOS!      ${RESET}"
echo -e "${GREEN}${BOLD}====================================================================${RESET}"
