#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include "DSP/SpaceLuxeEngine.h"
#include <atomic>

class AudioPluginAudioProcessor : public juce::AudioProcessor {
public:
    AudioPluginAudioProcessor();
    ~AudioPluginAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;

    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "171SpaceLuxe"; }

    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 20.0; }

    int getNumPrograms() override { return 5; }
    int getCurrentProgram() override { return currentProgram; }
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() { return apvts; }

    // Telemetria visuale thread-safe per la GUI a 60 FPS
    float getVisualLowEnergy() const noexcept { return visualLowEnergy.load(std::memory_order_relaxed); }
    float getVisualMidEnergy() const noexcept { return visualMidEnergy.load(std::memory_order_relaxed); }
    float getVisualHighEnergy() const noexcept { return visualHighEnergy.load(std::memory_order_relaxed); }
    float getVisualDuckingReduction() const noexcept { return visualDuckingReduction.load(std::memory_order_relaxed); }
    float getVisualBloomGain() const noexcept { return visualBloomGain.load(std::memory_order_relaxed); }
    bool isVisualDuckingActive() const noexcept { return visualDuckingActive.load(std::memory_order_relaxed); }
    bool isVisualBloomActive() const noexcept { return visualBloomActive.load(std::memory_order_relaxed); }
    bool isVisualSidechainExternal() const noexcept { return visualSidechainExternal.load(std::memory_order_relaxed); }

private:
    juce::AudioProcessorValueTreeState apvts;
    juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    dsp171::SpaceLuxeEngine engine;
    int currentProgram = 0;

    std::atomic<float> visualLowEnergy { 0.0f };
    std::atomic<float> visualMidEnergy { 0.0f };
    std::atomic<float> visualHighEnergy { 0.0f };
    std::atomic<float> visualDuckingReduction { 0.0f };
    std::atomic<float> visualBloomGain { 0.0f };
    std::atomic<bool> visualDuckingActive { false };
    std::atomic<bool> visualBloomActive { false };
    std::atomic<bool> visualSidechainExternal { false };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AudioPluginAudioProcessor)
};
