#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <chrono>
#include <cmath>
#include <fstream>
#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_formats/juce_audio_formats.h>
#include "../DSP/SpaceLuxeEngine.h"
#include "dsp171/DSPHireManager.h"

struct TestTrackSpec {
    std::string name;
    std::string category;
    std::string relativePath;
    std::string outputFilename;
    float preDelayMs;
    float decaySec;
    float roomSize;
    float highDampingHz;
    float lowWarmthDb;
    float shimmerAmount;
    float duckAmountPercent;
    float tailBloomDb;
    bool autoSense;
    bool spectralFocus;
    float stereoWidth;
    float monoMakerHz;
    float dryWetMix;
};

int main(int argc, char* argv[]) {
    juce::ignoreUnused(argc, argv);

    std::cout << "====================================================================\n";
    std::cout << "  171SPACELUXE - MULTI-AUDIO DIVERSE STEMS AUDIT & ENGINE STRESS   \n";
    std::cout << "  Orchestrato con DSPHireManager (8 Agenti Specializzati)          \n";
    std::cout << "====================================================================\n\n";

    // Inizializza DSP Hire Manager
    dsp171::DevelopmentVariables vars;
    vars.task = dsp171::DomainTask::SpatialReverbPhysical;
    vars.latencyTolerance = dsp171::LatencyTolerance::ZeroLatencyLive_0ms;
    auto dispatch = dsp171::DSPHireManager::dispatch(vars);

    std::cout << "[DSP HIRE MANAGER] Dispatch Convocato:\n";
    std::cout << " - Primary Specialist: " << dispatch.primaryAgent.agentId << " (" << dispatch.primaryAgent.agentTitle << ")\n";
    std::cout << " - Technical Reviewer: " << dispatch.reviewerAgent.agentId << " (" << dispatch.reviewerAgent.agentTitle << ")\n";
    std::cout << " - QA Lead Auditor:   " << dispatch.qaAuditorAgent.agentId << "\n";
    std::cout << " - C++ Engine Module: " << dispatch.recommendedCPlusPlusClass << "\n\n";

    // Setup JUCE Audio Format Manager
    juce::AudioFormatManager formatManager;
    formatManager.registerBasicFormats();

    // Directory di output per gli stem processati
    juce::File currentDir = juce::File::getCurrentWorkingDirectory();
    // Risaliamo se siamo nella cartella build
    juce::File rootDir = currentDir;
    while (!rootDir.getChildFile("projects").exists() && rootDir.getParentDirectory() != rootDir) {
        rootDir = rootDir.getParentDirectory();
    }

    juce::File outputDir = rootDir.getChildFile("tools-and-analysis")
                                  .getChildFile("audit-outputs")
                                  .getChildFile("171SpaceLuxe_MultiAudio_Audit");
    outputDir.createDirectory();

    std::cout << "[*] Cartella di output audio audit:\n    " << outputDir.getFullPathName().toStdString() << "\n\n";

    // Specifiche dei 5 brani di prova diversificati
    std::vector<TestTrackSpec> specs = {
        {
            "Track 1 - Rap/Trap Vocal Stem (Maurito)",
            "Vocal / Dynamic Lead",
            "tools-and-analysis/audit-outputs/171_PerfectPre_Audit_Stems/MAURITO_08-230312_1223-01.wav",
            "01_vocal_maurito_spaceluxe.wav",
            24.0f, 2.3f, 1.0f, 7500.0f, 1.5f, 0.0f, 65.0f, 3.5f, true, true, 1.25f, 120.0f, 0.38f
        },
        {
            "Track 2 - Electric Guitar & Amp",
            "Electric Guitar / Transients & Chords",
            "projects/171CleanDrive/build/_deps/juce-src/examples/Assets/guitar_amp.wav",
            "02_guitar_amp_spaceluxe.wav",
            30.0f, 3.8f, 1.4f, 6000.0f, 0.0f, 0.25f, 20.0f, 1.5f, false, false, 1.40f, 150.0f, 0.40f
        },
        {
            "Track 3 - Bowed Cello / Low Strings",
            "Acoustic Strings / Low Resonance",
            "projects/171CleanDrive/build/_deps/juce-src/examples/Assets/cello.wav",
            "03_cello_strings_spaceluxe.wav",
            28.0f, 3.0f, 1.2f, 8500.0f, 3.5f, 0.0f, 0.0f, 0.0f, false, false, 1.10f, 100.0f, 0.32f
        },
        {
            "Track 4 - Dynamic Percussive Bursts",
            "Percussion / Fast Transients & Ballistics",
            "tools-and-analysis/stimuli/04_dynamic_burst_ballistics.wav",
            "04_percussion_burst_spaceluxe.wav",
            8.0f, 0.85f, 0.7f, 5000.0f, -2.5f, 0.0f, 0.0f, 0.0f, false, false, 1.00f, 200.0f, 0.30f
        },
        {
            "Track 5 - Melodic Vocal Shimmer Cathedral (Adriano)",
            "Vocal / Sustained Melodic + Octave Shimmer",
            "tools-and-analysis/audit-outputs/171_PerfectPre_Audit_Stems/ADRIANO_02-240110_1148.wav",
            "05_vocal_adriano_shimmer.wav",
            42.0f, 5.5f, 1.8f, 11000.0f, 1.0f, 0.45f, 50.0f, 4.0f, true, true, 1.60f, 130.0f, 0.45f
        }
    };

    struct TrackResult {
        std::string name;
        std::string category;
        double sampleRate = 48000.0;
        int numSamples = 0;
        double durationSec = 0.0;
        double processingTimeMs = 0.0;
        double speedupRatio = 0.0;
        float inPeakDb = -100.0f;
        float inRmsDb = -100.0f;
        float outPeakDb = -100.0f;
        float outRmsDb = -100.0f;
        float maxDuckingGR = 0.0f;
        float maxTailBloom = 0.0f;
        bool hasNanInf = false;
        std::string status;
    };

    std::vector<TrackResult> results;

    for (size_t tIdx = 0; tIdx < specs.size(); ++tIdx) {
        const auto& spec = specs[tIdx];
        std::cout << "--------------------------------------------------------------------\n";
        std::cout << "[*] Esecuzione " << spec.name << "\n";
        std::cout << "    Categoria: " << spec.category << "\n";

        juce::File inputFile = rootDir.getChildFile(spec.relativePath);
        if (!inputFile.existsAsFile()) {
            std::cerr << "    [ERRORE] File audio non trovato: " << inputFile.getFullPathName().toStdString() << "\n";
            TrackResult r;
            r.name = spec.name;
            r.category = spec.category;
            r.status = "FILE NON TROVATO";
            results.push_back(r);
            continue;
        }

        std::unique_ptr<juce::AudioFormatReader> reader(formatManager.createReaderFor(inputFile));
        if (reader == nullptr) {
            std::cerr << "    [ERRORE] Impossibile decodificare formato audio: " << inputFile.getFullPathName().toStdString() << "\n";
            continue;
        }

        const int numChannels = static_cast<int>(reader->numChannels);
        const int numSamples = static_cast<int>(reader->lengthInSamples);
        const double sampleRate = reader->sampleRate;
        const double durationSec = static_cast<double>(numSamples) / sampleRate;

        std::cout << "    Formato: " << numChannels << " ch, " << sampleRate << " Hz, "
                  << numSamples << " samples (" << std::fixed << std::setprecision(2) << durationSec << " sec)\n";

        juce::AudioBuffer<float> inBuffer(2, numSamples);
        inBuffer.clear();

        if (numChannels >= 2) {
            reader->read(&inBuffer, 0, numSamples, 0, true, true);
        } else {
            // Mono a Stereo
            reader->read(&inBuffer, 0, numSamples, 0, true, false);
            inBuffer.copyFrom(1, 0, inBuffer, 0, 0, numSamples);
        }

        // Calcola picco e RMS di ingresso
        float inPeak = 0.0f;
        double inSumSq = 0.0;
        for (int ch = 0; ch < 2; ++ch) {
            const float* chPtr = inBuffer.getReadPointer(ch);
            for (int s = 0; s < numSamples; ++s) {
                float val = std::abs(chPtr[s]);
                if (val > inPeak) inPeak = val;
                inSumSq += chPtr[s] * chPtr[s];
            }
        }
        float inPeakDb = (inPeak > 1.0e-5f) ? (20.0f * std::log10(inPeak)) : -100.0f;
        float inRms = static_cast<float>(std::sqrt(inSumSq / (numSamples * 2)));
        float inRmsDb = (inRms > 1.0e-5f) ? (20.0f * std::log10(inRms)) : -100.0f;

        // Inizializza SpaceLuxeEngine
        dsp171::SpaceLuxeEngine engine;
        engine.prepare(sampleRate, 512);
        engine.setParametersV2(
            spec.preDelayMs,
            spec.decaySec,
            spec.roomSize,
            spec.highDampingHz,
            spec.lowWarmthDb,
            spec.shimmerAmount,
            spec.duckAmountPercent,
            spec.tailBloomDb,
            spec.autoSense,
            spec.spectralFocus,
            spec.stereoWidth,
            spec.monoMakerHz,
            spec.dryWetMix
        );
        engine.resetDuckingStats();

        juce::AudioBuffer<float> outBuffer;
        outBuffer.makeCopyOf(inBuffer);

        // Processamento a blocchi di 512 campioni con benchmark ad alta precisione
        constexpr int blockSize = 512;
        auto startTime = std::chrono::high_resolution_clock::now();

        for (int start = 0; start < numSamples; start += blockSize) {
            int currentBlock = std::min(blockSize, numSamples - start);
            juce::AudioBuffer<float> blockProxy(outBuffer.getArrayOfWritePointers(), 2, start, currentBlock);
            engine.processBlock(blockProxy);
        }

        auto endTime = std::chrono::high_resolution_clock::now();
        double elapsedMs = std::chrono::duration<double, std::milli>(endTime - startTime).count();
        double speedup = (durationSec * 1000.0) / elapsedMs;

        // Statistiche di uscita
        float outPeak = 0.0f;
        double outSumSq = 0.0;
        bool hasNanInf = false;

        for (int ch = 0; ch < 2; ++ch) {
            const float* chPtr = outBuffer.getReadPointer(ch);
            for (int s = 0; s < numSamples; ++s) {
                float val = chPtr[s];
                if (std::isnan(val) || std::isinf(val)) {
                    hasNanInf = true;
                }
                float absVal = std::abs(val);
                if (absVal > outPeak) outPeak = absVal;
                outSumSq += val * val;
            }
        }

        float outPeakDb = (outPeak > 1.0e-5f) ? (20.0f * std::log10(outPeak)) : -100.0f;
        float outRms = static_cast<float>(std::sqrt(outSumSq / (numSamples * 2)));
        float outRmsDb = (outRms > 1.0e-5f) ? (20.0f * std::log10(outRms)) : -100.0f;

        float maxDucking = engine.getMaxObservedDuckingGR();
        float maxBloom = engine.getMaxObservedBloom();

        std::cout << "    [DSP BENCHMARK]:\n";
        std::cout << "      Tempo CPU: " << std::fixed << std::setprecision(2) << elapsedMs << " ms ("
                  << std::setprecision(1) << speedup << "x Real-Time speedup)\n";
        std::cout << "      In Peak:   " << std::setprecision(2) << inPeakDb << " dBFS | In RMS:  " << inRmsDb << " dBFS\n";
        std::cout << "      Out Peak:  " << outPeakDb << " dBFS | Out RMS: " << outRmsDb << " dBFS\n";
        std::cout << "      Smart Ducking Max GR:   -" << std::setprecision(2) << maxDucking << " dB\n";
        std::cout << "      Tail Bloom Max Boost:   +" << maxBloom << " dB\n";
        std::cout << "      Sanity Check (NaN/Inf): " << (hasNanInf ? "CRITICAL ERROR!" : "PULITO (0 NaN/Inf)") << "\n";

        // Scrittura file WAV di output
        juce::File destWav = outputDir.getChildFile(spec.outputFilename);
        if (destWav.existsAsFile()) destWav.deleteFile();

        std::unique_ptr<juce::FileOutputStream> outStream(destWav.createOutputStream());
        if (outStream != nullptr) {
            juce::WavAudioFormat wavFormat;
            std::unique_ptr<juce::AudioFormatWriter> writer(wavFormat.createWriterFor(
                outStream.get(),
                sampleRate,
                2,
                24,
                {},
                0
            ));
            if (writer != nullptr) {
                outStream.release(); // La proprietà passa al writer
                writer->writeFromAudioSampleBuffer(outBuffer, 0, numSamples);
                std::cout << "    [SALVATO]: " << destWav.getFileName().toStdString() << " ("
                          << destWav.getSize() / 1024 << " KB)\n";
            }
        }

        TrackResult res;
        res.name = spec.name;
        res.category = spec.category;
        res.sampleRate = sampleRate;
        res.numSamples = numSamples;
        res.durationSec = durationSec;
        res.processingTimeMs = elapsedMs;
        res.speedupRatio = speedup;
        res.inPeakDb = inPeakDb;
        res.inRmsDb = inRmsDb;
        res.outPeakDb = outPeakDb;
        res.outRmsDb = outRmsDb;
        res.maxDuckingGR = maxDucking;
        res.maxTailBloom = maxBloom;
        res.hasNanInf = hasNanInf;
        res.status = hasNanInf ? "FAIL (NaN/Inf)" : "PASS (100% Valid)";
        results.push_back(res);
    }

    // Esporta un sommario JSON per il post-processing analitico in Python
    juce::File jsonLog = outputDir.getChildFile("spaceluxe_multiaudio_audit_summary.json");
    std::ofstream js(jsonLog.getFullPathName().toStdString());
    if (js.is_open()) {
        js << "{\n";
        js << "  \"engine\": \"171SpaceLuxeEngine\",\n";
        js << "  \"version\": \"1.0.0\",\n";
        js << "  \"timestamp\": \"" << juce::Time::getCurrentTime().toISO8601(true).toStdString() << "\",\n";
        js << "  \"audit_lead\": \"" << dispatch.primaryAgent.agentId << "\",\n";
        js << "  \"tracks\": [\n";
        for (size_t i = 0; i < results.size(); ++i) {
            const auto& r = results[i];
            js << "    {\n";
            js << "      \"track_name\": \"" << r.name << "\",\n";
            js << "      \"category\": \"" << r.category << "\",\n";
            js << "      \"duration_sec\": " << r.durationSec << ",\n";
            js << "      \"speedup_realtime\": " << r.speedupRatio << ",\n";
            js << "      \"cpu_time_ms\": " << r.processingTimeMs << ",\n";
            js << "      \"in_peak_dbfs\": " << r.inPeakDb << ",\n";
            js << "      \"in_rms_dbfs\": " << r.inRmsDb << ",\n";
            js << "      \"out_peak_dbfs\": " << r.outPeakDb << ",\n";
            js << "      \"out_rms_dbfs\": " << r.outRmsDb << ",\n";
            js << "      \"max_ducking_gr_db\": " << r.maxDuckingGR << ",\n";
            js << "      \"max_tail_bloom_db\": " << r.maxTailBloom << ",\n";
            js << "      \"status\": \"" << r.status << "\"\n";
            js << "    }" << ((i + 1 < results.size()) ? "," : "") << "\n";
        }
        js << "  ]\n";
        js << "}\n";
        js.close();
        std::cout << "\n[*] Sommario JSON salvato in:\n    " << jsonLog.getFullPathName().toStdString() << "\n";
    }

    std::cout << "\n====================================================================\n";
    std::cout << " MULTI-AUDIO RUN COMPLETATO CON SUCCESSO! AVVIO ANALISI AGENTI...    \n";
    std::cout << "====================================================================\n";

    return 0;
}
