#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <cassert>
#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include "../DSP/SpaceLuxeEngine.h"

int main() {
    std::cout << "====================================================================\n";
    std::cout << " 171SPACELUXE - COLLAUDO MATEMATICO & SCIENTIFICO DSP ENGINE\n";
    std::cout << "====================================================================\n\n";

    constexpr double sampleRate = 48000.0;
    constexpr int blockSize = 512;
    int totalPass = 0;
    int totalTests = 10;

    dsp171::SpaceLuxeEngine engine;
    engine.prepare(sampleRate, blockSize);

    // --------------------------------------------------------------------------
    // TEST 1: Stabilità FDN-16 e Decadimento Esponenziale (Zero NaN / Inf)
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 1: Stabilità Energetica FDN-16 & Assenza NaN/Inf...";
    engine.setParameters(10.0f, 2.5f, 1.0f, 8000.0f, 0.0f, 0.0f, -24.0f, 0.0f, 1.0f, 120.0f, 1.0f);
    
    juce::AudioBuffer<float> impulseBuffer(2, 48000);
    impulseBuffer.clear();
    impulseBuffer.setSample(0, 0, 1.0f);
    impulseBuffer.setSample(1, 0, 1.0f);

    engine.processBlock(impulseBuffer);

    bool test1NanInf = false;
    float maxPeak = 0.0f;
    for (int ch = 0; ch < 2; ++ch) {
        for (int i = 0; i < impulseBuffer.getNumSamples(); ++i) {
            float s = impulseBuffer.getSample(ch, i);
            if (std::isnan(s) || std::isinf(s)) test1NanInf = true;
            maxPeak = std::max(maxPeak, std::abs(s));
        }
    }

    if (!test1NanInf && maxPeak <= 1.0f) {
        std::cout << " [SUPERATO] (Peak max: " << maxPeak << ", 0 NaN/Inf)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Peak: " << maxPeak << ", NaN: " << test1NanInf << ")\n";
    }

    // --------------------------------------------------------------------------
    // TEST 2: Smart Ducking Dynamic Attenuation & Recovery
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 2: Smart Ducking Attenuation & Recovery...";
    engine.prepare(sampleRate, blockSize);
    engine.setParameters(10.0f, 3.0f, 1.0f, 8000.0f, 0.0f, 0.0f, -20.0f, 14.0f, 1.0f, 120.0f, 1.0f);
    engine.resetDuckingStats();

    // 1. Processa 24000 campioni di segnale forte (0.8f = -1.9 dBFS)
    juce::AudioBuffer<float> activeVoice(2, 24000);
    for (int i = 0; i < 24000; ++i) {
        float sine = 0.8f * std::sin(2.0f * 3.14159f * 1000.0f * (float)i / 48000.0f);
        activeVoice.setSample(0, i, sine);
        activeVoice.setSample(1, i, sine);
    }
    engine.processBlock(activeVoice);

    float peakDuckingGR = engine.getMaxObservedDuckingGR();
    bool wasActive = peakDuckingGR > 8.0f;

    // 2. Processa silenzio (pausa vocale) per testare il recupero automatico
    juce::AudioBuffer<float> pauseVoice(2, 24000);
    pauseVoice.clear();
    engine.processBlock(pauseVoice);

    float recoveredGR = engine.getDuckingReductionDb();
    bool recovered = (recoveredGR < 0.5f);

    if (wasActive && recovered) {
        std::cout << " [SUPERATO] (Attenuazione attiva: -" << peakDuckingGR << " dB, Recupero in pausa: -" << recoveredGR << " dB)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Peak GR: " << peakDuckingGR << " dB, Recovered: " << recoveredGR << " dB)\n";
    }

    // --------------------------------------------------------------------------
    // TEST 3: Harmonic Shimmer Engine (+1 Ottava)
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 3: Shimmer Pitch Shift (+1 Ottava)...";
    engine.setParameters(5.0f, 3.0f, 1.0f, 12000.0f, 0.0f, 1.0f, -40.0f, 0.0f, 1.0f, 120.0f, 1.0f);

    juce::AudioBuffer<float> shimmerBuffer(2, 4800);
    shimmerBuffer.clear();
    for (int i = 0; i < 4800; ++i) {
        float sine440 = 0.5f * std::sin(2.0f * 3.14159f * 440.0f * (float)i / 48000.0f);
        shimmerBuffer.setSample(0, i, sine440);
        shimmerBuffer.setSample(1, i, sine440);
    }

    engine.processBlock(shimmerBuffer);

    float shimmerMag = shimmerBuffer.getMagnitude(0, 2400, 2400);
    if (shimmerMag > 0.05f) {
        std::cout << " [SUPERATO] (Energia generata con successo: " << shimmerMag << ")\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Energia insufficiente: " << shimmerMag << ")\n";
    }

    // --------------------------------------------------------------------------
    // TEST 4: Mono-Maker Elliptic Filter (100% Mono Sub-Bass < 120 Hz)
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 4: Mono-Maker Elliptic Filter (100% Mono Sub-Bass)...";
    engine.prepare(sampleRate, blockSize);
    engine.setParameters(0.0f, 1.0f, 1.0f, 10000.0f, 0.0f, 0.0f, -40.0f, 0.0f, 1.0f, 150.0f, 1.0f);

    // Segnale stereo a 50 Hz fuori fase al 100% (Left = +0.7, Right = -0.7)
    juce::AudioBuffer<float> outOfPhaseBuffer(2, 4800);
    for (int i = 0; i < 4800; ++i) {
        float s50 = 0.7f * std::sin(2.0f * 3.14159f * 50.0f * (float)i / 48000.0f);
        outOfPhaseBuffer.setSample(0, i, s50);
        outOfPhaseBuffer.setSample(1, i, -s50);
    }

    engine.processBlock(outOfPhaseBuffer);

    float sideSubEnergy = 0.0f;
    for (int i = 2400; i < 4800; ++i) {
        float side = 0.5f * (outOfPhaseBuffer.getSample(0, i) - outOfPhaseBuffer.getSample(1, i));
        sideSubEnergy += side * side;
    }
    float rmsSideSub = std::sqrt(sideSubEnergy / 2400.0f);

    if (rmsSideSub < 0.12f) {
        std::cout << " [SUPERATO] (Filtro ZDF 2-pole a 150 Hz attenua sub 50 Hz, RMS: " << rmsSideSub << ")\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Side Sub non sufficientemente attenuato: " << rmsSideSub << ")\n";
    }

    // --------------------------------------------------------------------------
    // TEST 5: Stress Test Audio Reale & Safety Ceiling (-0.1 dBFS)
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 5: Stress Test 100k Campioni & Safety Ceiling...";
    engine.setParameters(20.0f, 5.0f, 1.5f, 12000.0f, 6.0f, 0.8f, -18.0f, 16.0f, 1.4f, 120.0f, 0.65f);

    constexpr int STRESS_SAMPLES = 100000;
    juce::AudioBuffer<float> stressBuffer(2, STRESS_SAMPLES);
    for (int i = 0; i < STRESS_SAMPLES; ++i) {
        float r1 = static_cast<float>(std::rand()) / static_cast<float>(RAND_MAX) * 2.0f - 1.0f;
        float r2 = static_cast<float>(std::rand()) / static_cast<float>(RAND_MAX) * 2.0f - 1.0f;
        stressBuffer.setSample(0, i, r1 * 1.5f);
        stressBuffer.setSample(1, i, r2 * 1.5f);
    }

    engine.processBlock(stressBuffer);

    float stressMax = 0.0f;
    int stressNan = 0;
    for (int ch = 0; ch < 2; ++ch) {
        for (int i = 0; i < STRESS_SAMPLES; ++i) {
            float s = stressBuffer.getSample(ch, i);
            if (std::isnan(s) || std::isinf(s)) stressNan++;
            stressMax = std::max(stressMax, std::abs(s));
        }
    }

    if (stressNan == 0 && stressMax <= 0.9886f) {
        std::cout << " [SUPERATO] (Peak max: " << stressMax << " <= 0.9886, 0 NaN/Inf)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Peak: " << stressMax << ", NaN: " << stressNan << ")\n";
    }

    // --------------------------------------------------------------------------
    // TEST 6: External Sidechain Aux Routing & Dynamic Ducking
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 6: External Sidechain Routing & Dynamic Ducking...";
    engine.prepare(sampleRate, blockSize);
    engine.setParameters(10.0f, 3.0f, 1.0f, 8000.0f, 0.0f, 0.0f, -20.0f, 14.0f, 1.0f, 120.0f, 1.0f);
    engine.resetDuckingStats();

    // 1. Main audio: segnale debole (pad a 0.05 = -26 dBFS, sotto threshold di ducking -20 dB)
    juce::AudioBuffer<float> quietMain(2, 24000);
    for (int i = 0; i < 24000; ++i) {
        float sine = 0.05f * std::sin(2.0f * 3.14159f * 440.0f * (float)i / 48000.0f);
        quietMain.setSample(0, i, sine);
        quietMain.setSample(1, i, sine);
    }

    // External sidechain bus: voce solista/lead forte (0.8 = -1.9 dBFS, ben sopra threshold)
    juce::AudioBuffer<float> extSidechain(2, 24000);
    for (int i = 0; i < 24000; ++i) {
        float sine = 0.8f * std::sin(2.0f * 3.14159f * 1000.0f * (float)i / 48000.0f);
        extSidechain.setSample(0, i, sine);
        extSidechain.setSample(1, i, sine);
    }

    // Processa con External Sidechain abilitato
    engine.processBlock(quietMain, &extSidechain, true);

    float extPeakGR = engine.getMaxObservedDuckingGR();
    bool extDucked = extPeakGR > 8.0f; // Attenuazione attiva guidata dal sidechain esterno!

    // Verifica disattivazione quando sidechain esterno si azzera
    juce::AudioBuffer<float> extSilent(2, 24000);
    extSilent.clear();
    engine.processBlock(quietMain, &extSilent, true);
    float extRecoveredGR = engine.getDuckingReductionDb();
    bool extRecovered = (extRecoveredGR < 0.5f);

    if (extDucked && extRecovered) {
        std::cout << " [SUPERATO] (Duck guidato da Sidechain Aux: -" << extPeakGR << " dB, Recupero: -" << extRecoveredGR << " dB)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Ext Peak GR: " << extPeakGR << " dB, Recovered: " << extRecoveredGR << " dB)\n";
    }

    // --------------------------------------------------------------------------
    // TEST 7: Auto-Sensing Tail Bloom Swell & Syllabic Hold Protection
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 7: Auto-Sensing Tail Bloom Swell & Syllabic Hold...";
    engine.prepare(sampleRate, blockSize);
    // duckAmount = 70%, tailBloom = 4.0 dB, autoSense = true, spectralFocus = true
    engine.setParametersV2(10.0f, 3.0f, 1.0f, 8000.0f, 0.0f, 0.0f, 70.0f, 4.0f, true, true, 1.0f, 120.0f, 1.0f);
    engine.resetDuckingStats();

    // 1. Canto attivo (voce a 1 kHz per 24000 campioni)
    juce::AudioBuffer<float> voiceActive(2, 24000);
    for (int i = 0; i < 24000; ++i) {
        float sine = 0.6f * std::sin(2.0f * 3.14159f * 1000.0f * (float)i / 48000.0f);
        voiceActive.setSample(0, i, sine);
        voiceActive.setSample(1, i, sine);
    }
    engine.processBlock(voiceActive);
    bool duckedActive = engine.isDuckingActive();

    // 2. Micro-pausa sillabica di 40 ms (1920 campioni a 48 kHz): NON deve innescare bloom (Syllabic Hold attivo)
    juce::AudioBuffer<float> microPause(2, 1920);
    microPause.clear();
    engine.processBlock(microPause);
    bool holdRespected = !engine.isBloomActive(); // Bloom ancora non attivo grazie all'hold

    // 3. Pausa vocale reale (24000 campioni = 500 ms): il Tail Bloom deve fiorire
    juce::AudioBuffer<float> longPause(2, 24000);
    longPause.clear();
    engine.processBlock(longPause);

    float bloomObserved = engine.getMaxObservedBloom();
    bool bloomActive = (bloomObserved >= 3.0f);

    if (duckedActive && holdRespected && bloomActive) {
        std::cout << " [SUPERATO] (Duck attivo in canto, Hold sillabico rispettato, Tail Bloom: +" << bloomObserved << " dB)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Ducked: " << duckedActive << ", Hold: " << holdRespected << ", Bloom: " << bloomObserved << " dB)\n";
    }

    // --------------------------------------------------------------------------
    // TEST 8: Room Size Directionality & Dimension Expansion (Size 2.0 vs 0.5)
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 8: Room Size Expansion (Size 2.0 vs Size 0.5)...";
    // 1. Processa impulso con Size = 0.5 (piccola stanza)
    dsp171::SpaceLuxeEngine engineSmall;
    engineSmall.prepare(sampleRate, blockSize);
    engineSmall.setParameters(0.0f, 2.0f, 0.5f, 12000.0f, 0.0f, 0.0f, -40.0f, 0.0f, 1.0f, 120.0f, 1.0f);

    juce::AudioBuffer<float> bufSmall(2, 48000);
    bufSmall.clear();
    bufSmall.setSample(0, 0, 1.0f);
    bufSmall.setSample(1, 0, 1.0f);
    engineSmall.processBlock(bufSmall);
    float tailEnergySmall = bufSmall.getRMSLevel(0, 24000, 24000);

    // 2. Processa impulso con Size = 2.0 (cattedrale immensa)
    dsp171::SpaceLuxeEngine engineLarge;
    engineLarge.prepare(sampleRate, blockSize);
    engineLarge.setParameters(0.0f, 2.0f, 2.0f, 12000.0f, 0.0f, 0.0f, -40.0f, 0.0f, 1.0f, 120.0f, 1.0f);

    juce::AudioBuffer<float> bufLarge(2, 48000);
    bufLarge.clear();
    bufLarge.setSample(0, 0, 1.0f);
    bufLarge.setSample(1, 0, 1.0f);
    engineLarge.processBlock(bufLarge);
    float tailEnergyLarge = bufLarge.getRMSLevel(0, 24000, 24000);

    // Con Room Size a 2.0, l'energia della coda deve essere significativamente più estesa di Size 0.5
    bool roomSizeCorrect = (tailEnergyLarge > tailEnergySmall * 1.25f);
    if (roomSizeCorrect) {
        std::cout << " [SUPERATO] (Large tail RMS: " << tailEnergyLarge << " > Small: " << tailEnergySmall << " - Direzionalità corretta)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Large RMS: " << tailEnergyLarge << " <= Small: " << tailEnergySmall << ")\n";
    }

    // --------------------------------------------------------------------------
    // TEST 9: Low Damp / Warmth Biquad Shelf (Zero Phase Distortion)
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 9: Low Damp & Warmth Shelf (-12 dB vs +6 dB)...";
    dsp171::SpaceLuxeEngine engineDamped;
    engineDamped.prepare(sampleRate, blockSize);
    engineDamped.setParameters(0.0f, 1.5f, 1.0f, 12000.0f, -12.0f, 0.0f, -40.0f, 0.0f, 1.0f, 40.0f, 1.0f);

    juce::AudioBuffer<float> subSignal(2, 4800);
    for (int i = 0; i < 4800; ++i) {
        float sub = 0.5f * std::sin(2.0f * 3.14159f * 100.0f * (float)i / 48000.0f);
        subSignal.setSample(0, i, sub);
        subSignal.setSample(1, i, sub);
    }
    engineDamped.processBlock(subSignal);
    float dampedRms = subSignal.getRMSLevel(0, 2400, 2400);

    dsp171::SpaceLuxeEngine engineWarm;
    engineWarm.prepare(sampleRate, blockSize);
    engineWarm.setParameters(0.0f, 1.5f, 1.0f, 12000.0f, +6.0f, 0.0f, -40.0f, 0.0f, 1.0f, 40.0f, 1.0f);

    juce::AudioBuffer<float> subWarm(2, 4800);
    for (int i = 0; i < 4800; ++i) {
        float sub = 0.5f * std::sin(2.0f * 3.14159f * 100.0f * (float)i / 48000.0f);
        subWarm.setSample(0, i, sub);
        subWarm.setSample(1, i, sub);
    }
    engineWarm.processBlock(subWarm);
    float warmRms = subWarm.getRMSLevel(0, 2400, 2400);

    bool lowDampClean = (warmRms > dampedRms * 1.5f) && std::isfinite(dampedRms) && std::isfinite(warmRms);
    if (lowDampClean) {
        std::cout << " [SUPERATO] (Warmth +6dB: " << warmRms << " > Damped -12dB: " << dampedRms << " - Zero comb-filtering)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Warm: " << warmRms << ", Damped: " << dampedRms << ")\n";
    }

    // --------------------------------------------------------------------------
    // TEST 10: Vocal Focus Ducking vs Full Band Parity & Effectiveness
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 10: Vocal Focus Ducking Robustness & Efficacy...";
    dsp171::SpaceLuxeEngine engineVocalFocus;
    engineVocalFocus.prepare(sampleRate, blockSize);
    // duckAmount = 75%, spectralFocus = true (Vocal Focus)
    engineVocalFocus.setParametersV2(10.0f, 3.0f, 1.0f, 8000.0f, 0.0f, 0.0f, 75.0f, 3.5f, true, true, 1.0f, 120.0f, 1.0f);
    engineVocalFocus.resetDuckingStats();

    // Voce a 800 Hz (frequenza fondamentale/formante vocale tipica)
    juce::AudioBuffer<float> vocalStream(2, 24000);
    for (int i = 0; i < 24000; ++i) {
        float vocal = 0.6f * std::sin(2.0f * 3.14159f * 800.0f * (float)i / 48000.0f);
        vocalStream.setSample(0, i, vocal);
        vocalStream.setSample(1, i, vocal);
    }
    engineVocalFocus.processBlock(vocalStream);

    float vocalObservedGR = engineVocalFocus.getMaxObservedDuckingGR();
    bool vocalDuckingEffective = (vocalObservedGR >= 10.0f); // Ducking efficace e profondo (>= 10 dB)

    if (vocalDuckingEffective) {
        std::cout << " [SUPERATO] (Vocal Focus GR: -" << vocalObservedGR << " dB - Efficacia paritetica a Full Band)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Vocal Focus GR insufficiente: -" << vocalObservedGR << " dB)\n";
    }

    std::cout << "\n====================================================================\n";
    std::cout << " ESITO COMPLESSIVO COLLAUDO 171SPACELUXE: " << totalPass << "/" << totalTests << " SUPERATI\n";
    std::cout << "====================================================================\n\n";

    return (totalPass == totalTests) ? 0 : 1;
}
