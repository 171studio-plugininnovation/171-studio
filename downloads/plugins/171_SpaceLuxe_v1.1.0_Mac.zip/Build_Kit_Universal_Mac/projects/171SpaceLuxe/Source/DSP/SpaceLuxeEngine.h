#pragma once
#include <vector>
#include <cmath>
#include <algorithm>
#include <array>
#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include "dsp171/ZDFSVF.h"
#include "dsp171/FastMath.h"

namespace dsp171 {

// ==============================================================================
// 1. SMART DUCKING & TAIL BLOOM ENGINE v3 (ULTRA-SMOOTH, ZERO-CLICK)
// ==============================================================================
class SmartDuckingEngine {
public:
    SmartDuckingEngine() = default;

    void prepare(double sampleRate) {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        updateAlphas();
        reset();
    }

    void reset() noexcept {
        currentEnvelope = 0.0f;
        currentGainReductionDb = 0.0f;
        currentBloomGainDb = 0.0f;
        smoothedGain = 1.0f;
        maxObservedGR = 0.0f;
        maxObservedBloom = 0.0f;
        longTermRms = 0.001f;
        silenceCounter = 0;
        effectiveThreshold = -24.0f;
    }

    void setParametersV2(float duckAmountPct,
                         float tailBloomDb = 3.5f,
                         bool autoSense = true,
                         bool spectralFocus = true,
                         float manualThresholdDb = -24.0f,
                         float attackMs = 5.0f,
                         float releaseMs = 180.0f,
                         float holdMs = 90.0f) noexcept
    {
        maxDepth = (std::clamp(duckAmountPct, 0.0f, 100.0f) / 100.0f) * 20.0f;
        maxBloomDb = std::clamp(tailBloomDb, 0.0f, 6.0f);
        useAutoSense = autoSense;
        useSpectralFocus = spectralFocus;
        manualThreshold = manualThresholdDb;
        attMs = std::clamp(attackMs, 0.2f, 100.0f);
        relMs = std::clamp(releaseMs, 10.0f, 2000.0f);
        holdSamples = static_cast<int>(std::clamp(holdMs, 10.0f, 300.0f) * 0.001f * static_cast<float>(sr));
        bloomDecaySamples = static_cast<int>(2.5f * static_cast<float>(sr)); // 2.5s naturale per tail bloom
        updateAlphas();
    }

    void setParameters(float thresholdDb, float depthDb, float attackMs = 5.0f, float releaseMs = 120.0f) noexcept {
        float duckPct = std::clamp((depthDb / 20.0f) * 100.0f, 0.0f, 100.0f);
        setParametersV2(duckPct, 0.0f, false, false, thresholdDb, attackMs, releaseMs, 60.0f);
    }

    inline float processSample(float keyL, float keyR) noexcept {
        float peak = std::max(std::abs(keyL), std::abs(keyR));

        // 1. Tracciamento RMS a lungo termine per Auto-Threshold
        float sq = peak * peak;
        longTermRms += (sq - longTermRms) * longTermAlpha;
        if (longTermRms < 1.0e-20f) longTermRms = 0.0f;
        float rmsDb = (longTermRms > 1.0e-10f) ? (10.0f * std::log10(longTermRms)) : -100.0f;

        if (useAutoSense) {
            effectiveThreshold = std::clamp(rmsDb - 8.0f, -55.0f, -12.0f);
        } else {
            effectiveThreshold = std::min(manualThreshold, rmsDb - 4.0f);
            effectiveThreshold = std::clamp(effectiveThreshold, -60.0f, -6.0f);
        }

        // 2. Inseguitore analogico asimmetrico
        if (peak > currentEnvelope) {
            currentEnvelope += (peak - currentEnvelope) * attackAlpha;
            silenceCounter = 0;
        } else {
            currentEnvelope += (peak - currentEnvelope) * releaseAlpha;
            if (currentEnvelope < 1.0e-20f) currentEnvelope = 0.0f;
            if (silenceCounter < holdSamples + bloomDecaySamples * 2) {
                silenceCounter++;
            }
        }

        float envDb = (currentEnvelope > 1.0e-7f)
            ? (20.0f * std::log10(currentEnvelope))
            : -140.0f;

        float targetGain = 1.0f;

        if (envDb > effectiveThreshold && maxDepth > 0.01f) {
            // VOCE PRESENTE: DUCKING ATTIVO
            silenceCounter = 0;
            float excess = envDb - effectiveThreshold;
            float attenDb = std::min(maxDepth, excess * 0.95f);
            currentGainReductionDb = attenDb;
            currentBloomGainDb = 0.0f;
            if (attenDb > maxObservedGR) maxObservedGR = attenDb;
            targetGain = std::pow(10.0f, -attenDb / 20.0f);
        } else {
            // VOCE ASSENTE: VERIFICA SYLLABIC HOLD & TAIL BLOOM
            currentGainReductionDb = 0.0f;
            if (silenceCounter >= holdSamples && maxBloomDb > 0.05f) {
                // Durante la finestra di decadimento della coda, attiva la fioritura
                int bloomElapsed = silenceCounter - holdSamples;
                if (bloomElapsed < bloomDecaySamples) {
                    float decayFactor = 1.0f - static_cast<float>(bloomElapsed) / static_cast<float>(bloomDecaySamples);
                    float activeBloomDb = maxBloomDb * decayFactor;
                    currentBloomGainDb = activeBloomDb;
                    if (maxBloomDb > maxObservedBloom) maxObservedBloom = maxBloomDb;
                    targetGain = std::pow(10.0f, activeBloomDb / 20.0f);
                } else {
                    // Fine coda: rilascio morbido al livello neutro 1.0 (zero click)
                    currentBloomGainDb = 0.0f;
                    targetGain = 1.0f;
                }
            } else {
                currentBloomGainDb = 0.0f;
                targetGain = 1.0f;
            }
        }

        // 3. Smooth dinamico asimmetrico
        float activeAlpha = duckReleaseAlpha;
        if (targetGain < smoothedGain) {
            activeAlpha = duckAttackAlpha;
        } else if (targetGain > 1.01f) {
            activeAlpha = swellAttackAlpha;
        }
        smoothedGain += (targetGain - smoothedGain) * activeAlpha;
        if (std::abs(smoothedGain - 1.0f) < 1.0e-6f) smoothedGain = 1.0f;

        return smoothedGain;
    }

    inline float getStereoBloomMultiplier() const noexcept {
        if (maxBloomDb <= 0.05f || smoothedGain <= 1.01f) return 1.0f;
        float maxLinearBloom = std::pow(10.0f, maxBloomDb / 20.0f);
        float bloomRatio = std::clamp((smoothedGain - 1.0f) / std::max(0.01f, maxLinearBloom - 1.0f), 0.0f, 1.0f);
        return 1.0f + 0.15f * bloomRatio;
    }

    float getGainReductionDb() const noexcept { return currentGainReductionDb; }
    float getBloomGainDb() const noexcept { return currentBloomGainDb; }
    float getMaxObservedGR() const noexcept { return maxObservedGR; }
    float getMaxObservedBloom() const noexcept { return maxObservedBloom; }
    float getEffectiveThresholdDb() const noexcept { return effectiveThreshold; }
    bool isDuckingActive() const noexcept { return currentGainReductionDb > 0.5f; }
    bool isBloomActive() const noexcept { return smoothedGain > 1.05f; }
    bool isSpectralFocusActive() const noexcept { return useSpectralFocus; }
    void resetStats() noexcept { maxObservedGR = 0.0f; maxObservedBloom = 0.0f; }

private:
    void updateAlphas() noexcept {
        attackAlpha      = 1.0f - std::exp(-1.0f / (float(attMs * 0.001 * sr)));
        releaseAlpha     = 1.0f - std::exp(-1.0f / (float(relMs * 0.001 * sr)));
        duckAttackAlpha  = 1.0f - std::exp(-1.0f / (float(0.012 * sr))); // 12 ms
        duckReleaseAlpha = 1.0f - std::exp(-1.0f / (float(0.060 * sr))); // 60 ms
        swellAttackAlpha = 1.0f - std::exp(-1.0f / (float(0.120 * sr))); // 120 ms
        longTermAlpha    = 1.0f - std::exp(-1.0f / (float(1.500 * sr)));
    }

    double sr = 48000.0;
    float maxDepth = 12.0f;
    float maxBloomDb = 0.0f;
    bool useAutoSense = true;
    bool useSpectralFocus = true;
    float manualThreshold = -24.0f;
    float effectiveThreshold = -24.0f;

    float attMs = 5.0f;
    float relMs = 180.0f;
    int holdSamples = 4320;
    int bloomDecaySamples = 120000;
    int silenceCounter = 0;

    float attackAlpha = 0.1f;
    float releaseAlpha = 0.01f;
    float duckAttackAlpha = 0.05f;
    float duckReleaseAlpha = 0.02f;
    float swellAttackAlpha = 0.01f;
    float longTermAlpha = 0.0001f;

    float currentEnvelope = 0.0f;
    float currentGainReductionDb = 0.0f;
    float currentBloomGainDb = 0.0f;
    float smoothedGain = 1.0f;
    float maxObservedGR = 0.0f;
    float maxObservedBloom = 0.0f;
    float longTermRms = 0.001f;
};

// ==============================================================================
// 2. SCHROEDER / DATTORRO ALLPASS INPUT DIFFUSER NETWORK
// Diffonde i transienti in modo setoso, senza chirping né risonanze metalliche
// ==============================================================================
class SchroederAllpassStage {
public:
    SchroederAllpassStage() = default;

    void prepare(int delaySamples, float feedback) {
        dSamples = std::max(2, delaySamples);
        buffer.assign(dSamples, 0.0f);
        index = 0;
        g = feedback;
    }

    inline float process(float in) noexcept {
        float delayed = buffer[index];
        float out = -g * in + delayed;
        float toBuf = in + g * out;
        if (std::abs(toBuf) < 1.0e-20f) toBuf = 0.0f;
        buffer[index] = toBuf;
        index = (index + 1) % dSamples;
        return out;
    }

    void reset() {
        std::fill(buffer.begin(), buffer.end(), 0.0f);
        index = 0;
    }

private:
    std::vector<float> buffer;
    int index = 0;
    int dSamples = 100;
    float g = 0.60f;
};

class InputDiffuser4Stage {
public:
    InputDiffuser4Stage() = default;

    void prepare(double sampleRate) {
        float scale = static_cast<float>(sampleRate / 48000.0);
        // Tempi di diffusione Dattorro/Schroeder decorrelati L/R
        static constexpr int delaysL[4] = { 229, 367, 577, 853 };
        static constexpr int delaysR[4] = { 251, 397, 607, 887 };
        static constexpr float diffGains[4] = { 0.62f, 0.58f, 0.52f, 0.48f };

        for (int i = 0; i < 4; ++i) {
            stageL[i].prepare(static_cast<int>(delaysL[i] * scale), diffGains[i]);
            stageR[i].prepare(static_cast<int>(delaysR[i] * scale), diffGains[i]);
        }
    }

    void reset() {
        for (int i = 0; i < 4; ++i) {
            stageL[i].reset();
            stageR[i].reset();
        }
    }

    inline void process(float inL, float inR, float& outL, float& outR) noexcept {
        float sL = inL;
        float sR = inR;

        for (int i = 0; i < 4; ++i) {
            sL = stageL[i].process(sL);
            sR = stageR[i].process(sR);
        }
        outL = sL;
        outR = sR;
    }

private:
    std::array<SchroederAllpassStage, 4> stageL;
    std::array<SchroederAllpassStage, 4> stageR;
};

// ==============================================================================
// 3. HARMONIC SHIMMER PITCH SHIFTER
// ==============================================================================
class ShimmerPitchEngine {
public:
    ShimmerPitchEngine() = default;

    void prepare(double sampleRate) {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        bufferSize = static_cast<int>(sr * 0.1);
        bufferL.assign(bufferSize, 0.0f);
        bufferR.assign(bufferSize, 0.0f);
        writePos = 0;
        phase = 0.0f;

        windowSize = static_cast<float>(sr * 0.045);
        rate = 1.0f / windowSize;
    }

    void process(float inL, float inR, float& outL, float& outR, float shimmerAmount) {
        if (shimmerAmount <= 0.001f) {
            outL = 0.0f;
            outR = 0.0f;
            return;
        }

        bufferL[writePos] = (std::abs(inL) < 1.0e-20f) ? 0.0f : inL;
        bufferR[writePos] = (std::abs(inR) < 1.0e-20f) ? 0.0f : inR;

        float phase1 = phase;
        float phase2 = std::fmod(phase + 0.5f, 1.0f);

        float delay1 = phase1 * windowSize;
        float delay2 = phase2 * windowSize;

        float s1L = readSample(bufferL, delay1);
        float s1R = readSample(bufferR, delay1);
        float s2L = readSample(bufferL, delay2);
        float s2R = readSample(bufferR, delay2);

        float w1 = 0.5f * (1.0f - std::cos(phase1 * 6.2831853f));
        float w2 = 0.5f * (1.0f - std::cos(phase2 * 6.2831853f));

        float shiftedL = (s1L * w1 + s2L * w2);
        float shiftedR = (s1R * w1 + s2R * w2);

        float satL = std::tanh(shiftedL * 1.4f) * 0.85f;
        float satR = std::tanh(shiftedR * 1.4f) * 0.85f;

        outL = satL * shimmerAmount;
        outR = satR * shimmerAmount;

        phase += rate;
        if (phase >= 1.0f) phase -= 1.0f;

        writePos = (writePos + 1) % bufferSize;
    }

private:
    inline float readSample(const std::vector<float>& buf, float delay) const noexcept {
        float readF = static_cast<float>(writePos) - delay;
        while (readF < 0.0f) readF += static_cast<float>(bufferSize);
        int idx0 = static_cast<int>(readF);
        int idx1 = (idx0 + 1) % bufferSize;
        float frac = readF - static_cast<float>(idx0);
        return buf[idx0] + frac * (buf[idx1] - buf[idx0]);
    }

    double sr = 48000.0;
    int bufferSize = 4800;
    std::vector<float> bufferL;
    std::vector<float> bufferR;
    int writePos = 0;
    float phase = 0.0f;
    float windowSize = 2160.0f;
    float rate = 0.00046f;
};

// ==============================================================================
// 4. PRECISION BIQUAD LOW SHELF FILTER (ANTI-DENORMAL PROTECTED)
// ==============================================================================
class BiquadLowShelf {
public:
    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        reset();
    }
    void reset() noexcept {
        x1 = x2 = 0.0f;
    }
    void setParameters(float freqHz, float gainDb, float q = 0.7071f) noexcept {
        if (std::abs(gainDb) < 0.05f) {
            b0 = 1.0f; b1 = 0.0f; b2 = 0.0f;
            a1 = 0.0f; a2 = 0.0f;
            isBypassed = true;
            return;
        }
        isBypassed = false;
        double A = std::pow(10.0, static_cast<double>(gainDb) / 40.0);
        double w0 = 6.283185307179586 * std::clamp(static_cast<double>(freqHz), 30.0, sr * 0.45) / sr;
        double cosW0 = std::cos(w0);
        double sinW0 = std::sin(w0);
        double alpha = sinW0 / (2.0 * static_cast<double>(q));
        double sqrtA2Alpha = 2.0 * std::sqrt(A) * alpha;

        double a0 = (A + 1.0) + (A - 1.0) * cosW0 + sqrtA2Alpha;
        double invA0 = 1.0 / a0;

        b0 = static_cast<float>((A * ((A + 1.0) - (A - 1.0) * cosW0 + sqrtA2Alpha)) * invA0);
        b1 = static_cast<float>((2.0 * A * ((A - 1.0) - (A + 1.0) * cosW0)) * invA0);
        b2 = static_cast<float>((A * ((A + 1.0) - (A - 1.0) * cosW0 - sqrtA2Alpha)) * invA0);
        a1 = static_cast<float>((-2.0 * ((A - 1.0) + (A + 1.0) * cosW0)) * invA0);
        a2 = static_cast<float>(((A + 1.0) + (A - 1.0) * cosW0 - sqrtA2Alpha) * invA0);
    }
    inline float process(float in) noexcept {
        if (isBypassed) return in;
        float out = b0 * in + x1;
        x1 = b1 * in - a1 * out + x2;
        x2 = b2 * in - a2 * out;
        if (std::abs(x1) < 1.0e-20f) x1 = 0.0f;
        if (std::abs(x2) < 1.0e-20f) x2 = 0.0f;
        return out;
    }
private:
    double sr = 48000.0;
    float b0 = 1.0f, b1 = 0.0f, b2 = 0.0f;
    float a1 = 0.0f, a2 = 0.0f;
    float x1 = 0.0f, x2 = 0.0f;
    bool isBypassed = true;
};

// ==============================================================================
// 5. VOCAL FOCUS WEIGHTING FILTER (200 Hz - 4800 Hz)
// ==============================================================================
class VocalFocusWeightingFilter {
public:
    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        hpf.setParameters(200.0f, 0.7071f, static_cast<float>(sr));
        lpf.setParameters(4800.0f, 0.7071f, static_cast<float>(sr));
        reset();
    }
    void reset() noexcept {
        hpf.reset();
        lpf.reset();
    }
    inline float process(float in) noexcept {
        float hpOut = hpf.process(in).hp;
        float lpOut = lpf.process(hpOut).lp;
        return lpOut * 1.58f;
    }
private:
    double sr = 48000.0;
    ZDFSVF64 hpf;
    ZDFSVF64 lpf;
};

// ==============================================================================
// 6. FDN-16 REVERB TANK CON WALSH-HADAMARD DIFFUSION & MULTI-RATE LFO
// Elimina completamente risonanze metalliche, battimenti e flutter echo
// ==============================================================================
class FDN16Tank {
public:
    static constexpr int NUM_LINES = 16;

    // 16 lunghezze prime mutuamente coprime ad alta densità modale (da 30ms a 128ms)
    static constexpr int PRIME_DELAYS[NUM_LINES] = {
        1453, 1619, 1787, 1997, 2221, 2467, 2731, 3019,
        3329, 3671, 4027, 4409, 4813, 5237, 5683, 6143
    };

    FDN16Tank() {
        baseDelayLengths.fill(1500);
        activeDelayLengths.fill(1500);
        writePointers.fill(0);
        feedbackGains.fill(0.85f);
        dampState.fill(0.0f);
        lfoPhases.fill(0.0f);
    }

    void prepare(double sampleRate) {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        scaleFactor = static_cast<float>(sr / 48000.0);

        // 4 velocità LFO non armoniche a rapporti primi per distruggere onde stazionarie
        // (Lexicon 480L / Valhalla dimensional chorus)
        static constexpr float lfoFrequencies[4] = { 0.51f, 0.73f, 0.89f, 1.13f };
        for (int i = 0; i < 4; ++i) {
            lfoRates[i] = static_cast<float>(6.283185307179586 * lfoFrequencies[i] / sr);
        }
        for (int i = 0; i < NUM_LINES; ++i) {
            lfoPhases[i] = static_cast<float>(i) * 0.392699f;
        }

        for (int i = 0; i < NUM_LINES; ++i) {
            int len = static_cast<int>(PRIME_DELAYS[i] * scaleFactor);
            baseDelayLengths[i] = len;
            activeDelayLengths[i] = len;
            int maxCap = std::max(65536, len * 4);
            delayBuffers[i].assign(maxCap, 0.0f);
            writePointers[i] = 0;
            feedbackGains[i] = 0.85f;
            dampState[i] = 0.0f;
        }

        updateDecay(2.5f, 1.0f, 0.0f);
        updateDamping(6500.0f);
    }

    void reset() noexcept {
        dampState.fill(0.0f);
        writePointers.fill(0);
        for (auto& buf : delayBuffers) {
            std::fill(buf.begin(), buf.end(), 0.0f);
        }
    }

    void updateDecay(float decayTimeSec, float roomSizeFactor = 1.0f, float lowWarmthDb = 0.0f) {
        currentDecay = std::max(0.1f, decayTimeSec);
        isFreeze = (decayTimeSec >= 19.5f);
        float clampedSize = std::clamp(roomSizeFactor, 0.5f, 2.0f);

        // Scalatura fisica dei ritardi (geometria stanza)
        float effectiveDecay = currentDecay * std::sqrt(clampedSize);
        float bassDecayMult = std::pow(10.0f, std::clamp(lowWarmthDb, -12.0f, 12.0f) / 30.0f);

        for (int i = 0; i < NUM_LINES; ++i) {
            activeDelayLengths[i] = static_cast<int>(static_cast<float>(baseDelayLengths[i]) * clampedSize);

            if (isFreeze) {
                feedbackGains[i] = 0.999f;
            } else {
                float lineDecay = (i >= 8) ? (effectiveDecay * bassDecayMult) : effectiveDecay;
                lineDecay = std::max(0.1f, lineDecay);
                float exponent = -3.0f * static_cast<float>(activeDelayLengths[i]) / (lineDecay * static_cast<float>(sr));
                feedbackGains[i] = std::pow(10.0f, exponent);
                feedbackGains[i] = std::clamp(feedbackGains[i], 0.0f, 0.985f);
            }
        }
    }

    void updateDamping(float highDampingHz) {
        float fCut = std::clamp(highDampingHz, 1000.0f, 18000.0f);
        dampAlpha = 1.0f - std::exp(-6.2831853f * fCut / static_cast<float>(sr));
    }

    // Fast Walsh-Hadamard Transform a 16 punti (FWHT-16)
    // Matrice unitaria a massima diffusione: accoppiamento rigorosamente uniforme 0.25 su tutti i canali
    static inline void fwht16(std::array<float, NUM_LINES>& a) noexcept {
        // Stage 1
        for (int i = 0; i < 16; i += 2) {
            float x = a[i], y = a[i + 1];
            a[i] = x + y; a[i + 1] = x - y;
        }
        // Stage 2
        for (int i = 0; i < 16; i += 4) {
            for (int j = 0; j < 2; ++j) {
                float x = a[i + j], y = a[i + j + 2];
                a[i + j] = x + y; a[i + j + 2] = x - y;
            }
        }
        // Stage 3
        for (int i = 0; i < 16; i += 8) {
            for (int j = 0; j < 4; ++j) {
                float x = a[i + j], y = a[i + j + 4];
                a[i + j] = x + y; a[i + j + 4] = x - y;
            }
        }
        // Stage 4
        for (int j = 0; j < 8; ++j) {
            float x = a[j], y = a[j + 8];
            a[j] = x + y; a[j + 8] = x - y;
        }
        // Normalizzazione ortogonale: 1 / sqrt(16) = 0.25
        for (int i = 0; i < 16; ++i) {
            a[i] *= 0.25f;
        }
    }

    void processSample(float inL, float inR, float shimmerL, float shimmerR, float& outL, float& outR) {
        std::array<float, NUM_LINES> readSamples;

        // Avanzamento dei 4 oscillatori LFO decorrelati
        for (int i = 0; i < NUM_LINES; ++i) {
            lfoPhases[i] += lfoRates[i % 4];
            if (lfoPhases[i] >= 6.2831853f) lfoPhases[i] -= 6.2831853f;

            // Modulazione delicata e setosa (ampiezza 2.5 campioni)
            float modOffset = std::sin(lfoPhases[i]) * 2.5f;
            float rPosF = static_cast<float>(writePointers[i] - activeDelayLengths[i]) + modOffset;
            int cap = static_cast<int>(delayBuffers[i].size());
            while (rPosF < 0.0f) rPosF += static_cast<float>(cap);
            int idx0 = static_cast<int>(rPosF);
            int idx1 = (idx0 + 1) % cap;
            float frac = rPosF - static_cast<float>(idx0);

            float raw = delayBuffers[i][idx0] + frac * (delayBuffers[i][idx1] - delayBuffers[i][idx0]);

            // High Damping (Air absorption LPF) con protezione attiva anti-denormal
            dampState[i] += (raw - dampState[i]) * dampAlpha;
            if (std::abs(dampState[i]) < 1.0e-20f) dampState[i] = 0.0f;

            readSamples[i] = dampState[i] * feedbackGains[i];
        }

        // Massima diffusione tramite Walsh-Hadamard Transform (zero flutter, zero metallic ringing)
        fwht16(readSamples);

        float sumL = 0.0f;
        float sumR = 0.0f;

        for (int i = 0; i < NUM_LINES; ++i) {
            float inSig = (i % 2 == 0) ? inL : inR;
            if (i % 4 == 0) inSig += shimmerL;
            if (i % 4 == 1) inSig += shimmerR;

            float toWrite = inSig + readSamples[i];

            // Soft-saturation solo sui picchi estremi di ingresso
            if (toWrite > 1.4f || toWrite < -1.4f) {
                toWrite = std::tanh(toWrite * 0.75f) * 1.333f;
            }

            if (std::abs(toWrite) < 1.0e-20f) toWrite = 0.0f;

            delayBuffers[i][writePointers[i]] = toWrite;
            writePointers[i] = (writePointers[i] + 1) % static_cast<int>(delayBuffers[i].size());

            // Decodifica stereo spaziale naturale
            if (i % 2 == 0) sumL += readSamples[i] * ((i < 8) ? 1.0f : -0.7f);
            else            sumR += readSamples[i] * ((i < 8) ? 0.7f : -1.0f);
        }

        constexpr float NORM = 0.35f;
        outL = sumL * NORM;
        outR = sumR * NORM;
    }

private:
    double sr = 48000.0;
    float scaleFactor = 1.0f;
    float currentDecay = 2.5f;
    float dampAlpha = 0.5f;
    bool isFreeze = false;

    std::array<float, 4> lfoRates = { 0.000065f, 0.000095f, 0.000115f, 0.000145f };
    std::array<float, NUM_LINES> lfoPhases;

    std::array<int, NUM_LINES> baseDelayLengths;
    std::array<int, NUM_LINES> activeDelayLengths;
    std::array<std::vector<float>, NUM_LINES> delayBuffers;
    std::array<int, NUM_LINES> writePointers;
    std::array<float, NUM_LINES> dampState;
    std::array<float, NUM_LINES> feedbackGains;
};

// ==============================================================================
// 7. PRE-DELAY & EARLY REFLECTIONS CON ASSORBIMENTO ACUSTICO DELLE PARETI
// ==============================================================================
class EarlyReflectionsEngine {
public:
    EarlyReflectionsEngine() = default;

    void prepare(double sampleRate) {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        int maxSamples = static_cast<int>(sr * 0.40);
        bufferL.assign(maxSamples, 0.0f);
        bufferR.assign(maxSamples, 0.0f);
        writePos = 0;
        setPreDelay(20.0f);

        // Filtro passa-basso di assorbimento pareti a 5500 Hz (elimina il clangore metallico)
        erLpAlpha = 1.0f - std::exp(-6.2831853f * 5500.0f / static_cast<float>(sr));
        erLpStateL = 0.0f;
        erLpStateR = 0.0f;
    }

    void setPreDelay(float preDelayMs) {
        int samples = static_cast<int>((std::clamp(preDelayMs, 0.0f, 250.0f) * 0.001f) * static_cast<float>(sr));
        preDelaySamples = std::max(1, samples);
    }

    void process(float inL, float inR, float& erL, float& erR, float& delayedDryL, float& delayedDryR) {
        int cap = static_cast<int>(bufferL.size());
        bufferL[writePos] = (std::abs(inL) < 1.0e-20f) ? 0.0f : inL;
        bufferR[writePos] = (std::abs(inR) < 1.0e-20f) ? 0.0f : inR;

        int rPos = writePos - preDelaySamples;
        if (rPos < 0) rPos += cap;
        delayedDryL = bufferL[rPos];
        delayedDryR = bufferR[rPos];

        static const float tapOffsetsMs[6] = { 7.5f, 13.2f, 19.8f, 28.4f, 37.1f, 49.3f };
        static const float tapGainsL[6]    = { 0.55f, -0.40f,  0.32f, -0.25f,  0.20f, -0.15f };
        static const float tapGainsR[6]    = { -0.40f, 0.55f, -0.28f,  0.35f, -0.16f,  0.20f };

        float accL = 0.0f;
        float accR = 0.0f;

        for (int t = 0; t < 6; ++t) {
            int tSample = preDelaySamples + static_cast<int>(tapOffsetsMs[t] * 0.001f * static_cast<float>(sr));
            int p = writePos - tSample;
            while (p < 0) p += cap;
            accL += bufferL[p] * tapGainsL[t];
            accR += bufferR[p] * tapGainsR[t];
        }

        // Applicazione assorbimento pareti (One-pole LPF)
        erLpStateL += (accL * 0.5f - erLpStateL) * erLpAlpha;
        erLpStateR += (accR * 0.5f - erLpStateR) * erLpAlpha;
        if (std::abs(erLpStateL) < 1.0e-20f) erLpStateL = 0.0f;
        if (std::abs(erLpStateR) < 1.0e-20f) erLpStateR = 0.0f;

        erL = erLpStateL;
        erR = erLpStateR;

        writePos = (writePos + 1) % cap;
    }

private:
    double sr = 48000.0;
    int preDelaySamples = 960;
    std::vector<float> bufferL;
    std::vector<float> bufferR;
    int writePos = 0;
    float erLpAlpha = 0.5f;
    float erLpStateL = 0.0f;
    float erLpStateR = 0.0f;
};

// ==============================================================================
// 8. MASTER SPACE LUXE REVERB ENGINE v2.0
// ==============================================================================
class SpaceLuxeEngine {
public:
    SpaceLuxeEngine() = default;

    void prepare(double sampleRate, int /*samplesPerBlock*/) {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;

        earlyReflections.prepare(sr);
        inputDiffuser.prepare(sr);
        fdnTank.prepare(sr);
        shimmer.prepare(sr);
        smartDucking.prepare(sr);

        // Filtro subsonico a 28 Hz ZDF ad alta precisione
        subsonicHpfL.reset();
        subsonicHpfL.setParameters(28.0f, 0.7071f, static_cast<float>(sr));
        subsonicHpfR.reset();
        subsonicHpfR.setParameters(28.0f, 0.7071f, static_cast<float>(sr));

        monoMakerFilter.reset();
        monoMakerFilter.setParameters(120.0f, 0.7071f, static_cast<float>(sr));

        warmthShelfL.prepare(sr);
        warmthShelfR.prepare(sr);

        vocalDetectorL.prepare(sr);
        vocalDetectorR.prepare(sr);

        vocalMidBandFilterL.reset();
        vocalMidBandFilterL.setParameters(2200.0f, 0.7071f, static_cast<float>(sr));
        vocalMidBandFilterR.reset();
        vocalMidBandFilterR.setParameters(2200.0f, 0.7071f, static_cast<float>(sr));

        midEnv = 0.0f;
    }

    void reset() {
        earlyReflections.prepare(sr);
        inputDiffuser.reset();
        fdnTank.reset();
        subsonicHpfL.reset();
        subsonicHpfR.reset();
        monoMakerFilter.reset();
        warmthShelfL.reset();
        warmthShelfR.reset();
        vocalDetectorL.reset();
        vocalDetectorR.reset();
        vocalMidBandFilterL.reset();
        vocalMidBandFilterR.reset();
        midEnv = 0.0f;
    }

    void setParametersV2(float preDelayMs,
                         float decayTimeSec,
                         float roomSize,
                         float highDampingHz,
                         float lowWarmthDb,
                         float shimmerAmount,
                         float duckAmountPercent,
                         float tailBloomDb,
                         bool autoSense,
                         bool spectralFocus,
                         float stereoWidth,
                         float monoMakerFreqHz,
                         float dryWetMix)
    {
        earlyReflections.setPreDelay(preDelayMs);
        fdnTank.updateDecay(decayTimeSec, roomSize, lowWarmthDb);
        fdnTank.updateDamping(highDampingHz);

        warmthShelfL.setParameters(220.0f, lowWarmthDb);
        warmthShelfR.setParameters(220.0f, lowWarmthDb);

        currentShimmerAmount = std::clamp(shimmerAmount, 0.0f, 1.0f);

        smartDucking.setParametersV2(duckAmountPercent, tailBloomDb, autoSense, spectralFocus);

        currentStereoWidth = std::clamp(stereoWidth, 0.0f, 2.0f);
        monoMakerFilter.setParameters(std::clamp(monoMakerFreqHz, 40.0f, 300.0f), 0.7071f, static_cast<float>(sr));
        currentDryWet = std::clamp(dryWetMix, 0.0f, 1.0f);
    }

    void setParameters(float preDelayMs,
                       float decayTimeSec,
                       float roomSize,
                       float highDampingHz,
                       float lowWarmthDb,
                       float shimmerAmount,
                       float duckThresholdDb,
                       float duckDepthDb,
                       float stereoWidth,
                       float monoMakerFreqHz,
                       float dryWetMix)
    {
        earlyReflections.setPreDelay(preDelayMs);
        fdnTank.updateDecay(decayTimeSec, roomSize, lowWarmthDb);
        fdnTank.updateDamping(highDampingHz);

        warmthShelfL.setParameters(220.0f, lowWarmthDb);
        warmthShelfR.setParameters(220.0f, lowWarmthDb);

        currentShimmerAmount = std::clamp(shimmerAmount, 0.0f, 1.0f);
        smartDucking.setParameters(duckThresholdDb, duckDepthDb);

        currentStereoWidth = std::clamp(stereoWidth, 0.0f, 2.0f);
        monoMakerFilter.setParameters(std::clamp(monoMakerFreqHz, 40.0f, 300.0f), 0.7071f, static_cast<float>(sr));

        currentDryWet = std::clamp(dryWetMix, 0.0f, 1.0f);
    }

    void processBlock(juce::AudioBuffer<float>& buffer,
                      const juce::AudioBuffer<float>* sidechainBuffer = nullptr,
                      bool useExternalSidechain = false)
    {
        const int numSamples = buffer.getNumSamples();
        if (buffer.getNumChannels() < 2 || numSamples <= 0) return;

        float* channelL = buffer.getWritePointer(0);
        float* channelR = buffer.getWritePointer(1);

        const float* scL = nullptr;
        const float* scR = nullptr;
        if (useExternalSidechain && sidechainBuffer != nullptr && sidechainBuffer->getNumChannels() > 0) {
            scL = sidechainBuffer->getReadPointer(0);
            scR = (sidechainBuffer->getNumChannels() > 1) ? sidechainBuffer->getReadPointer(1) : scL;
        }

        for (int i = 0; i < numSamples; ++i) {
            float inL = channelL[i];
            float inR = channelR[i];

            // 1. Smart Ducking & Tail Bloom Gain Calculation
            float duckInL = (scL != nullptr) ? scL[i] : inL;
            float duckInR = (scR != nullptr) ? scR[i] : inR;

            float keyL = duckInL;
            float keyR = duckInR;
            if (smartDucking.isSpectralFocusActive()) {
                keyL = vocalDetectorL.process(duckInL);
                keyR = vocalDetectorR.process(duckInR);
            }

            float duckGain = smartDucking.processSample(keyL, keyR);

            // 2. Pre-Delay ed Early Reflections con assorbimento acustico
            float erL = 0.0f, erR = 0.0f;
            float delayedDryL = 0.0f, delayedDryR = 0.0f;
            earlyReflections.process(inL, inR, erL, erR, delayedDryL, delayedDryR);

            // 3. Shimmer Pitch Shift (+1 Ottava)
            float shimL = 0.0f, shimR = 0.0f;
            shimmer.process(delayedDryL, delayedDryR, shimL, shimR, currentShimmerAmount);

            // 4. Schroeder / Dattorro 4-Stage Allpass Input Diffuser (diffusione setosa)
            float diffL = 0.0f, diffR = 0.0f;
            inputDiffuser.process(delayedDryL, delayedDryR, diffL, diffR);

            // 5. FDN-16 Reverb Tank con Walsh-Hadamard Diffusion & Modulazione Multi-Rate
            float lateL = 0.0f, lateR = 0.0f;
            fdnTank.processSample(diffL, diffR, shimL, shimR, lateL, lateR);

            // 6. Somma ER + Late Reverb con filtro subsonico 28 Hz ZDF stabile
            float wetL = erL * 0.6f + lateL;
            float wetR = erR * 0.6f + lateR;

            wetL = subsonicHpfL.process(wetL).hp;
            wetR = subsonicHpfR.process(wetR).hp;

            // 7. Warmth Low-Shelf Pulito e Morbido (zero cancellazioni di fase)
            wetL = warmthShelfL.process(wetL);
            wetR = warmthShelfR.process(wetR);

            // 8. Applicazione Smart Ducking & Tail Bloom Swell
            wetL *= duckGain;
            wetR *= duckGain;

            // 9. Mid/Side Stereo Spreader & Mono-Maker con Stereo Bloom Expansion
            float mid  = 0.5f * (wetL + wetR);
            float side = 0.5f * (wetL - wetR);

            auto mmOut = monoMakerFilter.process(side);
            float effectiveWidth = currentStereoWidth * smartDucking.getStereoBloomMultiplier();
            float rawSide = mmOut.hp * effectiveWidth;

            // Inseguitore di inviluppo Mid per la protezione della correlazione di fase stereo
            float absMid = std::abs(mid);
            midEnv += (absMid - midEnv) * (absMid > midEnv ? 0.08f : 0.002f);
            if (midEnv < 1.0e-20f) midEnv = 0.0f;

            // Limiter Mid/Side continuo e morbido (zero discontinuità né gradini nel decadimento della coda)
            float limitedSide = rawSide;
            if (effectiveWidth > 1.0f) {
                float threshold = std::max(1.0e-4f, midEnv * 1.30f);
                float absSide = std::abs(rawSide);
                if (absSide > threshold) {
                    float ratio = threshold / absSide;
                    limitedSide = rawSide * (0.6f * ratio + 0.4f);
                }
            }
            side = limitedSide;

            float finalWetL = mid + side;
            float finalWetR = mid - side;

            // 10. Crossfade Dry/Wet a potenza costante
            float angle = currentDryWet * 1.5707963f;
            float dryCoeff = std::cos(angle);
            float wetCoeff = std::sin(angle);

            float outL = inL * dryCoeff + finalWetL * wetCoeff;
            float outR = inR * dryCoeff + finalWetR * wetCoeff;

            // 11. Safety Ceiling Limiter (-0.1 dBFS)
            constexpr float CEIL = 0.98855f;
            if (outL > CEIL) outL = CEIL; else if (outL < -CEIL) outL = -CEIL;
            if (outR > CEIL) outR = CEIL; else if (outR < -CEIL) outR = -CEIL;

            channelL[i] = outL;
            channelR[i] = outR;
        }
    }

    float getDuckingReductionDb() const noexcept {
        return smartDucking.getGainReductionDb();
    }

    float getBloomGainDb() const noexcept {
        return smartDucking.getBloomGainDb();
    }

    float getMaxObservedDuckingGR() const noexcept {
        return smartDucking.getMaxObservedGR();
    }

    float getMaxObservedBloom() const noexcept {
        return smartDucking.getMaxObservedBloom();
    }

    bool isDuckingActive() const noexcept {
        return smartDucking.isDuckingActive();
    }

    bool isBloomActive() const noexcept {
        return smartDucking.isBloomActive();
    }

    void resetDuckingStats() noexcept {
        smartDucking.resetStats();
    }

private:
    double sr = 48000.0;
    EarlyReflectionsEngine earlyReflections;
    InputDiffuser4Stage inputDiffuser;
    FDN16Tank fdnTank;
    ShimmerPitchEngine shimmer;
    SmartDuckingEngine smartDucking;

    ZDFSVF64 subsonicHpfL;
    ZDFSVF64 subsonicHpfR;

    ZDFSVF64 monoMakerFilter;
    BiquadLowShelf warmthShelfL;
    BiquadLowShelf warmthShelfR;

    VocalFocusWeightingFilter vocalDetectorL;
    VocalFocusWeightingFilter vocalDetectorR;
    ZDFSVF64 vocalMidBandFilterL;
    ZDFSVF64 vocalMidBandFilterR;

    float currentShimmerAmount = 0.0f;
    float currentStereoWidth = 1.0f;
    float currentDryWet = 0.35f;
    float midEnv = 0.0f;
};

} // namespace dsp171
