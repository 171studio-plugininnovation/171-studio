#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <algorithm>

namespace plugin_171 {

// ==============================================================================
// BARRA E ANGOLARE DI RIDIMENSIONAMENTO DINAMICO BOUTIQUE 171
// Base: 960x620 (16:10.3) con aspect ratio lock, grip in ottone a 45°
// e visualizzazione percentuale di zoom vettoriale ad alta definizione.
// ==============================================================================
class ResizableHandleComponent : public juce::Component {
public:
    std::function<void(float currentScale)> onScaleChanged;

    ResizableHandleComponent() {
        setMouseCursor(juce::MouseCursor::BottomRightCornerResizeCursor);
    }

    ~ResizableHandleComponent() override = default;

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat();
        if (bounds.isEmpty()) return;

        const float w = bounds.getWidth();
        const float h = bounds.getHeight();

        // 1. Scanalature d'ombra a 45 gradi
        g.setColour(juce::Colour(0x70000000));
        g.drawLine(w - 4.0f, h, w, h - 4.0f, 1.6f);
        g.drawLine(w - 8.0f, h, w, h - 8.0f, 1.6f);
        g.drawLine(w - 12.0f, h, w, h - 12.0f, 1.6f);
        g.drawLine(w - 16.0f, h, w, h - 16.0f, 1.6f);

        // 2. Rilievi cesellati in foglia d'oro / ottone 171
        g.setColour(isHovered ? juce::Colour(0xffffe899) : juce::Colour(0xffc5a059));
        g.drawLine(w - 5.0f, h, w, h - 5.0f, 1.3f);
        g.drawLine(w - 9.0f, h, w, h - 9.0f, 1.3f);
        g.drawLine(w - 13.0f, h, w, h - 13.0f, 1.3f);
        g.drawLine(w - 17.0f, h, w, h - 17.0f, 1.3f);

        // 3. Tooltip zoom in sovraimpressione durante drag o hover
        if (isDragging || isHovered) {
            drawScaleTooltip(g);
        }
    }

    void mouseEnter(const juce::MouseEvent&) override {
        isHovered = true;
        repaint();
    }

    void mouseExit(const juce::MouseEvent&) override {
        isHovered = false;
        repaint();
    }

    void mouseDown(const juce::MouseEvent& e) override {
        if (auto* parent = findEditorParent()) {
            originalSize = parent->getBounds();
            dragStartPos = e.getScreenPosition();
            isDragging = true;
            repaint();
        }
    }

    void mouseDrag(const juce::MouseEvent& e) override {
        if (!isDragging) return;
        if (auto* parent = findEditorParent()) {
            auto delta = e.getScreenPosition() - dragStartPos;

            constexpr float baseWidth   = 960.0f;
            constexpr float baseHeight  = 620.0f;
            constexpr float aspectRatio = baseWidth / baseHeight;

            int newWidth = originalSize.getWidth() + delta.x;
            newWidth = std::clamp(newWidth, 768, 2400); // 80% fino a 250%
            int newHeight = juce::roundToInt(static_cast<float>(newWidth) / aspectRatio);

            parent->setSize(newWidth, newHeight);

            currentScaleRatio = static_cast<float>(newWidth) / baseWidth;
            if (onScaleChanged) {
                onScaleChanged(currentScaleRatio);
            }
            repaint();
        }
    }

    void mouseUp(const juce::MouseEvent&) override {
        isDragging = false;
        repaint();
    }

    float getCurrentScale() const noexcept { return currentScaleRatio; }

private:
    juce::Component* findEditorParent() {
        juce::Component* c = getParentComponent();
        while (c != nullptr) {
            if (dynamic_cast<juce::AudioProcessorEditor*>(c) != nullptr)
                return c;
            if (c->getParentComponent() == nullptr)
                return c;
            c = c->getParentComponent();
        }
        return getParentComponent();
    }

    void drawScaleTooltip(juce::Graphics& g) {
        int percent = juce::roundToInt(currentScaleRatio * 100.0f);
        juce::String text = juce::String(percent) + "%";

        auto tooltipRect = juce::Rectangle<float>(0.0f, 0.0f, 42.0f, 15.0f);
        g.setColour(juce::Colour(0xf012141a));
        g.fillRoundedRectangle(tooltipRect, 3.0f);
        g.setColour(juce::Colour(0xffc5a059));
        g.drawRoundedRectangle(tooltipRect, 3.0f, 1.0f);

        g.setFont(juce::FontOptions("DIN 1451 Mittelschrift", 9.5f, juce::Font::bold));
        g.setColour(juce::Colour(0xffffe899));
        g.drawText(text, tooltipRect, juce::Justification::centred);
    }

    bool isHovered = false;
    bool isDragging = false;
    juce::Rectangle<int> originalSize;
    juce::Point<int> dragStartPos;
    float currentScaleRatio = 1.0f;
};

} // namespace plugin_171
