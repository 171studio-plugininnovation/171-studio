#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_graphics/juce_graphics.h>
#include <vector>
#include <array>
#include <cmath>
#include <algorithm>

namespace plugin_171 {

// ==============================================================================
// 3D WATERFALL CRT REVERB DECAY SPECTROGRAM — BOUTIQUE 171 STANDARD
// Highly-optimized vector visualizer driven synchronously by editor timer (30 FPS).
// Uses cached static backing image for gold bezel, CRT glass, grid and scanlines.
// Zero heap allocations in paint() — 100% Real-Time & Host Safe.
// ==============================================================================
class SpaceLuxeWaterfallDisplay : public juce::Component {
public:
    static constexpr int NUM_BINS = 28;       // 28 bande di frequenza logaritmiche
    static constexpr int NUM_SLICES = 18;     // 18 fette storiche a cascata 3D fluide

    SpaceLuxeWaterfallDisplay() {
        for (auto& slice : slices) {
            slice.fill(0.0f);
        }
        currentSpectrum.fill(0.0f);
    }

    ~SpaceLuxeWaterfallDisplay() override = default;

    // Inietta energia di frequenza dal thread GUI (chiamato a 30 FPS)
    void pushAudioEnergy(float lowEnergy, float midEnergy, float highEnergy, float duckingDb, float bloomDb = 0.0f) {
        currentLow = lowEnergy;
        currentMid = midEnergy;
        currentHigh = highEnergy;
        duckReduction = duckingDb;
        bloomGain = bloomDb;

        // Genera la nuova fetta interpolata in base all'energia
        std::array<float, NUM_BINS> newSlice;
        for (int b = 0; b < NUM_BINS; ++b) {
            float frac = static_cast<float>(b) / static_cast<float>(NUM_BINS - 1);
            float energy = 0.0f;
            if (frac < 0.25f) {
                energy = currentLow * (1.0f - frac * 4.0f) + currentMid * (frac * 4.0f);
            } else if (frac < 0.65f) {
                float f2 = (frac - 0.25f) / 0.4f;
                energy = currentMid * (1.0f - f2) + currentHigh * f2;
            } else {
                energy = currentHigh;
            }

            newSlice[b] = std::clamp(energy, 0.0f, 1.0f);
        }

        // Fai scorrere le fette verso il retro della cascata 3D
        for (int s = NUM_SLICES - 1; s > 0; --s) {
            for (int b = 0; b < NUM_BINS; ++b) {
                slices[s][b] = slices[s - 1][b] * 0.93f;
            }
        }
        slices[0] = newSlice;

        // Decadimento dell'energia iniettata
        currentLow  *= 0.86f;
        currentMid  *= 0.83f;
        currentHigh *= 0.80f;

        repaint();
    }

    void resized() override {
        rebuildBackingCache();
    }

    void paint(juce::Graphics& g) override {
        auto totalBounds = getLocalBounds().toFloat();
        if (totalBounds.isEmpty()) return;

        // 1. Disegna il telaio e CRT di fondo dalla cache (0 ms CPU)
        if (backingCache.isValid()) {
            g.drawImageAt(backingCache, 0, 0);
        }

        float inset = 7.0f;
        auto crtBounds = totalBounds.reduced(inset);

        // 2. Rendering delle 18 Fette Isometriche 3D
        float originX = crtBounds.getX() + 18.0f;
        float originY = crtBounds.getY() + crtBounds.getHeight() * 0.77f;
        float plotWidth = crtBounds.getWidth() - 36.0f;

        for (int s = NUM_SLICES - 1; s >= 0; --s) {
            float depthFrac = static_cast<float>(s) / static_cast<float>(NUM_SLICES);
            float invDepth = 1.0f - depthFrac;

            float sliceOffsetY = -depthFrac * (crtBounds.getHeight() * 0.52f);
            float sliceOffsetX = depthFrac * 12.0f;
            float sliceScaleX  = 1.0f - depthFrac * 0.15f;

            juce::Colour sliceColor = (s == 0)
                ? juce::Colour(0xff00f5ff) // Fronte attivo: ciano elettrico ultra-brillante
                : juce::Colour::fromFloatRGBA(
                    0.08f + invDepth * 0.75f,
                    0.40f + invDepth * 0.55f,
                    0.95f,
                    0.20f + invDepth * 0.70f
                  );

            juce::Path slicePath;
            bool firstPoint = true;

            for (int b = 0; b < NUM_BINS; ++b) {
                float xFrac = static_cast<float>(b) / static_cast<float>(NUM_BINS - 1);
                float px = originX + sliceOffsetX + (xFrac * plotWidth * sliceScaleX);
                
                float val = slices[s][b];
                float heightPeak = val * (crtBounds.getHeight() * 0.38f);
                float py = originY + sliceOffsetY - heightPeak;

                if (firstPoint) {
                    slicePath.startNewSubPath(px, py);
                    firstPoint = false;
                } else {
                    slicePath.lineTo(px, py);
                }
            }

            if (s == 0) {
                g.setColour(juce::Colour(0x3500f5ff));
                g.strokePath(slicePath, juce::PathStrokeType(3.5f));
            }

            g.setColour(sliceColor);
            g.strokePath(slicePath, juce::PathStrokeType(s == 0 ? 1.8f : 1.1f));
        }

        // 3. Telemetria Dinamica: Smart Duck & Tail Bloom Status
        auto teleBounds = crtBounds.removeFromTop(24).reduced(12, 3);
        if (bloomGain > 0.3f) {
            float bloomAlpha = std::clamp(bloomGain / 4.0f, 0.45f, 1.0f);
            g.setColour(juce::Colour(0xffffd700).withAlpha(bloomAlpha));
            g.setFont(juce::FontOptions(11.5f, juce::Font::bold));
            g.drawText("TAIL BLOOM ACTIVE: +" + juce::String(bloomGain, 1) + " dB",
                       teleBounds.toNearestInt(), juce::Justification::topRight, false);
        } else if (duckReduction > 0.4f) {
            float duckAlpha = std::clamp(duckReduction / 12.0f, 0.35f, 1.0f);
            g.setColour(juce::Colour(0xffff9900).withAlpha(duckAlpha));
            g.setFont(juce::FontOptions(11.5f, juce::Font::bold));
            g.drawText("SMART DUCK ACTIVE: -" + juce::String(duckReduction, 1) + " dB",
                       teleBounds.toNearestInt(), juce::Justification::topRight, false);
        } else {
            g.setColour(juce::Colour(0x5500e5ff));
            g.setFont(juce::FontOptions(10.0f, juce::Font::plain));
            g.drawText("DECAY SPECTRUM 3D", teleBounds.toNearestInt(), juce::Justification::topRight, false);
        }

        // 4. Riflesso ottico bombato in vetro CRT
        juce::ColourGradient glassGrad(
            juce::Colour(0x30ffffff), crtBounds.getX(), crtBounds.getY(),
            juce::Colour(0x02ffffff), crtBounds.getX() + crtBounds.getWidth() * 0.55f, crtBounds.getY() + crtBounds.getHeight() * 0.65f,
            false
        );
        g.setGradientFill(glassGrad);
        g.fillRoundedRectangle(crtBounds, 6.0f);
    }

private:
    void rebuildBackingCache() {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        backingCache = juce::Image(juce::Image::ARGB, w, h, true);
        juce::Graphics g(backingCache);
        auto totalBounds = juce::Rectangle<float>(0, 0, static_cast<float>(w), static_cast<float>(h));

        // Cornice in ottone cesellato
        float chamfer = 12.0f;
        juce::Path bezelPath;
        bezelPath.startNewSubPath(totalBounds.getX() + chamfer, totalBounds.getY());
        bezelPath.lineTo(totalBounds.getRight() - chamfer, totalBounds.getY());
        bezelPath.lineTo(totalBounds.getRight(), totalBounds.getY() + chamfer);
        bezelPath.lineTo(totalBounds.getRight(), totalBounds.getBottom() - chamfer);
        bezelPath.lineTo(totalBounds.getRight() - chamfer, totalBounds.getBottom());
        bezelPath.lineTo(totalBounds.getX() + chamfer, totalBounds.getBottom());
        bezelPath.lineTo(totalBounds.getX(), totalBounds.getBottom() - chamfer);
        bezelPath.lineTo(totalBounds.getX(), totalBounds.getY() + chamfer);
        bezelPath.closeSubPath();

        // Ombra esterna
        g.setColour(juce::Colours::black.withAlpha(0.65f));
        g.fillPath(bezelPath, juce::AffineTransform::translation(1.5f, 2.5f));

        // Gradiente dorato del telaio
        juce::ColourGradient bezelGrad(
            juce::Colour(0xffffe58a), totalBounds.getX(), totalBounds.getY(),
            juce::Colour(0xff4a3518), totalBounds.getRight(), totalBounds.getBottom(), false);
        bezelGrad.addColour(0.35, juce::Colour(0xff8c7047));
        bezelGrad.addColour(0.70, juce::Colour(0xff5c4320));
        g.setGradientFill(bezelGrad);
        g.fillPath(bezelPath);

        g.setColour(juce::Colour(0xffffe899).withAlpha(0.75f));
        g.strokePath(bezelPath, juce::PathStrokeType(1.4f));

        // Incasso e Schermo CRT
        float inset = 7.0f;
        auto crtBounds = totalBounds.reduced(inset);
        g.setColour(juce::Colour(0xff05070a));
        g.fillRoundedRectangle(crtBounds, 7.0f);

        juce::ColourGradient crtBg(
            juce::Colour(0xff0a1420), crtBounds.getCentreX(), crtBounds.getCentreY(),
            juce::Colour(0xff03060a), crtBounds.getX(), crtBounds.getY(), true);
        g.setGradientFill(crtBg);
        g.fillRoundedRectangle(crtBounds, 6.0f);

        // Griglia CRT al fosforo ciano
        g.setColour(juce::Colour(0x1500e5ff));
        constexpr int gridCols = 8;
        constexpr int gridRows = 5;
        for (int c = 1; c < gridCols; ++c) {
            float x = crtBounds.getX() + (crtBounds.getWidth() / gridCols) * c;
            g.drawVerticalLine(static_cast<int>(x), crtBounds.getY(), crtBounds.getBottom());
        }
        for (int r = 1; r < gridRows; ++r) {
            float y = crtBounds.getY() + (crtBounds.getHeight() / gridRows) * r;
            g.drawHorizontalLine(static_cast<int>(y), crtBounds.getX(), crtBounds.getRight());
        }

        // Scanlines CRT pre-renderizzate (frequenza 4px, zero impatto CPU runtime)
        g.setColour(juce::Colours::black.withAlpha(0.12f));
        int startY = static_cast<int>(crtBounds.getY());
        int endY   = static_cast<int>(crtBounds.getBottom());
        for (int y = startY; y < endY; y += 4) {
            g.drawHorizontalLine(y, crtBounds.getX(), crtBounds.getRight());
        }

        // Bordo interno fosforo
        g.setColour(juce::Colour(0x3000d4ff));
        g.drawRoundedRectangle(crtBounds, 6.0f, 1.0f);
    }

    std::array<std::array<float, NUM_BINS>, NUM_SLICES> slices;
    std::array<float, NUM_BINS> currentSpectrum;

    float currentLow = 0.0f;
    float currentMid = 0.0f;
    float currentHigh = 0.0f;
    float duckReduction = 0.0f;
    float bloomGain = 0.0f;

    juce::Image backingCache;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SpaceLuxeWaterfallDisplay)
};

} // namespace plugin_171
