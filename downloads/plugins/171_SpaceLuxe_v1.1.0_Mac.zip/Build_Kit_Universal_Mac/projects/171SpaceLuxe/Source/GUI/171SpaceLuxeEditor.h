#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_graphics/juce_graphics.h>
#include <BinaryData.h>
#include <cmath>
#include <algorithm>
#include "BoutiqueHardwareLookAndFeel.h"
#include "BoutiqueHardwareComponents.h"
#include "SpaceLuxeWaterfallDisplay.h"
#include "ResizableHandleComponent.h"
#include "../PluginProcessor.h"

namespace plugin_171 {

// ==============================================================================
// 171 STUDIO BOUTIQUE HARDWARE LOOK AND FEEL
// Knurled metal dials, glowing neon arcs, laser serigraphy & brass trims
// ==============================================================================
class SpaceLuxeBoutiqueLookAndFeel : public juce::LookAndFeel_V4 {
public:
    enum class KnobTheme {
        CyanSpace,       // Pre-Delay, Decay, Room Size
        AmberDamp,       // High Damp, Low Warmth
        GoldBloom,       // Duck Amount, Tail Bloom
        VioletShimmer,   // Shimmer
        TitaniumMaster   // Width, Mono-Maker, Dry/Wet
    };

    SpaceLuxeBoutiqueLookAndFeel() {
        setColour(juce::Slider::textBoxTextColourId, juce::Colour(0xffffe899));
        setColour(juce::Slider::textBoxBackgroundColourId, juce::Colour(0xff090c10));
        setColour(juce::Slider::textBoxOutlineColourId, juce::Colour(0xff524021));
        setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff12161f));
        setColour(juce::ComboBox::outlineColourId, juce::Colour(0xff6e5428));
        setColour(juce::ComboBox::textColourId, juce::Colour(0xffffe899));
        setColour(juce::ComboBox::arrowColourId, juce::Colour(0xffd4af37));
        setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xff12151c));
        setColour(juce::PopupMenu::textColourId, juce::Colour(0xffffe899));
        setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xff2a3444));
        setColour(juce::PopupMenu::highlightedTextColourId, juce::Colour(0xffffffff));
    }

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPosProportional, float rotaryStartAngle, float rotaryEndAngle,
                          juce::Slider& slider) override
    {
        const auto bounds = juce::Rectangle<float>((float)x, (float)y, (float)width, (float)height);
        if (bounds.isEmpty()) return;

        // Determina il colore tematico della manopola
        KnobTheme theme = KnobTheme::CyanSpace;
        if (slider.getProperties().contains("Theme")) {
            theme = static_cast<KnobTheme>((int)slider.getProperties()["Theme"]);
        }

        juce::Colour neonCol = juce::Colour(0xff00f0ff);
        switch (theme) {
            case KnobTheme::CyanSpace:      neonCol = juce::Colour(0xff00f0ff); break;
            case KnobTheme::AmberDamp:      neonCol = juce::Colour(0xffffa520); break;
            case KnobTheme::GoldBloom:      neonCol = juce::Colour(0xffffd700); break;
            case KnobTheme::VioletShimmer:  neonCol = juce::Colour(0xffff33aa); break;
            case KnobTheme::TitaniumMaster: neonCol = juce::Colour(0xffe8c872); break;
        }

        // Riserva spazio per la pillola del valore sotto
        float textBoxHeight = 18.0f;
        auto knobArea = bounds;
        if (slider.getTextBoxPosition() == juce::Slider::TextBoxBelow) {
            knobArea.removeFromBottom(textBoxHeight);
        }

        const float diameter = juce::jmin(knobArea.getWidth(), knobArea.getHeight());
        const float cx = knobArea.getCentreX();
        const float cy = knobArea.getCentreY();
        const float rBase = diameter * 0.44f;

        const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

        // ----------------------------------------------------------------------
        // 1. SCALA CIRCOLARE GRADUATA CON TACCHE SERIGRAFATE & ARCO INCASSATO
        // ----------------------------------------------------------------------
        const float rTrack = rBase + 1.5f;

        // Pista scura incassata
        juce::Path trackPath;
        trackPath.addCentredArc(cx, cy, rTrack, rTrack, 0.0f, rotaryStartAngle, rotaryEndAngle, true);
        g.setColour(juce::Colour(0xff0c0e12));
        g.strokePath(trackPath, juce::PathStrokeType(3.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // Arco attivo luminoso neon
        if (sliderPosProportional > 0.005f) {
            juce::Path activePath;
            activePath.addCentredArc(cx, cy, rTrack, rTrack, 0.0f, rotaryStartAngle, angle, true);

            // Alone bloom esterno
            g.setColour(neonCol.withAlpha(0.28f));
            g.strokePath(activePath, juce::PathStrokeType(6.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Linea centrale incandescente
            g.setColour(neonCol);
            g.strokePath(activePath, juce::PathStrokeType(2.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Core bianco brillante
            g.setColour(juce::Colours::white.withAlpha(0.65f));
            g.strokePath(activePath, juce::PathStrokeType(0.9f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }

        // Tacche serigrafate calibrate (11 tacche da 0 a 10)
        constexpr int numTicks = 11;
        const float rTickIn = rTrack + 3.0f;
        for (int i = 0; i < numTicks; ++i) {
            float frac = (float)i / (float)(numTicks - 1);
            float a = rotaryStartAngle + frac * (rotaryEndAngle - rotaryStartAngle);
            bool isMajor = (i == 0 || i == 5 || i == 10);
            float tickLen = isMajor ? 5.0f : 3.0f;

            float x1 = cx + std::sin(a) * rTickIn;
            float y1 = cy - std::cos(a) * rTickIn;
            float x2 = cx + std::sin(a) * (rTickIn + tickLen);
            float y2 = cy - std::cos(a) * (rTickIn + tickLen);

            if (frac <= sliderPosProportional && sliderPosProportional > 0.005f) {
                g.setColour(neonCol.brighter(0.2f));
            } else {
                g.setColour(isMajor ? juce::Colour(0xffd4af37) : juce::Colour(0x77c5a059));
            }
            g.drawLine(x1, y1, x2, y2, isMajor ? 1.4f : 0.9f);
        }

        // ----------------------------------------------------------------------
        // 2. GONNA CILINDRICA ZIGRINATA IN METALLO (KNURLED SKIRT 36 DENTI)
        // ----------------------------------------------------------------------
        const float rSkirt = rBase * 0.84f;

        // Ombra portata fissa sul telaio (luce fissa ad ore 10:30)
        g.setColour(juce::Colours::black.withAlpha(0.65f));
        g.fillEllipse(cx - rSkirt + 1.8f, cy - rSkirt + 3.0f, rSkirt * 2.0f, rSkirt * 2.0f);

        // Corona zigrinata con sfumatura d'ottone / titanio canna di fucile
        juce::ColourGradient skirtGrad(
            juce::Colour(0xff606670), cx - rSkirt, cy - rSkirt,
            juce::Colour(0xff16181d), cx + rSkirt, cy + rSkirt, false);
        g.setGradientFill(skirtGrad);
        g.fillEllipse(cx - rSkirt, cy - rSkirt, rSkirt * 2.0f, rSkirt * 2.0f);

        // Dentellatura zigrinata a 36 micro-faccette diamantate
        constexpr int knurlTeeth = 36;
        for (int k = 0; k < knurlTeeth; ++k) {
            float ka = (float)k * juce::MathConstants<float>::twoPi / (float)knurlTeeth;
            float kx1 = cx + std::cos(ka) * (rSkirt - 2.5f);
            float ky1 = cy + std::sin(ka) * (rSkirt - 2.5f);
            float kx2 = cx + std::cos(ka) * rSkirt;
            float ky2 = cy + std::sin(ka) * rSkirt;

            bool isLight = (std::cos(ka - 2.35f) > 0.0f);
            g.setColour(isLight ? juce::Colour(0x40ffffff) : juce::Colour(0x60000000));
            g.drawLine(kx1, ky1, kx2, ky2, 1.2f);
        }

        // ----------------------------------------------------------------------
        // 3. CAP CENTRALE IN OTTONE TORNITO CON SPAZZOLATURA CONICA SUNBURST
        // ----------------------------------------------------------------------
        const float rTrench = rSkirt * 0.82f;
        g.setColour(juce::Colour(0xff090a0d));
        g.fillEllipse(cx - rTrench, cy - rTrench, rTrench * 2.0f, rTrench * 2.0f);

        const float rCap = rTrench * 0.94f;
        juce::ColourGradient capGrad(
            juce::Colour(0xff3a3e47), cx - rCap * 0.4f, cy - rCap * 0.4f,
            juce::Colour(0xff14151a), cx + rCap * 0.8f, cy + rCap * 0.8f, false);
        g.setGradientFill(capGrad);
        g.fillEllipse(cx - rCap, cy - rCap, rCap * 2.0f, rCap * 2.0f);

        // Bordo in foglia d'oro lavorato CNC
        juce::ColourGradient goldRim(
            juce::Colour(0xffffe899), cx - rCap, cy - rCap,
            juce::Colour(0xff614820), cx + rCap, cy + rCap, false);
        g.setGradientFill(goldRim);
        g.drawEllipse(cx - rCap, cy - rCap, rCap * 2.0f, rCap * 2.0f, 1.2f);

        // ----------------------------------------------------------------------
        // 4. INCISIONE INDICATORE A TACCA FLUORESCENTE
        // ----------------------------------------------------------------------
        const float tipDist = rCap * 0.88f;
        const float inDist  = rCap * 0.32f;
        float notchX1 = cx + std::sin(angle) * inDist;
        float notchY1 = cy - std::cos(angle) * inDist;
        float notchX2 = cx + std::sin(angle) * tipDist;
        float notchY2 = cy - std::cos(angle) * tipDist;

        // Solco ombra
        g.setColour(juce::Colour(0xff06070a));
        g.drawLine(notchX1, notchY1, notchX2, notchY2, 3.2f);

        // Smalto fluorescente in tinta tematica
        g.setColour(neonCol);
        g.drawLine(notchX1, notchY1, notchX2, notchY2, 2.0f);

        // Punto ad alta riflettenza all'estremità
        g.setColour(juce::Colours::white);
        g.fillEllipse(notchX2 - 1.4f, notchY2 - 1.4f, 2.8f, 2.8f);
    }

    void drawComboBox(juce::Graphics& g, int width, int height, bool isButtonDown,
                      int buttonX, int buttonY, int buttonW, int buttonH, juce::ComboBox& box) override
    {
        juce::ignoreUnused(isButtonDown, buttonX, buttonY, buttonW, buttonH);
        auto bounds = juce::Rectangle<float>(0, 0, (float)width, (float)height).reduced(1.0f);

        // Ombra di contatto
        g.setColour(juce::Colours::black.withAlpha(0.6f));
        g.fillRoundedRectangle(bounds.translated(1.0f, 2.0f), 3.0f);

        // Sfondo scuro spazzolato
        juce::ColourGradient bgGrad(
            juce::Colour(0xff181c24), bounds.getX(), bounds.getY(),
            juce::Colour(0xff0d0f14), bounds.getX(), bounds.getBottom(), false);
        g.setGradientFill(bgGrad);
        g.fillRoundedRectangle(bounds, 3.0f);

        // Cornice sottile in ottone dorato
        g.setColour(box.hasKeyboardFocus(true) ? juce::Colour(0xffffe899) : juce::Colour(0xff73562a));
        g.drawRoundedRectangle(bounds, 3.0f, 1.2f);

        // Freccia a triangolo dorata
        auto arrowZone = bounds.removeFromRight(20.0f);
        juce::Path arrow;
        float ax = arrowZone.getCentreX();
        float ay = arrowZone.getCentreY();
        arrow.startNewSubPath(ax - 4.0f, ay - 2.5f);
        arrow.lineTo(ax + 4.0f, ay - 2.5f);
        arrow.lineTo(ax, ay + 3.5f);
        arrow.closeSubPath();

        g.setColour(juce::Colour(0xffffe899));
        g.fillPath(arrow);
    }

    void drawButtonBackground(juce::Graphics& g, juce::Button& button, const juce::Colour& backgroundColour,
                              bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override
    {
        juce::ignoreUnused(backgroundColour);
        auto bounds = button.getLocalBounds().toFloat().reduced(1.5f);
        bool isOn = button.getToggleState();

        // Ombra
        g.setColour(juce::Colours::black.withAlpha(0.65f));
        g.fillRoundedRectangle(bounds.translated(1.2f, 2.0f), 4.0f);

        if (isOn) {
            // Retroilluminato ciano intenso / azzurro glaciale
            juce::ColourGradient onGrad(
                juce::Colour(0xff00d4ff), bounds.getX(), bounds.getY(),
                juce::Colour(0xff0066aa), bounds.getX(), bounds.getBottom(), false);
            g.setGradientFill(onGrad);
            g.fillRoundedRectangle(bounds, 4.0f);

            // Bordo luce bianca
            g.setColour(juce::Colours::white.withAlpha(0.85f));
            g.drawRoundedRectangle(bounds, 4.0f, 1.2f);
        } else {
            // Metallo scuro incassato
            juce::ColourGradient offGrad(
                shouldDrawButtonAsHighlighted ? juce::Colour(0xff2a303c) : juce::Colour(0xff181c24), bounds.getX(), bounds.getY(),
                juce::Colour(0xff0d0f14), bounds.getX(), bounds.getBottom(), false);
            g.setGradientFill(offGrad);
            g.fillRoundedRectangle(bounds, 4.0f);

            // Cornice dorata sottile
            g.setColour(juce::Colour(0xff6e5428));
            g.drawRoundedRectangle(bounds, 4.0f, 1.0f);
        }

        if (shouldDrawButtonAsDown) {
            g.setColour(juce::Colours::black.withAlpha(0.25f));
            g.fillRoundedRectangle(bounds, 4.0f);
        }
    }

    void drawButtonText(juce::Graphics& g, juce::TextButton& button, bool /*isMouseOverButton*/, bool /*isButtonDown*/) override {
        auto bounds = button.getLocalBounds().toFloat();
        bool isOn = button.getToggleState();

        g.setFont(juce::FontOptions("DIN 1451 Mittelschrift", 11.0f, juce::Font::bold));
        g.setColour(isOn ? juce::Colour(0xff05101a) : juce::Colour(0xffffe899));
        g.drawText(button.getButtonText(), bounds, juce::Justification::centred, false);
    }
};


// ==============================================================================
// 171SPACELUXE MASTER GUI EDITOR (BOUTIQUE STUDIO STANDARD)
// Chassis in titanio anodizzato, cornice a 45° beveled, waterfall 3D al fosforo,
// lampade jewel diamond-cut procedurale e ridimensionamento vettoriale 60 FPS.
// ==============================================================================
class SpaceLuxeEditorComponent : public juce::Component, public juce::Timer {
public:
    explicit SpaceLuxeEditorComponent(AudioPluginAudioProcessor& proc)
        : processor(proc)
    {
        setLookAndFeel(&boutiqueLnF);

        // 1. Display 3D Waterfall CRT con scanlines e bezel in ottone
        addAndMakeVisible(waterfallDisplay);

        // 2. Setup Controlli: SPACE & TIME (Tema Ciano Elettrico)
        setupKnob(sliderPreDelay, labelPreDelay, "PRE-DELAY", " ms", SpaceLuxeBoutiqueLookAndFeel::KnobTheme::CyanSpace);
        setupKnob(sliderDecay,    labelDecay,    "DECAY",     " s",  SpaceLuxeBoutiqueLookAndFeel::KnobTheme::CyanSpace);
        setupKnob(sliderSize,     labelSize,     "ROOM SIZE", "",    SpaceLuxeBoutiqueLookAndFeel::KnobTheme::CyanSpace);

        // 3. Setup Controlli: DAMPING & COLOR (Tema Ambra Calda)
        setupKnob(sliderHighDamp, labelHighDamp, "HIGH DAMP", " Hz", SpaceLuxeBoutiqueLookAndFeel::KnobTheme::AmberDamp);
        setupKnob(sliderLowWarmth,labelLowWarmth,"LOW WARMTH"," dB", SpaceLuxeBoutiqueLookAndFeel::KnobTheme::AmberDamp);

        // 4. Setup Controlli: SHIMMER (Tema Magenta) & SMART SWELL (Tema Oro Radiant)
        setupKnob(sliderShimmer,    labelShimmer,    "SHIMMER",     " %", SpaceLuxeBoutiqueLookAndFeel::KnobTheme::VioletShimmer);
        setupKnob(sliderDuckAmount, labelDuckAmount, "DUCK AMOUNT", " %", SpaceLuxeBoutiqueLookAndFeel::KnobTheme::GoldBloom);
        setupKnob(sliderTailBloom,  labelTailBloom,  "TAIL BLOOM",  " dB",SpaceLuxeBoutiqueLookAndFeel::KnobTheme::GoldBloom);

        // 5. Setup Controlli: OUTPUT & MASTER (Tema Oro / Platino)
        setupKnob(sliderWidth,    labelWidth,    "STEREO WIDTH", "x", SpaceLuxeBoutiqueLookAndFeel::KnobTheme::TitaniumMaster);
        setupKnob(sliderMonoMaker,labelMonoMaker,"MONO-MAKER", " Hz",SpaceLuxeBoutiqueLookAndFeel::KnobTheme::TitaniumMaster);
        setupKnob(sliderDryWet,   labelDryWet,   "DRY / WET", " %",   SpaceLuxeBoutiqueLookAndFeel::KnobTheme::GoldBloom);

        // 6. Freeze Button & Presets Selector
        btnFreeze.setButtonText("FREEZE");
        btnFreeze.setClickingTogglesState(true);
        addAndMakeVisible(btnFreeze);

        for (int i = 0; i < processor.getNumPrograms(); ++i) {
            presetSelector.addItem(processor.getProgramName(i), i + 1);
        }
        presetSelector.setSelectedId(processor.getCurrentProgram() + 1, juce::dontSendNotification);
        presetSelector.onChange = [this]() {
            processor.setCurrentProgram(presetSelector.getSelectedId() - 1);
        };
        addAndMakeVisible(presetSelector);

        focusSelector.addItem("FOCUS: VOCAL", 1);
        focusSelector.addItem("FOCUS: FULL BAND", 2);
        focusSelector.setSelectedId(1, juce::dontSendNotification);
        addAndMakeVisible(focusSelector);

        sidechainSelector.addItem("SC: AUTO INT", 1);
        sidechainSelector.addItem("SC: EXT AUX", 2);
        sidechainSelector.setSelectedId(1, juce::dontSendNotification);
        addAndMakeVisible(sidechainSelector);

        labelSidechain.setText("SMART DUCKING ROUTING & FOCUS", juce::dontSendNotification);
        labelSidechain.setFont(juce::FontOptions("DIN 1451 Mittelschrift", 10.0f, juce::Font::bold));
        labelSidechain.setColour(juce::Label::textColourId, juce::Colour(0xffffe899));
        labelSidechain.setJustificationType(juce::Justification::centred);
        addAndMakeVisible(labelSidechain);

        // 7. Angolare di ridimensionamento dinamico boutique
        addAndMakeVisible(resizeHandle);

        // 8. Collegamenti Parametri APVTS
        auto& apvts = processor.getAPVTS();
        attachPreDelay   = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "preDelay", sliderPreDelay);
        attachDecay      = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "decay", sliderDecay);
        attachSize       = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "size", sliderSize);
        attachHighDamp   = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "highDamp", sliderHighDamp);
        attachLowWarmth  = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "lowWarmth", sliderLowWarmth);
        attachShimmer    = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "shimmer", sliderShimmer);
        attachDuckAmount = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "duckAmount", sliderDuckAmount);
        attachTailBloom  = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "tailBloom", sliderTailBloom);
        attachDuckFocus  = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(apvts, "duckFocus", focusSelector);
        attachWidth      = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "width", sliderWidth);
        attachMonoMaker  = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "monoMaker", sliderMonoMaker);
        attachDryWet     = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "dryWet", sliderDryWet);
        attachFreeze     = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(apvts, "freeze", btnFreeze);
        attachSidechain  = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(apvts, "sidechainSource", sidechainSelector);

        setSize(960, 620);
        startTimerHz(30); // 30 FPS telemetry: ultra-fluido, zero carico su message thread DAW
    }

    ~SpaceLuxeEditorComponent() override {
        stopTimer();
        setLookAndFeel(nullptr);
    }

    void timerCallback() override {
        float low = processor.getVisualLowEnergy();
        float mid = processor.getVisualMidEnergy();
        float high = processor.getVisualHighEnergy();
        float duck = processor.getVisualDuckingReduction();
        float bloom = processor.getVisualBloomGain();
        waterfallDisplay.pushAudioEnergy(low, mid, high, duck, bloom);

        bool duckActive = processor.isVisualDuckingActive();
        bool bloomActive = processor.isVisualBloomActive();
        bool scExt = processor.isVisualSidechainExternal();

        if (duckActive != isDuckLampOn || bloomActive != isBloomLampOn || scExt != isSidechainExternal) {
            isDuckLampOn = duckActive;
            isBloomLampOn = bloomActive;
            isSidechainExternal = scExt;
            repaint(jewelsArea.expanded(18).toNearestInt());
        }
    }

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat();
        if (bounds.isEmpty()) return;

        // 1. Disegna telaio PBR e serigrafie statiche dalla cache ad alte prestazioni (0 ms CPU)
        if (backgroundCache.isValid()) {
            g.drawImageAt(backgroundCache, 0, 0);
        }

        auto w = bounds.getWidth();
        auto h = bounds.getHeight();
        const float scaleX = w / 960.0f;
        const float scaleY = h / 620.0f;
        const float fontScale = std::min(scaleX, scaleY);

        // 2. Logo Ufficiale 171 Studio Satin Gold Badge nel backplate superiore
        auto badgeImg = juce::ImageCache::getFromMemory(BinaryData::badge_171_gold_180x60_png, BinaryData::badge_171_gold_180x60_pngSize);
        if (badgeImg.isValid()) {
            float badgeW = 95.0f * scaleX;
            float badgeH = 32.0f * scaleY;
            juce::Rectangle<float> badgeRect(bounds.getX() + 370.0f * scaleX, bounds.getY() + 18.0f * scaleY, badgeW, badgeH);
            g.drawImage(badgeImg, badgeRect, juce::RectanglePlacement::centred);
        }

        // 3. LAMPADE A GIOIELLO SFACCETTATE DIAMOND-CUT (ENGINE ASSET CORE)
        // Lampada 1: POWER (Ruby Gem)
        JewelLightRenderer::drawFacetedJewelLight(g, jewelPowerBounds, juce::Colour(0xffff2035), 0.95f);
        paintJewelLabel(g, jewelPowerBounds, "POWER", true, juce::Colour(0xffff2035), fontScale);

        // Lampada 2: SMART DUCK / TAIL BLOOM (Bicolore Amber/Gold dinamica)
        bool isDuckOrBloom = isDuckLampOn || isBloomLampOn;
        juce::Colour duckCol = isBloomLampOn ? juce::Colour(0xffffd700) : juce::Colour(0xffff9900);
        float duckBrightness = isBloomLampOn ? 0.95f : (isDuckLampOn ? 0.90f : 0.0f);
        JewelLightRenderer::drawFacetedJewelLight(g, jewelDuckBounds, duckCol, duckBrightness);
        paintJewelLabel(g, jewelDuckBounds, isBloomLampOn ? "BLOOM" : "SMART DUCK", isDuckOrBloom, duckCol, fontScale);

        // Lampada 3: EXT SC (Electric Cyan)
        JewelLightRenderer::drawFacetedJewelLight(g, jewelSidechainBounds, juce::Colour(0xff00f0ff), isSidechainExternal ? 0.95f : 0.0f);
        paintJewelLabel(g, jewelSidechainBounds, "EXT SC", isSidechainExternal, juce::Colour(0xff00f0ff), fontScale);
    }

    void rebuildBackgroundCache() {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        backgroundCache = juce::Image(juce::Image::ARGB, w, h, true);
        juce::Graphics g(backgroundCache);
        auto bounds = juce::Rectangle<float>(0, 0, (float)w, (float)h);

        const float scaleX = (float)w / 960.0f;
        const float scaleY = (float)h / 620.0f;
        const float fontScale = std::min(scaleX, scaleY);

        // 1. TELAIO BASE IN TITANIO ANODIZZATO SCURO SPAZZOLATO PBR
        juce::Colour titaniumDark = juce::Colour(0xff121419);
        juce::Colour titaniumMid  = juce::Colour(0xff1c212b);
        juce::Colour titaniumHighlight = juce::Colour(0xff272e3c);

        float cx = bounds.getCentreX();
        float cy = bounds.getCentreY();
        float maxR = std::hypot((float)w * 0.5f, (float)h * 0.5f);

        juce::ColourGradient radialTitanium(titaniumMid, cx, cy, titaniumDark, cx, cy + maxR, true);
        radialTitanium.addColour(0.35, titaniumHighlight);
        radialTitanium.addColour(0.70, titaniumMid);
        radialTitanium.addColour(0.95, titaniumDark);
        g.setGradientFill(radialTitanium);
        g.fillRect(bounds);

        // Micro-spazzolatura radiale concentrica pre-renderizzata
        for (float r = 16.0f * fontScale; r < maxR; r += 5.0f * fontScale) {
            float alpha = (std::fmod(r, 10.0f * fontScale) < 5.0f * fontScale) ? 0.030f : 0.012f;
            g.setColour(juce::Colours::white.withAlpha(alpha));
            g.drawEllipse(cx - r, cy - r, r * 2.0f, r * 2.0f, 0.75f);
        }

        // 2. CORNICE PERIMETRALE A 45° CON BORDO BEVELED DORATO
        auto fBounds = bounds.reduced(10.0f * fontScale);
        float chamfer = 14.0f * fontScale;
        juce::Path framePath;
        framePath.startNewSubPath(fBounds.getX() + chamfer, fBounds.getY());
        framePath.lineTo(fBounds.getRight() - chamfer, fBounds.getY());
        framePath.lineTo(fBounds.getRight(), fBounds.getY() + chamfer);
        framePath.lineTo(fBounds.getRight(), fBounds.getBottom() - chamfer);
        framePath.lineTo(fBounds.getRight() - chamfer, fBounds.getBottom());
        framePath.lineTo(fBounds.getX() + chamfer, fBounds.getBottom());
        framePath.lineTo(fBounds.getX(), fBounds.getBottom() - chamfer);
        framePath.lineTo(fBounds.getX(), fBounds.getY() + chamfer);
        framePath.closeSubPath();

        g.setColour(juce::Colours::black.withAlpha(0.65f));
        g.strokePath(framePath, juce::PathStrokeType(3.5f * fontScale));

        juce::ColourGradient goldBorder(
            juce::Colour(0xffffe899), fBounds.getX(), fBounds.getY(),
            juce::Colour(0xff523d1c), fBounds.getRight(), fBounds.getBottom(), false);
        g.setGradientFill(goldBorder);
        g.strokePath(framePath, juce::PathStrokeType(1.6f * fontScale));

        // 3. VITI PHILLIPS SKEUOMORFICHE AGLI ANGOLI
        float screwOffset = 22.0f * fontScale;
        float screwR = 7.0f * fontScale;
        BoutiqueHardwareRenderer::paintPhillipsScrew(g, bounds.getX() + screwOffset, bounds.getY() + screwOffset, screwR, 18.0f);
        BoutiqueHardwareRenderer::paintPhillipsScrew(g, bounds.getRight() - screwOffset, bounds.getY() + screwOffset, screwR, 52.0f);
        BoutiqueHardwareRenderer::paintPhillipsScrew(g, bounds.getX() + screwOffset, bounds.getBottom() - screwOffset, screwR, 76.0f);
        BoutiqueHardwareRenderer::paintPhillipsScrew(g, bounds.getRight() - screwOffset, bounds.getBottom() - screwOffset, screwR, 112.0f);

        // 4. DIVISORI IN OTTONE IN RILIEVO PER LE 3 CAMPATE RACK
        BoutiqueHardwareRenderer::paintBrassDivider(g, bounds.getX() + 310.0f * scaleX, bounds.getY() + 80.0f * scaleY, bounds.getBottom() - 40.0f * scaleY);
        BoutiqueHardwareRenderer::paintBrassDivider(g, bounds.getX() + 650.0f * scaleX, bounds.getY() + 80.0f * scaleY, bounds.getBottom() - 40.0f * scaleY);

        // 5. INTESTAZIONE SUPERIORE SERIGRAFATA
        juce::Rectangle<float> headerBounds(bounds.getX() + 38.0f * scaleX, bounds.getY() + 16.0f * scaleY, 320.0f * scaleX, 32.0f * scaleY);
        g.setColour(juce::Colour(0xffffe899));
        g.setFont(juce::FontOptions(22.0f * fontScale, juce::Font::bold));
        g.drawText("171SPACELUXE", headerBounds, juce::Justification::centredLeft, false);

        juce::Rectangle<float> subHeaderBounds(bounds.getX() + 40.0f * scaleX, bounds.getY() + 42.0f * scaleY, 360.0f * scaleX, 16.0f * scaleY);
        g.setColour(juce::Colour(0xff00e5ff));
        g.setFont(juce::FontOptions(11.0f * fontScale, juce::Font::plain));
        g.drawText("HYBRID BOUTIQUE REVERB & SPACE SCULPTOR", subHeaderBounds, juce::Justification::centredLeft, false);

        // 6. INTESTAZIONI DELLE SEZIONI RACK
        juce::Rectangle<float> sec1Header(bounds.getX() + 25.0f * scaleX, bounds.getY() + 84.0f * scaleY, 275.0f * scaleX, 22.0f * scaleY);
        g.setColour(juce::Colour(0xffc8ab7d));
        g.setFont(juce::FontOptions(12.0f * fontScale, juce::Font::bold));
        g.drawText("SPACE & DAMPING", sec1Header, juce::Justification::centred, false);

        juce::Rectangle<float> sec2Header(bounds.getX() + 325.0f * scaleX, bounds.getY() + 84.0f * scaleY, 310.0f * scaleX, 22.0f * scaleY);
        g.drawText("3D WATERFALL VISUALIZER", sec2Header, juce::Justification::centred, false);

        juce::Rectangle<float> sec3Header(bounds.getX() + 665.0f * scaleX, bounds.getY() + 84.0f * scaleY, 275.0f * scaleX, 22.0f * scaleY);
        g.drawText("SHIMMER & SMART SWELL", sec3Header, juce::Justification::centred, false);

        // 7. FOOTER SERIGRAFATO
        juce::Rectangle<float> footerBounds(bounds.getX() + 20.0f * scaleX, bounds.getBottom() - 28.0f * scaleY, bounds.getWidth() - 40.0f * scaleX, 20.0f * scaleY);
        g.setColour(juce::Colour(0x66c8ab7d));
        g.setFont(juce::FontOptions(10.0f * fontScale, juce::Font::plain));
        g.drawText("171 STUDIO INNOVATIO - FDN-16 MATRIX - AUTO-SENSING DUCKING & TAIL BLOOM SWELL",
                   footerBounds, juce::Justification::centred, false);
    }

    void resized() override {
        rebuildBackgroundCache();

        auto bounds = getLocalBounds();
        const float scaleX = (float)bounds.getWidth() / 960.0f;
        const float scaleY = (float)bounds.getHeight() / 620.0f;
        const float fontScale = std::min(scaleX, scaleY);

        auto S = [scaleX, scaleY](float x, float y, float w, float h) -> juce::Rectangle<int> {
            return { juce::roundToInt(x * scaleX),
                     juce::roundToInt(y * scaleY),
                     juce::roundToInt(w * scaleX),
                     juce::roundToInt(h * scaleY) };
        };

        // Jewel Lamps posizionate in alto a destra
        float jSize = 28.0f * fontScale;
        jewelPowerBounds     = juce::Rectangle<float>((float)bounds.getRight() - 65.0f * scaleX, 16.0f * scaleY, jSize, jSize);
        jewelDuckBounds      = juce::Rectangle<float>((float)bounds.getRight() - 145.0f * scaleX, 16.0f * scaleY, jSize, jSize);
        jewelSidechainBounds = juce::Rectangle<float>((float)bounds.getRight() - 225.0f * scaleX, 16.0f * scaleY, jSize, jSize);
        jewelsArea = juce::Rectangle<float>((float)bounds.getRight() - 240.0f * scaleX, 12.0f * scaleY, 200.0f * scaleX, 48.0f * scaleY);

        // Header controls: Preset ComboBox & Freeze
        presetSelector.setBounds(S(960 - 455, 18, 200, 26));
        btnFreeze.setBounds(S(960 - 540, 18, 75, 26));

        // Sezione 1: Spazio & Damping
        sliderPreDelay.setBounds(S(35, 120, 78, 88));
        sliderDecay.setBounds(S(125, 120, 78, 88));
        sliderSize.setBounds(S(215, 120, 78, 88));

        sliderHighDamp.setBounds(S(70, 230, 88, 92));
        sliderLowWarmth.setBounds(S(180, 230, 88, 92));

        sliderWidth.setBounds(S(70, 345, 88, 92));
        sliderMonoMaker.setBounds(S(180, 345, 88, 92));

        // Sezione 2: Visualizer & Master Dry/Wet
        waterfallDisplay.setBounds(S(325, 120, 310, 310));
        sliderDryWet.setBounds(S(395, 450, 170, 110));

        // Sezione 3: Shimmer, Ducking & Tail Bloom
        sliderShimmer.setBounds(S(760, 115, 95, 95));

        sliderDuckAmount.setBounds(S(695, 220, 95, 95));
        sliderTailBloom.setBounds(S(815, 220, 95, 95));

        labelSidechain.setBounds(S(690, 325, 240, 18));
        focusSelector.setBounds(S(695, 348, 110, 26));
        sidechainSelector.setBounds(S(815, 348, 110, 26));

        // Angolare di ridimensionamento dinamico (angolo in basso a destra)
        resizeHandle.setBounds(bounds.getRight() - 22, bounds.getBottom() - 22, 22, 22);
    }

private:
    static void paintJewelLabel(juce::Graphics& g, juce::Rectangle<float> lampBounds,
                                const juce::String& text, bool isLit, juce::Colour color, float fontScale)
    {
        g.setFont(juce::FontOptions("DIN 1451 Mittelschrift", 8.5f * fontScale, juce::Font::bold));
        g.setColour(isLit ? color.interpolatedWith(juce::Colour(0xffffe899), 0.45f) : juce::Colour(0x88c5a059));
        juce::Rectangle<float> labelRect(lampBounds.getX() - 14.0f, lampBounds.getBottom() + 1.0f, lampBounds.getWidth() + 28.0f, 13.0f);
        g.drawText(text, labelRect, juce::Justification::centred, false);
    }

    void setupKnob(juce::Slider& slider, juce::Label& label, const juce::String& text, const juce::String& suffix,
                   SpaceLuxeBoutiqueLookAndFeel::KnobTheme theme)
    {
        slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 68, 18);
        slider.setTextValueSuffix(suffix);
        slider.getProperties().set("Theme", (int)theme);
        addAndMakeVisible(slider);

        label.setText(text, juce::dontSendNotification);
        label.setFont(juce::FontOptions("DIN 1451 Mittelschrift", 10.5f, juce::Font::bold));
        label.setColour(juce::Label::textColourId, juce::Colour(0xffffe899));
        label.setJustificationType(juce::Justification::centred);
        label.attachToComponent(&slider, false);
    }

    AudioPluginAudioProcessor& processor;
    SpaceLuxeBoutiqueLookAndFeel boutiqueLnF;
    SpaceLuxeWaterfallDisplay waterfallDisplay;
    ResizableHandleComponent resizeHandle;

    juce::Slider sliderPreDelay, sliderDecay, sliderSize;
    juce::Slider sliderHighDamp, sliderLowWarmth;
    juce::Slider sliderShimmer;
    juce::Slider sliderDuckAmount, sliderTailBloom;
    juce::Slider sliderWidth, sliderMonoMaker, sliderDryWet;

    juce::Label labelPreDelay, labelDecay, labelSize;
    juce::Label labelHighDamp, labelLowWarmth;
    juce::Label labelShimmer;
    juce::Label labelDuckAmount, labelTailBloom;
    juce::Label labelWidth, labelMonoMaker, labelDryWet;

    juce::TextButton btnFreeze;
    juce::ComboBox presetSelector;
    juce::ComboBox focusSelector;
    juce::ComboBox sidechainSelector;
    juce::Label labelSidechain;

    juce::Rectangle<float> jewelPowerBounds;
    juce::Rectangle<float> jewelDuckBounds;
    juce::Rectangle<float> jewelSidechainBounds;
    juce::Rectangle<float> jewelsArea;

    bool isDuckLampOn = false;
    bool isBloomLampOn = false;
    bool isSidechainExternal = false;

    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachPreDelay, attachDecay, attachSize;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachHighDamp, attachLowWarmth;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachShimmer;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachDuckAmount, attachTailBloom;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> attachDuckFocus;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachWidth, attachMonoMaker, attachDryWet;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> attachFreeze;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> attachSidechain;

    juce::Image backgroundCache;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SpaceLuxeEditorComponent)
};

} // namespace plugin_171
