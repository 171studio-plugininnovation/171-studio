#include "PluginProcessor.h"
#include "PluginEditor.h"

AudioPluginAudioProcessor::AudioPluginAudioProcessor()
    : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput("Output", juce::AudioChannelSet::stereo(), true)
                                      .withInput("Sidechain", juce::AudioChannelSet::stereo(), false)),
      apvts(*this, nullptr, "Parameters", createParameterLayout())
{
}

AudioPluginAudioProcessor::~AudioPluginAudioProcessor() {}

juce::AudioProcessorValueTreeState::ParameterLayout AudioPluginAudioProcessor::createParameterLayout() {
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // Space & Time
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID("preDelay", 1), "Pre-Delay",
        juce::NormalisableRange<float>(0.0f, 250.0f, 0.1f, 0.7f), 20.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID("decay", 1), "Decay Time",
        juce::NormalisableRange<float>(0.2f, 20.0f, 0.05f, 0.5f), 2.8f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID("size", 1), "Room Size",
        juce::NormalisableRange<float>(0.5f, 2.0f, 0.01f), 1.0f));

    // Damping & Color
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID("highDamp", 1), "High Damping",
        juce::NormalisableRange<float>(1000.0f, 18000.0f, 1.0f, 0.4f), 6500.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID("lowWarmth", 1), "Low Warmth",
        juce::NormalisableRange<float>(-12.0f, 12.0f, 0.1f), 2.0f));

    // Shimmer
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID("shimmer", 1), "Harmonic Shimmer",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.0f));

    // Smart Ducking & Tail Bloom v2
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID("duckAmount", 1), "Duck Amount",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.5f), 65.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID("tailBloom", 1), "Tail Bloom",
        juce::NormalisableRange<float>(0.0f, 6.0f, 0.1f), 3.5f));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID("duckFocus", 1), "Ducking Focus",
        juce::StringArray { "Vocal Focus (500Hz-4.5kHz)", "Full Band" }, 0));

    // Parametri legacy di compatibilità
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID("duckThreshold", 1), "Duck Threshold",
        juce::NormalisableRange<float>(-60.0f, 0.0f, 0.5f), -24.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID("duckDepth", 1), "Duck Depth",
        juce::NormalisableRange<float>(0.0f, 24.0f, 0.5f), 12.0f));

    // Output & Stereo
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID("width", 1), "Stereo Width",
        juce::NormalisableRange<float>(0.0f, 2.0f, 0.01f), 1.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID("monoMaker", 1), "Mono-Maker Cut",
        juce::NormalisableRange<float>(40.0f, 300.0f, 1.0f, 0.5f), 120.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID("dryWet", 1), "Dry/Wet Mix",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.005f), 0.35f));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID("freeze", 1), "Freeze Mode", false));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID("sidechainSource", 1), "Sidechain Source",
        juce::StringArray { "Internal", "External" }, 0));

    return { params.begin(), params.end() };
}

void AudioPluginAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock) {
    engine.prepare(sampleRate, samplesPerBlock);
}

void AudioPluginAudioProcessor::releaseResources() {
    engine.reset();
}

bool AudioPluginAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const {
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;
    if (layouts.getMainInputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // Sidechain input bus (opzionale, mono o stereo)
    if (layouts.inputBuses.size() > 1) {
        auto sc = layouts.inputBuses[1];
        if (!sc.isDisabled() && sc != juce::AudioChannelSet::stereo() && sc != juce::AudioChannelSet::mono())
            return false;
    }
    return true;
}

void AudioPluginAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) {
    juce::ScopedNoDenormals noDenormals;
    const int numSamples = buffer.getNumSamples();
    if (numSamples <= 0 || buffer.getNumChannels() < 2) return;

    // Lettura parametri thread-safe da APVTS
    float preDelay      = apvts.getRawParameterValue("preDelay")->load();
    float decay         = apvts.getRawParameterValue("decay")->load();
    float size          = apvts.getRawParameterValue("size")->load();
    float highDamp      = apvts.getRawParameterValue("highDamp")->load();
    float lowWarmth     = apvts.getRawParameterValue("lowWarmth")->load();
    float shimmer       = apvts.getRawParameterValue("shimmer")->load();
    
    float duckAmount = 65.0f;
    if (auto* p = apvts.getRawParameterValue("duckAmount")) duckAmount = p->load();
    float tailBloom = 3.5f;
    if (auto* p = apvts.getRawParameterValue("tailBloom")) tailBloom = p->load();
    bool spectralFocus = true;
    if (auto* p = apvts.getRawParameterValue("duckFocus")) spectralFocus = (p->load() < 0.5f);

    float width         = apvts.getRawParameterValue("width")->load();
    float monoMaker     = apvts.getRawParameterValue("monoMaker")->load();
    float dryWet        = apvts.getRawParameterValue("dryWet")->load();
    bool freeze         = apvts.getRawParameterValue("freeze")->load() > 0.5f;

    if (freeze) decay = 20.0f;

    engine.setParametersV2(preDelay, decay, size, highDamp, lowWarmth,
                           shimmer, duckAmount, tailBloom, true, spectralFocus,
                           width, monoMaker, dryWet);

    bool useExternalSidechain = false;
    if (auto* scParam = apvts.getRawParameterValue("sidechainSource")) {
        useExternalSidechain = (scParam->load() > 0.5f);
    }
    visualSidechainExternal.store(useExternalSidechain, std::memory_order_relaxed);

    // Gestione multi-bus: main output e optional sidechain bus
    auto mainOutput = getBusBuffer(buffer, false, 0);

    bool hasSidechainBus = (getBusCount(true) > 1 && getChannelCountOfBus(true, 1) > 0);
    juce::AudioBuffer<float> scBuffer;
    if (hasSidechainBus) {
        scBuffer = getBusBuffer(buffer, true, 1);
    }

    // Elaborazione audio real-time con routing sidechain
    engine.processBlock(mainOutput, hasSidechainBus ? &scBuffer : nullptr, useExternalSidechain);

    // Aggiornamento telemetria per display Waterfall
    float peakL = mainOutput.getMagnitude(0, 0, numSamples);
    float peakR = mainOutput.getMagnitude(1, 0, numSamples);
    float peakAvg = (peakL + peakR) * 0.5f;

    visualLowEnergy.store(std::min(1.0f, peakAvg * 1.8f), std::memory_order_relaxed);
    visualMidEnergy.store(std::min(1.0f, peakAvg * 1.4f), std::memory_order_relaxed);
    visualHighEnergy.store(std::min(1.0f, peakAvg * 1.1f + shimmer * 0.4f), std::memory_order_relaxed);
    visualDuckingReduction.store(engine.getDuckingReductionDb(), std::memory_order_relaxed);
    visualBloomGain.store(engine.getBloomGainDb(), std::memory_order_relaxed);
    visualDuckingActive.store(engine.isDuckingActive(), std::memory_order_relaxed);
    visualBloomActive.store(engine.isBloomActive(), std::memory_order_relaxed);
}

void AudioPluginAudioProcessor::setCurrentProgram(int index) {
    currentProgram = std::clamp(index, 0, getNumPrograms() - 1);
    
    // Preset di fabbrica boutique
    switch (currentProgram) {
        case 0: // Vocal Velvet Plate (Smart Ducked & Tail Bloom)
            apvts.getParameter("preDelay")->setValueNotifyingHost(apvts.getParameterRange("preDelay").convertTo0to1(25.0f));
            apvts.getParameter("decay")->setValueNotifyingHost(apvts.getParameterRange("decay").convertTo0to1(2.6f));
            apvts.getParameter("size")->setValueNotifyingHost(apvts.getParameterRange("size").convertTo0to1(1.0f));
            apvts.getParameter("highDamp")->setValueNotifyingHost(apvts.getParameterRange("highDamp").convertTo0to1(7000.0f));
            apvts.getParameter("lowWarmth")->setValueNotifyingHost(apvts.getParameterRange("lowWarmth").convertTo0to1(2.5f));
            apvts.getParameter("shimmer")->setValueNotifyingHost(apvts.getParameterRange("shimmer").convertTo0to1(0.0f));
            if (auto* p = apvts.getParameter("duckAmount")) p->setValueNotifyingHost(apvts.getParameterRange("duckAmount").convertTo0to1(75.0f));
            if (auto* p = apvts.getParameter("tailBloom"))  p->setValueNotifyingHost(apvts.getParameterRange("tailBloom").convertTo0to1(4.0f));
            if (auto* p = apvts.getParameter("duckFocus"))  p->setValueNotifyingHost(0.0f);
            apvts.getParameter("duckThreshold")->setValueNotifyingHost(apvts.getParameterRange("duckThreshold").convertTo0to1(-22.0f));
            apvts.getParameter("duckDepth")->setValueNotifyingHost(apvts.getParameterRange("duckDepth").convertTo0to1(14.0f));
            apvts.getParameter("width")->setValueNotifyingHost(apvts.getParameterRange("width").convertTo0to1(1.15f));
            apvts.getParameter("monoMaker")->setValueNotifyingHost(apvts.getParameterRange("monoMaker").convertTo0to1(130.0f));
            apvts.getParameter("dryWet")->setValueNotifyingHost(apvts.getParameterRange("dryWet").convertTo0to1(0.38f));
            break;

        case 1: // Cathedral Shimmer Ambient
            apvts.getParameter("preDelay")->setValueNotifyingHost(apvts.getParameterRange("preDelay").convertTo0to1(45.0f));
            apvts.getParameter("decay")->setValueNotifyingHost(apvts.getParameterRange("decay").convertTo0to1(7.5f));
            apvts.getParameter("size")->setValueNotifyingHost(apvts.getParameterRange("size").convertTo0to1(1.6f));
            apvts.getParameter("highDamp")->setValueNotifyingHost(apvts.getParameterRange("highDamp").convertTo0to1(12000.0f));
            apvts.getParameter("lowWarmth")->setValueNotifyingHost(apvts.getParameterRange("lowWarmth").convertTo0to1(1.0f));
            apvts.getParameter("shimmer")->setValueNotifyingHost(apvts.getParameterRange("shimmer").convertTo0to1(0.65f));
            if (auto* p = apvts.getParameter("duckAmount")) p->setValueNotifyingHost(apvts.getParameterRange("duckAmount").convertTo0to1(45.0f));
            if (auto* p = apvts.getParameter("tailBloom"))  p->setValueNotifyingHost(apvts.getParameterRange("tailBloom").convertTo0to1(3.0f));
            if (auto* p = apvts.getParameter("duckFocus"))  p->setValueNotifyingHost(0.0f);
            apvts.getParameter("duckThreshold")->setValueNotifyingHost(apvts.getParameterRange("duckThreshold").convertTo0to1(-28.0f));
            apvts.getParameter("duckDepth")->setValueNotifyingHost(apvts.getParameterRange("duckDepth").convertTo0to1(8.0f));
            apvts.getParameter("width")->setValueNotifyingHost(apvts.getParameterRange("width").convertTo0to1(1.4f));
            apvts.getParameter("monoMaker")->setValueNotifyingHost(apvts.getParameterRange("monoMaker").convertTo0to1(100.0f));
            apvts.getParameter("dryWet")->setValueNotifyingHost(apvts.getParameterRange("dryWet").convertTo0to1(0.45f));
            break;

        case 2: // Tight Studio Drum Chamber
            apvts.getParameter("preDelay")->setValueNotifyingHost(apvts.getParameterRange("preDelay").convertTo0to1(8.0f));
            apvts.getParameter("decay")->setValueNotifyingHost(apvts.getParameterRange("decay").convertTo0to1(0.95f));
            apvts.getParameter("size")->setValueNotifyingHost(apvts.getParameterRange("size").convertTo0to1(0.7f));
            apvts.getParameter("highDamp")->setValueNotifyingHost(apvts.getParameterRange("highDamp").convertTo0to1(4500.0f));
            apvts.getParameter("lowWarmth")->setValueNotifyingHost(apvts.getParameterRange("lowWarmth").convertTo0to1(0.0f));
            apvts.getParameter("shimmer")->setValueNotifyingHost(apvts.getParameterRange("shimmer").convertTo0to1(0.0f));
            if (auto* p = apvts.getParameter("duckAmount")) p->setValueNotifyingHost(apvts.getParameterRange("duckAmount").convertTo0to1(35.0f));
            if (auto* p = apvts.getParameter("tailBloom"))  p->setValueNotifyingHost(apvts.getParameterRange("tailBloom").convertTo0to1(1.2f));
            if (auto* p = apvts.getParameter("duckFocus"))  p->setValueNotifyingHost(1.0f);
            apvts.getParameter("duckThreshold")->setValueNotifyingHost(apvts.getParameterRange("duckThreshold").convertTo0to1(-14.0f));
            apvts.getParameter("duckDepth")->setValueNotifyingHost(apvts.getParameterRange("duckDepth").convertTo0to1(6.0f));
            apvts.getParameter("width")->setValueNotifyingHost(apvts.getParameterRange("width").convertTo0to1(1.0f));
            apvts.getParameter("monoMaker")->setValueNotifyingHost(apvts.getParameterRange("monoMaker").convertTo0to1(150.0f));
            apvts.getParameter("dryWet")->setValueNotifyingHost(apvts.getParameterRange("dryWet").convertTo0to1(0.25f));
            break;

        case 3: // Synth Ethereal Space (Infinite Decay)
            apvts.getParameter("preDelay")->setValueNotifyingHost(apvts.getParameterRange("preDelay").convertTo0to1(30.0f));
            apvts.getParameter("decay")->setValueNotifyingHost(apvts.getParameterRange("decay").convertTo0to1(18.0f));
            apvts.getParameter("size")->setValueNotifyingHost(apvts.getParameterRange("size").convertTo0to1(1.8f));
            apvts.getParameter("highDamp")->setValueNotifyingHost(apvts.getParameterRange("highDamp").convertTo0to1(14000.0f));
            apvts.getParameter("lowWarmth")->setValueNotifyingHost(apvts.getParameterRange("lowWarmth").convertTo0to1(3.0f));
            apvts.getParameter("shimmer")->setValueNotifyingHost(apvts.getParameterRange("shimmer").convertTo0to1(0.85f));
            if (auto* p = apvts.getParameter("duckAmount")) p->setValueNotifyingHost(apvts.getParameterRange("duckAmount").convertTo0to1(55.0f));
            if (auto* p = apvts.getParameter("tailBloom"))  p->setValueNotifyingHost(apvts.getParameterRange("tailBloom").convertTo0to1(3.5f));
            if (auto* p = apvts.getParameter("duckFocus"))  p->setValueNotifyingHost(0.0f);
            apvts.getParameter("duckThreshold")->setValueNotifyingHost(apvts.getParameterRange("duckThreshold").convertTo0to1(-30.0f));
            apvts.getParameter("duckDepth")->setValueNotifyingHost(apvts.getParameterRange("duckDepth").convertTo0to1(10.0f));
            apvts.getParameter("width")->setValueNotifyingHost(apvts.getParameterRange("width").convertTo0to1(1.5f));
            apvts.getParameter("monoMaker")->setValueNotifyingHost(apvts.getParameterRange("monoMaker").convertTo0to1(90.0f));
            apvts.getParameter("dryWet")->setValueNotifyingHost(apvts.getParameterRange("dryWet").convertTo0to1(0.60f));
            break;

        case 4: // Warm Vintage Acoustic Hall
            apvts.getParameter("preDelay")->setValueNotifyingHost(apvts.getParameterRange("preDelay").convertTo0to1(18.0f));
            apvts.getParameter("decay")->setValueNotifyingHost(apvts.getParameterRange("decay").convertTo0to1(3.4f));
            apvts.getParameter("size")->setValueNotifyingHost(apvts.getParameterRange("size").convertTo0to1(1.2f));
            apvts.getParameter("highDamp")->setValueNotifyingHost(apvts.getParameterRange("highDamp").convertTo0to1(5200.0f));
            apvts.getParameter("lowWarmth")->setValueNotifyingHost(apvts.getParameterRange("lowWarmth").convertTo0to1(4.0f));
            apvts.getParameter("shimmer")->setValueNotifyingHost(apvts.getParameterRange("shimmer").convertTo0to1(0.1f));
            if (auto* p = apvts.getParameter("duckAmount")) p->setValueNotifyingHost(apvts.getParameterRange("duckAmount").convertTo0to1(40.0f));
            if (auto* p = apvts.getParameter("tailBloom"))  p->setValueNotifyingHost(apvts.getParameterRange("tailBloom").convertTo0to1(2.0f));
            if (auto* p = apvts.getParameter("duckFocus"))  p->setValueNotifyingHost(0.0f);
            apvts.getParameter("duckThreshold")->setValueNotifyingHost(apvts.getParameterRange("duckThreshold").convertTo0to1(-20.0f));
            apvts.getParameter("duckDepth")->setValueNotifyingHost(apvts.getParameterRange("duckDepth").convertTo0to1(8.0f));
            apvts.getParameter("width")->setValueNotifyingHost(apvts.getParameterRange("width").convertTo0to1(1.1f));
            apvts.getParameter("monoMaker")->setValueNotifyingHost(apvts.getParameterRange("monoMaker").convertTo0to1(110.0f));
            apvts.getParameter("dryWet")->setValueNotifyingHost(apvts.getParameterRange("dryWet").convertTo0to1(0.32f));
            break;
            apvts.getParameter("monoMaker")->setValueNotifyingHost(apvts.getParameterRange("monoMaker").convertTo0to1(110.0f));
            apvts.getParameter("dryWet")->setValueNotifyingHost(apvts.getParameterRange("dryWet").convertTo0to1(0.32f));
            break;
    }
}

const juce::String AudioPluginAudioProcessor::getProgramName(int index) {
    switch (index) {
        case 0: return "01 - Vocal Velvet Plate (Smart Ducked)";
        case 1: return "02 - Cathedral Shimmer Ambient";
        case 2: return "03 - Tight Studio Drum Chamber";
        case 3: return "04 - Synth Ethereal Space (Infinite Decay)";
        case 4: return "05 - Warm Vintage Acoustic Hall";
        default: return "Preset";
    }
}

void AudioPluginAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void AudioPluginAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType())) {
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
    }
}

juce::AudioProcessorEditor* AudioPluginAudioProcessor::createEditor() {
    return new AudioPluginAudioProcessorEditor(*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new AudioPluginAudioProcessor();
}
