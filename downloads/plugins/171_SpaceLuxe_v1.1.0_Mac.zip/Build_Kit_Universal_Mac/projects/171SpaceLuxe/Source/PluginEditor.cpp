#include "PluginEditor.h"

AudioPluginAudioProcessorEditor::AudioPluginAudioProcessorEditor(AudioPluginAudioProcessor& p)
    : AudioProcessorEditor(&p),
      processorRef(p),
      editorComponent(p)
{
    addAndMakeVisible(editorComponent);
    setSize(960, 620);
    setResizable(true, true);
    setResizeLimits(768, 496, 2400, 1550);
}

AudioPluginAudioProcessorEditor::~AudioPluginAudioProcessorEditor() {}

void AudioPluginAudioProcessorEditor::paint(juce::Graphics& g) {
    g.fillAll(juce::Colours::black);
}

void AudioPluginAudioProcessorEditor::resized() {
    editorComponent.setBounds(getLocalBounds());
}
