#!/bin/bash
# ==============================================================================
# 🍏 171 STUDIO INNOVATIO — INSTALLATORE UFFICIALE macOS (Apple Silicon & Intel)
# Plugin: 171 SpaceLuxe (v1.1.0)
# Architetture Supportate: ARM64 (M1/M2/M3/M4) + x86_64 (Intel)
# ==============================================================================

set -e
DIR="$(cd "$(dirname "$0")" && pwd)"

echo "======================================================================"
echo " 🍏 171 STUDIO INNOVATIO — INSTALLATORE UFFICIALE macOS"
echo " Plugin: 171 SpaceLuxe (v1.1.0)"
echo "======================================================================"
echo ""

USER_AU="$HOME/Library/Audio/Plug-Ins/Components"
USER_VST3="$HOME/Library/Audio/Plug-Ins/VST3"
USER_APP="/Applications/171 Studio"

mkdir -p "$USER_AU" "$USER_VST3" "$USER_APP"

if [ -d "$DIR/171SpaceLuxe.component" ]; then
    echo "▶ Installazione AudioUnit v2 per Logic Pro / GarageBand..."
    rm -rf "$USER_AU/171SpaceLuxe.component"
    cp -R "$DIR/171SpaceLuxe.component" "$USER_AU/"
    echo "  ✔ Copiato in $USER_AU/171SpaceLuxe.component"
fi

if [ -d "$DIR/171SpaceLuxe.vst3" ]; then
    echo "▶ Installazione VST3 per Ableton Live / FL Studio / Cubase / Studio One / Reaper..."
    rm -rf "$USER_VST3/171SpaceLuxe.vst3"
    cp -R "$DIR/171SpaceLuxe.vst3" "$USER_VST3/"
    echo "  ✔ Copiato in $USER_VST3/171SpaceLuxe.vst3"
fi

if [ -d "$DIR/171SpaceLuxe.app" ]; then
    echo "▶ Installazione Standalone App..."
    rm -rf "$USER_APP/171SpaceLuxe.app"
    cp -R "$DIR/171SpaceLuxe.app" "$USER_APP/"
    echo "  ✔ Copiato in $USER_APP/171SpaceLuxe.app"
fi

echo ""
echo "▶ Verifica sicurezza e sblocco Apple Gatekeeper..."
xattr -dr com.apple.quarantine "$USER_AU/171SpaceLuxe.component" 2>/dev/null || true
xattr -dr com.apple.quarantine "$USER_VST3/171SpaceLuxe.vst3" 2>/dev/null || true
xattr -dr com.apple.quarantine "$USER_APP/171SpaceLuxe.app" 2>/dev/null || true
echo "  ✔ Attributi quarantine rimossi con successo."

if [ -f "$DIR/Build_Kit_Universal_Mac/build_mac.sh" ]; then
    echo ""
    echo "----------------------------------------------------------------------"
    echo "Vuoi anche ricompilare i sorgenti C++/DSP nativamente sul tuo Mac con Clang/Xcode?"
    read -p "Eseguire build nativa ottimizzata vDSP NEON adesso? [s/N]: " comp
    if [[ "$comp" =~ ^[sSyY]$ ]]; then
        cd "$DIR/Build_Kit_Universal_Mac"
        chmod +x build_mac.sh
        ./build_mac.sh --install
    fi
fi

echo ""
echo "======================================================================"
echo "🎉 INSTALLAZIONE COMPLETATA CON SUCCESSO!"
echo "Apri Apple Logic Pro, Ableton Live, FL Studio Mac o Studio One."
echo "Per verificare la registrazione AU in Logic Pro, digita nel Terminale:"
echo "    auval -v aufx 171L 171P"
echo "======================================================================"
echo "171 Studio Innovatio — Messina, Italia"
echo ""
read -p "Premi INVIO per terminare..."
