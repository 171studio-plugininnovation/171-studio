================================================================================
🍏 171 STUDIO INNOVATIO — MASTER AUDIO SUITE PER macOS (Apple Silicon & Intel)
================================================================================
Plugin:           171 SpaceLuxe
Versione:         v1.1.0
Categoria:        Boutique Hybrid Reverb & Space Sculptor
Sviluppatore:     171 Studio Innovatio (Messina, Italia)
Sito Ufficiale:   https://171studio.it
FourCC Codici:    Produttore: '171P' | Sottotipo AU: '171L' | Tipo: aufx
================================================================================

CONTENUTO DEL PACCHETTO:
1. 171SpaceLuxe.component  -> Formato AudioUnit v2 ufficiale per Logic Pro e GarageBand
2. 171SpaceLuxe.vst3       -> Formato VST3 ufficiale per Ableton Live, FL Studio, Cubase, Studio One, Reaper
3. 171SpaceLuxe.app        -> Applicazione nativa Standalone macOS per tracking autonomo
4. INSTALLA_SU_MAC.command -> Script eseguibile per installazione automatica con 1 clic
5. 171SpaceLuxe_Retina_GUI.png -> Screenshot fotorealistico ad altissima risoluzione Retina
6. SCHEDA_TECNICA_APPLE_MACOS.md -> Dossier tecnico e architettura DSP
7. Build_Kit_Universal_Mac/ -> Sorgenti C++, CMakeLists.txt e script di compilazione nativa

--------------------------------------------------------------------------------
GUIDA RAPIDA ALL'INSTALLAZIONE SU macOS:
--------------------------------------------------------------------------------

METODO 1: INSTALLAZIONE AUTOMATICA (Consigliato)
1. Fai doppio clic sul file 'INSTALLA_SU_MAC.command'.
2. Se macOS mostra un messaggio di sicurezza la prima volta:
   - Fai clic destro (o Control+Clic) su 'INSTALLA_SU_MAC.command' e scegli 'Apri'.
3. Lo script installerà automaticamente i componenti nelle tue directory audio utente:
   - ~/Library/Audio/Plug-Ins/Components/
   - ~/Library/Audio/Plug-Ins/VST3/
   - /Applications/171 Studio/
4. Riavvia la tua DAW preferita (Apple Logic Pro, Ableton Live, FL Studio Mac, Studio One).

METODO 2: INSTALLAZIONE MANUALE
- Copia '171SpaceLuxe.component' in:
    ~/Library/Audio/Plug-Ins/Components/
- Copia '171SpaceLuxe.vst3' in:
    ~/Library/Audio/Plug-Ins/VST3/
- Se macOS Gatekeeper dovesse bloccare il caricamento all'avvio della DAW,
  apri il Terminale e incolla questo comando:
    xattr -dr com.apple.quarantine ~/Library/Audio/Plug-Ins/Components/171SpaceLuxe.component
    xattr -dr com.apple.quarantine ~/Library/Audio/Plug-Ins/VST3/171SpaceLuxe.vst3

--------------------------------------------------------------------------------
VALIDAZIONE CON LOGIC PRO (auval):
--------------------------------------------------------------------------------
Per testare la conformità del plugin con le specifiche di Apple, apri il Terminale ed esegui:
    auval -v aufx 171L 171P

Il plugin supererà tutti i controlli audio e comparirà in Logic Pro nel menu:
    Audio Units -> 171PluginInnovation -> 171 SpaceLuxe

Buona produzione musicale da tutto il team di 171 Studio Innovatio!
Assistenza & Feedback: info@171studio.it | https://171studio.it
================================================================================
