# 🌌 DOSSIER TECNICO DI TRASPOSIZIONE — 171 SPACELUXE
### Boutique Hybrid Reverb, FDN-16 Matrix & Space Sculptor per Apple macOS

**Progetto:** 171 SpaceLuxe (`v1.1.0`)  
**Architettura:** Universal Binary Fat (`arm64` Apple Silicon M1-M4 + `x86_64` Intel)  
**Deployment Target Minimo:** macOS 11.0 Big Sur  
**Approvato da:** Il Direttore  
**Coordinamento:** `dsp-hire-manager`, `spatial-mastering-engineer` & `apple-macos-engineer`  

---

## 1. SPECIFICHE FORMATI & METADATI APPLE AUDIOUNIT

| Parametro | Valore Configurato | Specifiche per DAW macOS |
|---|---|---|
| **AudioUnit Type** | `kAudioUnitType_Effect` (`'aufx'`) | Inseribile come riverbero su tracce e bus mandata in **Logic Pro** |
| **Manufacturer Code** | `'171P'` | Conforme alle specifiche Apple (include almeno una maiuscola) |
| **Plugin Code / Subtype** | `'171L'` | Identificativo univoco a 4 caratteri per scansione AU |
| **Target Formati Mac** | **AU (`.component`)**, **VST3 (`.vst3`)**, **Standalone (`.app`)** | AU per Logic Pro; VST3 per Ableton, Cubase, Studio One, Reaper, FL |
| **Sidechain Input** | Abilitato (Multi-bus ausiliario) | Supporto per Smart Ducking pilotato da traccia vocale o cassa esterna |
| **Sicurezza Gatekeeper** | Hardened Runtime attivo | Flag `--options runtime` + entitlements JIT e Unsigned Memory |

---

## 2. MODELLAZIONE ALGORITMICA SU APPLE SILICON (M1–M4)

171 SpaceLuxe implementa il top dell'ingegneria di riverberazione spaziale ibrida:

1. **Serbatoio FDN-16 con Matrice Householder Unitaria**:
   - 16 linee di ritardo mutualmente prime per azzerare le risonanze modali.
   - Matrice di diffusione Householder unitaria $O(N)$ a conservazione energetica rigorosa, vettorizzata con istruzioni **ARM64 NEON**.
2. **Smart Ducking Anti-Mascheramento**:
   - Inviluppo dinamico che abbassa la coda di riverbero in presenza del segnale dry o sidechain, con presence lift a +4 dB per preservare la voce in primo piano.
3. **Harmonic Shimmer Dual-Head (+12 semitoni)**:
   - Pitch shifting sincrono rigenerativo a saturazione morbida per ambienti celestiali ed eterei.
4. **Mono-Maker ZDF SVF & True-Peak Brickwall**:
   - Filtro di sicurezza passa-alto per mantenere le basse frequenze monofoniche (< 120 Hz) e limiter a -0.1 dBFS.

---

## 3. INTERFACCIA RETINA A 60 FPS (BOUTIQUE LUXURY)

- **Waterfall Spectrogram CRT 3D a 60 FPS**: Visualizzazione tridimensionale dello svanimento delle frequenze nel tempo, ottimizzata con backing cache asincrono.
- **Pannello Anodizzato Blu Cobalto**: Finiture metalliche di lusso con logo 171 Studio satinato in oro.
- **Interfaccia Ridimensionabile Proporzionale**: Da 768x496 a 2400x1550 con rendering nitido sub-pixel su schermi Liquid Retina HiDPI.

---

## 4. COMANDO DI COMPILAZIONE RAPIDA

```bash
# Esegui da terminale Mac:
./scripts/build_171spaceluxe_mac.sh

# Validazione Apple auval per Logic Pro:
auval -v aufx 171L 171P
```
