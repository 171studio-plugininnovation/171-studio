import math
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

def create_punchcraft_gui_preview():
    w, h = 980, 620
    im = Image.new("RGBA", (w, h), (18, 22, 26, 255))
    draw = ImageDraw.Draw(im)

    # 1. Texture metallica spazzolata per lo chassis Dark Titanium
    chassis = Image.new("RGBA", (w, h), (24, 28, 34, 255))
    ch_draw = ImageDraw.Draw(chassis)

    for y in range(h):
        grad = y / h
        c = int(32 - grad * 14)
        ch_draw.line([(0, y), (w, y)], fill=(c, c + 3, c + 8, 255))

    im.paste(chassis, (0, 0))

    # Bordo esterno smussato con profilo fresato CNC
    draw.rounded_rectangle([(2, 2), (w - 3, h - 3)], radius=8, outline=(60, 72, 85, 255), width=2)
    draw.rounded_rectangle([(5, 5), (w - 6, h - 6)], radius=7, outline=(15, 18, 22, 255), width=2)

    # Viti a brugola nei 4 angoli
    def draw_bolt(bx, by):
        r = 5
        draw.ellipse([(bx - r, by - r), (bx + r, by + r)], fill=(80, 95, 110, 255), outline=(40, 48, 56, 255))
        # Foro esagonale
        pts = []
        for i in range(6):
            ang = i * (math.pi / 3)
            pts.append((bx + math.cos(ang) * 2.5, by + math.sin(ang) * 2.5))
        draw.polygon(pts, fill=(20, 24, 28, 255))

    draw_bolt(16, 16)
    draw_bolt(w - 16, 16)
    draw_bolt(16, h - 16)
    draw_bolt(w - 16, h - 16)

    # 2. Logo Oro 171 Studio
    logo_path = "projects/171PunchCraft/Source/Assets/logo_171_gold.png"
    if os.path.exists(logo_path):
        try:
            logo_img = Image.open(logo_path).convert("RGBA")
            logo_img = logo_img.resize((48, 48), Image.Resampling.LANCZOS)
            im.paste(logo_img, (26, 12), logo_img)
        except Exception:
            pass

    # Serigrafia Header
    try:
        font_title = ImageFont.truetype("arialbd.ttf", 20)
        font_sub = ImageFont.truetype("arialbd.ttf", 10)
        font_sec = ImageFont.truetype("arialbd.ttf", 11)
        font_lbl = ImageFont.truetype("arial.ttf", 10)
    except Exception:
        font_title = ImageFont.load_default()
        font_sub = ImageFont.load_default()
        font_sec = ImageFont.load_default()
        font_lbl = ImageFont.load_default()

    draw.text((82, 14), "171 PUNCHCRAFT", fill=(212, 175, 55, 255), font=font_title)
    draw.text((82, 38), "MULTI-BAND TRANSIENT SHAPER & SUB-HARMONIC SCULPTOR - INNOVATIO LABS", fill=(158, 171, 184, 255), font=font_sub)

    # Header buttons
    # 3-Band Multi Button (Attivo, Ambra/Oro)
    draw.rounded_rectangle([(w - 240, 18), (w - 130, 46)], radius=4, fill=(255, 179, 0, 255), outline=(255, 213, 79, 255))
    draw.text((w - 225, 24), "3-BAND MULTI", fill=(10, 12, 15, 255), font=font_sec)

    # Bypass Button
    draw.rounded_rectangle([(w - 110, 18), (w - 30, 46)], radius=4, fill=(26, 30, 36, 255), outline=(50, 60, 72, 255))
    draw.text((w - 95, 24), "BYPASS", fill=(158, 171, 184, 255), font=font_sec)

    # 3. Oscilloscopio Centrale
    sc_x, sc_y, sc_w, sc_h = 20, 68, 810, 245
    draw.rounded_rectangle([(sc_x, sc_y), (sc_x + sc_w, sc_y + sc_h)], radius=6, fill=(12, 15, 18, 255), outline=(45, 54, 65, 255), width=2)

    # Griglia CRT
    for gx in range(1, 8):
        x_line = sc_x + (sc_w * gx) // 8
        draw.line([(x_line, sc_y + 4), (x_line, sc_y + sc_h - 4)], fill=(20, 35, 45, 255))
    for gy in range(1, 5):
        y_line = sc_y + (sc_h * gy) // 5
        draw.line([(sc_x + 4, y_line), (sc_x + sc_w - 4, y_line)], fill=(20, 35, 45, 255))
    # Linea di zero centrale
    draw.line([(sc_x + 4, sc_y + sc_h // 2), (sc_x + sc_w - 4, sc_y + sc_h // 2)], fill=(35, 60, 80, 255), width=1)

    # Dati simulati di forma d'onda con transiente ed inviluppo
    pts_wave = []
    pts_att = []
    pts_sus = []
    mid_y = sc_y + sc_h // 2

    np.random.seed(42)
    for i in range(200):
        t = i / 200.0
        px = sc_x + 6 + int(t * (sc_w - 12))

        # Tre transienti burst simulati
        burst1 = math.exp(-((t - 0.22) ** 2) / 0.001)
        burst2 = math.exp(-((t - 0.55) ** 2) / 0.0015)
        burst3 = math.exp(-((t - 0.82) ** 2) / 0.0008)
        burst = burst1 * 0.85 + burst2 * 0.75 + burst3 * 0.95

        osc = math.sin(t * 80.0) * burst + math.sin(t * 30.0) * 0.08
        audio_val = abs(osc)

        py_wave = mid_y - int(audio_val * (sc_h * 0.40))
        py_att = mid_y - int((audio_val + burst * 0.45) * (sc_h * 0.40))
        py_sus = mid_y + int((audio_val + burst * 0.30) * (sc_h * 0.38))

        pts_wave.append((px, py_wave))
        pts_att.append((px, py_att))
        pts_sus.append((px, py_sus))

    # Disegna tracce oscilloscopio & Phosphor Decay Trail
    # 1. Glow e scia fosforescente ambra
    for i in range(len(pts_att) - 1):
        draw.line([(pts_att[i][0], pts_att[i][1] + 3), (pts_att[i + 1][0], pts_att[i + 1][1] + 3)], fill=(255, 140, 0, 80), width=5)
    for i in range(len(pts_sus) - 1):
        draw.line([pts_sus[i], pts_sus[i + 1]], fill=(0, 229, 255, 220), width=2)
    for i in range(len(pts_wave) - 1):
        draw.line([pts_wave[i], pts_wave[i + 1]], fill=(126, 151, 176, 255), width=2)
    for i in range(len(pts_att) - 1):
        draw.line([pts_att[i], pts_att[i + 1]], fill=(255, 179, 0, 255), width=2)

    # Linee Crossover Interattive
    x_c1 = sc_x + int(sc_w * 0.28)
    x_c2 = sc_x + int(sc_w * 0.72)
    for y_dot in range(sc_y + 8, sc_y + sc_h - 8, 8):
        draw.line([(x_c1, y_dot), (x_c1, y_dot + 4)], fill=(255, 193, 7, 200), width=2)
        draw.line([(x_c2, y_dot), (x_c2, y_dot + 4)], fill=(0, 229, 255, 200), width=2)

    draw.text((x_c1 - 25, sc_y + sc_h - 20), "140 Hz", fill=(255, 193, 7, 255), font=font_sub)
    draw.text((x_c2 - 25, sc_y + sc_h - 20), "2500 Hz", fill=(0, 229, 255, 255), font=font_sub)

    draw.text((sc_x + 10, sc_y + 8), "REAL-TIME DYNAMIC TRANSIENT OSCILLOSCOPE", fill=(140, 160, 180, 255), font=font_sub)
    draw.text((sc_x + sc_w - 180, sc_y + 8), "* ATTACK FLUX", fill=(255, 179, 0, 255), font=font_sub)
    draw.text((sc_x + sc_w - 90, sc_y + 8), "* SUSTAIN TAIL", fill=(0, 229, 255, 255), font=font_sub)

    # 4. LED Meters Verticali
    lm_x, lm_y, lm_w, lm_h = sc_x + sc_w + 10, sc_y, 100, sc_h
    draw.rounded_rectangle([(lm_x, lm_y), (lm_x + lm_w, lm_y + lm_h)], radius=4, fill=(16, 18, 22, 255), outline=(40, 48, 56, 255))
    draw.text((lm_x + 8, lm_y + 6), "ATTACK", fill=(255, 179, 0, 255), font=font_sub)
    draw.text((lm_x + 55, lm_y + 6), "SUSTAIN", fill=(0, 229, 255, 255), font=font_sub)

    # LED Bars
    for col, (cx, col_fill) in enumerate([(lm_x + 10, (255, 179, 0)), (lm_x + 56, (0, 229, 255))]):
        num_seg = 16
        lit_seg = 11 if col == 0 else 8
        for s in range(num_seg):
            sy = lm_y + lm_h - 12 - s * 12
            is_lit = s < lit_seg
            f = col_fill if is_lit else (28, 34, 42)
            if is_lit and s >= 13:
                f = (255, 60, 60)
            draw.rectangle([(cx, sy - 8), (cx + 34, sy)], fill=f)

    # 5. Le 4 Campate Inferiori
    bay_y = 328
    bay_h = h - bay_y - 20
    bay_w = (w - 50) // 4

    bays = [
        ("BAY 1: SUB-HARMONICS", (255, 213, 79), [
            ("SUB ON", "button", (255, 213, 79)),
            ("45 Hz", "box", (200, 200, 200)),
            ("LEVEL", "knob", (255, 213, 79), "+3.0 dB", 0.65),
            ("DRIVE", "knob", (255, 213, 79), "35%", 0.35)
        ]),
        ("BAY 2: ATTACK SHAPING", (255, 179, 0), [
            ("BOOST", "knob", (255, 179, 0), "+60%", 0.80),
            ("SENS", "knob", (255, 179, 0), "60%", 0.60),
            ("SHAPE", "knob", (255, 179, 0), "1.8 ms", 0.35)
        ]),
        ("BAY 3: SUSTAIN SHAPING", (0, 229, 255), [
            ("SUSTAIN", "knob", (0, 229, 255), "-20%", 0.40),
            ("LENGTH", "knob", (0, 229, 255), "80 ms", 0.30)
        ]),
        ("BAY 4: CROSSOVER & MASTER", (105, 240, 174), [
            ("LOW", "small_knob", (255, 193, 7), "140 Hz", 0.30),
            ("HIGH", "small_knob", (0, 229, 255), "2.5 kHz", 0.65),
            ("CLIP -0.1 dBFS", "button", (255, 82, 82)),
            ("MIX", "small_knob", (105, 240, 174), "100%", 1.0),
            ("TRIM", "small_knob", (105, 240, 174), "0.0 dB", 0.50)
        ])
    ]

    def draw_knob(kx, ky, r, label, val_str, accent, norm):
        # Base ombra
        draw.ellipse([(kx - r - 1, ky - r + 1), (kx + r + 1, ky + r + 3)], fill=(10, 12, 14, 255))
        # Ghiera metallica con zigrinatura
        draw.ellipse([(kx - r, ky - r), (kx + r, ky + r)], fill=(32, 38, 46, 255), outline=(56, 66, 78, 255), width=2)
        # Corona denti
        for d in range(24):
            ang = d * (math.pi / 12)
            draw.line([(kx + math.cos(ang) * (r - 1), ky + math.sin(ang) * (r - 1)),
                       (kx + math.cos(ang) * (r - 4), ky + math.sin(ang) * (r - 4))], fill=(70, 82, 95, 255))
        # Cap tornito
        cr = r - 5
        draw.ellipse([(kx - cr, ky - cr), (kx + cr, ky + cr)], fill=(22, 26, 32, 255), outline=(40, 48, 58, 255))

        # Arco indicatore
        ang_start = 2.356
        ang_end = 7.068
        cur_ang = ang_start + norm * (ang_end - ang_start)

        # Tacca indicatore
        tx1 = kx + math.cos(cur_ang - 1.5707) * (cr * 0.4)
        ty1 = ky + math.sin(cur_ang - 1.5707) * (cr * 0.4)
        tx2 = kx + math.cos(cur_ang - 1.5707) * (cr * 0.85)
        ty2 = ky + math.sin(cur_ang - 1.5707) * (cr * 0.85)
        draw.line([(tx1, ty1), (tx2, ty2)], fill=accent, width=2)

        draw.text((kx - 22, ky - r - 14), label, fill=(176, 190, 197, 255), font=font_sub)
        draw.text((kx - 18, ky + r + 4), val_str, fill=accent, font=font_sub)

    for b_idx, (b_title, b_col, items) in enumerate(bays):
        bx = 20 + b_idx * (bay_w + 3)
        draw.rounded_rectangle([(bx, bay_y), (bx + bay_w, bay_y + bay_h)], radius=4, fill=(20, 23, 27, 255), outline=(40, 46, 55, 255))

        # Header campata
        draw.rounded_rectangle([(bx, bay_y), (bx + bay_w, bay_y + 22)], radius=4, fill=(27, 32, 38, 255))
        draw.rectangle([(bx + 6, bay_y + 6), (bx + 9, bay_y + 16)], fill=b_col)
        draw.text((bx + 14, bay_y + 4), b_title, fill=(236, 239, 241, 255), font=font_sub)

        # Controlli all'interno della campata
        if b_idx == 0: # Sub-Harmonics
            draw.rounded_rectangle([(bx + 8, bay_y + 28), (bx + bay_w // 2 - 2, bay_y + 50)], radius=3, fill=(255, 213, 79, 255))
            draw.text((bx + 14, bay_y + 32), "SUB ON", fill=(10, 12, 14, 255), font=font_sub)
            draw.rounded_rectangle([(bx + bay_w // 2 + 2, bay_y + 28), (bx + bay_w - 8, bay_y + 50)], radius=3, fill=(15, 18, 22, 255), outline=(50, 60, 70, 255))
            draw.text((bx + bay_w // 2 + 6, bay_y + 32), "DUAL (-1&-2)", fill=(255, 213, 79, 255), font=font_sub)

            draw.rounded_rectangle([(bx + 8, bay_y + 56), (bx + bay_w - 8, bay_y + 78)], radius=3, fill=(15, 18, 22, 255), outline=(50, 60, 70, 255))
            draw.text((bx + 18, bay_y + 60), "45 Hz (808 Club)", fill=(255, 213, 79, 255), font=font_sub)
            draw_knob(bx + 38, bay_y + 140, 24, "LEVEL", "+3.0 dB", (255, 213, 79), 0.65)
            draw_knob(bx + bay_w - 38, bay_y + 140, 24, "DRIVE", "35%", (255, 213, 79), 0.35)

        elif b_idx == 1: # Attack Shaping
            draw.rounded_rectangle([(bx + 8, bay_y + 28), (bx + bay_w - 8, bay_y + 50)], radius=3, fill=(15, 18, 22, 255), outline=(60, 50, 20, 255))
            draw.text((bx + 18, bay_y + 32), "CURVE: BALANCED (SPL)", fill=(255, 179, 0, 255), font=font_sub)
            kw = (bay_w - 20) // 3
            draw_knob(bx + 10 + kw // 2, bay_y + 120, 22, "BOOST", "+60%", (255, 179, 0), 0.80)
            draw_knob(bx + 10 + kw + kw // 2, bay_y + 120, 22, "SENS", "60%", (255, 179, 0), 0.60)
            draw_knob(bx + 10 + kw * 2 + kw // 2, bay_y + 120, 22, "SHAPE", "1.8 ms", (255, 179, 0), 0.35)

        elif b_idx == 2: # Sustain Shaping
            kw = (bay_w - 20) // 2
            draw_knob(bx + 10 + kw // 2, bay_y + 110, 26, "SUSTAIN", "-20%", (0, 229, 255), 0.40)
            draw_knob(bx + 10 + kw + kw // 2, bay_y + 110, 26, "LENGTH", "80 ms", (0, 229, 255), 0.30)

        elif b_idx == 3: # Crossover & Master
            draw_knob(bx + 40, bay_y + 65, 18, "LOW", "140 Hz", (255, 193, 7), 0.30)
            draw_knob(bx + bay_w - 40, bay_y + 65, 18, "HIGH", "2.5 kHz", (0, 229, 255), 0.65)
            draw.rounded_rectangle([(bx + 10, bay_y + 110), (bx + bay_w - 10, bay_y + 130)], radius=3, fill=(255, 82, 82, 255))
            draw.text((bx + 20, bay_y + 114), "CLIPPER -0.1 dBFS", fill=(255, 255, 255, 255), font=font_sub)
            draw_knob(bx + 40, bay_y + 175, 18, "MIX", "100%", (105, 240, 174), 1.0)
            draw_knob(bx + bay_w - 40, bay_y + 175, 18, "TRIM", "0.0 dB", (105, 240, 174), 0.50)

    # Salva anteprima
    out_dir_brain = r"C:\Users\171Studio\.gemini\antigravity\brain\e19b20f6-fcdd-41bc-abd0-938055cf415e"
    out_path_brain = os.path.join(out_dir_brain, "171punchcraft_gui_preview.png")
    out_path_local = "projects/171PunchCraft/171PunchCraft_GUI_Preview.png"

    im.save(out_path_brain, "PNG")
    im.save(out_path_local, "PNG")
    print(f"[PREVIEW SALVATA]: {out_path_brain}")
    print(f"[PREVIEW LOCALE ]: {out_path_local}")

if __name__ == "__main__":
    create_punchcraft_gui_preview()
