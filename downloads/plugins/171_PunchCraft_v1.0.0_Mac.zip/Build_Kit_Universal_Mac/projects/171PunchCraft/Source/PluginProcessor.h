#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include "DSP/PunchCraftEngine.h"

class PunchCraftAudioProcessor : public juce::AudioProcessor {
public:
    PunchCraftAudioProcessor();
    ~PunchCraftAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "171PunchCraft"; }

    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int index) override { juce::ignoreUnused(index); }
    const juce::String getProgramName(int index) override { juce::ignoreUnused(index); return {}; }
    void changeProgramName(int index, const juce::String& newName) override { juce::ignoreUnused(index, newName); }

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }
    dsp171::PunchCraftEngine& getEngine() noexcept { return engine; }

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    void updateEngineParameters() noexcept;

    juce::AudioProcessorValueTreeState apvts;
    dsp171::PunchCraftEngine engine;

    std::atomic<float>* multiBandParam = nullptr;
    std::atomic<float>* attackBoostParam = nullptr;
    std::atomic<float>* attackSensParam = nullptr;
    std::atomic<float>* attackShapeParam = nullptr;
    std::atomic<float>* curveModeParam = nullptr;
    std::atomic<float>* sustainBoostParam = nullptr;
    std::atomic<float>* sustainDecayParam = nullptr;
    std::atomic<float>* crossLowParam = nullptr;
    std::atomic<float>* crossHighParam = nullptr;
    std::atomic<float>* subEnableParam = nullptr;
    std::atomic<float>* subTunedParam = nullptr;
    std::atomic<float>* subOctModeParam = nullptr;
    std::atomic<float>* subLevelParam = nullptr;
    std::atomic<float>* subDriveParam = nullptr;
    std::atomic<float>* clipperOnParam = nullptr;
    std::atomic<float>* dryWetParam = nullptr;
    std::atomic<float>* outTrimParam = nullptr;
    std::atomic<float>* bypassParam = nullptr;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PunchCraftAudioProcessor)
};
