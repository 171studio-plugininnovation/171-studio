#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <cmath>
#include <algorithm>

namespace dsp171 {

class PunchCraftLEDMeters : public juce::Component,
                            private juce::Timer
{
public:
    PunchCraftLEDMeters() {
        startTimerHz(30);
    }

    ~PunchCraftLEDMeters() override {
        stopTimer();
    }

    void updateLevels(float attackDelta, float sustainDelta) noexcept {
        targetAtt = std::clamp(attackDelta * 2.5f, 0.0f, 1.0f);
        targetSus = std::clamp(sustainDelta * 2.0f, 0.0f, 1.0f);
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const float w = bounds.getWidth();
        const float h = bounds.getHeight();

        // Sfondo chassis incassato
        g.setColour(juce::Colour(0xFF101216));
        g.fillRoundedRectangle(bounds, 4.0f);
        g.setColour(juce::Colour(0xFF282F38));
        g.drawRoundedRectangle(bounds, 4.0f, 1.0f);

        const float colW = (w - 12.0f) * 0.5f;
        const float slotY = 22.0f;
        const float slotH = h - 30.0f;

        // Colonna 1: ATTACK DELTA (Ambra)
        drawBar(g, 4.0f, slotY, colW, slotH, currentAtt, juce::Colour(0xFFFFB300), juce::Colour(0xFFFF3D00), "ATTACK");

        // Colonna 2: SUSTAIN DELTA (Ciano)
        drawBar(g, 8.0f + colW, slotY, colW, slotH, currentSus, juce::Colour(0xFF00E5FF), juce::Colour(0xFF00B0FF), "SUSTAIN");
    }

private:
    void drawBar(juce::Graphics& g, float x, float y, float w, float h, float level,
                 juce::Colour activeColor, juce::Colour peakColor, const juce::String& label)
    {
        // Titolo colonna
        g.setFont(juce::FontOptions("Segoe UI", 8.5f, juce::Font::bold));
        g.setColour(juce::Colour(0xFFB0BEC5));
        g.drawText(label, static_cast<int>(x), 4, static_cast<int>(w), 14, juce::Justification::centred);

        // Slot nero opaco per i segmenti LED
        juce::Rectangle<float> slotRect(x, y, w, h);
        g.setColour(juce::Colour(0xFF0A0C0E));
        g.fillRoundedRectangle(slotRect, 2.0f);

        constexpr int numSegments = 16;
        const float segGap = 1.5f;
        const float segH = (h - (numSegments - 1) * segGap - 4.0f) / numSegments;

        int litCount = static_cast<int>(std::round(level * numSegments));
        litCount = std::clamp(litCount, 0, numSegments);

        for (int i = 0; i < numSegments; ++i) {
            // Indice 0 è in basso, numSegments-1 è in alto
            float segY = y + h - 2.0f - (i + 1) * segH - i * segGap;
            juce::Rectangle<float> segRect(x + 2.0f, segY, w - 4.0f, segH);

            if (i < litCount) {
                // Segmento acceso con bagliore
                juce::Colour c = (i >= numSegments - 3) ? peakColor : activeColor;
                g.setColour(c.withAlpha(0.35f));
                g.fillRoundedRectangle(segRect.expanded(1.0f), 1.5f);
                g.setColour(c);
                g.fillRoundedRectangle(segRect, 1.0f);
            } else {
                // Segmento spento (molto scuro)
                g.setColour(juce::Colour(0xFF1A1F26));
                g.fillRoundedRectangle(segRect, 1.0f);
            }
        }
    }

    void timerCallback() override {
        // Balistica di decadimento morbida tipo peak meter
        currentAtt += (targetAtt - currentAtt) * 0.35f;
        currentSus += (targetSus - currentSus) * 0.35f;
        targetAtt *= 0.88f;
        targetSus *= 0.88f;
        repaint();
    }

    float targetAtt = 0.0f;
    float targetSus = 0.0f;
    float currentAtt = 0.0f;
    float currentSus = 0.0f;
};

} // namespace dsp171
