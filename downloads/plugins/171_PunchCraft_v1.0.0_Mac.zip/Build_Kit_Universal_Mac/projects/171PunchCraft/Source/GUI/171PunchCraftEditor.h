#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <BinaryData.h>
#include "PunchCraftOscilloscopeComponent.h"
#include "PunchCraftLEDMeters.h"
#include "ResizableHandleComponent.h"

namespace PunchCraftBinaryData = BinaryData;

namespace dsp171 {

// ==============================================================================
// BOUTIQUE LOOK AND FEEL FOR 171PUNCHCRAFT
// ==============================================================================
class PunchCraftBoutiqueLookAndFeel : public juce::LookAndFeel_V4 {
public:
    PunchCraftBoutiqueLookAndFeel() {
        setColour(juce::Slider::textBoxTextColourId, juce::Colour(0xFFD4AF37)); // Gold text
        setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    }

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPosProportional, float rotaryStartAngle,
                          float rotaryEndAngle, juce::Slider& slider) override
    {
        const float radius = static_cast<float>(std::min(width, height)) * 0.5f - 4.0f;
        const float centreX = static_cast<float>(x) + static_cast<float>(width) * 0.5f;
        const float centreY = static_cast<float>(y) + static_cast<float>(height) * 0.5f;
        const float currentAngle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

        // Colore indicatore basato sulla funzione del controllo
        juce::Colour accentCol(0xFFFFB300); // Default Ambra (Attack)
        if (slider.getName().containsIgnoreCase("sustain")) {
            accentCol = juce::Colour(0xFF00E5FF); // Ciano (Sustain)
        } else if (slider.getName().containsIgnoreCase("sub")) {
            accentCol = juce::Colour(0xFFFFD54F); // Oro caldo (Sub)
        } else if (slider.getName().containsIgnoreCase("out") || slider.getName().containsIgnoreCase("mix") || slider.getName().containsIgnoreCase("trim")) {
            accentCol = juce::Colour(0xFF69F0AE); // Smeraldo boutique (Master)
        }

        // 1. Ombra proiettata alla base della manopola
        g.setColour(juce::Colour(0x60000000));
        g.fillEllipse(centreX - radius + 1.0f, centreY - radius + 3.0f, radius * 2.0f, radius * 2.0f);

        // 2. Arco di indicatore luminescente sul quadrante
        juce::Path arcPath;
        arcPath.addCentredArc(centreX, centreY, radius + 2.0f, radius + 2.0f, 0.0f, rotaryStartAngle, currentAngle, true);
        g.setColour(accentCol.withAlpha(0.25f));
        g.strokePath(arcPath, juce::PathStrokeType(4.0f));
        g.setColour(accentCol);
        g.strokePath(arcPath, juce::PathStrokeType(1.8f));

        // 3. Render Manopola Ufficiale 171 Studio in Acciaio Satinato Nero
        auto knobImg = juce::ImageCache::getFromMemory(PunchCraftBinaryData::knob_171_steel_satin_128_png,
                                                       PunchCraftBinaryData::knob_171_steel_satin_128_pngSize);
        if (knobImg.isValid()) {
            float knobDiam = radius * 2.0f;
            float imgW = static_cast<float>(knobImg.getWidth());
            float imgH = static_cast<float>(knobImg.getHeight());
            auto transform = juce::AffineTransform::rotation(currentAngle, imgW * 0.5f, imgH * 0.5f)
                .translated(centreX - imgW * 0.5f, centreY - imgH * 0.5f)
                .scaled(knobDiam / imgW, knobDiam / imgH, centreX, centreY);
            g.drawImageTransformed(knobImg, transform);
        } else {
            // Procedural PBR fallback
            g.setColour(juce::Colour(0xFF262C34));
            g.fillEllipse(centreX - radius + 2.0f, centreY - radius + 2.0f, (radius - 2.0f) * 2.0f, (radius - 2.0f) * 2.0f);
        }

        // 4. Tacca laser fresata e illuminata sulla manopola
        const float notchInnerR = radius * 0.35f;
        const float notchOuterR = radius * 0.88f;
        float nx1 = centreX + std::sin(currentAngle) * notchInnerR;
        float ny1 = centreY - std::cos(currentAngle) * notchInnerR;
        float nx2 = centreX + std::sin(currentAngle) * notchOuterR;
        float ny2 = centreY - std::cos(currentAngle) * notchOuterR;

        g.setColour(juce::Colour(0x90000000));
        g.drawLine(nx1 + 1.0f, ny1 + 1.0f, nx2 + 1.0f, ny2 + 1.0f, 3.0f);
        g.setColour(accentCol);
        g.drawLine(nx1, ny1, nx2, ny2, 2.0f);
    }
};

// ==============================================================================
// MAIN BOUTIQUE PANEL FOR 171PUNCHCRAFT
// ==============================================================================
class PunchCraftMainPanel : public juce::Component,
                            private juce::Timer {
public:
    PunchCraftMainPanel(juce::AudioProcessorValueTreeState& apvts, PunchCraftEngine& engine)
        : valueTreeState(apvts), dspEngine(engine),
          oscilloscope(dspEngine.getOscilloscopeBuffer())
    {
        // 1. Carica il logo 171 Studio Gold da BinaryData
        goldLogoImage = juce::ImageCache::getFromMemory(PunchCraftBinaryData::logo_171_gold_png,
                                                        PunchCraftBinaryData::logo_171_gold_pngSize);

        setLookAndFeel(&boutiqueLookAndFeel);

        // 2. Setup Display Centrale
        addAndMakeVisible(oscilloscope);
        addAndMakeVisible(ledMeters);

        // 3. Setup Parametri & Sliders
        setupSlider(attackBoostSlider, "attackBoost", "ATTACK", -100.0f, 100.0f, "%");
        setupSlider(attackSensSlider, "attackSens", "SENSITIVITY", 0.0f, 100.0f, "%");
        setupSlider(attackShapeSlider, "attackShape", "DURATION", 0.5f, 10.0f, "ms");

        setupSlider(sustainBoostSlider, "sustainBoost", "SUSTAIN", -100.0f, 100.0f, "%");
        setupSlider(sustainDecaySlider, "sustainDecay", "LENGTH", 10.0f, 500.0f, "ms");

        setupSlider(subLevelSlider, "subLevel", "SUB LEVEL", -40.0f, 12.0f, "dB");
        setupSlider(subDriveSlider, "subDrive", "SUB DRIVE", 0.0f, 100.0f, "%");

        setupSlider(crossLowSlider, "crossLow", "LOW CROSS", 40.0f, 400.0f, "Hz");
        setupSlider(crossHighSlider, "crossHigh", "HIGH CROSS", 1000.0f, 8000.0f, "Hz");

        setupSlider(dryWetSlider, "dryWet", "PARALLEL MIX", 0.0f, 100.0f, "%");
        setupSlider(outputTrimSlider, "outTrim", "TRIM", -18.0f, 18.0f, "dB");

        // 4. Selettori e Bottoni Stepped
        multiBandButton.setButtonText("3-BAND MULTI");
        multiBandButton.setClickingTogglesState(true);
        multiBandButton.setColour(juce::TextButton::buttonOnColourId, juce::Colour(0xFFFFB300));
        multiBandButton.setColour(juce::TextButton::textColourOnId, juce::Colours::black);
        addAndMakeVisible(multiBandButton);
        multiBandAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            valueTreeState, "multiBand", multiBandButton);

        subEnableButton.setButtonText("SUB ON");
        subEnableButton.setClickingTogglesState(true);
        subEnableButton.setColour(juce::TextButton::buttonOnColourId, juce::Colour(0xFFFFD54F));
        subEnableButton.setColour(juce::TextButton::textColourOnId, juce::Colours::black);
        addAndMakeVisible(subEnableButton);
        subEnableAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            valueTreeState, "subEnable", subEnableButton);

        subFreqBox.addItem("30 Hz (Sub Rumble)", 1);
        subFreqBox.addItem("45 Hz (808 Club)", 2);
        subFreqBox.addItem("60 Hz (Kick Punch)", 3);
        subFreqBox.addItem("80 Hz (Bass Body)", 4);
        subFreqBox.setSelectedId(2, juce::dontSendNotification);
        addAndMakeVisible(subFreqBox);
        subFreqAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(
            valueTreeState, "subTuned", subFreqBox);

        // Sub Octave Mode (Waves Submarine / bx_subsynth tier)
        subOctModeBox.addItem("-1 Oct (f0/2)", 1);
        subOctModeBox.addItem("-2 Oct (f0/4)", 2);
        subOctModeBox.addItem("Dual (-1 & -2 Oct)", 3);
        subOctModeBox.setSelectedId(1, juce::dontSendNotification);
        addAndMakeVisible(subOctModeBox);
        subOctModeAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(
            valueTreeState, "subOctMode", subOctModeBox);

        // Transient Curve Mode (Neutron / SPL / Envolution)
        curveModeBox.addItem("Precise (Neutron)", 1);
        curveModeBox.addItem("Balanced (SPL)", 2);
        curveModeBox.addItem("Loose (Envolution)", 3);
        curveModeBox.setSelectedId(2, juce::dontSendNotification);
        addAndMakeVisible(curveModeBox);
        curveModeAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(
            valueTreeState, "curveMode", curveModeBox);

        clipperButton.setButtonText("CLIPPER -0.1 dBFS");
        clipperButton.setClickingTogglesState(true);
        clipperButton.setColour(juce::TextButton::buttonOnColourId, juce::Colour(0xFFFF5252));
        addAndMakeVisible(clipperButton);
        clipperAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            valueTreeState, "clipperOn", clipperButton);

        bypassButton.setButtonText("BYPASS");
        bypassButton.setClickingTogglesState(true);
        bypassButton.setColour(juce::TextButton::buttonOnColourId, juce::Colour(0xFFFF3D00));
        addAndMakeVisible(bypassButton);
        bypassAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            valueTreeState, "bypass", bypassButton);

        // Maniglia di ridimensionamento fluido con aspect ratio lock
        addAndMakeVisible(resizeHandle);

        // Timer di rendering a 30 FPS per balistica e display fluido a 0.0% CPU
        startTimerHz(30);
    }

    ~PunchCraftMainPanel() override {
        stopTimer();
        setLookAndFeel(nullptr);
    }

    void timerCallback() override {
        ledMeters.updateLevels(dspEngine.getLatestAttackDelta(), dspEngine.getLatestSustainDelta());
        oscilloscope.setCrossoverFrequencies(static_cast<float>(crossLowSlider.getValue()),
                                            static_cast<float>(crossHighSlider.getValue()),
                                            multiBandButton.getToggleState());
    }

    void paint(juce::Graphics& g) override {
        // 1. Sfondo e campate da cache pre-renderizzata (0.0 ms CPU)
        if (backgroundCache.isValid()) {
            g.drawImageAt(backgroundCache, 0, 0);
        }

        // 2. Header Boutique con Badge Ufficiale 171 Studio Satin Gold
        auto badgeImg = juce::ImageCache::getFromMemory(PunchCraftBinaryData::badge_171_gold_180x60_png,
                                                        PunchCraftBinaryData::badge_171_gold_180x60_pngSize);
        if (badgeImg.isValid()) {
            g.drawImage(badgeImg, 22.0f, 14.0f, 96.0f, 32.0f, 0, 0, badgeImg.getWidth(), badgeImg.getHeight());
        }

        // Serigrafia Marchio Ufficiale
        g.setFont(juce::FontOptions("Segoe UI", 18.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xFFD4AF37)); // Oro 171
        g.drawText("171 PUNCHCRAFT", 128, 14, 280, 22, juce::Justification::left);

        g.setFont(juce::FontOptions("Segoe UI", 9.5f, juce::Font::bold));
        g.setColour(juce::Colour(0xFF9EABB8));
        g.drawText("MULTI-BAND TRANSIENT SHAPER & SUB-HARMONIC SCULPTOR", 128, 36, 420, 14, juce::Justification::left);
    }

    void rebuildBackgroundCache() {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        backgroundCache = juce::Image(juce::Image::ARGB, w, h, true);
        juce::Graphics g(backgroundCache);
        auto bounds = juce::Rectangle<float>(0, 0, static_cast<float>(w), static_cast<float>(h));

        // Chassis Alluminio Spazzolato Dark Titanium / Obsidian
        juce::ColourGradient chassisGrad(juce::Colour(0xFF1E2229), 0.0f, 0.0f,
                                         juce::Colour(0xFF121518), 0.0f, static_cast<float>(h), false);
        g.setGradientFill(chassisGrad);
        g.fillRoundedRectangle(bounds, 8.0f);

        // Texture metallo spazzolato fine
        g.setColour(juce::Colour(0x06FFFFFF));
        for (float y = 0.0f; y < static_cast<float>(h); y += 3.0f) {
            g.drawHorizontalLine(static_cast<int>(y), 0.0f, static_cast<float>(w));
        }

        // Bordo esterno bisellato
        g.setColour(juce::Colour(0xFF38404C));
        g.drawRoundedRectangle(bounds.reduced(1.0f), 8.0f, 1.5f);

        // Viti a brugola industriali nei 4 angoli
        drawAllenBolt(g, 16.0f, 16.0f);
        drawAllenBolt(g, static_cast<float>(w) - 16.0f, 16.0f);
        drawAllenBolt(g, 16.0f, static_cast<float>(h) - 16.0f);
        drawAllenBolt(g, static_cast<float>(w) - 16.0f, static_cast<float>(h) - 16.0f);

        // Pannellature delle 4 Campate Inferiori
        const float bayY = 328.0f;
        const float bayH = static_cast<float>(h) - bayY - 20.0f;
        const float bayW = (static_cast<float>(w) - 50.0f) / 4.0f;

        drawBayChassis(g, 20.0f + 0 * (bayW + 3.0f), bayY, bayW, bayH, "BAY 1: SUB-HARMONIC ENGINE", juce::Colour(0xFFFFD54F));
        drawBayChassis(g, 20.0f + 1 * (bayW + 3.0f), bayY, bayW, bayH, "BAY 2: ATTACK SHAPING", juce::Colour(0xFFFFB300));
        drawBayChassis(g, 20.0f + 2 * (bayW + 3.0f), bayY, bayW, bayH, "BAY 3: SUSTAIN SHAPING", juce::Colour(0xFF00E5FF));
        drawBayChassis(g, 20.0f + 3 * (bayW + 3.0f), bayY, bayW, bayH, "BAY 4: CROSSOVER & MASTER", juce::Colour(0xFF69F0AE));
    }

    void resized() override {
        rebuildBackgroundCache();
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());

        // Header controls (Mode & Bypass)
        multiBandButton.setBounds(static_cast<int>(w - 240), 18, 110, 28);
        bypassButton.setBounds(static_cast<int>(w - 110), 18, 80, 28);

        // Display Centrale e LED Meters
        const float scopeX = 20.0f;
        const float scopeY = 68.0f;
        const float metersW = 100.0f;
        const float scopeW = w - 40.0f - metersW - 10.0f;
        const float scopeH = 245.0f;

        oscilloscope.setBounds(static_cast<int>(scopeX), static_cast<int>(scopeY),
                               static_cast<int>(scopeW), static_cast<int>(scopeH));
        ledMeters.setBounds(static_cast<int>(scopeX + scopeW + 10.0f), static_cast<int>(scopeY),
                            static_cast<int>(metersW), static_cast<int>(scopeH));

        // 4 Campate inferiori
        const float bayY = 328.0f;
        const float bayH = h - bayY - 20.0f;
        const float bayW = (w - 50.0f) / 4.0f;

        // Bay 1: Sub-Harmonics
        float b1X = 20.0f;
        subEnableButton.setBounds(static_cast<int>(b1X + 8), static_cast<int>(bayY + 26), static_cast<int>((bayW - 20) * 0.46f), 22);
        subOctModeBox.setBounds(static_cast<int>(b1X + 8 + (bayW - 20) * 0.50f), static_cast<int>(bayY + 26), static_cast<int>((bayW - 20) * 0.50f), 22);
        subFreqBox.setBounds(static_cast<int>(b1X + 8), static_cast<int>(bayY + 52), static_cast<int>(bayW - 16), 22);
        subLevelSlider.setBounds(static_cast<int>(b1X + 6), static_cast<int>(bayY + 80), static_cast<int>(bayW * 0.5f - 8), static_cast<int>(bayH - 88));
        subDriveSlider.setBounds(static_cast<int>(b1X + bayW * 0.5f + 2), static_cast<int>(bayY + 80), static_cast<int>(bayW * 0.5f - 8), static_cast<int>(bayH - 88));

        // Bay 2: Attack Shaping
        float b2X = 20.0f + 1 * (bayW + 3.0f);
        curveModeBox.setBounds(static_cast<int>(b2X + 8), static_cast<int>(bayY + 26), static_cast<int>(bayW - 16), 22);
        float dialW = (bayW - 16.0f) / 3.0f;
        attackBoostSlider.setBounds(static_cast<int>(b2X + 6), static_cast<int>(bayY + 54), static_cast<int>(dialW), static_cast<int>(bayH - 62));
        attackSensSlider.setBounds(static_cast<int>(b2X + 6 + dialW), static_cast<int>(bayY + 54), static_cast<int>(dialW), static_cast<int>(bayH - 62));
        attackShapeSlider.setBounds(static_cast<int>(b2X + 6 + dialW * 2), static_cast<int>(bayY + 54), static_cast<int>(dialW), static_cast<int>(bayH - 62));

        // Bay 3: Sustain Shaping
        float b3X = 20.0f + 2 * (bayW + 3.0f);
        float susDialW = (bayW - 16.0f) * 0.5f;
        sustainBoostSlider.setBounds(static_cast<int>(b3X + 8), static_cast<int>(bayY + 36), static_cast<int>(susDialW), static_cast<int>(bayH - 48));
        sustainDecaySlider.setBounds(static_cast<int>(b3X + 8 + susDialW), static_cast<int>(bayY + 36), static_cast<int>(susDialW), static_cast<int>(bayH - 48));

        // Bay 4: Crossover & Master
        float b4X = 20.0f + 3 * (bayW + 3.0f);
        crossLowSlider.setBounds(static_cast<int>(b4X + 6), static_cast<int>(bayY + 28), static_cast<int>((bayW - 18.0f) * 0.5f), 90);
        crossHighSlider.setBounds(static_cast<int>(b4X + 8 + (bayW - 18.0f) * 0.5f), static_cast<int>(bayY + 28), static_cast<int>((bayW - 18.0f) * 0.5f), 90);

        clipperButton.setBounds(static_cast<int>(b4X + 8), static_cast<int>(bayY + 124), static_cast<int>(bayW - 16), 22);

        float mDialW = (bayW - 16.0f) * 0.5f;
        dryWetSlider.setBounds(static_cast<int>(b4X + 8), static_cast<int>(bayY + 152), static_cast<int>(mDialW), static_cast<int>(bayH - 162));
        outputTrimSlider.setBounds(static_cast<int>(b4X + 8 + mDialW), static_cast<int>(bayY + 152), static_cast<int>(mDialW), static_cast<int>(bayH - 162));

        resizeHandle.setBounds(getWidth() - 16, getHeight() - 16, 16, 16);
    }

private:
    void setupSlider(juce::Slider& slider, const juce::String& paramId, const juce::String& labelText,
                     float minVal, float maxVal, const juce::String& suffix)
    {
        slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 55, 14);
        slider.setRange(minVal, maxVal);
        slider.setTextValueSuffix(" " + suffix);
        slider.setName(labelText);
        addAndMakeVisible(slider);

        auto attachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            valueTreeState, paramId, slider);
        sliderAttachments.push_back(std::move(attachment));
    }

    void drawBayChassis(juce::Graphics& g, float x, float y, float w, float h,
                        const juce::String& title, juce::Colour accentCol)
    {
        juce::Rectangle<float> rect(x, y, w, h);
        g.setColour(juce::Colour(0xFF14171B));
        g.fillRoundedRectangle(rect, 4.0f);

        g.setColour(juce::Colour(0xFF282E37));
        g.drawRoundedRectangle(rect, 4.0f, 1.0f);

        // Header campata
        juce::Rectangle<float> headerRect(x, y, w, 22.0f);
        g.setColour(juce::Colour(0xFF1B2026));
        g.fillRoundedRectangle(headerRect, 4.0f);

        g.setColour(accentCol);
        g.fillRect(x + 6.0f, y + 6.0f, 3.0f, 10.0f);

        g.setFont(juce::FontOptions("Segoe UI", 9.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xFFECEFF1));
        g.drawText(title, static_cast<int>(x + 14.0f), static_cast<int>(y + 3.0f),
                   static_cast<int>(w - 20.0f), 16, juce::Justification::left);
    }

    void drawAllenBolt(juce::Graphics& g, float x, float y) {
        constexpr float radius = 5.0f;
        g.setColour(juce::Colour(0x60000000));
        g.fillEllipse(x - radius + 1.0f, y - radius + 1.0f, radius * 2.0f, radius * 2.0f);

        juce::ColourGradient boltGrad(juce::Colour(0xFF8A9BA8), x - radius, y - radius,
                                      juce::Colour(0xFF323B44), x + radius, y + radius, false);
        g.setGradientFill(boltGrad);
        g.fillEllipse(x - radius, y - radius, radius * 2.0f, radius * 2.0f);

        // Foro esagonale a brugola
        g.setColour(juce::Colour(0xFF181C22));
        juce::Path hexPath;
        constexpr int sides = 6;
        for (int i = 0; i < sides; ++i) {
            float angle = i * (6.2831853f / sides);
            float px = x + std::cos(angle) * (radius * 0.48f);
            float py = y + std::sin(angle) * (radius * 0.48f);
            if (i == 0) hexPath.startNewSubPath(px, py);
            else hexPath.lineTo(px, py);
        }
        hexPath.closeSubPath();
        g.fillPath(hexPath);
    }

    juce::AudioProcessorValueTreeState& valueTreeState;
    PunchCraftEngine& dspEngine;

    PunchCraftBoutiqueLookAndFeel boutiqueLookAndFeel;
    juce::Image backgroundCache;
    juce::Image goldLogoImage;

    PunchCraftOscilloscopeComponent oscilloscope;
    PunchCraftLEDMeters ledMeters;

    juce::Slider attackBoostSlider, attackSensSlider, attackShapeSlider;
    juce::Slider sustainBoostSlider, sustainDecaySlider;
    juce::Slider subLevelSlider, subDriveSlider;
    juce::Slider crossLowSlider, crossHighSlider;
    juce::Slider dryWetSlider, outputTrimSlider;

    juce::TextButton multiBandButton;
    juce::TextButton subEnableButton;
    juce::ComboBox subFreqBox;
    juce::ComboBox subOctModeBox;
    juce::ComboBox curveModeBox;
    juce::TextButton clipperButton;
    juce::TextButton bypassButton;

    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAttachments;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> multiBandAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> subEnableAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> subFreqAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> subOctModeAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> curveModeAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> clipperAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bypassAttachment;

    plugin_171::ResizableHandleComponent resizeHandle;
};

} // namespace dsp171
