#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <array>
#include "../DSP/PunchCraftEngine.h"

namespace dsp171 {

class PunchCraftOscilloscopeComponent : public juce::Component,
                                        private juce::Timer
{
public:
    PunchCraftOscilloscopeComponent(const CircularOscilloscopeBuffer& bufferToRead)
        : scopeBuffer(bufferToRead)
    {
        setOpaque(true);
        startTimerHz(30); // 30 FPS sincronizzato per zero-lag e minimo carico CPU
    }

    ~PunchCraftOscilloscopeComponent() override {
        stopTimer();
    }

    void setCrossoverFrequencies(float lowHz, float highHz, bool isMultiBand) noexcept {
        crossoverLow = lowHz;
        crossoverHigh = highHz;
        multiBand = isMultiBand;
        repaint();
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const float w = bounds.getWidth();
        const float h = bounds.getHeight();

        // 1. Inset Bezel & Dark CRT Background
        g.setColour(juce::Colour(0xFF0F1115));
        g.fillRoundedRectangle(bounds, 6.0f);

        juce::ColourGradient bgGrad(juce::Colour(0xFF14181F), w * 0.5f, h * 0.5f,
                                    juce::Colour(0xFF0A0C0E), 0.0f, 0.0f, true);
        g.setGradientFill(bgGrad);
        g.fillRoundedRectangle(bounds.reduced(1.0f), 5.0f);

        // Bordo fresato metallico
        g.setColour(juce::Colour(0xFF282F38));
        g.drawRoundedRectangle(bounds.reduced(0.5f), 6.0f, 1.2f);

        // 2. Griglia fine di precisione
        g.setColour(juce::Colour(0x1800E5FF)); // ciano molto tenue
        constexpr int numVLines = 8;
        for (int i = 1; i < numVLines; ++i) {
            float x = w * (static_cast<float>(i) / numVLines);
            g.drawVerticalLine(static_cast<int>(x), 4.0f, h - 4.0f);
        }

        constexpr int numHLines = 4;
        for (int i = 1; i < numHLines; ++i) {
            float y = h * (static_cast<float>(i) / numHLines);
            g.drawHorizontalLine(static_cast<int>(y), 4.0f, w - 4.0f);
        }

        // Linea centrale di zero
        g.setColour(juce::Colour(0x30FFFFFF));
        g.drawHorizontalLine(static_cast<int>(h * 0.5f), 4.0f, w - 4.0f);

        // 3. Acquisizione snapshot dai buffer atomici
        scopeBuffer.readSnapshot(cachedWave, cachedAtt, cachedSus);

        // 4. Disegno Waveform di base (Titanio/Grigio Scuro) & Phosphor Decay Trail
        constexpr size_t N = CircularOscilloscopeBuffer::BufferSize;
        constexpr size_t step = 4; // visualizza 256 punti

        wavePath.clear();
        attPath.clear();
        susPath.clear();
        phosphorPath.clear();
        attFillPath.clear();

        const float midY = h * 0.5f;
        const float ampScale = h * 0.42f;

        bool firstPoint = true;
        for (size_t i = 0; i < N; i += step) {
            float normX = static_cast<float>(i) / static_cast<float>(N);
            float px = 4.0f + normX * (w - 8.0f);

            float audioVal = std::clamp(cachedWave[i], 0.0f, 1.5f);
            float pyWave = midY - audioVal * ampScale;

            float attVal = std::clamp(cachedAtt[i], 0.0f, 1.5f);
            // Inseguimento della scia fosforescente CRT
            phosphorTrail[i] = std::max(attVal, phosphorTrail[i] * 0.89f);
            float pyPhos = midY - (audioVal + phosphorTrail[i] * 1.8f) * ampScale;
            float pyAtt = midY - (audioVal + attVal * 1.8f) * ampScale;

            float susVal = std::clamp(cachedSus[i], 0.0f, 1.5f);
            float pySus = midY + (audioVal + susVal * 1.2f) * ampScale;

            if (firstPoint) {
                wavePath.startNewSubPath(px, pyWave);
                attPath.startNewSubPath(px, pyAtt);
                susPath.startNewSubPath(px, pySus);
                phosphorPath.startNewSubPath(px, pyPhos);
                attFillPath.startNewSubPath(px, pyAtt);
                firstPoint = false;
            } else {
                wavePath.lineTo(px, pyWave);
                attPath.lineTo(px, pyAtt);
                susPath.lineTo(px, pySus);
                phosphorPath.lineTo(px, pyPhos);
                attFillPath.lineTo(px, pyAtt);
            }
        }

        // Chiusura del gradiente di riempimento attack
        attFillPath.lineTo(w - 4.0f, midY);
        attFillPath.lineTo(4.0f, midY);
        attFillPath.closeSubPath();
        juce::ColourGradient attHeat(juce::Colour(0x28ffaa00), 0.0f, midY - 40.0f,
                                     juce::Colour(0x02ffaa00), 0.0f, midY, false);
        g.setGradientFill(attHeat);
        g.fillPath(attFillPath);

        // Glow e rendering tracciati
        // Phosphor Persistence Trail (CRT Glow)
        g.setColour(juce::Colour(0x22FFB300));
        g.strokePath(phosphorPath, juce::PathStrokeType(4.5f));

        // Sustain (Neon Cyan)
        g.setColour(juce::Colour(0x5500E5FF));
        g.strokePath(susPath, juce::PathStrokeType(3.0f));
        g.setColour(juce::Colour(0xFF00E5FF));
        g.strokePath(susPath, juce::PathStrokeType(1.2f));

        // Waveform principale (Deep Metallic Titanium)
        g.setColour(juce::Colour(0x884A5B6D));
        g.strokePath(wavePath, juce::PathStrokeType(2.5f));
        g.setColour(juce::Colour(0xFF7E97B0));
        g.strokePath(wavePath, juce::PathStrokeType(1.2f));

        // Attack Transient Spikes (Glowing Amber/Gold)
        g.setColour(juce::Colour(0x66FFB300));
        g.strokePath(attPath, juce::PathStrokeType(3.5f));
        g.setColour(juce::Colour(0xFFFFC107));
        g.strokePath(attPath, juce::PathStrokeType(1.4f));

        // 5. Linee Crossover Interattive (se in modalità 3-Bande)
        if (multiBand) {
            // Posizione logaritmica approssimata delle frequenze di crossover
            float normLow = std::clamp((std::log10(crossoverLow) - std::log10(40.0f)) / (std::log10(12000.0f) - std::log10(40.0f)), 0.08f, 0.45f);
            float normHigh = std::clamp((std::log10(crossoverHigh) - std::log10(40.0f)) / (std::log10(12000.0f) - std::log10(40.0f)), 0.55f, 0.92f);

            float xLow = 4.0f + normLow * (w - 8.0f);
            float xHigh = 4.0f + normHigh * (w - 8.0f);

            g.setColour(juce::Colour(0xAAFFC107)); // ambra per Low Crossover
            g.drawDashedLine(juce::Line<float>(xLow, 6.0f, xLow, h - 6.0f), dashPattern, 2, 1.2f);

            g.setColour(juce::Colour(0xAA00E5FF)); // ciano per High Crossover
            g.drawDashedLine(juce::Line<float>(xHigh, 6.0f, xHigh, h - 6.0f), dashPattern, 2, 1.2f);

            // Diciture frequenze
            g.setFont(juce::FontOptions("Segoe UI", 10.0f, juce::Font::bold));
            g.setColour(juce::Colour(0xFFFFC107));
            g.drawText(juce::String(static_cast<int>(crossoverLow)) + " Hz",
                       static_cast<int>(xLow) - 30, static_cast<int>(h - 18.0f), 60, 14, juce::Justification::centred);

            g.setColour(juce::Colour(0xFF00E5FF));
            g.drawText(juce::String(static_cast<int>(crossoverHigh)) + " Hz",
                       static_cast<int>(xHigh) - 30, static_cast<int>(h - 18.0f), 60, 14, juce::Justification::centred);
        }

        // 6. Header Serigrafico sul Display
        g.setFont(juce::FontOptions("Segoe UI", 9.5f, juce::Font::bold));
        g.setColour(juce::Colour(0xAA9EABB8));
        g.drawText("REAL-TIME DYNAMIC TRANSIENT OSCILLOSCOPE", 10, 6, 260, 14, juce::Justification::left);

        // Legenda attiva in alto a destra
        g.setFont(juce::FontOptions("Segoe UI", 9.0f, juce::Font::plain));
        g.setColour(juce::Colour(0xFFFFC107));
        g.drawText("* ATTACK FLUX", static_cast<int>(w - 170.0f), 6, 80, 14, juce::Justification::centredRight);
        g.setColour(juce::Colour(0xFF00E5FF));
        g.drawText("* SUSTAIN TAIL", static_cast<int>(w - 90.0f), 6, 80, 14, juce::Justification::centredRight);
    }

private:
    void timerCallback() override {
        repaint();
    }

    const CircularOscilloscopeBuffer& scopeBuffer;
    float crossoverLow = 140.0f;
    float crossoverHigh = 2500.0f;
    bool multiBand = true;

    std::array<float, CircularOscilloscopeBuffer::BufferSize> cachedWave {};
    std::array<float, CircularOscilloscopeBuffer::BufferSize> cachedAtt {};
    std::array<float, CircularOscilloscopeBuffer::BufferSize> cachedSus {};
    std::array<float, CircularOscilloscopeBuffer::BufferSize> phosphorTrail {};

    juce::Path wavePath;
    juce::Path attPath;
    juce::Path susPath;
    juce::Path phosphorPath;
    juce::Path attFillPath;
    const float dashPattern[2] = { 4.0f, 3.0f };
};

} // namespace dsp171
