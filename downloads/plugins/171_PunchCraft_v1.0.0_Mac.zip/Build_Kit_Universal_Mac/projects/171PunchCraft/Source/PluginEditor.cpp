#include "PluginProcessor.h"
#include "PluginEditor.h"

PunchCraftAudioProcessorEditor::PunchCraftAudioProcessorEditor(PunchCraftAudioProcessor& p)
    : AudioProcessorEditor(&p), processorRef(p),
      mainPanel(p.getAPVTS(), p.getEngine())
{
    addAndMakeVisible(mainPanel);
    setSize(980, 620);
    setResizable(true, true);
    setResizeLimits(800, 500, 1400, 900);
}

PunchCraftAudioProcessorEditor::~PunchCraftAudioProcessorEditor() = default;

void PunchCraftAudioProcessorEditor::paint(juce::Graphics& g) {
    g.fillAll(juce::Colour(0xFF101215));
}

void PunchCraftAudioProcessorEditor::resized() {
    mainPanel.setBounds(getLocalBounds());
}
