#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <chrono>
#include <cmath>
#include <fstream>
#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_formats/juce_audio_formats.h>
#include "../DSP/PunchCraftEngine.h"
#include "dsp171/DSPHireManager.h"

struct TestTrackSpec {
    std::string name;
    std::string category;
    std::string relativePath;
    std::string outputFilename;
    bool isMultiBand;
    float attackBoostPct;
    float attackSensPct;
    float attackDurationMs;
    float sustainBoostPct;
    float sustainDecayMs;
    float crossLowHz;
    float crossHighHz;
    bool subEnable;
    float subTunedHz;
    float subLevelDb;
    float subDrivePct;
    bool punchClipper;
    float dryWetPct;
};

int main(int argc, char* argv[]) {
    juce::ignoreUnused(argc, argv);

    std::cout << "====================================================================\n";
    std::cout << "  171PUNCHCRAFT - MULTI-AUDIO STEM AUDIT & DYNAMICS BENCHMARK       \n";
    std::cout << "  Orchestrato con DSPHireManager (Council Specialists)             \n";
    std::cout << "====================================================================\n\n";

    // Dispatch del DSPHireManager
    auto dispatchAtt = dsp171::DSPHireManager::dispatchTransientShaping();
    auto dispatchSub = dsp171::DSPHireManager::dispatchSubHarmonics();

    std::cout << "[DSP HIRE MANAGER] Dispatch Convocato:\n";
    std::cout << " - Transient Specialist:    " << dispatchAtt.primaryAgent.agentId << " (" << dispatchAtt.primaryAgent.agentTitle << ")\n";
    std::cout << " - Sub-Harmonic Specialist: " << dispatchSub.primaryAgent.agentId << " (" << dispatchSub.primaryAgent.agentTitle << ")\n";
    std::cout << " - QA Lead Auditor:         " << dispatchAtt.qaAuditorAgent.agentId << "\n\n";

    juce::AudioFormatManager formatManager;
    formatManager.registerBasicFormats();

    juce::File currentDir = juce::File::getCurrentWorkingDirectory();
    juce::File rootDir = currentDir;
    while (!rootDir.getChildFile("projects").exists() && rootDir.getParentDirectory() != rootDir) {
        rootDir = rootDir.getParentDirectory();
    }

    juce::File outputDir = rootDir.getChildFile("tools-and-analysis")
                                  .getChildFile("audit-outputs")
                                  .getChildFile("171PunchCraft_MultiAudio_Audit");
    outputDir.createDirectory();

    std::cout << "[*] Cartella di output audio audit:\n    " << outputDir.getFullPathName().toStdString() << "\n\n";

    std::vector<TestTrackSpec> specs = {
        {
            "Track 1 - Drum / Transient Ballistics Bus",
            "Drums & Percussion / In-Your-Face Kick & Snare Punch",
            "tools-and-analysis/stimuli/04_dynamic_burst_ballistics.wav",
            "01_drums_punch_sculpt.wav",
            true, 60.0f, 60.0f, 1.8f, -20.0f, 80.0f, 140.0f, 2500.0f,
            true, 60.0f, 3.0f, 35.0f, true, 100.0f
        },
        {
            "Track 2 - Melodic & Harmonic Bus (Dankle Stem)",
            "Acoustic & Plucked / Dynamic Pluck Definition & Body",
            "tools-and-analysis/audit-outputs/171_PerfectPre_Audit_Stems/DANKLE_02-230715_1908.wav",
            "02_melodic_pluck_punch.wav",
            true, 40.0f, 50.0f, 1.2f, 25.0f, 220.0f, 160.0f, 3000.0f,
            false, 45.0f, -40.0f, 0.0f, true, 85.0f
        },
        {
            "Track 3 - Lead Vocal Bus (Maurito Stem)",
            "Vocals / Consonant Intelligibility & Snap",
            "tools-and-analysis/audit-outputs/171_PerfectPre_Audit_Stems/MAURITO_08-230312_1223-01.wav",
            "03_vocal_consonant_snap.wav",
            true, 45.0f, 65.0f, 1.0f, -15.0f, 100.0f, 200.0f, 3500.0f,
            false, 45.0f, -40.0f, 0.0f, true, 90.0f
        },
        {
            "Track 4 - Master Mix Bus (Adriano Full Melodic Track)",
            "Master Bus / Punch Sculptor & Sub Earthshaker",
            "tools-and-analysis/audit-outputs/171_PerfectPre_Audit_Stems/ADRIANO_02-240110_1148.wav",
            "04_master_bus_punchcraft.wav",
            true, 25.0f, 45.0f, 2.0f, 10.0f, 180.0f, 120.0f, 2800.0f,
            true, 45.0f, 1.5f, 20.0f, true, 100.0f
        }
    };

    for (const auto& spec : specs) {
        std::cout << "--------------------------------------------------------------------\n";
        std::cout << "[*] Esecuzione " << spec.name << "\n";
        std::cout << "    Preset: " << spec.category << "\n";

        juce::File inputFile = rootDir.getChildFile(spec.relativePath);
        if (!inputFile.existsAsFile()) {
            std::cerr << "    [ERRORE] File non trovato: " << inputFile.getFullPathName().toStdString() << "\n";
            continue;
        }

        std::unique_ptr<juce::AudioFormatReader> reader(formatManager.createReaderFor(inputFile));
        if (reader == nullptr) continue;

        const int numChannels = static_cast<int>(reader->numChannels);
        const int numSamples = static_cast<int>(reader->lengthInSamples);
        const double sampleRate = reader->sampleRate;
        const double durationSec = static_cast<double>(numSamples) / sampleRate;

        juce::AudioBuffer<float> inBuffer(2, numSamples);
        inBuffer.clear();

        if (numChannels >= 2) {
            reader->read(&inBuffer, 0, numSamples, 0, true, true);
        } else {
            reader->read(&inBuffer, 0, numSamples, 0, true, false);
            inBuffer.copyFrom(1, 0, inBuffer, 0, 0, numSamples);
        }

        dsp171::PunchCraftEngine engine;
        engine.prepare(sampleRate, 512);
        engine.setParameters(
            spec.isMultiBand,
            spec.attackBoostPct,
            spec.attackSensPct,
            spec.attackDurationMs,
            spec.sustainBoostPct,
            spec.sustainDecayMs,
            spec.crossLowHz,
            spec.crossHighHz,
            spec.subEnable,
            spec.subTunedHz,
            spec.subLevelDb,
            spec.subDrivePct,
            spec.punchClipper,
            spec.dryWetPct,
            0.0f,
            false
        );
        engine.resetStats();

        juce::AudioBuffer<float> outBuffer;
        outBuffer.makeCopyOf(inBuffer);

        constexpr int blockSize = 512;
        auto startTime = std::chrono::high_resolution_clock::now();

        for (int start = 0; start < numSamples; start += blockSize) {
            int currentBlock = std::min(blockSize, numSamples - start);
            juce::AudioBuffer<float> blockProxy(outBuffer.getArrayOfWritePointers(), 2, start, currentBlock);
            engine.processBlock(blockProxy);
        }

        auto endTime = std::chrono::high_resolution_clock::now();
        double elapsedMs = std::chrono::duration<double, std::milli>(endTime - startTime).count();
        double speedup = (durationSec * 1000.0) / elapsedMs;

        float maxAttDelta = engine.getMaxObservedAttackDelta();
        float maxSusDelta = engine.getMaxObservedSustainDelta();

        // Misurazione picco e sanità
        float outPeak = 0.0f;
        bool hasNanInf = false;

        for (int i = 0; i < numSamples; ++i) {
            float l = outBuffer.getSample(0, i);
            float r = outBuffer.getSample(1, i);
            if (std::isnan(l) || std::isnan(r) || std::isinf(l) || std::isinf(r)) hasNanInf = true;
            outPeak = std::max(outPeak, std::max(std::abs(l), std::abs(r)));
        }

        float outPeakDb = (outPeak > 1.0e-5f) ? (20.0f * std::log10(outPeak)) : -100.0f;

        std::cout << "    [BENCHMARK]:\n";
        std::cout << "      Tempo CPU: " << std::fixed << std::setprecision(2) << elapsedMs << " ms ("
                  << std::setprecision(1) << speedup << "x Real-Time speedup)\n";
        std::cout << "      Max Attack Delta:   +" << std::setprecision(3) << maxAttDelta << "\n";
        std::cout << "      Max Sustain Delta:  +" << std::setprecision(3) << maxSusDelta << "\n";
        std::cout << "      Out Peak:           " << outPeakDb << " dBFS (Ceiling <= -0.1 dBFS)\n";
        std::cout << "      Sanity Check:       " << (hasNanInf ? "ERROR NaN/Inf" : "PULITO (0 NaN/Inf)") << "\n";

        juce::File destWav = outputDir.getChildFile(spec.outputFilename);
        if (destWav.existsAsFile()) destWav.deleteFile();

        std::unique_ptr<juce::FileOutputStream> outStream(destWav.createOutputStream());
        if (outStream != nullptr) {
            juce::WavAudioFormat wavFormat;
            std::unique_ptr<juce::AudioFormatWriter> writer(wavFormat.createWriterFor(
                outStream.get(), sampleRate, 2, 24, {}, 0));
            if (writer != nullptr) {
                outStream.release();
                writer->writeFromAudioSampleBuffer(outBuffer, 0, numSamples);
                std::cout << "    [SALVATO]: " << destWav.getFileName().toStdString() << " ("
                          << destWav.getSize() / 1024 << " KB)\n";
            }
        }
    }

    std::cout << "\n====================================================================\n";
    std::cout << " 171PUNCHCRAFT - AUDIO AUDIT COMPLETATO CON SUCCESSO!               \n";
    std::cout << "====================================================================\n";

    return 0;
}
