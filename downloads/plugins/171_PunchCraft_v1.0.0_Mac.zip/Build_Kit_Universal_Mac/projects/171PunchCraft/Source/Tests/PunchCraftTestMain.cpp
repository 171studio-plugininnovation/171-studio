#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>
#include <cassert>
#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include "../DSP/PunchCraftEngine.h"

int main(int argc, char* argv[]) {
    juce::ignoreUnused(argc, argv);

    std::cout << "====================================================================\n";
    std::cout << " 171PUNCHCRAFT - COLLAUDO MATEMATICO & SCIENTIFICO DSP ENGINE\n";
    std::cout << " Multi-Band Transient Shaper & Sub-Harmonic Sculptor (Council Audit)\n";
    std::cout << "====================================================================\n\n";

    constexpr double sampleRate = 48000.0;
    int testsPassed = 0;

    // --------------------------------------------------------------------------
    // TEST 1: Level-Independent Differential Attack Detection (D.E.T.)
    // --------------------------------------------------------------------------
    {
        dsp171::DifferentialTransientDetector det;
        det.prepare(sampleRate);
        det.setParameters(80.0f, 60.0f, 1.5f); // +80% Attack Boost

        // Burst ad alto livello (0.8 = -2 dBFS)
        float observedDeltaHigh = 0.0f;
        float gainPeakHigh = 1.0f;
        for (int i = 0; i < 200; ++i) {
            float g = det.processSample(0.8f, observedDeltaHigh);
            if (g > gainPeakHigh) gainPeakHigh = g;
        }

        det.reset();
        // Burst a basso livello (0.08 = -22 dBFS)
        float observedDeltaLow = 0.0f;
        float gainPeakLow = 1.0f;
        for (int i = 0; i < 200; ++i) {
            float g = det.processSample(0.08f, observedDeltaLow);
            if (g > gainPeakLow) gainPeakLow = g;
        }

        // Il guadagno di attacco D.E.T. deve intervenire efficacemente in entrambi i casi (> 2.0x)
        if (gainPeakHigh > 2.5f && gainPeakLow > 2.0f) {
            std::cout << "[*] Test 1: Level-Independent D.E.T. Attack Detection... [SUPERATO] (High Peak Gain: "
                      << gainPeakHigh << ", Low Peak Gain: " << gainPeakLow << ")\n";
            testsPassed++;
        } else {
            std::cout << "[!] Test 1: Level-Independent D.E.T. Attack Detection... [FALLITO]\n";
        }
    }

    // --------------------------------------------------------------------------
    // TEST 2: Attack Boost vs Cut Linearity
    // --------------------------------------------------------------------------
    {
        dsp171::DifferentialTransientDetector detBoost, detCut;
        detBoost.prepare(sampleRate);
        detBoost.setParameters(100.0f, 50.0f, 1.5f); // +100% Boost

        detCut.prepare(sampleRate);
        detCut.setParameters(-100.0f, 50.0f, 1.5f); // -100% Cut

        float maxBoost = 1.0f, minCut = 1.0f;
        float delta = 0.0f;
        for (int i = 0; i < 300; ++i) {
            float sample = (i < 50) ? 0.9f : 0.0f;
            float gB = detBoost.processSample(sample, delta);
            float gC = detCut.processSample(sample, delta);
            if (gB > maxBoost) maxBoost = gB;
            if (gC < minCut) minCut = gC;
        }

        if (maxBoost >= 3.5f && minCut <= 0.45f) {
            std::cout << "[*] Test 2: Attack Boost vs Cut Linearity... [SUPERATO] (Max Boost: "
                      << maxBoost << "x, Min Cut: " << minCut << "x)\n";
            testsPassed++;
        } else {
            std::cout << "[!] Test 2: Attack Boost vs Cut Linearity... [FALLITO] (Boost: "
                      << maxBoost << ", Cut: " << minCut << ")\n";
        }
    }

    // --------------------------------------------------------------------------
    // TEST 3: Attack Duration & Shape Time-Domain Conformance
    // --------------------------------------------------------------------------
    {
        dsp171::DifferentialTransientDetector detSharp, detBroad;
        detSharp.prepare(sampleRate);
        detSharp.setParameters(100.0f, 50.0f, 0.8f); // 0.8 ms sharp

        detBroad.prepare(sampleRate);
        detBroad.setParameters(100.0f, 50.0f, 6.0f); // 6.0 ms broad

        float delta = 0.0f;
        int activeSamplesSharp = 0, activeSamplesBroad = 0;

        for (int i = 0; i < 2000; ++i) {
            float in = (i < 150) ? 0.9f : 0.0f; // Burst percussivo di 3 ms
            float gS = detSharp.processSample(in, delta);
            float gB = detBroad.processSample(in, delta);
            if (gS > 1.3f) activeSamplesSharp++;
            if (gB > 1.3f) activeSamplesBroad++;
        }

        // Il profilo broad deve durare significativamente più a lungo del profilo sharp
        if (activeSamplesBroad > activeSamplesSharp * 2) {
            std::cout << "[*] Test 3: Attack Duration & Shape Conformance... [SUPERATO] (Sharp: "
                      << activeSamplesSharp << " smp, Broad: " << activeSamplesBroad << " smp)\n";
            testsPassed++;
        } else {
            std::cout << "[!] Test 3: Attack Duration & Shape Conformance... [FALLITO]\n";
        }
    }

    // --------------------------------------------------------------------------
    // TEST 4: Differential Sustain Envelope & Tail Expansion
    // --------------------------------------------------------------------------
    {
        dsp171::DifferentialSustainDetector susBoost, susCut;
        susBoost.prepare(sampleRate);
        susBoost.setParameters(100.0f, 250.0f); // +100% Sustain boost, 250ms decay
        susCut.prepare(sampleRate);
        susCut.setParameters(-100.0f, 100.0f); // -100% Sustain choke

        float delta = 0.0f;
        float energyBoost = 0.0f, energyCut = 0.0f;

        // Simuliamo il decadimento di un fusto di rullante (esponenziale da 1.0 a 0.01)
        for (int i = 0; i < 15000; ++i) {
            float decay = std::exp(-static_cast<float>(i) / (sampleRate * 0.15f));
            float gB = susBoost.processSample(decay, delta);
            float gC = susCut.processSample(decay, delta);
            energyBoost += (decay * gB) * (decay * gB);
            energyCut   += (decay * gC) * (decay * gC);
        }

        if (energyBoost > energyCut * 2.0f) {
            std::cout << "[*] Test 4: Differential Sustain Envelope & Tail... [SUPERATO] (Energy Boost: "
                      << energyBoost << " > Cut: " << energyCut << ")\n";
            testsPassed++;
        } else {
            std::cout << "[!] Test 4: Differential Sustain Envelope & Tail... [FALLITO]\n";
        }
    }

    // --------------------------------------------------------------------------
    // TEST 5: 3-Band Linkwitz-Riley Flat Magnitude Recombination
    // --------------------------------------------------------------------------
    {
        dsp171::LinkwitzRileyCrossover3Band xo;
        xo.prepare(sampleRate);
        xo.setCrossoverFrequencies(140.0f, 2500.0f);

        // Testiamo il passaggio di frequenze chiave (100 Hz, 1000 Hz, 5000 Hz)
        const std::vector<float> freqs = { 80.0f, 140.0f, 400.0f, 1000.0f, 2500.0f, 6000.0f, 12000.0f };
        bool flatRecomb = true;
        float maxErrorDb = 0.0f;

        for (float f : freqs) {
            xo.reset();
            float maxRecomb = 0.0f;
            for (int i = 0; i < 2000; ++i) {
                float in = std::sin(2.0f * 3.14159265f * f * (float(i) / float(sampleRate)));
                float lowL, lowR, midL, midR, highL, highR;
                xo.process(in, in, lowL, lowR, midL, midR, highL, highR);
                float recomb = lowL + midL + highL;
                if (i > 500) { // Steady state
                    maxRecomb = std::max(maxRecomb, std::abs(recomb));
                }
            }
            float errorDb = std::abs(20.0f * std::log10(maxRecomb));
            if (errorDb > maxErrorDb) maxErrorDb = errorDb;
            if (errorDb > 0.40f) flatRecomb = false;
        }

        if (flatRecomb) {
            std::cout << "[*] Test 5: 3-Band Linkwitz-Riley Flat Magnitude... [SUPERATO] (Errore massimo: "
                      << maxErrorDb << " dB <= 0.40 dB)\n";
            testsPassed++;
        } else {
            std::cout << "[!] Test 5: 3-Band Linkwitz-Riley Flat Magnitude... [FALLITO] (Errore: " << maxErrorDb << " dB)\n";
        }
    }

    // --------------------------------------------------------------------------
    // TEST 6: Crossover Cutoff Frequency Selectivity
    // --------------------------------------------------------------------------
    {
        dsp171::LinkwitzRileyCrossover3Band xo;
        xo.prepare(sampleRate);
        xo.setCrossoverFrequencies(150.0f, 2500.0f);

        // Input 50 Hz: deve essere quasi tutto in LowBand, quasi 0 in HighBand
        float maxLow50 = 0.0f, maxHigh50 = 0.0f;
        for (int i = 0; i < 2000; ++i) {
            float in = std::sin(2.0f * 3.14159265f * 50.0f * (float(i) / float(sampleRate)));
            float lowL, lowR, midL, midR, highL, highR;
            xo.process(in, in, lowL, lowR, midL, midR, highL, highR);
            if (i > 500) {
                maxLow50 = std::max(maxLow50, std::abs(lowL));
                maxHigh50 = std::max(maxHigh50, std::abs(highL));
            }
        }

        if (maxLow50 > 0.85f && maxHigh50 < 0.05f) {
            std::cout << "[*] Test 6: Crossover Cutoff Selectivity... [SUPERATO] (Low Band 50Hz: "
                      << maxLow50 << ", High Band leakage: " << maxHigh50 << ")\n";
            testsPassed++;
        } else {
            std::cout << "[!] Test 6: Crossover Cutoff Selectivity... [FALLITO]\n";
        }
    }

    // --------------------------------------------------------------------------
    // TEST 7: Sub-Harmonic Synthesizer Octave Division Accuracy (60 Hz -> 30 Hz)
    // --------------------------------------------------------------------------
    {
        dsp171::SubHarmonicSynthesizer sub;
        sub.prepare(sampleRate);
        sub.setParameters(true, 60.0f, 0.0f, 25.0f); // Sintonizzato su 60 Hz

        // Alimentiamo con un'onda a 60 Hz per 1.5 secondi (72.000 campioni)
        constexpr int totalSamples = 72000;
        constexpr int settleSamples = 24000; // 0.5s di assestamento per filtri ZDF
        std::vector<float> subOuts;
        subOuts.reserve(totalSamples - settleSamples);

        for (int i = 0; i < totalSamples; ++i) {
            float in = 0.8f * std::sin(2.0f * 3.14159265f * 60.0f * (float(i) / float(sampleRate)));
            float outL = 0.0f, outR = 0.0f;
            sub.process(in, in, outL, outR);
            if (i >= settleSamples) subOuts.push_back(outL);
        }

        // Calcoliamo i passaggi per lo zero positivi dell'uscita sub: devono corrispondere a ~30 Hz
        int zeroCrossings = 0;
        for (size_t i = 1; i < subOuts.size(); ++i) {
            if (subOuts[i - 1] < 0.0f && subOuts[i] >= 0.0f) {
                zeroCrossings++;
            }
        }
        float measuredFreq = (static_cast<float>(zeroCrossings) * float(sampleRate)) / float(subOuts.size());

        if (std::abs(measuredFreq - 30.0f) <= 2.5f) {
            std::cout << "[*] Test 7: Sub-Harmonic Octave Division Accuracy... [SUPERATO] (Target: 30 Hz, Misurato: "
                      << measuredFreq << " Hz)\n";
            testsPassed++;
        } else {
            std::cout << "[!] Test 7: Sub-Harmonic Octave Division Accuracy... [FALLITO] (Misurato: " << measuredFreq << " Hz)\n";
        }
    }

    // --------------------------------------------------------------------------
    // TEST 8: Sub-Harmonic Schmitt-Trigger Noise Immunity & DC Blocker
    // --------------------------------------------------------------------------
    {
        dsp171::SubHarmonicSynthesizer sub;
        sub.prepare(sampleRate);
        sub.setParameters(true, 45.0f, 0.0f, 25.0f);

        // Alimentiamo rumore a bassissimo livello (-70 dBFS)
        float maxNoiseOut = 0.0f;
        double sumDC = 0.0;
        juce::Random rng(12345);

        for (int i = 0; i < 10000; ++i) {
            float tinyNoise = (rng.nextFloat() * 2.0f - 1.0f) * 0.0003f;
            float outL = 0.0f, outR = 0.0f;
            sub.process(tinyNoise, tinyNoise, outL, outR);
            maxNoiseOut = std::max(maxNoiseOut, std::abs(outL));
            if (i > 2000) sumDC += outL;
        }

        float dcDrift = static_cast<float>(sumDC / 8000.0);
        if (maxNoiseOut < 0.005f && std::abs(dcDrift) < 1.0e-5f) {
            std::cout << "[*] Test 8: Sub-Harmonic Noise Immunity & DC Blocker... [SUPERATO] (DC drift: "
                      << dcDrift << ", Leakage: " << maxNoiseOut << ")\n";
            testsPassed++;
        } else {
            std::cout << "[!] Test 8: Sub-Harmonic Noise Immunity & DC Blocker... [FALLITO]\n";
        }
    }

    // --------------------------------------------------------------------------
    // TEST 9: Punch ADAA Soft-Clipper (-0.1 dBFS Ceiling Protection)
    // --------------------------------------------------------------------------
    {
        dsp171::PunchADAAClipper clipper;
        clipper.reset();

        constexpr float ceilingLinear = 0.9885531f; // -0.1 dBFS
        float maxOut = 0.0f;

        // Alimentiamo un segnale iper-amplificato (+12 dBFS = 4.0 lineare)
        for (int i = 0; i < 2000; ++i) {
            float in = 4.0f * std::sin(2.0f * 3.14159265f * 1000.0f * (float(i) / float(sampleRate)));
            float out = clipper.processSample(in);
            maxOut = std::max(maxOut, std::abs(out));
        }

        if (maxOut <= ceilingLinear + 0.0005f) {
            std::cout << "[*] Test 9: Punch Soft-Clipper (-0.1 dBFS Ceiling)... [SUPERATO] (Max Out: "
                      << maxOut << " <= " << ceilingLinear << ")\n";
            testsPassed++;
        } else {
            std::cout << "[!] Test 9: Punch Soft-Clipper (-0.1 dBFS Ceiling)... [FALLITO] (Max Out: " << maxOut << ")\n";
        }
    }

    // --------------------------------------------------------------------------
    // TEST 10: 100k Sample Stress Test & Denormal/NaN/Inf Sanity
    // --------------------------------------------------------------------------
    {
        dsp171::PunchCraftEngine engine;
        engine.prepare(sampleRate, 512);
        engine.setParameters(true, 50.0f, 50.0f, 1.5f, 25.0f, 120.0f, 140.0f, 2500.0f,
                             true, 45.0f, 3.0f, 30.0f, true, 100.0f, 0.0f, false);

        juce::AudioBuffer<float> buffer(2, 512);
        juce::Random rng(54321);
        bool hasNanInf = false;

        for (int block = 0; block < 200; ++block) { // 200 * 512 = 102,400 samples
            for (int i = 0; i < 512; ++i) {
                buffer.setSample(0, i, (rng.nextFloat() * 2.0f - 1.0f) * 0.9f);
                buffer.setSample(1, i, (rng.nextFloat() * 2.0f - 1.0f) * 0.9f);
            }
            engine.processBlock(buffer);

            for (int ch = 0; ch < 2; ++ch) {
                for (int i = 0; i < 512; ++i) {
                    float s = buffer.getSample(ch, i);
                    if (std::isnan(s) || std::isinf(s)) hasNanInf = true;
                }
            }
        }

        if (!hasNanInf) {
            std::cout << "[*] Test 10: Stress Test 100k Campioni & Assenza NaN/Inf... [SUPERATO] (102.400 campioni puliti)\n";
            testsPassed++;
        } else {
            std::cout << "[!] Test 10: Stress Test 100k Campioni & Assenza NaN/Inf... [FALLITO]\n";
        }
    }

    std::cout << "\n====================================================================\n";
    std::cout << " ESITO COMPLESSIVO COLLAUDO 171PUNCHCRAFT: " << testsPassed << "/10 SUPERATI\n";
    std::cout << "====================================================================\n";

    return (testsPassed == 10) ? 0 : 1;
}
