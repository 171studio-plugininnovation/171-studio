#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include "GUI/171PunchCraftEditor.h"

class PunchCraftAudioProcessorEditor : public juce::AudioProcessorEditor {
public:
    explicit PunchCraftAudioProcessorEditor(PunchCraftAudioProcessor& p);
    ~PunchCraftAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    PunchCraftAudioProcessor& processorRef;
    dsp171::PunchCraftMainPanel mainPanel;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PunchCraftAudioProcessorEditor)
};
