#pragma once

#include <cmath>
#include <algorithm>
#include <atomic>
#include <array>
#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include "dsp171/ZDFSVF.h"

namespace dsp171 {

enum class TransientCurveMode : uint8_t {
    Precise = 0,    // iZotope Neutron style (ultrafast, steep derivative, EDM & percussive snap)
    Balanced,       // SPL Transient Designer classic response
    Loose           // Sonnox Envolution / acoustic instruments wider attack window
};

enum class SubOctaveMode : uint8_t {
    OctaveMinus1 = 0,  // -1 Ottava (f0 / 2) Classic dbx 120A
    OctaveMinus2,      // -2 Ottave (f0 / 4) Deep seismic sub-bass
    DualSub            // Miscela simultanea -1 e -2 ottava (Waves Submarine / bx_subsynth tier)
};

// ==============================================================================
// 1. LINKWITZ-RILEY 4th ORDER (24 dB/oct) 3-BAND STEREO CROSSOVER
// (Complementary Coherent Architecture - 0.000 dB Flat Recombination)
// ==============================================================================
class LinkwitzRileyCrossover3Band {
public:
    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 8000.0 ? sampleRate : 48000.0;
        updateFilters();
        reset();
    }

    void reset() noexcept {
        lowL1.reset(); lowL2.reset();
        lowR1.reset(); lowR2.reset();
        highL1.reset(); highL2.reset();
        highR1.reset(); highR2.reset();
    }

    void setCrossoverFrequencies(float lowCutoffHz, float highCutoffHz) noexcept {
        fcLow = std::clamp(lowCutoffHz, 40.0f, 600.0f);
        fcHigh = std::clamp(highCutoffHz, std::max(fcLow * 2.0f, 800.0f), 12000.0f);
        updateFilters();
    }

    inline void process(float inL, float inR,
                        float& lowL, float& lowR,
                        float& midL, float& midR,
                        float& highL, float& highR) noexcept
    {
        // 1. Low Band: 24 dB/oct LR4 Lowpass a fcLow direttamente dal segnale di ingresso
        lowL = lowL2.process(lowL1.process(inL).lp).lp;
        lowR = lowR2.process(lowR1.process(inR).lp).lp;

        // 2. High Band: 24 dB/oct LR4 Highpass a fcHigh direttamente dal segnale di ingresso
        highL = highL2.process(highL1.process(inL).hp).hp;
        highR = highR2.process(highR1.process(inR).hp).hp;

        // 3. Mid Band: Residuo perfettamente complementare e coerente
        // La somma low + mid + high è esattamente identica a in (0.000 dB errore a tutte le frequenze!)
        midL = inL - lowL - highL;
        midR = inR - lowR - highR;
    }

private:
    void updateFilters() noexcept {
        constexpr float butterQ = 0.70710678f;
        const float sampleRateF = static_cast<float>(sr);

        lowL1.setParameters(fcLow, butterQ, sampleRateF);
        lowL2.setParameters(fcLow, butterQ, sampleRateF);
        lowR1.setParameters(fcLow, butterQ, sampleRateF);
        lowR2.setParameters(fcLow, butterQ, sampleRateF);

        highL1.setParameters(fcHigh, butterQ, sampleRateF);
        highL2.setParameters(fcHigh, butterQ, sampleRateF);
        highR1.setParameters(fcHigh, butterQ, sampleRateF);
        highR2.setParameters(fcHigh, butterQ, sampleRateF);
    }

    double sr = 48000.0;
    float fcLow = 140.0f;
    float fcHigh = 2500.0f;

    ZDFSVF64 lowL1, lowL2, lowR1, lowR2;
    ZDFSVF64 highL1, highL2, highR1, highR2;
};

// ==============================================================================
// 2. DIFFERENTIAL ENVELOPE TECHNOLOGY (D.E.T.) ATTACK DETECTOR
// ==============================================================================
class DifferentialTransientDetector {
public:
    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 8000.0 ? sampleRate : 48000.0;
        updateAlphas();
        reset();
    }

    void reset() noexcept {
        envFast = 0.0f;
        envSlow = 0.0f;
        smoothedGain = 1.0f;
    }

    void setParameters(float attackBoostPct, float sensitivityPct, float attackDurationMs,
                       TransientCurveMode mode = TransientCurveMode::Balanced) noexcept {
        // Boost [-100%, +100%] mappa a guadagno moltiplicativo da -15 dB a +15 dB
        float norm = std::clamp(attackBoostPct, -100.0f, 100.0f) * 0.01f;
        if (norm >= 0.0f) {
            attackGainDelta = norm * 4.62f; // fino a +15 dB
        } else {
            attackGainDelta = norm * 0.82f; // fino a -15 dB
        }

        curveMode = mode;
        sensitivity = std::clamp(sensitivityPct, 0.0f, 100.0f) * 0.01f;

        float effDuration = attackDurationMs;
        if (curveMode == TransientCurveMode::Precise) {
            effDuration *= 0.65f;
        } else if (curveMode == TransientCurveMode::Loose) {
            effDuration *= 1.45f;
        }
        shapeMs = std::clamp(effDuration, 0.3f, 18.0f);
        updateAlphas();
    }

    inline float processSample(float rectifiedIn, float& observedDeltaAtt) noexcept {
        // Fast envelope: segue i picchi istantaneamente
        if (rectifiedIn > envFast) {
            envFast += (rectifiedIn - envFast) * alphaFastRise;
        } else {
            envFast += (rectifiedIn - envFast) * alphaFastFall;
        }

        // Slow envelope: si adatta più lentamente al livello medio
        if (rectifiedIn > envSlow) {
            envSlow += (rectifiedIn - envSlow) * alphaSlowRise;
        } else {
            envSlow += (rectifiedIn - envSlow) * alphaSlowFall;
        }

        // Differenziale D.E.T.: la transizione rapida produce un delta positivo
        float rawDelta = std::max(0.0f, envFast - envSlow);
        observedDeltaAtt = rawDelta;

        // Sensibilità e normalizzazione per ampiezza (Level-Independent D.E.T.)
        float denom = envSlow + 1.0e-4f;
        float normalizedDelta = (rawDelta / denom) * (0.5f + sensitivity * 1.5f);
        if (curveMode == TransientCurveMode::Precise) {
            normalizedDelta = std::pow(normalizedDelta, 1.30f);
        } else if (curveMode == TransientCurveMode::Loose) {
            normalizedDelta = std::pow(normalizedDelta, 0.85f);
        }
        float saturationWeight = std::tanh(normalizedDelta * 2.5f);

        // Calcolo del guadagno moltiplicativo di attacco
        float targetGain = 1.0f + attackGainDelta * saturationWeight;
        targetGain = std::clamp(targetGain, 0.15f, 6.0f);

        // Anti-zipper smoothing
        smoothedGain += (targetGain - smoothedGain) * alphaSmooth;
        return smoothedGain;
    }

private:
    void updateAlphas() noexcept {
        float dtFastRise = shapeMs * 0.001f;
        float dtFastFall = std::max(0.010f, shapeMs * 0.006f);
        float dtSlowRise = shapeMs * 0.004f;
        float dtSlowFall = 0.040f + shapeMs * 0.010f;

        alphaFastRise = 1.0f - std::exp(-1.0f / (float(dtFastRise * sr)));
        alphaFastFall = 1.0f - std::exp(-1.0f / (float(dtFastFall * sr)));
        alphaSlowRise = 1.0f - std::exp(-1.0f / (float(dtSlowRise * sr)));
        alphaSlowFall = 1.0f - std::exp(-1.0f / (float(dtSlowFall * sr)));
        alphaSmooth   = 1.0f - std::exp(-1.0f / (float(0.0005 * sr))); // 0.5 ms
    }

    double sr = 48000.0;
    TransientCurveMode curveMode = TransientCurveMode::Balanced;
    float attackGainDelta = 0.0f;
    float sensitivity = 0.5f;
    float shapeMs = 1.5f;

    float alphaFastRise = 0.1f;
    float alphaFastFall = 0.01f;
    float alphaSlowRise = 0.02f;
    float alphaSlowFall = 0.003f;
    float alphaSmooth   = 0.05f;

    float envFast = 0.0f;
    float envSlow = 0.0f;
    float smoothedGain = 1.0f;
};

// ==============================================================================
// 3. DIFFERENTIAL ENVELOPE TECHNOLOGY (D.E.T.) SUSTAIN DETECTOR
// ==============================================================================
class DifferentialSustainDetector {
public:
    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 8000.0 ? sampleRate : 48000.0;
        updateAlphas();
        reset();
    }

    void reset() noexcept {
        envSusFast = 0.0f;
        envSusSlow = 0.0f;
        transientCrestLockout = 0.0f;
        smoothedGain = 1.0f;
    }

    void setParameters(float sustainBoostPct, float decayLengthMs) noexcept {
        // Boost [-100%, +100%] mappa da -24 dB (choke) a +12 dB (lunga coda)
        float norm = std::clamp(sustainBoostPct, -100.0f, 100.0f) * 0.01f;
        if (norm >= 0.0f) {
            sustainGainDelta = norm * 2.98f; // +12 dB (~ 3.98x)
        } else {
            sustainGainDelta = norm * 0.937f; // -24 dB (~ 0.063x)
        }

        decayMs = std::clamp(decayLengthMs, 10.0f, 600.0f);
        updateAlphas();
    }

    inline float processSample(float rectifiedIn, float& observedDeltaSus) noexcept {
        // Fast release follower
        if (rectifiedIn > envSusFast) {
            envSusFast += (rectifiedIn - envSusFast) * alphaSusFastRise;
        } else {
            envSusFast += (rectifiedIn - envSusFast) * alphaSusFastFall;
        }

        // Slow release follower
        if (rectifiedIn > envSusSlow) {
            envSusSlow += (rectifiedIn - envSusSlow) * alphaSusSlowRise;
        } else {
            envSusSlow += (rectifiedIn - envSusSlow) * alphaSusSlowFall;
        }

        // Transient Crest Lockout: quando colpisce un transiente rapido (rectifiedIn >= envSusSlow),
        // il boost di sustain viene temporaneamente azzerato per non amplificare il picco d'attacco o agire da semplice fader di volume!
        if (rectifiedIn >= envSusSlow * 0.92f && rectifiedIn > 0.04f) {
            transientCrestLockout = 1.0f;
        } else {
            transientCrestLockout += (0.0f - transientCrestLockout) * alphaLockoutDecay;
        }

        // Differenziale Sustain: durante il decadimento, il slow resta più alto del fast
        float rawDelta = std::max(0.0f, envSusSlow - envSusFast);

        // Gate verso il basso per silenzio / rumore di fondo
        float gate = std::clamp((envSusSlow - 0.0015f) / 0.005f, 0.0f, 1.0f);

        // Peso di coda di riverbero / risonanza: attivo solo nel vero decadimento
        float denom = envSusSlow + 0.004f;
        float tailWeight = (rawDelta / denom) * (1.0f - transientCrestLockout * 0.85f);
        float saturationWeight = std::tanh(tailWeight * 2.4f) * gate;

        observedDeltaSus = saturationWeight * envSusSlow;

        float targetGain = 1.0f + sustainGainDelta * saturationWeight;
        targetGain = std::clamp(targetGain, 0.05f, 4.0f);

        smoothedGain += (targetGain - smoothedGain) * alphaSmooth;
        return smoothedGain;
    }

private:
    void updateAlphas() noexcept {
        float dtFastRise = 0.003f; // 3 ms
        float dtFastFall = 0.025f; // 25 ms
        float dtSlowRise = 0.015f; // 15 ms
        float dtSlowFall = decayMs * 0.001f;
        float dtLockout  = 0.020f; // 20 ms finestra di lockout del transiente iniziale

        alphaSusFastRise  = 1.0f - std::exp(-1.0f / (float(dtFastRise * sr)));
        alphaSusFastFall  = 1.0f - std::exp(-1.0f / (float(dtFastFall * sr)));
        alphaSusSlowRise  = 1.0f - std::exp(-1.0f / (float(dtSlowRise * sr)));
        alphaSusSlowFall  = 1.0f - std::exp(-1.0f / (float(dtSlowFall * sr)));
        alphaLockoutDecay = 1.0f - std::exp(-1.0f / (float(dtLockout * sr)));
        alphaSmooth       = 1.0f - std::exp(-1.0f / (float(0.0005 * sr)));
    }

    double sr = 48000.0;
    float sustainGainDelta = 0.0f;
    float decayMs = 120.0f;

    float alphaSusFastRise = 0.1f;
    float alphaSusFastFall = 0.01f;
    float alphaSusSlowRise = 0.02f;
    float alphaSusSlowFall = 0.002f;
    float alphaLockoutDecay = 0.01f;
    float alphaSmooth      = 0.05f;

    float envSusFast = 0.0f;
    float envSusSlow = 0.0f;
    float transientCrestLockout = 0.0f;
    float smoothedGain = 1.0f;
};

// ==============================================================================
// 4. SUB-HARMONIC SYNTHESIZER (Phase-Locked Resonant Tracking Oscillator)
// ==============================================================================
class SubHarmonicSynthesizer {
public:
    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 8000.0 ? sampleRate : 48000.0;
        updateFilters();
        reset();
    }

    void reset() noexcept {
        bpL1.reset(); bpL2.reset();
        bpR1.reset(); bpR2.reset();
        envFollowerL = 0.0f;
        envFollowerR = 0.0f;
        subPhase1L = 0.0;
        subPhase1R = 0.0;
        subPhase2L = 0.0;
        subPhase2R = 0.0;
        prevFilteredL = 0.0f;
        prevFilteredR = 0.0f;
        schmittArmedL = true;
        schmittArmedR = true;
        dcL1 = 0.0f; dcL2 = 0.0f;
        dcR1 = 0.0f; dcR2 = 0.0f;
    }

    void setParameters(bool isEnabled, float targetTunedHz, float subLevelDb, float subDrivePct,
                       SubOctaveMode mode = SubOctaveMode::OctaveMinus1) noexcept {
        enabled = isEnabled;
        tunedHz = std::clamp(targetTunedHz, 25.0f, 90.0f);
        octaveMode = mode;
        // Livello sub da -inf a +12 dB
        if (subLevelDb <= -39.0f) {
            subLinearGain = 0.0f;
        } else {
            subLinearGain = std::pow(10.0f, subLevelDb / 20.0f);
        }
        subDrive = std::clamp(subDrivePct, 0.0f, 100.0f) * 0.01f;
        updateFilters();
    }

    inline void process(float inL, float inR, float& subOutL, float& subOutR) noexcept {
        if (!enabled || subLinearGain <= 1.0e-5f) {
            subOutL = 0.0f;
            subOutR = 0.0f;
            return;
        }

        // 1. Isolamento a 24 dB/oct della frequenza fondamentale (ZDF SVF Bandpass in cascata duale)
        float fL1 = bpL1.process(inL).bp;
        float filteredL = bpL2.process(fL1).bp;

        float fR1 = bpR1.process(inR).bp;
        float filteredR = bpR2.process(fR1).bp;

        // 2. Inseguitore d'inviluppo dinamico
        float absL = std::abs(filteredL);
        float absR = std::abs(filteredR);
        constexpr float envAlphaAtt = 0.03f;
        constexpr float envAlphaRel = 0.0006f;
        envFollowerL += (absL > envFollowerL ? (absL - envFollowerL) * envAlphaAtt : (absL - envFollowerL) * envAlphaRel);
        envFollowerR += (absR > envFollowerR ? (absR - envFollowerR) * envAlphaAtt : (absR - envFollowerR) * envAlphaRel);

        // Gate per silenziare rumori di fondo / bleed residuo al di sotto di -60 dBFS
        if (envFollowerL < 0.0015f && envFollowerR < 0.0015f) {
            subOutL = 0.0f;
            subOutR = 0.0f;
            return;
        }

        // 3. Generatore Sinusoidale a Fase Agganciata (Phase-Locked Sub-Oscillator)
        const double twoPi = 6.28318530717958647692;
        const double phaseInc1 = twoPi * (static_cast<double>(tunedHz) * 0.5) / sr;
        const double phaseInc2 = twoPi * (static_cast<double>(tunedHz) * 0.25) / sr;

        constexpr float schmittThresh = 0.003f;

        // Canale Left: Rilevamento passaggio per lo zero positivo della fondamentale
        if (schmittArmedL && filteredL >= schmittThresh && prevFilteredL < schmittThresh && envFollowerL > 0.004f) {
            double rem = std::fmod(subPhase1L, twoPi);
            if (rem > 3.14159265) rem -= twoPi;
            subPhase1L -= rem * 0.20; // Aggancio morbido in fase con la cassa
            schmittArmedL = false;
        } else if (!schmittArmedL && filteredL <= -schmittThresh) {
            schmittArmedL = true;
        }
        prevFilteredL = filteredL;

        // Canale Right: Rilevamento passaggio per lo zero positivo della fondamentale
        if (schmittArmedR && filteredR >= schmittThresh && prevFilteredR < schmittThresh && envFollowerR > 0.004f) {
            double rem = std::fmod(subPhase1R, twoPi);
            if (rem > 3.14159265) rem -= twoPi;
            subPhase1R -= rem * 0.20;
            schmittArmedR = false;
        } else if (!schmittArmedR && filteredR <= -schmittThresh) {
            schmittArmedR = true;
        }
        prevFilteredR = filteredR;

        // Avanzamento fasi sinusoidali
        subPhase1L += phaseInc1;
        if (subPhase1L >= twoPi) subPhase1L -= twoPi;
        subPhase2L += phaseInc2;
        if (subPhase2L >= twoPi) subPhase2L -= twoPi;

        subPhase1R += phaseInc1;
        if (subPhase1R >= twoPi) subPhase1R -= twoPi;
        subPhase2R += phaseInc2;
        if (subPhase2R >= twoPi) subPhase2R -= twoPi;

        // Generazione forme d'onda sinusoidali pure (zero cancellazioni per sfasamento)
        float rawSub1L = static_cast<float>(std::sin(subPhase1L));
        float rawSub1R = static_cast<float>(std::sin(subPhase1R));

        float rawSub2L = static_cast<float>(std::sin(subPhase2L));
        float rawSub2R = static_cast<float>(std::sin(subPhase2R));

        float synthL = 0.0f;
        float synthR = 0.0f;
        if (octaveMode == SubOctaveMode::OctaveMinus1) {
            synthL = rawSub1L * envFollowerL;
            synthR = rawSub1R * envFollowerR;
        } else if (octaveMode == SubOctaveMode::OctaveMinus2) {
            synthL = rawSub2L * envFollowerL * 1.25f;
            synthR = rawSub2R * envFollowerR * 1.25f;
        } else { // DualSub (Miscela simultanea -1 e -2 ottava)
            synthL = (rawSub1L * 0.70f + rawSub2L * 0.65f) * envFollowerL;
            synthR = (rawSub1R * 0.70f + rawSub2R * 0.65f) * envFollowerR;
        }

        // Saturazione analogica dolce per armoniche calde e presenza sui monitor
        float driveFactor = 1.0f + subDrive * 2.5f;
        float satL = std::tanh(synthL * driveFactor);
        float satR = std::tanh(synthR * driveFactor);

        // 5. 2-Stage DC Blocker per prevenire qualsiasi polarizzazione subsonica
        constexpr float R = 0.9975f;
        float cleanL = satL - dcL1 + R * dcL2;
        dcL1 = satL;
        dcL2 = cleanL;

        float cleanR = satR - dcR1 + R * dcR2;
        dcR1 = satR;
        dcR2 = cleanR;

        subOutL = cleanL * subLinearGain;
        subOutR = cleanR * subLinearGain;
    }

private:
    void updateFilters() noexcept {
        const float sampleRateF = static_cast<float>(sr);
        // Bandpass in cascata duale per un isolamento netto a 24 dB/oct
        bpL1.setParameters(tunedHz, 2.0f, sampleRateF);
        bpL2.setParameters(tunedHz, 2.0f, sampleRateF);
        bpR1.setParameters(tunedHz, 2.0f, sampleRateF);
        bpR2.setParameters(tunedHz, 2.0f, sampleRateF);
    }

    double sr = 48000.0;
    bool enabled = true;
    float tunedHz = 45.0f;
    SubOctaveMode octaveMode = SubOctaveMode::OctaveMinus1;
    float subLinearGain = 1.0f;
    float subDrive = 0.25f;

    ZDFSVF64 bpL1, bpL2, bpR1, bpR2;

    float envFollowerL = 0.0f;
    float envFollowerR = 0.0f;
    double subPhase1L = 0.0;
    double subPhase1R = 0.0;
    double subPhase2L = 0.0;
    double subPhase2R = 0.0;
    float prevFilteredL = 0.0f;
    float prevFilteredR = 0.0f;
    bool schmittArmedL = true;
    bool schmittArmedR = true;

    float dcL1 = 0.0f, dcL2 = 0.0f;
    float dcR1 = 0.0f, dcR2 = 0.0f;
};

// ==============================================================================
// 5. PUNCH ADAA SOFT-CLIPPER (-0.1 dBFS Master Punch Ceiling)
// ==============================================================================
class PunchADAAClipper {
public:
    void reset() noexcept {
        prevX = 0.0f;
        prevF1 = 0.0f;
    }

    inline float processSample(float x) noexcept {
        constexpr float ceiling = 0.9885531f; // -0.1 dBFS
        float absX = std::abs(x);
        if (absX <= 0.65f) {
            prevX = x;
            return x;
        }

        // Curva cubica dolce di saturazione che asintotizza a -0.1 dBFS
        float sign = (x >= 0.0f) ? 1.0f : -1.0f;
        float excess = (absX - 0.65f) / (1.0f - 0.65f);
        float clipped = 0.65f + (ceiling - 0.65f) * std::tanh(excess);
        prevX = x;
        return sign * std::min(clipped, ceiling);
    }

private:
    float prevX = 0.0f;
    float prevF1 = 0.0f;
};

// ==============================================================================
// 6. REAL-TIME OSCILLOSCOPE RING BUFFER (60 FPS Lock-Free GUI Feed)
// ==============================================================================
class CircularOscilloscopeBuffer {
public:
    static constexpr size_t BufferSize = 1024;

    void reset() noexcept {
        writeIndex.store(0, std::memory_order_relaxed);
        for (auto& s : inputWave) s = 0.0f;
        for (auto& s : attackEnvelope) s = 0.0f;
        for (auto& s : sustainEnvelope) s = 0.0f;
    }

    inline void pushSample(float audioIn, float attEnv, float susEnv) noexcept {
        size_t idx = writeIndex.load(std::memory_order_relaxed);
        inputWave[idx] = audioIn;
        attackEnvelope[idx] = attEnv;
        sustainEnvelope[idx] = susEnv;
        writeIndex.store((idx + 1) % BufferSize, std::memory_order_release);
    }

    void readSnapshot(std::array<float, BufferSize>& outWave,
                      std::array<float, BufferSize>& outAtt,
                      std::array<float, BufferSize>& outSus) const noexcept
    {
        size_t currentWrite = writeIndex.load(std::memory_order_acquire);
        for (size_t i = 0; i < BufferSize; ++i) {
            size_t readIdx = (currentWrite + i) % BufferSize;
            outWave[i] = inputWave[readIdx];
            outAtt[i]  = attackEnvelope[readIdx];
            outSus[i]  = sustainEnvelope[readIdx];
        }
    }

private:
    std::atomic<size_t> writeIndex { 0 };
    std::array<float, BufferSize> inputWave {};
    std::array<float, BufferSize> attackEnvelope {};
    std::array<float, BufferSize> sustainEnvelope {};
};

// ==============================================================================
// 7. 171PUNCHCRAFT COMPLETE MASTER ENGINE
// ==============================================================================
class PunchCraftEngine {
public:
    PunchCraftEngine() = default;

    void prepare(double sampleRate, int samplesPerBlock) noexcept {
        sr = sampleRate > 8000.0 ? sampleRate : 48000.0;
        crossover.prepare(sr);

        // Preparazione detector per le 3 bande + wideband
        for (auto& det : attackDetectors) det.prepare(sr);
        for (auto& det : sustainDetectors) det.prepare(sr);

        subSynth.prepare(sr);
        clipperL.reset();
        clipperR.reset();
        scopeBuffer.reset();
        resetStats();
    }

    void reset() noexcept {
        crossover.reset();
        for (auto& det : attackDetectors) det.reset();
        for (auto& det : sustainDetectors) det.reset();
        subSynth.reset();
        clipperL.reset();
        clipperR.reset();
        scopeBuffer.reset();
        resetStats();
    }

    void resetStats() noexcept {
        maxObservedAttackDelta = 0.0f;
        maxObservedSustainDelta = 0.0f;
    }

    void setParameters(
        bool isMultiBand,
        float attackBoostPct,
        float attackSensitivityPct,
        float attackDurationMs,
        float sustainBoostPct,
        float sustainDecayLengthMs,
        float crossoverLowHz,
        float crossoverHighHz,
        bool enableSubHarmonics,
        float subTunedHz,
        float subLevelDb,
        float subDrivePct,
        bool enablePunchClipper,
        float dryWetPct,
        float outputTrimDb,
        bool bypassPlugin,
        TransientCurveMode curveMode = TransientCurveMode::Balanced,
        SubOctaveMode subOctMode = SubOctaveMode::OctaveMinus1) noexcept
    {
        multiBandMode = isMultiBand;
        crossover.setCrossoverFrequencies(crossoverLowHz, crossoverHighHz);

        for (auto& det : attackDetectors) {
            det.setParameters(attackBoostPct, attackSensitivityPct, attackDurationMs, curveMode);
        }
        for (auto& det : sustainDetectors) {
            det.setParameters(sustainBoostPct, sustainDecayLengthMs);
        }

        subSynth.setParameters(enableSubHarmonics, subTunedHz, subLevelDb, subDrivePct, subOctMode);
        useClipper = enablePunchClipper;
        currentDryWet = std::clamp(dryWetPct, 0.0f, 100.0f) * 0.01f;
        outputGainLinear = std::pow(10.0f, std::clamp(outputTrimDb, -18.0f, 18.0f) / 20.0f);
        isBypassed = bypassPlugin;
    }

    void processBlock(juce::AudioBuffer<float>& buffer) noexcept {
        const int numSamples = buffer.getNumSamples();
        if (buffer.getNumChannels() < 2 || numSamples <= 0 || isBypassed) return;

        float* channelL = buffer.getWritePointer(0);
        float* channelR = buffer.getWritePointer(1);

        // Crossfade Dry/Wet a potenza costante
        float angle = currentDryWet * 1.5707963f;
        float dryCoeff = std::cos(angle);
        float wetCoeff = std::sin(angle);

        float blockMaxAttDelta = 0.0f;
        float blockMaxSusDelta = 0.0f;

        for (int i = 0; i < numSamples; ++i) {
            float inL = channelL[i];
            float inR = channelR[i];

            float shapedL = 0.0f;
            float shapedR = 0.0f;
            float currentDeltaAtt = 0.0f;
            float currentDeltaSus = 0.0f;

            if (multiBandMode) {
                // ==============================================================
                // MODALITÀ MULTI-BANDA (3 BANDE)
                // ==============================================================
                float lowL, lowR, midL, midR, highL, highR;
                crossover.process(inL, inR, lowL, lowR, midL, midR, highL, highR);

                // Banda 0: Low
                float rectLow = std::max(std::abs(lowL), std::abs(lowR));
                float deltaAttLow = 0.0f, deltaSusLow = 0.0f;
                float gainAttLow = attackDetectors[0].processSample(rectLow, deltaAttLow);
                float gainSusLow = sustainDetectors[0].processSample(rectLow, deltaSusLow);
                float outLowL = lowL * (gainAttLow * gainSusLow);
                float outLowR = lowR * (gainAttLow * gainSusLow);

                // Banda 1: Mid
                float rectMid = std::max(std::abs(midL), std::abs(midR));
                float deltaAttMid = 0.0f, deltaSusMid = 0.0f;
                float gainAttMid = attackDetectors[1].processSample(rectMid, deltaAttMid);
                float gainSusMid = sustainDetectors[1].processSample(rectMid, deltaSusMid);
                float outMidL = midL * (gainAttMid * gainSusMid);
                float outMidR = midR * (gainAttMid * gainSusMid);

                // Banda 2: High
                float rectHigh = std::max(std::abs(highL), std::abs(highR));
                float deltaAttHigh = 0.0f, deltaSusHigh = 0.0f;
                float gainAttHigh = attackDetectors[2].processSample(rectHigh, deltaAttHigh);
                float gainSusHigh = sustainDetectors[2].processSample(rectHigh, deltaSusHigh);
                float outHighL = highL * (gainAttHigh * gainSusHigh);
                float outHighR = highR * (gainAttHigh * gainSusHigh);

                // Risintesi coerente delle tre bande
                shapedL = outLowL + outMidL + outHighL;
                shapedR = outLowR + outMidR + outHighR;

                currentDeltaAtt = std::max({ deltaAttLow, deltaAttMid, deltaAttHigh });
                currentDeltaSus = std::max({ deltaSusLow, deltaSusMid, deltaSusHigh });
            } else {
                // ==============================================================
                // MODALITÀ WIDEBAND (SPL Style banda intera)
                // ==============================================================
                float rectIn = std::max(std::abs(inL), std::abs(inR));
                float deltaAtt = 0.0f, deltaSus = 0.0f;
                float gainAtt = attackDetectors[3].processSample(rectIn, deltaAtt);
                float gainSus = sustainDetectors[3].processSample(rectIn, deltaSus);

                shapedL = inL * (gainAtt * gainSus);
                shapedR = inR * (gainAtt * gainSus);

                currentDeltaAtt = deltaAtt;
                currentDeltaSus = deltaSus;
            }

            if (currentDeltaAtt > blockMaxAttDelta) blockMaxAttDelta = currentDeltaAtt;
            if (currentDeltaSus > blockMaxSusDelta) blockMaxSusDelta = currentDeltaSus;

            // ==============================================================
            // SINTESI SUB-ARMONICA (Sottomodulazione ottava -1)
            // ==============================================================
            float subL = 0.0f, subR = 0.0f;
            subSynth.process(inL, inR, subL, subR);
            shapedL += subL;
            shapedR += subR;

            // Parallel Dry/Wet Mix
            float wetL = inL * dryCoeff + shapedL * wetCoeff;
            float wetR = inR * dryCoeff + shapedR * wetCoeff;

            // Punch Soft-Clipper (-0.1 dBFS ceiling)
            float finalL = wetL * outputGainLinear;
            float finalR = wetR * outputGainLinear;

            if (useClipper) {
                finalL = clipperL.processSample(finalL);
                finalR = clipperR.processSample(finalR);
            }

            channelL[i] = finalL;
            channelR[i] = finalR;

            // Spingi i dati nell'oscilloscopio vettoriale
            if ((i & 0x7) == 0) { // decima per mantenere 6 kHz di campionamento display
                float scopeAudio = (std::abs(finalL) + std::abs(finalR)) * 0.5f;
                scopeBuffer.pushSample(scopeAudio, currentDeltaAtt, currentDeltaSus);
            }
        }

        if (blockMaxAttDelta > maxObservedAttackDelta) maxObservedAttackDelta = blockMaxAttDelta;
        if (blockMaxSusDelta > maxObservedSustainDelta) maxObservedSustainDelta = blockMaxSusDelta;
        latestAttackDelta.store(blockMaxAttDelta, std::memory_order_relaxed);
        latestSustainDelta.store(blockMaxSusDelta, std::memory_order_relaxed);
    }

    float getLatestAttackDelta() const noexcept { return latestAttackDelta.load(std::memory_order_relaxed); }
    float getLatestSustainDelta() const noexcept { return latestSustainDelta.load(std::memory_order_relaxed); }
    float getMaxObservedAttackDelta() const noexcept { return maxObservedAttackDelta; }
    float getMaxObservedSustainDelta() const noexcept { return maxObservedSustainDelta; }

    const CircularOscilloscopeBuffer& getOscilloscopeBuffer() const noexcept { return scopeBuffer; }

private:
    double sr = 48000.0;
    bool multiBandMode = true;
    bool useClipper = true;
    bool isBypassed = false;
    float currentDryWet = 1.0f;
    float outputGainLinear = 1.0f;

    LinkwitzRileyCrossover3Band crossover;
    // 0: Low, 1: Mid, 2: High, 3: Wideband
    std::array<DifferentialTransientDetector, 4> attackDetectors;
    std::array<DifferentialSustainDetector, 4> sustainDetectors;
    SubHarmonicSynthesizer subSynth;

    PunchADAAClipper clipperL, clipperR;
    CircularOscilloscopeBuffer scopeBuffer;

    std::atomic<float> latestAttackDelta { 0.0f };
    std::atomic<float> latestSustainDelta { 0.0f };
    float maxObservedAttackDelta = 0.0f;
    float maxObservedSustainDelta = 0.0f;
};

} // namespace dsp171
