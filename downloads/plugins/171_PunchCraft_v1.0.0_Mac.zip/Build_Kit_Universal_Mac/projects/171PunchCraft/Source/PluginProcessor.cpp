#include "PluginProcessor.h"
#include "PluginEditor.h"

PunchCraftAudioProcessor::PunchCraftAudioProcessor()
    : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "Parameters", createParameterLayout())
{
    multiBandParam    = apvts.getRawParameterValue("multiBand");
    attackBoostParam  = apvts.getRawParameterValue("attackBoost");
    attackSensParam   = apvts.getRawParameterValue("attackSens");
    attackShapeParam  = apvts.getRawParameterValue("attackShape");
    curveModeParam    = apvts.getRawParameterValue("curveMode");
    sustainBoostParam = apvts.getRawParameterValue("sustainBoost");
    sustainDecayParam = apvts.getRawParameterValue("sustainDecay");
    crossLowParam     = apvts.getRawParameterValue("crossLow");
    crossHighParam    = apvts.getRawParameterValue("crossHigh");
    subEnableParam    = apvts.getRawParameterValue("subEnable");
    subTunedParam     = apvts.getRawParameterValue("subTuned");
    subOctModeParam   = apvts.getRawParameterValue("subOctMode");
    subLevelParam     = apvts.getRawParameterValue("subLevel");
    subDriveParam     = apvts.getRawParameterValue("subDrive");
    clipperOnParam    = apvts.getRawParameterValue("clipperOn");
    dryWetParam       = apvts.getRawParameterValue("dryWet");
    outTrimParam      = apvts.getRawParameterValue("outTrim");
    bypassParam       = apvts.getRawParameterValue("bypass");
}

PunchCraftAudioProcessor::~PunchCraftAudioProcessor() = default;

juce::AudioProcessorValueTreeState::ParameterLayout PunchCraftAudioProcessor::createParameterLayout() {
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { "multiBand", 1 }, "3-Band Multi Mode", true));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "attackBoost", 1 }, "Attack Boost/Cut",
        juce::NormalisableRange<float>(-100.0f, 100.0f, 0.1f), 25.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "attackSens", 1 }, "Attack Sensitivity",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 50.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "attackShape", 1 }, "Attack Duration",
        juce::NormalisableRange<float>(0.5f, 10.0f, 0.1f, 0.5f), 1.5f));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { "curveMode", 1 }, "Transient Curve Mode",
        juce::StringArray { "Precise (Neutron)", "Balanced (SPL)", "Loose (Envolution)" }, 1));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "sustainBoost", 1 }, "Sustain Boost/Cut",
        juce::NormalisableRange<float>(-100.0f, 100.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "sustainDecay", 1 }, "Sustain Decay Length",
        juce::NormalisableRange<float>(10.0f, 500.0f, 1.0f, 0.5f), 120.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "crossLow", 1 }, "Crossover Low",
        juce::NormalisableRange<float>(40.0f, 400.0f, 1.0f, 0.5f), 140.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "crossHigh", 1 }, "Crossover High",
        juce::NormalisableRange<float>(1000.0f, 8000.0f, 10.0f, 0.5f), 2500.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { "subEnable", 1 }, "Sub-Harmonic Enable", true));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { "subTuned", 1 }, "Sub Tuned Frequency",
        juce::StringArray { "30 Hz", "45 Hz", "60 Hz", "80 Hz" }, 1));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { "subOctMode", 1 }, "Sub-Harmonic Mode",
        juce::StringArray { "-1 Oct (f0/2)", "-2 Oct (f0/4)", "Dual (-1 & -2 Oct)" }, 0));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "subLevel", 1 }, "Sub-Harmonic Level",
        juce::NormalisableRange<float>(-40.0f, 12.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "subDrive", 1 }, "Sub-Harmonic Drive",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 20.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { "clipperOn", 1 }, "Punch ADAA Soft Clipper", true));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "dryWet", 1 }, "Dry/Wet Parallel Mix",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 100.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "outTrim", 1 }, "Output Trim Gain",
        juce::NormalisableRange<float>(-18.0f, 18.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { "bypass", 1 }, "Bypass Plugin", false));

    return { params.begin(), params.end() };
}

void PunchCraftAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock) {
    engine.prepare(sampleRate, samplesPerBlock);
    updateEngineParameters();
}

void PunchCraftAudioProcessor::releaseResources() {
    engine.reset();
}

bool PunchCraftAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const {
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
        && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;

    return true;
}

void PunchCraftAudioProcessor::updateEngineParameters() noexcept {
    bool isMb = multiBandParam != nullptr && multiBandParam->load(std::memory_order_relaxed) > 0.5f;
    float attBoost = attackBoostParam != nullptr ? attackBoostParam->load(std::memory_order_relaxed) : 25.0f;
    float attSens = attackSensParam != nullptr ? attackSensParam->load(std::memory_order_relaxed) : 50.0f;
    float attShape = attackShapeParam != nullptr ? attackShapeParam->load(std::memory_order_relaxed) : 1.5f;
    float susBoost = sustainBoostParam != nullptr ? sustainBoostParam->load(std::memory_order_relaxed) : 0.0f;
    float susDecay = sustainDecayParam != nullptr ? sustainDecayParam->load(std::memory_order_relaxed) : 120.0f;
    float cLow = crossLowParam != nullptr ? crossLowParam->load(std::memory_order_relaxed) : 140.0f;
    float cHigh = crossHighParam != nullptr ? crossHighParam->load(std::memory_order_relaxed) : 2500.0f;

    bool subOn = subEnableParam != nullptr && subEnableParam->load(std::memory_order_relaxed) > 0.5f;
    int subChoice = subTunedParam != nullptr ? static_cast<int>(subTunedParam->load(std::memory_order_relaxed)) : 1;
    float tunedF = 45.0f;
    switch (subChoice) {
        case 0: tunedF = 30.0f; break;
        case 1: tunedF = 45.0f; break;
        case 2: tunedF = 60.0f; break;
        case 3: tunedF = 80.0f; break;
        default: tunedF = 45.0f; break;
    }

    float subLvl = subLevelParam != nullptr ? subLevelParam->load(std::memory_order_relaxed) : 0.0f;
    float subDrv = subDriveParam != nullptr ? subDriveParam->load(std::memory_order_relaxed) : 20.0f;
    bool clipOn = clipperOnParam != nullptr && clipperOnParam->load(std::memory_order_relaxed) > 0.5f;
    float dw = dryWetParam != nullptr ? dryWetParam->load(std::memory_order_relaxed) : 100.0f;
    float trim = outTrimParam != nullptr ? outTrimParam->load(std::memory_order_relaxed) : 0.0f;
    bool byp = bypassParam != nullptr && bypassParam->load(std::memory_order_relaxed) > 0.5f;

    int curveIdx = curveModeParam != nullptr ? static_cast<int>(curveModeParam->load(std::memory_order_relaxed)) : 1;
    auto curveMode = static_cast<dsp171::TransientCurveMode>(std::clamp(curveIdx, 0, 2));

    int subOctIdx = subOctModeParam != nullptr ? static_cast<int>(subOctModeParam->load(std::memory_order_relaxed)) : 0;
    auto subOctMode = static_cast<dsp171::SubOctaveMode>(std::clamp(subOctIdx, 0, 2));

    engine.setParameters(
        isMb, attBoost, attSens, attShape,
        susBoost, susDecay, cLow, cHigh,
        subOn, tunedF, subLvl, subDrv,
        clipOn, dw, trim, byp,
        curveMode, subOctMode);
}

void PunchCraftAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages) {
    juce::ignoreUnused(midiMessages);
    juce::ScopedNoDenormals noDenormals;

    updateEngineParameters();
    engine.processBlock(buffer);
}

juce::AudioProcessorEditor* PunchCraftAudioProcessor::createEditor() {
    return new PunchCraftAudioProcessorEditor(*this);
}

void PunchCraftAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void PunchCraftAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType())) {
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
        updateEngineParameters();
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new PunchCraftAudioProcessor();
}
