﻿====================================================================
 171PUNCHCRAFT v1.0.0 (Win64) - Multi-Band Transient & Sub-Harmonic Sculptor
 171 Studio Innovatio GUI & DSP Suite (Plugin #3 della Trilogia)
====================================================================

CONTENUTO DEL PACCHETTO:
1. VST3/171PunchCraft.vst3
   Copiare la cartella in:
   C:\Program Files\Common Files\VST3\

2. Standalone/171PunchCraft.exe
   Applicazione autonoma a bassissima latenza per tracking e sound design.

CARATTERISTICHE INNOVATIVE:
- Modalita Dual: 3-Band Multi-Band (Crossover Linkwitz-Riley 24 dB/oct ZDF SVF) e Wideband.
- Differential Envelope Technology (D.E.T.) Level-Independent:
  * Attack Boost/Cut (-15 dB a +15 dB) con Attack Duration/Shape (0.5 a 10 ms) e Sensitivity.
  * Sustain Boost/Cut (-24 dB choke a +12 dB bloom) con Decay Length (10 a 500 ms).
- Sub-Harmonic Synthesizer a divisione di frequenza (f0 / 2) con Schmitt-trigger zero-crossing e saturazione analogica (30, 45, 60, 80 Hz).
- Punch ADAA Soft-Clipper (-0.1 dBFS ceiling True Peak).
- Display Oscilloscopio Real-Time 60 FPS con visualizzazione separata di Attack Flux (Ambra) e Sustain Tail (Ciano) e linee crossover interattive.
- Dual LED meters verticali per Attack Delta e Sustain Delta.
- GUI Boutique con chassis in titanio scuro, manopole metalliche zigrinate a 36 denti e Logo Oro 171 Studio ufficiale.
====================================================================
