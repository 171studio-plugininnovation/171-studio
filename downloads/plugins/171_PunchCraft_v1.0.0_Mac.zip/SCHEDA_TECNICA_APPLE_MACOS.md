# 🥊 DOSSIER TECNICO DI TRASPOSIZIONE — 171 PUNCHCRAFT
### Multi-Band Transient Shaper & Sub-Harmonic Sculptor per Apple macOS

**Progetto:** 171 PunchCraft (`v1.0.0`)  
**Architettura:** Universal Binary Fat (`arm64` Apple Silicon M1-M4 + `x86_64` Intel)  
**Deployment Target Minimo:** macOS 11.0 Big Sur  
**Approvato da:** Il Direttore  
**Coordinamento:** `dsp-hire-manager`, `comp-optical-universal` & `apple-macos-engineer`  

---

## 1. SPECIFICHE FORMATI & METADATI APPLE AUDIOUNIT

| Parametro | Valore Configurato | Specifiche per DAW macOS |
|---|---|---|
| **AudioUnit Type** | `kAudioUnitType_Effect` (`'aufx'`) | Inseribile come transient shaper su tracce e bus ritmici in **Logic Pro** |
| **Manufacturer Code** | `'171P'` | Conforme alle specifiche Apple (include almeno una maiuscola) |
| **Plugin Code / Subtype** | `'171K'` | Identificativo univoco a 4 caratteri per scansione AU |
| **Target Formati Mac** | **AU (`.component`)**, **VST3 (`.vst3`)**, **Standalone (`.app`)** | AU per Logic Pro; VST3 per Ableton, Cubase, Studio One, Reaper, FL |
| **Sicurezza Gatekeeper** | Hardened Runtime attivo | Flag `--options runtime` + entitlements JIT e Unsigned Memory |

---

## 2. MODELLAZIONE ALGORITMICA SU APPLE SILICON (M1–M4)

171 PunchCraft introduce un controllo micro-dinamico scientifico su batteria, percussioni e strumenti a corda:

1. **Crossover Linkwitz-Riley LR4 a 3 Vie Coerente**:
   - Pendenza di 24 dB/ottava che garantisce una somma perfetta (Low + Mid + High = 0.000 dB) a fase rigorosamente piatta, senza residui comb-filtering.
2. **Rilevatore Differenziale D.E.T. (Differential Envelope Tracking)**:
   - Modella attacco e sustain indipendentemente dal volume in ingresso.
   - Sustain shaping con gate di silenzio sotto i -48 dBFS per non amplificare il fruscio di fondo.
3. **Sub-Harmonic Synthesizer PLSO (Phase-Locked Sub Oscillator)**:
   - Sintetizzatore a fase bloccata ancorato alla fondamentale del transiente, azzerando jitter e cancellazioni di fase sul sub-basso.
4. **Vettorizzazione SIMD ARM64 NEON**:
   - Elaborazione simultanea dei tre banchi di frequenza con latenza aggiuntiva pari a 0 campioni.

---

## 3. INTERFACCIA RETINA A 60 FPS (BOUTIQUE LUXURY)

- **Oscilloscopio CRT Vettoriale a 60 FPS**: Display balistico che evidenzia la forma d'onda e la sagoma dinamica dei transienti modificati in tempo reale.
- **LED Meter Ladder Multicolore**: Indicatori visivi rapidi per livello di transiente, corpo e sub-generazione.
- **Manopole in Acciaio Satinato con Ghiere Neon**: Oro per il sub, Ambra per l'attacco, Ciano per il sustain e Smeraldo per il master.

---

## 4. COMANDO DI COMPILAZIONE RAPIDA

```bash
# Esegui da terminale Mac:
./scripts/build_171punchcraft_mac.sh

# Validazione Apple auval per Logic Pro:
auval -v aufx 171K 171P
```
