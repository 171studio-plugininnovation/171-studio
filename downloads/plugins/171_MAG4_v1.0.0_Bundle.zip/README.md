# 171 MAG4 - Guida Completa all'Installazione (REAPER JSFX & VST3)

Grazie per aver scaricato **171 MAG4 - Air Equalizer & Analog Saturation Pro** [171 Studio]!

---

## OPZIONE 1: Uso IMMEDIATO in REAPER (Consigliato, Zero Compilazione!)
REAPER include il motore audio nativo **JSFX (Jesusonic FX)** a 64-bit ad altissima efficienza. Non richiede alcuna compilazione né software aggiuntivo!

1. Prendi il file `171_MAG4.jsfx` presente in questo pacchetto.
2. Apri REAPER:
   - Vai nel menu in alto: **Options -> Show REAPER resource path in explorer/finder**.
   - Si aprirà la cartella dati di configurazione di REAPER.
   - Entra nella sottocartella **Effects/**.
   - Incolla qui il file `171_MAG4.jsfx`.
3. In REAPER:
   - Apri la finestra FX su qualsiasi traccia (o premi **F5** per fare il refresh della lista plugin).
   - Cerca **171 MAG4** o **MAG4** nella barra di ricerca.
   - Inseriscilo! Avrai il DSP a 64-bit minimale di fase con l'AIR BAND® fino a 40 kHz e il Drive a saturazione armonica immediatamente operativo!

---

## OPZIONE 2: Compilazione VST3 per FL Studio, Ableton Live, Cubase, Studio One, REAPER

Nella cartella `VST3_Source/` trovi il codice sorgente C++20 standard JUCE 7:

### Su Windows (10 / 11):
1. Installa [CMake](https://cmake.org/download/) e **Visual Studio 2022** (con carico di lavoro "Sviluppo di applicazioni desktop con C++").
2. Apri la cartella `VST3_Source` ed esegui con doppio clic:
   `build_vst3_windows.bat`
3. Al termine troverai il file compilato in:
   `build/MaagEQ4_AirSaturation_artefacts/Release/VST3/171_MAG4.vst3`
4. Copialo nella directory standard dei plugin VST3:
   `C:\Program Files\Common Files\VST3\`
5. Riavvia la tua DAW ed esegui una scansione dei nuovi plugin VST3.

### Su macOS (Apple Silicon M1/M2/M3 & Intel):
1. Apri il Terminale nella cartella `VST3_Source`.
2. Esegui:
   `chmod +x build_vst3_mac.sh && ./build_vst3_mac.sh`
3. Copia il file `171_MAG4.vst3` in:
   `~/Library/Audio/Plug-Ins/VST3/`

---

## Specifiche del Plugin 171 MAG4:
- **Banda 1 (SUB / 40Hz)**: Bell largo Q=0.45 (-5 a +15 dB) o Shelf 10Hz risonante.
- **Banda 2 (160 Hz)**: Bell musicale Q=0.55 per il calore e il corpo di kick, rullante, voce e basso.
- **Banda 3 (MID-HIGH)**: Switchabile tra 650 Hz e 2.5 kHz (Q=0.65).
- **Banda 4 (AIR BAND®)**: 2.5k, 5k, 10k, 15k, 20k, 40k Hz con boost-only ultra-ampio fino a +20 dB.
- **Saturazione Indipendente**: Drive 0-100%, 3 circuiti (Class-A Discrete 2ª armonica, Iron Transformer 3ª armonica, Tube Air Silk), Pre/Post EQ routing, Bass Flux e Harmonic Bias.
- **Phase Correlation**: Monitoraggio stereo in tempo reale dell'integrità di fase da -1 a +1.
