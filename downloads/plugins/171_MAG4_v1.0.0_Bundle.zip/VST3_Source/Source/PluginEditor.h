// =====================================================================
// 171 MAG4 AIR & ANALOG SATURATION PRO - VST3
// PluginEditor.h - Hardware GUI
// =====================================================================
#pragma once

#include "PluginProcessor.h"

class MaagEQ4AudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit MaagEQ4AudioProcessorEditor(MaagEQ4AudioProcessor&);
    ~MaagEQ4AudioProcessorEditor() override = default;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    MaagEQ4AudioProcessor& audioProcessor;

    // Sliders & Knobs
    juce::Slider inputGainSlider, outputGainSlider;
    juce::Slider subGainSlider, mid160GainSlider, midHighGainSlider, airGainSlider;
    juce::Slider driveSlider, biasSlider;
    juce::ComboBox airFreqBox, subModeBox, midHighFreqBox, satModeBox, satRouteBox;
    juce::ToggleButton bypassButton, phaseButton, autoGainButton;

    // Attachments
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboBoxAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;

    std::unique_ptr<SliderAttachment> inAtt, outAtt, subAtt, m160Att, mHighAtt, airAtt, driveAtt, biasAtt;
    std::unique_ptr<ComboBoxAttachment> airFreqAtt, subModeAtt, mHighFreqAtt, satModeAtt, satRouteAtt;
    std::unique_ptr<ButtonAttachment> bypassAtt, phaseAtt;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MaagEQ4AudioProcessorEditor)
};
