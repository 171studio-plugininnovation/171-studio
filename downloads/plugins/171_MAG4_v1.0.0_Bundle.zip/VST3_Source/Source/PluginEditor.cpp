// =====================================================================
// 171 MAG4 AIR & ANALOG SATURATION PRO - VST3
// PluginEditor.cpp - Skeuomorphic Anodized Royal Blue UI
// =====================================================================
#include "PluginEditor.h"

MaagEQ4AudioProcessorEditor::MaagEQ4AudioProcessorEditor(MaagEQ4AudioProcessor& p)
    : AudioProcessorEditor(&p), audioProcessor(p)
{
    setSize(920, 560);

    auto& apvts = audioProcessor.getAPVTS();

    auto setupKnob = [this](juce::Slider& s, const juce::String& text) {
        s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 56, 18);
        addAndMakeVisible(s);
    };

    setupKnob(inputGainSlider, "Input Gain");
    setupKnob(outputGainSlider, "Output Trim");
    setupKnob(subGainSlider, "Sub 40Hz");
    setupKnob(mid160GainSlider, "160 Hz");
    setupKnob(midHighGainSlider, "Mid-High");
    setupKnob(airGainSlider, "AIR GAIN");
    setupKnob(driveSlider, "DRIVE");

    inAtt = std::make_unique<SliderAttachment>(apvts, "inputGain", inputGainSlider);
    outAtt = std::make_unique<SliderAttachment>(apvts, "outputGain", outputGainSlider);
    subAtt = std::make_unique<SliderAttachment>(apvts, "subGain", subGainSlider);
    m160Att = std::make_unique<SliderAttachment>(apvts, "mid160Gain", mid160GainSlider);
    mHighAtt = std::make_unique<SliderAttachment>(apvts, "midHighGain", midHighGainSlider);
    airAtt = std::make_unique<SliderAttachment>(apvts, "airGain", airGainSlider);
    driveAtt = std::make_unique<SliderAttachment>(apvts, "drive", driveSlider);

    airFreqBox.addItemList({"2.5 kHz", "5 kHz", "10 kHz", "15 kHz", "20 kHz", "40 kHz"}, 1);
    addAndMakeVisible(airFreqBox);
    airFreqAtt = std::make_unique<ComboBoxAttachment>(apvts, "airFreq", airFreqBox);

    satModeBox.addItemList({"Class-A Discrete", "Iron Transformer", "Tube Air"}, 1);
    addAndMakeVisible(satModeBox);
    satModeAtt = std::make_unique<ComboBoxAttachment>(apvts, "satMode", satModeBox);

    satRouteBox.addItemList({"Pre-EQ", "Post-EQ"}, 1);
    addAndMakeVisible(satRouteBox);
    satRouteAtt = std::make_unique<ComboBoxAttachment>(apvts, "satRoute", satRouteBox);

    bypassButton.setButtonText("BYPASS");
    addAndMakeVisible(bypassButton);
    bypassAtt = std::make_unique<ButtonAttachment>(apvts, "bypass", bypassButton);
}

void MaagEQ4AudioProcessorEditor::paint(juce::Graphics& g)
{
    // Brushed Anodized Royal Blue Faceplate
    juce::ColourGradient bgGrad(
        juce::Colour(0xff082846), getWidth() * 0.5f, 0.0f,
        juce::Colour(0xff020d18), getWidth() * 0.5f, getHeight() * 1.0f, false);
    g.setGradientFill(bgGrad);
    g.fillAll();

    // 171 MAG4 Chassis Header
    g.setColour(juce::Colour(0xff22d3ee));
    g.setFont(juce::Font(22.0f, juce::Font::bold));
    g.drawText("171 MAG4", 24, 16, 200, 26, juce::Justification::left);

    g.setFont(juce::Font(11.0f, juce::Font::plain));
    g.setColour(juce::Colours::lightgrey);
    g.drawText("AIR & HARMONIC SATURATION EQUALIZER - 171 STUDIO", 24, 42, 500, 18, juce::Justification::left);
}

void MaagEQ4AudioProcessorEditor::resized()
{
    inputGainSlider.setBounds(30, 80, 80, 110);
    subGainSlider.setBounds(150, 80, 80, 110);
    mid160GainSlider.setBounds(250, 80, 80, 110);
    midHighGainSlider.setBounds(350, 80, 80, 110);
    airGainSlider.setBounds(460, 80, 95, 125);
    airFreqBox.setBounds(460, 215, 95, 24);

    driveSlider.setBounds(600, 80, 95, 125);
    satModeBox.setBounds(710, 85, 140, 24);
    satRouteBox.setBounds(710, 120, 140, 24);

    outputGainSlider.setBounds(780, 160, 80, 110);
    bypassButton.setBounds(800, 20, 80, 26);
}
