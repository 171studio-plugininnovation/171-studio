// =====================================================================
// MÄAG EQ4 AIR & ANALOG SATURATION PRO - VST3 / CLAP / AU
// PluginProcessor.cpp - Real-time DSP Implementation
// =====================================================================
#include "PluginProcessor.h"
#include <cmath>

MaagEQ4AudioProcessor::MaagEQ4AudioProcessor()
    : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "Parameters", createParameterLayout())
{
}

juce::AudioProcessorValueTreeState::ParameterLayout MaagEQ4AudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back(std::make_unique<juce::AudioParameterFloat>("inputGain", "Input Gain", -18.0f, 18.0f, 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("subGain", "Sub Gain", -5.0f, 15.0f, 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterChoice>("subMode", "Sub Mode", juce::StringArray{"40 Hz", "10 Hz"}, 0));

    params.push_back(std::make_unique<juce::AudioParameterFloat>("mid160Gain", "160 Hz Gain", -5.0f, 15.0f, 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("midHighGain", "Mid-High Gain", -5.0f, 15.0f, 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterChoice>("midHighFreq", "Mid-High Freq", juce::StringArray{"650 Hz", "2.5 kHz"}, 0));

    params.push_back(std::make_unique<juce::AudioParameterFloat>("airGain", "Air Band Gain", 0.0f, 20.0f, 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterChoice>("airFreq", "Air Band Freq",
        juce::StringArray{"2.5 kHz", "5 kHz", "10 kHz", "15 kHz", "20 kHz", "40 kHz"}, 4));

    params.push_back(std::make_unique<juce::AudioParameterFloat>("drive", "Saturation Drive", 0.0f, 100.0f, 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterChoice>("satMode", "Saturation Circuit",
        juce::StringArray{"Class-A Discrete", "Iron Transformer", "Tube Air"}, 0));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("satBias", "Harmonic Bias", -100.0f, 100.0f, 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterChoice>("satRoute", "Saturation Route",
        juce::StringArray{"Pre-EQ", "Post-EQ"}, 1));

    params.push_back(std::make_unique<juce::AudioParameterFloat>("outputGain", "Output Trim", -18.0f, 18.0f, 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterBool>("bypass", "Bypass", false));
    params.push_back(std::make_unique<juce::AudioParameterBool>("phaseInvert", "Phase Invert", false));

    return { params.begin(), params.end() };
}

void MaagEQ4AudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    juce::dsp::ProcessSpec spec;
    spec.sampleRate = sampleRate;
    spec.maximumBlockSize = samplesPerBlock;
    spec.numChannels = 2;

    for (int ch = 0; ch < 2; ++ch) {
        subFilter[ch].reset();
        mid160Filter[ch].reset();
        midHighFilter[ch].reset();
        airFilter[ch].reset();
    }

    updateFilterCoefficients(sampleRate);
}

void MaagEQ4AudioProcessor::releaseResources() {}

void MaagEQ4AudioProcessor::updateFilterCoefficients(double sampleRate)
{
    float subG = *apvts.getRawParameterValue("subGain");
    int subM = static_cast<int>(*apvts.getRawParameterValue("subMode"));

    // Sub: 40Hz Bell (Q=0.45) or 10Hz Low Shelf
    if (subM == 0) {
        auto c = FilterCoefs::makePeakFilter(sampleRate, 40.0f, 0.45f, juce::Decibels::decibelsToGain(subG));
        for (int ch = 0; ch < 2; ++ch) subFilter[ch].coefficients = c;
    } else {
        auto c = FilterCoefs::makeLowShelf(sampleRate, 18.0f, 0.42f, juce::Decibels::decibelsToGain(subG));
        for (int ch = 0; ch < 2; ++ch) subFilter[ch].coefficients = c;
    }

    // Band 2: 160Hz Bell (Q=0.55)
    float g160 = *apvts.getRawParameterValue("mid160Gain");
    auto c160 = FilterCoefs::makePeakFilter(sampleRate, 160.0f, 0.55f, juce::Decibels::decibelsToGain(g160));
    for (int ch = 0; ch < 2; ++ch) mid160Filter[ch].coefficients = c160;

    // Band 3: 650Hz / 2.5kHz Bell (Q=0.65)
    float gMid = *apvts.getRawParameterValue("midHighGain");
    float fMid = (*apvts.getRawParameterValue("midHighFreq") == 0) ? 650.0f : 2500.0f;
    auto cMid = FilterCoefs::makePeakFilter(sampleRate, fMid, 0.65f, juce::Decibels::decibelsToGain(gMid));
    for (int ch = 0; ch < 2; ++ch) midHighFilter[ch].coefficients = cMid;

    // Band 4: AIR BAND® High Shelf
    float gAir = *apvts.getRawParameterValue("airGain");
    int airSel = static_cast<int>(*apvts.getRawParameterValue("airFreq"));
    float rawF = 20000.0f;
    if (airSel == 0) rawF = 2500.0f;
    else if (airSel == 1) rawF = 5000.0f;
    else if (airSel == 2) rawF = 10000.0f;
    else if (airSel == 3) rawF = 15000.0f;
    else if (airSel == 4) rawF = 20000.0f;
    else rawF = 40000.0f;

    float nyq = static_cast<float>(sampleRate * 0.5);
    float effF = rawF;
    float effG = gAir;
    if (rawF >= 38000.0f) {
        effF = nyq * 0.72f;
        effG = gAir * 0.48f;
    } else if (rawF >= 19000.0f) {
        effF = nyq * 0.62f;
        effG = gAir * 0.75f;
    } else {
        effF = std::min(rawF, nyq * 0.95f);
    }
    auto cAir = FilterCoefs::makeHighShelf(sampleRate, effF, 0.45f, juce::Decibels::decibelsToGain(effG));
    for (int ch = 0; ch < 2; ++ch) airFilter[ch].coefficients = cAir;
}

void MaagEQ4AudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    if (*apvts.getRawParameterValue("bypass")) return;

    updateFilterCoefficients(getSampleRate());

    float inGainLinear = juce::Decibels::decibelsToGain(*apvts.getRawParameterValue("inputGain"));
    float outGainLinear = juce::Decibels::decibelsToGain(*apvts.getRawParameterValue("outputGain"));
    if (*apvts.getRawParameterValue("phaseInvert")) outGainLinear *= -1.0f;

    float drive = *apvts.getRawParameterValue("drive");
    int satMode = static_cast<int>(*apvts.getRawParameterValue("satMode"));
    int satRoute = static_cast<int>(*apvts.getRawParameterValue("satRoute"));
    float satBias = *apvts.getRawParameterValue("satBias") / 100.0f;

    float k = 1.0f + (drive / 100.0f) * 8.5f;
    float evenWeight = (satMode == 0) ? (0.18f * (1.0f - satBias * 0.5f)) : (0.08f * (1.0f - satBias * 0.8f));
    float oddWeight = (satMode == 1) ? (0.75f * (1.0f + satBias * 0.5f)) : (0.50f * (1.0f + satBias * 0.5f));

    auto applySaturation = [&](float x) -> float {
        float cx = std::max(-1.0f, std::min(1.0f, x));
        if (drive <= 0.001f) return cx;

        if (satMode == 0) {
            // Class-A Discrete: Tanh + Asymmetric 2nd harmonic
            return (std::tanh(k * cx) / std::tanh(k)) + evenWeight * (drive / 100.0f) * (cx * cx - 0.25f * std::abs(cx));
        } else if (satMode == 1) {
            // Transformer Iron: Core hysteresis saturation + 3rd harmonic
            float d = k * cx;
            return (d / std::pow(1.0f + std::pow(std::abs(d) * oddWeight, 2.2f), 1.0f / 2.2f)) + 0.04f * (drive / 100.0f) * (cx * cx);
        } else {
            // Tube Air: Exponential silk
            float sign = cx < 0 ? -1.0f : 1.0f;
            return sign * (1.0f - std::exp(-k * std::abs(cx))) / (1.0f - std::exp(-k));
        }
    };

    const int numChannels = buffer.getNumChannels();
    const int numSamples = buffer.getNumSamples();

    for (int ch = 0; ch < std::min(2, numChannels); ++ch)
    {
        float* channelData = buffer.getWritePointer(ch);

        for (int i = 0; i < numSamples; ++i)
        {
            float s = channelData[i] * inGainLinear;

            if (satRoute == 0 && drive > 0.0f) s = applySaturation(s);

            s = subFilter[ch].processSample(s);
            s = mid160Filter[ch].processSample(s);
            s = midHighFilter[ch].processSample(s);
            s = airFilter[ch].processSample(s);

            if (satRoute == 1 && drive > 0.0f) s = applySaturation(s);

            channelData[i] = s * outGainLinear;
        }
    }
}

void MaagEQ4AudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void MaagEQ4AudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState.get() != nullptr && xmlState->hasTagName(apvts.state.getType()))
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
}
