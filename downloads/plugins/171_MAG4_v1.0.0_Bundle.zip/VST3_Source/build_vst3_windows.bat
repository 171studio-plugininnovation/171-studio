@echo off
echo ===================================================
echo Compilazione VST3 per 171 MAG4 Air ^& Saturation
echo ===================================================
echo Assicurati di avere CMake e Visual Studio 2022 installati.

if not exist build mkdir build
cd build

cmake .. -G "Visual Studio 17 2022" -A x64
if %errorlevel% neq 0 (
    echo Errore durante la generazione dei file di progetto CMake!
    pause
    exit /b %errorlevel%
)

cmake --build . --config Release --target MaagEQ4_AirSaturation_VST3
if %errorlevel% neq 0 (
    echo Errore durante la compilazione del plugin VST3!
    pause
    exit /b %errorlevel%
)

echo.
echo ===================================================
echo Compilazione completata con successo!
echo Il plugin VST3 e disponibile in:
echo build/MaagEQ4_AirSaturation_artefacts/Release/VST3/171_MAG4.vst3
echo.
echo Copialo in:
echo C:\Program Files\Common Files\VST3\
echo ===================================================
pause
