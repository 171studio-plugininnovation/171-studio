#!/bin/bash
echo "==================================================="
echo "Compilazione VST3 / AU per 171 MAG4 su macOS"
echo "==================================================="

mkdir -p build && cd build
cmake .. -G Xcode
cmake --build . --config Release

echo "Compilazione completata! Copia il file in:"
echo "~/Library/Audio/Plug-Ins/VST3/"
