#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include <dsp171/PerfectClipEngine.h>

class PerfectClipAudioProcessor : public juce::AudioProcessor {
public:
    PerfectClipAudioProcessor();
    ~PerfectClipAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "171PerfectClip"; }

    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int index) override { juce::ignoreUnused(index); }
    const juce::String getProgramName(int index) override { juce::ignoreUnused(index); return {}; }
    void changeProgramName(int index, const juce::String& newName) override { juce::ignoreUnused(index, newName); }

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }
    dsp171::PerfectClipEngine& getEngine() noexcept { return engine; }

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    void updateEngineParameters() noexcept;

    juce::AudioProcessorValueTreeState apvts;
    dsp171::PerfectClipEngine engine;

    // Fast atomic cache pointers for real-time DSP
    std::atomic<float>* inGainParam = nullptr;
    std::atomic<float>* ceilingParam = nullptr;
    std::atomic<float>* outGainParam = nullptr;
    std::atomic<float>* clipModeParam = nullptr;
    std::atomic<float>* softKneeParam = nullptr;
    std::atomic<float>* transDetailParam = nullptr;
    std::atomic<float>* alchemyAirParam = nullptr;
    std::atomic<float>* routingParam = nullptr;
    std::atomic<float>* monoMakerParam = nullptr;
    std::atomic<float>* monoMakerFreqParam = nullptr;
    std::atomic<float>* truePeakParam = nullptr;
    std::atomic<float>* deltaAuditionParam = nullptr;
    std::atomic<float>* bypassParam = nullptr;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PerfectClipAudioProcessor)
};
