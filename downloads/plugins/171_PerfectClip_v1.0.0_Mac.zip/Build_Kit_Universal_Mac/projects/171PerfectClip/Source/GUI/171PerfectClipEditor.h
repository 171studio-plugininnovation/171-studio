#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <BinaryData.h>
#include "PerfectClipCRTScope.h"
#include "ResizableHandleComponent.h"
#include "../PluginProcessor.h"

namespace PerfectClipBinaryData = BinaryData;

namespace dsp171 {

// ==============================================================================
// BOUTIQUE LOOK AND FEEL FOR 171PERFECTCLIP
// ==============================================================================
class PerfectClipBoutiqueLookAndFeel : public juce::LookAndFeel_V4 {
public:
    PerfectClipBoutiqueLookAndFeel() {
        setColour(juce::Slider::textBoxTextColourId, juce::Colour(0xFFFFD54F)); // Gold text
        setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xFF161A22));
        setColour(juce::ComboBox::textColourId, juce::Colour(0xFFFFD54F));
        setColour(juce::ComboBox::outlineColourId, juce::Colour(0xFF303846));
        setColour(juce::TooltipWindow::backgroundColourId, juce::Colour(0xFF141820));
        setColour(juce::TooltipWindow::textColourId, juce::Colour(0xFFECEFF1));
        setColour(juce::TooltipWindow::outlineColourId, juce::Colour(0xFFFFD54F));
    }

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPosProportional, float rotaryStartAngle,
                          float rotaryEndAngle, juce::Slider& slider) override
    {
        const float radius = static_cast<float>(std::min(width, height)) * 0.5f - 4.0f;
        const float centreX = static_cast<float>(x) + static_cast<float>(width) * 0.5f;
        const float centreY = static_cast<float>(y) + static_cast<float>(height) * 0.5f;
        const float currentAngle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

        // Accent color based on role
        juce::Colour accentCol(0xFFFF9100); // Amber (Drive / Clipping)
        if (slider.getName().containsIgnoreCase("ceiling") || slider.getName().containsIgnoreCase("thresh")) {
            accentCol = juce::Colour(0xFFFF5252); // Red/Coral (Ceiling)
        } else if (slider.getName().containsIgnoreCase("detail") || slider.getName().containsIgnoreCase("trans")) {
            accentCol = juce::Colour(0xFF00E5FF); // Electric Cyan (Detail Preservation)
        } else if (slider.getName().containsIgnoreCase("air") || slider.getName().containsIgnoreCase("alchemy")) {
            accentCol = juce::Colour(0xFF69F0AE); // Emerald Sheen (Alchemy Air)
        } else if (slider.getName().containsIgnoreCase("out") || slider.getName().containsIgnoreCase("trim")) {
            accentCol = juce::Colour(0xFFFFD54F); // Warm Gold (Master)
        }

        // 1. Drop shadow behind dial
        g.setColour(juce::Colour(0x70000000));
        g.fillEllipse(centreX - radius + 1.0f, centreY - radius + 3.0f, radius * 2.0f, radius * 2.0f);

        // 2. Glowing indicator arc on dial bezel
        juce::Path arcPath;
        arcPath.addCentredArc(centreX, centreY, radius + 2.0f, radius + 2.0f, 0.0f, rotaryStartAngle, currentAngle, true);
        g.setColour(accentCol.withAlpha(0.20f));
        g.strokePath(arcPath, juce::PathStrokeType(4.0f));
        g.setColour(accentCol);
        g.strokePath(arcPath, juce::PathStrokeType(1.8f));

        // 3. Render dial bitmap if available in BinaryData, or procedural PBR metal
        auto knobImg = juce::ImageCache::getFromMemory(PerfectClipBinaryData::knob_171_steel_satin_128_png,
                                                       PerfectClipBinaryData::knob_171_steel_satin_128_pngSize);
        if (knobImg.isValid()) {
            float knobDiam = radius * 2.0f;
            float imgW = static_cast<float>(knobImg.getWidth());
            float imgH = static_cast<float>(knobImg.getHeight());
            auto transform = juce::AffineTransform::rotation(currentAngle, imgW * 0.5f, imgH * 0.5f)
                .translated(centreX - imgW * 0.5f, centreY - imgH * 0.5f)
                .scaled(knobDiam / imgW, knobDiam / imgH, centreX, centreY);
            g.drawImageTransformed(knobImg, transform);
        } else {
            // Procedural brushed dark titanium disc
            juce::ColourGradient dialGrad(juce::Colour(0xFF282E38), centreX, centreY - radius,
                                          juce::Colour(0xFF14171E), centreX, centreY + radius, false);
            g.setGradientFill(dialGrad);
            g.fillEllipse(centreX - radius + 2.0f, centreY - radius + 2.0f, (radius - 2.0f) * 2.0f, (radius - 2.0f) * 2.0f);
            g.setColour(juce::Colour(0xFF3A4452));
            g.drawEllipse(centreX - radius + 2.0f, centreY - radius + 2.0f, (radius - 2.0f) * 2.0f, (radius - 2.0f) * 2.0f, 1.2f);
        }

        // 4. Laser indicator notch
        const float notchInnerR = radius * 0.35f;
        const float notchOuterR = radius * 0.88f;
        float nx1 = centreX + std::sin(currentAngle) * notchInnerR;
        float ny1 = centreY - std::cos(currentAngle) * notchInnerR;
        float nx2 = centreX + std::sin(currentAngle) * notchOuterR;
        float ny2 = centreY - std::cos(currentAngle) * notchOuterR;

        g.setColour(juce::Colour(0x90000000));
        g.drawLine(nx1 + 1.0f, ny1 + 1.0f, nx2 + 1.0f, ny2 + 1.0f, 3.0f);
        g.setColour(accentCol);
        g.drawLine(nx1, ny1, nx2, ny2, 2.0f);
    }
};

// ==============================================================================
// 171PERFECTCLIP MAIN EDITOR
// ==============================================================================
class PerfectClipEditor : public juce::AudioProcessorEditor,
                          private juce::Timer
{
public:
    struct HelpItem {
        juce::String title;
        juce::String value;
        juce::String description;
        juce::String recommendation;
    };

    PerfectClipEditor(PerfectClipAudioProcessor& p)
        : AudioProcessorEditor(&p), audioProcessor(p),
          crtScope(audioProcessor.getEngine())
    {
        setLookAndFeel(&lookAndFeel);

        // Load 171 Studio Gold Logo
        goldLogoImage = juce::ImageCache::getFromMemory(PerfectClipBinaryData::logo_171_gold_png,
                                                        PerfectClipBinaryData::logo_171_gold_pngSize);

        // Configure CRT Scope
        addAndMakeVisible(crtScope);
        crtScope.addMouseListener(this, true);

        // 1. Controls: Drive
        setupRotarySlider(driveSlider, driveLabel, "Drive", " DRIVE", "-24", "+24 dB");
        driveSlider.setTooltip("Master Input Drive into the clipping core. Clean mastering gain up to +24 dB.");
        driveSlider.addMouseListener(this, true);
        driveAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            audioProcessor.getAPVTS(), "inGain", driveSlider);

        // 2. Controls: Ceiling
        setupRotarySlider(ceilingSlider, ceilingLabel, "Ceiling", " CEILING", "-24", "0 dBFS");
        ceilingSlider.setTooltip("Master Safety Ceiling. Bit-exact peak threshold with zero overshoot.");
        ceilingSlider.addMouseListener(this, true);
        ceilingAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            audioProcessor.getAPVTS(), "ceiling", ceilingSlider);

        // 3. Controls: Soft Knee
        setupRotarySlider(kneeSlider, kneeLabel, "Knee", " SOFT KNEE", "Hard", "100%");
        kneeSlider.setTooltip("Continuously variable transition from brickwall hard clip (0%) to smooth C2 analog knee (100%).");
        kneeSlider.addMouseListener(this, true);
        kneeAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            audioProcessor.getAPVTS(), "softKnee", kneeSlider);

        // 4. Controls: TransDetail Preservation
        setupRotarySlider(detailSlider, detailLabel, "Detail", " TRANSDETAIL", "0%", "100%");
        detailSlider.setTooltip("171 TransDetail™ Matrix: Orthogonal high-frequency transient protection preventing IMD against heavy bass.");
        detailSlider.addMouseListener(this, true);
        detailAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            audioProcessor.getAPVTS(), "transDetail", detailSlider);

        // 5. Controls: Alchemy Air
        setupRotarySlider(alchemySlider, alchemyLabel, "Air", " ALCHEMY AIR", "-6", "+6 dB");
        alchemySlider.setTooltip("Active zero-delay HF contouring shelf (~10 kHz). Injects silky sparkle into preserved transients.");
        alchemySlider.addMouseListener(this, true);
        alchemyAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            audioProcessor.getAPVTS(), "alchemyAir", alchemySlider);

        // 6. Controls: Output Trim
        setupRotarySlider(outTrimSlider, outTrimLabel, "Out Trim", " OUTPUT TRIM", "-24", "+24 dB");
        outTrimSlider.setTooltip("Master clean output makeup gain with True-Peak safety protection.");
        outTrimSlider.addMouseListener(this, true);
        outTrimAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            audioProcessor.getAPVTS(), "outGain", outTrimSlider);

        // 7. Controls: Topology Selector & Dedicated Gold 122 Hardware Switch
        topologyBox.addItem("Digital Hard (ADAA-2)", 1);
        topologyBox.addItem("Gold ADC 122 Mojo", 2);
        topologyBox.addItem("Tube Triode Class-A", 3);
        topologyBox.addItem("Germanium Diode", 4);
        topologyBox.setSelectedId(1, juce::dontSendNotification);
        topologyBox.setTooltip("Clipper Topology: Digital Hard, Gold ADC 122, Tube Triode, or Germanium Diode.");
        topologyBox.addMouseListener(this, true);
        addAndMakeVisible(topologyBox);
        topologyAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(
            audioProcessor.getAPVTS(), "clipMode", topologyBox);

        setupButton(gold122Btn, "✦ GOLD 122 ADC ✦", false);
        gold122Btn.setColour(juce::ToggleButton::textColourId, juce::Colour(0xFFFFD54F));
        gold122Btn.setColour(juce::ToggleButton::tickColourId, juce::Colour(0xFFFFD54F));
        gold122Btn.setTooltip("Quick toggle for Lavry Gold 122-96 ADC Physical Emulation (discrete JFET H2 + Joule thermal sag).");
        gold122Btn.addMouseListener(this, true);
        gold122Btn.onClick = [this]() {
            if (gold122Btn.getToggleState()) {
                topologyBox.setSelectedId(2, juce::sendNotificationSync);
            } else {
                topologyBox.setSelectedId(1, juce::sendNotificationSync);
            }
        };

        // 8. Controls: Routing Selector
        routingBox.addItem("Stereo L/R", 1);
        routingBox.addItem("Mid/Side Split", 2);
        routingBox.addItem("Mid Only", 3);
        routingBox.addItem("Side Only", 4);
        routingBox.setSelectedId(1, juce::dontSendNotification);
        routingBox.setTooltip("Stereo Routing: Stereo L/R, Mid/Side Split, Mid Only (clip punch), Side Only (clip width).");
        routingBox.addMouseListener(this, true);
        addAndMakeVisible(routingBox);
        routingAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(
            audioProcessor.getAPVTS(), "routing", routingBox);

        // 9. Buttons: Mono-Maker, True-Peak, Delta Audition, Bypass
        setupButton(monoMakerBtn, "Mono < 80Hz", true);
        monoMakerBtn.setTooltip("Sub-Bass Mono Maker (<80 Hz HPF on Side channel). Keeps bass strictly mono for tight club punch.");
        monoMakerBtn.addMouseListener(this, true);
        monoMakerAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            audioProcessor.getAPVTS(), "monoMaker", monoMakerBtn);

        setupButton(truePeakBtn, "ISP True-Peak", true);
        truePeakBtn.setTooltip("ITU-R BS.1770-4 4x Oversampled True-Peak Limiter. Guarantees zero inter-sample clipping.");
        truePeakBtn.addMouseListener(this, true);
        truePeakAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            audioProcessor.getAPVTS(), "truePeak", truePeakBtn);

        setupButton(deltaAuditionBtn, "Delta Audition", false);
        deltaAuditionBtn.setTooltip("Delta Audition: Solos exclusively the shaved-off peak audio. Silent when below ceiling.");
        deltaAuditionBtn.addMouseListener(this, true);
        deltaAuditionAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            audioProcessor.getAPVTS(), "deltaAudition", deltaAuditionBtn);

        setupButton(bypassBtn, "Bypass", false);
        bypassBtn.setTooltip("Bit-Exact True Hardware Bypass passing input directly to output with zero latency.");
        bypassBtn.addMouseListener(this, true);
        bypassAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            audioProcessor.getAPVTS(), "bypass", bypassBtn);

        addAndMakeVisible(resizableHandle);

        setResizable(true, true);
        setResizeLimits(800, 520, 1440, 900);
        setSize(960, 580);

        startTimerHz(30);
    }

    ~PerfectClipEditor() override {
        stopTimer();
        setLookAndFeel(nullptr);
    }

    void mouseEnter(const juce::MouseEvent& e) override {
        updateHoverHelp(e.eventComponent);
    }

    void mouseExit(const juce::MouseEvent& e) override {
        if (e.eventComponent == activeHoveredComponent) {
            activeHoveredComponent = nullptr;
            repaint(infoBarBounds);
        }
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const float w = bounds.getWidth();
        const float h = bounds.getHeight();

        // 1. Brushed Dark Titanium Chassis Background
        juce::ColourGradient bgGrad(juce::Colour(0xFF171A21), 0.0f, 0.0f,
                                    juce::Colour(0xFF0D0F14), 0.0f, h, false);
        g.setGradientFill(bgGrad);
        g.fillRect(bounds);

        // Subtle anodized brushed lines
        g.setColour(juce::Colour(0x06FFFFFF));
        for (float y = 0.0f; y < h; y += 3.0f) {
            g.drawHorizontalLine(static_cast<int>(y), 0.0f, w);
        }

        // 2. Header Bar with Gold 171 Logo
        g.setColour(juce::Colour(0xFF101319));
        g.fillRect(0.0f, 0.0f, w, 46.0f);
        g.setColour(juce::Colour(0xFF28303C));
        g.drawHorizontalLine(46, 0.0f, w);

        if (goldLogoImage.isValid()) {
            g.drawImageWithin(goldLogoImage, 16, 7, 140, 32,
                              juce::RectanglePlacement(juce::RectanglePlacement::xLeft | juce::RectanglePlacement::yMid));
        }

        g.setColour(juce::Colour(0xFFFFD54F));
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 15.0f, juce::Font::bold)));
        g.drawText("171 PERFECTCLIP", 165, 11, 220, 24, juce::Justification::left);

        g.setColour(juce::Colour(0xFF78889B));
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultSansSerifFontName(), 10.0f, juce::Font::plain)));
        g.drawText("ADAA-2 TRUE-PEAK MASTERING CLIPPER // TRANSDETAIL MATRIX",
                   360, 14, 420, 20, juce::Justification::left);

        // Active Topology Badge in Header
        drawTopologyBadge(g, static_cast<int>(w) - 210, 11, 195, 24);

        // 3. Draw Functional Bays (Bay 1, Bay 2 Scope, Bay 3 TransDetail, Bay 4 Master)
        drawBay(g, bay1Bounds, "INPUT & CONDITIONING");
        drawBay(g, bay2Bounds, "60 FPS CRT BIPOLAR DELTA SCOPE");
        drawBay(g, bay3Bounds, "TOPOLOGY & TRANSDETAIL™ MATRIX");
        drawBay(g, bay4Bounds, "OUTPUT & AUDITION");

        // 4. Draw Interactive Pro Parameter Inspector / Info Bar
        drawInfoBar(g, infoBarBounds);
    }

    void resized() override {
        const auto bounds = getLocalBounds();
        const int w = bounds.getWidth();
        const int h = bounds.getHeight();

        const int topY = 52;
        const int infoBarH = 68;
        const int bottomH = h - topY - infoBarH - 12;

        const int bay1W = static_cast<int>(w * 0.20f);
        const int bay2W = static_cast<int>(w * 0.38f);
        const int bay3W = static_cast<int>(w * 0.25f);
        const int bay4W = w - bay1W - bay2W - bay3W - 20;

        bay1Bounds = juce::Rectangle<int>(8, topY, bay1W, bottomH);
        bay2Bounds = juce::Rectangle<int>(bay1Bounds.getRight() + 4, topY, bay2W, bottomH);
        bay3Bounds = juce::Rectangle<int>(bay2Bounds.getRight() + 4, topY, bay3W, bottomH);
        bay4Bounds = juce::Rectangle<int>(bay3Bounds.getRight() + 4, topY, bay4W, bottomH);

        infoBarBounds = juce::Rectangle<int>(8, h - infoBarH - 6, w - 16, infoBarH);

        // Bay 1: Input Drive, Routing, Mono Maker
        driveSlider.setBounds(bay1Bounds.getX() + (bay1Bounds.getWidth() - 90) / 2, bay1Bounds.getY() + 32, 90, 90);
        routingBox.setBounds(bay1Bounds.getX() + 16, bay1Bounds.getY() + 140, bay1Bounds.getWidth() - 32, 26);
        monoMakerBtn.setBounds(bay1Bounds.getX() + 16, bay1Bounds.getY() + 180, bay1Bounds.getWidth() - 32, 28);

        // Bay 2: CRT Scope & Ceiling
        const int scopeH = bay2Bounds.getHeight() - 130;
        crtScope.setBounds(bay2Bounds.getX() + 10, bay2Bounds.getY() + 30, bay2Bounds.getWidth() - 20, scopeH);
        ceilingSlider.setBounds(bay2Bounds.getX() + (bay2Bounds.getWidth() - 90) / 2, crtScope.getBottom() + 10, 90, 85);

        // Bay 3: Gold 122 Quick Hardware Switch, Topology Box, Soft Knee, TransDetail, Alchemy Air
        gold122Btn.setBounds(bay3Bounds.getX() + 16, bay3Bounds.getY() + 28, bay3Bounds.getWidth() - 32, 24);
        topologyBox.setBounds(bay3Bounds.getX() + 16, bay3Bounds.getY() + 56, bay3Bounds.getWidth() - 32, 24);
        const int b3MidX = bay3Bounds.getX() + bay3Bounds.getWidth() / 2;
        kneeSlider.setBounds(bay3Bounds.getX() + 10, bay3Bounds.getY() + 86, 75, 75);
        alchemySlider.setBounds(b3MidX + 10, bay3Bounds.getY() + 86, 75, 75);
        detailSlider.setBounds(bay3Bounds.getX() + (bay3Bounds.getWidth() - 95) / 2, bay3Bounds.getY() + 166, 95, 95);

        // Bay 4: Output Trim, ISP True-Peak, Delta Audition, Bypass
        outTrimSlider.setBounds(bay4Bounds.getX() + (bay4Bounds.getWidth() - 90) / 2, bay4Bounds.getY() + 32, 90, 90);
        truePeakBtn.setBounds(bay4Bounds.getX() + 16, bay4Bounds.getY() + 135, bay4Bounds.getWidth() - 32, 28);
        deltaAuditionBtn.setBounds(bay4Bounds.getX() + 16, bay4Bounds.getY() + 175, bay4Bounds.getWidth() - 32, 28);
        bypassBtn.setBounds(bay4Bounds.getX() + 16, bay4Bounds.getY() + 215, bay4Bounds.getWidth() - 32, 28);

        resizableHandle.setBounds(w - 18, h - 18, 18, 18);
    }

private:
    void timerCallback() override {
        const float cVal = audioProcessor.getAPVTS().getRawParameterValue("ceiling")->load(std::memory_order_relaxed);
        crtScope.setCeilingLinear(std::pow(10.0f, cVal / 20.0f));

        const int topId = topologyBox.getSelectedId();
        const bool isGold = (topId == 2);
        crtScope.setGoldMode(isGold);
        if (gold122Btn.getToggleState() != isGold) {
            gold122Btn.setToggleState(isGold, juce::dontSendNotification);
        }

        // Refresh telemetry on info bar when idle
        repaint(infoBarBounds);
    }

    void updateHoverHelp(juce::Component* comp) {
        activeHoveredComponent = comp;
        repaint(infoBarBounds);
    }

    void drawTopologyBadge(juce::Graphics& g, int x, int y, int w, int h) {
        auto r = juce::Rectangle<int>(x, y, w, h).toFloat();
        g.setColour(juce::Colour(0xFF141820));
        g.fillRoundedRectangle(r, 4.0f);
        g.setColour(juce::Colour(0xFF303846));
        g.drawRoundedRectangle(r, 4.0f, 1.0f);

        const int topId = topologyBox.getSelectedId();
        juce::String topName = "DIGITAL HARD";
        juce::Colour ledCol(0xFF00E5FF);

        if (topId == 2) {
            topName = "GOLD ADC 122";
            ledCol = juce::Colour(0xFFFFD54F);
        } else if (topId == 3) {
            topName = "TUBE TRIODE";
            ledCol = juce::Colour(0xFFFF9100);
        } else if (topId == 4) {
            topName = "GERMANIUM";
            ledCol = juce::Colour(0xFFFF5252);
        }

        // Illuminated LED indicator
        g.setColour(ledCol);
        g.fillEllipse(r.getX() + 8.0f, r.getCentreY() - 3.5f, 7.0f, 7.0f);
        g.setColour(ledCol.withAlpha(0.35f));
        g.fillEllipse(r.getX() + 6.0f, r.getCentreY() - 5.5f, 11.0f, 11.0f);

        g.setColour(juce::Colour(0xFFCCD6E0));
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 10.0f, juce::Font::bold)));
        g.drawText("TOPOLOGY: " + topName, static_cast<int>(r.getX() + 22.0f), static_cast<int>(r.getY()), static_cast<int>(r.getWidth() - 26.0f), static_cast<int>(r.getHeight()), juce::Justification::left);
    }

    void drawBay(juce::Graphics& g, const juce::Rectangle<int>& bounds, const juce::String& title) {
        auto r = bounds.toFloat();
        g.setColour(juce::Colour(0xFF101319));
        g.fillRoundedRectangle(r, 6.0f);
        g.setColour(juce::Colour(0xFF242B36));
        g.drawRoundedRectangle(r, 6.0f, 1.0f);

        // Bay Title Banner
        g.setColour(juce::Colour(0xFF141820));
        g.fillRoundedRectangle(r.getX(), r.getY(), r.getWidth(), 22.0f, 6.0f);
        g.setColour(juce::Colour(0xFF8898AA));
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 9.5f, juce::Font::bold)));
        g.drawText(title, bounds.getX() + 10, bounds.getY() + 2, bounds.getWidth() - 20, 18, juce::Justification::left);
    }

    void drawInfoBar(juce::Graphics& g, const juce::Rectangle<int>& bounds) {
        auto r = bounds.toFloat();
        
        // Background Chassis
        g.setColour(juce::Colour(0xFF0F1218));
        g.fillRoundedRectangle(r, 5.0f);
        g.setColour(juce::Colour(0xFF2B3340));
        g.drawRoundedRectangle(r, 5.0f, 1.2f);

        // Header accent line
        g.setColour(juce::Colour(0xFFFFD54F).withAlpha(0.35f));
        g.drawHorizontalLine(bounds.getY() + 1, r.getX() + 2.0f, r.getRight() - 2.0f);

        auto help = getHelpForActiveComponent();

        if (help.title.isNotEmpty()) {
            // PARAMETER TITLE & VALUE
            g.setColour(juce::Colour(0xFFFFD54F));
            g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 11.0f, juce::Font::bold)));
            juce::String header = "▶ " + help.title;
            if (help.value.isNotEmpty()) {
                header += " : [" + help.value + "]";
            }
            g.drawText(header, bounds.getX() + 14, bounds.getY() + 6, bounds.getWidth() - 28, 16, juce::Justification::left);

            // DESCRIPTION (Line 1)
            g.setColour(juce::Colour(0xFFE0E6ED));
            g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultSansSerifFontName(), 10.5f, juce::Font::plain)));
            g.drawText(help.description, bounds.getX() + 14, bounds.getY() + 24, bounds.getWidth() - 28, 18, juce::Justification::left);

            // RECOMMENDATION / ACOUSTIC PHYSICS (Line 2)
            g.setColour(juce::Colour(0xFF00E5FF));
            g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 9.5f, juce::Font::plain)));
            g.drawText("✦ " + help.recommendation, bounds.getX() + 14, bounds.getY() + 44, bounds.getWidth() - 28, 16, juce::Justification::left);
        } else {
            // LIVE REAL-TIME TELEMETRY WHEN IDLE
            auto telem = audioProcessor.getEngine().getTelemetry();
            g.setColour(juce::Colour(0xFFFFD54F));
            g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 10.5f, juce::Font::bold)));
            g.drawText("▶ REAL-TIME TELEMETRY & MASTERING STATUS", bounds.getX() + 14, bounds.getY() + 6, 400, 16, juce::Justification::left);

            // Glowing green status LED
            g.setColour(juce::Colour(0xFF00E676));
            g.fillEllipse(bounds.getRight() - 110.0f, bounds.getY() + 9.0f, 8.0f, 8.0f);
            g.setColour(juce::Colour(0xFFECEFF1));
            g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 9.5f, juce::Font::bold)));
            g.drawText("DSP ACTIVE", bounds.getRight() - 96, bounds.getY() + 5, 80, 16, juce::Justification::left);

            juce::String m1 = "PEAK IN: " + juce::String(telem.inPeakDbL, 1) + " dBFS | CEILING: " 
                            + juce::String(audioProcessor.getAPVTS().getRawParameterValue("ceiling")->load(), 1) + " dBFS | PEAK OUT: "
                            + juce::String(telem.outPeakDbL, 1) + " dBFS";
            g.setColour(juce::Colour(0xFFCCD6E0));
            g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 10.0f, juce::Font::plain)));
            g.drawText(m1, bounds.getX() + 14, bounds.getY() + 25, bounds.getWidth() - 28, 16, juce::Justification::left);

            juce::String m2 = "MAX CLIP REDUCTION: " + juce::String(telem.maxGainReductionDb, 1) + " dB | CREST FACTOR: "
                            + juce::String(telem.crestFactorDb, 1) + " dB | TRUE-PEAK GUARD: "
                            + (audioProcessor.getAPVTS().getRawParameterValue("truePeak")->load() > 0.5f ? "ACTIVE (BS.1770 4x)" : "OFF");
            g.setColour(juce::Colour(0xFF8898AA));
            g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 9.5f, juce::Font::plain)));
            g.drawText(m2, bounds.getX() + 14, bounds.getY() + 45, bounds.getWidth() - 28, 16, juce::Justification::left);
        }
    }

    HelpItem getHelpForActiveComponent() const {
        if (activeHoveredComponent == nullptr) return {};

        if (activeHoveredComponent == &driveSlider || activeHoveredComponent->isParentOf(&driveSlider) || activeHoveredComponent == &driveLabel) {
            const float v = audioProcessor.getAPVTS().getRawParameterValue("inGain")->load();
            return {
                "INPUT DRIVE (dB)",
                juce::String(v, 1) + " dB",
                "Clean mastering gain pushing audio into the clipping core. Perfectly symmetric gain with 0 Hz DC preservation.",
                "RECOMMENDED: +2.0 to +6.0 dB for modern loud masters; push +8 to +12 dB for aggressive punch on drums/busses."
            };
        }

        if (activeHoveredComponent == &ceilingSlider || activeHoveredComponent->isParentOf(&ceilingSlider) || activeHoveredComponent == &ceilingLabel) {
            const float v = audioProcessor.getAPVTS().getRawParameterValue("ceiling")->load();
            return {
                "SAFETY CEILING (dBFS)",
                juce::String(v, 1) + " dBFS",
                "Strict master peak ceiling. Guaranteed 100% bit-exact peak compliance with zero overshoot across all topologies.",
                "RECOMMENDED: -0.1 dBFS to -0.3 dBFS for standard digital master; -1.0 dBFS for Apple Music / Spotify streaming."
            };
        }

        if (activeHoveredComponent == &kneeSlider || activeHoveredComponent->isParentOf(&kneeSlider) || activeHoveredComponent == &kneeLabel) {
            const float v = audioProcessor.getAPVTS().getRawParameterValue("softKnee")->load() * 100.0f;
            return {
                "SOFT KNEE (%)",
                juce::String(v, 0) + "%",
                "Continuously variable transition from brickwall hard clipping (0%) to smooth C2 analog quintic knee (100%).",
                "RECOMMENDED: 0% for pure transient punch on kicks/snares; 15% to 35% for transparent master bus leveling."
            };
        }

        if (activeHoveredComponent == &detailSlider || activeHoveredComponent->isParentOf(&detailSlider) || activeHoveredComponent == &detailLabel) {
            const float v = audioProcessor.getAPVTS().getRawParameterValue("transDetail")->load() * 100.0f;
            return {
                "171 TRANSDETAIL™ MATRIX (%)",
                juce::String(v, 0) + "%",
                "Orthogonal carrier/detail decomposition. Preserves high-frequency transients and cymbals from intermodulation against bass peaks.",
                "RECOMMENDED: 100% for maximum acoustic transparency, transient air, and cymbal clarity; 0% for naive clipping."
            };
        }

        if (activeHoveredComponent == &alchemySlider || activeHoveredComponent->isParentOf(&alchemySlider) || activeHoveredComponent == &alchemyLabel) {
            const float v = audioProcessor.getAPVTS().getRawParameterValue("alchemyAir")->load();
            return {
                "ALCHEMY AIR (dB)",
                juce::String(v, 1) + " dB",
                "Zero-delay active HF contouring shelf (~10 kHz). Injects silky high-frequency sheen and sparkle into preserved transients.",
                "RECOMMENDED: 0.0 dB for flat linear response; +0.5 to +2.0 dB to add high-end air to dark or compressed masters."
            };
        }

        if (activeHoveredComponent == &outTrimSlider || activeHoveredComponent->isParentOf(&outTrimSlider) || activeHoveredComponent == &outTrimLabel) {
            const float v = audioProcessor.getAPVTS().getRawParameterValue("outGain")->load();
            return {
                "OUTPUT TRIM (dB)",
                juce::String(v, 1) + " dB",
                "Clean output makeup gain. Followed by 5 Hz DC blocker and True-Peak lookahead safety limiter.",
                "RECOMMENDED: Set to 0.0 dB for standard master output, or negative trim to match perceived input loudness."
            };
        }

        if (activeHoveredComponent == &topologyBox || activeHoveredComponent->isParentOf(&topologyBox)) {
            const int id = topologyBox.getSelectedId();
            juce::String modeName = "Digital Hard";
            if (id == 2) modeName = "Gold ADC 122";
            else if (id == 3) modeName = "Tube Triode";
            else if (id == 4) modeName = "Germanium";
            return {
                "CLIPPER TOPOLOGY",
                modeName,
                "Selects between 4 physical & mathematical clipping engines: Digital Hard, Gold ADC 122, Tube Triode, and Germanium.",
                "Digital Hard = max loudness; Gold 122 = Lavry discrete JFET & thermal sag; Tube = warm harmonics; Germanium = vintage bite."
            };
        }

        if (activeHoveredComponent == &gold122Btn) {
            return {
                "✦ GOLD 122 ADC ✦ QUICK SWITCH",
                gold122Btn.getToggleState() ? "ENGAGED" : "OFF",
                "Dedicated hardware switch activating the Lavry Gold 122-96 ADC physical emulation with discrete JFET front-end & Joule thermal sag.",
                "RECOMMENDED: Enable for authentic legendary high-end mastering converter saturation and warm analog glue."
            };
        }

        if (activeHoveredComponent == &routingBox || activeHoveredComponent->isParentOf(&routingBox)) {
            return {
                "CHANNEL ROUTING",
                routingBox.getText(),
                "Routing modes: Stereo L/R, Mid/Side Split, Mid Only (clips mono punch while preserving side reverb), Side Only (clips width).",
                "RECOMMENDED: Stereo L/R for standard tracks; Mid/Side Split to control heavy center kick/snare without ducking wide stereo guitars."
            };
        }

        if (activeHoveredComponent == &monoMakerBtn) {
            return {
                "SUB-BASS MONO MAKER (< 80 Hz)",
                monoMakerBtn.getToggleState() ? "ENGAGED" : "BYPASSED",
                "Elliptical highpass filter on Side channel (<80 Hz). Forces low sub-bass frequencies into strict mono, eliminating phase cancellation.",
                "RECOMMENDED: Always keep ON for vinyl mastering, club sound systems, and maximum low-end impact."
            };
        }

        if (activeHoveredComponent == &truePeakBtn) {
            return {
                "ITU-R BS.1770-4 TRUE-PEAK GUARD",
                truePeakBtn.getToggleState() ? "ENGAGED (4x Oversampled)" : "OFF",
                "Lookahead True-Peak limiter with 4x Hermite cubic oversampled inter-sample peak (ISP) detection. Automatically reports 64-sample latency to DAW.",
                "RECOMMENDED: Keep ON for streaming masters (Spotify, Apple Music, YouTube) to prevent D/A inter-sample distortion."
            };
        }

        if (activeHoveredComponent == &deltaAuditionBtn) {
            return {
                "DELTA AUDITION MODE",
                deltaAuditionBtn.getToggleState() ? "SOLO ACTIVE" : "OFF",
                "Solos exclusively the shaved-off peak audio (pre-clip minus post-clip). Total silence when audio is below ceiling.",
                "AUDITION TOOL: Turn ON to hear exactly what is being shaved off. Zero comb filtering, bit-exact phase alignment!"
            };
        }

        if (activeHoveredComponent == &bypassBtn) {
            return {
                "MASTER BYPASS",
                bypassBtn.getToggleState() ? "BYPASSED" : "ACTIVE",
                "Bit-exact true hardware bypass passing input directly to output with zero latency and zero coloration.",
                "A/B TOOL: Toggle to compare clipped audio against the original unclipped signal."
            };
        }

        if (activeHoveredComponent == &crtScope || activeHoveredComponent->isParentOf(&crtScope)) {
            return {
                "60 FPS CRT BIPOLAR DELTA OSCILLOSCOPE",
                "ACTIVE",
                "Hardware-accelerated real-time CRT scope displaying input signal (dim green), clipped output (amber), and delta spikes (cyan).",
                "VISUAL GUIDE: Shaded amber region shows exact waveform saturation against the calibrated ceiling grid lines."
            };
        }

        return {};
    }

    void setupRotarySlider(juce::Slider& slider, juce::Label& label, const juce::String& name,
                           const juce::String& title, const juce::String& /*minTxt*/, const juce::String& /*maxTxt*/)
    {
        slider.setName(name);
        slider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 70, 16);
        addAndMakeVisible(slider);

        label.setText(title, juce::dontSendNotification);
        label.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 9.0f, juce::Font::bold)));
        label.setColour(juce::Label::textColourId, juce::Colour(0xFF8898AA));
        label.setJustificationType(juce::Justification::centred);
        label.attachToComponent(&slider, false);
    }

    void setupButton(juce::ToggleButton& btn, const juce::String& text, bool defaultState) {
        btn.setButtonText(text);
        btn.setToggleState(defaultState, juce::dontSendNotification);
        btn.setColour(juce::ToggleButton::textColourId, juce::Colour(0xFFCCD6E0));
        btn.setColour(juce::ToggleButton::tickColourId, juce::Colour(0xFFFF9100));
        addAndMakeVisible(btn);
    }

    PerfectClipAudioProcessor& audioProcessor;
    PerfectClipBoutiqueLookAndFeel lookAndFeel;

    PerfectClipCRTScope crtScope;
    plugin_171::ResizableHandleComponent resizableHandle;

    juce::Image goldLogoImage;

    juce::Rectangle<int> bay1Bounds;
    juce::Rectangle<int> bay2Bounds;
    juce::Rectangle<int> bay3Bounds;
    juce::Rectangle<int> bay4Bounds;
    juce::Rectangle<int> infoBarBounds;

    juce::Component* activeHoveredComponent = nullptr;

    // Sliders
    juce::Slider driveSlider, ceilingSlider, kneeSlider, detailSlider, alchemySlider, outTrimSlider;
    juce::Label driveLabel, ceilingLabel, kneeLabel, detailLabel, alchemyLabel, outTrimLabel;

    // ComboBoxes
    juce::ComboBox topologyBox, routingBox;

    // Buttons
    juce::ToggleButton gold122Btn, monoMakerBtn, truePeakBtn, deltaAuditionBtn, bypassBtn;

    // Attachments
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> driveAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> ceilingAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> kneeAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> detailAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> alchemyAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> outTrimAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> topologyAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> routingAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> monoMakerAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> truePeakAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> deltaAuditionAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bypassAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PerfectClipEditor)
};

} // namespace dsp171