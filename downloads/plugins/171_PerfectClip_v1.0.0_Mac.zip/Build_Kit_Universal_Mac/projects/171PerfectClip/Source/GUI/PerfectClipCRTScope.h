#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <array>
#include <cmath>
#include <dsp171/PerfectClipEngine.h>

namespace dsp171 {

class PerfectClipCRTScope : public juce::Component,
                            private juce::Timer
{
public:
    PerfectClipCRTScope(PerfectClipEngine& engineToRead)
        : engine(engineToRead)
    {
        setOpaque(true);
        startTimerHz(60); // 60 FPS ultra-smooth CRT refresh
    }

    ~PerfectClipCRTScope() override {
        stopTimer();
    }

    void setCeilingLinear(float ceilingLin) noexcept {
        currentCeiling = std::clamp(ceilingLin, 0.01f, 1.0f);
    }

    void setGoldMode(bool isGold) noexcept {
        goldMode = isGold;
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const float w = bounds.getWidth();
        const float h = bounds.getHeight();
        if (w < 10.0f || h < 10.0f) return;

        // 1. Inset Dark CRT Screen Bezel
        g.setColour(juce::Colour(0xFF0A0C10));
        g.fillRoundedRectangle(bounds, 6.0f);

        juce::ColourGradient crtGrad(juce::Colour(0xFF101620), w * 0.5f, h * 0.5f,
                                    juce::Colour(0xFF050709), 0.0f, 0.0f, true);
        g.setGradientFill(crtGrad);
        g.fillRoundedRectangle(bounds.reduced(1.5f), 5.0f);

        // Metallic border
        g.setColour(juce::Colour(0xFF202632));
        g.drawRoundedRectangle(bounds.reduced(0.5f), 6.0f, 1.0f);

        // 2. Tektronix Laboratory Precision Graticule
        g.setColour(juce::Colour(0x1400E5FF)); // Subdued cyan grid
        constexpr int numVLines = 10;
        for (int i = 1; i < numVLines; ++i) {
            float x = 4.0f + (w - 8.0f) * (static_cast<float>(i) / numVLines);
            g.drawVerticalLine(static_cast<int>(x), 4.0f, h - 4.0f);
        }

        constexpr int numHLines = 6;
        for (int i = 1; i < numHLines; ++i) {
            float y = 4.0f + (h - 8.0f) * (static_cast<float>(i) / numHLines);
            g.drawHorizontalLine(static_cast<int>(y), 4.0f, w - 4.0f);
        }

        // Zero AC Center Line
        const float midY = h * 0.5f;
        g.setColour(juce::Colour(0x2800E5FF));
        g.drawHorizontalLine(static_cast<int>(midY), 4.0f, w - 4.0f);

        // 3. Positive & Negative Clipping Ceiling Lines
        const float ampScale = (h * 0.5f - 8.0f);
        const float ceilYPos = midY - currentCeiling * ampScale;
        const float ceilYNeg = midY + currentCeiling * ampScale;

        g.setColour(juce::Colour(0x60FF9100)); // Glowing Amber dashed reference lines
        float dashPattern[2] = { 4.0f, 3.0f };
        g.drawDashedLine(juce::Line<float>(4.0f, ceilYPos, w - 4.0f, ceilYPos), dashPattern, 2, 1.2f);
        g.drawDashedLine(juce::Line<float>(4.0f, ceilYNeg, w - 4.0f, ceilYNeg), dashPattern, 2, 1.2f);

        // 4. Capture Scope Snapshot from Audio Engine Lock-Free Buffer
        engine.copyScopeSnapshot(scopeSnapshot);

        // 5. Build Waveform Paths
        constexpr size_t N = PerfectClipEngine::SCOPE_BUFFER_SIZE;
        constexpr size_t step = 4; // Render 256 vector points across width

        normalPath.clear();
        clippedDeltaPath.clear();

        bool firstPoint = true;
        for (size_t i = 0; i < N; i += step) {
            const float normX = static_cast<float>(i) / static_cast<float>(N);
            const float px = 4.0f + normX * (w - 8.0f);

            const auto& sample = scopeSnapshot[i];
            const float audioVal = std::clamp(sample.outSample, -1.5f, 1.5f);
            const float py = midY - audioVal * ampScale;

            if (firstPoint) {
                normalPath.startNewSubPath(px, py);
                firstPoint = false;
            } else {
                normalPath.lineTo(px, py);
            }

            // If sample is clipped or exceeds ceiling, highlight in orange
            if (sample.clipped || std::abs(sample.inSample) >= currentCeiling) {
                const float inVal = std::clamp(sample.inSample, -1.5f, 1.5f);
                const float pyIn = midY - inVal * ampScale;
                clippedDeltaPath.startNewSubPath(px, py);
                clippedDeltaPath.lineTo(px, pyIn);
            }
        }

        // Draw Ambient Cyan Phosphor Waveform
        g.setColour(juce::Colour(0x3000E5FF)); // Soft halo glow
        g.strokePath(normalPath, juce::PathStrokeType(3.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        g.setColour(juce::Colour(0xFF00E5FF)); // Core beam
        g.strokePath(normalPath, juce::PathStrokeType(1.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // Draw Clipped Delta Sparks in Intense Amber / Neon Red
        if (!clippedDeltaPath.isEmpty()) {
            g.setColour(juce::Colour(0x80FF3D00)); // Amber bloom
            g.strokePath(clippedDeltaPath, juce::PathStrokeType(3.0f, juce::PathStrokeType::mitered));

            g.setColour(juce::Colour(0xFFFF9100)); // Crisp spark
            g.strokePath(clippedDeltaPath, juce::PathStrokeType(1.5f, juce::PathStrokeType::mitered));
        }

        // 6. Real-time Telemetry On-Screen Display (HUD)
        const auto telemetry = engine.getTelemetry();
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 10.0f, juce::Font::bold)));
        
        // GR Badge
        if (telemetry.maxGainReductionDb > 0.05f) {
            g.setColour(juce::Colour(0xFFFF5252));
            g.drawText(juce::String::formatted("CLIP: -%.1f dB", telemetry.maxGainReductionDb),
                       10, 8, 120, 16, juce::Justification::left);
        } else {
            g.setColour(juce::Colour(0xFF8090A0));
            g.drawText("CLIP: 0.0 dB", 10, 8, 120, 16, juce::Justification::left);
        }

        // Gold 122 Active Badge
        if (goldMode) {
            g.setColour(juce::Colour(0xFFFFD54F)); // Radiant warm gold
            g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 9.5f, juce::Font::bold)));
            g.drawText("✦ GOLD 122 CONVERTER ✦", 0, 8, static_cast<int>(w), 16, juce::Justification::centred);
        }

        // Crest Factor Badge
        g.setColour(juce::Colour(0xFF00E5FF));
        g.setFont(juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 10.0f, juce::Font::bold)));
        g.drawText(juce::String::formatted("CREST: %.1f dB", telemetry.crestFactorDb),
                   static_cast<int>(w) - 130, 8, 120, 16, juce::Justification::right);
    }

private:
    void timerCallback() override {
        repaint();
    }

    PerfectClipEngine& engine;
    float currentCeiling = 1.0f;
    bool goldMode = false;

    std::array<PerfectClipEngine::ScopeSample, PerfectClipEngine::SCOPE_BUFFER_SIZE> scopeSnapshot{};
    juce::Path normalPath;
    juce::Path clippedDeltaPath;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PerfectClipCRTScope)
};

} // namespace dsp171
