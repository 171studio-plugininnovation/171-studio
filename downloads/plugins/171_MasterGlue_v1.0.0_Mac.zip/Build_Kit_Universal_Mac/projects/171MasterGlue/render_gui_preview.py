import os
import math
from PIL import Image, ImageDraw, ImageFont, ImageFilter

def create_preview(out_paths):
    width, height = 960, 600
    img = Image.new("RGBA", (width, height), (14, 16, 18, 255))
    draw = ImageDraw.Draw(img)

    # 1. Texture Chassis Alluminio Spazzolato Scuro
    for y in range(height):
        factor = y / float(height)
        r = int(22 - factor * 8)
        g = int(24 - factor * 9)
        b = int(28 - factor * 11)
        draw.line([(0, y), (width, y)], fill=(r, g, b, 255))
        # Micro rigature spazzolate
        if y % 3 == 0:
            draw.line([(0, y), (width, y)], fill=(r + 4, g + 4, b + 5, 255))

    # Bordo esterno bisellato
    draw.rounded_rectangle([(1, 1), (width - 2, height - 2)], radius=10, outline=(55, 62, 72, 255), width=2)
    draw.rounded_rectangle([(3, 3), (width - 4, height - 4)], radius=9, outline=(25, 28, 33, 255), width=1)

    # Viti Torx nei 4 angoli
    def draw_screw(x, y):
        draw.ellipse([(x - 6, y - 6), (x + 6, y + 6)], fill=(12, 14, 16, 255), outline=(50, 56, 65, 255))
        draw.line([(x - 3, y), (x + 3, y)], fill=(30, 35, 42, 255), width=2)
        draw.line([(x, y - 3), (x, y + 3)], fill=(30, 35, 42, 255), width=2)

    draw_screw(20, 20)
    draw_screw(width - 20, 20)
    draw_screw(20, height - 20)
    draw_screw(width - 20, height - 20)

    # 2. Header & Targhetta Centrale in Ottone Lucido 171 Studio
    badge_w, badge_h = 440, 40
    bx1 = (width - badge_w) // 2
    by1 = 14
    bx2 = bx1 + badge_w
    by2 = by1 + badge_h

    # Gradiente ottone dorato
    draw.rounded_rectangle([(bx1, by1), (bx2, by2)], radius=6, fill=(185, 145, 55, 255), outline=(235, 210, 140, 255), width=2)
    draw.rounded_rectangle([(bx1 + 2, by1 + 2), (bx2 - 2, by2 - 2)], radius=5, outline=(130, 95, 30, 255), width=1)

    draw.text((width // 2, by1 + 10), "171 MASTER GLUE", fill=(18, 20, 24, 255), anchor="mm")
    draw.text((width // 2, by1 + 26), "DISCRETE ANALOG MASTER BUS CONSOLE & IMAGER", fill=(45, 38, 20, 255), anchor="mm")

    # Preset Bar in alto a destra
    draw.rounded_rectangle([(width - 320, 18), (width - 130, 46)], radius=4, fill=(20, 24, 30, 255), outline=(90, 75, 45, 255), width=1)
    draw.text((width - 225, 32), "1. Master Bus Glue (SSL)", fill=(240, 220, 160, 255), anchor="mm")

    # Bypass switch in alto a destra
    draw.rounded_rectangle([(width - 110, 18), (width - 35, 46)], radius=4, fill=(28, 20, 20, 255), outline=(140, 40, 40, 255), width=1)
    draw.text((width - 72, 32), "BYPASS", fill=(220, 100, 100, 255), anchor="mm")

    # 3. DOPPIO VU METER GALVANOMETRICO ANALOGICO
    meter_w, meter_h = 270, 175
    gap = 20
    total_vu_w = meter_w * 2 + gap
    start_x = (width - total_vu_w) // 2
    vu_y = 68

    def draw_vu_meter(x, y, title, needle_val, is_gr=False):
        # Cornice scura in metallo
        draw.rounded_rectangle([(x, y), (x + meter_w, y + meter_h)], radius=8, fill=(24, 22, 20, 255), outline=(65, 58, 50, 255), width=2)
        
        # Quadrante beige crema vintage
        dx1, dy1 = x + 5, y + 5
        dx2, dy2 = x + meter_w - 5, y + meter_h - 5
        draw.rounded_rectangle([(dx1, dy1), (dx2, dy2)], radius=6, fill=(245, 238, 222, 255))

        # Alone caldo lampada a tungsteno interna
        cx = (dx1 + dx2) // 2
        cy = dy1 + 25
        for r in range(50, 0, -5):
            alpha = int(45 * (1.0 - r / 50.0))
            draw.ellipse([(cx - r * 2, cy - r), (cx + r * 2, cy + r)], fill=(255, 180, 50, alpha))

        # LED Indicatori di Stato (Peak Red su Meter L / Active Amber su Meter R)
        if not is_gr:
            # Overload Peak LED
            led_x, led_y = dx2 - 24, dy1 + 16
            draw.ellipse([(led_x - 6, led_y - 6), (led_x + 6, led_y + 6)], fill=(255, 30, 30, 180))
            draw.ellipse([(led_x - 4, led_y - 4), (led_x + 4, led_y + 4)], fill=(255, 50, 50, 255))
            draw.ellipse([(led_x - 1, led_y - 1), (led_x + 1, led_y + 1)], fill=(255, 255, 255, 255))
            draw.text((led_x - 22, led_y), "PEAK", fill=(255, 60, 60, 255), anchor="rm")
        else:
            # GR Active LED
            led_x, led_y = dx1 + 24, dy1 + 16
            draw.ellipse([(led_x - 6, led_y - 6), (led_x + 6, led_y + 6)], fill=(255, 175, 0, 180))
            draw.ellipse([(led_x - 4, led_y - 4), (led_x + 4, led_y + 4)], fill=(255, 190, 20, 255))
            draw.ellipse([(led_x - 1, led_y - 1), (led_x + 1, led_y + 1)], fill=(255, 255, 240, 255))
            draw.text((led_x + 10, led_y), "ACTIVE", fill=(255, 195, 30, 255), anchor="lm")

        # Arco e scala
        pivot_x = cx
        pivot_y = dy2 + 65
        radius = 180

        # Disegna arco nero
        draw.arc([(pivot_x - radius, pivot_y - radius), (pivot_x + radius, pivot_y + radius)], start=236, end=304, fill=(45, 40, 35, 255), width=2)

        if not is_gr:
            # Arco rosso per > 0 VU
            draw.arc([(pivot_x - radius, pivot_y - radius), (pivot_x + radius, pivot_y + radius)], start=294, end=304, fill=(200, 40, 40, 255), width=3)
            ticks = [("-20", 238), ("-10", 250), ("-5", 263), ("-3", 273), ("-1", 284), ("0", 294), ("+3", 304)]
        else:
            ticks = [("20", 238), ("12", 249), ("8", 260), ("5", 271), ("3", 282), ("1", 293), ("0", 304)]

        for lbl, deg in ticks:
            rad = math.radians(deg)
            tx1 = pivot_x + math.cos(rad) * (radius - 5)
            ty1 = pivot_y + math.sin(rad) * (radius - 5)
            tx2 = pivot_x + math.cos(rad) * (radius + 5)
            ty2 = pivot_y + math.sin(rad) * (radius + 5)
            col = (200, 40, 40, 255) if (not is_gr and lbl in ["0", "+3"]) else (45, 40, 35, 255)
            draw.line([(tx1, ty1), (tx2, ty2)], fill=col, width=2 if lbl in ["0", "20"] else 1)
            
            lx = pivot_x + math.cos(rad) * (radius - 16)
            ly = pivot_y + math.sin(rad) * (radius - 16)
            draw.text((lx, ly), lbl, fill=col, anchor="mm")

        # Titolo Meter
        draw.text((cx, dy1 + 75), title, fill=(80, 72, 64, 255), anchor="mm")

        # Ago galvanometrico
        needle_deg = needle_val
        n_rad = math.radians(needle_deg)
        tip_x = pivot_x + math.cos(n_rad) * (radius - 8)
        tip_y = pivot_y + math.sin(n_rad) * (radius - 8)

        # Ombra ago
        draw.line([(pivot_x + 3, pivot_y + 3), (tip_x + 3, tip_y + 3)], fill=(0, 0, 0, 40), width=2)
        # Ago corpo
        draw.line([(pivot_x, pivot_y), (tip_x, tip_y)], fill=(25, 23, 20, 255), width=2)
        # Punta rossa
        px = pivot_x + math.cos(n_rad) * (radius - 24)
        py = pivot_y + math.sin(n_rad) * (radius - 24)
        draw.line([(px, py), (tip_x, tip_y)], fill=(220, 40, 40, 255), width=2)

        # Perno ottone centrale
        draw.ellipse([(pivot_x - 12, pivot_y - 12), (pivot_x + 12, pivot_y + 12)], fill=(25, 23, 20, 255))
        draw.ellipse([(pivot_x - 7, pivot_y - 7), (pivot_x + 7, pivot_y + 7)], fill=(195, 160, 85, 255), outline=(40, 35, 25, 255))

        # Riflesso vetro
        draw.arc([(dx1 + 10, dy1 - 40), (dx2 - 10, dy1 + 80)], start=20, end=160, fill=(255, 255, 255, 30), width=18)

    # Disegna VU Sinistro (Input VU: lancetta verso -3 dB / 273 deg)
    draw_vu_meter(start_x, vu_y, "INPUT VU (0 VU = -18 dBFS)", 280, False)
    # Disegna VU Destro (Gain Reduction: lancetta verso 4 dB GR / 276 deg)
    draw_vu_meter(start_x + meter_w + gap, vu_y, "GAIN REDUCTION (dB)", 282, True)

    # 4. QUATTRO BAY INFERIORI
    bay_y = 265
    bay_h = 315
    margin = 20
    b_gap = 14
    bay_w = (width - margin * 2 - b_gap * 3) // 4

    bays = [
        ("1. DYNAMICS", (255, 215, 0)),
        ("2. TIMING & SC", (255, 165, 32)),
        ("3. ANALOG COLOR", (255, 60, 50)),
        ("4. SPATIAL & MIX", (0, 230, 165))
    ]

    for i, (title, color) in enumerate(bays):
        bx = margin + i * (bay_w + b_gap)
        # Sfondo del bay incassato
        draw.rounded_rectangle([(bx, bay_y), (bx + bay_w, bay_y + bay_h)], radius=6, fill=(16, 18, 22, 255), outline=(38, 43, 52, 255), width=1)
        # Barra del titolo del bay
        draw.rounded_rectangle([(bx, bay_y), (bx + bay_w, bay_y + 24)], radius=6, fill=(24, 27, 33, 255))
        draw.line([(bx + 8, bay_y + 24), (bx + bay_w - 8, bay_y + 24)], fill=color, width=2)
        draw.text((bx + bay_w // 2, bay_y + 12), title, fill=(230, 230, 230, 255), anchor="mm")

    # Helper per disegnare manopola zigrinata
    def draw_knob(cx, cy, radius, label, val_text, color, angle_deg=220):
        # Traccia graduata ad arco
        draw.arc([(cx - radius - 5, cy - radius - 5), (cx + radius + 5, cy + radius + 5)], start=140, end=400, fill=(20, 22, 26, 255), width=4)
        draw.arc([(cx - radius - 5, cy - radius - 5), (cx + radius + 5, cy + radius + 5)], start=140, end=angle_deg, fill=color, width=3)

        # Ghiera zigrinata 36 denti
        draw.ellipse([(cx - radius, cy - radius), (cx + radius, cy + radius)], fill=(15, 17, 20, 255), outline=(45, 50, 60, 255), width=2)
        inner_r = radius - 3
        draw.ellipse([(cx - inner_r, cy - inner_r), (cx + inner_r, cy + inner_r)], fill=(38, 42, 50, 255), outline=(190, 155, 75, 180), width=1)

        # Indicatore
        rad = math.radians(angle_deg)
        ix1 = cx + math.cos(rad) * (inner_r * 0.3)
        iy1 = cy + math.sin(rad) * (inner_r * 0.3)
        ix2 = cx + math.cos(rad) * (inner_r * 0.9)
        iy2 = cy + math.sin(rad) * (inner_r * 0.9)
        draw.line([(ix1, iy1), (ix2, iy2)], fill=color, width=2)

        # Etichetta e Valore
        draw.text((cx, cy - radius - 14), label, fill=(180, 185, 195, 255), anchor="mm")
        draw.rounded_rectangle([(cx - 30, cy + radius + 6), (cx + 30, cy + radius + 22)], radius=3, fill=(10, 12, 14, 255), outline=(60, 50, 30, 255), width=1)
        draw.text((cx, cy + radius + 14), val_text, fill=(255, 230, 150, 255), anchor="mm")

    # Helper per selettore rotativo a scatti (Chicken-Head / Step Switch)
    def draw_stepper(cx, cy, label, options, sel_idx, color):
        draw.text((cx, cy - 24), label, fill=(180, 185, 195, 255), anchor="mm")
        draw.rounded_rectangle([(cx - 80, cy - 10), (cx + 80, cy + 14)], radius=4, fill=(22, 25, 30, 255), outline=(50, 55, 65, 255), width=1)
        draw.text((cx, cy + 2), options[sel_idx], fill=color, anchor="mm")

    # BAY 1 CONTROLS
    b1_x = margin + bay_w // 2
    draw_knob(b1_x, bay_y + 75, 34, "THRESHOLD", "-12.0 dB", (255, 215, 0), 230)
    draw_stepper(b1_x, bay_y + 160, "TOPOLOGY", ["VCA MASTER", "DIODE-BRIDGE"], 0, (255, 215, 0))
    draw_stepper(b1_x, bay_y + 215, "DETECTION", ["FEEDFORWARD (SSL)", "FEEDBACK (Neve)"], 0, (255, 215, 0))
    draw_stepper(b1_x, bay_y + 270, "RATIO", ["1.5:1", "2:1 (Glue)", "4:1", "10:1"], 1, (255, 215, 0))

    # BAY 2 CONTROLS
    b2_x = margin + (bay_w + b_gap) + bay_w // 2
    draw_stepper(b2_x, bay_y + 65, "ATTACK", ["0.1 ms", "0.3 ms", "1.0 ms", "3.0 ms", "10 ms", "30 ms"], 4, (255, 165, 32))
    draw_stepper(b2_x, bay_y + 130, "RELEASE", ["0.1 s", "0.3 s", "0.6 s", "1.2 s", "AUTO (2-Stage)"], 4, (255, 165, 32))
    draw_stepper(b2_x, bay_y + 195, "SC FILTER", ["Off", "HPF 60 Hz", "HPF 90 Hz", "HPF 150 Hz", "THRUST TILT"], 4, (255, 165, 32))
    # Toggle switch EXT SC
    draw.rounded_rectangle([(b2_x - 55, bay_y + 250), (b2_x + 55, bay_y + 274)], radius=4, fill=(20, 24, 28, 255), outline=(60, 65, 75, 255))
    draw.text((b2_x, bay_y + 262), "EXT SC: OFF", fill=(150, 155, 165, 255), anchor="mm")

    # BAY 3 CONTROLS
    b3_x = margin + (bay_w + b_gap) * 2 + bay_w // 2
    draw_knob(b3_x, bay_y + 75, 34, "MAKEUP GAIN", "+2.5 dB", (255, 215, 0), 195)
    draw_knob(b3_x, bay_y + 160, 26, "DRIVE", "35%", (255, 60, 50), 220)
    draw_stepper(b3_x, bay_y + 225, "TRANSFORMER CORE", ["IRON (Marinair)", "NICKEL (Jensen)", "STEEL (USA)"], 0, (255, 120, 100))
    # Toggle switch CEILING CLIP
    draw.rounded_rectangle([(b3_x - 65, bay_y + 272), (b3_x + 65, bay_y + 294)], radius=4, fill=(28, 20, 20, 255), outline=(200, 50, 50, 255))
    draw.text((b3_x, bay_y + 283), "CEILING CLIP (-0.1)", fill=(255, 80, 80, 255), anchor="mm")

    # BAY 4 CONTROLS
    b4_x = margin + (bay_w + b_gap) * 3 + bay_w // 2
    draw_knob(b4_x - 45, bay_y + 85, 25, "WIDTH", "115%", (0, 230, 165), 235)
    draw_knob(b4_x + 45, bay_y + 85, 25, "MONO-MKR", "100 Hz", (0, 230, 165), 215)
    draw_knob(b4_x, bay_y + 215, 34, "PARALLEL MIX", "100%", (0, 230, 165), 390)

    for p in out_paths:
        os.makedirs(os.path.dirname(os.path.abspath(p)), exist_ok=True)
        img.save(p, "PNG")
        print(f"[PREVIEW SALVATA]: {p}")

if __name__ == "__main__":
    brain_dir = r"C:\Users\171Studio\.gemini\antigravity\brain\e19b20f6-fcdd-41bc-abd0-938055cf415e"
    project_dir = r"C:\Users\171Studio\Desktop\171 PLUGIN INNOVATIO GUI AND DSP\projects\171MasterGlue"
    
    paths = [
        os.path.join(brain_dir, "171masterglue_gui_preview.png"),
        os.path.join(project_dir, "171MasterGlue_GUI_Preview.png")
    ]
    create_preview(paths)
