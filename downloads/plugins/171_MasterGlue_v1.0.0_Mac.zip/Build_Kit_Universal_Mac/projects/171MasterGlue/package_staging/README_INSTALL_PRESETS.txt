﻿====================================================================
 171MASTERGLUE v1.0.0 (Win64) - Discrete Analog Master Bus Console & Imager
 171 Studio Innovatio GUI & DSP Suite
====================================================================

CONTENUTO DEL PACCHETTO:
1. VST3/171MasterGlue.vst3
   Copiare la cartella in:
   C:\Program Files\Common Files\VST3\

2. Standalone/171MasterGlue.exe
   Applicazione standalone a latenza zero per test e mastering autonomo.

CARATTERISTICHE PRINCIPALI:
- Dual-Topology Dynamics: VCA Master (SSL 4000 G) vs Diode-Bridge (Neve 33609/2254)
- Thrust Filter Bank: HPF 60/90/150 Hz + API-style Thrust (+3 dB/oct tilt)
- Marinair LO1166 Summing Transformer Saturation con isteresi magnetica a 2 stadi DC block
- TrueSpace Stereo Imager (0-150%) con Mono-Maker ZDF SVF 12-dB/oct ed elliptical phase protection limiter (r_LR >= +0.20)
- Mastering Safety Soft-Clipper (-0.1 dBFS ceiling)
- Dual Vintage Galvanometric Analog VU Meters (In/Out & Gain Reduction con balistica IEC 60268-17)
- GUI Boutique 171 Studio: Chassis alluminio anodizzato militare opaco scuro, quadranti in pergamena crema con retroilluminazione al tungsteno, manopole in metallo zigrinato a 36 denti.

PRESET DI FABBRICA INCLUSI:
1. Master Bus Glue (SSL Punch)
2. Drum Bus Glue & Iron
3. Warm Acoustic Diode-Bridge
4. Parallel NYC Crusher
5. Wide & Loud Master
====================================================================
