#include "PluginProcessor.h"
#include "PluginEditor.h"

AudioPluginAudioProcessorEditor::AudioPluginAudioProcessorEditor(AudioPluginAudioProcessor& p)
    : AudioProcessorEditor(&p), processorRef(p), mainPanel(p)
{
    addAndMakeVisible(mainPanel);
    setResizable(true, true);
    setResizeLimits(720, 450, 1920, 1200);
    setSize(960, 600);
}

AudioPluginAudioProcessorEditor::~AudioPluginAudioProcessorEditor() {}

void AudioPluginAudioProcessorEditor::paint(juce::Graphics& g) {
    g.fillAll(juce::Colour(0xff0d0e10));
}

void AudioPluginAudioProcessorEditor::resized() {
    mainPanel.setBounds(getLocalBounds());
}
