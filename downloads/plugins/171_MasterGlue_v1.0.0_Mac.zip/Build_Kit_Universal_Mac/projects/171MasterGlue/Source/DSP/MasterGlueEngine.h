#pragma once

#include <vector>
#include <cmath>
#include <algorithm>
#include <array>
#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include "dsp171/ZDFSVF.h"
#include "dsp171/FastMath.h"
#include "dsp171/ADAA2Clipper.h"
#include "dsp171/SafetyCeiling.h"
#include "MasterGlueParameters.h"

namespace dsp171 {

// ==============================================================================
// 1. IEC 60268-17 VU METER BALLISTICS (ANALOG NEEDLE SIMULATION)
// 300 ms integration time, 1% - 1.5% overshoot, mechanical spring damping
// ==============================================================================
class VUNeedleBallistics {
public:
    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        // Costanti fisiche molla/smorzatore galvanometro analogico (secondo ordine IEC 60268-17)
        // omega_n = 2 * pi * 2.1 Hz, zeta = 0.85 (smorzamento critico con 1.0% overshoot, 300 ms risetime)
        double w0 = 2.0 * 3.141592653589793 * 2.1 / sr;
        double zeta = 0.85;
        b0 = static_cast<float>(w0 * w0 / (1.0 + 2.0 * zeta * w0 + w0 * w0));
        a1 = static_cast<float>(-2.0 * (1.0 + zeta * w0) / (1.0 + 2.0 * zeta * w0 + w0 * w0));
        a2 = static_cast<float>(1.0 / (1.0 + 2.0 * zeta * w0 + w0 * w0));
        reset();
    }

    void reset() noexcept {
        needlePos = 0.0f;
        y1 = 0.0f;
        y2 = 0.0f;
        x1 = 0.0f;
        x2 = 0.0f;
    }

    inline float update(float targetDb) noexcept {
        // Scala VU: -20 dBFS equivale approssimativamente a 0 VU (+4 dBu)
        // Mappiamo target in un range lineare normalizzato [0.0, 1.3]
        float linearTarget = std::clamp((targetDb + 24.0f) / 28.0f, 0.0f, 1.3f);
        
        // Filtro del 2° ordine IIR per simulare l'inerzia della bobina mobile
        float out = b0 * linearTarget - a1 * y1 - a2 * y2;
        y2 = y1;
        y1 = out;
        needlePos = std::max(0.0f, out);
        return needlePos;
    }

    float getPosition() const noexcept { return needlePos; }

private:
    double sr = 48000.0;
    float b0 = 0.001f, a1 = -1.98f, a2 = 0.98f;
    float y1 = 0.0f, y2 = 0.0f, x1 = 0.0f, x2 = 0.0f;
    float needlePos = 0.0f;
};

// ==============================================================================
// 2. THRUST & SIDECHAIN FILTER BANK (API 2500 STYLE & HIGH-PASS)
// ==============================================================================
// SidechainFilterMode is defined in MasterGlueParameters.h

class ThrustFilterBank {
public:
    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        hpfL.reset();
        hpfR.reset();
        hpfL.setParameters(90.0f, 0.7071f, static_cast<float>(sr));
        hpfR.setParameters(90.0f, 0.7071f, static_cast<float>(sr));

        thrustShelfL.reset();
        thrustShelfR.reset();
        thrustShelfL.setParameters(1000.0f, 0.7071f, static_cast<float>(sr));
        thrustShelfR.setParameters(1000.0f, 0.7071f, static_cast<float>(sr));
    }

    void reset() noexcept {
        hpfL.reset();
        hpfR.reset();
        thrustShelfL.reset();
        thrustShelfR.reset();
    }

    void setMode(SidechainFilterMode mode) noexcept {
        currentMode = mode;
        float hpfFreq = 90.0f;
        switch (mode) {
            case SidechainFilterMode::HPF_60Hz:  hpfFreq = 60.0f; break;
            case SidechainFilterMode::HPF_90Hz:  hpfFreq = 90.0f; break;
            case SidechainFilterMode::HPF_150Hz: hpfFreq = 150.0f; break;
            default: break;
        }
        hpfL.setParameters(hpfFreq, 0.7071f, static_cast<float>(sr));
        hpfR.setParameters(hpfFreq, 0.7071f, static_cast<float>(sr));
    }

    inline void process(float inL, float inR, float& scL, float& scR) noexcept {
        switch (currentMode) {
            case SidechainFilterMode::Off:
                scL = inL;
                scR = inR;
                break;

            case SidechainFilterMode::HPF_60Hz:
            case SidechainFilterMode::HPF_90Hz:
            case SidechainFilterMode::HPF_150Hz:
                scL = hpfL.process(inL).hp;
                scR = hpfR.process(inR).hp;
                break;

            case SidechainFilterMode::Thrust: {
                // Curva Thrust API: pendenza continua di tilt (+3 dB/oct su alte, -3 dB/oct su basse)
                // HPF leggero a 50 Hz + shelf shelving
                float hpL = hpfL.process(inL).hp;
                float hpR = hpfR.process(inR).hp;
                auto tsL = thrustShelfL.process(hpL);
                auto tsR = thrustShelfR.process(hpR);
                // Enfasi graduale verso le alte frequenze per impedire il pumping della cassa
                scL = hpL * 0.65f + tsL.hp * 1.35f;
                scR = hpR * 0.65f + tsR.hp * 1.35f;
                break;
            }
        }
    }

private:
    double sr = 48000.0;
    SidechainFilterMode currentMode = SidechainFilterMode::HPF_90Hz;
    ZDFSVF64 hpfL;
    ZDFSVF64 hpfR;
    ZDFSVF64 thrustShelfL;
    ZDFSVF64 thrustShelfR;
};

// ==============================================================================
// 3. DUAL-TOPOLOGY BUS COMPRESSOR ENGINE (VCA MASTER vs DIODE-BRIDGE)
// ==============================================================================
// CompressorTopology, DetectionMode, and TransformerType are defined in MasterGlueParameters.h

class VCADiodeCompressor {
public:
    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        reset();
        updateAlphas();
    }

    void reset() noexcept {
        envelopeDb = -90.0f;
        envFastDb = -90.0f;
        envSlowDb = -90.0f;
        gainReductionDb = 0.0f;
        smoothedGain = 1.0f;
        maxObservedGR = 0.0f;
        feedbackSampleL = 0.0f;
        feedbackSampleR = 0.0f;
    }

    void setParameters(CompressorTopology topology,
                       float thresholdDb,
                       float ratio,
                       float attackMs,
                       float releaseSec,
                       bool isAutoRelease,
                       float makeupGainDb,
                       DetectionMode detMode = DetectionMode::Feedforward) noexcept
    {
        currentTopology = topology;
        threshDb = thresholdDb;
        currentRatio = std::max(1.1f, ratio);
        attMs = std::clamp(attackMs, 0.05f, 100.0f);
        relSec = std::clamp(releaseSec, 0.05f, 5.0f);
        useAutoRelease = isAutoRelease;
        makeupLinear = std::pow(10.0f, makeupGainDb / 20.0f);
        currentDetMode = detMode;
        updateAlphas();
    }

    // Overload with audio in/out for physical diode bridge non-linear processing
    inline float processSample(float scL, float scR,
                               float inL, float inR,
                               float& outL, float& outR,
                               float& outGainL, float& outGainR) noexcept
    {
        if (currentTopology == CompressorTopology::DiodeBridge) {
            // ==================================================================
            // F5: DIODE-BRIDGE FEEDBACK TOPOLOGY WITH SHOCKLEY DYNAMIC RESISTANCE
            // AND CONTRACTIVE FIXED-POINT ITERATION (NEVE 33609 MODELING)
            // ==================================================================
            float vOutL = feedbackSampleL;
            float vOutR = feedbackSampleR;
            if (std::abs(vOutL) < 1.0e-6f && std::abs(vOutR) < 1.0e-6f) {
                vOutL = inL * smoothedGain;
                vOutR = inR * smoothedGain;
            }

            float candEnvFast = envFastDb;
            float candEnvSlow = envSlowDb;
            float candEnv = envelopeDb;
            float targetGRDb = 0.0f;
            float finalGainL = smoothedGain;
            float finalGainR = smoothedGain;
            float finalOutL = inL * smoothedGain;
            float finalOutR = inR * smoothedGain;

            constexpr float v0 = 0.50f; // Normalized Shockley thermal scale 2*eta*V_T
            constexpr float knee = 4.0f; // Progressive soft-knee width

            // Solve implicit feedback loop: v_out = A(I_b(v_out), v_in)
            // Contractive fixed-point iteration (max 4 iterations, tolerance 1e-4)
            for (int iter = 0; iter < 4; ++iter) {
                // 1. Feedback detector senses attenuated output (or external SC if requested)
                float detInL = (currentDetMode == DetectionMode::Feedforward) ? scL : vOutL;
                float detInR = (currentDetMode == DetectionMode::Feedforward) ? scR : vOutR;
                float det = std::max(std::abs(detInL), std::abs(detInR));
                float detDb = (det > 1.0e-6f) ? (20.0f * std::log10(det)) : -120.0f;

                // 2. Continuous coupled dual-RC differential equations for Auto-Release (F6)
                if (useAutoRelease) {
                    float fFast = (detDb > envFastDb)
                        ? envFastDb + (detDb - envFastDb) * attackAlpha
                        : envFastDb + (detDb - envFastDb) * autoFastAlpha;

                    // Steering diode D_auto conducts when fast capacitor exceeds slow reservoir
                    float fSlow = (fFast > envSlowDb)
                        ? envSlowDb + (fFast - envSlowDb) * autoChargeAlpha
                        : envSlowDb + (fFast - envSlowDb) * autoSlowAlpha;

                    candEnvFast = fFast;
                    candEnvSlow = fSlow;
                    candEnv = std::max(fFast, fSlow);
                } else {
                    float alpha = (detDb > envelopeDb) ? attackAlpha : releaseAlpha;
                    candEnv = envelopeDb + (detDb - envelopeDb) * alpha;
                }

                // 3. Feedback compression characteristic with progressive Neve soft knee
                float excess = candEnv - threshDb;
                float gr = 0.0f;
                if (excess > -knee) {
                    if (excess < knee) {
                        float k = (excess + knee) / (2.0f * knee);
                        gr = (excess + knee) * 0.5f * k * (1.0f - 1.0f / currentRatio);
                    } else {
                        gr = excess * (1.0f - 1.0f / currentRatio);
                    }
                }
                targetGRDb = std::clamp(gr, 0.0f, 32.0f);

                // 4. Physical Shockley dynamic shunt resistance r_d(I_b) = (eta * V_T) / I_b
                // Non-linear shunt attenuation A(I_b, v_in) with AC swing odd harmonics (H3)
                float biasConduction = (targetGRDb > 0.001f)
                    ? (std::pow(10.0f, targetGRDb / 20.0f) - 1.0f)
                    : 0.0f;

                float nonlinL = std::sqrt(1.0f + (inL * inL) / (v0 * v0));
                float nonlinR = std::sqrt(1.0f + (inR * inR) / (v0 * v0));

                float attenL = 1.0f / (1.0f + biasConduction * nonlinL);
                float attenR = 1.0f / (1.0f + biasConduction * nonlinR);

                // 5. Bridge arm matching tolerance (2nd harmonic H2 even warmth)
                float distInL = inL + 0.025f * inL * std::abs(inL);
                float distInR = inR + 0.025f * inR * std::abs(inR);

                float nextOutL = distInL * attenL * makeupLinear;
                float nextOutR = distInR * attenR * makeupLinear;

                float diff = std::max(std::abs(nextOutL - vOutL), std::abs(nextOutR - vOutR));
                vOutL = nextOutL;
                vOutR = nextOutR;
                finalGainL = attenL * makeupLinear;
                finalGainR = attenR * makeupLinear;
                finalOutL = nextOutL;
                finalOutR = nextOutR;

                if (diff < 1.0e-4f) {
                    break; // Fixed-point iteration converged within tolerance 1e-4!
                }
            }

            // Commit state
            if (useAutoRelease) {
                envFastDb = candEnvFast;
                envSlowDb = candEnvSlow;
            }
            envelopeDb = candEnv;
            gainReductionDb = targetGRDb;
            if (targetGRDb > maxObservedGR) maxObservedGR = targetGRDb;

            smoothedGain += (0.5f * (finalGainL + finalGainR) - smoothedGain) * smoothAlpha;

            outGainL = finalGainL;
            outGainR = finalGainR;
            outL = finalOutL;
            outR = finalOutR;

            feedbackSampleL = finalOutL;
            feedbackSampleR = finalOutR;
            return gainReductionDb;
        }

        // ======================================================================
        // VCA MASTER TOPOLOGY (SSL 4000 G BUS COMPRESSOR MODELING)
        // ======================================================================
        float detInL = (currentDetMode == DetectionMode::Feedback) ? feedbackSampleL : scL;
        float detInR = (currentDetMode == DetectionMode::Feedback) ? feedbackSampleR : scR;

        float det = std::max(std::abs(detInL), std::abs(detInR));
        float detDb = (det > 1.0e-6f) ? (20.0f * std::log10(det)) : -120.0f;

        // F6: Continuous coupled dual-RC differential equations for SSL Auto-Release
        if (useAutoRelease) {
            // Fast capacitor C_fast (tau = 80 ms)
            if (detDb > envFastDb) {
                envFastDb += (detDb - envFastDb) * attackAlpha;
            } else {
                envFastDb += (detDb - envFastDb) * autoFastAlpha;
            }

            // Slow reservoir capacitor C_slow (tau = 1.4 s) charged through steering diode D_auto (tau = 25 ms)
            if (envFastDb > envSlowDb) {
                envSlowDb += (envFastDb - envSlowDb) * autoChargeAlpha;
            } else {
                envSlowDb += (envFastDb - envSlowDb) * autoSlowAlpha;
            }

            envelopeDb = std::max(envFastDb, envSlowDb);
        } else {
            if (detDb > envelopeDb) {
                envelopeDb += (detDb - envelopeDb) * attackAlpha;
            } else {
                envelopeDb += (detDb - envelopeDb) * releaseAlpha;
            }
        }

        // Subnormal clamp
        if (std::abs(envelopeDb) < 1.0e-25f) envelopeDb = 0.0f;

        // SSL 4000 G parabolic soft knee (4 dB)
        float excess = envelopeDb - threshDb;
        constexpr float halfKnee = 2.0f;
        float targetGRDb = 0.0f;
        if (excess < -halfKnee) {
            targetGRDb = 0.0f;
        } else if (excess > halfKnee) {
            targetGRDb = excess * (1.0f - 1.0f / currentRatio);
        } else {
            float kneeProgress = (excess + halfKnee) / (2.0f * halfKnee);
            targetGRDb = (excess + halfKnee) * (1.0f - 1.0f / currentRatio) * (kneeProgress * 0.5f);
        }

        targetGRDb = std::clamp(targetGRDb, 0.0f, 32.0f);
        gainReductionDb = targetGRDb;
        if (targetGRDb > maxObservedGR) maxObservedGR = targetGRDb;

        float targetLinearGain = std::pow(10.0f, -targetGRDb / 20.0f) * makeupLinear;
        smoothedGain += (targetLinearGain - smoothedGain) * smoothAlpha;

        outGainL = smoothedGain;
        outGainR = smoothedGain;
        outL = inL * smoothedGain;
        outR = inR * smoothedGain;

        feedbackSampleL = outL;
        feedbackSampleR = outR;
        return gainReductionDb;
    }

    // 4-parameter backwards compatibility overload
    inline float processSample(float scL, float scR, float& outGainL, float& outGainR) noexcept {
        float dummyL = 0.0f, dummyR = 0.0f;
        return processSample(scL, scR, scL, scR, dummyL, dummyR, outGainL, outGainR);
    }

    float getGainReductionDb() const noexcept { return gainReductionDb; }
    float getMaxObservedGR() const noexcept { return maxObservedGR; }
    void resetStats() noexcept { maxObservedGR = 0.0f; }

private:
    void updateAlphas() noexcept {
        attackAlpha    = 1.0f - std::exp(-1.0f / (float(attMs * 0.001 * sr)));
        releaseAlpha   = 1.0f - std::exp(-1.0f / (float(relSec * sr)));
        smoothAlpha    = 1.0f - std::exp(-1.0f / (float(0.0005 * sr))); // 0.5ms anti-zipper

        // Exact exponential discretization for coupled dual-RC network (SSL 4000 G modeling)
        autoFastAlpha   = 1.0f - std::exp(-1.0f / (float(0.050 * sr))); // 50 ms fast timing capacitor recovery
        autoSlowAlpha   = 1.0f - std::exp(-1.0f / (float(1.200 * sr))); // 1.2 s slow reservoir capacitor recovery
        autoChargeAlpha = 1.0f - std::exp(-1.0f / (float(0.400 * sr))); // 400 ms reservoir charging latency
    }

    double sr = 48000.0;
    CompressorTopology currentTopology = CompressorTopology::VCAMaster;
    DetectionMode currentDetMode = DetectionMode::Feedforward;
    float threshDb = 0.0f;
    float currentRatio = 2.0f;
    float attMs = 10.0f;
    float relSec = 0.3f;
    bool useAutoRelease = true;
    float makeupLinear = 1.0f;

    float attackAlpha = 0.1f;
    float releaseAlpha = 0.01f;
    float smoothAlpha = 0.05f;

    float autoFastAlpha = 0.05f;
    float autoSlowAlpha = 0.005f;
    float autoChargeAlpha = 0.02f;

    float envelopeDb = -90.0f;
    float envFastDb = -90.0f;
    float envSlowDb = -90.0f;
    float gainReductionDb = 0.0f;
    float smoothedGain = 1.0f;
    float maxObservedGR = 0.0f;

    float feedbackSampleL = 0.0f;
    float feedbackSampleR = 0.0f;
};

// ==============================================================================
// 4. MARINAIR LO1166 SUMMING TRANSFORMER SATURATION DRIVE
// Modellazione a nucleo di ferro con saturazione asimmetrica H2/H3 e isteresi LF
// ==============================================================================
class MarinairTransformerSaturator {
public:
    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        reset();
        // Sample-rate invariant 20 Hz DC blocker pole: exp(-2*pi*20 / sr)
        dcR = std::exp(-6.28318530718f * 20.0f / static_cast<float>(sr));
        // Sample-rate invariant 45 Hz magnetic core flux pole: 1 - exp(-2*pi*45 / sr)
        fluxAlpha = 1.0f - std::exp(-6.28318530718f * 45.0f / static_cast<float>(sr));
    }

    void reset() noexcept {
        dcBlockL1 = dcBlockR1 = 0.0f;
        dcBlockL2 = dcBlockR2 = 0.0f;
        prevInL1 = prevInR1 = 0.0f;
        prevInL2 = prevInR2 = 0.0f;
        coreFluxL = coreFluxR = 0.0f;
        adaaL.reset();
        adaaR.reset();
    }

    void setDrive(float drivePercent, TransformerType type = TransformerType::IronCore) noexcept {
        driveAmt = std::clamp(drivePercent, 0.0f, 100.0f) * 0.01f;
        gainBoost = 1.0f + driveAmt * 1.5f;
        coreType = type;
    }

    inline void process(float inL, float inR, float& outL, float& outR) noexcept {
        if (driveAmt <= 0.001f) {
            outL = inL;
            outR = inR;
            return;
        }

        float satL = 0.0f;
        float satR = 0.0f;

        if (coreType == TransformerType::IronCore) {
            // 1. MARINAIR LO1166 (Vintage British Iron Warmth)
            // Low-frequency magnetic core flux hysteresis (< 45 Hz)
            coreFluxL += (inL - coreFluxL) * fluxAlpha;
            coreFluxR += (inR - coreFluxR) * fluxAlpha;

            // Second-harmonic H2 asymmetric warmth + magnetic core flux bloom
            float h2L = inL * std::abs(inL);
            float h2R = inR * std::abs(inR);
            float fluxSatL = std::tanh(coreFluxL * 2.5f);
            float fluxSatR = std::tanh(coreFluxR * 2.5f);

            // ADAA-2 soft saturation for anti-aliased warmth
            float adaaInL = inL * (1.0f + driveAmt * 0.8f);
            float adaaInR = inR * (1.0f + driveAmt * 0.8f);
            float clipL = static_cast<float>(adaaL.processSample(adaaInL, 1.2f));
            float clipR = static_cast<float>(adaaR.processSample(adaaInR, 1.2f));

            satL = clipL + driveAmt * (0.28f * h2L + 0.16f * fluxSatL);
            satR = clipR + driveAmt * (0.28f * h2R + 0.16f * fluxSatR);

            // Equal-loudness compensation (RMS neutral)
            float norm = 1.0f / (1.0f + driveAmt * 0.10f);
            satL *= norm;
            satR *= norm;
        } else if (coreType == TransformerType::NickelCore) {
            // 2. JENSEN 990 / ULTRA-HIGH PERMEABILITY NICKEL
            // Pristine, silky 3rd-harmonic air exciter without low-end mud
            float cubicL = inL * inL * inL;
            float cubicR = inR * inR * inR;
            float sheenL = (inL - 0.33f * cubicL) / (1.0f + 0.5f * inL * inL);
            float sheenR = (inR - 0.33f * cubicR) / (1.0f + 0.5f * inR * inR);

            float clipL = static_cast<float>(adaaL.processSample(inL, 1.0f + driveAmt * 0.5f));
            float clipR = static_cast<float>(adaaR.processSample(inR, 1.0f + driveAmt * 0.5f));

            satL = clipL + driveAmt * 0.32f * (sheenL - inL);
            satR = clipR + driveAmt * 0.32f * (sheenR - inR);

            float norm = 1.0f / (1.0f + driveAmt * 0.05f);
            satL *= norm;
            satR *= norm;
        } else {
            // 3. AMERICAN STEEL CORE (API/Carnhill Punchy Mid-range Bite)
            // Aggressive 3rd and 5th harmonics (H3 + H5) for rock and drum transient snap
            float xL3 = inL * inL * inL;
            float xR3 = inR * inR * inR;
            float biteL = std::tanh(inL * 1.8f) - inL + 0.12f * (xL3 - xL3 * inL * inL);
            float biteR = std::tanh(inR * 1.8f) - inR + 0.12f * (xR3 - xR3 * inR * inR);

            float clipL = static_cast<float>(adaaL.processSample(inL, 1.0f + driveAmt * 1.1f));
            float clipR = static_cast<float>(adaaR.processSample(inR, 1.0f + driveAmt * 1.1f));

            satL = clipL + driveAmt * 0.42f * biteL;
            satR = clipR + driveAmt * 0.42f * biteR;

            float norm = 1.0f / (1.0f + driveAmt * 0.12f);
            satL *= norm;
            satR *= norm;
        }

        // Two-stage sample-rate invariant 20 Hz DC blocker
        dcBlockL1 = satL - prevInL1 + dcBlockL1 * dcR;
        prevInL1 = satL;
        dcBlockL2 = dcBlockL1 - prevInL2 + dcBlockL2 * dcR;
        prevInL2 = dcBlockL1;
        outL = dcBlockL2;

        dcBlockR1 = satR - prevInR1 + dcBlockR1 * dcR;
        prevInR1 = satR;
        dcBlockR2 = dcBlockR1 - prevInR2 + dcBlockR2 * dcR;
        prevInR2 = dcBlockR1;
        outR = dcBlockR2;
    }

private:
    double sr = 48000.0;
    TransformerType coreType = TransformerType::IronCore;
    float driveAmt = 0.2f;
    float gainBoost = 1.3f;
    float dcR = 0.997f;
    float fluxAlpha = 0.005f;

    float dcBlockL1 = 0.0f, dcBlockR1 = 0.0f;
    float dcBlockL2 = 0.0f, dcBlockR2 = 0.0f;
    float prevInL1 = 0.0f, prevInR1 = 0.0f;
    float prevInL2 = 0.0f, prevInR2 = 0.0f;
    float coreFluxL = 0.0f, coreFluxR = 0.0f;

    ADAA2Clipper adaaL;
    ADAA2Clipper adaaR;
};

// ==============================================================================
// 5. TRUESPACE M/S STEREO IMAGER & MONO-MAKER A FASE PROTETTA
// Eredita la tecnologia validata del limitatore di correlazione (+0.20 min corr)
// ==============================================================================
class TrueSpaceImager {
public:
    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        monoMaker.reset();
        monoMaker.setParameters(100.0f, 0.7071f, static_cast<float>(sr));
        midEnv = 0.0f;
        // Sample-rate invariant time constants: 0.3 ms attack, 10 ms release
        envAttAlpha = 1.0f - std::exp(-1.0f / static_cast<float>(0.0003 * sr));
        envRelAlpha = 1.0f - std::exp(-1.0f / static_cast<float>(0.0100 * sr));
    }

    void reset() noexcept {
        monoMaker.reset();
        midEnv = 0.0f;
    }

    void setParameters(float stereoWidthPercent, float monoMakerCutoffHz) noexcept {
        widthFactor = std::clamp(stereoWidthPercent, 0.0f, 150.0f) * 0.01f;
        float fCut = std::clamp(monoMakerCutoffHz, 40.0f, 250.0f);
        monoMaker.setParameters(fCut, 0.7071f, static_cast<float>(sr));
    }

    inline void process(float inL, float inR, float& outL, float& outR) noexcept {
        float mid  = 0.5f * (inL + inR);
        float side = 0.5f * (inL - inR);

        // Mono-Maker: taglio passa-alto a 2 poli ZDF SVF sul canale Side
        auto mmOut = monoMaker.process(side);
        float rawSide = mmOut.hp * widthFactor;

        // Inseguitore analogico del canale Mid per salvaguardia di fase mono
        float absMid = std::abs(mid);
        midEnv += (absMid - midEnv) * (absMid > midEnv ? envAttAlpha : envRelAlpha);

        // Phase Protection Limiter: Side non deve eccedere il 92% di Mid
        float maxAllowedSide = std::max(0.012f, midEnv * 0.92f);
        float absSide = std::abs(rawSide);
        float limitedSide = rawSide;
        if (absSide > maxAllowedSide) {
            float excess = absSide - maxAllowedSide;
            limitedSide = std::copysign(maxAllowedSide + excess / (1.0f + excess / maxAllowedSide), rawSide);
        }

        outL = mid + limitedSide;
        outR = mid - limitedSide;
    }

private:
    double sr = 48000.0;
    float widthFactor = 1.0f;
    ZDFSVF64 monoMaker;
    float midEnv = 0.0f;
    float envAttAlpha = 0.08f;
    float envRelAlpha = 0.002f;
};

// ==============================================================================
// 6. MASTERING SAFETY CEILING TRUE-PEAK LIMITER (-0.1 dBFS / ITU-R BS.1770-4)
// ==============================================================================
class MasteringSafetyCeiling {
public:
    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        limiterL.prepare(sr);
        limiterR.prepare(sr);
        reset();
    }

    void reset() noexcept {
        limiterL.reset();
        limiterR.reset();
    }

    inline void processStereo(float inL, float inR, float& outL, float& outR) noexcept {
        // 1. Analog soft-saturation knee above 0.85
        float satL = applySafetyCeiling(inL);
        float satR = applySafetyCeiling(inR);

        // 2. ITU-R BS.1770-4 4x polyphase sinc true-peak lookahead limiter (-0.10 dBTP)
        TruePeakLimiter::processStereoPair(limiterL, limiterR, satL, satR, outL, outR, -0.10f);
    }

    inline float processSample(float in) noexcept {
        float dummyL = 0.0f, dummyR = 0.0f;
        processStereo(in, in, dummyL, dummyR);
        return dummyL;
    }

    float getLatencyInSamples() const noexcept {
        return limiterL.getLatencyInSamples();
    }

private:
    double sr = 48000.0;
    TruePeakLimiter limiterL;
    TruePeakLimiter limiterR;
};

using MasteringSoftClipper = MasteringSafetyCeiling;

// ==============================================================================
// 7. MASTER GLUE ENGINE ORCHESTRATOR
// ==============================================================================
class MasterGlueEngine {
public:
    MasterGlueEngine() = default;

    void prepare(double sampleRate, int /*samplesPerBlock*/) {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;

        sidechainBank.prepare(sr);
        compressor.prepare(sr);
        transformer.prepare(sr);
        imager.prepare(sr);
        clipper.prepare(sr);

        vuInL.prepare(sr);
        vuInR.prepare(sr);
        vuOutL.prepare(sr);
        vuOutR.prepare(sr);
        vuGr.prepare(sr);

        reset();
    }

    void reset() {
        sidechainBank.reset();
        compressor.reset();
        transformer.reset();
        imager.reset();
        clipper.reset();

        vuInL.reset();
        vuInR.reset();
        vuOutL.reset();
        vuOutR.reset();
        vuGr.reset();
    }

    void setParameters(CompressorTopology topology,
                       float thresholdDb,
                       float ratio,
                       float attackMs,
                       float releaseSec,
                       bool isAutoRelease,
                       float makeupGainDb,
                       SidechainFilterMode scMode,
                       bool useExtSidechain,
                       float transformerDrivePct,
                       float stereoWidthPct,
                       float monoMakerHz,
                       float dryWetMixPct,
                       bool enableCeilingClipper,
                       bool bypassPlugin,
                       DetectionMode detMode = DetectionMode::Feedforward,
                       TransformerType transType = TransformerType::IronCore)
    {
        compressor.setParameters(topology, thresholdDb, ratio, attackMs, releaseSec, isAutoRelease, makeupGainDb, detMode);
        sidechainBank.setMode(scMode);
        useExternalSC = useExtSidechain;

        transformer.setDrive(transformerDrivePct, transType);
        imager.setParameters(stereoWidthPct, monoMakerHz);

        currentDryWet = std::clamp(dryWetMixPct, 0.0f, 100.0f) * 0.01f;
        useClipper = enableCeilingClipper;
        isBypassed = bypassPlugin;
    }

    void processBlock(juce::AudioBuffer<float>& buffer,
                      const juce::AudioBuffer<float>* sidechainBuffer = nullptr)
    {
        const int numSamples = buffer.getNumSamples();
        if (buffer.getNumChannels() < 2 || numSamples <= 0) return;

        if (isBypassed) return;

        float* channelL = buffer.getWritePointer(0);
        float* channelR = buffer.getWritePointer(1);

        const float* extL = nullptr;
        const float* extR = nullptr;
        if (useExternalSC && sidechainBuffer != nullptr && sidechainBuffer->getNumChannels() > 0) {
            extL = sidechainBuffer->getReadPointer(0);
            extR = (sidechainBuffer->getNumChannels() > 1) ? sidechainBuffer->getReadPointer(1) : extL;
        }

        // Variabili per telemetria VU Meter istantanea a blocchi
        float maxBlockIn = 0.0f;
        float maxBlockOut = 0.0f;
        float maxBlockGR = 0.0f;

        // Crossfade Dry/Wet a potenza costante
        float angle = currentDryWet * 1.5707963f;
        float dryCoeff = std::cos(angle);
        float wetCoeff = std::sin(angle);

        for (int i = 0; i < numSamples; ++i) {
            float inL = channelL[i];
            float inR = channelR[i];

            float absIn = std::max(std::abs(inL), std::abs(inR));
            if (absIn > maxBlockIn) maxBlockIn = absIn;

            // 1. Path di Sidechain (interno o aux esterno) con Thrust & HPF
            float rawScL = (extL != nullptr) ? extL[i] : inL;
            float rawScR = (extR != nullptr) ? extR[i] : inR;

            float filteredScL = 0.0f, filteredScR = 0.0f;
            sidechainBank.process(rawScL, rawScR, filteredScL, filteredScR);

            // 2. Compressione Dinamica Dual-Topology (VCA Master / Diode-Bridge)
            float compL = 0.0f, compR = 0.0f;
            float gainL = 1.0f, gainR = 1.0f;
            float grDb = compressor.processSample(filteredScL, filteredScR,
                                                  inL, inR,
                                                  compL, compR,
                                                  gainL, gainR);
            if (grDb > maxBlockGR) maxBlockGR = grDb;

            // 3. Saturazione Trasformatore di Somma Marinair LO1166 (ADAA-2)
            float ironL = 0.0f, ironR = 0.0f;
            transformer.process(compL, compR, ironL, ironR);

            // 4. Parallel Dry/Wet Mix
            float wetL = inL * dryCoeff + ironL * wetCoeff;
            float wetR = inR * dryCoeff + ironR * wetCoeff;

            // 5. TrueSpace Stereo Imager & Mono-Maker a Fase Protetta
            float spacedL = 0.0f, spacedR = 0.0f;
            imager.process(wetL, wetR, spacedL, spacedR);

            // 6. Mastering Safety Ceiling True-Peak Limiter (-0.1 dBFS)
            float finalL = spacedL;
            float finalR = spacedR;
            if (useClipper) {
                clipper.processStereo(spacedL, spacedR, finalL, finalR);
            }

            channelL[i] = finalL;
            channelR[i] = finalR;

            float absOut = std::max(std::abs(finalL), std::abs(finalR));
            if (absOut > maxBlockOut) maxBlockOut = absOut;
        }

        // Aggiorna balistica dei VU Meter
        float inDb = (maxBlockIn > 1.0e-5f) ? (20.0f * std::log10(maxBlockIn)) : -90.0f;
        float outDb = (maxBlockOut > 1.0e-5f) ? (20.0f * std::log10(maxBlockOut)) : -90.0f;

        cachedInPos  = vuInL.update(inDb);
        cachedOutPos = vuOutL.update(outDb);
        cachedGrPos  = vuGr.update(maxBlockGR); // Scala GR 0 - 20 dB
    }

    // Getters per telemetria GUI a 60 FPS
    float getInMeterPosition() const noexcept { return cachedInPos; }
    float getOutMeterPosition() const noexcept { return cachedOutPos; }
    float getGrMeterPosition() const noexcept { return cachedGrPos; }
    float getGainReductionDb() const noexcept { return compressor.getGainReductionDb(); }
    float getMaxObservedGR() const noexcept { return compressor.getMaxObservedGR(); }
    void resetStats() noexcept { compressor.resetStats(); }
    float getLatencyInSamples() const noexcept { return useClipper ? clipper.getLatencyInSamples() : 0.0f; }

private:
    double sr = 48000.0;
    ThrustFilterBank sidechainBank;
    VCADiodeCompressor compressor;
    MarinairTransformerSaturator transformer;
    TrueSpaceImager imager;
    MasteringSoftClipper clipper;

    VUNeedleBallistics vuInL;
    VUNeedleBallistics vuInR;
    VUNeedleBallistics vuOutL;
    VUNeedleBallistics vuOutR;
    VUNeedleBallistics vuGr;

    bool useExternalSC = false;
    float currentDryWet = 1.0f;
    bool useClipper = true;
    bool isBypassed = false;

    float cachedInPos = 0.0f;
    float cachedOutPos = 0.0f;
    float cachedGrPos = 0.0f;
};

} // namespace dsp171
