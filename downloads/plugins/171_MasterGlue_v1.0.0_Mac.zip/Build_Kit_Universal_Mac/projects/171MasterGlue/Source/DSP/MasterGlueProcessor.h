#pragma once
#include "MasterGlueEngine.h"
#include "MasterGlueParameters.h"

namespace dsp171 {

// MasterGlueProcessor provides a high-level wrapper and parameter configuration
// contract for the 171MasterGlue DSP Engine.
using MasterGlueProcessor = MasterGlueEngine;

} // namespace dsp171
