#pragma once
#include <cstdint>

namespace dsp171 {

// ==============================================================================
// 171MasterGlue DSP Parameter & Mode Enumerations
// ==============================================================================

enum class CompressorTopology : uint8_t {
    VCAMaster = 0,    // SSL 4000 G Master Bus (Feedforward, Decibel-linear VCA punch)
    DiodeBridge       // Neve 33609 / 2254 (Feedback, Shockley dynamic shunt resistance)
};

enum class DetectionMode : uint8_t {
    Feedforward = 0,  // Modern SSL Style (detector senses pre-VCA input)
    Feedback          // Vintage Neve / API Style (detector senses post-attenuation output)
};

enum class SidechainFilterMode : uint8_t {
    Off = 0,
    HPF_60Hz,
    HPF_90Hz,
    HPF_150Hz,
    Thrust            // API 2500 continuous spectral tilt (+3 dB/oct highs, -3 dB/oct lows)
};

enum class TransformerType : uint8_t {
    IronCore = 0,     // Marinair LO1166 (Vintage British Iron Warmth & LF flux saturation)
    NickelCore,       // Jensen 990 (Clean, open airy sheen, minimal LF hysteresis)
    SteelCore         // American Steel (Punchy low-mid grit & rich odd harmonics)
};

} // namespace dsp171
