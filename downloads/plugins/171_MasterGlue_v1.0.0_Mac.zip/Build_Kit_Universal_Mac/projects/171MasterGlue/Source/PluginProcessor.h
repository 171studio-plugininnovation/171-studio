#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include "DSP/MasterGlueEngine.h"
#include <atomic>

class AudioPluginAudioProcessor : public juce::AudioProcessor {
public:
    AudioPluginAudioProcessor();
    ~AudioPluginAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;

    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "171MasterGlue"; }

    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.5; }

    int getNumPrograms() override { return 5; }
    int getCurrentProgram() override { return currentProgram; }
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() { return apvts; }

    // Telemetria visuale thread-safe per la GUI e i VU meter galvanometrici
    float getVisualInMeter() const noexcept { return visualInMeter.load(std::memory_order_relaxed); }
    float getVisualOutMeter() const noexcept { return visualOutMeter.load(std::memory_order_relaxed); }
    float getVisualGrMeter() const noexcept { return visualGrMeter.load(std::memory_order_relaxed); }
    float getVisualGainReductionDb() const noexcept { return visualGainReductionDb.load(std::memory_order_relaxed); }
    int getVisualTopology() const noexcept { return visualTopology.load(std::memory_order_relaxed); }

private:
    juce::AudioProcessorValueTreeState apvts;
    juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    dsp171::MasterGlueEngine engine;
    int currentProgram = 0;

    std::atomic<float> visualInMeter { 0.0f };
    std::atomic<float> visualOutMeter { 0.0f };
    std::atomic<float> visualGrMeter { 0.0f };
    std::atomic<float> visualGainReductionDb { 0.0f };
    std::atomic<int> visualTopology { 0 };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AudioPluginAudioProcessor)
};
