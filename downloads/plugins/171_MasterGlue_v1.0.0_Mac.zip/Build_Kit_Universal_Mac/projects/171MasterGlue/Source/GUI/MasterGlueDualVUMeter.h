#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <cmath>
#include <algorithm>

namespace plugin_171 {

// ==============================================================================
// DUAL GALVANOMETRIC ANALOG VU METERS (IEC 60268-17 NEEDLE BALLISTICS)
// Left Meter: Audio Input / Output Level (-20 to +3 VU)
// Right Meter: Master Bus Gain Reduction (0 to -20 dB GR)
// ==============================================================================
class MasterGlueDualVUMeter : public juce::Component {
public:
    MasterGlueDualVUMeter() {
        setOpaque(false);
    }

    ~MasterGlueDualVUMeter() override = default;

    void setLevels(float inMeterPos, float outMeterPos, float grMeterPos, float rawGrDb) noexcept {
        targetInPos  = std::clamp(inMeterPos, 0.0f, 1.3f);
        targetOutPos = std::clamp(outMeterPos, 0.0f, 1.3f);
        targetGrPos  = std::clamp(grMeterPos, 0.0f, 1.3f);
        currentGrDb  = rawGrDb;

        // Inerzia dell'ago (smorzamento a 60 FPS)
        needleLevel += (targetInPos - needleLevel) * 0.22f;
        needleGr    += (targetGrPos - needleGr) * 0.25f;

        repaint();
    }

    void setShowOutput(bool showOut) noexcept {
        showOutputMeter = showOut;
        repaint();
    }

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat();
        if (bounds.isEmpty()) return;

        const float gap = 16.0f;
        const float meterWidth = (bounds.getWidth() - gap) * 0.5f;
        const float meterHeight = bounds.getHeight();

        // 1. VU Meter Sinistro (Livello Audio In / Out)
        auto leftMeterBounds = juce::Rectangle<float>(bounds.getX(), bounds.getY(), meterWidth, meterHeight);
        drawSingleMeter(g, leftMeterBounds, showOutputMeter ? "OUTPUT VU" : "INPUT VU", needleLevel, false);

        // 2. VU Meter Destro (Gain Reduction)
        auto rightMeterBounds = juce::Rectangle<float>(bounds.getX() + meterWidth + gap, bounds.getY(), meterWidth, meterHeight);
        drawSingleMeter(g, rightMeterBounds, "GAIN REDUCTION", needleGr, true);
    }

private:
    void drawSingleMeter(juce::Graphics& g, juce::Rectangle<float> rect, const juce::String& title, float normPos, bool isGR) {
        g.saveState();

        // 1. Cornice esterna in metallo brunito / ottone
        g.setColour(juce::Colour(0xff1a1816));
        g.fillRoundedRectangle(rect, 8.0f);

        g.setColour(juce::Colour(0xff453d36));
        g.drawRoundedRectangle(rect, 8.0f, 2.0f);

        auto dialArea = rect.reduced(4.0f);

        // 2. Fondo quadrante in pergamena crema vintage invecchiata
        juce::ColourGradient dialGrad(
            juce::Colour(0xfff7f2e6), dialArea.getCentreX(), dialArea.getY() + 10.0f,
            juce::Colour(0xffe5dcc8), dialArea.getCentreX(), dialArea.getBottom(), false);
        g.setGradientFill(dialGrad);
        g.fillRoundedRectangle(dialArea, 6.0f);

        // 3. Luce ambra/tungsteno calda soffusa interna (Vintage Bulb Glow)
        juce::ColourGradient lampGlow(
            juce::Colour(0x66ffbe40), dialArea.getCentreX(), dialArea.getY() + 12.0f,
            juce::Colour(0x05ffb833), dialArea.getCentreX(), dialArea.getBottom() - 10.0f, true);
        g.setGradientFill(lampGlow);
        g.fillRoundedRectangle(dialArea, 6.0f);

        // LED Indicatore di Stato (Peak Red su Meter L / Active Amber su Meter R)
        if (!isGR) {
            bool isPeakOverload = (normPos >= 0.95f);
            float ledX = dialArea.getRight() - 20.0f;
            float ledY = dialArea.getY() + 14.0f;
            if (isPeakOverload) {
                // Glow rosso acceso per picchi oltre 0 VU
                g.setColour(juce::Colour(0x77ff2222));
                g.fillEllipse(ledX - 5.0f, ledY - 5.0f, 16.0f, 16.0f);
                g.setColour(juce::Colour(0xffff2020));
                g.fillEllipse(ledX - 3.0f, ledY - 3.0f, 12.0f, 12.0f);
                g.setColour(juce::Colour(0xffffffff));
                g.fillEllipse(ledX - 1.0f, ledY - 1.0f, 4.0f, 4.0f);
            } else {
                g.setColour(juce::Colour(0xff3d1a1a));
                g.fillEllipse(ledX - 3.0f, ledY - 3.0f, 12.0f, 12.0f);
                g.setColour(juce::Colour(0xff552222));
                g.drawEllipse(ledX - 3.0f, ledY - 3.0f, 12.0f, 12.0f, 1.0f);
            }
            g.setFont(juce::FontOptions(dialArea.getHeight() * 0.065f, juce::Font::bold));
            g.setColour(isPeakOverload ? juce::Colour(0xffff4444) : juce::Colour(0xff776655));
            g.drawText("PEAK", ledX - 28.0f, ledY - 5.0f, 25.0f, 12.0f, juce::Justification::centredRight);
        } else {
            bool isGRActive = (currentGrDb >= 0.5f);
            float ledX = dialArea.getX() + 10.0f;
            float ledY = dialArea.getY() + 14.0f;
            if (isGRActive) {
                g.setColour(juce::Colour(0x66ffaa00));
                g.fillEllipse(ledX - 5.0f, ledY - 5.0f, 16.0f, 16.0f);
                g.setColour(juce::Colour(0xffffb300));
                g.fillEllipse(ledX - 3.0f, ledY - 3.0f, 12.0f, 12.0f);
                g.setColour(juce::Colour(0xfffff2cc));
                g.fillEllipse(ledX - 1.0f, ledY - 1.0f, 4.0f, 4.0f);
            } else {
                g.setColour(juce::Colour(0xff382e18));
                g.fillEllipse(ledX - 3.0f, ledY - 3.0f, 12.0f, 12.0f);
                g.setColour(juce::Colour(0xff4a3d20));
                g.drawEllipse(ledX - 3.0f, ledY - 3.0f, 12.0f, 12.0f, 1.0f);
            }
            g.setFont(juce::FontOptions(dialArea.getHeight() * 0.065f, juce::Font::bold));
            g.setColour(isGRActive ? juce::Colour(0xffffc107) : juce::Colour(0xff776655));
            g.drawText("ACTIVE", ledX + 12.0f, ledY - 5.0f, 36.0f, 12.0f, juce::Justification::left);
        }

        // 4. Arco e serigrafia della scala graduata
        const float pivotX = dialArea.getCentreX();
        const float pivotY = dialArea.getBottom() + dialArea.getHeight() * 0.45f;
        const float radius = dialArea.getHeight() * 1.15f;

        float angleMin = -0.58f; // -33 gradi
        float angleMax =  0.58f; // +33 gradi

        // Arco nero
        juce::Path arcPath;
        arcPath.addCentredArc(pivotX, pivotY, radius, radius, 0.0f, angleMin, angleMax, true);
        g.setColour(juce::Colour(0xff2b2824));
        g.strokePath(arcPath, juce::PathStrokeType(1.6f));

        // Arco rosso (Danger zone oltre lo 0 VU)
        if (!isGR) {
            float angleZero = angleMin + (angleMax - angleMin) * (20.0f / 23.0f);
            juce::Path redArc;
            redArc.addCentredArc(pivotX, pivotY, radius + 0.5f, radius + 0.5f, 0.0f, angleZero, angleMax, true);
            g.setColour(juce::Colour(0xffc92a2a));
            g.strokePath(redArc, juce::PathStrokeType(2.5f));
        }

        // Tacche e numeri serigrafati
        g.setColour(juce::Colour(0xff2b2824));
        g.setFont(juce::FontOptions(dialArea.getHeight() * 0.09f, juce::Font::bold));

        if (!isGR) {
            // Scala Livello Audio: -20, -10, -7, -5, -3, -2, -1, 0, +1, +2, +3
            static const float tickVals[] = { 0.0f, 0.25f, 0.45f, 0.60f, 0.73f, 0.869f, 1.0f };
            static const char* tickLabels[] = { "-20", "-10", "-5", "-3", "-1", "0", "+3" };
            for (int i = 0; i < 7; ++i) {
                float a = angleMin + (angleMax - angleMin) * tickVals[i];
                float x1 = pivotX + std::sin(a) * (radius - 4.0f);
                float y1 = pivotY - std::cos(a) * (radius - 4.0f);
                float x2 = pivotX + std::sin(a) * (radius + 4.0f);
                float y2 = pivotY - std::cos(a) * (radius + 4.0f);

                if (i >= 5) g.setColour(juce::Colour(0xffc92a2a));
                else g.setColour(juce::Colour(0xff2b2824));

                g.drawLine(x1, y1, x2, y2, (i == 5) ? 2.0f : 1.2f);

                float lx = pivotX + std::sin(a) * (radius - 14.0f);
                float ly = pivotY - std::cos(a) * (radius - 14.0f);
                g.drawText(tickLabels[i], lx - 15.0f, ly - 8.0f, 30.0f, 16.0f, juce::Justification::centred);
            }
        } else {
            // Scala Gain Reduction: 0 (a destra o a riposo), -1, -2, -3, -5, -7, -10, -15, -20
            // Nel VU GR classico l'ago a riposo (0 dB GR) sta a destra (+30 deg) e scende a sinistra!
            static const float tickValsGR[] = { 0.0f, 0.15f, 0.30f, 0.48f, 0.65f, 0.82f, 1.0f };
            static const char* tickLabelsGR[] = { "0", "1", "3", "5", "8", "12", "20" };
            for (int i = 0; i < 7; ++i) {
                // Inversione: 0 dB a destra (angleMax), 20 dB a sinistra (angleMin)
                float a = angleMax - (angleMax - angleMin) * tickValsGR[i];
                float x1 = pivotX + std::sin(a) * (radius - 4.0f);
                float y1 = pivotY - std::cos(a) * (radius - 4.0f);
                float x2 = pivotX + std::sin(a) * (radius + 4.0f);
                float y2 = pivotY - std::cos(a) * (radius + 4.0f);

                g.setColour(juce::Colour(0xff2b2824));
                g.drawLine(x1, y1, x2, y2, (i == 0) ? 2.0f : 1.2f);

                float lx = pivotX + std::sin(a) * (radius - 14.0f);
                float ly = pivotY - std::cos(a) * (radius - 14.0f);
                g.drawText(tickLabelsGR[i], lx - 15.0f, ly - 8.0f, 30.0f, 16.0f, juce::Justification::centred);
            }
        }

        // Titolo Meter
        g.setColour(juce::Colour(0xff524a42));
        g.setFont(juce::FontOptions(dialArea.getHeight() * 0.10f, juce::Font::bold));
        g.drawText(title, dialArea.getX(), dialArea.getY() + dialArea.getHeight() * 0.42f,
                   dialArea.getWidth(), 20.0f, juce::Justification::centred);

        // 5. Calcolo Angolo Ago Galvanometrico con Fisica Inerziale
        float needleAngle = 0.0f;
        if (!isGR) {
            float clamped = std::clamp(normPos, 0.0f, 1.25f);
            needleAngle = angleMin + (angleMax - angleMin) * (clamped / 1.15f);
        } else {
            // Gain reduction: 0 dB = angleMax, 20 dB = angleMin
            float clampedGR = std::clamp(currentGrDb / 20.0f, 0.0f, 1.0f);
            needleAngle = angleMax - (angleMax - angleMin) * clampedGR;
        }

        // Ombra dell'ago (proiezione realistica)
        const float tipRadius = radius - 6.0f;
        const float tipX = pivotX + std::sin(needleAngle) * tipRadius;
        const float tipY = pivotY - std::cos(needleAngle) * tipRadius;

        g.setColour(juce::Colour(0x35000000));
        g.drawLine(pivotX + 2.0f, pivotY + 2.0f, tipX + 2.5f, tipY + 2.5f, 2.0f);

        // Corpo dell'ago in metallo nero opaco con punta rossa
        g.setColour(juce::Colour(0xff181715));
        g.drawLine(pivotX, pivotY, tipX, tipY, 1.8f);

        g.setColour(juce::Colour(0xffd92323));
        float pX = pivotX + std::sin(needleAngle) * (tipRadius - 12.0f);
        float pY = pivotY - std::cos(needleAngle) * (tipRadius - 12.0f);
        g.drawLine(pX, pY, tipX, tipY, 2.2f);

        // Perno centrale con vite tornita in ottone
        g.setColour(juce::Colour(0xff1e1c19));
        g.fillEllipse(pivotX - 9.0f, pivotY - 9.0f, 18.0f, 18.0f);

        g.setColour(juce::Colour(0xffc5a059));
        g.fillEllipse(pivotX - 5.0f, pivotY - 5.0f, 10.0f, 10.0f);

        g.setColour(juce::Colour(0xff332b1d));
        g.drawEllipse(pivotX - 5.0f, pivotY - 5.0f, 10.0f, 10.0f, 1.0f);

        // 6. Riflesso curvo di vetro smerigliato sul quadrante
        juce::Path glarePath;
        glarePath.addCentredArc(dialArea.getCentreX(), dialArea.getY() - dialArea.getHeight() * 0.3f,
                                dialArea.getWidth() * 0.9f, dialArea.getHeight() * 0.9f,
                                0.0f, -0.6f, 0.6f, true);
        g.setColour(juce::Colour(0x18ffffff));
        g.strokePath(glarePath, juce::PathStrokeType(dialArea.getHeight() * 0.35f));

        g.restoreState();
    }

    float targetInPos = 0.0f;
    float targetOutPos = 0.0f;
    float targetGrPos = 0.0f;
    float currentGrDb = 0.0f;

    float needleLevel = 0.0f;
    float needleGr = 0.0f;
    bool showOutputMeter = false;
};

} // namespace plugin_171
