#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_graphics/juce_graphics.h>
#include <BinaryData.h>
#include <cmath>
#include <algorithm>
#include "BoutiqueHardwareLookAndFeel.h"
#include "BoutiqueHardwareComponents.h"
#include "MasterGlueDualVUMeter.h"
#include "ResizableHandleComponent.h"
#include "../PluginProcessor.h"

namespace MasterGlueBinaryData = BinaryData;

namespace plugin_171 {

// ==============================================================================
// 171 MASTER GLUE BOUTIQUE HARDWARE LOOK AND FEEL
// Knurled metal dials, chicken-head stepped switches, gold/amber trims
// ==============================================================================
class MasterGlueBoutiqueLookAndFeel : public juce::LookAndFeel_V4 {
public:
    enum class KnobTheme {
        GoldDynamics,    // Threshold, Makeup, Ratio
        AmberSidechain,  // Attack, Release, Sidechain HPF
        CrimsonDrive,    // Transformer Drive
        EmeraldSpatial   // Stereo Width, Mono-Maker, Mix
    };

    MasterGlueBoutiqueLookAndFeel() {
        setColour(juce::Slider::textBoxTextColourId, juce::Colour(0xffffe899));
        setColour(juce::Slider::textBoxBackgroundColourId, juce::Colour(0xff090c10));
        setColour(juce::Slider::textBoxOutlineColourId, juce::Colour(0xff524021));
        setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff12161f));
        setColour(juce::ComboBox::outlineColourId, juce::Colour(0xff6e5428));
        setColour(juce::ComboBox::textColourId, juce::Colour(0xffffe899));
        setColour(juce::ComboBox::arrowColourId, juce::Colour(0xffd4af37));
        setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xff12151c));
        setColour(juce::PopupMenu::textColourId, juce::Colour(0xffffe899));
        setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xff2a3444));
        setColour(juce::PopupMenu::highlightedTextColourId, juce::Colour(0xffffffff));
    }

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPosProportional, float rotaryStartAngle, float rotaryEndAngle,
                          juce::Slider& slider) override
    {
        const auto bounds = juce::Rectangle<float>((float)x, (float)y, (float)width, (float)height);
        if (bounds.isEmpty()) return;

        KnobTheme theme = KnobTheme::GoldDynamics;
        if (slider.getProperties().contains("Theme")) {
            theme = static_cast<KnobTheme>((int)slider.getProperties()["Theme"]);
        }

        juce::Colour glowCol = juce::Colour(0xffffd700);
        switch (theme) {
            case KnobTheme::GoldDynamics:   glowCol = juce::Colour(0xffffd700); break;
            case KnobTheme::AmberSidechain: glowCol = juce::Colour(0xffffa520); break;
            case KnobTheme::CrimsonDrive:   glowCol = juce::Colour(0xffff3b30); break;
            case KnobTheme::EmeraldSpatial: glowCol = juce::Colour(0xff00e5a3); break;
        }

        float textBoxHeight = 18.0f;
        auto knobArea = bounds;
        if (slider.getTextBoxPosition() == juce::Slider::TextBoxBelow) {
            knobArea.removeFromBottom(textBoxHeight);
        }

        const float diameter = juce::jmin(knobArea.getWidth(), knobArea.getHeight());
        const float cx = knobArea.getCentreX();
        const float cy = knobArea.getCentreY();
        const float rBase = diameter * 0.44f;

        const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

        // 1. Pista serigrafata circolare
        const float rTrack = rBase + 1.5f;
        juce::Path trackPath;
        trackPath.addCentredArc(cx, cy, rTrack, rTrack, 0.0f, rotaryStartAngle, rotaryEndAngle, true);
        g.setColour(juce::Colour(0xff0c0e12));
        g.strokePath(trackPath, juce::PathStrokeType(3.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // Arco attivo luminoso
        if (sliderPosProportional > 0.005f) {
            juce::Path activePath;
            activePath.addCentredArc(cx, cy, rTrack, rTrack, 0.0f, rotaryStartAngle, angle, true);
            g.setColour(glowCol.withAlpha(0.30f));
            g.strokePath(activePath, juce::PathStrokeType(6.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            g.setColour(glowCol);
            g.strokePath(activePath, juce::PathStrokeType(2.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }

        // Tacche graduate
        const int numTicks = 11;
        for (int i = 0; i < numTicks; ++i) {
            float tAngle = rotaryStartAngle + (float)i / (float)(numTicks - 1) * (rotaryEndAngle - rotaryStartAngle);
            float tR1 = rBase + 4.0f;
            float tR2 = rBase + ((i == 0 || i == numTicks - 1 || i == 5) ? 9.0f : 6.0f);
            float tx1 = cx + std::sin(tAngle) * tR1;
            float ty1 = cy - std::cos(tAngle) * tR1;
            float tx2 = cx + std::sin(tAngle) * tR2;
            float ty2 = cy - std::cos(tAngle) * tR2;

            g.setColour(tAngle <= angle ? glowCol.withAlpha(0.85f) : juce::Colour(0x60888888));
            g.drawLine(tx1, ty1, tx2, ty2, (i == 0 || i == numTicks - 1 || i == 5) ? 1.6f : 1.0f);
        }

        // 2. Ombra portata della manopola
        g.setColour(juce::Colour(0x60000000));
        g.fillEllipse(cx - rBase + 2.0f, cy - rBase + 4.0f, rBase * 2.0f, rBase * 2.0f);

        // 3. Render Manopola Ufficiale 171 Studio in Acciaio Satinato Nero
        auto knobImg = juce::ImageCache::getFromMemory(MasterGlueBinaryData::knob_171_steel_satin_128_png,
                                                       MasterGlueBinaryData::knob_171_steel_satin_128_pngSize);
        if (knobImg.isValid()) {
            float knobDiam = rBase * 2.0f;
            float imgW = (float)knobImg.getWidth();
            float imgH = (float)knobImg.getHeight();
            auto transform = juce::AffineTransform::rotation(angle, imgW * 0.5f, imgH * 0.5f)
                .translated(cx - imgW * 0.5f, cy - imgH * 0.5f)
                .scaled(knobDiam / imgW, knobDiam / imgH, cx, cy);
            g.drawImageTransformed(knobImg, transform);
        } else {
            // Fallback procedurale PBR
            const int numTeeth = 36;
            for (int t = 0; t < numTeeth; ++t) {
                float toothAngle = (float)t * 6.2831853f / (float)numTeeth;
                float toothR1 = rBase - 2.5f;
                float toothR2 = rBase;
                float x1 = cx + std::sin(toothAngle) * toothR1;
                float y1 = cy - std::cos(toothAngle) * toothR1;
                float x2 = cx + std::sin(toothAngle) * toothR2;
                float y2 = cy - std::cos(toothAngle) * toothR2;
                g.setColour(t % 2 == 0 ? juce::Colour(0xff2e333d) : juce::Colour(0xff121418));
                g.drawLine(x1, y1, x2, y2, 2.0f);
            }

            const float rInner = rBase - 2.8f;
            juce::ColourGradient metalGrad(
                juce::Colour(0xff3b404b), cx - rInner * 0.4f, cy - rInner * 0.4f,
                juce::Colour(0xff15181e), cx + rInner * 0.6f, cy + rInner * 0.6f, false);
            g.setGradientFill(metalGrad);
            g.fillEllipse(cx - rInner, cy - rInner, rInner * 2.0f, rInner * 2.0f);

            g.setColour(juce::Colour(0xffc5a059).withAlpha(0.65f));
            g.drawEllipse(cx - rInner, cy - rInner, rInner * 2.0f, rInner * 2.0f, 1.2f);
        }

        // 4. Tacca indicatrice incisa e illuminata
        const float indR1 = rBase * 0.35f;
        const float indR2 = rBase * 0.95f;
        const float ix1 = cx + std::sin(angle) * indR1;
        const float iy1 = cy - std::cos(angle) * indR1;
        const float ix2 = cx + std::sin(angle) * indR2;
        const float iy2 = cy - std::cos(angle) * indR2;

        g.setColour(juce::Colour(0x90000000));
        g.drawLine(ix1 + 1.0f, iy1 + 1.0f, ix2 + 1.0f, iy2 + 1.0f, 3.2f);
        g.setColour(glowCol);
        g.drawLine(ix1, iy1, ix2, iy2, 2.2f);
    }
};

// ==============================================================================
// 171 MASTER GLUE BOUTIQUE MAIN EDITOR
// ==============================================================================
class MasterGlueMainPanel : public juce::Component, private juce::Timer {
public:
    MasterGlueMainPanel(AudioPluginAudioProcessor& p) : processor(p) {
        setLookAndFeel(&lookAndFeel);

        // Inizializza VU Meter
        addAndMakeVisible(vuMeters);

        // Inizializza Manopole e Controlli
        setupSlider(sliderThreshold, "threshold", "THRESHOLD", MasterGlueBoutiqueLookAndFeel::KnobTheme::GoldDynamics, "dB");
        setupSlider(sliderMakeup, "makeup", "MAKEUP", MasterGlueBoutiqueLookAndFeel::KnobTheme::GoldDynamics, "dB");

        setupSlider(sliderDrive, "transformer_drive", "DRIVE", MasterGlueBoutiqueLookAndFeel::KnobTheme::CrimsonDrive, "%");
        setupSlider(sliderWidth, "stereo_width", "WIDTH", MasterGlueBoutiqueLookAndFeel::KnobTheme::EmeraldSpatial, "%");
        setupSlider(sliderMonoMaker, "mono_maker", "MONO-MAKER", MasterGlueBoutiqueLookAndFeel::KnobTheme::EmeraldSpatial, "Hz");
        setupSlider(sliderMix, "dry_wet", "PARALLEL MIX", MasterGlueBoutiqueLookAndFeel::KnobTheme::EmeraldSpatial, "%");

        // Selettori a Scatti
        setupChoice(comboTopology, "topology", "TOPOLOGY");
        setupChoice(comboDetectionMode, "detection_mode", "DETECTION");
        setupChoice(comboRatio, "ratio", "RATIO");
        setupChoice(comboAttack, "attack", "ATTACK");
        setupChoice(comboRelease, "release", "RELEASE");
        setupChoice(comboSidechain, "sidechain_filter", "SC FILTER");
        setupChoice(comboTransformerType, "transformer_type", "CORE TYPE");

        // Pulsanti Toggle
        setupToggle(btnExtSidechain, "ext_sidechain", "EXT SC");
        setupToggle(btnClipper, "soft_clipper", "CEILING CLIP");
        setupToggle(btnBypass, "bypass", "BYPASS");

        // Presets Combo
        presetBox.addItemList({
            "1. Master Bus Glue (SSL Classic)",
            "2. Warm Vintage Console (Neve Thick)",
            "3. Modern Hip-Hop & Trap Bus",
            "4. Acoustic & Vocal Master",
            "5. Parallel NYC Drum Punch"
        }, 1);
        presetBox.setSelectedId(1, juce::dontSendNotification);
        presetBox.onChange = [this]() {
            processor.setCurrentProgram(presetBox.getSelectedId() - 1);
        };
        addAndMakeVisible(presetBox);

        // Maniglia di Ridimensionamento
        addAndMakeVisible(resizeHandle);
        resizeHandle.onScaleChanged = [this](float) { repaint(); };

        startTimerHz(30); // 30 FPS telemetry: ultra-fluido, zero carico su message thread DAW
    }

    ~MasterGlueMainPanel() override {
        setLookAndFeel(nullptr);
    }

    void timerCallback() override {
        // Aggiorna telemetria dei VU meter galvanometrici
        float inPos  = processor.getVisualInMeter();
        float outPos = processor.getVisualOutMeter();
        float grPos  = processor.getVisualGrMeter();
        float grDb   = processor.getVisualGainReductionDb();

        vuMeters.setLevels(inPos, outPos, grPos, grDb);
    }

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat();
        if (bounds.isEmpty()) return;

        // 1. Sfondo e cornici decorative statiche da cache (0 ms CPU)
        if (backgroundCache.isValid()) {
            g.drawImageAt(backgroundCache, 0, 0);
        }

        // 2. Header & Targhetta 171 Studio con Logo Ufficiale
        auto headerArea = bounds.removeFromTop(62.0f);
        drawHeaderBadge(g, headerArea);
    }

    void rebuildBackgroundCache() {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        backgroundCache = juce::Image(juce::Image::ARGB, w, h, true);
        juce::Graphics g(backgroundCache);
        auto bounds = juce::Rectangle<float>(0, 0, (float)w, (float)h);

        // Chassis Alluminio Anodizzato Nero Opaco Militare
        juce::ColourGradient bgGrad(
            juce::Colour(0xff16181b), 0.0f, 0.0f,
            juce::Colour(0xff0d0e10), 0.0f, bounds.getHeight(), false);
        g.setGradientFill(bgGrad);
        g.fillRoundedRectangle(bounds, 10.0f);

        // Texture metallo spazzolato fine
        g.setColour(juce::Colour(0x06ffffff));
        for (float y = 0.0f; y < bounds.getHeight(); y += 3.0f) {
            g.drawHorizontalLine((int)y, 0.0f, bounds.getWidth());
        }

        // Bordo bisellato PBR esterno
        g.setColour(juce::Colour(0xff333842));
        g.drawRoundedRectangle(bounds.reduced(1.0f), 10.0f, 1.5f);

        // Viti Torx brunite nei 4 angoli
        drawScrew(g, 18.0f, 18.0f);
        drawScrew(g, bounds.getWidth() - 18.0f, 18.0f);
        drawScrew(g, 18.0f, bounds.getHeight() - 18.0f);
        drawScrew(g, bounds.getWidth() - 18.0f, bounds.getHeight() - 18.0f);

        // Cornici decorative dei 4 Bay Inferiori
        const float bayY = 270.0f;
        const float bayHeight = bounds.getHeight() - bayY - 18.0f;
        const float margin = 20.0f;
        const float gap = 12.0f;
        const float totalW = bounds.getWidth() - (margin * 2.0f) - (gap * 3.0f);
        const float bayW = totalW / 4.0f;

        drawBayPanel(g, juce::Rectangle<float>(margin, bayY, bayW, bayHeight), "1. DYNAMICS", juce::Colour(0xffffd700));
        drawBayPanel(g, juce::Rectangle<float>(margin + (bayW + gap), bayY, bayW, bayHeight), "2. TIMING & SC", juce::Colour(0xffffa520));
        drawBayPanel(g, juce::Rectangle<float>(margin + (bayW + gap) * 2.0f, bayY, bayW, bayHeight), "3. ANALOG COLOR", juce::Colour(0xffff3b30));
        drawBayPanel(g, juce::Rectangle<float>(margin + (bayW + gap) * 3.0f, bayY, bayW, bayHeight), "4. SPATIAL & MIX", juce::Colour(0xff00e5a3));
    }

    void resized() override {
        rebuildBackgroundCache();
        auto bounds = getLocalBounds();
        const float w = (float)bounds.getWidth();
        const float h = (float)bounds.getHeight();

        // Posizionamento Preset Box & Bypass nell'Header
        presetBox.setBounds(static_cast<int>(w - 310.0f), 18, 190, 26);
        btnBypass.setBounds(static_cast<int>(w - 105.0f), 18, 75, 26);

        // Posizionamento Doppio VU Meter (Centrato in alto)
        const int vuW = 560;
        const int vuH = 180;
        vuMeters.setBounds((bounds.getWidth() - vuW) / 2, 72, vuW, vuH);

        // Layout dei 4 Bay Inferiori
        const float bayY = 270.0f;
        const float bayHeight = h - bayY - 18.0f;
        const float margin = 20.0f;
        const float gap = 12.0f;
        const float totalW = w - (margin * 2.0f) - (gap * 3.0f);
        const float bayW = totalW / 4.0f;

        // BAY 1: DYNAMICS (Threshold, Topology, Detection, Ratio)
        auto b1 = juce::Rectangle<float>(margin, bayY, bayW, bayHeight);
        sliderThreshold.setBounds(static_cast<int>(b1.getX() + 10), static_cast<int>(b1.getY() + 30), static_cast<int>(b1.getWidth() - 20), 95);
        comboTopology.setBounds(static_cast<int>(b1.getX() + 15), static_cast<int>(b1.getY() + 132), static_cast<int>(b1.getWidth() - 30), 22);
        comboDetectionMode.setBounds(static_cast<int>(b1.getX() + 15), static_cast<int>(b1.getY() + 158), static_cast<int>(b1.getWidth() - 30), 22);
        comboRatio.setBounds(static_cast<int>(b1.getX() + 15), static_cast<int>(b1.getY() + 184), static_cast<int>(b1.getWidth() - 30), 22);

        // BAY 2: TIMING & SC (Attack, Release, SC Filter, Ext SC)
        auto b2 = juce::Rectangle<float>(margin + (bayW + gap), bayY, bayW, bayHeight);
        comboAttack.setBounds(static_cast<int>(b2.getX() + 15), static_cast<int>(b2.getY() + 36), static_cast<int>(b2.getWidth() - 30), 24);
        comboRelease.setBounds(static_cast<int>(b2.getX() + 15), static_cast<int>(b2.getY() + 86), static_cast<int>(b2.getWidth() - 30), 24);
        comboSidechain.setBounds(static_cast<int>(b2.getX() + 15), static_cast<int>(b2.getY() + 136), static_cast<int>(b2.getWidth() - 30), 24);
        btnExtSidechain.setBounds(static_cast<int>(b2.getX() + 25), static_cast<int>(b2.getY() + 180), static_cast<int>(b2.getWidth() - 50), 26);

        // BAY 3: ANALOG COLOR (Makeup, Drive, Transformer Type, Clipper)
        auto b3 = juce::Rectangle<float>(margin + (bayW + gap) * 2.0f, bayY, bayW, bayHeight);
        sliderMakeup.setBounds(static_cast<int>(b3.getX() + 10), static_cast<int>(b3.getY() + 30), static_cast<int>(b3.getWidth() - 20), 80);
        sliderDrive.setBounds(static_cast<int>(b3.getX() + 15), static_cast<int>(b3.getY() + 114), static_cast<int>(b3.getWidth() - 30), 65);
        comboTransformerType.setBounds(static_cast<int>(b3.getX() + 15), static_cast<int>(b3.getY() + 182), static_cast<int>(b3.getWidth() - 30), 22);
        btnClipper.setBounds(static_cast<int>(b3.getX() + 25), static_cast<int>(b3.getY() + 208), static_cast<int>(b3.getWidth() - 50), 22);

        // BAY 4: SPATIAL & MIX (Width, Mono-Maker, Mix)
        auto b4 = juce::Rectangle<float>(margin + (bayW + gap) * 3.0f, bayY, bayW, bayHeight);
        sliderWidth.setBounds(static_cast<int>(b4.getX() + 12), static_cast<int>(b4.getY() + 32), static_cast<int>(b4.getWidth() * 0.5f - 14), 85);
        sliderMonoMaker.setBounds(static_cast<int>(b4.getX() + b4.getWidth() * 0.5f + 2), static_cast<int>(b4.getY() + 32), static_cast<int>(b4.getWidth() * 0.5f - 14), 85);
        sliderMix.setBounds(static_cast<int>(b4.getX() + 15), static_cast<int>(b4.getY() + 130), static_cast<int>(b4.getWidth() - 30), 95);

        // Resize Handle in basso a destra
        resizeHandle.setBounds(bounds.getWidth() - 24, bounds.getHeight() - 24, 24, 24);
    }

private:
    void setupSlider(juce::Slider& s, const juce::String& paramID, const juce::String& name,
                     MasterGlueBoutiqueLookAndFeel::KnobTheme theme, const juce::String& suffix)
    {
        s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 65, 16);
        s.setTextValueSuffix(" " + suffix);
        s.getProperties().set("Theme", static_cast<int>(theme));
        s.setName(name);
        addAndMakeVisible(s);

        attachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            processor.getAPVTS(), paramID, s));
    }

    void setupChoice(juce::ComboBox& c, const juce::String& paramID, const juce::String& /*name*/) {
        auto* param = processor.getAPVTS().getParameter(paramID);
        if (auto* choiceParam = dynamic_cast<juce::AudioParameterChoice*>(param)) {
            c.addItemList(choiceParam->choices, 1);
        }
        addAndMakeVisible(c);
        comboAttachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(
            processor.getAPVTS(), paramID, c));
    }

    void setupToggle(juce::ToggleButton& b, const juce::String& paramID, const juce::String& text) {
        b.setButtonText(text);
        addAndMakeVisible(b);
        buttonAttachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
            processor.getAPVTS(), paramID, b));
    }

    void drawScrew(juce::Graphics& g, float x, float y) {
        g.setColour(juce::Colour(0xff0a0c0e));
        g.fillEllipse(x - 5.0f, y - 5.0f, 10.0f, 10.0f);
        g.setColour(juce::Colour(0xff2b303a));
        g.drawEllipse(x - 5.0f, y - 5.0f, 10.0f, 10.0f, 1.0f);
        g.setColour(juce::Colour(0xff1a1e24));
        g.drawLine(x - 3.0f, y, x + 3.0f, y, 1.4f);
        g.drawLine(x, y - 3.0f, x, y + 3.0f, 1.4f);
    }

    void drawHeaderBadge(juce::Graphics& g, juce::Rectangle<float> area) {
        // Logo ufficiale 171 Studio Gold Badge a sinistra dell'header
        auto badgeImg = juce::ImageCache::getFromMemory(MasterGlueBinaryData::badge_171_gold_180x60_png,
                                                        MasterGlueBinaryData::badge_171_gold_180x60_pngSize);
        if (badgeImg.isValid()) {
            g.drawImage(badgeImg, area.getX() + 25.0f, 15.0f, 85.0f, 28.0f, 0, 0, badgeImg.getWidth(), badgeImg.getHeight());
        }

        // Targhetta centrale in ottone dorato lucido
        const float badgeW = 390.0f;
        const float badgeH = 38.0f;
        auto badgeRect = juce::Rectangle<float>(area.getCentreX() - badgeW * 0.5f, 12.0f, badgeW, badgeH);

        juce::ColourGradient brassGrad(
            juce::Colour(0xffd4af37), badgeRect.getX(), badgeRect.getY(),
            juce::Colour(0xff8c6d23), badgeRect.getRight(), badgeRect.getBottom(), false);
        g.setGradientFill(brassGrad);
        g.fillRoundedRectangle(badgeRect, 5.0f);

        g.setColour(juce::Colour(0xffffe899));
        g.drawRoundedRectangle(badgeRect, 5.0f, 1.2f);

        // Titolo a rilievo
        g.setColour(juce::Colour(0xff121417));
        g.setFont(juce::FontOptions(16.0f, juce::Font::bold));
        g.drawText("171 MASTER GLUE", badgeRect.removeFromTop(20.0f), juce::Justification::centred);

        g.setFont(juce::FontOptions(10.5f, juce::Font::plain));
        g.drawText("DISCRETE ANALOG MASTER BUS CONSOLE & IMAGER", badgeRect, juce::Justification::centred);
    }

    void drawBayPanel(juce::Graphics& g, juce::Rectangle<float> rect, const juce::String& title, juce::Colour accentCol) {
        // Pannello incassato con finitura metallica scura
        g.setColour(juce::Colour(0xff101215));
        g.fillRoundedRectangle(rect, 6.0f);

        g.setColour(juce::Colour(0xff262b33));
        g.drawRoundedRectangle(rect, 6.0f, 1.2f);

        // Barra d'accento superiore
        auto bar = rect.removeFromTop(22.0f);
        g.setColour(juce::Colour(0xff181b20));
        g.fillRoundedRectangle(bar, 6.0f);

        g.setColour(accentCol);
        g.drawLine(bar.getX() + 6.0f, bar.getBottom(), bar.getRight() - 6.0f, bar.getBottom(), 1.5f);

        // Titolo del Bay
        g.setColour(juce::Colour(0xffe8e8e8));
        g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        g.drawText(title, bar, juce::Justification::centred);
    }

    AudioPluginAudioProcessor& processor;
    MasterGlueBoutiqueLookAndFeel lookAndFeel;

    MasterGlueDualVUMeter vuMeters;
    ResizableHandleComponent resizeHandle;

    juce::Slider sliderThreshold;
    juce::Slider sliderMakeup;
    juce::Slider sliderDrive;
    juce::Slider sliderWidth;
    juce::Slider sliderMonoMaker;
    juce::Slider sliderMix;

    juce::ComboBox comboTopology;
    juce::ComboBox comboDetectionMode;
    juce::ComboBox comboRatio;
    juce::ComboBox comboAttack;
    juce::ComboBox comboRelease;
    juce::ComboBox comboSidechain;
    juce::ComboBox comboTransformerType;

    juce::ToggleButton btnExtSidechain;
    juce::ToggleButton btnClipper;
    juce::ToggleButton btnBypass;
    juce::ComboBox presetBox;

    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> attachments;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> comboAttachments;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAttachments;

    juce::Image backgroundCache;
};

} // namespace plugin_171
