#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <cassert>
#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include "../DSP/MasterGlueEngine.h"

bool runTestSuiteForSampleRate(double sampleRate, int& outPassed, int& outTotal) {
    std::cout << "\n--------------------------------------------------------------------\n";
    std::cout << " [*] COLLAUDO FREQUENZA DI CAMPIONAMENTO: " << sampleRate << " Hz\n";
    std::cout << "--------------------------------------------------------------------\n";

    constexpr int blockSize = 512;
    int totalPass = 0;
    int totalTests = 10;

    dsp171::MasterGlueEngine engine;
    engine.prepare(sampleRate, blockSize);

    // --------------------------------------------------------------------------
    // TEST 1: VCA Master Mode Decibel Linearity & Gain Reduction
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 1: VCA Master Mode Decibel Linearity & Gain Reduction (" << sampleRate << " Hz)...";
    // Threshold: -12 dB, Ratio: 4:1, Attack: 10ms, Release: 300ms, Makeup: 0dB
    engine.setParameters(
        dsp171::CompressorTopology::VCAMaster,
        -12.0f, 4.0f, 10.0f, 0.3f, false, 0.0f,
        dsp171::SidechainFilterMode::Off, false,
        0.0f, 100.0f, 100.0f, 100.0f, true, false
    );
    engine.resetStats();

    // Segnale di prova a 1000 Hz con picco a -2 dBFS (eccesso di +10 dB sopra la soglia)
    // Con ratio 4:1, l'uscita oltre soglia deve essere compressa a 10/4 = 2.5 dB, quindi GR atteso ~ 7.5 dB
    int nTone1 = static_cast<int>(sampleRate);
    juce::AudioBuffer<float> testTone(2, nTone1);
    float inAmp = 0.7943f; // -2 dBFS
    for (int i = 0; i < nTone1; ++i) {
        float s = inAmp * std::sin(2.0f * 3.14159265f * 1000.0f * static_cast<float>(i) / static_cast<float>(sampleRate));
        testTone.setSample(0, i, s);
        testTone.setSample(1, i, s);
    }
    engine.processBlock(testTone);

    float observedGR = engine.getMaxObservedGR();
    if (observedGR >= 6.5f && observedGR <= 8.5f) {
        std::cout << " [SUPERATO] (GR osservato: " << observedGR << " dB, target: ~7.5 dB)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (GR: " << observedGR << " dB)\n";
    }

    // --------------------------------------------------------------------------
    // TEST 2: Diode-Bridge Mode Progressive Knee
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 2: Diode-Bridge Mode Soft Progressive Knee (" << sampleRate << " Hz)...";
    engine.reset();
    engine.setParameters(
        dsp171::CompressorTopology::DiodeBridge,
        -10.0f, 3.0f, 10.0f, 0.3f, false, 0.0f,
        dsp171::SidechainFilterMode::Off, false,
        0.0f, 100.0f, 100.0f, 100.0f, true, false
    );
    engine.resetStats();

    int nTone2 = static_cast<int>(sampleRate);
    juce::AudioBuffer<float> diodeTone(2, nTone2);
    for (int i = 0; i < nTone2; ++i) {
        float s = 0.7f * std::sin(2.0f * 3.14159265f * 400.0f * static_cast<float>(i) / static_cast<float>(sampleRate));
        diodeTone.setSample(0, i, s);
        diodeTone.setSample(1, i, s);
    }
    engine.processBlock(diodeTone);

    float diodeGR = engine.getMaxObservedGR();
    if (diodeGR > 3.0f && diodeGR < 12.0f) {
        std::cout << " [SUPERATO] (Diode-Bridge GR morbido: " << diodeGR << " dB)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Diode GR: " << diodeGR << " dB)\n";
    }

    // --------------------------------------------------------------------------
    // TEST 3: Program-Dependent Auto-Release a Due Stadi
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 3: Program-Dependent Auto-Release Ballistics (" << sampleRate << " Hz)...";
    engine.reset();
    engine.setParameters(
        dsp171::CompressorTopology::VCAMaster,
        -20.0f, 4.0f, 1.0f, 0.3f, true, 0.0f, // Auto-Release = true
        dsp171::SidechainFilterMode::Off, false,
        0.0f, 100.0f, 100.0f, 100.0f, true, false
    );

    // 1. Burst transiente breve (100 ms)
    int nBurst = static_cast<int>(0.100 * sampleRate);
    juce::AudioBuffer<float> burst(2, nBurst);
    for (int i = 0; i < nBurst; ++i) {
        burst.setSample(0, i, 0.8f);
        burst.setSample(1, i, 0.8f);
    }
    engine.processBlock(burst);
    float burstGR = engine.getGainReductionDb();

    // 2. Silenzio di recupero (150 ms)
    int nSilence = static_cast<int>(0.150 * sampleRate);
    juce::AudioBuffer<float> silence(2, nSilence);
    silence.clear();
    engine.processBlock(silence);
    float postSilenceGR = engine.getGainReductionDb();

    if (burstGR > 5.0f && postSilenceGR < burstGR * 0.3f) {
        std::cout << " [SUPERATO] (Burst GR: " << burstGR << " dB -> Recupero rapido: " << postSilenceGR << " dB)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Burst: " << burstGR << ", Post: " << postSilenceGR << ")\n";
    }

    // --------------------------------------------------------------------------
    // TEST 4: Thrust & Sidechain High-Pass Filter Rejection
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 4: Thrust Sidechain Filter Low-End Rejection (" << sampleRate << " Hz)...";
    engine.reset();
    // Impostiamo HPF a 150 Hz
    engine.setParameters(
        dsp171::CompressorTopology::VCAMaster,
        -15.0f, 4.0f, 10.0f, 0.3f, false, 0.0f,
        dsp171::SidechainFilterMode::HPF_150Hz, false,
        0.0f, 100.0f, 100.0f, 100.0f, true, false
    );
    engine.resetStats();

    // Segnale sub-bass a 45 Hz a -6 dBFS
    int nSub = static_cast<int>(0.500 * sampleRate);
    juce::AudioBuffer<float> subBass(2, nSub);
    for (int i = 0; i < nSub; ++i) {
        float s = 0.5f * std::sin(2.0f * 3.14159265f * 45.0f * static_cast<float>(i) / static_cast<float>(sampleRate));
        subBass.setSample(0, i, s);
        subBass.setSample(1, i, s);
    }
    engine.processBlock(subBass);

    float subGR = engine.getMaxObservedGR();
    if (subGR < 2.5f) {
        std::cout << " [SUPERATO] (Sub a 45 Hz respinto dal sidechain, GR limitato a: " << subGR << " dB)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Pumping sub indesiderato: " << subGR << " dB)\n";
    }

    // --------------------------------------------------------------------------
    // TEST 5: Marinair Transformer Saturation & Harmonic Generation
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 5: Marinair Transformer ADAA-2 Drive & DC Blocker (" << sampleRate << " Hz)...";
    engine.reset();
    engine.setParameters(
        dsp171::CompressorTopology::VCAMaster,
        0.0f, 2.0f, 10.0f, 0.3f, false, 0.0f,
        dsp171::SidechainFilterMode::Off, false,
        80.0f, 100.0f, 100.0f, 100.0f, false, false // 80% Transformer Drive
    );

    int nDrive = static_cast<int>(0.500 * sampleRate);
    juce::AudioBuffer<float> driveBuffer(2, nDrive);
    for (int i = 0; i < nDrive; ++i) {
        float s = 0.6f * std::sin(2.0f * 3.14159265f * 100.0f * static_cast<float>(i) / static_cast<float>(sampleRate));
        driveBuffer.setSample(0, i, s);
        driveBuffer.setSample(1, i, s);
    }
    engine.processBlock(driveBuffer);

    int startSample = static_cast<int>(0.100 * sampleRate);
    float dcOffset = 0.0f;
    for (int i = startSample; i < nDrive; ++i) {
        dcOffset += driveBuffer.getSample(0, i);
    }
    dcOffset /= static_cast<float>(nDrive - startSample);

    if (std::abs(dcOffset) < 1.0e-3f) {
        std::cout << " [SUPERATO] (DC Blocker perfetto: " << dcOffset << ", ADAA-2 Drive analogico attivo)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (DC drift: " << dcOffset << ")\n";
    }

    // --------------------------------------------------------------------------
    // TEST 6: TrueSpace Imager & Phase-Protection (+0.20 Min Correlation)
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 6: TrueSpace Imager Phase Protection (" << sampleRate << " Hz)...";
    engine.reset();
    engine.setParameters(
        dsp171::CompressorTopology::VCAMaster,
        0.0f, 2.0f, 10.0f, 0.3f, false, 0.0f,
        dsp171::SidechainFilterMode::Off, false,
        0.0f, 150.0f, 100.0f, 100.0f, false, false // Width 150%
    );

    int nWide = static_cast<int>(0.500 * sampleRate);
    juce::AudioBuffer<float> wideAudio(2, nWide);
    for (int i = 0; i < nWide; ++i) {
        float center = 0.5f * std::sin(2.0f * 3.14159265f * 440.0f * static_cast<float>(i) / static_cast<float>(sampleRate));
        float sideSig = 0.25f * std::sin(2.0f * 3.14159265f * 880.0f * static_cast<float>(i) / static_cast<float>(sampleRate));
        wideAudio.setSample(0, i, center + sideSig);
        wideAudio.setSample(1, i, center - sideSig);
    }
    engine.processBlock(wideAudio);

    double sumLR = 0.0, sumL2 = 0.0, sumR2 = 0.0;
    int corrStart = static_cast<int>(0.100 * sampleRate);
    for (int i = corrStart; i < nWide; ++i) {
        float l = wideAudio.getSample(0, i);
        float r = wideAudio.getSample(1, i);
        sumLR += l * r;
        sumL2 += l * l;
        sumR2 += r * r;
    }
    float corr = (float)(sumLR / (std::sqrt(sumL2 * sumR2) + 1.0e-12));

    if (corr >= 0.20f) {
        std::cout << " [SUPERATO] (Correlazione fase: " << corr << " >= +0.20, Mono-compatibile al 100%)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Correlazione debole o negativa: " << corr << ")\n";
    }

    // --------------------------------------------------------------------------
    // TEST 7: Mono-Maker ZDF SVF Filter (Sub-Bass Mono Collapse)
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 7: Mono-Maker Elliptic Filter (" << sampleRate << " Hz)...";
    engine.reset();
    engine.setParameters(
        dsp171::CompressorTopology::VCAMaster,
        0.0f, 2.0f, 10.0f, 0.3f, false, 0.0f,
        dsp171::SidechainFilterMode::Off, false,
        0.0f, 100.0f, 120.0f, 100.0f, false, false // Mono-maker a 120 Hz
    );

    int nSide = static_cast<int>(0.500 * sampleRate);
    juce::AudioBuffer<float> sideSub(2, nSide);
    for (int i = 0; i < nSide; ++i) {
        float s = 0.5f * std::sin(2.0f * 3.14159265f * 50.0f * static_cast<float>(i) / static_cast<float>(sampleRate));
        sideSub.setSample(0, i, s);
        sideSub.setSample(1, i, -s);
    }
    engine.processBlock(sideSub);

    int sideStart = static_cast<int>(0.250 * sampleRate);
    float sideEnergy = 0.0f;
    for (int i = sideStart; i < nSide; ++i) {
        float diff = sideSub.getSample(0, i) - sideSub.getSample(1, i);
        sideEnergy += diff * diff;
    }
    sideEnergy = std::sqrt(sideEnergy / static_cast<float>(nSide - sideStart));

    if (sideEnergy < 0.25f) {
        std::cout << " [SUPERATO] (Energia Side sub-120Hz attenuata: " << sideEnergy << " < 0.25)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Energia Side: " << sideEnergy << ")\n";
    }

    // --------------------------------------------------------------------------
    // TEST 8: Mastering Safety Ceiling True-Peak Limiter (-0.1 dBFS)
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 8: Mastering Safety True-Peak Limiter (" << sampleRate << " Hz)...";
    engine.reset();
    engine.setParameters(
        dsp171::CompressorTopology::VCAMaster,
        0.0f, 2.0f, 10.0f, 0.3f, false, 12.0f, // +12 dB Makeup gain per forzare il limiter
        dsp171::SidechainFilterMode::Off, false,
        0.0f, 100.0f, 100.0f, 100.0f, true, false // Ceiling limiter ON
    );

    int nLoud = static_cast<int>(0.500 * sampleRate);
    juce::AudioBuffer<float> loudBuffer(2, nLoud);
    for (int i = 0; i < nLoud; ++i) {
        loudBuffer.setSample(0, i, 0.95f);
        loudBuffer.setSample(1, i, 0.95f);
    }
    engine.processBlock(loudBuffer);

    float maxPeak = 0.0f;
    for (int ch = 0; ch < 2; ++ch) {
        for (int i = 0; i < nLoud; ++i) {
            maxPeak = std::max(maxPeak, std::abs(loudBuffer.getSample(ch, i)));
        }
    }

    constexpr float CEIL = 0.98855f + 1.0e-4f;
    if (maxPeak <= CEIL) {
        std::cout << " [SUPERATO] (Picco massimo: " << maxPeak << " <= " << CEIL << " = -0.1 dBFS)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Limiter oltrepassato: " << maxPeak << ")\n";
    }

    // --------------------------------------------------------------------------
    // TEST 9: Parallel NYC Mix (Constant-Power Crossfade)
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 9: Parallel NYC Dry/Wet Crossfade (" << sampleRate << " Hz)...";
    engine.reset();
    engine.setParameters(
        dsp171::CompressorTopology::VCAMaster,
        -15.0f, 10.0f, 1.0f, 0.1f, false, 0.0f,
        dsp171::SidechainFilterMode::Off, false,
        0.0f, 100.0f, 100.0f, 50.0f, false, false // Mix 50%
    );

    int nMix = static_cast<int>(0.100 * sampleRate);
    juce::AudioBuffer<float> mixBuf(2, nMix);
    for (int i = 0; i < nMix; ++i) {
        mixBuf.setSample(0, i, 0.5f);
        mixBuf.setSample(1, i, 0.5f);
    }
    engine.processBlock(mixBuf);

    float mixPeak = std::abs(mixBuf.getSample(0, nMix / 2));
    if (mixPeak > 0.1f && mixPeak < 0.6f) {
        std::cout << " [SUPERATO] (Dry/Wet 50% bilanciato: " << mixPeak << ")\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Peak mix: " << mixPeak << ")\n";
    }

    // --------------------------------------------------------------------------
    // TEST 10: Stress Test 100k Campioni & Assenza NaN/Inf
    // --------------------------------------------------------------------------
    std::cout << "[*] Test 10: Stress Test 100k Campioni & Assenza NaN/Inf (" << sampleRate << " Hz)...";
    engine.reset();
    engine.setParameters(
        dsp171::CompressorTopology::DiodeBridge,
        -18.0f, 4.0f, 0.3f, 0.1f, true, 8.0f,
        dsp171::SidechainFilterMode::Thrust, false,
        60.0f, 130.0f, 140.0f, 75.0f, true, false
    );

    juce::AudioBuffer<float> stressBuffer(2, 100000);
    bool nanInfFound = false;
    for (int i = 0; i < 100000; ++i) {
        float noise = ((float)rand() / (float)RAND_MAX) * 2.0f - 1.0f;
        stressBuffer.setSample(0, i, noise * 0.8f);
        stressBuffer.setSample(1, i, noise * 0.8f);
    }
    engine.processBlock(stressBuffer);

    for (int ch = 0; ch < 2; ++ch) {
        for (int i = 0; i < 100000; ++i) {
            float val = stressBuffer.getSample(ch, i);
            if (std::isnan(val) || std::isinf(val)) {
                nanInfFound = true;
                break;
            }
        }
    }

    if (!nanInfFound) {
        std::cout << " [SUPERATO] (100k campioni senza un singolo NaN o Inf!)\n";
        totalPass++;
    } else {
        std::cout << " [FALLITO] (Rilevati NaN o Inf!)\n";
    }

    outPassed = totalPass;
    outTotal = totalTests;
    return (totalPass == totalTests);
}

int main() {
    std::cout << "====================================================================\n";
    std::cout << " 171MASTERGLUE - COLLAUDO MATEMATICO & MULTI-SAMPLE RATE DSP ENGINE\n";
    std::cout << " Discrete Analog Master Bus Console & Imager (DSPHireManager Council)\n";
    std::cout << " Standard Frequencies: 44.1 kHz, 48 kHz, 88.2 kHz, 96 kHz\n";
    std::cout << "====================================================================\n";

    const std::vector<double> sampleRates = { 44100.0, 48000.0, 88200.0, 96000.0 };
    int grandTotalPass = 0;
    int grandTotalTests = 0;

    for (double sr : sampleRates) {
        int passed = 0;
        int total = 0;
        runTestSuiteForSampleRate(sr, passed, total);
        grandTotalPass += passed;
        grandTotalTests += total;
    }

    std::cout << "\n====================================================================\n";
    std::cout << " ESITO COMPLESSIVO MULTI-SAMPLE RATE 171MASTERGLUE:\n";
    std::cout << " " << grandTotalPass << "/" << grandTotalTests << " TEST SUPERATI CON SUCCESSO SU 44.1k, 48k, 88.2k, 96k!\n";
    std::cout << "====================================================================\n";

    return (grandTotalPass == grandTotalTests) ? 0 : 1;
}
