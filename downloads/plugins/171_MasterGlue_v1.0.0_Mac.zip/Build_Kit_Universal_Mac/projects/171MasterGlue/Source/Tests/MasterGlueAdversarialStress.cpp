#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <cassert>
#include <algorithm>
#include <random>
#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include "../DSP/MasterGlueEngine.h"
#include "dsp171/ADAA2Clipper.h"
#include "dsp171/SafetyCeiling.h"

// ==============================================================================
// 171MASTERGLUE - ADVERSARIAL STRESS & NUMERICAL STABILITY AUDIT (CHALLENGER M2)
// Rigorous verification of:
// 1. Banach fixed-point convergence in Diode-Bridge feedback mode (+24dB bursts, Nyquist, 0-cross)
// 2. 2nd-Order ADAA C-inf antiderivatives and L'Hopital limits (|x_n - x_{n-1}| < 1e-7 down to 0)
// 3. Continuous SSL coupled dual-RC differential equations under transient trains
// 4. ITU-R BS.1770 4x polyphase sinc True-Peak limiter inter-sample peak suppression
// 5. Multi-sample rate invariance across 44.1k, 48k, 88.2k, 96k, 192k
// ==============================================================================

struct AdversarialTestResults {
    int totalRun = 0;
    int totalPassed = 0;
    int totalFailed = 0;

    void record(const std::string& name, bool passed, const std::string& details = "") {
        totalRun++;
        if (passed) {
            totalPassed++;
            std::cout << "  [PASS] " << name;
            if (!details.empty()) std::cout << " (" << details << ")";
            std::cout << "\n";
        } else {
            totalFailed++;
            std::cout << "  [FAIL] " << name;
            if (!details.empty()) std::cout << " (" << details << ")";
            std::cout << "\n";
        }
    }
};

// ==============================================================================
// SUITE 1: BANACH FIXED-POINT CONVERGENCE & LIMIT CYCLE STRESS
// ==============================================================================
void runFixedPointStressTests(double sr, AdversarialTestResults& results) {
    std::cout << "\n--- SUITE 1: Banach Fixed-Point Convergence & Limit Cycles (" << sr << " Hz) ---\n";

    dsp171::MasterGlueEngine engine;
    engine.prepare(sr, 512);

    // 1.1A Direct Banach Fixed-Point Contraction Ratio & Audio Stream Convergence
    {
        // Audit the Banach contraction factor L = |v(k+1) - v(k)| / |v(k) - v(k-1)| and iteration count
        // during real continuous audio streaming across 10,000 samples.
        constexpr float v0 = 0.50f;
        constexpr float knee = 4.0f;
        constexpr float threshDb = -18.0f;
        constexpr float currentRatio = 6.0f;
        constexpr float makeupLinear = 1.995f; // +6 dB
        float attackAlpha = 1.0f - std::exp(-1.0f / (float(0.0001 * sr))); // 0.1 ms

        double maxContractionFactor = 0.0;
        bool allContracted = true;
        int maxIterToConverge = 0;
        double maxResidualAt4 = 0.0;
        float envDb = -90.0f;
        float feedbackSample = 0.0f;

        // Process 10,000 samples of 1000 Hz sine with dynamic amplitude modulation (-12 dB to +18 dB)
        for (int i = 0; i < 10000; ++i) {
            float progress = static_cast<float>(i) / 10000.0f;
            float inAmp = 0.25f + 7.75f * std::sin(3.14159265f * progress); // sweeps from -12dB up to +18dB
            float inSample = inAmp * std::sin(2.0f * 3.14159265f * 1000.0f * static_cast<float>(i) / static_cast<float>(sr));
            float distIn = inSample + 0.025f * inSample * std::abs(inSample);
            float nonlin = std::sqrt(1.0f + (inSample * inSample) / (v0 * v0));

            float vOut = feedbackSample;
            if (std::abs(vOut) < 1.0e-6f) {
                vOut = inSample;
            }

            float prevDiff = 0.0f;
            int iterCount = 0;

            for (int iter = 0; iter < 10; ++iter) {
                iterCount = iter + 1;
                float det = std::abs(vOut);
                float detDb = (det > 1.0e-6f) ? (20.0f * std::log10(det)) : -120.0f;
                float candEnv = (detDb > envDb)
                    ? envDb + (detDb - envDb) * attackAlpha
                    : envDb + (detDb - envDb) * 0.05f;

                float excess = candEnv - threshDb;
                float gr = 0.0f;
                if (excess > -knee) {
                    if (excess < knee) {
                        float k = (excess + knee) / (2.0f * knee);
                        gr = (excess + knee) * 0.5f * k * (1.0f - 1.0f / currentRatio);
                    } else {
                        gr = excess * (1.0f - 1.0f / currentRatio);
                    }
                }
                float targetGRDb = std::clamp(gr, 0.0f, 32.0f);
                float biasConduction = (targetGRDb > 0.001f)
                    ? (std::pow(10.0f, targetGRDb / 20.0f) - 1.0f)
                    : 0.0f;
                float atten = 1.0f / (1.0f + biasConduction * nonlin);
                float nextOut = distIn * atten * makeupLinear;

                float diff = std::abs(nextOut - vOut);
                if (iter > 0 && prevDiff > 1.0e-6f) {
                    double L = static_cast<double>(diff / prevDiff);
                    maxContractionFactor = std::max(maxContractionFactor, L);
                    if (L >= 1.0) {
                        allContracted = false;
                    }
                }
                prevDiff = diff;
                vOut = nextOut;

                if (diff < 1.0e-4f) {
                    break;
                }
            }

            maxIterToConverge = std::max(maxIterToConverge, iterCount);

            // Compute exact reference solution with 10 iterations to measure residual of 4 iterations
            float vOut4 = feedbackSample;
            if (std::abs(vOut4) < 1.0e-6f) vOut4 = inSample;
            for (int iter = 0; iter < 4; ++iter) {
                float det = std::abs(vOut4);
                float detDb = (det > 1.0e-6f) ? (20.0f * std::log10(det)) : -120.0f;
                float candEnv = (detDb > envDb)
                    ? envDb + (detDb - envDb) * attackAlpha
                    : envDb + (detDb - envDb) * 0.05f;

                float excess = candEnv - threshDb;
                float gr = 0.0f;
                if (excess > -knee) {
                    if (excess < knee) {
                        float k = (excess + knee) / (2.0f * knee);
                        gr = (excess + knee) * 0.5f * k * (1.0f - 1.0f / currentRatio);
                    } else {
                        gr = excess * (1.0f - 1.0f / currentRatio);
                    }
                }
                float targetGRDb = std::clamp(gr, 0.0f, 32.0f);
                float biasConduction = (targetGRDb > 0.001f)
                    ? (std::pow(10.0f, targetGRDb / 20.0f) - 1.0f)
                    : 0.0f;
                float atten = 1.0f / (1.0f + biasConduction * nonlin);
                vOut4 = distIn * atten * makeupLinear;
            }

            // Relative difference between 4 iterations (production) and 10 iterations (fully converged)
            double residual4 = std::abs(static_cast<double>(vOut4) - static_cast<double>(vOut));
            double relResidual = residual4 / std::max(1.0, static_cast<double>(inAmp));
            maxResidualAt4 = std::max(maxResidualAt4, relResidual);

            feedbackSample = vOut;
            float detFinal = std::abs(vOut);
            float detDbFinal = (detFinal > 1.0e-6f) ? (20.0f * std::log10(detFinal)) : -120.0f;
            envDb = (detDbFinal > envDb) ? envDb + (detDbFinal - envDb) * attackAlpha : envDb + (detDbFinal - envDb) * 0.05f;
        }

        // Banach contraction factor L must be < 1.0 everywhere, and the relative 4-iteration truncation error must be < 1e-3 (-60 dB)
        bool banachValid = allContracted && (maxContractionFactor < 1.0) && (maxResidualAt4 < 1.0e-3);
        results.record("1.1A Banach Contraction Ratio (L < 1.0 & relative 4-iter residual < 1e-3)", banachValid,
                       "Max L: " + std::to_string(maxContractionFactor) +
                       ", Max rel 4-iter residual: " + std::to_string(maxResidualAt4) +
                       ", Max iter to 1e-4: " + std::to_string(maxIterToConverge));
    }

    // 1.1B +24 dB Step Burst Dynamics & Compression Settling (Without Limiter)
    {
        engine.reset();
        engine.setParameters(
            dsp171::CompressorTopology::DiodeBridge,
            -18.0f, 6.0f, 0.1f, 0.2f, true, 0.0f, // 0 dB makeup
            dsp171::SidechainFilterMode::Off, false,
            0.0f, 100.0f, 100.0f, 100.0f, false, false, // Limiter disabled
            dsp171::DetectionMode::Feedback
        );
        engine.resetStats();

        // +24 dBFS step burst (15.8489f)
        float stepAmp = 15.8489f;
        int nTotal = 4096;
        juce::AudioBuffer<float> stepBuf(2, nTotal);
        stepBuf.clear();
        for (int i = 500; i < 3500; ++i) {
            stepBuf.setSample(0, i, stepAmp);
            stepBuf.setSample(1, i, stepAmp);
        }
        engine.processBlock(stepBuf);

        // Verify steady-state compression level after settling (sample 2000)
        float steadyOut = std::abs(stepBuf.getSample(0, 2000));
        float maxGR = engine.getMaxObservedGR();
        bool allFinite = true;
        for (int i = 0; i < nTotal; ++i) {
            if (!std::isfinite(stepBuf.getSample(0, i))) allFinite = false;
        }

        // Under 6:1 ratio and +24 dB step in feedback mode, control voltage GR is ~8.5 dB and steady out < 5.0
        bool stepSettled = allFinite && (maxGR > 6.0f) && (steadyOut < 5.0f);
        results.record("1.1B +24 dB Step Burst Dynamics (Steady-state Settled)", stepSettled,
                       "Max observed GR: " + std::to_string(maxGR) + " dB, Steady out: " + std::to_string(steadyOut));
    }

    // 1.1C +24 dB Step Burst with True-Peak Safety Ceiling Active
    {
        engine.reset();
        engine.setParameters(
            dsp171::CompressorTopology::DiodeBridge,
            -18.0f, 6.0f, 0.1f, 0.2f, true, 6.0f, // +6 dB makeup
            dsp171::SidechainFilterMode::Off, false,
            0.0f, 100.0f, 100.0f, 100.0f, true, false, // Safety ceiling limiter ACTIVE!
            dsp171::DetectionMode::Feedback
        );

        int nBurst = 4096;
        juce::AudioBuffer<float> ceilingBurst(2, nBurst);
        ceilingBurst.clear();
        float burstAmp = 15.8489f; // +24 dBFS
        for (int i = 500; i < 3500; ++i) {
            ceilingBurst.setSample(0, i, burstAmp);
            ceilingBurst.setSample(1, i, burstAmp);
        }
        engine.processBlock(ceilingBurst);

        float maxCeilingPeak = 0.0f;
        for (int ch = 0; ch < 2; ++ch) {
            for (int i = 0; i < nBurst; ++i) {
                maxCeilingPeak = std::max(maxCeilingPeak, std::abs(ceilingBurst.getSample(ch, i)));
            }
        }

        constexpr float CEIL = 0.988553f + 1.0e-4f;
        bool ceilingProtected = (maxCeilingPeak <= CEIL);
        results.record("1.1C +24 dB Step Burst with True-Peak Ceiling Active", ceilingProtected,
                       "Max peak across entire burst: " + std::to_string(maxCeilingPeak) + " <= " + std::to_string(CEIL));
    }

    // 1.2 Nyquist-Rate Alternations: (+A, -A, +A, -A)
    {
        engine.reset();
        engine.setParameters(
            dsp171::CompressorTopology::DiodeBridge,
            -15.0f, 4.0f, 0.05f, 0.1f, false, 0.0f, // Fastest attack (0.05 ms)
            dsp171::SidechainFilterMode::Off, false,
            0.0f, 100.0f, 100.0f, 100.0f, false, false,
            dsp171::DetectionMode::Feedback
        );

        bool nyquistPassed = true;
        int nNyquist = 4096;
        juce::AudioBuffer<float> nyquistBuf(2, nNyquist);
        float amp = 10.0f; // +20 dBFS Nyquist square
        for (int i = 0; i < nNyquist; ++i) {
            float s = (i % 2 == 0) ? amp : -amp;
            nyquistBuf.setSample(0, i, s);
            nyquistBuf.setSample(1, i, s);
        }
        engine.processBlock(nyquistBuf);

        // Check for NaN/Inf and verify symmetry in steady state
        float diffSymmetry = 0.0f;
        for (int i = 2000; i < nNyquist - 1; ++i) {
            float s1 = nyquistBuf.getSample(0, i);
            float s2 = nyquistBuf.getSample(0, i + 1);
            if (!std::isfinite(s1) || !std::isfinite(s2)) {
                nyquistPassed = false;
                break;
            }
            diffSymmetry = std::max(diffSymmetry, std::abs(std::abs(s1) - std::abs(s2)));
        }

        bool nyquistOk = nyquistPassed && (diffSymmetry < 0.25f);
        results.record("1.2 Nyquist Alternation (+A, -A, +A, -A)", nyquistOk,
                       "Steady-state symmetry diff: " + std::to_string(diffSymmetry));
    }

    // 1.3 Zero-Crossing & Micro-Dynamics (1e-7 to 1e-3 amplitude sine)
    {
        engine.reset();
        engine.setParameters(
            dsp171::CompressorTopology::DiodeBridge,
            -20.0f, 4.0f, 1.0f, 0.1f, true, 0.0f,
            dsp171::SidechainFilterMode::Off, false,
            0.0f, 100.0f, 100.0f, 100.0f, false, false,
            dsp171::DetectionMode::Feedback
        );

        int nMicro = 4096;
        juce::AudioBuffer<float> microBuf(2, nMicro);
        // Frequency 1000 Hz, amplitude sweeping from 1e-7 to 1e-3
        for (int i = 0; i < nMicro; ++i) {
            float progress = static_cast<float>(i) / static_cast<float>(nMicro);
            float currentAmp = 1.0e-7f + progress * (1.0e-3f - 1.0e-7f);
            float s = currentAmp * std::sin(2.0f * 3.14159265f * 1000.0f * static_cast<float>(i) / static_cast<float>(sr));
            microBuf.setSample(0, i, s);
            microBuf.setSample(1, i, s);
        }
        engine.processBlock(microBuf);

        bool microClean = true;
        for (int i = 0; i < nMicro; ++i) {
            float s = microBuf.getSample(0, i);
            if (!std::isfinite(s) || std::isnan(s)) {
                microClean = false;
                break;
            }
        }
        results.record("1.3 Micro-Dynamics Sweep (1e-7 to 1e-3 crossing)", microClean,
                       "Clean continuity across detector floor");
    }

    // 1.4 High Makeup Gain Stress (+24 dB Makeup, 10:1 Ratio)
    {
        engine.reset();
        engine.setParameters(
            dsp171::CompressorTopology::DiodeBridge,
            -24.0f, 10.0f, 0.1f, 0.1f, true, 24.0f, // +24 dB Makeup
            dsp171::SidechainFilterMode::Off, false,
            0.0f, 100.0f, 100.0f, 100.0f, false, false,
            dsp171::DetectionMode::Feedback
        );

        int nNoise = 10000;
        juce::AudioBuffer<float> noiseBuf(2, nNoise);
        std::mt19937 rng(42);
        std::normal_distribution<float> dist(0.0f, 2.0f); // 2.0 RMS = heavy bursts
        for (int i = 0; i < nNoise; ++i) {
            float s = dist(rng);
            noiseBuf.setSample(0, i, s);
            noiseBuf.setSample(1, i, s);
        }
        engine.processBlock(noiseBuf);

        bool stable = true;
        for (int ch = 0; ch < 2; ++ch) {
            for (int i = 0; i < nNoise; ++i) {
                float s = noiseBuf.getSample(ch, i);
                if (!std::isfinite(s)) {
                    stable = false;
                    break;
                }
            }
        }
        results.record("1.4 Extreme Makeup Gain (+24dB Makeup + High Ratio)", stable,
                       "10,000 heavy noise samples finite: " + std::string(stable ? "YES" : "NO"));
    }
}

// ==============================================================================
// SUITE 2: ADAA-2 C-INF ANTIDERIVATIVE & L'HOPITAL BOUNDARY STRESS
// ==============================================================================
void runADAA2StressTests(AdversarialTestResults& results) {
    std::cout << "\n--- SUITE 2: ADAA-2 Antiderivative & L'Hopital Limits ---\n";

    dsp171::ADAA2Clipper clipper;

    // 2.1 Near-Identical Adjacent Samples (|x_n - x_{n-1}| < 1e-7 down to 0)
    {
        clipper.reset();
        std::vector<double> deltas = { 1e-5, 1e-6, 1e-7, 1e-8, 1e-9, 1e-11, 1e-14, 0.0 };
        bool allClean = true;
        double maxErrorFromStatic = 0.0;

        for (double d : deltas) {
            clipper.reset();
            double xBase = 0.75;
            // Feed 3 samples with delta spacing
            float y0 = clipper.processSample(static_cast<float>(xBase), 1.0f);
            float y1 = clipper.processSample(static_cast<float>(xBase + d), 1.0f);
            float y2 = clipper.processSample(static_cast<float>(xBase + 2.0 * d), 1.0f);

            if (!std::isfinite(y0) || !std::isfinite(y1) || !std::isfinite(y2)) {
                allClean = false;
            }

            // In steady state, y2 should match static function closely
            double expected = dsp171::ADAA2Clipper::f((xBase + 2.0 * d) * 1.5) / 1.5;
            double err = std::abs(static_cast<double>(y2) - expected);
            maxErrorFromStatic = std::max(maxErrorFromStatic, err);
        }

        bool ok = allClean && (maxErrorFromStatic < 1e-4);
        results.record("2.1 Near-Identical Samples (|x_n - x_{n-1}| down to 0)", ok,
                       "Max dev from static curve: " + std::to_string(maxErrorFromStatic));
    }

    // 2.2 Boundary Continuity Across |dTot| = eps (1.0e-5)
    {
        // Sweep dTot across eps from (eps - 1e-6) to (eps + 1e-6) with fixed x1
        double x1 = 0.50;
        double x2 = 0.50;
        constexpr double eps = 1.0e-5;

        double maxStepJump = 0.0;
        double prevOut = 0.0;
        bool first = true;
        bool allFinite = true;

        for (int step = -50; step <= 50; ++step) {
            double dTot = eps + static_cast<double>(step) * 1.0e-7;
            double in = x2 + dTot;

            clipper.reset();
            // Pre-seed state with x2 then x1
            clipper.processSample(static_cast<float>(x2), 1.0f);
            clipper.processSample(static_cast<float>(x1), 1.0f);
            float out = clipper.processSample(static_cast<float>(in), 1.0f);

            if (!std::isfinite(out)) {
                allFinite = false;
            }

            if (!first) {
                double diff = std::abs(static_cast<double>(out) - prevOut);
                maxStepJump = std::max(maxStepJump, diff);
            }
            prevOut = static_cast<double>(out);
            first = false;
        }

        // The jump across adjacent 1e-7 steps should be smooth (< 1e-4)
        bool smooth = allFinite && (maxStepJump < 1.0e-4);
        results.record("2.2 Boundary Continuity across |dTot| = eps (1e-5)", smooth,
                       "Max step jump across boundary: " + std::to_string(maxStepJump));
    }

    // 2.3 Triple-Coincident DC Sweep (x0 = x1 = x2 from -20 to +20)
    {
        bool dcPassed = true;
        double maxDcDiff = 0.0;

        for (int i = -1000; i <= 1000; ++i) {
            float xVal = static_cast<float>(i) * 0.02f; // -20.0 to +20.0
            clipper.reset();
            clipper.processSample(xVal, 1.0f);
            clipper.processSample(xVal, 1.0f);
            float y = clipper.processSample(xVal, 1.0f);

            if (!std::isfinite(y)) {
                dcPassed = false;
                break;
            }

            // Analytical expectation for constant signal: f(x * 1.5) / 1.5
            double expected = dsp171::ADAA2Clipper::f(static_cast<double>(xVal) * 1.5) / 1.5;
            double diff = std::abs(static_cast<double>(y) - expected);
            maxDcDiff = std::max(maxDcDiff, diff);
        }

        bool dcOk = dcPassed && (maxDcDiff < 1.0e-5);
        results.record("2.3 Triple-Coincident DC Sweep (-20 to +20)", dcOk,
                       "Max difference from analytic f(x): " + std::to_string(maxDcDiff));
    }

    // 2.4 Nyquist Alternation Limit (x0 = +A, x1 = -A, x2 = +A -> dTot = 0, diff = 2A)
    {
        clipper.reset();
        float A = 1.25f;
        clipper.processSample(A, 1.0f);  // x2 = A
        clipper.processSample(-A, 1.0f); // x1 = -A
        float yLimit = clipper.processSample(A, 1.0f); // x0 = A -> dTot = 0, diff = 2A

        // Compare with numerical perturbation limit (A + 1e-7, -A, A)
        dsp171::ADAA2Clipper numClipper;
        numClipper.processSample(A, 1.0f);
        numClipper.processSample(-A, 1.0f);
        float yPerturb = numClipper.processSample(A + 1.0e-7f, 1.0f);

        double diff = std::abs(static_cast<double>(yLimit) - static_cast<double>(yPerturb));
        bool nyquistOk = std::isfinite(yLimit) && (diff < 1.0e-4);
        results.record("2.4 Nyquist Alternation L'Hopital Limit (dTot=0, diff=2A)", nyquistOk,
                       "Difference from numerical perturbation: " + std::to_string(diff));
    }

    // 2.5 Hostile Inputs: NaN, Inf, -Inf, Subnormals, Huge Values
    {
        clipper.reset();
        float nanVal = std::numeric_limits<float>::quiet_NaN();
        float infVal = std::numeric_limits<float>::infinity();
        float subnormal = 1.0e-38f;
        float hugeVal = 1.0e20f;

        float r1 = clipper.processSample(nanVal, 1.0f);
        float r2 = clipper.processSample(infVal, 1.0f);
        float r3 = clipper.processSample(-infVal, 1.0f);
        float r4 = clipper.processSample(subnormal, 1.0f);
        float r5 = clipper.processSample(hugeVal, 1.0f);

        bool safe = std::isfinite(r1) && std::isfinite(r2) && std::isfinite(r3) &&
                    std::isfinite(r4) && std::isfinite(r5);
        results.record("2.5 Hostile Input Robustness (NaN/Inf/Subnormal/Huge)", safe,
                       "All returned finite floats safely");
    }
}

// ==============================================================================
// SUITE 3: CONTINUOUS AUTO-RELEASE DUAL-RC BALLISTICS
// ==============================================================================
void runAutoReleaseStressTests(double sr, AdversarialTestResults& results) {
    std::cout << "\n--- SUITE 3: Continuous Coupled Dual-RC Auto-Release (" << sr << " Hz) ---\n";

    dsp171::MasterGlueEngine engine;
    engine.prepare(sr, 512);

    // 3.1 Program Dependency: Short Transient (50ms) vs Sustained Burst (2000ms)
    {
        engine.reset();
        engine.setParameters(
            dsp171::CompressorTopology::VCAMaster,
            -20.0f, 4.0f, 1.0f, 0.3f, true, 0.0f, // Auto-Release = true
            dsp171::SidechainFilterMode::Off, false,
            0.0f, 100.0f, 100.0f, 100.0f, false, false
        );

        // Case A: Short 50 ms burst
        int nShortBurst = static_cast<int>(0.050 * sr);
        juce::AudioBuffer<float> shortBuf(2, nShortBurst);
        for (int i = 0; i < nShortBurst; ++i) {
            shortBuf.setSample(0, i, 0.9f);
            shortBuf.setSample(1, i, 0.9f);
        }
        engine.processBlock(shortBuf);
        float peakShortGR = engine.getGainReductionDb();

        // Silence recovery for 150 ms
        int nRecovery = static_cast<int>(0.150 * sr);
        juce::AudioBuffer<float> silenceBuf(2, nRecovery);
        silenceBuf.clear();
        engine.processBlock(silenceBuf);
        float shortResidualGR = engine.getGainReductionDb();
        float shortResidualRatio = shortResidualGR / (peakShortGR + 1e-6f);

        // Case B: Sustained 2000 ms burst
        engine.reset();
        int nLongBurst = static_cast<int>(2.000 * sr);
        juce::AudioBuffer<float> longBuf(2, nLongBurst);
        for (int i = 0; i < nLongBurst; ++i) {
            longBuf.setSample(0, i, 0.9f);
            longBuf.setSample(1, i, 0.9f);
        }
        engine.processBlock(longBuf);
        float peakLongGR = engine.getGainReductionDb();

        // Silence recovery for 150 ms
        silenceBuf.clear();
        engine.processBlock(silenceBuf);
        float longResidualGR = engine.getGainReductionDb();
        float longResidualRatio = longResidualGR / (peakLongGR + 1e-6f);

        // The short burst should recover much faster (residual ratio < 0.25)
        // Sustained burst should hold charge in C_slow (residual ratio > 0.40)
        bool programDependent = (shortResidualRatio < 0.25f) && (longResidualRatio > 0.35f);
        results.record("3.1 Program-Dependent Auto-Release Ballistics", programDependent,
                       "Short residual: " + std::to_string(shortResidualRatio * 100.0f) + "%, Long residual: " +
                       std::to_string(longResidualRatio * 100.0f) + "%");
    }

    // 3.2 Dense Impulse Train (Machine gun / rapid transient rolls)
    {
        engine.reset();
        engine.setParameters(
            dsp171::CompressorTopology::VCAMaster,
            -15.0f, 4.0f, 1.0f, 0.2f, true, 0.0f,
            dsp171::SidechainFilterMode::Off, false,
            0.0f, 100.0f, 100.0f, 100.0f, false, false
        );

        int totalLen = static_cast<int>(1.0 * sr);
        juce::AudioBuffer<float> rollBuf(2, totalLen);
        rollBuf.clear();
        // 10 ms pulse every 40 ms
        int pulseLen = static_cast<int>(0.010 * sr);
        int period = static_cast<int>(0.040 * sr);
        for (int start = 0; start + pulseLen < totalLen; start += period) {
            for (int i = 0; i < pulseLen; ++i) {
                rollBuf.setSample(0, start + i, 0.85f);
                rollBuf.setSample(1, start + i, 0.85f);
            }
        }
        engine.processBlock(rollBuf);

        bool rollClean = true;
        for (int ch = 0; ch < 2; ++ch) {
            for (int i = 0; i < totalLen; ++i) {
                float s = rollBuf.getSample(ch, i);
                if (!std::isfinite(s)) rollClean = false;
            }
        }
        results.record("3.2 Dense Transient Train Accumulation & Recovery", rollClean,
                       "Clean envelope tracking with zero DC drift or NaN");
    }
}

// ==============================================================================
// SUITE 4: TRUE-PEAK LIMITER INTER-SAMPLE PEAK AUDIT
// ==============================================================================
void runTruePeakStressTests(double sr, AdversarialTestResults& results) {
    std::cout << "\n--- SUITE 4: ITU-R BS.1770-4 True-Peak Limiter (-0.10 dBTP) (" << sr << " Hz) ---\n";

    dsp171::MasterGlueEngine engine;
    engine.prepare(sr, 512);

    // 4.1 Synthetic Inter-Sample Peak: 45-degree shifted sine at fs/4 with 0 dBFS amplitude
    // Peaks fall exactly midway between samples: continuous peak is +3.01 dBFS = 1.414 linear
    {
        engine.reset();
        engine.setParameters(
            dsp171::CompressorTopology::VCAMaster,
            0.0f, 2.0f, 10.0f, 0.3f, false, 0.0f,
            dsp171::SidechainFilterMode::Off, false,
            0.0f, 100.0f, 100.0f, 100.0f, true, false // Ceiling limiter enabled!
        );

        int nTone = static_cast<int>(0.500 * sr);
        juce::AudioBuffer<float> ispBuf(2, nTone);
        float freq = static_cast<float>(sr) / 4.0f; // fs / 4
        float phase = 3.14159265f / 4.0f;           // 45 degrees
        for (int i = 0; i < nTone; ++i) {
            float s = 1.0f * std::sin(2.0f * 3.14159265f * freq * static_cast<float>(i) / static_cast<float>(sr) + phase);
            ispBuf.setSample(0, i, s);
            ispBuf.setSample(1, i, s);
        }
        engine.processBlock(ispBuf);

        // Check discrete peak of output
        float maxSample = 0.0f;
        for (int ch = 0; ch < 2; ++ch) {
            for (int i = 0; i < nTone; ++i) {
                maxSample = std::max(maxSample, std::abs(ispBuf.getSample(ch, i)));
            }
        }

        // Strict limit: -0.10 dBFS is 0.988553f
        constexpr float CEIL = 0.988553f + 1.0e-4f;
        bool ceilingRespected = (maxSample <= CEIL);
        results.record("4.1 Synthetic Inter-Sample Peak Suppression (fs/4 @ 45 deg)", ceilingRespected,
                       "Max discrete sample: " + std::to_string(maxSample) + " <= " + std::to_string(CEIL));
    }

    // 4.2 Stereo Linking Balance Preservation under Unilateral Transient Peak
    {
        dsp171::TruePeakLimiter limL, limR;
        limL.prepare(sr);
        limR.prepare(sr);

        // Unilateral transient: Left = +6 dBFS (2.0f), Right = -6 dBFS (0.5f)
        float inL = 2.0f;
        float inR = 0.5f;
        float outL = 0.0f, outR = 0.0f;

        // Process a short burst
        for (int i = 0; i < 20; ++i) {
            dsp171::TruePeakLimiter::processStereoPair(limL, limR, inL, inR, outL, outR, -0.10f);
        }

        // Under 100% stereo linking, the ratio (outL / outR) must equal (inL / inR) = 4.0
        float ratioIn = inL / inR;
        float ratioOut = outL / outR;
        float balanceError = std::abs(ratioOut - ratioIn);

        bool balanceOk = (balanceError < 0.01f) && (outL <= 0.988553f + 1e-4f);
        results.record("4.2 True-Peak Stereo Linking Balance (Soundstage Integrity)", balanceOk,
                       "In ratio: " + std::to_string(ratioIn) + ", Out ratio: " + std::to_string(ratioOut));
    }
}

// ==============================================================================
// MAIN RUNNER
// ==============================================================================
int main() {
    std::cout << "====================================================================\n";
    std::cout << " 171MASTERGLUE - EMPIRICAL ADVERSARIAL STRESS TEST HARNESS\n";
    std::cout << " Mathematical Numerical Stability Auditor (Challenger M2)\n";
    std::cout << "====================================================================\n";

    AdversarialTestResults results;

    // Test across standard and high-resolution sample rates
    const std::vector<double> sampleRates = { 44100.0, 48000.0, 88200.0, 96000.0, 192000.0 };

    for (double sr : sampleRates) {
        std::cout << "\n====================================================================";
        std::cout << "\n TESTING AT SAMPLE RATE: " << sr << " Hz";
        std::cout << "\n====================================================================";

        runFixedPointStressTests(sr, results);
        runAutoReleaseStressTests(sr, results);
        runTruePeakStressTests(sr, results);
    }

    // Suite 2 (ADAA-2) is sample-rate independent analytical math
    runADAA2StressTests(results);

    std::cout << "\n====================================================================\n";
    std::cout << " ADVERSARIAL AUDIT SUMMARY:\n";
    std::cout << " Total tests executed: " << results.totalRun << "\n";
    std::cout << " Tests PASSED:         " << results.totalPassed << "\n";
    std::cout << " Tests FAILED:         " << results.totalFailed << "\n";
    std::cout << "====================================================================\n";

    if (results.totalFailed == 0) {
        std::cout << "\n>>> VERDICT: APPROVE <<<\n";
        std::cout << "All mathematical numerical stability criteria satisfied across all sample rates.\n\n";
        return 0;
    } else {
        std::cout << "\n>>> VERDICT: REJECT <<<\n";
        std::cout << "Failures detected in mathematical numerical stability.\n\n";
        return 1;
    }
}
