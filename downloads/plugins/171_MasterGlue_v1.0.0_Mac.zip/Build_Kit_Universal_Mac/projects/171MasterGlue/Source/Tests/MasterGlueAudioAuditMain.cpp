#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <chrono>
#include <cmath>
#include <fstream>
#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_formats/juce_audio_formats.h>
#include "../DSP/MasterGlueEngine.h"
#include "dsp171/DSPHireManager.h"

struct TestTrackSpec {
    std::string name;
    std::string category;
    std::string relativePath;
    std::string outputFilename;
    dsp171::CompressorTopology topology;
    float thresholdDb;
    float ratio;
    float attackMs;
    float releaseSec;
    bool isAutoRelease;
    float makeupDb;
    dsp171::SidechainFilterMode scMode;
    float drivePct;
    float stereoWidthPct;
    float monoMakerHz;
    float dryWetPct;
};

int main(int argc, char* argv[]) {
    juce::ignoreUnused(argc, argv);

    std::cout << "====================================================================\n";
    std::cout << "  171MASTERGLUE - MULTI-AUDIO MASTER BUS AUDIT & DYNAMICS BENCHMARK\n";
    std::cout << "  Orchestrato con DSPHireManager (8 Agenti Specializzati)          \n";
    std::cout << "====================================================================\n\n";

    dsp171::DevelopmentVariables vars;
    vars.task = dsp171::DomainTask::CompressionDynamics;
    vars.compressionTopology = dsp171::CompressionTopology::VCA_BusMaster;
    auto dispatch = dsp171::DSPHireManager::dispatch(vars);

    std::cout << "[DSP HIRE MANAGER] Dispatch Convocato:\n";
    std::cout << " - Primary Specialist: " << dispatch.primaryAgent.agentId << " (" << dispatch.primaryAgent.agentTitle << ")\n";
    std::cout << " - Technical Reviewer: " << dispatch.reviewerAgent.agentId << " (" << dispatch.reviewerAgent.agentTitle << ")\n";
    std::cout << " - QA Lead Auditor:   " << dispatch.qaAuditorAgent.agentId << "\n\n";

    juce::AudioFormatManager formatManager;
    formatManager.registerBasicFormats();

    juce::File currentDir = juce::File::getCurrentWorkingDirectory();
    juce::File rootDir = currentDir;
    while (!rootDir.getChildFile("projects").exists() && rootDir.getParentDirectory() != rootDir) {
        rootDir = rootDir.getParentDirectory();
    }

    juce::File outputDir = rootDir.getChildFile("tools-and-analysis")
                                  .getChildFile("audit-outputs")
                                  .getChildFile("171MasterGlue_MultiAudio_Audit");
    outputDir.createDirectory();

    std::vector<TestTrackSpec> specs = {
        {
            "Track 1 - Drum / Transient Ballistics Bus",
            "Drums & Percussion / VCA Punch Glue",
            "tools-and-analysis/stimuli/04_dynamic_burst_ballistics.wav",
            "01_drums_vca_glue.wav",
            dsp171::CompressorTopology::VCAMaster,
            -24.0f, 4.0f, 10.0f, 0.1f, false, 3.0f,
            dsp171::SidechainFilterMode::Thrust, 25.0f, 110.0f, 90.0f, 100.0f
        },
        {
            "Track 2 - Melodic & Harmonic Bus (Dankle Stem)",
            "Acoustic & Melodic / Neve Diode-Bridge Thick Warmth",
            "tools-and-analysis/audit-outputs/171_PerfectPre_Audit_Stems/DANKLE_02-230715_1908.wav",
            "02_melodic_diode_bridge.wav",
            dsp171::CompressorTopology::DiodeBridge,
            -24.0f, 3.0f, 3.0f, 0.3f, true, 4.0f,
            dsp171::SidechainFilterMode::HPF_90Hz, 50.0f, 115.0f, 110.0f, 100.0f
        },
        {
            "Track 3 - Lead Vocal Bus (Parallel NYC)",
            "Vocals / Heavy Crush Parallel NY Compression",
            "tools-and-analysis/audit-outputs/171_PerfectPre_Audit_Stems/MAURITO_08-230312_1223-01.wav",
            "03_vocal_parallel_nyc.wav",
            dsp171::CompressorTopology::VCAMaster,
            -20.0f, 10.0f, 0.1f, 0.1f, false, 6.0f,
            dsp171::SidechainFilterMode::HPF_150Hz, 40.0f, 105.0f, 120.0f, 45.0f // 45% Wet
        },
        {
            "Track 4 - Master Mix Bus (Adriano Full Melodic Track)",
            "Master Bus Glue / Transparent SSL + Marinair Drive",
            "tools-and-analysis/audit-outputs/171_PerfectPre_Audit_Stems/ADRIANO_02-240110_1148.wav",
            "04_master_bus_glue.wav",
            dsp171::CompressorTopology::VCAMaster,
            -18.0f, 2.0f, 10.0f, 0.3f, true, 2.0f,
            dsp171::SidechainFilterMode::HPF_90Hz, 30.0f, 115.0f, 100.0f, 100.0f
        }
    };

    for (const auto& spec : specs) {
        std::cout << "--------------------------------------------------------------------\n";
        std::cout << "[*] Esecuzione " << spec.name << "\n";
        std::cout << "    Preset: " << spec.category << "\n";

        juce::File inputFile = rootDir.getChildFile(spec.relativePath);
        if (!inputFile.existsAsFile()) {
            std::cerr << "    [ERRORE] File non trovato: " << inputFile.getFullPathName().toStdString() << "\n";
            continue;
        }

        std::unique_ptr<juce::AudioFormatReader> reader(formatManager.createReaderFor(inputFile));
        if (reader == nullptr) continue;

        const int numChannels = static_cast<int>(reader->numChannels);
        const int numSamples = static_cast<int>(reader->lengthInSamples);
        const double sampleRate = reader->sampleRate;
        const double durationSec = static_cast<double>(numSamples) / sampleRate;

        juce::AudioBuffer<float> inBuffer(2, numSamples);
        inBuffer.clear();

        if (numChannels >= 2) {
            reader->read(&inBuffer, 0, numSamples, 0, true, true);
        } else {
            reader->read(&inBuffer, 0, numSamples, 0, true, false);
            inBuffer.copyFrom(1, 0, inBuffer, 0, 0, numSamples);
        }

        dsp171::MasterGlueEngine engine;
        engine.prepare(sampleRate, 512);
        engine.setParameters(
            spec.topology,
            spec.thresholdDb,
            spec.ratio,
            spec.attackMs,
            spec.releaseSec,
            spec.isAutoRelease,
            spec.makeupDb,
            spec.scMode,
            false,
            spec.drivePct,
            spec.stereoWidthPct,
            spec.monoMakerHz,
            spec.dryWetPct,
            true,  // Ceiling soft-clipper ON
            false  // Bypass OFF
        );
        engine.resetStats();

        juce::AudioBuffer<float> outBuffer;
        outBuffer.makeCopyOf(inBuffer);

        constexpr int blockSize = 512;
        auto startTime = std::chrono::high_resolution_clock::now();

        for (int start = 0; start < numSamples; start += blockSize) {
            int currentBlock = std::min(blockSize, numSamples - start);
            juce::AudioBuffer<float> blockProxy(outBuffer.getArrayOfWritePointers(), 2, start, currentBlock);
            engine.processBlock(blockProxy);
        }

        auto endTime = std::chrono::high_resolution_clock::now();
        double elapsedMs = std::chrono::duration<double, std::milli>(endTime - startTime).count();
        double speedup = (durationSec * 1000.0) / elapsedMs;

        float maxGR = engine.getMaxObservedGR();

        // Misurazione picco e correlazione
        float outPeak = 0.0f;
        double sumLR = 0.0, sumL2 = 0.0, sumR2 = 0.0;
        bool hasNanInf = false;

        for (int i = 0; i < numSamples; ++i) {
            float l = outBuffer.getSample(0, i);
            float r = outBuffer.getSample(1, i);
            if (std::isnan(l) || std::isnan(r) || std::isinf(l) || std::isinf(r)) hasNanInf = true;
            outPeak = std::max(outPeak, std::max(std::abs(l), std::abs(r)));
            sumLR += l * r;
            sumL2 += l * l;
            sumR2 += r * r;
        }

        float outPeakDb = (outPeak > 1.0e-5f) ? (20.0f * std::log10(outPeak)) : -100.0f;
        float corr = (float)(sumLR / (std::sqrt(sumL2 * sumR2) + 1.0e-12));

        std::cout << "    [BENCHMARK]:\n";
        std::cout << "      Tempo CPU: " << std::fixed << std::setprecision(2) << elapsedMs << " ms ("
                  << std::setprecision(1) << speedup << "x Real-Time speedup)\n";
        std::cout << "      Max Gain Reduction: -" << std::setprecision(2) << maxGR << " dB\n";
        std::cout << "      Out Peak:           " << outPeakDb << " dBFS (Ceiling <= -0.1 dBFS)\n";
        std::cout << "      Stereo Correlation: " << std::setprecision(3) << corr << " (>= +0.20)\n";
        std::cout << "      Sanity Check:       " << (hasNanInf ? "ERROR NaN/Inf" : "PULITO (0 NaN/Inf)") << "\n";

        juce::File destWav = outputDir.getChildFile(spec.outputFilename);
        if (destWav.existsAsFile()) destWav.deleteFile();

        std::unique_ptr<juce::FileOutputStream> outStream(destWav.createOutputStream());
        if (outStream != nullptr) {
            juce::WavAudioFormat wavFormat;
            std::unique_ptr<juce::AudioFormatWriter> writer(wavFormat.createWriterFor(
                outStream.get(), sampleRate, 2, 24, {}, 0));
            if (writer != nullptr) {
                outStream.release();
                writer->writeFromAudioSampleBuffer(outBuffer, 0, numSamples);
                std::cout << "    [SALVATO]: " << destWav.getFileName().toStdString() << " ("
                          << destWav.getSize() / 1024 << " KB)\n";
            }
        }
    }

    std::cout << "\n====================================================================\n";
    std::cout << " 171MASTERGLUE - AUDIO AUDIT COMPLETATO CON SUCCESSO!               \n";
    std::cout << "====================================================================\n";

    return 0;
}
