#include "PluginProcessor.h"
#include "PluginEditor.h"

AudioPluginAudioProcessor::AudioPluginAudioProcessor()
    : AudioProcessor(BusesProperties()
                     .withInput("Input", juce::AudioChannelSet::stereo(), true)
                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)
                     .withInput("Sidechain", juce::AudioChannelSet::stereo(), false)),
      apvts(*this, nullptr, "Parameters", createParameterLayout())
{
}

AudioPluginAudioProcessor::~AudioPluginAudioProcessor() {}

juce::AudioProcessorValueTreeState::ParameterLayout AudioPluginAudioProcessor::createParameterLayout() {
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { "topology", 1 }, "Topology",
        juce::StringArray { "VCA Master", "Diode-Bridge" }, 0));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { "detection_mode", 1 }, "Detection",
        juce::StringArray { "Feedforward", "Feedback" }, 0));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "threshold", 1 }, "Threshold",
        juce::NormalisableRange<float>(-30.0f, 10.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel("dB")));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { "ratio", 1 }, "Ratio",
        juce::StringArray { "1.5:1", "2:1", "4:1", "10:1" }, 1));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { "attack", 1 }, "Attack",
        juce::StringArray { "0.1 ms", "0.3 ms", "1.0 ms", "3.0 ms", "10 ms", "30 ms" }, 4));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { "release", 1 }, "Release",
        juce::StringArray { "0.1 s", "0.3 s", "0.6 s", "1.2 s", "Auto" }, 4));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "makeup", 1 }, "Makeup Gain",
        juce::NormalisableRange<float>(0.0f, 20.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel("dB")));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { "sidechain_filter", 1 }, "Sidechain HPF",
        juce::StringArray { "Off", "60 Hz", "90 Hz", "150 Hz", "Thrust" }, 2));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { "ext_sidechain", 1 }, "External SC", false));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "transformer_drive", 1 }, "Transformer Drive",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.5f), 20.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { "transformer_type", 1 }, "Transformer Core",
        juce::StringArray { "Iron Core (Marinair)", "Nickel Core (Jensen)", "Steel Core (American)" }, 0));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "stereo_width", 1 }, "Stereo Width",
        juce::NormalisableRange<float>(0.0f, 150.0f, 0.5f), 100.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "mono_maker", 1 }, "Mono-Maker",
        juce::NormalisableRange<float>(40.0f, 200.0f, 1.0f), 100.0f,
        juce::AudioParameterFloatAttributes().withLabel("Hz")));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { "dry_wet", 1 }, "Mix",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.5f), 100.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { "soft_clipper", 1 }, "Ceiling Clip", true));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { "bypass", 1 }, "Master Bypass", false));

    return { params.begin(), params.end() };
}

void AudioPluginAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock) {
    engine.prepare(sampleRate, samplesPerBlock);
}

void AudioPluginAudioProcessor::releaseResources() {
    engine.reset();
}

bool AudioPluginAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const {
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;
    if (layouts.getMainInputChannelSet() != juce::AudioChannelSet::stereo() &&
        layouts.getMainInputChannelSet() != juce::AudioChannelSet::mono())
        return false;
    return true;
}

void AudioPluginAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& /*midiMessages*/) {
    juce::ScopedNoDenormals noDenormals;

    const int totalNumInputChannels = getTotalNumInputChannels();
    const int totalNumOutputChannels = getTotalNumOutputChannels();

    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear(i, 0, buffer.getNumSamples());

    // Se l'ingresso è mono, copia sul canale destro per elaborazione stereo autentica
    if (totalNumInputChannels == 1 && totalNumOutputChannels >= 2) {
        buffer.copyFrom(1, 0, buffer, 0, 0, buffer.getNumSamples());
    }

    // Lettura parametri APVTS
    int topIdx = static_cast<int>(apvts.getRawParameterValue("topology")->load());
    auto topology = (topIdx == 1) ? dsp171::CompressorTopology::DiodeBridge 
                                  : dsp171::CompressorTopology::VCAMaster;
    visualTopology.store(topIdx, std::memory_order_relaxed);

    int detIdx = static_cast<int>(apvts.getRawParameterValue("detection_mode")->load());
    auto detMode = (detIdx == 1) ? dsp171::DetectionMode::Feedback : dsp171::DetectionMode::Feedforward;

    float thresh = apvts.getRawParameterValue("threshold")->load();

    int ratioIdx = static_cast<int>(apvts.getRawParameterValue("ratio")->load());
    static constexpr float ratioTable[4] = { 1.5f, 2.0f, 4.0f, 10.0f };
    float ratioVal = ratioTable[std::clamp(ratioIdx, 0, 3)];

    int attIdx = static_cast<int>(apvts.getRawParameterValue("attack")->load());
    static constexpr float attackTable[6] = { 0.1f, 0.3f, 1.0f, 3.0f, 10.0f, 30.0f };
    float attackVal = attackTable[std::clamp(attIdx, 0, 5)];

    int relIdx = static_cast<int>(apvts.getRawParameterValue("release")->load());
    static constexpr float releaseTable[5] = { 0.1f, 0.3f, 0.6f, 1.2f, 0.3f };
    float releaseVal = releaseTable[std::clamp(relIdx, 0, 4)];
    bool isAutoRel = (relIdx == 4);

    float makeup = apvts.getRawParameterValue("makeup")->load();

    int scIdx = static_cast<int>(apvts.getRawParameterValue("sidechain_filter")->load());
    auto scMode = static_cast<dsp171::SidechainFilterMode>(std::clamp(scIdx, 0, 4));

    bool useExtSC = apvts.getRawParameterValue("ext_sidechain")->load() > 0.5f;
    float drive = apvts.getRawParameterValue("transformer_drive")->load();
    int transIdx = static_cast<int>(apvts.getRawParameterValue("transformer_type")->load());
    auto transType = static_cast<dsp171::TransformerType>(std::clamp(transIdx, 0, 2));

    float width = apvts.getRawParameterValue("stereo_width")->load();
    float mmHz = apvts.getRawParameterValue("mono_maker")->load();
    float mix = apvts.getRawParameterValue("dry_wet")->load();
    bool clip = apvts.getRawParameterValue("soft_clipper")->load() > 0.5f;
    bool bpass = apvts.getRawParameterValue("bypass")->load() > 0.5f;

    engine.setParameters(
        topology,
        thresh,
        ratioVal,
        attackVal,
        releaseVal,
        isAutoRel,
        makeup,
        scMode,
        useExtSC,
        drive,
        width,
        mmHz,
        mix,
        clip,
        bpass,
        detMode,
        transType
    );

    // Buffer sidechain aux (bus 1)
    const juce::AudioBuffer<float>* scBuf = nullptr;
    auto sidechainBus = getBus(true, 1);
    if (useExtSC && sidechainBus != nullptr && sidechainBus->isEnabled()) {
        auto sidechainBlock = sidechainBus->getBusBuffer(buffer);
        scBuf = &sidechainBlock;
    }

    engine.processBlock(buffer, scBuf);

    // Telemetria thread-safe a 60 FPS
    visualInMeter.store(engine.getInMeterPosition(), std::memory_order_relaxed);
    visualOutMeter.store(engine.getOutMeterPosition(), std::memory_order_relaxed);
    visualGrMeter.store(engine.getGrMeterPosition(), std::memory_order_relaxed);
    visualGainReductionDb.store(engine.getGainReductionDb(), std::memory_order_relaxed);
}

void AudioPluginAudioProcessor::setCurrentProgram(int index) {
    currentProgram = std::clamp(index, 0, getNumPrograms() - 1);
    switch (currentProgram) {
        case 0: // Master Bus Glue (SSL Classic)
            apvts.getParameter("topology")->setValueNotifyingHost(0.0f);
            apvts.getParameter("detection_mode")->setValueNotifyingHost(0.0f); // Feedforward
            apvts.getParameter("threshold")->setValueNotifyingHost(apvts.getParameterRange("threshold").convertTo0to1(-8.0f));
            apvts.getParameter("ratio")->setValueNotifyingHost(1.0f / 3.0f); // 2:1
            apvts.getParameter("attack")->setValueNotifyingHost(4.0f / 5.0f); // 10 ms
            apvts.getParameter("release")->setValueNotifyingHost(1.0f); // Auto
            apvts.getParameter("makeup")->setValueNotifyingHost(apvts.getParameterRange("makeup").convertTo0to1(2.0f));
            apvts.getParameter("sidechain_filter")->setValueNotifyingHost(2.0f / 4.0f); // 90 Hz
            apvts.getParameter("transformer_drive")->setValueNotifyingHost(0.20f);
            apvts.getParameter("transformer_type")->setValueNotifyingHost(0.0f); // Iron Core
            apvts.getParameter("stereo_width")->setValueNotifyingHost(apvts.getParameterRange("stereo_width").convertTo0to1(105.0f));
            apvts.getParameter("mono_maker")->setValueNotifyingHost(apvts.getParameterRange("mono_maker").convertTo0to1(100.0f));
            apvts.getParameter("dry_wet")->setValueNotifyingHost(1.0f);
            break;

        case 1: // Warm Vintage Console (Neve Thick)
            apvts.getParameter("topology")->setValueNotifyingHost(1.0f); // Diode-Bridge
            apvts.getParameter("detection_mode")->setValueNotifyingHost(1.0f); // Feedback
            apvts.getParameter("threshold")->setValueNotifyingHost(apvts.getParameterRange("threshold").convertTo0to1(-14.0f));
            apvts.getParameter("ratio")->setValueNotifyingHost(2.0f / 3.0f); // 4:1
            apvts.getParameter("attack")->setValueNotifyingHost(3.0f / 5.0f); // 3.0 ms
            apvts.getParameter("release")->setValueNotifyingHost(1.0f); // Auto
            apvts.getParameter("makeup")->setValueNotifyingHost(apvts.getParameterRange("makeup").convertTo0to1(3.5f));
            apvts.getParameter("sidechain_filter")->setValueNotifyingHost(1.0f / 4.0f); // 60 Hz
            apvts.getParameter("transformer_drive")->setValueNotifyingHost(0.55f); // 55% Drive
            apvts.getParameter("transformer_type")->setValueNotifyingHost(0.0f); // Iron Core
            apvts.getParameter("stereo_width")->setValueNotifyingHost(apvts.getParameterRange("stereo_width").convertTo0to1(100.0f));
            apvts.getParameter("mono_maker")->setValueNotifyingHost(apvts.getParameterRange("mono_maker").convertTo0to1(120.0f));
            apvts.getParameter("dry_wet")->setValueNotifyingHost(1.0f);
            break;

        case 2: // Modern Hip-Hop & Trap Bus (Thrust + 808 Safe)
            apvts.getParameter("topology")->setValueNotifyingHost(0.0f); // VCA Master
            apvts.getParameter("detection_mode")->setValueNotifyingHost(0.0f); // Feedforward
            apvts.getParameter("threshold")->setValueNotifyingHost(apvts.getParameterRange("threshold").convertTo0to1(-10.0f));
            apvts.getParameter("ratio")->setValueNotifyingHost(1.0f / 3.0f); // 2:1
            apvts.getParameter("attack")->setValueNotifyingHost(5.0f / 5.0f); // 30 ms (maximum transient punch)
            apvts.getParameter("release")->setValueNotifyingHost(0.0f); // 0.1 s fast snap
            apvts.getParameter("makeup")->setValueNotifyingHost(apvts.getParameterRange("makeup").convertTo0to1(2.5f));
            apvts.getParameter("sidechain_filter")->setValueNotifyingHost(1.0f); // Thrust Tilt Filter
            apvts.getParameter("transformer_drive")->setValueNotifyingHost(0.35f);
            apvts.getParameter("transformer_type")->setValueNotifyingHost(1.0f); // Steel Core
            apvts.getParameter("stereo_width")->setValueNotifyingHost(apvts.getParameterRange("stereo_width").convertTo0to1(115.0f));
            apvts.getParameter("mono_maker")->setValueNotifyingHost(apvts.getParameterRange("mono_maker").convertTo0to1(140.0f));
            apvts.getParameter("dry_wet")->setValueNotifyingHost(1.0f);
            break;

        case 3: // Acoustic & Vocal Master (Transparent Mastering)
            apvts.getParameter("topology")->setValueNotifyingHost(0.0f);
            apvts.getParameter("detection_mode")->setValueNotifyingHost(1.0f); // Feedback
            apvts.getParameter("threshold")->setValueNotifyingHost(apvts.getParameterRange("threshold").convertTo0to1(-6.0f));
            apvts.getParameter("ratio")->setValueNotifyingHost(0.0f); // 1.5:1
            apvts.getParameter("attack")->setValueNotifyingHost(4.0f / 5.0f); // 10 ms
            apvts.getParameter("release")->setValueNotifyingHost(1.0f); // Auto
            apvts.getParameter("makeup")->setValueNotifyingHost(apvts.getParameterRange("makeup").convertTo0to1(1.0f));
            apvts.getParameter("sidechain_filter")->setValueNotifyingHost(2.0f / 4.0f); // 90 Hz
            apvts.getParameter("transformer_drive")->setValueNotifyingHost(0.10f);
            apvts.getParameter("transformer_type")->setValueNotifyingHost(0.5f); // Nickel Core
            apvts.getParameter("stereo_width")->setValueNotifyingHost(apvts.getParameterRange("stereo_width").convertTo0to1(110.0f));
            apvts.getParameter("mono_maker")->setValueNotifyingHost(apvts.getParameterRange("mono_maker").convertTo0to1(90.0f));
            apvts.getParameter("dry_wet")->setValueNotifyingHost(1.0f);
            break;

        case 4: // Parallel NYC Drum Punch
            apvts.getParameter("topology")->setValueNotifyingHost(0.0f);
            apvts.getParameter("detection_mode")->setValueNotifyingHost(0.0f); // Feedforward
            apvts.getParameter("threshold")->setValueNotifyingHost(apvts.getParameterRange("threshold").convertTo0to1(-20.0f));
            apvts.getParameter("ratio")->setValueNotifyingHost(1.0f); // 10:1 (Heavy crush)
            apvts.getParameter("attack")->setValueNotifyingHost(0.0f); // 0.1 ms (fastest)
            apvts.getParameter("release")->setValueNotifyingHost(0.0f); // 0.1 s
            apvts.getParameter("makeup")->setValueNotifyingHost(apvts.getParameterRange("makeup").convertTo0to1(6.0f));
            apvts.getParameter("sidechain_filter")->setValueNotifyingHost(2.0f / 4.0f); // 90 Hz
            apvts.getParameter("transformer_drive")->setValueNotifyingHost(0.70f);
            apvts.getParameter("transformer_type")->setValueNotifyingHost(1.0f); // Steel Core
            apvts.getParameter("stereo_width")->setValueNotifyingHost(apvts.getParameterRange("stereo_width").convertTo0to1(120.0f));
            apvts.getParameter("mono_maker")->setValueNotifyingHost(apvts.getParameterRange("mono_maker").convertTo0to1(100.0f));
            apvts.getParameter("dry_wet")->setValueNotifyingHost(0.40f); // 40% Wet (Parallel)
            break;
    }
}

const juce::String AudioPluginAudioProcessor::getProgramName(int index) {
    switch (index) {
        case 0: return "Master Bus Glue (SSL Classic)";
        case 1: return "Warm Vintage Console (Neve Thick)";
        case 2: return "Modern Hip-Hop & Trap Bus";
        case 3: return "Acoustic & Vocal Master";
        case 4: return "Parallel NYC Drum Punch";
        default: return "Custom";
    }
}

void AudioPluginAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void AudioPluginAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType())) {
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
    }
}

juce::AudioProcessorEditor* AudioPluginAudioProcessor::createEditor() {
    return new AudioPluginAudioProcessorEditor(*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new AudioPluginAudioProcessor();
}
