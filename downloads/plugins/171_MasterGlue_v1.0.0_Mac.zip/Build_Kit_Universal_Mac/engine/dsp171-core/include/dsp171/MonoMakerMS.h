#pragma once
#include <cmath>
#include <algorithm>
#include "Common.h"
#include "ZDFSVF.h"

namespace dsp171 {

// =============================================================================
// MONO-MAKER & TRUESPACE MID/SIDE STEREO PROCESSOR
//
// Ispirato alle tecnologie Brainworx / bx_rooMS:
// Converte il bus stereo in coordinate Mid/Side, applica un filtro passa-alto
// a 2-poli a retroazione istantanea (ZDF SVF, 12 dB/ottava) ESCLUSIVAMENTE
// sul canale Side (S), ed effettua lo scaling continuo dell'ampiezza stereo.
//
// Risultato: I bassi al di sotto del punto di taglio (20-400 Hz) convergono
// al 100% in monofonia solida e priva di cancellazioni di fase per subwoofer
// e incisione vinile, mentre le frequenze medio-alte mantengono tridimensionalita.
// =============================================================================

class MonoMakerMS {
public:
    MonoMakerMS() = default;

    void prepare(double sampleRate) {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        filter.reset();
        filter.setParameters(cutoffHz, 0.7071f, static_cast<float>(sr));
    }

    void reset() noexcept {
        filter.reset();
    }

    void setParameters(float monoCutoffHz, float stereoWidth = 1.0f) noexcept {
        cutoffHz = std::clamp(monoCutoffHz, 20.0f, 500.0f);
        width = std::clamp(stereoWidth, 0.0f, 2.5f);
        filter.setParameters(cutoffHz, 0.7071f, static_cast<float>(sr));
    }

    // Elabora una coppia stereofonica in-place
    inline void processSample(float& l, float& r) noexcept {
        // 1. Codifica M/S a potenza costante (1 / sqrt(2) approx 0.70710678f)
        constexpr float INV_SQRT2 = 0.7071067811865475f;
        float mid  = (l + r) * INV_SQRT2;
        float side = (l - r) * INV_SQRT2;

        // 2. Filtraggio passa-alto ZDF SVF sul canale Side
        auto svf = filter.process(side);
        float filteredSide = svf.hp;

        // 3. Scaling ampiezza stereofonica
        filteredSide *= width;

        // 4. Decodifica M/S -> L/R
        l = (mid + filteredSide) * INV_SQRT2;
        r = (mid - filteredSide) * INV_SQRT2;
    }

    float getCutoffHz() const noexcept { return cutoffHz; }
    float getStereoWidth() const noexcept { return width; }

private:
    double sr = 48000.0;
    float cutoffHz = 120.0f;
    float width = 1.0f;
    ZDFSVF64 filter;
};

} // namespace dsp171
