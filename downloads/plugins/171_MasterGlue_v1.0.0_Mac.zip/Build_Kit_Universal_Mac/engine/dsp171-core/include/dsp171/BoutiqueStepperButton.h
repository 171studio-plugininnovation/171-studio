#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <functional>

namespace gui171 {

// ==============================================================================
// Preset Stepper Button (Freccia dorata cesellata < o > stile Plugin Alliance / 171 Studio)
// ==============================================================================
class BoutiqueStepperButton : public juce::Component {
public:
    enum class Direction { Previous, Next };

    explicit BoutiqueStepperButton(Direction dir) : direction(dir) {
        setOpaque(false);
        setMouseCursor(juce::MouseCursor::PointingHandCursor);
    }

    void setOnClick(std::function<void()> cb) {
        onClick = std::move(cb);
    }

    void mouseEnter(const juce::MouseEvent&) override { isHovered = true; repaint(); }
    void mouseExit(const juce::MouseEvent&) override  { isHovered = false; isDown = false; repaint(); }
    void mouseDown(const juce::MouseEvent&) override  { isDown = true; repaint(); }
    void mouseUp(const juce::MouseEvent&) override {
        if (isDown && onClick) onClick();
        isDown = false;
        repaint();
    }

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat().reduced(1.0f);

        // Sfondo beveled bronzo spazzolato
        juce::Colour bgCol = isDown ? juce::Colour(0xff16181f) :
                             isHovered ? juce::Colour(0xff2d2417) : juce::Colour(0xff1d212b);
        g.setColour(bgCol);
        g.fillRoundedRectangle(bounds, 3.5f);

        g.setColour(isHovered ? juce::Colour(0xffffe082) : juce::Colour(0xffc5a059));
        g.drawRoundedRectangle(bounds, 3.5f, 1.0f);

        // Freccia chevron dorata
        float cx = bounds.getCentreX();
        float cy = bounds.getCentreY();
        float sz = 4.0f;

        juce::Path p;
        if (direction == Direction::Previous) {
            p.startNewSubPath(cx + sz * 0.7f, cy - sz);
            p.lineTo(cx - sz * 0.7f, cy);
            p.lineTo(cx + sz * 0.7f, cy + sz);
        } else {
            p.startNewSubPath(cx - sz * 0.7f, cy - sz);
            p.lineTo(cx + sz * 0.7f, cy);
            p.lineTo(cx - sz * 0.7f, cy + sz);
        }

        g.setColour(isHovered ? juce::Colour(0xffffe082) : juce::Colour(0xffd4af37));
        g.strokePath(p, juce::PathStrokeType(1.8f, juce::PathStrokeType::mitered, juce::PathStrokeType::rounded));
    }

private:
    Direction direction;
    bool isHovered = false;
    bool isDown = false;
    std::function<void()> onClick;
};

} // namespace gui171
