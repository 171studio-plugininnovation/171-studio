#pragma once
#include <cmath>
#include <array>
#include <algorithm>
#include <cstdint>
#include <numbers>
#include <span>
#include "Common.h"
#include "PitchDetectorMPM.h"

namespace dsp171 {

// =============================================================================
// PARAMETRI REVERSE ENGINEERING - WAVES TUNE REAL-TIME ARCHITECTURE
// =============================================================================
inline constexpr float PARAM_PITCH_TRACK_DPLL_GAIN = 0.70f;
inline constexpr float PARAM_PITCH_TRACK_DPLL_TC   = 0.30f;

inline constexpr float PARAM_OLA_EXTREMA_DPLL_GAIN = 0.02f;
inline constexpr float PARAM_OLA_EXTREMA_DPLL_TC   = 0.98f;

inline constexpr float PARAM_SNR_ACQUISITION_THRESHOLD = 16.0f; // dB: lock acquisition
inline constexpr float PARAM_SNR_TRACK                 = 1.0f;  // dB: maintain lock
inline constexpr float PARAM_SNR_MAX_FOLLOW            = 8.0f;  // dB: max sudden drop adaptation

inline constexpr float PARAM_VIBRATO_FREQ_HZ                 = 5.8f;   // Hz
inline constexpr float PARAM_VIBRATO_NOTCH_Q                 = 0.6f;   // Q
inline constexpr float PARAM_VIBRATO_INTEGRATION_TIME_MS     = 100.0f; // ms
inline constexpr float PARAM_VIBRATO_ENERGY_DETECTOR_THRESH = 0.6f;   // cents RMS

inline constexpr float PARAM_TUNE_SPEED      = 15.0f;  // ms default
inline constexpr float PARAM_NOTE_TRANSITION = 120.0f; // ms default
inline constexpr float PARAM_TOLERANCE_SLOPE = 30.0f;  // dCents (3.0 cents)

// Stato della macchina a stati a isteresi SNR a 3 stadi
enum class DPLLTrackingState : uint8_t {
    Unlocked = 0,   // Ricerca / non vocalizzato
    Acquiring = 1,  // Acquisizione lock in corso
    Locked = 2      // Sincronizzato con precisione sub-cent
};

// Telemetria in tempo reale del motore DPLL
struct DPLLTelemetry {
    float f0Hz = 0.0f;              // Frequenza fondamentale istantanea f0(t)
    float basePitchHz = 0.0f;       // Frequenza fondamentale depurata dal vibrato
    float ncoPhase = 0.0f;          // Fase istantanea NCO [-pi, pi)
    float snrDb = -120.0f;          // SNR istantaneo stimato in dB
    DPLLTrackingState state = DPLLTrackingState::Unlocked;
    float vibratoCents = 0.0f;      // Ampiezza vibrato isolata in cents
    float vibratoEnergy = 0.0f;     // Inviluppo energetico integrato del vibrato
    bool isVibratoActive = false;   // True se vibrato > soglia 0.6 cents
    float extremaPhaseOffset = 0.0f;// Offset di fase corretto dall'Extrema DPLL
    bool isVoiced = false;          // True se segnale vocalizzato con lock solido
};

// =============================================================================
// ButterworthBandpassPreFilter
// Filtro di pre-elaborazione Butterworth di 2° ordine in cascata:
// - Highpass @ 70 Hz (anti-rumble, soppressione pop plosive e handling noise)
// - Lowpass / De-esser @ 4500 Hz (attenuazione sibilanti, air band e overtoni spuri)
// Implementato in forma diretta II trasposta per stabilità e zero latenza.
// =============================================================================
class ButterworthBandpassPreFilter {
public:
    ButterworthBandpassPreFilter() noexcept { reset(); }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        updateCoeffs();
        reset();
    }

    void reset() noexcept {
        hpS1 = 0.0f; hpS2 = 0.0f;
        lpS1 = 0.0f; lpS2 = 0.0f;
    }

    [[nodiscard]] inline float processSample(float in) noexcept {
        if (!std::isfinite(in)) {
            hpS1 = 0.0f; hpS2 = 0.0f;
            lpS1 = 0.0f; lpS2 = 0.0f;
            return 0.0f;
        }
        // Highpass 70 Hz
        const float hpOut = hpB0 * in + hpS1;
        hpS1 = hpB1 * in - hpA1 * hpOut + hpS2;
        hpS2 = hpB2 * in - hpA2 * hpOut;
        if (std::abs(hpS1) < 1.0e-25f) hpS1 = 0.0f;
        if (std::abs(hpS2) < 1.0e-25f) hpS2 = 0.0f;

        // Lowpass 4500 Hz
        const float lpOut = lpB0 * hpOut + lpS1;
        lpS1 = lpB1 * hpOut - lpA1 * lpOut + lpS2;
        lpS2 = lpB2 * hpOut - lpA2 * lpOut;
        if (std::abs(lpS1) < 1.0e-25f) lpS1 = 0.0f;
        if (std::abs(lpS2) < 1.0e-25f) lpS2 = 0.0f;

        return lpOut;
    }

private:
    void updateCoeffs() noexcept {
        // Highpass @ 70 Hz
        {
            const float fc = 70.0f;
            const float w0 = std::tan(PI * fc / sr);
            const float k = w0 * w0;
            const float sqrt2 = 1.41421356237f;
            const float norm = 1.0f / (1.0f + sqrt2 * w0 + k);
            hpB0 = 1.0f * norm;
            hpB1 = -2.0f * norm;
            hpB2 = 1.0f * norm;
            hpA1 = 2.0f * (k - 1.0f) * norm;
            hpA2 = (1.0f - sqrt2 * w0 + k) * norm;
        }
        // Lowpass @ 4500 Hz
        {
            const float fc = 4500.0f;
            const float w0 = std::tan(PI * fc / sr);
            const float k = w0 * w0;
            const float sqrt2 = 1.41421356237f;
            const float norm = 1.0f / (1.0f + sqrt2 * w0 + k);
            lpB0 = k * norm;
            lpB1 = 2.0f * k * norm;
            lpB2 = k * norm;
            lpA1 = 2.0f * (k - 1.0f) * norm;
            lpA2 = (1.0f - sqrt2 * w0 + k) * norm;
        }
    }

    float sr = 48000.0f;
    float hpB0{1.0f}, hpB1{-2.0f}, hpB2{1.0f}, hpA1{0.0f}, hpA2{0.0f};
    float lpB0{0.0f}, lpB1{0.0f}, lpB2{0.0f}, lpA1{0.0f}, lpA2{0.0f};
    float hpS1{0.0f}, hpS2{0.0f};
    float lpS1{0.0f}, lpS2{0.0f};
};

// =============================================================================
// HilbertPhaseSplitter
// Sdoppiatore di quadratura a 90 gradi ad altissima fedelta' basato su filtro
// FIR Hilbert antisimmetrico a fase lineare a 63 tap con finestra Blackman.
// I coefficienti pari sono identicamente zero (halfband property), richiedendo
// solo 16 moltiplicazioni per campione con simmetria antisimmetrica.
// Ramo In-Phase: puro ritardo di gruppo di M = 31 campioni (0.64 ms a 48 kHz).
// Ramo Quadrature: sfasamento ESATTO di 90.000 gradi su tutta la gamma 35 Hz - 22 kHz.
// =============================================================================
class HilbertPhaseSplitter {
public:
    static constexpr size_t TAPS = 63;
    static constexpr size_t M = (TAPS - 1) / 2; // 31 campioni di ritardo di gruppo
    static constexpr size_t BUFFER_SIZE = 128; // Potenza di 2 per buffer circolare
    static constexpr size_t BUFFER_MASK = BUFFER_SIZE - 1;

    HilbertPhaseSplitter() noexcept {
        initCoefficients();
        reset();
    }

    void reset() noexcept {
        delayLine.fill(0.0f);
        writeIndex = 0;
    }

    // Inserisce un campione e restituisce la coppia ortogonale { In-Phase (I), Quadrature (Q) }
    inline void processSample(float in, float& outI, float& outQ) noexcept {
        delayLine[writeIndex] = in;

        // Ramo In-Phase: campione al centro del filtro (ritardo esatto M)
        const size_t centerIdx = (writeIndex + BUFFER_SIZE - M) & BUFFER_MASK;
        outI = delayLine[centerIdx];

        // Ramo Quadrature: convoluzione antisimmetrica con i soli tap dispari
        // x_hat[n] = sum_{k=1,dispari} h[k] * (x[n - M - k] - x[n - M + k])
        float qSum = 0.0f;
        for (size_t k = 1; k <= M; k += 2) {
            const size_t plusIdx  = (writeIndex + BUFFER_SIZE - M + k) & BUFFER_MASK;
            const size_t minusIdx = (writeIndex + BUFFER_SIZE - M - k) & BUFFER_MASK;
            const float diff = delayLine[minusIdx] - delayLine[plusIdx];
            qSum += coeffHalf[k] * diff;
        }
        outQ = qSum;

        writeIndex = (writeIndex + 1) & BUFFER_MASK;
    }

private:
    void initCoefficients() noexcept {
        coeffHalf.fill(0.0f);
        for (size_t k = 1; k <= M; k += 2) {
            const float fk = static_cast<float>(k);
            const float ideal = 2.0f / (PI * fk);
            // Finestra Blackman-Harris simmetrica
            const float n = static_cast<float>(M + k);
            const float N = static_cast<float>(TAPS - 1);
            const float w = 0.42f - 0.5f * std::cos(2.0f * PI * n / N) + 0.08f * std::cos(4.0f * PI * n / N);
            coeffHalf[k] = ideal * w;
        }
    }

    std::array<float, M + 1> coeffHalf{};
    std::array<float, BUFFER_SIZE> delayLine{};
    size_t writeIndex = 0;
};

// =============================================================================
// DualPathVibratoEngine
// Motore di separazione e re-iniezione del vibrato naturale vocale (Waves Tune RT):
// - Filtro IIR Bandpass a 5.8 Hz con Q = 0.6 (PARAM_VIBRATO_FREQ_HZ, PARAM_VIBRATO_NOTCH_Q)
// - Energy detector con integrazione a 100 ms (PARAM_VIBRATO_INTEGRATION_TIME_MS)
// - Soglia di attivazione a 0.6 cents RMS (PARAM_VIBRATO_ENERGY_DETECTOR_THRESH)
// - Re-iniezione scalata del vibrato tramite moltiplicatore [0% .. 200%]
// =============================================================================
class DualPathVibratoEngine {
public:
    DualPathVibratoEngine() noexcept { reset(); }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        invSr = 1.0f / sr;
        
        // Calcola biquad bandpass a 5.8 Hz
        const float fc = PARAM_VIBRATO_FREQ_HZ;
        const float Q = PARAM_VIBRATO_NOTCH_Q;
        const float w0 = 2.0f * PI * fc / sr;
        const float alpha = std::sin(w0) / (2.0f * Q);
        const float a0 = 1.0f + alpha;

        b0 = alpha / a0;
        b1 = 0.0f;
        b2 = -alpha / a0;
        a1 = (-2.0f * std::cos(w0)) / a0;
        a2 = (1.0f - alpha) / a0;

        // Costante di tempo integrazione 100 ms
        envAlpha = 1.0f - std::exp(-invSr / (PARAM_VIBRATO_INTEGRATION_TIME_MS * 0.001f));
        reset();
    }

    void reset() noexcept {
        s1 = 0.0f;
        s2 = 0.0f;
        vibratoCents = 0.0f;
        integratedEnergy = 0.0f;
        vibratoActive = false;
        multiplier = 1.0f; // 100% default
    }

    void setMultiplier(float mult) noexcept {
        multiplier = std::clamp(mult, 0.0f, 2.0f);
    }

    [[nodiscard]] float getMultiplier() const noexcept { return multiplier; }

    // Elabora la deviazione istantanea di frequenza in cents
    // centsDeviation: scostamento relativo in cents (1200 * log2(f0 / f_center))
    // Restituisce la componente vibrato estratta in cents
    inline float processCents(float centsDeviation) noexcept {
        // Filtraggio bandpass 5.8 Hz
        const float bpOut = b0 * centsDeviation + s1;
        s1 = b1 * centsDeviation - a1 * bpOut + s2;
        s2 = b2 * centsDeviation - a2 * bpOut;
        if (std::abs(s1) < 1.0e-25f) s1 = 0.0f;
        if (std::abs(s2) < 1.0e-25f) s2 = 0.0f;

        vibratoCents = bpOut;

        // Rilevatore d'energia d'inviluppo con costante 100 ms
        const float absVal = std::abs(vibratoCents);
        integratedEnergy += envAlpha * (absVal - integratedEnergy);
        if (integratedEnergy < 1.0e-25f) integratedEnergy = 0.0f;

        // Confronto con soglia 0.6 cents
        vibratoActive = (integratedEnergy >= PARAM_VIBRATO_ENERGY_DETECTOR_THRESH);

        return vibratoCents;
    }

    [[nodiscard]] float getVibratoCents() const noexcept { return vibratoCents; }
    [[nodiscard]] float getIntegratedEnergy() const noexcept { return integratedEnergy; }
    [[nodiscard]] bool isActive() const noexcept { return vibratoActive; }

    // Calcola il pitch risintetizzato re-iniettando il vibrato scalato
    [[nodiscard]] inline float applyVibratoToPitch(float tunedPitchHz) const noexcept {
        if (!vibratoActive || std::abs(vibratoCents) < 1e-4f) {
            return tunedPitchHz;
        }
        // Rapporto in semitoni = vibratoCents * multiplier / 1200
        const float centsToInject = vibratoCents * multiplier;
        return tunedPitchHz * std::pow(2.0f, centsToInject / 1200.0f);
    }

private:
    float sr = 48000.0f;
    float invSr = 1.0f / 48000.0f;
    float b0{0.0f}, b1{0.0f}, b2{0.0f}, a1{0.0f}, a2{0.0f};
    float s1{0.0f}, s2{0.0f};
    float envAlpha = 0.001f;

    float vibratoCents = 0.0f;
    float integratedEnergy = 0.0f;
    bool vibratoActive = false;
    float multiplier = 1.0f;
};

// =============================================================================
// ExtremaOLADPLL
// DPLL secondario a inseguimento lento (PARAM_OLA_EXTREMA_DPLL_GAIN = 0.02,
// PARAM_OLA_EXTREMA_DPLL_TC = 0.98) per l'allineamento continuo delle epoche
// e dei grain boundaries (GCI) evitando distorsioni di fase e sfasamenti.
// =============================================================================
class ExtremaOLADPLL {
public:
    ExtremaOLADPLL() noexcept { reset(); }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        invSr = 1.0f / sr;
        
        // Loop filter a bassissimo guadagno (0.02) e costante di tempo 0.98
        const float loopGain = PARAM_OLA_EXTREMA_DPLL_GAIN;
        kp = loopGain * 0.1f;
        ki = loopGain * (1.0f - PARAM_OLA_EXTREMA_DPLL_TC) * 0.05f * invSr;
        reset();
    }

    void reset() noexcept {
        phaseOffset = 0.0f;
        integrator = 0.0f;
        prevDerivative = 0.0f;
        prevExtremumSample = 0.0f;
        samplesSinceExtremum = 0;
    }

    // Misura l'errore tra la fase NCO e l'estremo fisico della forma d'onda
    inline float update(float ncoPhase, float currentSample, float prevSample) noexcept {
        const float derivative = currentSample - prevSample;
        // Rilevamento passaggio per lo zero della derivata con curvatura negativa (picco positivo)
        const bool isPeak = (prevDerivative > 0.0f && derivative <= 0.0f);
        prevDerivative = derivative;

        if (isPeak) {
            // All'estremo, l'NCO ideale dovrebbe avere fase zero
            float phaseErr = -ncoPhase;
            while (phaseErr > PI) phaseErr -= 2.0f * PI;
            while (phaseErr < -PI) phaseErr += 2.0f * PI;

            // Filtro ad anello del 2° ordine
            integrator += ki * phaseErr;
            integrator = std::clamp(integrator, -PI * 0.5f, PI * 0.5f);
            phaseOffset = kp * phaseErr + integrator;
            phaseOffset = std::clamp(phaseOffset, -PI * 0.5f, PI * 0.5f);
        }

        return phaseOffset;
    }

    [[nodiscard]] float getPhaseOffset() const noexcept { return phaseOffset; }

private:
    float sr = 48000.0f;
    float invSr = 1.0f / 48000.0f;
    float kp = 0.002f;
    float ki = 0.00001f;
    float phaseOffset = 0.0f;
    float integrator = 0.0f;
    float prevDerivative = 0.0f;
    float prevExtremumSample = 0.0f;
    uint32_t samplesSinceExtremum = 0;
};

// =============================================================================
// DPLLPitchTracker
// Motore Completo Dual DPLL ispirato all'architettura originale Waves Tune RT:
// 1. Pre-filtraggio Butterworth cascata (HP 70 Hz + LP 4.5 kHz).
// 2. Sdoppiatore Hilbert polifase I/Q a 8 stadi per demodulazione di fase istantanea.
// 3. Pitch DPLL principale: PI controller del 2 ordine + NCO campione per campione.
// 4. Extrema OLA DPLL: sincronizzazione continua delle epoche sui cicli vocali.
// 5. Macchina a stati a isteresi SNR a 3 stadi (16 dB lock, 1 dB track, 8 dB follow).
// 6. Dual-Path Vibrato Engine: isolamento a 5.8 Hz, energy detector e re-iniezione.
// 7. Zero allocazioni dinamiche nel process thread, SIMD-friendly, C++20 standard.
// =============================================================================
class DPLLPitchTracker {
public:
    DPLLPitchTracker() noexcept {
        reset();
    }

    void prepare(double sampleRate, VocalRange range = VocalRange::Wide) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        invSr = 1.0f / sr;

        preFilter.prepare(sr);
        phaseSplitter.reset();
        vibratoEngine.prepare(sr);
        extremaDPLL.prepare(sr);

        setVocalRange(range);
        updateLoopFilterParameters();
        reset();
    }

    void reset() noexcept {
        preFilter.reset();
        phaseSplitter.reset();
        vibratoEngine.reset();
        extremaDPLL.reset();

        ncoPhase = 0.0f;
        ncoFrequencyHz = 220.0f;
        centerFrequencyHz = 220.0f;
        smoothedF0Hz = 220.0f;
        basePitchHz = 220.0f;

        dpllIntegrator = 0.0f;
        dpllProportional = 0.0f;

        phaseDelayBuffer.fill(0.0f);
        phaseDelayWriteIdx = 0;

        periodDelayBuffer.fill(0.0f);
        periodDelayWriteIdx = 0;
        smoothedPeriodicity = 0.0f;
        smoothedDiffSq = 0.0f;
        smoothedSigSq = 0.0f;

        powerSignal = 0.0f;
        powerError = 0.0f;
        noiseFloorPower = 1.0e-6f;
        snrDb = -120.0f;
        peakSnrDb = -120.0f;

        trackingState = DPLLTrackingState::Unlocked;
        acquisitionHoldSamples = 0;
        dropoutTimerSamples = 0;

        prevSample = 0.0f;
        zcPrevSign = 0;
        zcIntervalSamples = 0;
        prevZcSample = 0.0f;
        prevFracZero = 0.0f;
        coarseFrequencyHz = 220.0f;

        sustainCounterSamples = 0;
    }

    // Configura il range vocale di ricerca (Input Type)
    void setVocalRange(VocalRange range) noexcept {
        vocalRange = range;
        switch (range) {
            case VocalRange::AltoTenor: minPitchHz = 85.0f;  maxPitchHz = 620.0f;  break;
            case VocalRange::Soprano:   minPitchHz = 125.0f; maxPitchHz = 1100.0f; break;
            case VocalRange::LowMale:   minPitchHz = 55.0f;  maxPitchHz = 360.0f;  break;
            case VocalRange::Wide:
            default:                    minPitchHz = 45.0f;  maxPitchHz = 1250.0f; break;
        }
        ncoFrequencyHz = std::clamp(ncoFrequencyHz, minPitchHz, maxPitchHz);
    }

    [[nodiscard]] VocalRange getVocalRange() const noexcept { return vocalRange; }

    // --- Controlli Parametrici Waves Tune Real-Time ---

    // Tune Speed [0.1 .. 800 ms] (Default 15.0 ms)
    void setTuneSpeedMs(float speedMs) noexcept {
        tuneSpeedMs = std::clamp(speedMs, 0.1f, 800.0f);
        speedAlpha = 1.0f - std::exp(-invSr / (tuneSpeedMs * 0.001f));
    }

    // Note Transition [0.1 .. 800 ms] (Default 120.0 ms)
    void setNoteTransitionMs(float transMs) noexcept {
        noteTransitionMs = std::clamp(transMs, 0.1f, 800.0f);
    }

    // Tolerance (Cents [0..40] & Time [0..300 ms])
    void setTolerance(float cents, float timeMs) noexcept {
        toleranceCents = std::clamp(cents, 0.0f, 40.0f);
        toleranceTimeMs = std::clamp(timeMs, 0.0f, 300.0f);
        toleranceMaxSamples = static_cast<uint32_t>(toleranceTimeMs * 0.001f * sr);
    }

    // Vibrato Multiplier [0% .. 200%]
    void setVibratoMultiplier(float mult) noexcept {
        vibratoEngine.setMultiplier(mult);
    }

    [[nodiscard]] float getVibratoMultiplier() const noexcept {
        return vibratoEngine.getMultiplier();
    }

    // --- Elaborazione Campione per Campione (Zero Allocazioni, Hard Real-Time) ---

    // Elabora un campione audio e restituisce la frequenza fondamentale f0(t) tracciata
    inline float processSample(float inSample) noexcept {
        // 1. Pre-filtraggio Butterworth (HP 70 Hz + LP 4.5 kHz)
        const float preFiltered = preFilter.processSample(inSample);

        // 2. Coarse Zero-Crossing Period Estimator (ausilio per rapido pull-in in caso di sblocco)
        updateCoarseEstimator(preFiltered);

        // Memorizza nel buffer di ritardo per stima HNR periodo-su-periodo con interpolazione sub-sample
        periodDelayBuffer[periodDelayWriteIdx] = preFiltered;
        const float nominalT0 = (coarseFrequencyHz > 10.0f) ? (sr / coarseFrequencyHz) : (sr / 220.0f);
        const float safeT0 = std::clamp(nominalT0, 10.0f, static_cast<float>(PERIOD_DELAY_SIZE - 4));
        const size_t t0Floor = static_cast<size_t>(std::floor(safeT0));
        const float frac = safeT0 - static_cast<float>(t0Floor);

        const size_t idx0 = (periodDelayWriteIdx + PERIOD_DELAY_SIZE - t0Floor) & PERIOD_DELAY_MASK;
        const size_t idx1 = (periodDelayWriteIdx + PERIOD_DELAY_SIZE - t0Floor - 1) & PERIOD_DELAY_MASK;
        const float delayedSample = (1.0f - frac) * periodDelayBuffer[idx0] + frac * periodDelayBuffer[idx1];
        periodDelayWriteIdx = (periodDelayWriteIdx + 1) & PERIOD_DELAY_MASK;

        // Calcolo Harmonic-to-Noise Ratio (HNR / SNR) periodo-su-periodo (Waves Tune RT):
        // Differenza quadratica normalizzata (NSDF) per evitare singolarità allo zero-crossing
        const float diff = preFiltered - delayedSample;
        const float diffSq = diff * diff;
        const float sigSq = preFiltered * preFiltered + delayedSample * delayedSample + 1.0e-7f;
        const float rAlpha = 0.005f; // ~4 ms averaging
        smoothedDiffSq += rAlpha * (diffSq - smoothedDiffSq);
        smoothedSigSq += rAlpha * (sigSq - smoothedSigSq);
        powerSignal = smoothedSigSq * 0.5f;

        const float normError = std::clamp(smoothedDiffSq / (smoothedSigSq + 1.0e-7f), 0.0f, 1.0f);
        const float rSafe = std::clamp(1.0f - normError, 0.001f, 0.999f);
        smoothedPeriodicity = rSafe;

        if (powerSignal > 1.0e-6f) {
            snrDb = 10.0f * std::log10(rSafe / (1.0f - rSafe + 1.0e-4f));
        } else {
            snrDb = -120.0f;
        }

        // 3. Sdoppiatore Hilbert a quadratura polifase (I/Q)
        float inI = 0.0f, inQ = 0.0f;
        phaseSplitter.processSample(preFiltered, inI, inQ);

        // 4. Oscillatore NCO a fase istantanea con allineamento temporale al ritardo di gruppo Hilbert (M = 31)
        phaseDelayBuffer[phaseDelayWriteIdx] = ncoPhase;
        const size_t delayedPhaseIdx = (phaseDelayWriteIdx + PHASE_DELAY_CAPACITY - HilbertPhaseSplitter::M) & PHASE_DELAY_MASK;
        const float alignedNcoPhase = phaseDelayBuffer[delayedPhaseIdx];
        phaseDelayWriteIdx = (phaseDelayWriteIdx + 1) & PHASE_DELAY_MASK;

        const float cosPhase = std::cos(alignedNcoPhase);
        const float sinPhase = std::sin(alignedNcoPhase);

        // Demodulazione istantanea perfettamente allineata nel tempo: z * e^(-j * phi)
        // I_demod = I * cos + Q * sin
        // Q_demod = Q * cos - I * sin
        const float iDemod = inI * cosPhase + inQ * sinPhase;
        const float qDemod = inQ * cosPhase - inI * sinPhase;

        // 5. Calcolo errore di fase istantaneo con feedback negativo rigoroso
        float phaseError = 0.0f;
        const float signalMagSq = iDemod * iDemod + qDemod * qDemod;
        if (signalMagSq > 1e-12f) {
            phaseError = std::atan2(-qDemod, iDemod);
        }

        // 6. Macchina a stati a isteresi SNR a 3 stadi (16 dB lock, 1 dB track, 8 dB follow)
        updateSNRStateMachine();

        // 7. Loop Filter del 2 ordine (PI Controller) per il Pitch DPLL
        if (trackingState == DPLLTrackingState::Acquiring) {
            // Durante l'acquisizione, aggancia immediatamente coarseFrequencyHz
            centerFrequencyHz = coarseFrequencyHz;
            ncoFrequencyHz = coarseFrequencyHz;
            dpllIntegrator = 0.0f;
            sustainCounterSamples = 0;
        } else if (trackingState == DPLLTrackingState::Locked) {
            // Locked: il PI controller del 2° ordine traccia e annulla l'errore di fase
            dpllIntegrator += dpllKi * phaseError;
            const float maxDeltaF = 0.4f; // Max deviazione fine DPLL dal centro fondamentale (+/- 0.4 Hz)
            dpllIntegrator = std::clamp(dpllIntegrator, -maxDeltaF, maxDeltaF);
            dpllProportional = std::clamp(dpllKp * phaseError, -0.2f, 0.2f);

            centerFrequencyHz = coarseFrequencyHz;
            ncoFrequencyHz = centerFrequencyHz + dpllProportional + dpllIntegrator;
            ncoFrequencyHz = std::clamp(ncoFrequencyHz, minPitchHz, maxPitchHz);
            sustainCounterSamples++;
        } else {
            // Unlocked
            centerFrequencyHz = coarseFrequencyHz;
            ncoFrequencyHz = coarseFrequencyHz;
            dpllIntegrator = 0.0f;
            sustainCounterSamples = 0;
        }

        // Avanza la fase dell'NCO per il campione successivo
        const float phaseInc = 2.0f * PI * ncoFrequencyHz * invSr;
        ncoPhase += phaseInc;
        if (ncoPhase >= PI)  ncoPhase -= 2.0f * PI;
        if (ncoPhase < -PI) ncoPhase += 2.0f * PI;

        // 9. Extrema OLA DPLL (sincronizzazione dei grain boundaries sulle epoche GCI)
        const float extremaOffset = extremaDPLL.update(ncoPhase, preFiltered, prevSample);
        prevSample = preFiltered;

        // 10. Dual-Path Vibrato Separation Engine
        // Calcola cents deviation rispetto al pitch di riferimento smoothed
        smoothedF0Hz += speedAlpha * (ncoFrequencyHz - smoothedF0Hz);
        const float currentCents = (smoothedF0Hz > 20.0f) ? 1200.0f * std::log2(ncoFrequencyHz / smoothedF0Hz) : 0.0f;
        const float vibCents = vibratoEngine.processCents(currentCents);

        // Separa il pitch base dal vibrato naturale
        basePitchHz = ncoFrequencyHz * std::pow(2.0f, -vibCents / 1200.0f);

        // Prepara telemetria aggiornata
        telemetry.f0Hz = ncoFrequencyHz;
        telemetry.basePitchHz = basePitchHz;
        telemetry.ncoPhase = ncoPhase;
        telemetry.snrDb = snrDb;
        telemetry.state = trackingState;
        telemetry.vibratoCents = vibCents;
        telemetry.vibratoEnergy = vibratoEngine.getIntegratedEnergy();
        telemetry.isVibratoActive = vibratoEngine.isActive();
        telemetry.extremaPhaseOffset = extremaOffset;
        telemetry.isVoiced = (trackingState == DPLLTrackingState::Locked);

        return ncoFrequencyHz;
    }

    // Elabora un intero blocco di campioni
    void processBlock(const float* input, float* outF0, size_t numSamples) noexcept {
        if (input == nullptr || outF0 == nullptr || numSamples == 0) return;
        for (size_t i = 0; i < numSamples; ++i) {
            outF0[i] = processSample(input[i]);
        }
    }

    // --- Accesso Telemetria e Stato ---

    [[nodiscard]] const DPLLTelemetry& getTelemetry() const noexcept { return telemetry; }
    [[nodiscard]] bool isLocked() const noexcept { return trackingState == DPLLTrackingState::Locked; }
    [[nodiscard]] float getEstimatedF0() const noexcept { return ncoFrequencyHz; }
    [[nodiscard]] float getCoarseFrequencyHz() const noexcept { return coarseFrequencyHz; }
    [[nodiscard]] float getCenterFrequencyHz() const noexcept { return centerFrequencyHz; }
    [[nodiscard]] float getDpllIntegrator() const noexcept { return dpllIntegrator; }
    [[nodiscard]] float getBasePitchHz() const noexcept { return basePitchHz; }
    [[nodiscard]] float getSNR() const noexcept { return snrDb; }
    [[nodiscard]] DPLLTrackingState getState() const noexcept { return trackingState; }
    [[nodiscard]] float getNCOPhase() const noexcept { return ncoPhase; }
    [[nodiscard]] float getVibratoCents() const noexcept { return vibratoEngine.getVibratoCents(); }
    [[nodiscard]] bool isVibratoActive() const noexcept { return vibratoEngine.isActive(); }
    [[nodiscard]] float applyVibratoToPitch(float targetHz) const noexcept {
        return vibratoEngine.applyVibratoToPitch(targetHz);
    }

    // Inietta o guida la frequenza centrale di pull-in da un pitch detector ad alta confidenza (es. MPM/NSDF)
    void setCoarseFrequency(float freqHz) noexcept {
        if (std::isfinite(freqHz) && freqHz >= minPitchHz && freqHz <= maxPitchHz) {
            coarseFrequencyHz = freqHz;
            if (trackingState == DPLLTrackingState::Unlocked && powerSignal > 1.0e-5f) {
                centerFrequencyHz = freqHz;
                ncoFrequencyHz = freqHz;
            }
        }
    }

private:
    void updateLoopFilterParameters() noexcept {
        // Parametri loop filter del 2° ordine derivati da GAIN = 0.70 e TC = 0.30
        const float gain = PARAM_PITCH_TRACK_DPLL_GAIN;
        const float tc = PARAM_PITCH_TRACK_DPLL_TC;
        dpllKp = gain * (1.0f / tc);   // ~2.33 Hz/rad (inseguimento fase morbido e privo di cycle-slip)
        dpllKi = gain * (0.001f / tc); // ~0.00233 Hz/rad/sample
    }

    // Rilevatore Coarse Zero-Crossing Period per initial pull-in con interpolazione sub-sample
    inline void updateCoarseEstimator(float s) noexcept {
        zcIntervalSamples++;
        const int sign = (s >= 0.0f) ? 1 : -1;
        if (zcPrevSign < 0 && sign > 0) {
            // Calcolo interpolazione sub-sample esatta del punto di attraversamento dello zero
            const float fracZero = (prevZcSample != s) ? (-prevZcSample / (s - prevZcSample)) : 0.0f;
            const float exactPeriodSamples = static_cast<float>(zcIntervalSamples) + fracZero - prevFracZero;
            prevFracZero = fracZero;

            if (exactPeriodSamples >= (sr / maxPitchHz) && exactPeriodSamples <= (sr / minPitchHz)) {
                const float estF = sr / exactPeriodSamples;
                coarseFrequencyHz = std::clamp(estF, minPitchHz, maxPitchHz);
            }
            zcIntervalSamples = 0;
        } else if (zcIntervalSamples > static_cast<size_t>(sr / minPitchHz) * 2) {
            zcIntervalSamples = static_cast<size_t>(sr / minPitchHz);
        }
        zcPrevSign = sign;
        prevZcSample = s;
    }

    // Macchina a stati a isteresi SNR a 3 stadi
    inline void updateSNRStateMachine() noexcept {
        switch (trackingState) {
            case DPLLTrackingState::Unlocked: {
                // Per acquisire il lock, l'SNR deve superare la soglia di acquisizione (16 dB)
                if (snrDb >= PARAM_SNR_ACQUISITION_THRESHOLD) {
                    trackingState = DPLLTrackingState::Acquiring;
                    acquisitionHoldSamples = 0;
                    peakSnrDb = snrDb;
                }
                break;
            }
            case DPLLTrackingState::Acquiring: {
                if (snrDb >= PARAM_SNR_ACQUISITION_THRESHOLD) {
                    acquisitionHoldSamples++;
                    peakSnrDb = std::max(peakSnrDb, snrDb);
                    // Conferma lock dopo ~10 ms continui (o 2 cicli di fondamentale)
                    const uint32_t confirmSamples = static_cast<uint32_t>(sr * 0.008f);
                    if (acquisitionHoldSamples >= confirmSamples) {
                        trackingState = DPLLTrackingState::Locked;
                        dropoutTimerSamples = 0;
                    }
                } else {
                    // Fallito aggancio: ritorna ad Unlocked
                    trackingState = DPLLTrackingState::Unlocked;
                    acquisitionHoldSamples = 0;
                }
                break;
            }
            case DPLLTrackingState::Locked: {
                peakSnrDb = std::max(peakSnrDb * 0.9998f, snrDb);

                // Condizione 1: Caduta sotto SNR minimo di mantenimento (1 dB)
                const bool dropBelowTrack = (snrDb < PARAM_SNR_TRACK);
                // Condizione 2: Caduta improvvisa oltre PARAM_SNR_MAX_FOLLOW (8 dB rispetto al picco)
                const bool suddenPlunge = (snrDb < (peakSnrDb - PARAM_SNR_MAX_FOLLOW));

                if (dropBelowTrack || suddenPlunge) {
                    dropoutTimerSamples++;
                    // Tolleranza temporale prima di sganciare (~15 ms di hold time per preservare glottal pauses)
                    const uint32_t holdSamples = static_cast<uint32_t>(sr * 0.015f);
                    if (dropoutTimerSamples >= holdSamples) {
                        trackingState = DPLLTrackingState::Unlocked;
                        dropoutTimerSamples = 0;
                    }
                } else {
                    dropoutTimerSamples = 0;
                }
                break;
            }
        }
    }

    float sr = 48000.0f;
    float invSr = 1.0f / 48000.0f;

    // Range vocale
    VocalRange vocalRange = VocalRange::Wide;
    float minPitchHz = 45.0f;
    float maxPitchHz = 1250.0f;

    // Sottomoduli
    ButterworthBandpassPreFilter preFilter;
    HilbertPhaseSplitter phaseSplitter;
    DualPathVibratoEngine vibratoEngine;
    ExtremaOLADPLL extremaDPLL;

    // NCO & Pitch DPLL Loop Filter
    static constexpr size_t PHASE_DELAY_CAPACITY = 64;
    static constexpr size_t PHASE_DELAY_MASK = 63;
    std::array<float, PHASE_DELAY_CAPACITY> phaseDelayBuffer{};
    size_t phaseDelayWriteIdx = 0;

    static constexpr size_t PERIOD_DELAY_SIZE = 2048;
    static constexpr size_t PERIOD_DELAY_MASK = 2047;
    std::array<float, PERIOD_DELAY_SIZE> periodDelayBuffer{};
    size_t periodDelayWriteIdx = 0;
    float smoothedPeriodicity = 0.0f;
    float smoothedDiffSq = 0.0f;
    float smoothedSigSq = 0.0f;

    float ncoPhase = 0.0f;
    float ncoFrequencyHz = 220.0f;
    float centerFrequencyHz = 220.0f;
    float smoothedF0Hz = 220.0f;
    float basePitchHz = 220.0f;
    float dpllKp = 0.05f;
    float dpllKi = 0.001f;
    float dpllProportional = 0.0f;
    float dpllIntegrator = 0.0f;

    // Stima SNR
    float powerSignal = 0.0f;
    float powerError = 0.0f;
    float noiseFloorPower = 1.0e-6f;
    float snrDb = -120.0f;
    float peakSnrDb = -120.0f;

    // Macchina a stati
    DPLLTrackingState trackingState = DPLLTrackingState::Unlocked;
    uint32_t acquisitionHoldSamples = 0;
    uint32_t dropoutTimerSamples = 0;

    // Coarse Zero-Crossing Period Estimator
    float prevSample = 0.0f;
    int zcPrevSign = 0;
    size_t zcIntervalSamples = 0;
    float prevZcSample = 0.0f;
    float prevFracZero = 0.0f;
    float coarseFrequencyHz = 220.0f;

    // Parametri dinamici Waves Tune RT
    float tuneSpeedMs = PARAM_TUNE_SPEED;
    float speedAlpha = 0.001f;
    float noteTransitionMs = PARAM_NOTE_TRANSITION;
    float toleranceCents = 0.0f;
    float toleranceTimeMs = 0.0f;
    uint32_t toleranceMaxSamples = 0;
    uint32_t sustainCounterSamples = 0;

    DPLLTelemetry telemetry{};
};

} // namespace dsp171
