#pragma once
#include <cmath>
#include <algorithm>
#include <array>
#include <cstdint>
#include "Common.h"
#include "FastMath.h"

namespace dsp171 {

// =============================================================================
// CLA76Compressor
// Emulatore dell'amplificatore limitatore FET Universal Audio 1176 / Waves CLA-76
//
// Caratteristiche Modellistiche:
// 1. Rilevatore e Attenuatore FET ultra-veloce a tempo discreto:
//    - Attacco: da 1 (1000 microsecondi = 1 ms) a 7 (meno di 20 microsecondi!)
//    - Rilascio: da 1 (1000 ms = 1 secondo) a 7 (50 millisecondi)
// 2. 4 Rapporti di Compressione con Soglia Interattiva:
//    - 4:1 (Soglia -18 dBFS), 8:1 (-16 dBFS), 12:1 (-14 dBFS), 20:1 (-12 dBFS)
// 3. Modalità "ALL BUTTONS IN" (British Mode):
//    - Esplosione iniziale del fronte d'onda, collasso del bias FET, saturazione spinta
// 4. Due Revisioni Hardware Vintage:
//    - Blackface (Rev D/E): Basso rumore, trasformatori lineari, punch solido
//    - Blue Stripe (Rev A/B): Guadagno superiore, grinta aggressiva sulle medie (2-4 kHz)
// 5. Modalità "Comp Off": stadio preamplificatore e trasformatore attivo senza GR.
// 6. Stadio Input (-inf..0 dB), Output (-inf..0 dB), Mix [0..100%] e Hum 50/60Hz.
// =============================================================================
class CLA76Compressor {
public:
    enum class Ratio : uint8_t {
        Ratio4  = 0, // 4:1
        Ratio8  = 1, // 8:1
        Ratio12 = 2, // 12:1
        Ratio20 = 3, // 20:1
        AllButtons = 4 // All Buttons In / British Mode
    };

    enum class Revision : uint8_t {
        Blackface = 0, // LN Revision D/E
        BlueStripe = 1  // Revision A (più armoniche e mordente sulle medie)
    };

    enum class AnalogHum : uint8_t {
        Off  = 0,
        Hum50Hz = 1,
        Hum60Hz = 2
    };

    CLA76Compressor() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        invSr = 1.0f / sr;
        dt = invSr;

        // Progetta filtro passa-alto 100 Hz per sidechain (Butterworth 2-pole)
        const float w0 = 2.0f * 3.14159265f * 100.0f * invSr;
        const float cosw0 = std::cos(w0);
        const float sinw0 = std::sin(w0);
        const float alpha = sinw0 / (2.0f * 0.70710678f);
        const float a0 = 1.0f + alpha;

        scHpB0 = ((1.0f + cosw0) * 0.5f) / a0;
        scHpB1 = (-(1.0f + cosw0)) / a0;
        scHpB2 = ((1.0f + cosw0) * 0.5f) / a0;
        scHpA1 = (-2.0f * cosw0) / a0;
        scHpA2 = (1.0f - alpha) / a0;

        updateTimeConstants();
        reset();
    }

    void reset() noexcept {
        envelopeL = 0.0f;
        envelopeR = 0.0f;
        currentGRL_dB = 0.0f;
        currentGRR_dB = 0.0f;
        humPhase = 0.0f;
        scHpStateL1 = 0.0f;
        scHpStateL2 = 0.0f;
        scHpStateR1 = 0.0f;
        scHpStateR2 = 0.0f;
    }

    // Input Control: da -60.0 dB a 0.0 dB (determina la spinta nel circuito FET)
    void setInputDb(float inDb) noexcept {
        inputDb = std::clamp(inDb, -60.0f, 0.0f);
        // +30 dB di guadagno base per allineare l'ingresso al punto di lavoro 1176
        inputGainLin = std::pow(10.0f, (inputDb + 30.0f) * 0.05f);
    }

    // Output Control: da -60.0 dB a 0.0 dB (make-up gain)
    void setOutputDb(float outDb) noexcept {
        outputDb = std::clamp(outDb, -60.0f, 0.0f);
        outputGainLin = std::pow(10.0f, (outputDb + 18.0f) * 0.05f);
    }

    // Attack: da 1 (più lento, 1 ms) a 7 (più veloce, 20 microsecondi)
    void setAttackKnob(float att1To7) noexcept {
        attackKnob = std::clamp(att1To7, 1.0f, 7.0f);
        updateTimeConstants();
    }

    // Release: da 1 (più lento, 1000 ms) a 7 (più veloce, 50 ms)
    void setReleaseKnob(float rel1To7) noexcept {
        releaseKnob = std::clamp(rel1To7, 1.0f, 7.0f);
        updateTimeConstants();
    }

    // Ratio: 4:1, 8:1, 12:1, 20:1 o All Buttons In
    void setRatio(Ratio r) noexcept {
        ratio = r;
    }

    void setAllButtons(bool enabled) noexcept {
        ratio = enabled ? Ratio::AllButtons : Ratio::Ratio4;
    }

    // Revisione: Blackface vs Blue Stripe
    void setRevision(Revision rev) noexcept {
        revision = rev;
    }

    void setBlueStripe(bool isBlue) noexcept {
        revision = isBlue ? Revision::BlueStripe : Revision::Blackface;
    }

    // Comp Off (disabilita il Gain Reduction preservando il preamplificatore FET)
    void setCompOff(bool off) noexcept {
        compOff = off;
    }

    // Analog Hum (Off, 50Hz, 60Hz)
    void setAnalogHum(AnalogHum hum) noexcept {
        analogHum = hum;
    }

    // Mix Parallelo [0% .. 100%]
    void setMix(float mix0To100) noexcept {
        mix = std::clamp(mix0To100 * 0.01f, 0.0f, 1.0f);
    }

    // Sidechain High-Pass Filter (100 Hz Studio Standard)
    void setSidechainHighPass(bool enabled) noexcept {
        scHighPass = enabled;
    }
    [[nodiscard]] bool isSidechainHighPass() const noexcept {
        return scHighPass;
    }

    // Telemetria Gain Reduction in dB
    [[nodiscard]] float getGainReductionL() const noexcept { return currentGRL_dB; }
    [[nodiscard]] float getGainReductionR() const noexcept { return currentGRR_dB; }

    // Elaborazione Audio Stereo Phase-Linked
    void process(float* inOutL, float* inOutR, size_t numSamples) noexcept {
        if (!inOutL || !inOutR || numSamples == 0) return;

        for (size_t i = 0; i < numSamples; ++i) {
            const float dryL = inOutL[i];
            const float dryR = inOutR[i];

            // 1. Guadagno d'ingresso che spinge il segnale verso la soglia
            float sigL = dryL * inputGainLin;
            float sigR = dryR * inputGainLin;

            // 2. Rilevatore di picco FET ultra-veloce con accoppiamento stereo
            float attenL = 1.0f;
            float attenR = 1.0f;

            if (!compOff) {
                float detL = sigL;
                float detR = sigR;
                if (scHighPass) {
                    const float wL = detL - scHpA1 * scHpStateL1 - scHpA2 * scHpStateL2;
                    detL = scHpB0 * wL + scHpB1 * scHpStateL1 + scHpB2 * scHpStateL2;
                    scHpStateL2 = scHpStateL1;
                    scHpStateL1 = wL;

                    const float wR = detR - scHpA1 * scHpStateR1 - scHpA2 * scHpStateR2;
                    detR = scHpB0 * wR + scHpB1 * scHpStateR1 + scHpB2 * scHpStateR2;
                    scHpStateR2 = scHpStateR1;
                    scHpStateR1 = wR;
                }

                const float peakL = std::abs(detL);
                const float peakR = std::abs(detR);
                const float maxPeak = std::max(peakL, peakR);

                // Calcolo Gain Reduction target in base al Ratio e alla soglia interattiva
                const float targetGrDb = computeTargetGR(maxPeak);

                // Rilevatore balistico FET (20 us - 1 ms attacco / 50 - 1000 ms rilascio)
                if (targetGrDb > envelopeL) {
                    envelopeL += attackCoeff * (targetGrDb - envelopeL);
                } else {
                    envelopeL += releaseCoeff * (targetGrDb - envelopeL);
                }
                envelopeR = envelopeL; // Stereo-link coerenza di fase

                currentGRL_dB = envelopeL;
                currentGRR_dB = envelopeR;

                attenL = std::pow(10.0f, -currentGRL_dB * 0.05f);
                attenR = std::pow(10.0f, -currentGRR_dB * 0.05f);
            } else {
                currentGRL_dB = 0.0f;
                currentGRR_dB = 0.0f;
            }

            // 3. Attenuazione FET applicata al segnale
            float wetL = sigL * attenL;
            float wetR = sigR * attenR;

            // 4. Output Stage & Saturazione Hardware
            wetL *= outputGainLin;
            wetR *= outputGainLin;

            // Saturazione del preamplificatore FET e trasformatore d'uscita
            // Blue Stripe ha una spinta sulle armoniche dispari superiore a Blackface
            wetL = saturateFET(wetL, revision, ratio == Ratio::AllButtons);
            wetR = saturateFET(wetR, revision, ratio == Ratio::AllButtons);

            // 5. Hum Analogico
            if (analogHum != AnalogHum::Off) {
                const float humFreq = (analogHum == AnalogHum::Hum50Hz) ? 50.0f : 60.0f;
                humPhase += humFreq * invSr * 2.0f * 3.14159265f;
                if (humPhase > 2.0f * 3.14159265f) humPhase -= 2.0f * 3.14159265f;
                const float humSig = 0.00025f * (std::sin(humPhase) + 0.45f * std::sin(2.0f * humPhase));
                wetL += humSig;
                wetR += humSig;
            }

            // 6. Dry / Wet Mix
            inOutL[i] = (1.0f - mix) * dryL + mix * wetL;
            inOutR[i] = (1.0f - mix) * dryR + mix * wetR;
        }
    }

private:
    float computeTargetGR(float peakAmp) const noexcept {
        if (peakAmp <= 1.0e-5f) return 0.0f;
        const float peakDb = 20.0f * std::log10(peakAmp);

        // Interazione Soglia / Ratio autentica 1176:
        // A ratio più alti corrisponde una soglia più alta!
        float threshold = -18.0f;
        float rVal = 4.0f;

        switch (ratio) {
            case Ratio::Ratio4:
                threshold = -18.0f;
                rVal = 4.0f;
                break;
            case Ratio::Ratio8:
                threshold = -16.0f;
                rVal = 8.0f;
                break;
            case Ratio::Ratio12:
                threshold = -14.0f;
                rVal = 12.0f;
                break;
            case Ratio::Ratio20:
                threshold = -12.0f;
                rVal = 20.0f;
                break;
            case Ratio::AllButtons:
                // All Buttons In (British Mode): soglia a -20 dB, ratio iper-aggressivo
                threshold = -20.0f;
                rVal = 24.0f;
                break;
        }

        const float overDb = peakDb - threshold;
        if (overDb <= 0.0f) return 0.0f;

        if (ratio == Ratio::AllButtons) {
            // Curva caratteristica "All Buttons In":
            // Distorsione da collasso del bias FET con compressione estrema e rilascio ritardato
            return (overDb * 1.15f) * (1.0f - 1.0f / rVal);
        }

        return overDb * (1.0f - 1.0f / rVal);
    }

    static float saturateFET(float x, Revision rev, bool allButtons) noexcept {
        if (allButtons) {
            // Saturazione violenta British Mode
            return std::tanh(1.35f * x) * 1.15f;
        }

        if (rev == Revision::BlueStripe) {
            // Blue Stripe (Rev A): maggiore ricchezza di 3a armonica e mordente
            const float k = 1.1f;
            return std::tanh(k * x) * (1.0f + 0.04f * x * x);
        } else {
            // Blackface (Rev D/E): più lineare, clipping caldo Classe A
            return std::tanh(x);
        }
    }

    void updateTimeConstants() noexcept {
        // Attack: 1 (1 ms) a 7 (20 microsecondi = 0.00002 s)
        // Scala esponenziale: t_att = 0.00002 * (50.0 ^ ((7.0 - knob) / 6.0))
        const float expAtt = (7.0f - attackKnob) / 6.0f;
        const float attackSeconds = 0.000020f * std::pow(50.0f, expAtt);
        attackCoeff = 1.0f - std::exp(-dt / attackSeconds);

        // Release: 1 (1000 ms) a 7 (50 ms)
        // Scala esponenziale: t_rel = 0.050 * (20.0 ^ ((7.0 - knob) / 6.0))
        const float expRel = (7.0f - releaseKnob) / 6.0f;
        const float releaseSeconds = 0.050f * std::pow(20.0f, expRel);
        releaseCoeff = 1.0f - std::exp(-dt / releaseSeconds);
    }

    float sr{44100.0f};
    float invSr{1.0f / 44100.0f};
    float dt{1.0f / 44100.0f};

    float inputDb{-30.0f};
    float outputDb{-18.0f};
    float inputGainLin{1.0f};
    float outputGainLin{1.0f};

    float attackKnob{3.0f};  // Default standard 1176
    float releaseKnob{7.0f}; // Default rapido CLA-76
    float attackCoeff{0.1f};
    float releaseCoeff{0.01f};

    Ratio ratio{Ratio::Ratio4};
    Revision revision{Revision::Blackface};
    bool compOff{false};
    AnalogHum analogHum{AnalogHum::Off};
    float mix{1.0f};

    float envelopeL{0.0f};
    float envelopeR{0.0f};
    float currentGRL_dB{0.0f};
    float currentGRR_dB{0.0f};
    float humPhase{0.0f};

    // Sidechain High-Pass Filter Biquad
    bool scHighPass{false};
    float scHpB0{1.0f}, scHpB1{-2.0f}, scHpB2{1.0f};
    float scHpA1{0.0f}, scHpA2{0.0f};
    float scHpStateL1{0.0f}, scHpStateL2{0.0f};
    float scHpStateR1{0.0f}, scHpStateR2{0.0f};
};

} // namespace dsp171
