#pragma once
#include <cmath>
#include <array>
#include <algorithm>
#include "Common.h"

namespace dsp171 {

// Tabella di lookup precalcolata per dB -> linear gain (-60 dB a +24 dB con risoluzione 0.1 dB)
class FastDbToGainTable {
public:
    static constexpr float MinDb = -60.0f;
    static constexpr float MaxDb = 24.0f;
    static constexpr float StepDb = 0.1f;
    static constexpr size_t TableSize = static_cast<size_t>((MaxDb - MinDb) / StepDb) + 1;

    FastDbToGainTable() {
        for (size_t i = 0; i < TableSize; ++i) {
            const float db = MinDb + static_cast<float>(i) * StepDb;
            table[i] = std::pow(10.0f, db / 20.0f);
        }
    }

    inline float lookup(float db) const noexcept {
        if (!std::isfinite(db) || db <= MinDb) return table[0];
        if (db >= MaxDb) return table[TableSize - 1];

        const float indexFloat = (db - MinDb) / StepDb;
        const size_t idx = static_cast<size_t>(indexFloat);
        const float frac = indexFloat - static_cast<float>(idx);

        if (idx + 1 < TableSize) {
            return table[idx] * (1.0f - frac) + table[idx + 1] * frac;
        }
        return table[idx];
    }

private:
    std::array<float, TableSize> table{};
};

inline const FastDbToGainTable& getGlobalDbToGainTable() {
    static const FastDbToGainTable instance;
    return instance;
}

inline float fastDbToLinear(float db) noexcept {
    if (!std::isfinite(db) || db <= -144.0f) return 0.0f;
    if (db >= 48.0f) db = 48.0f;
    return std::exp(db * 0.1151292546497022842f); // ln(10) / 20 = 0.1151292546497022842
}

} // namespace dsp171
