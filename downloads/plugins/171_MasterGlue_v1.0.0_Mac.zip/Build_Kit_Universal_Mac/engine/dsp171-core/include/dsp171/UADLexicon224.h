#pragma once
#include <cmath>
#include <algorithm>
#include <vector>

namespace dsp171 {

/**
 * @brief UADLexicon224
 * Reverse-engineered from Universal Audio / Lexicon 224 Digital Reverb.
 * Faithfully models David Griesinger's iconic 1978 reverberator topology:
 * - Input Pre-Delay (0 to 250 ms).
 * - 4-stage All-Pass Input Diffusion network with coprime delay spacing.
 * - Split-band decay: Independent Bass Decay Multiplier (0.2x - 4.0x) and Mid Decay Time (0.2s - 70s).
 * - 2-pole Crossover filter network (100 Hz - 1500 Hz) steering decay loops.
 * - Treble Decay high-frequency damping filter (1 kHz - 16 kHz).
 * - Griesinger Dual-Loop recirculating figure-eight resonator with cross-coupling matrix.
 * - Mode Enhancement LFO modulation preventing metallic pitch modes.
 * - Converter Emulation: 12-bit floating-point granulation & analog 20 kHz reconstruction.
 * - Programs: Small Hall B, Large Hall B, Acoustic Chamber, Vocal Plate.
 * Zero dynamic allocation during real-time audio processing.
 */
class UADLexicon224 {
public:
    enum class Program {
        SmallHallB,
        LargeHallB,
        AcousticChamber,
        VocalPlate
    };

    UADLexicon224() noexcept 
        : m_sampleRate(44100.0f) {
        prepare(44100.0f);
    }

    void prepare(float sampleRate) {
        m_sampleRate = sampleRate;

        // Pre-delay buffer (up to 300 ms at 192 kHz)
        const size_t maxPreDelaySamples = static_cast<size_t>(0.3f * m_sampleRate) + 64;
        m_preDelayBufferL.assign(maxPreDelaySamples, 0.0f);
        m_preDelayBufferR.assign(maxPreDelaySamples, 0.0f);
        m_preDelayWriteIdx = 0;

        rebuildProgramDelays();

        // Mode enhancement LFO
        m_lfoPhase = 0.0f;

        // Filter states
        m_dampL = 0.0f; m_dampR = 0.0f;
        m_xoverLpL = 0.0f; m_xoverLpR = 0.0f;
        m_lastLoopA = 0.0f;
        m_lastLoopB = 0.0f;

        updateParameters();
    }

    void setParameters(float predelayMs = 24.0f,       // 0 to 250 ms
                       float midDecaySec = 2.5f,       // 0.2 to 70.0 seconds
                       float bassMultiplier = 1.0f,    // 0.2x to 4.0x
                       float crossoverFreq = 500.0f,   // 100 to 1500 Hz
                       float trebleDecayFreq = 8000.0f,// 1000 to 16000 Hz
                       float diffusion = 0.75f,        // 0.0 to 1.0
                       float depth = 0.5f,             // 0.0 to 1.0
                       Program program = Program::SmallHallB,
                       bool vintage12Bit = true,
                       float mix = 0.35f) noexcept {
        m_predelayMs = std::clamp(predelayMs, 0.0f, 250.0f);
        m_midDecaySec = std::clamp(midDecaySec, 0.2f, 70.0f);
        m_bassMultiplier = std::clamp(bassMultiplier, 0.2f, 4.0f);
        m_crossoverFreq = std::clamp(crossoverFreq, 100.0f, 1500.0f);
        m_trebleDecayFreq = std::clamp(trebleDecayFreq, 1000.0f, 16000.0f);
        m_diffusion = std::clamp(diffusion, 0.0f, 1.0f);
        m_depth = std::clamp(depth, 0.0f, 1.0f);

        if (m_program != program) {
            m_program = program;
            rebuildProgramDelays();
        }

        m_vintage12Bit = vintage12Bit;
        m_mix = std::clamp(mix, 0.0f, 1.0f);

        updateParameters();
    }

    void process(float inL, float inR, float& outL, float& outR) noexcept {
        const float dryL = inL;
        const float dryR = inR;

        // Stage 1: Input Pre-delay
        const size_t preDelaySamples = static_cast<size_t>(m_predelayMs * 0.001f * m_sampleRate);
        const size_t bufferSize = m_preDelayBufferL.size();

        m_preDelayBufferL[m_preDelayWriteIdx] = inL;
        m_preDelayBufferR[m_preDelayWriteIdx] = inR;

        const size_t readIdx = (m_preDelayWriteIdx + bufferSize - (preDelaySamples % bufferSize)) % bufferSize;
        float delayedInL = m_preDelayBufferL[readIdx];
        float delayedInR = m_preDelayBufferR[readIdx];

        m_preDelayWriteIdx = (m_preDelayWriteIdx + 1) % bufferSize;

        // Stage 2: Vintage 12-Bit Floating Point Converter Emulation (Lexicon 224 input stage)
        if (m_vintage12Bit) {
            delayedInL = quantize12BitFloat(delayedInL);
            delayedInR = quantize12BitFloat(delayedInR);
        }

        // Stage 3: Input Diffusion Network (4 cascaded allpass diffusers)
        float diffSig = (delayedInL + delayedInR) * 0.5f;
        diffSig = processAllpass(m_diffuser1, diffSig, m_diffCoeff);
        diffSig = processAllpass(m_diffuser2, diffSig, m_diffCoeff);
        diffSig = processAllpass(m_diffuser3, diffSig, m_diffCoeff);
        diffSig = processAllpass(m_diffuser4, diffSig, m_diffCoeff);

        // Stage 4: Mode Enhancement LFO (Slow subtle phase modulation of delay loop)
        m_lfoPhase += m_lfoInc;
        if (m_lfoPhase >= 6.283185307179586f) m_lfoPhase -= 6.283185307179586f;
        const float modOffset = std::sin(m_lfoPhase) * 2.0f; // +/- 2 samples modulation

        // Stage 5: Griesinger Dual Recirculating Delay Loop Tank
        // Loop A
        float tankInA = diffSig + m_lastLoopB * m_feedbackMid;
        float outA1 = readDelayMod(m_loopDelayA1, 0.0f);
        writeDelay(m_loopDelayA1, tankInA);

        float outA2 = readDelayMod(m_loopDelayA2, modOffset);
        writeDelay(m_loopDelayA2, outA1);

        float outA3 = readDelayMod(m_loopDelayA3, 0.0f);
        writeDelay(m_loopDelayA3, outA2);

        float outA4 = readDelayMod(m_loopDelayA4, -modOffset);
        writeDelay(m_loopDelayA4, outA3);

        // Loop B
        float tankInB = diffSig + m_lastLoopA * m_feedbackMid;
        float outB1 = readDelayMod(m_loopDelayB1, 0.0f);
        writeDelay(m_loopDelayB1, tankInB);

        float outB2 = readDelayMod(m_loopDelayB2, -modOffset);
        writeDelay(m_loopDelayB2, outB1);

        float outB3 = readDelayMod(m_loopDelayB3, 0.0f);
        writeDelay(m_loopDelayB3, outB2);

        float outB4 = readDelayMod(m_loopDelayB4, modOffset);
        writeDelay(m_loopDelayB4, outB3);

        // Stage 6: Split-Band Crossover Damping (Bass Multiplier + Mid Decay + Treble HF Roll-off)
        // Loop A damping
        m_xoverLpL += m_xoverAlpha * (outA4 - m_xoverLpL);
        const float bassPartA = m_xoverLpL;
        const float midPartA = outA4 - m_xoverLpL;

        // Apply bass decay scaling vs mid (strictly clamped < 0.985 to prevent loop explosion)
        float dampedA = bassPartA * m_bassDecayScale + midPartA;
        m_dampL += m_dampAlpha * (dampedA - m_dampL);
        m_lastLoopA = std::clamp(m_dampL, -2.0f, 2.0f);

        // Loop B damping
        m_xoverLpR += m_xoverAlpha * (outB4 - m_xoverLpR);
        const float bassPartB = m_xoverLpR;
        const float midPartB = outB4 - m_xoverLpR;

        float dampedB = bassPartB * m_bassDecayScale + midPartB;
        m_dampR += m_dampAlpha * (dampedB - m_dampR);
        m_lastLoopB = std::clamp(m_dampR, -2.0f, 2.0f);

        // Stage 7: Spatial Multi-Tap Output Matrixing (Decorrelated Left & Right)
        const float earlyReflWeight = 1.0f - m_depth * 0.7f;
        const float lateReverbWeight = 0.5f + m_depth * 0.5f;

        float wetL = (outA1 - outA3 + outB2) * earlyReflWeight + (outA4 + outB3) * lateReverbWeight;
        float wetR = (outB1 - outB3 + outA2) * earlyReflWeight + (outB4 + outA3) * lateReverbWeight;

        // Anti-denormal and vintage scaling
        if (std::abs(wetL) < 1e-15f) wetL = 0.0f;
        if (std::abs(wetR) < 1e-15f) wetR = 0.0f;

        // Stage 8: Output Dry/Wet Mix
        outL = dryL + m_mix * (wetL - dryL);
        outR = dryR + m_mix * (wetR - dryR);
    }

    void processBlock(const float* inL, const float* inR, float* outL, float* outR, size_t numSamples) noexcept {
        for (size_t i = 0; i < numSamples; ++i) {
            process(inL[i], inR[i], outL[i], outR[i]);
        }
    }

private:
    struct DelayLine {
        std::vector<float> buffer;
        size_t writeIdx{0};
        size_t delaySamples{0};
    };

    struct AllpassLine {
        std::vector<float> buffer;
        size_t writeIdx{0};
        size_t delaySamples{0};
    };

    void initDelay(DelayLine& dl, size_t len) {
        dl.delaySamples = std::max<size_t>(len, 4);
        dl.buffer.assign(dl.delaySamples + 32, 0.0f);
        dl.writeIdx = 0;
    }

    void initAllpass(AllpassLine& al, size_t len) {
        al.delaySamples = std::max<size_t>(len, 4);
        al.buffer.assign(al.delaySamples + 32, 0.0f);
        al.writeIdx = 0;
    }

    static void writeDelay(DelayLine& dl, float sample) noexcept {
        dl.buffer[dl.writeIdx] = sample;
        dl.writeIdx = (dl.writeIdx + 1) % dl.delaySamples;
    }

    static float readDelayMod(const DelayLine& dl, float modSamples) noexcept {
        // True circular delay of dl.delaySamples with LFO modulation
        // Oldest sample written dl.delaySamples ago is at dl.writeIdx!
        const float bufLen = static_cast<float>(dl.delaySamples);
        float readPos = static_cast<float>(dl.writeIdx) + modSamples;
        while (readPos < 0.0f) readPos += bufLen;
        while (readPos >= bufLen) readPos -= bufLen;

        const size_t idx0 = static_cast<size_t>(readPos) % dl.delaySamples;
        const size_t idx1 = (idx0 + 1) % dl.delaySamples;
        const float frac = readPos - static_cast<float>(idx0);
        return dl.buffer[idx0] + frac * (dl.buffer[idx1] - dl.buffer[idx0]);
    }

    static float processAllpass(AllpassLine& al, float input, float coeff) noexcept {
        const float delayed = al.buffer[al.writeIdx];
        const float v = input - coeff * delayed;
        const float output = delayed + coeff * v;
        al.buffer[al.writeIdx] = v;
        al.writeIdx = (al.writeIdx + 1) % al.delaySamples;
        return output;
    }

    void rebuildProgramDelays() {
        // Scale coprime delay lengths according to sample rate and Griesinger program selection
        const float rateScale = m_sampleRate / 34125.0f;

        float dScale = 1.0f;
        switch (m_program) {
            case Program::SmallHallB:      dScale = 1.0f;  break;
            case Program::LargeHallB:      dScale = 1.38f; break;
            case Program::AcousticChamber:  dScale = 0.68f; break;
            case Program::VocalPlate:       dScale = 0.52f; break;
        }

        initAllpass(m_diffuser1, static_cast<size_t>(142 * rateScale * dScale));
        initAllpass(m_diffuser2, static_cast<size_t>(107 * rateScale * dScale));
        initAllpass(m_diffuser3, static_cast<size_t>(379 * rateScale * dScale));
        initAllpass(m_diffuser4, static_cast<size_t>(277 * rateScale * dScale));

        initDelay(m_loopDelayA1, static_cast<size_t>(672 * rateScale * dScale));
        initDelay(m_loopDelayA2, static_cast<size_t>(1800 * rateScale * dScale));
        initDelay(m_loopDelayA3, static_cast<size_t>(3540 * rateScale * dScale));
        initDelay(m_loopDelayA4, static_cast<size_t>(4453 * rateScale * dScale));

        initDelay(m_loopDelayB1, static_cast<size_t>(905 * rateScale * dScale));
        initDelay(m_loopDelayB2, static_cast<size_t>(2111 * rateScale * dScale));
        initDelay(m_loopDelayB3, static_cast<size_t>(3119 * rateScale * dScale));
        initDelay(m_loopDelayB4, static_cast<size_t>(4107 * rateScale * dScale));
    }

    [[nodiscard]] static float quantize12BitFloat(float x) noexcept {
        // Models the 12-bit floating point mantissa resolution of the original Lexicon 224 DAC
        if (std::abs(x) < 1e-7f) return 0.0f;
        int exp;
        const float mantissa = std::frexp(x, &exp);
        // Quantize 12-bit mantissa (sign + 11 bits = 2048 steps)
        const float qMantissa = std::round(mantissa * 2048.0f) / 2048.0f;
        return std::ldexp(qMantissa, exp);
    }

    void updateParameters() noexcept {
        // Reverb decay feedback calculation: RT60 equation for recirculating loop
        // Loop time around tank is approx 150 ms (0.150s)
        constexpr float loopTimeSec = 0.150f;
        m_feedbackMid = std::clamp(std::pow(10.0f, -3.0f * loopTimeSec / m_midDecaySec), 0.1f, 0.985f);

        // Bass multiplier scale: strictly guard loop gain < 0.985f to prevent infinite feedback
        float maxBassScale = 0.985f / std::max(m_feedbackMid, 0.01f);
        m_bassDecayScale = std::clamp(m_bassMultiplier, 0.2f, std::min(maxBassScale, 2.0f));

        // Treble damping 1-pole filter alpha
        const float wTreble = 2.0f * 3.141592653589793f * m_trebleDecayFreq / m_sampleRate;
        m_dampAlpha = wTreble / (1.0f + wTreble);

        // Crossover 1-pole filter alpha
        const float wXover = 2.0f * 3.141592653589793f * m_crossoverFreq / m_sampleRate;
        m_xoverAlpha = wXover / (1.0f + wXover);

        // Diffusion coefficient
        m_diffCoeff = (m_program == Program::VocalPlate) ? (0.75f + 0.20f * m_diffusion) : (0.5f + 0.25f * m_diffusion);

        // Mode enhancement LFO frequency (~0.8 Hz)
        m_lfoInc = 2.0f * 3.141592653589793f * 0.8f / m_sampleRate;
    }

    float m_sampleRate;
    float m_predelayMs{24.0f};
    float m_midDecaySec{2.5f};
    float m_bassMultiplier{1.0f};
    float m_crossoverFreq{500.0f};
    float m_trebleDecayFreq{8000.0f};
    float m_diffusion{0.75f};
    float m_depth{0.5f};
    Program m_program{Program::SmallHallB};
    bool m_vintage12Bit{true};
    float m_mix{0.35f};

    // Coefficients
    float m_feedbackMid{0.7f};
    float m_bassDecayScale{1.0f};
    float m_dampAlpha{0.5f};
    float m_xoverAlpha{0.1f};
    float m_diffCoeff{0.7f};
    float m_lfoInc{0.0f};

    // Pre-delay buffer
    std::vector<float> m_preDelayBufferL;
    std::vector<float> m_preDelayBufferR;
    size_t m_preDelayWriteIdx{0};

    // Diffuser lines
    AllpassLine m_diffuser1;
    AllpassLine m_diffuser2;
    AllpassLine m_diffuser3;
    AllpassLine m_diffuser4;

    // Tank delay lines
    DelayLine m_loopDelayA1;
    DelayLine m_loopDelayA2;
    DelayLine m_loopDelayA3;
    DelayLine m_loopDelayA4;

    DelayLine m_loopDelayB1;
    DelayLine m_loopDelayB2;
    DelayLine m_loopDelayB3;
    DelayLine m_loopDelayB4;

    // States
    float m_lastLoopA{0.0f};
    float m_lastLoopB{0.0f};
    float m_dampL{0.0f};
    float m_dampR{0.0f};
    float m_xoverLpL{0.0f};
    float m_xoverLpR{0.0f};
    float m_lfoPhase{0.0f};
};

} // namespace dsp171
