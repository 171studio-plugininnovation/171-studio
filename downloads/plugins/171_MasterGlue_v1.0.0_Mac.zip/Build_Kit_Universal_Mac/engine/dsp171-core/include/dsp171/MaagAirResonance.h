#pragma once

#include <cmath>
#include <algorithm>
#include <cstdint>
#include "Common.h"
#include "FastMath.h"
#include "ZDFSVF.h"

namespace dsp171 {

// =============================================================================
// MAAG AIR BAND & DYNAMIC VOCAL RESONANCE TAMER (De-Harsh)
//
// Designed under guidance of Agente 23 (maag-air-resonance-specialist).
//
// Combines:
// 1. Clifford Maag EQ4 legendary "Air Band" peaking shelf network (2.5k, 5k, 10k, 20k, 40kHz).
//    Features Nyquist-compensated frequency response avoiding high-end cramping.
// 2. Adaptive Dynamic Resonance Tamer (2.8 kHz - 4.2 kHz) for instant soothing
//    of ear-piercing sibilance overtones, harsh mic capsules, and nasal resonances.
//
// Hard real-time C++20, 0 samples latency, zero dynamic heap allocations.
// =============================================================================

class MaagAirResonance {
public:
    enum class AirFreq : uint8_t {
        Freq_2k5 = 0,
        Freq_5k,
        Freq_10k,
        Freq_20k,
        Freq_40k
    };

    MaagAirResonance() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        fs = (sampleRate > 1000.0) ? sampleRate : 48000.0;
        invFs = 1.0 / fs;
        reset();
        updateAirFilterCoeffs();
        updateTamerCoeffs();
    }

    void reset() noexcept {
        airS1_L = 0.0; airS2_L = 0.0;
        airS1_R = 0.0; airS2_R = 0.0;

        tamerSVF_L.reset();
        tamerSVF_R.reset();

        detectorEnvL = 0.0f;
        detectorEnvR = 0.0f;
        dynamicGainL = 1.0f;
        dynamicGainR = 1.0f;
        currentDeHarshGRL = 0.0f;
        currentDeHarshGRR = 0.0f;
    }

    // --- Parameter Setters ---

    // Air Band Gain (0.0 dB to +12.0 dB)
    void setAirGain(float gainDb) noexcept {
        airGainDb = std::clamp(gainDb, 0.0f, 12.0f);
        updateAirFilterCoeffs();
    }

    // Air Band Target Frequency
    void setAirFrequency(AirFreq freq) noexcept {
        airFreqSelection = freq;
        updateAirFilterCoeffs();
    }

    // Dynamic De-Harsh Sensitivity/Threshold (-50.0 dB to 0.0 dB)
    void setDeHarshThreshold(float threshDb) noexcept {
        deHarshThreshDb = std::clamp(threshDb, -50.0f, 0.0f);
        threshLinear = std::pow(10.0f, deHarshThreshDb * 0.05f);
    }

    // Dynamic De-Harsh Max Depth (0.0 dB to 14.0 dB)
    void setDeHarshDepth(float depthDb) noexcept {
        deHarshDepthDb = std::clamp(depthDb, 0.0f, 14.0f);
    }

    // De-Harsh Center Frequency (2000 Hz to 6000 Hz)
    void setDeHarshCenterFreq(float centerHz) noexcept {
        tamerFreq = std::clamp(centerHz, 2000.0f, 6000.0f);
        updateTamerCoeffs();
    }

    void setAirEnabled(bool enable) noexcept { airEnabled = enable; }
    void setDeHarshEnabled(bool enable) noexcept { deHarshEnabled = enable; }

    // Telemetry
    [[nodiscard]] float getDeHarshGainReduction() const noexcept {
        return std::max(currentDeHarshGRL, currentDeHarshGRR);
    }

    // --- Processing Block ---
    void process(float* const* channelData, int numChannels, int numSamples) noexcept {
        if (numChannels <= 0 || numSamples <= 0) return;

        float* left = channelData[0];
        float* right = (numChannels > 1) ? channelData[1] : nullptr;

        for (int i = 0; i < numSamples; ++i) {
            float inL = left[i];
            float inR = right ? right[i] : inL;

            // 1. Dynamic De-Harsh Tamer Stage
            if (deHarshEnabled && deHarshDepthDb > 0.05f) {
                auto outL_svf = tamerSVF_L.process(inL);
                float scL = 2.0f * static_cast<float>(tamerSVF_L.R) * outL_svf.bp;

                float scR = scL;
                if (right) {
                    auto outR_svf = tamerSVF_R.process(inR);
                    scR = 2.0f * static_cast<float>(tamerSVF_R.R) * outR_svf.bp;
                }

                // Envelope follower
                float absL = std::abs(scL);
                float absR = std::abs(scR);

                const float alphaAtk = 0.25f;
                const float alphaRel = 0.005f;
                detectorEnvL += ((absL > detectorEnvL) ? alphaAtk : alphaRel) * (absL - detectorEnvL);
                detectorEnvR += ((absR > detectorEnvR) ? alphaAtk : alphaRel) * (absR - detectorEnvR);
                if (detectorEnvL < 1.0e-25f) detectorEnvL = 0.0f;
                if (detectorEnvR < 1.0e-25f) detectorEnvR = 0.0f;

                float targetGainDbL = 0.0f;
                float targetGainDbR = 0.0f;

                if (detectorEnvL > threshLinear) {
                    float overDb = 20.0f * std::log10(detectorEnvL / threshLinear);
                    targetGainDbL = -std::min(deHarshDepthDb, overDb * 0.85f);
                }
                if (detectorEnvR > threshLinear) {
                    float overDb = 20.0f * std::log10(detectorEnvR / threshLinear);
                    targetGainDbR = -std::min(deHarshDepthDb, overDb * 0.85f);
                }

                currentDeHarshGRL = -targetGainDbL;
                currentDeHarshGRR = -targetGainDbR;

                float gLinL = std::pow(10.0f, targetGainDbL * 0.05f);
                float gLinR = std::pow(10.0f, targetGainDbR * 0.05f);

                dynamicGainL += 0.20f * (gLinL - dynamicGainL);
                dynamicGainR += 0.20f * (gLinR - dynamicGainR);

                inL = inL - (1.0f - dynamicGainL) * scL;
                if (right) {
                    inR = inR - (1.0f - dynamicGainR) * scR;
                }
            } else {
                currentDeHarshGRL = 0.0f;
                currentDeHarshGRR = 0.0f;
            }

            // 2. Maag EQ4 Air Band Stage (High Peaking Shelf)
            if (airEnabled && airGainDb > 0.05f) {
                inL = processAirBandL(inL);
                if (right) {
                    inR = processAirBandR(inR);
                }
            }

            left[i] = inL;
            if (right) right[i] = inR;
        }
    }

private:
    double fs = 48000.0;
    double invFs = 1.0 / 48000.0;

    bool airEnabled = true;
    bool deHarshEnabled = true;

    AirFreq airFreqSelection = AirFreq::Freq_20k;
    float airGainDb = 3.5f;

    float deHarshThreshDb = -24.0f;
    float deHarshDepthDb = 4.5f;
    float threshLinear = 0.063095f;
    float tamerFreq = 3400.0f;

    // Air Band ZDF Filter Coeffs & States
    double airG = 0.5;
    double airK = 1.414;
    double airA = 1.0;
    double airS1_L = 0.0, airS2_L = 0.0;
    double airS1_R = 0.0, airS2_R = 0.0;

    // ZDF SVF 64 for Dynamic Notch Resonance Tamer
    ZDFSVF64 tamerSVF_L;
    ZDFSVF64 tamerSVF_R;

    float detectorEnvL = 0.0f;
    float detectorEnvR = 0.0f;
    float dynamicGainL = 1.0f;
    float dynamicGainR = 1.0f;
    float currentDeHarshGRL = 0.0f;
    float currentDeHarshGRR = 0.0f;

    void updateAirFilterCoeffs() noexcept {
        double fc = 20000.0;
        switch (airFreqSelection) {
            case AirFreq::Freq_2k5: fc = 2500.0;  break;
            case AirFreq::Freq_5k:  fc = 5000.0;  break;
            case AirFreq::Freq_10k: fc = 10000.0; break;
            case AirFreq::Freq_20k: fc = 20000.0; break;
            case AirFreq::Freq_40k: fc = 38000.0; break;
        }

        const double nyquist = 0.5 * fs;
        double mappedFc = std::min(fc, nyquist * 0.94);

        const double Q = 0.38;
        airA = std::pow(10.0, airGainDb * 0.025);
        double w0 = 2.0 * 3.14159265358979323846 * mappedFc;
        airG = std::tan(w0 * 0.5 * invFs) / std::sqrt(airA);
        airK = 1.0 / Q;
    }

    void updateTamerCoeffs() noexcept {
        const float Q = 3.2f;
        tamerSVF_L.setParameters(tamerFreq, Q, static_cast<float>(fs));
        tamerSVF_R.setParameters(tamerFreq, Q, static_cast<float>(fs));
    }

    float processAirBandL(float in) noexcept {
        double v0 = static_cast<double>(in);
        double d = 1.0 / (1.0 + airG * (airG + airK));
        double hp = (v0 - (airG + airK) * airS1_L - airS2_L) * d;
        double bp = airG * hp + airS1_L;
        double lp = airG * bp + airS2_L;
        airS1_L = airG * hp + bp;
        airS2_L = airG * bp + lp;
        if (std::abs(airS1_L) < 1.0e-25) airS1_L = 0.0;
        if (std::abs(airS2_L) < 1.0e-25) airS2_L = 0.0;

        double out = v0 + (airA * airA - 1.0) * (hp + (airK / airA) * bp);
        return static_cast<float>(out);
    }

    float processAirBandR(float in) noexcept {
        double v0 = static_cast<double>(in);
        double d = 1.0 / (1.0 + airG * (airG + airK));
        double hp = (v0 - (airG + airK) * airS1_R - airS2_R) * d;
        double bp = airG * hp + airS1_R;
        double lp = airG * bp + airS2_R;
        airS1_R = airG * hp + bp;
        airS2_R = airG * bp + lp;
        if (std::abs(airS1_R) < 1.0e-25) airS1_R = 0.0;
        if (std::abs(airS2_R) < 1.0e-25) airS2_R = 0.0;

        double out = v0 + (airA * airA - 1.0) * (hp + (airK / airA) * bp);
        return static_cast<float>(out);
    }
};

} // namespace dsp171
