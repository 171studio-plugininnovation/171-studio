#pragma once

#include <cmath>
#include <algorithm>
#include "Common.h"
#include "FastMath.h"
#include "ZDFSVF.h"

namespace dsp171 {

// =============================================================================
// SSLGChannelEQ (SSL 4000 G-Series Black Knob 242 EQ)
// Inspired by: Solid State Logic SL 4000 G Console Channel Strip EQ
// Crafted for: 171EasyVoice Vocal Channel Strip
//
// Features:
// 1. 4-Band Parametric Console EQ:
//    - LF Band: 30 Hz - 450 Hz, +/-15 dB, switchable Bell vs Shelf (with authentic
//      SSL G-Series resonant undershoot/overshoot for tight low-end focus).
//    - LMF Band: 200 Hz - 2500 Hz, +/-15 dB, Q variable from 0.5 to 2.5
//      with proportional-Q auto-sharpening response.
//    - HMF Band: 600 Hz - 7000 Hz, +/-15 dB, Q variable from 0.5 to 2.5
//      with proportional-Q response.
//    - HF Band: 1.5 kHz - 16 kHz, +/-15 dB, switchable Bell vs Shelf (sweet air sheen).
// 2. High-Pass Filter (HPF):
//    - 18 dB/oct (3rd order Butterworth ZDF cascade), 16 Hz to 350 Hz with bypass out.
// 3. Low-Pass Filter (LPF):
//    - 12 dB/oct (2nd order Butterworth ZDF), 3 kHz to 22 kHz with bypass out.
// 4. Zero-Delay Feedback (ZDF) 64-bit trapezoidal integrators (zero high-frequency cramping).
// 5. Hard real-time safe (zero allocations, C++20, noexcept).
// =============================================================================

class SSLGChannelEQ {
public:
    enum class BandType : uint8_t {
        Shelf = 0,
        Bell  = 1
    };

    struct BandConfig {
        float freqHz = 1000.0f;
        float gainDb = 0.0f;
        float q = 0.707f;
        BandType type = BandType::Bell;
    };

    SSLGChannelEQ() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        invSr = 1.0f / sr;

        updateCoefficients();
        reset();
    }

    void reset() noexcept {
        hpfSVF_L.reset();
        hpfSVF_R.reset();
        hpfOnePole_L.reset();
        hpfOnePole_R.reset();

        lpfSVF_L.reset();
        lpfSVF_R.reset();

        for (int i = 0; i < 4; ++i) {
            bandSVF_L[i].reset();
            bandSVF_R[i].reset();
            undershootSVF_L[i].reset();
            undershootSVF_R[i].reset();
        }
    }

    // --- Controls ---

    // High-Pass Filter: 16 Hz to 350 Hz (<= 16.5 Hz = Bypassed)
    void setHPFFreq(float freqHz) noexcept {
        hpfHz = std::clamp(freqHz, 16.0f, 350.0f);
        hpfEnabled = (hpfHz > 16.5f);
        updateHPF();
    }

    // Low-Pass Filter: 3000 Hz to 22000 Hz (>= 21500 Hz = Bypassed)
    void setLPFFreq(float freqHz) noexcept {
        lpfHz = std::clamp(freqHz, 3000.0f, 22000.0f);
        lpfEnabled = (lpfHz < 21500.0f);
        updateLPF();
    }

    // LF Band (Band 0): 30 - 450 Hz, +/-15 dB
    void setLF(float freqHz, float gainDb, BandType type = BandType::Shelf) noexcept {
        bands[0].freqHz = std::clamp(freqHz, 30.0f, 450.0f);
        bands[0].gainDb = std::clamp(gainDb, -15.0f, 15.0f);
        bands[0].type = type;
        bands[0].q = 0.707f;
        updateBand(0);
    }

    // LMF Band (Band 1): 200 - 2500 Hz, +/-15 dB, Q [0.5 .. 2.5]
    void setLMF(float freqHz, float gainDb, float q = 0.707f) noexcept {
        bands[1].freqHz = std::clamp(freqHz, 200.0f, 2500.0f);
        bands[1].gainDb = std::clamp(gainDb, -15.0f, 15.0f);
        bands[1].q = std::clamp(q, 0.5f, 2.5f);
        bands[1].type = BandType::Bell;
        updateBand(1);
    }

    // HMF Band (Band 2): 600 - 7000 Hz, +/-15 dB, Q [0.5 .. 2.5]
    void setHMF(float freqHz, float gainDb, float q = 0.707f) noexcept {
        bands[2].freqHz = std::clamp(freqHz, 600.0f, 7000.0f);
        bands[2].gainDb = std::clamp(gainDb, -15.0f, 15.0f);
        bands[2].q = std::clamp(q, 0.5f, 2.5f);
        bands[2].type = BandType::Bell;
        updateBand(2);
    }

    // HF Band (Band 3): 1500 - 16000 Hz, +/-15 dB
    void setHF(float freqHz, float gainDb, BandType type = BandType::Shelf) noexcept {
        bands[3].freqHz = std::clamp(freqHz, 1500.0f, 16000.0f);
        bands[3].gainDb = std::clamp(gainDb, -15.0f, 15.0f);
        bands[3].type = type;
        bands[3].q = 0.707f;
        updateBand(3);
    }

    // --- Audio Processing ---

    inline void processSample(float inL, float inR, float& outL, float& outR) noexcept {
        if (!std::isfinite(inL)) inL = 0.0f;
        if (!std::isfinite(inR)) inR = 0.0f;

        float sL = inL;
        float sR = inR;

        // 1. High-Pass Filter (18 dB/oct = 2nd order SVF HP + 1st order OnePole HP)
        if (hpfEnabled) {
            sL = hpfSVF_L.process(sL).hp;
            sR = hpfSVF_R.process(sR).hp;
            sL = hpfOnePole_L.process(sL);
            sR = hpfOnePole_R.process(sR);
        }

        // 2. Low-Pass Filter (12 dB/oct = 2nd order SVF LP)
        if (lpfEnabled) {
            sL = lpfSVF_L.process(sL).lp;
            sR = lpfSVF_R.process(sR).lp;
        }

        // 3. Parametric 4-Band SSL G-Series Cascade
        for (int b = 0; b < 4; ++b) {
            if (std::abs(bands[b].gainDb) < 0.05f) continue; // Bit-exact bypass for zero gain

            const float linBoost = bandLinGain[b] - 1.0f;

            if (bands[b].type == BandType::Bell) {
                // Bell mode: proportional bell peak
                const float bpL = bandSVF_L[b].process(sL).bp;
                const float bpR = bandSVF_R[b].process(sR).bp;
                sL += bpL * linBoost;
                sR += bpR * linBoost;
            } else {
                // Shelf mode (LF or HF) with authentic SSL G-Series resonant dip/rise
                if (b == 0) {
                    // Low Shelf with undershoot:
                    const float lpL = bandSVF_L[0].process(sL).lp;
                    const float lpR = bandSVF_R[0].process(sR).lp;
                    sL += lpL * linBoost;
                    sR += lpR * linBoost;

                    // SSL 242 undershoot: opposite dip of 12% around 1.4 * fc
                    const float underBoost = -linBoost * 0.12f;
                    const float underBpL = undershootSVF_L[0].process(sL).bp;
                    const float underBpR = undershootSVF_R[0].process(sR).bp;
                    sL += underBpL * underBoost;
                    sR += underBpR * underBoost;
                } else {
                    // High Shelf:
                    const float hpL = bandSVF_3_L.process(sL).hp;
                    const float hpR = bandSVF_3_R.process(sR).hp;
                    sL += hpL * linBoost;
                    sR += hpR * linBoost;
                }
            }
        }

        outL = sL;
        outR = sR;
    }

    void processBlock(float* inOutL, float* inOutR, size_t numSamples) noexcept {
        if (!inOutL || !inOutR || numSamples == 0) return;
        for (size_t i = 0; i < numSamples; ++i) {
            processSample(inOutL[i], inOutR[i], inOutL[i], inOutR[i]);
        }
    }

private:
    void updateHPF() noexcept {
        if (hpfEnabled) {
            hpfSVF_L.setParameters(hpfHz, 0.707f, sr);
            hpfSVF_R.setParameters(hpfHz, 0.707f, sr);
            hpfOnePole_L.setCutoff(hpfHz, sr);
            hpfOnePole_R.setCutoff(hpfHz, sr);
        }
    }

    void updateLPF() noexcept {
        if (lpfEnabled) {
            lpfSVF_L.setParameters(lpfHz, 0.707f, sr);
            lpfSVF_R.setParameters(lpfHz, 0.707f, sr);
        }
    }

    void updateBand(int b) noexcept {
        if (b < 0 || b >= 4) return;

        // Linear gain factor
        bandLinGain[b] = std::pow(10.0f, bands[b].gainDb * 0.05f);

        // Proportional Q modeling: bandwidth tightens slightly at high boost/cut
        float effectiveQ = bands[b].q;
        if (bands[b].type == BandType::Bell && (b == 1 || b == 2)) {
            const float boostNorm = std::abs(bands[b].gainDb) / 15.0f;
            effectiveQ = bands[b].q * (1.0f + 0.35f * boostNorm); // Up to +35% sharper at +/-15 dB
        }

        if (b == 0) {
            // LF band
            bandSVF_L[0].setParameters(bands[0].freqHz, 0.707f, sr);
            bandSVF_R[0].setParameters(bands[0].freqHz, 0.707f, sr);
            // Resonant undershoot centered at 1.4 * fc
            undershootSVF_L[0].setParameters(bands[0].freqHz * 1.4f, 1.2f, sr);
            undershootSVF_R[0].setParameters(bands[0].freqHz * 1.4f, 1.2f, sr);
        } else if (b == 3) {
            // HF band
            bandSVF_L[3].setParameters(bands[3].freqHz, 0.707f, sr);
            bandSVF_R[3].setParameters(bands[3].freqHz, 0.707f, sr);
            bandSVF_3_L.setParameters(bands[3].freqHz, 0.707f, sr);
            bandSVF_3_R.setParameters(bands[3].freqHz, 0.707f, sr);
        } else {
            // LMF (1) and HMF (2) Bell bands
            bandSVF_L[b].setParameters(bands[b].freqHz, effectiveQ, sr);
            bandSVF_R[b].setParameters(bands[b].freqHz, effectiveQ, sr);
        }
    }

    void updateCoefficients() noexcept {
        updateHPF();
        updateLPF();
        for (int b = 0; b < 4; ++b) {
            updateBand(b);
        }
    }

    float sr = 48000.0f;
    float invSr = 1.0f / 48000.0f;

    float hpfHz = 16.0f;
    bool hpfEnabled = false;

    float lpfHz = 22000.0f;
    bool lpfEnabled = false;

    BandConfig bands[4]{
        { 80.0f, 0.0f, 0.707f, BandType::Shelf },   // LF
        { 450.0f, 0.0f, 1.0f, BandType::Bell },    // LMF
        { 2400.0f, 0.0f, 1.0f, BandType::Bell },   // HMF
        { 8000.0f, 0.0f, 0.707f, BandType::Shelf }  // HF
    };

    float bandLinGain[4]{ 1.0f, 1.0f, 1.0f, 1.0f };

    // High-Pass Filter (3rd Order 18 dB/oct)
    ZDFSVF64 hpfSVF_L;
    ZDFSVF64 hpfSVF_R;
    ZDFOnePoleHP64 hpfOnePole_L;
    ZDFOnePoleHP64 hpfOnePole_R;

    // Low-Pass Filter (2nd Order 12 dB/oct)
    ZDFSVF64 lpfSVF_L;
    ZDFSVF64 lpfSVF_R;

    // 4 Parametric Bands
    ZDFSVF64 bandSVF_L[4];
    ZDFSVF64 bandSVF_R[4];
    ZDFSVF64 undershootSVF_L[4];
    ZDFSVF64 undershootSVF_R[4];
    ZDFSVF64 bandSVF_3_L;
    ZDFSVF64 bandSVF_3_R;
};

} // namespace dsp171
