#pragma once
#include <cmath>
#include <array>
#include <algorithm>
#include <cstdint>
#include <string_view>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// Tipo di Scala Musicale
// =============================================================================
enum class ScaleType : uint8_t {
    Chromatic = 0,
    Major = 1,              // Scala Maggiore (Ionian)
    NaturalMinor = 2,       // Minore Naturale (Aeolian)
    HarmonicMinor = 3,      // Minore Armonica
    MajorPentatonic = 4,    // Pentatonica Maggiore
    MinorPentatonic = 5,    // Pentatonica Minore
    Dorian = 6,             // Modo Dorico
    Custom = 7,             // Maschera semitonale personalizzata
    MelodicMinor = 8,       // Minore Melodica (ascendente)
    Phrygian = 9,           // Modo Frigio
    Lydian = 10,            // Modo Lidio
    Mixolydian = 11,        // Modo Misolidio
    Locrian = 12,           // Modo Locrio
    Blues = 13              // Scala Blues
};

// =============================================================================
// Risultato della quantizzazione musicale
// =============================================================================
struct QuantizeResult {
    float originalFreqHz = 0.0f;
    float targetFreqHz = 0.0f;
    float originalMidiNote = 0.0f;
    int targetMidiNote = 0;
    float centsOffset = 0.0f;
    float pitchRatio = 1.0f;        // targetFreqHz / originalFreqHz
    uint8_t notePitchClass = 0;     // 0=C, 1=C#, ..., 11=B
    int octave = 0;
    bool isValid = false;
};

// =============================================================================
// MusicalQuantizer
// Quantizzatore musicale real-time per pitch vocale
// Caratteristiche:
// 1. Zero allocazioni di memoria.
// 2. Maschere di bit O(1) per tutti i 12 gradi cromatici.
// 3. Sintonizzazione di riferimento A4 configurabile (es. 432 Hz, 440 Hz, 442 Hz).
// 4. Algoritmo di Nearest Scale Note con risoluzione esatta della distanza in cents.
// =============================================================================
class MusicalQuantizer {
public:
    // Maschere standard a 12 bit (bit 0 = tonica, bit 1 = semitono sopra, ecc.)
    static constexpr uint16_t MASK_CHROMATIC        = 0x0FFF; // 1111 1111 1111 (tutti i 12 semitoni)
    static constexpr uint16_t MASK_MAJOR            = 0x0AB5; // 1010 1011 0101 (0, 2, 4, 5, 7, 9, 11)
    static constexpr uint16_t MASK_NATURAL_MINOR    = 0x05AD; // 0101 1010 1101 (0, 2, 3, 5, 7, 8, 10)
    static constexpr uint16_t MASK_HARMONIC_MINOR   = 0x09AD; // 1001 1010 1101 (0, 2, 3, 5, 7, 8, 11)
    static constexpr uint16_t MASK_MELODIC_MINOR    = 0x0AAD; // 1010 1010 1101 (0, 2, 3, 5, 7, 9, 11)
    static constexpr uint16_t MASK_DORIAN           = 0x06AD; // 0110 1010 1101 (0, 2, 3, 5, 7, 9, 10)
    static constexpr uint16_t MASK_PHRYGIAN         = 0x05AB; // 0101 1010 1011 (0, 1, 3, 5, 7, 8, 10)
    static constexpr uint16_t MASK_LYDIAN           = 0x0AD5; // 1010 1101 0101 (0, 2, 4, 6, 7, 9, 11)
    static constexpr uint16_t MASK_MIXOLYDIAN       = 0x06B5; // 0110 1011 0101 (0, 2, 4, 5, 7, 9, 10)
    static constexpr uint16_t MASK_LOCRIAN          = 0x056B; // 0101 0110 1011 (0, 1, 3, 5, 6, 8, 10)
    static constexpr uint16_t MASK_MAJOR_PENTATONIC = 0x0295; // 0010 1001 0101 (0, 2, 4, 7, 9)
    static constexpr uint16_t MASK_MINOR_PENTATONIC = 0x04A9; // 0100 1010 1001 (0, 3, 5, 7, 10)
    static constexpr uint16_t MASK_BLUES            = 0x04E9; // 0100 1110 1001 (0, 3, 5, 6, 7, 10)

    MusicalQuantizer() noexcept {
        updateEffectiveMask();
    }

    void setScale(ScaleType scale) noexcept {
        currentScale = scale;
        updateEffectiveMask();
    }

    // Imposta la tonica della scala (0 = C, 1 = C#, 2 = D, ..., 11 = B)
    void setRootKey(int rootKey) noexcept {
        rootNote = std::clamp(rootKey, 0, 11);
        updateEffectiveMask();
    }

    // Frequenza di riferimento A4 in Hz (default: 440.0f)
    void setA4Reference(float a4Hz) noexcept {
        a4Frequency = std::clamp(a4Hz, 415.0f, 466.0f);
        invA4 = 1.0f / a4Frequency;
    }

    // Maschera semitonale per note in Bypass (pitch immutato a ratio 1.0)
    void setBypassMask(uint16_t mask) noexcept {
        bypassMask = mask & 0x0FFF;
    }

    // Maschera semitonale per note Bloccate/Proibite (escluse dallo snap)
    void setBlockedMask(uint16_t mask) noexcept {
        blockedMask = mask & 0x0FFF;
    }

    // Modalità Live MIDI Target Note (da master keyboard o traccia MIDI)
    void setTargetMidiNote(int midiNote, bool active) noexcept {
        midiTargetNote = midiNote;
        midiTargetActive = active;
        if (!active) {
            lastMidiCandidate = -1;
        }
    }

    // Maschera custom a 12 bit (quando ScaleType == Custom)
    void setCustomMask(uint16_t mask) noexcept {
        customMask = mask & 0x0FFF;
        if (currentScale == ScaleType::Custom) {
            updateEffectiveMask();
        }
    }

    // Quantizza la frequenza in ingresso alla nota più vicina nella scala attiva
    [[nodiscard]] QuantizeResult quantize(float freqHz) const noexcept {
        if (!std::isfinite(freqHz) || freqHz < 20.0f || freqHz > 5000.0f) {
            return QuantizeResult{ 440.0f, 440.0f, 69.0f, 69, 0.0f, 1.0f, 9, 4, false };
        }

        // Calcolo della nota MIDI continua m = 69 + 12 * log2(f / A4)
        const float midiContinuous = 69.0f + 12.0f * (std::log(freqHz * invA4) * 1.4426950408889634f); // 1/ln(2)
        const int nominalMidi = static_cast<int>(std::round(midiContinuous));
        const int nominalPitchClass = ((nominalMidi % 12) + 12) % 12;

        // 1. Controllo Stato BYPASS: se il semitono assoluto è in bypass e non c'è MIDI override, lascia inalterata la voce
        if (!midiTargetActive && (bypassMask & (1 << nominalPitchClass)) != 0) {
            return QuantizeResult{
                freqHz,
                freqHz,
                midiContinuous,
                nominalMidi,
                0.0f,
                1.0f,
                static_cast<uint8_t>(nominalPitchClass),
                (nominalMidi / 12) - 1,
                true
            };
        }

        int bestMidi = -1;
        float minDistance = 1e9f;

        // 2. Controllo Stato LIVE MIDI TARGET: snap verso la nota MIDI suonata (all'ottava più vicina con isteresi)
        if (midiTargetActive && midiTargetNote >= 0) {
            const int targetClass = ((midiTargetNote % 12) + 12) % 12;
            int candidateMidi = (nominalMidi / 12) * 12 + targetClass;
            const float hyst = (lastMidiCandidate >= 0 && ((lastMidiCandidate % 12) + 12) % 12 == targetClass) ? 6.5f : 6.0f;
            while (static_cast<float>(candidateMidi) - midiContinuous > hyst) candidateMidi -= 12;
            while (midiContinuous - static_cast<float>(candidateMidi) > hyst) candidateMidi += 12;
            lastMidiCandidate = candidateMidi;
            bestMidi = candidateMidi;
        } else {
            lastMidiCandidate = -1;
            // 3. Scansione locale in un intorno di +/- 6 semitoni escludendo le note bloccate (usando pitchClass assoluto 0..11)
            for (int offset = -6; offset <= 6; ++offset) {
                const int testMidi = nominalMidi + offset;
                const int pitchClass = ((testMidi % 12) + 12) % 12;

                // Salta note bloccate (maschera assoluta 12-note)
                if ((blockedMask & (1 << pitchClass)) != 0) {
                    continue;
                }

                if (isPitchClassActive(pitchClass)) {
                    const float dist = std::abs(static_cast<float>(testMidi) - midiContinuous);
                    if (dist < minDistance) {
                        minDistance = dist;
                        bestMidi = testMidi;
                    }
                }
            }

            // Fallback: se nessuna nota nei +/- 6 semitoni è valida, estendi la ricerca a +/- 12 semitoni
            if (bestMidi < 0) {
                for (int offset = -12; offset <= 12; ++offset) {
                    const int testMidi = nominalMidi + offset;
                    const int pitchClass = ((testMidi % 12) + 12) % 12;
                    if ((blockedMask & (1 << pitchClass)) != 0) continue;
                    if (isPitchClassActive(pitchClass)) {
                        const float dist = std::abs(static_cast<float>(testMidi) - midiContinuous);
                        if (dist < minDistance) {
                            minDistance = dist;
                            bestMidi = testMidi;
                        }
                    }
                }
            }

            // Se tutte le note della scala sono bloccate, bypassa senza correzione
            if (bestMidi < 0) {
                return QuantizeResult{
                    freqHz,
                    freqHz,
                    midiContinuous,
                    nominalMidi,
                    0.0f,
                    1.0f,
                    static_cast<uint8_t>(nominalPitchClass),
                    (nominalMidi / 12) - 1,
                    true
                };
            }
        }

        // Frequenza target f_target = A4 * 2^((bestMidi - 69) / 12)
        const float targetFreq = a4Frequency * std::pow(2.0f, static_cast<float>(bestMidi - 69) * (1.0f / 12.0f));
        const float cents = (static_cast<float>(bestMidi) - midiContinuous) * 100.0f;
        const float rawRatio = (freqHz > 0.0f) ? (targetFreq / freqHz) : 1.0f;
        const float ratio = std::isfinite(rawRatio) ? std::clamp(rawRatio, 0.25f, 4.0f) : 1.0f;

        const uint8_t bestClass = static_cast<uint8_t>(((bestMidi % 12) + 12) % 12);
        const int bestOctave = (bestMidi / 12) - 1;

        return QuantizeResult{
            freqHz,
            targetFreq,
            midiContinuous,
            bestMidi,
            cents,
            ratio,
            bestClass,
            bestOctave,
            true
        };
    }

    // Restituisce il nome testuale della nota (es. "C4", "F#3")
    static constexpr std::string_view getPitchClassName(uint8_t pitchClass) noexcept {
        constexpr std::array<std::string_view, 12> names = {
            "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"
        };
        return names[pitchClass % 12];
    }

    [[nodiscard]] ScaleType getScale() const noexcept { return currentScale; }
    [[nodiscard]] int getRootKey() const noexcept { return rootNote; }
    [[nodiscard]] float getA4Reference() const noexcept { return a4Frequency; }
    [[nodiscard]] uint16_t getActiveMask() const noexcept { return effectiveMask; }

    [[nodiscard]] inline bool isPitchClassActive(int pitchClass) const noexcept {
        const int relativeNote = ((pitchClass - rootNote) % 12 + 12) % 12;
        return (effectiveMask & (1 << relativeNote)) != 0;
    }

private:
    void updateEffectiveMask() noexcept {
        switch (currentScale) {
            case ScaleType::Chromatic:       effectiveMask = MASK_CHROMATIC; break;
            case ScaleType::Major:           effectiveMask = MASK_MAJOR; break;
            case ScaleType::NaturalMinor:    effectiveMask = MASK_NATURAL_MINOR; break;
            case ScaleType::HarmonicMinor:   effectiveMask = MASK_HARMONIC_MINOR; break;
            case ScaleType::MelodicMinor:    effectiveMask = MASK_MELODIC_MINOR; break;
            case ScaleType::Dorian:          effectiveMask = MASK_DORIAN; break;
            case ScaleType::Phrygian:        effectiveMask = MASK_PHRYGIAN; break;
            case ScaleType::Lydian:          effectiveMask = MASK_LYDIAN; break;
            case ScaleType::Mixolydian:      effectiveMask = MASK_MIXOLYDIAN; break;
            case ScaleType::Locrian:         effectiveMask = MASK_LOCRIAN; break;
            case ScaleType::MajorPentatonic: effectiveMask = MASK_MAJOR_PENTATONIC; break;
            case ScaleType::MinorPentatonic: effectiveMask = MASK_MINOR_PENTATONIC; break;
            case ScaleType::Blues:           effectiveMask = MASK_BLUES; break;
            case ScaleType::Custom:          effectiveMask = customMask; break;
            default:                         effectiveMask = MASK_CHROMATIC; break;
        }

        // Se la maschera fosse vuota per errore custom, fallback su Chromatic
        if (effectiveMask == 0) {
            effectiveMask = MASK_CHROMATIC;
        }
    }

    ScaleType currentScale = ScaleType::Chromatic;
    int rootNote = 0; // 0 = C
    float a4Frequency = 440.0f;
    float invA4 = 1.0f / 440.0f;
    uint16_t customMask = MASK_CHROMATIC;
    uint16_t effectiveMask = MASK_CHROMATIC;
    uint16_t bypassMask = 0;
    uint16_t blockedMask = 0;
    int midiTargetNote = -1;
    bool midiTargetActive = false;
    mutable int lastMidiCandidate = -1;
};

} // namespace dsp171
