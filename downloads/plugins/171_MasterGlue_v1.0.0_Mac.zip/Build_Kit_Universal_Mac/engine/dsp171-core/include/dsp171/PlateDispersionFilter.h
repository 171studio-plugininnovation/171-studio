#pragma once
#include <array>
#include <cmath>
#include <algorithm>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// PLATE DISPERSION FILTER (EMT 140 PHYSICAL BENDING WAVE EMULATION)
//
// Nelle piastre metalliche (EMT 140), la propagazione delle onde di flessione
// obbedisce all'equazione biarmonica: vg(omega) proportional sqrt(omega).
// Le alte frequenze viaggiano piu velocemente delle basse frequenze, giungendo
// prima ai pickup e generando il caratteristico transiente "chirp" dispersivo.
//
// Questo modulo impiega una cascata di allpass dispersivi del 1 ordine
// accordati progressivamente per ricreare la corretta dispersione modale.
// =============================================================================

class PlateDispersionStage {
public:
    PlateDispersionStage() = default;

    void prepare(float coeff) noexcept {
        a = std::clamp(coeff, -0.95f, 0.95f);
        x1 = 0.0f;
        y1 = 0.0f;
    }

    void reset() noexcept {
        x1 = 0.0f;
        y1 = 0.0f;
    }

    inline float process(float in) noexcept {
        // Allpass 1st order: y[n] = a * x[n] + x[n-1] - a * y[n-1]
        float out = a * in + x1 - a * y1;
        x1 = in;
        y1 = out;
        if (std::abs(y1) < 1.0e-20f) y1 = 0.0f;
        return out;
    }

private:
    float a = -0.5f;
    float x1 = 0.0f;
    float y1 = 0.0f;
};

class PlateDispersionFilter {
public:
    static constexpr int NUM_STAGES = 8;

    PlateDispersionFilter() = default;

    void prepare(double sampleRate) {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        updateCoefficients();
        reset();
    }

    void reset() noexcept {
        for (int i = 0; i < NUM_STAGES; ++i) {
            stagesL[i].reset();
            stagesR[i].reset();
        }
    }

    void setDispersionAmount(float amount01) noexcept {
        dispersionAmount = std::clamp(amount01, 0.0f, 1.0f);
        updateCoefficients();
    }

    inline void processSample(float inL, float inR, float& outL, float& outR) noexcept {
        if (dispersionAmount < 0.001f) {
            outL = inL;
            outR = inR;
            return;
        }

        float sL = inL;
        float sR = inR;

        for (int i = 0; i < NUM_STAGES; ++i) {
            sL = stagesL[i].process(sL);
            sR = stagesR[i].process(sR);
        }

        outL = inL * (1.0f - dispersionAmount) + sL * dispersionAmount;
        outR = inR * (1.0f - dispersionAmount) + sR * dispersionAmount;
    }

private:
    void updateCoefficients() noexcept {
        // Calcolo coefficienti allpass per modellare la curvatura sqrt(omega)
        for (int i = 0; i < NUM_STAGES; ++i) {
            float frac = static_cast<float>(i + 1) / static_cast<float>(NUM_STAGES + 1);
            // Coefficiente negativo ritarda le basse frequenze rispetto alle alte
            float coeff = -0.30f - 0.55f * std::sqrt(frac) * dispersionAmount;
            stagesL[i].prepare(coeff);
            // Lieve asimmetria tra L e R per spazialita naturale della piastra
            stagesR[i].prepare(coeff * 0.96f);
        }
    }

    double sr = 48000.0;
    float dispersionAmount = 0.75f;
    std::array<PlateDispersionStage, NUM_STAGES> stagesL;
    std::array<PlateDispersionStage, NUM_STAGES> stagesR;
};

} // namespace dsp171
