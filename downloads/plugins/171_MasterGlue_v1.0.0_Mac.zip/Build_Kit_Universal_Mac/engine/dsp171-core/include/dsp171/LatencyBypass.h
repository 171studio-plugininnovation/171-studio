#pragma once
#include <array>
#include <algorithm>
#include <cmath>

namespace dsp171 {

// =============================================================================
// Motore di Master Bypass a Latenza Compensata Bit-Exact
// Mantiene un buffer circolare di campioni dry pristini ritardati esattamente
// della latenza complessiva del plugin (oversampling + lookahead limiter).
// In modalità bypass, garantisce zero sfasamento rispetto alla traccia DAW,
// zero perdite o colorazioni dal circuito di saturazione e crossfade liscio.
// =============================================================================
template <size_t MaxChannels = 2, size_t MaxLatencySamples = 512>
class LatencyCompensatedBypass {
public:
    void reset() noexcept {
        for (size_t ch = 0; ch < MaxChannels; ++ch) {
            ringBuffer[ch].fill(0.0f);
        }
        writeIdx = 0;
    }

    // Scrive il campione dry pristino prima di qualsiasi processing
    inline void pushDrySample(size_t channel, float drySample) noexcept {
        if (channel < MaxChannels) {
            ringBuffer[channel][writeIdx] = drySample;
        }
    }

    // Avanza l'indice di scrittura dopo aver memorizzato tutti i canali per il sample corrente
    inline void advanceWriteIndex() noexcept {
        writeIdx = (writeIdx + 1) % MaxLatencySamples;
    }

    // Recupera il campione dry allineato temporalmente alla latenza specificata
    inline float getAlignedDrySample(size_t channel, size_t latencySamples) const noexcept {
        if (channel >= MaxChannels) return 0.0f;
        const size_t lat = std::min(latencySamples, MaxLatencySamples - 1);
        const size_t readIdx = (writeIdx + MaxLatencySamples - lat - 1) % MaxLatencySamples;
        return ringBuffer[channel][readIdx];
    }

    // Applica il crossfade bypass sul campione wet
    inline float applyBypass(size_t channel, float wetSample, float bypass01, size_t latencySamples) const noexcept {
        const float dryAligned = getAlignedDrySample(channel, latencySamples);
        return (wetSample * (1.0f - bypass01)) + (dryAligned * bypass01);
    }

private:
    std::array<std::array<float, MaxLatencySamples>, MaxChannels> ringBuffer{};
    size_t writeIdx = 0;
};

} // namespace dsp171
