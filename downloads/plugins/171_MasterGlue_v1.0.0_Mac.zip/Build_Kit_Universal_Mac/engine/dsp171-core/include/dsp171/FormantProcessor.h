#pragma once
#include <cmath>
#include <array>
#include <algorithm>
#include "Common.h"
#include "ZDFTiltFilter.h"
#include "FormantShaperZDF.h"

namespace dsp171 {

// =============================================================================
// FormantProcessor
// Modulo avanzato di gestione e compensazione delle formanti del tratto vocale
// basato sul motore Zero-Delay Feedback (ZDF) a doppio polo FormantShaperZDF.
//
// Specifiche Matematiche e Algoritmiche (Melda MAutoPitch-grade):
// 1. "Keep Formants" Automatic Dynamic Tracking:
//    Durante il pitch retuning (specie in Hard-Tune o note alte), compensa
//    automaticamente il pitch ratio applicato:
//      FormantShift_auto = -12.0f * log2(pitchRatio)
//    Neutralizza completamente l'effetto "chipmunk" (voce stridula su note alte)
//    e l'effetto "orco/troll" (voce cavernosa su note basse).
// 2. Formant Shift Bipolare Manuale [-12.0 st .. +12.0 st]:
//    Cumulabile con la compensazione automatica:
//      FormantShift_effective = FormantShift_manual + (keepFormants ? FormantShift_auto : 0.0f)
// 3. Reshaping Spettrale ZDF a Doppio Polo (64-bit):
//    - Banco di filtri parametrici Bell ZDF SVF Cytomic / Zavalishin per preservare
//      le formanti F1 e F2 del tratto vocale.
//    - Formant Tracking dinamico basato su F0 vocale.
//    - Tilt spettrale invariante a 850 Hz per compensazione pendenza glottica.
// 4. Zero latenza algoritmica (0 campioni), zero allocazioni, real-time safe e noexcept.
// =============================================================================
class FormantProcessor : public FormantShaperZDF {
public:
    using FormantShaperZDF::FormantShaperZDF;

    // Metodi compatibili con le interfacce esistenti
    void setFormantShiftSemitones(float semitones) noexcept {
        setManualFormantShift(semitones);
    }

    [[nodiscard]] float getFormantShiftSemitones() const noexcept {
        return getManualFormantShift();
    }

    [[nodiscard]] float getAutoFormantShiftSemitones() const noexcept {
        return getAutoFormantShift();
    }

    [[nodiscard]] float getEffectiveFormantShiftSemitones() const noexcept {
        return getEffectiveFormantShift();
    }

    // Aggiornamento semplificato solo con ratio (mantiene compatibilità)
    void updateRetunePitchRatio(float pitchRatio) noexcept {
        updateTracking(0.0f, pitchRatio, true);
    }

    // Elaborazione a blocchi (zero allocazioni)
    void processBlock(float* buffer, size_t numSamples) noexcept {
        if (buffer == nullptr || numSamples == 0) return;
        for (size_t i = 0; i < numSamples; ++i) {
            buffer[i] = processSample(buffer[i]);
        }
    }
};

} // namespace dsp171
