#pragma once
#include <cstdint>

#if defined(_M_X64) || defined(__x86_64__) || defined(_M_IX86) || defined(__i386__)
#include <xmmintrin.h>
#include <pmmintrin.h>
#define DSP171_ARCH_X86_64 1
#elif defined(__aarch64__) || defined(_M_ARM64)
#include <cfenv>
#define DSP171_ARCH_ARM64 1
#else
#define DSP171_ARCH_GENERIC 1
#endif

namespace dsp171 {

/**
 * @brief ScopedDenormalDisabler
 * Zero-overhead RAII guard that sets Flush-To-Zero (FTZ) and Denormals-Are-Zero (DAZ)
 * on the CPU floating-point control register for the duration of the audio callback.
 * Prevents catastrophic CPU spikes (up to 100x slowdown) caused by denormal/subnormal
 * floating point numbers in recursive IIR filters, reverbs, and compressors under quiet audio.
 */
class ScopedDenormalDisabler {
public:
    ScopedDenormalDisabler() noexcept {
#if defined(DSP171_ARCH_X86_64)
        m_oldMxcsr = _mm_getcsr();
        // Bit 15: Flush To Zero (FTZ), Bit 6: Denormals Are Zero (DAZ)
        _mm_setcsr(m_oldMxcsr | 0x8040);
#elif defined(DSP171_ARCH_ARM64)
        uint64_t fpcr;
        asm volatile("mrs %0, fpcr" : "=r"(fpcr));
        m_oldFpcr = fpcr;
        // Bit 24: Flush to Zero mode
        fpcr |= (1ULL << 24);
        asm volatile("msr fpcr, %0" : : "r"(fpcr));
#endif
    }

    ~ScopedDenormalDisabler() noexcept {
#if defined(DSP171_ARCH_X86_64)
        _mm_setcsr(m_oldMxcsr);
#elif defined(DSP171_ARCH_ARM64)
        asm volatile("msr fpcr, %0" : : "r"(m_oldFpcr));
#endif
    }

    ScopedDenormalDisabler(const ScopedDenormalDisabler&) = delete;
    ScopedDenormalDisabler& operator=(const ScopedDenormalDisabler&) = delete;

private:
#if defined(DSP171_ARCH_X86_64)
    uint32_t m_oldMxcsr{0};
#elif defined(DSP171_ARCH_ARM64)
    uint64_t m_oldFpcr{0};
#endif
};

} // namespace dsp171
