#pragma once
#include <cmath>
#include <algorithm>
#include <array>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// DECAY RATE EQ (FABFILTER PRO-R MULTI-BAND DECAY SHAPER)
//
// Consente di scolpire il tempo di decadimento RT60 in modo selettivo per banda,
// svincolando la dimensione fisica della stanza dall'assorbimento acustico.
//
// Fornisce 3 bande di moltiplicazione del tempo di decadimento:
// 1. Bass Multiply (Low Shelf): estende o asciuga i bassi (es. 200% o 50%).
// 2. Mid Presence (Parametric Bell): modula la presenza delle armoniche vocali.
// 3. High Damping (High Shelf): simula l'assorbimento dell'aria e dei materiali.
//
// Calcola i guadagni di retroazione gi per ciascuna delay line secondo la legge:
// gi = 10^(-3 * di / (fs * RT60 * M(fi)))
// =============================================================================

class DecayRateEQ {
public:
    DecayRateEQ() = default;

    void prepare(double sampleRate) noexcept {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
    }

    void setBands(float bassMult, float bassFreqHz,
                  float midMult, float midFreqHz, float midQ,
                  float trebleMult, float trebleFreqHz) noexcept {
        bMult = std::clamp(bassMult, 0.1f, 4.0f);
        bFreq = std::clamp(bassFreqHz, 40.0f, 600.0f);

        mMult = std::clamp(midMult, 0.1f, 4.0f);
        mFreq = std::clamp(midFreqHz, 300.0f, 6000.0f);
        mQ    = std::clamp(midQ, 0.2f, 4.0f);

        tMult = std::clamp(trebleMult, 0.05f, 3.0f);
        tFreq = std::clamp(trebleFreqHz, 2000.0f, 18000.0f);
    }

    // Calcola il moltiplicatore M(f) alla frequenza desiderata
    float evaluateMultiplierAt(float freqHz) const noexcept {
        float f = std::clamp(freqHz, 20.0f, static_cast<float>(sr * 0.49));
        float mult = 1.0f;

        // 1. Low Shelf Decay Curve
        float lowRatio = f / bFreq;
        float lowWeight = 1.0f / (1.0f + lowRatio * lowRatio); // 2-pole lowpass curve
        mult += (bMult - 1.0f) * lowWeight;

        // 2. High Shelf Decay Curve
        float highRatio = f / tFreq;
        float highWeight = (highRatio * highRatio) / (1.0f + highRatio * highRatio); // 2-pole highpass curve
        mult += (tMult - 1.0f) * highWeight;

        // 3. Mid Bell Peak/Notch
        float octDist = std::log2(f / mFreq);
        float bellWeight = std::exp(-0.5f * (octDist * octDist) / (mQ * mQ * 0.5f));
        mult += (mMult - 1.0f) * bellWeight;

        return std::max(0.05f, mult);
    }

    // Calcola il guadagno di loop ottimale per una delay line di lunghezza dSamples
    float calculateLoopGain(float baseRT60Sec, int dSamples, float characteristicFreqHz, bool isFreeze = false) const noexcept {
        if (isFreeze) return 0.999f;

        float effectiveRT60 = std::max(0.05f, baseRT60Sec * evaluateMultiplierAt(characteristicFreqHz));
        float exponent = -3.0f * static_cast<float>(dSamples) / (static_cast<float>(sr) * effectiveRT60);
        float g = std::pow(10.0f, exponent);
        return std::clamp(g, 0.0f, 0.985f);
    }

    // Calcola un intero vettore di guadagni per N linee di ritardo
    void calculateGainVector(float baseRT60Sec, const int* delaySamples, float* outGains, int numLines, bool isFreeze = false) const noexcept {
        for (int i = 0; i < numLines; ++i) {
            // Frequenza fondamentale associata alla delay line fi = fs / di
            float fNominal = static_cast<float>(sr) / static_cast<float>(std::max(1, delaySamples[i]));
            // Distribuzione frequenziale modale
            float fi = std::clamp(fNominal * 3.5f, 60.0f, 16000.0f);
            outGains[i] = calculateLoopGain(baseRT60Sec, delaySamples[i], fi, isFreeze);
        }
    }

private:
    double sr = 48000.0;
    float bMult = 1.0f;
    float bFreq = 250.0f;
    float mMult = 1.0f;
    float mFreq = 1500.0f;
    float mQ    = 1.0f;
    float tMult = 0.7f;
    float tFreq = 7000.0f;
};

} // namespace dsp171
