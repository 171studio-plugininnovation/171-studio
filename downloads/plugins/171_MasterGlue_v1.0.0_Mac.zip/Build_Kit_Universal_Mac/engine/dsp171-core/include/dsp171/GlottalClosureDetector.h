#pragma once
#include <cmath>
#include <array>
#include <algorithm>
#include <cstdint>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// Marcatore GCI (Glottal Closure Instant / Epoca Glottica)
// Rappresenta l'istante esatto di chiusura delle corde vocali nel dominio temporale.
// =============================================================================
struct GCIMark {
    float timestamp = 0.0f;       // Indice di campione continuo (sub-sample) nel buffer circolare
    float period = 0.0f;          // Periodo locale T0 in campioni
    float strength = 0.0f;        // Intensità dell'impulso glottico
    bool isVoiced = true;         // True se associato a fonazione periodica
};

// =============================================================================
// GlottalClosureDetector
// Rilevatore real-time ad altissima precisione dei Glottal Closure Instants (GCI)
// Caratteristiche:
// 1. Zero allocazioni dinamiche nel process thread.
// 2. Tracciamento sincrono con il periodo fondamentale T0 derivato da MPM.
// 3. Raffinamento dell'epoca tramite minimo della derivata del flusso (dUg/dt)
//    e picco di inviluppo ad alta pendenza.
// 4. Coda circolare di epoche per ricerca O(1) dell'analisi grain più vicina.
// 5. Gestione fall-back trasparente su segmenti non vocalizzati (unvoiced).
// =============================================================================
class GlottalClosureDetector {
public:
    static constexpr size_t GCI_HISTORY_CAPACITY = 128; // Buffer circolare delle ultime 128 epoche
    static constexpr size_t GCI_HISTORY_MASK = GCI_HISTORY_CAPACITY - 1;

    GlottalClosureDetector() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        reset();
    }

    void reset() noexcept {
        gciHistory.fill(GCIMark{});
        historyCount = 0;
        headIndex = 0;
        lastGciTimestamp = 0.0f;
        prevSample = 0.0f;
        prevDerivative = 0.0f;
        hasNewEpochThisSample = false;
    }

    // Registra un nuovo campione audio e aggiorna la marcatura sincrona delle epoche GCI.
    // currentSampleIndex: indice temporale cumulativo continuo del flusso audio in ingresso.
    // currentT0: periodo fondamentale istantaneo in campioni stimato da MPM.
    // isVoiced: flag di vocalizzazione dal pitch detector.
    // circularBuffer: puntatore al buffer circolare di campioni grezzi.
    // bufferMask: maschera bitwise per indirizzamento circolare (es. bufferSize - 1).
    inline void processSample(float sample,
                              int64_t currentSampleIndex,
                              float currentT0,
                              bool isVoiced,
                              const float* circularBuffer,
                              size_t bufferMask) noexcept {
        hasNewEpochThisSample = false;
        // Calcolo della derivata discreta del segnale (prima differenza)
        const float derivative = sample - prevSample;
        prevSample = sample;

        const float nominalT0 = (isVoiced && currentT0 >= 10.0f) ? currentT0 : (sr * 0.010f); // 10ms di fallback
        const float expectedNextGci = lastGciTimestamp + nominalT0;

        // Se abbiamo superato l'istante atteso per la prossima epoca
        if (static_cast<float>(currentSampleIndex) >= expectedNextGci) {
            float refinedGci = static_cast<float>(currentSampleIndex);
            float peakStrength = std::abs(sample);

            if (isVoiced && circularBuffer != nullptr) {
                // Raffinamento causale nella finestra passata [-0.4 * T0, 0]
                // CRITICO: Non ispezionare mai campioni futuri (d > 0) che contengono dati vecchi non sovrascritti!
                const int searchWindow = std::clamp(static_cast<int>(nominalT0 * 0.40f), 2, 128);
                float minDeriv = derivative;
                int bestOffset = 0;

                for (int d = -searchWindow; d <= 0; ++d) {
                    const int64_t idx = currentSampleIndex + d;
                    const size_t cIdx = static_cast<size_t>(idx) & bufferMask;
                    const size_t cPrevIdx = static_cast<size_t>(idx - 1) & bufferMask;
                    const float sCur = circularBuffer[cIdx];
                    const float sPrev = circularBuffer[cPrevIdx];
                    const float dVal = sCur - sPrev;

                    // Cerchiamo il punto di massima negatività della derivata causale (glottal closing slope)
                    if (dVal < minDeriv) {
                        minDeriv = dVal;
                        bestOffset = d;
                        peakStrength = std::abs(sCur);
                    }
                }

                refinedGci = static_cast<float>(currentSampleIndex + bestOffset);
            }

            // Registra l'epoca nella coda circolare
            addGCI(refinedGci, nominalT0, peakStrength, isVoiced);
            lastGciTimestamp = refinedGci;
            hasNewEpochThisSample = true;
        }
    }

    // Trova l'epoca GCI più vicina ad un timestamp target sintetico richiesto da TD-PSOLA
    [[nodiscard]] inline GCIMark findNearestGCI(float targetTimestamp) const noexcept {
        if (historyCount == 0) {
            return GCIMark{ targetTimestamp, sr * 0.010f, 1.0f, false };
        }

        // Cerca l'epoca con minima distanza temporale
        float minDiff = 1e20f;
        GCIMark bestMark = gciHistory[0];

        for (size_t i = 0; i < historyCount; ++i) {
            const size_t idx = (headIndex + GCI_HISTORY_CAPACITY - 1 - i) & GCI_HISTORY_MASK;
            const GCIMark& mark = gciHistory[idx];
            const float diff = std::abs(mark.timestamp - targetTimestamp);

            if (diff < minDiff) {
                minDiff = diff;
                bestMark = mark;
            }
        }

        return bestMark;
    }

    [[nodiscard]] float getLastGCITimestamp() const noexcept { return lastGciTimestamp; }
    [[nodiscard]] size_t getHistoryCount() const noexcept { return historyCount; }
    [[nodiscard]] bool hasNewEpoch() const noexcept { return hasNewEpochThisSample; }

private:
    inline void addGCI(float timestamp, float period, float strength, bool isVoiced) noexcept {
        gciHistory[headIndex] = GCIMark{ timestamp, period, strength, isVoiced };
        headIndex = (headIndex + 1) & GCI_HISTORY_MASK;
        if (historyCount < GCI_HISTORY_CAPACITY) {
            historyCount++;
        }
    }

    float sr = 48000.0f;
    std::array<GCIMark, GCI_HISTORY_CAPACITY> gciHistory{};
    size_t headIndex = 0;
    size_t historyCount = 0;

    float lastGciTimestamp = 0.0f;
    float prevSample = 0.0f;
    float prevDerivative = 0.0f;
    bool hasNewEpochThisSample = false;
};

} // namespace dsp171
