#pragma once
#include <vector>
#include <array>
#include <cmath>
#include <algorithm>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// SCHROEDER ALLPASS INPUT DIFFUSER NETWORK (LEXICON 224 / VALHALLA VINTAGEVERB)
//
// Cascata di diffusori allpass con coefficiente di diffusione aureo g = 0.618.
// Disperde i transienti percussivi in ingresso in una nuvola densa pre-FDN,
// eliminando qualsiasi effetto metallico e flutter echo.
// =============================================================================

class SchroederAllpassStage {
public:
    SchroederAllpassStage() = default;

    void prepare(int delaySamples, float feedback = 0.618034f) {
        dSamples = std::max(2, delaySamples);
        buffer.assign(dSamples, 0.0f);
        index = 0;
        g = std::clamp(feedback, 0.1f, 0.85f);
    }

    inline float process(float in) noexcept {
        float delayed = buffer[index];
        float out = -g * in + delayed;
        buffer[index] = in + g * out;
        index = (index + 1) % dSamples;
        return out;
    }

    void reset() noexcept {
        std::fill(buffer.begin(), buffer.end(), 0.0f);
        index = 0;
    }

    int getDelaySamples() const noexcept { return dSamples; }
    float getFeedback() const noexcept { return g; }

private:
    std::vector<float> buffer;
    int index = 0;
    int dSamples = 100;
    float g = 0.618034f; // Rapporto aureo (phi) per minima risonanza
};

class SchroederDiffuser {
public:
    static constexpr int NUM_STAGES = 4;
    static constexpr int BASE_DELAYS[NUM_STAGES] = { 149, 211, 337, 421 };

    SchroederDiffuser() = default;

    void prepare(double sampleRate) {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        const float scale = static_cast<float>(sr / 48000.0);

        for (int i = 0; i < NUM_STAGES; ++i) {
            int dL = std::max(2, static_cast<int>(BASE_DELAYS[i] * scale));
            // Offset coprimo di +19 campioni per decorrelazione stereofonica
            int dR = std::max(2, static_cast<int>((BASE_DELAYS[i] + 19) * scale));

            stagesL[i].prepare(dL, 0.618034f);
            stagesR[i].prepare(dR, 0.618034f);
        }
    }

    void reset() noexcept {
        for (int i = 0; i < NUM_STAGES; ++i) {
            stagesL[i].reset();
            stagesR[i].reset();
        }
    }

    inline void processSample(float inL, float inR, float& outL, float& outR) noexcept {
        float sL = inL;
        float sR = inR;

        for (int i = 0; i < NUM_STAGES; ++i) {
            sL = stagesL[i].process(sL);
            sR = stagesR[i].process(sR);
        }

        outL = sL;
        outR = sR;
    }

private:
    double sr = 48000.0;
    std::array<SchroederAllpassStage, NUM_STAGES> stagesL;
    std::array<SchroederAllpassStage, NUM_STAGES> stagesR;
};

} // namespace dsp171
