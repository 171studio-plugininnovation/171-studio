#pragma once
#include <cmath>
#include <algorithm>

namespace dsp171 {

/**
 * @brief UADDistressor
 * Reverse-engineered from Universal Audio / Empirical Labs EL8 Distressor.
 * Models Dave Derr's digitally controlled analog knee compressor featuring:
 * - 8 Ratios: 1:1, 2:1, 3:1, 4:1, 6:1, 10:1 (Opto mode), 20:1, and NUKE (brickwall).
 * - Audio Modes: Clean, Dist 2 (warm 2nd harmonic tube-like), Dist 3 (tape-style 3rd harmonic), and HP (80 Hz highpass).
 * - Detector Modes: Norm, HP (120 Hz sidechain bass filter), and Band Emphasis (6 kHz vocal sibilance/presence boost).
 */
class UADDistressor {
public:
    enum class Ratio {
        Ratio1_1,
        Ratio2_1,
        Ratio3_1,
        Ratio4_1,
        Ratio6_1,
        Ratio10_1_Opto,
        Ratio20_1,
        Ratio_Nuke
    };

    enum class AudioDistortion {
        Clean,
        Dist2, // 2nd harmonic (even tube warmth)
        Dist3  // 3rd harmonic (odd tape saturation)
    };

    enum class DetectorMode {
        Norm,
        HP,           // Highpass at 120 Hz
        BandEmphasis, // Bell boost at 6 kHz (de-harshing)
        HP_BandEmphasis
    };

    UADDistressor() noexcept 
        : m_sampleRate(44100.0f) {}

    void prepare(float sampleRate) noexcept {
        m_sampleRate = sampleRate;
        m_gainReductionL = 1.0f;
        m_gainReductionR = 1.0f;
        m_detHpL = 0.0f; m_detHpR = 0.0f;
        m_detEmpL = 0.0f; m_detEmpR = 0.0f;
        m_audioHpL = 0.0f; m_audioHpR = 0.0f;
    }

    void setParameters(float inputDrive = 5.0f, float outputLevel = 5.0f,
                       float attackKnob = 3.0f, float releaseKnob = 3.0f,
                       Ratio ratio = Ratio::Ratio4_1,
                       AudioDistortion audioDist = AudioDistortion::Clean,
                       bool audioHp = false,
                       DetectorMode detMode = DetectorMode::Norm) noexcept {
        // Distressor 0-10 knobs
        m_inputGain = std::pow(10.0f, (std::clamp(inputDrive, 0.0f, 10.0f) * 4.0f - 20.0f) / 20.0f);
        m_outputGain = std::pow(10.0f, (std::clamp(outputLevel, 0.0f, 10.0f) * 4.0f - 20.0f) / 20.0f);
        
        m_ratioMode = ratio;
        m_audioDist = audioDist;
        m_audioHp = audioHp;
        m_detMode = detMode;

        // Attack ballistics (Knob 0 = 0.05 ms, Knob 10 = 35 ms)
        m_attackMs = 0.05f + std::pow(attackKnob / 10.0f, 2.0f) * 35.0f;
        if (ratio == Ratio::Ratio10_1_Opto) {
            m_attackMs = 10.0f; // Opto mode locks attack to classic 10 ms
        }

        // Release ballistics (Knob 0 = 50 ms, Knob 10 = 3500 ms)
        m_releaseMs = 50.0f + std::pow(releaseKnob / 10.0f, 2.0f) * 3450.0f;

        // Ratio numeric values and knee profile
        switch (ratio) {
            case Ratio::Ratio1_1:        m_ratio = 1.0f;  m_kneeWidthDb = 0.0f; break;
            case Ratio::Ratio2_1:        m_ratio = 2.0f;  m_kneeWidthDb = 12.0f; break; // ultra soft knee
            case Ratio::Ratio3_1:        m_ratio = 3.0f;  m_kneeWidthDb = 8.0f; break;
            case Ratio::Ratio4_1:        m_ratio = 4.0f;  m_kneeWidthDb = 6.0f; break;
            case Ratio::Ratio6_1:        m_ratio = 6.0f;  m_kneeWidthDb = 4.0f; break;
            case Ratio::Ratio10_1_Opto:  m_ratio = 10.0f; m_kneeWidthDb = 10.0f; break; // Opto curve
            case Ratio::Ratio20_1:       m_ratio = 20.0f; m_kneeWidthDb = 2.0f; break;
            case Ratio::Ratio_Nuke:      m_ratio = 100.0f; m_kneeWidthDb = 0.5f; break; // Brickwall hard knee
        }

        m_attCoeff = 1.0f - std::exp(-1.0f / ((m_attackMs * 0.001f) * m_sampleRate));
        m_relCoeff = 1.0f - std::exp(-1.0f / ((m_releaseMs * 0.001f) * m_sampleRate));
    }

    inline void process(float inL, float inR, float& outL, float& outR) noexcept {
        // 1. Audio Highpass (80 Hz, 18 dB/oct filter)
        float sigL = inL * m_inputGain;
        float sigR = inR * m_inputGain;

        if (m_audioHp) {
            float alphaAudio = 80.0f / (80.0f + m_sampleRate / 6.2831853f);
            m_audioHpL += alphaAudio * (sigL - m_audioHpL);
            m_audioHpR += alphaAudio * (sigR - m_audioHpR);
            sigL -= m_audioHpL;
            sigR -= m_audioHpR;
        }

        // 2. Detector Sidechain Filtering
        float detL = sigL;
        float detR = sigR;

        if (m_detMode == DetectorMode::HP || m_detMode == DetectorMode::HP_BandEmphasis) {
            float alphaDet = 120.0f / (120.0f + m_sampleRate / 6.2831853f);
            m_detHpL += alphaDet * (detL - m_detHpL);
            m_detHpR += alphaDet * (detR - m_detHpR);
            detL -= m_detHpL;
            detR -= m_detHpR;
        }

        if (m_detMode == DetectorMode::BandEmphasis || m_detMode == DetectorMode::HP_BandEmphasis) {
            // 6 kHz peak boost in detector
            float alphaEmp = 6000.0f / (6000.0f + m_sampleRate / 6.2831853f);
            m_detEmpL += alphaEmp * (detL - m_detEmpL);
            m_detEmpR += alphaEmp * (detR - m_detEmpR);
            detL += (detL - m_detEmpL) * 1.5f;
            detR += (detR - m_detEmpR) * 1.5f;
        }

        // 3. Dynamic Knee Gain Reduction
        float peakDet = std::max(std::fabs(detL), std::fabs(detR));
        float detDb = 20.0f * std::log10(std::max(peakDet, 1e-5f));
        float thresholdDb = -18.0f; // Fixed internal reference threshold

        float overDb = detDb - thresholdDb;
        float targetGrDb = 0.0f;

        if (m_ratio > 1.05f) {
            if (overDb > (m_kneeWidthDb * 0.5f)) {
                targetGrDb = overDb * (1.0f - 1.0f / m_ratio);
            } else if (overDb > -(m_kneeWidthDb * 0.5f)) {
                float x = overDb + (m_kneeWidthDb * 0.5f);
                targetGrDb = (x * x / (2.0f * m_kneeWidthDb)) * (1.0f - 1.0f / m_ratio);
            }
        }

        float targetGainLinear = std::pow(10.0f, -targetGrDb / 20.0f);

        // 4. Attack/Release Ballistics using precomputed coefficients
        if (targetGainLinear < m_gainReductionL) {
            m_gainReductionL += m_attCoeff * (targetGainLinear - m_gainReductionL);
        } else {
            m_gainReductionL += m_relCoeff * (targetGainLinear - m_gainReductionL);
        }
        m_gainReductionR = m_gainReductionL;

        float compL = sigL * m_gainReductionL;
        float compR = sigR * m_gainReductionR;

        // 5. Audio Distortion Modes (Dist 2 vs Dist 3)
        if (m_audioDist == AudioDistortion::Dist2) {
            // Warm 2nd harmonic (asymmetric tube)
            compL += 0.06f * (compL * compL);
            compR += 0.06f * (compR * compR);
        } else if (m_audioDist == AudioDistortion::Dist3) {
            // Tape 3rd harmonic saturation (symmetric soft saturation)
            compL = std::tanh(compL * 1.15f) / 1.15f;
            compR = std::tanh(compR * 1.15f) / 1.15f;
        }

        outL = compL * m_outputGain;
        outR = compR * m_outputGain;
    }

    void processBlock(float* left, float* right, int numSamples) noexcept {
        for (int i = 0; i < numSamples; ++i) {
            process(left[i], right[i], left[i], right[i]);
        }
    }

    void processBlock(const float* inL, const float* inR, float* outL, float* outR, size_t numSamples) noexcept {
        for (size_t i = 0; i < numSamples; ++i) {
            process(inL[i], inR[i], outL[i], outR[i]);
        }
    }

    [[nodiscard]] float getGainReductionDb() const noexcept {
        return -20.0f * std::log10(std::max(m_gainReductionL, 1e-4f));
    }

    [[nodiscard]] float getGainReductionDbL() const noexcept {
        return -20.0f * std::log10(std::max(m_gainReductionL, 1e-4f));
    }

    [[nodiscard]] float getGainReductionDbR() const noexcept {
        return -20.0f * std::log10(std::max(m_gainReductionR, 1e-4f));
    }

private:
    float m_sampleRate;
    float m_inputGain{1.0f};
    float m_outputGain{1.0f};
    float m_attackMs{5.0f};
    float m_releaseMs{200.0f};
    Ratio m_ratioMode{Ratio::Ratio4_1};
    float m_ratio{4.0f};
    float m_kneeWidthDb{6.0f};
    AudioDistortion m_audioDist{AudioDistortion::Clean};
    bool m_audioHp{false};
    DetectorMode m_detMode{DetectorMode::Norm};

    float m_gainReductionL{1.0f};
    float m_gainReductionR{1.0f};
    float m_attCoeff{0.1f};
    float m_relCoeff{0.01f};
    float m_detHpL{0}, m_detHpR{0};
    float m_detEmpL{0}, m_detEmpR{0};
    float m_audioHpL{0}, m_audioHpR{0};
};

} // namespace dsp171
