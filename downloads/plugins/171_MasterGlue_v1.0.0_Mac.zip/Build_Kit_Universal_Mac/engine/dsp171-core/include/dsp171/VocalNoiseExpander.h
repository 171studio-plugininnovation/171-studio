#pragma once

#include <cmath>
#include <algorithm>
#include <cstdint>
#include "Common.h"
#include "FastMath.h"
#include "ZDFSVF.h"

namespace dsp171 {

// =============================================================================
// VOCAL NOISE EXPANDER & GATE (Schmitt-Trigger Hysteresis & De-Bleed)
//
// Specialized Hard Real-Time C++20 Vocal Gate/Expander developed under
// guidance of Agente 19 (vocal-gate-expander-specialist).
//
// Solves high-gain vocal chain noise floor elevation, headphone spill (click/cymbals)
// and microphone room ambience without consonant-clipping or gate chatter.
//
// Key Specifications:
// - Dual-threshold Schmitt-Trigger: T_open > T_close prevents chatter.
// - 2-pole Zero-Delay Feedback (ZDF) Sidechain Bandpass Filter (180 Hz - 4.5 kHz).
// - Envelope state machine: Attack -> Hold -> Release with smooth exponential decay.
// - Soft Downward Expander curve with bounded Range floor (-48 dB to -6 dB).
// - Zero Latency (0 samples), zero heap allocations, strict FTZ/DAZ.
// =============================================================================

class VocalNoiseExpander {
public:
    enum class Mode : uint8_t {
        DownwardExpander = 0,
        HardGate
    };

    enum class ListenMode : uint8_t {
        Audio = 0,
        Sidechain,
        Delta
    };

    VocalNoiseExpander() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        fs = (sampleRate > 1000.0) ? sampleRate : 48000.0;
        invFs = 1.0 / fs;
        reset();
        updateFilterCoeffs();
        updateTimeConstants();
    }

    void reset() noexcept {
        detectorEnvL = 0.0f;
        detectorEnvR = 0.0f;
        gainEnvL = 1.0f;
        gainEnvR = 1.0f;
        currentGRL = 0.0f;
        currentGRR = 0.0f;
        holdCounterL = 0;
        holdCounterR = 0;
        gateStateL = State::Closed;
        gateStateR = State::Closed;

        scSVF_L.reset();
        scSVF_R.reset();
    }

    // --- Parameter Setters ---

    // Threshold in dBFS (-60.0 dB to 0.0 dB)
    void setThreshold(float threshDb) noexcept {
        thresholdDb = std::clamp(threshDb, -80.0f, 0.0f);
        updateThresholds();
    }

    // Hysteresis in dB (1.0 dB to 12.0 dB)
    void setHysteresis(float hystDb) noexcept {
        hysteresisDb = std::clamp(hystDb, 1.0f, 15.0f);
        updateThresholds();
    }

    // Range in dB (-60.0 dB to -3.0 dB) - maximum attenuation applied
    void setRange(float rangeDb) noexcept {
        rangeDbValue = std::clamp(rangeDb, -60.0f, -3.0f);
        floorLinear = std::pow(10.0f, rangeDbValue * 0.05f);
    }

    // Expansion Ratio (1.2:1 to 8.0:1)
    void setRatio(float r) noexcept {
        ratio = std::clamp(r, 1.1f, 12.0f);
    }

    // Attack time in milliseconds (0.1 ms to 20.0 ms)
    void setAttackMs(float ms) noexcept {
        attackMs = std::clamp(ms, 0.1f, 50.0f);
        updateTimeConstants();
    }

    // Hold time in milliseconds (5.0 ms to 300.0 ms)
    void setHoldMs(float ms) noexcept {
        holdMs = std::clamp(ms, 0.0f, 500.0f);
        updateTimeConstants();
    }

    // Release time in milliseconds (10.0 ms to 1000.0 ms)
    void setReleaseMs(float ms) noexcept {
        releaseMs = std::clamp(ms, 10.0f, 1500.0f);
        updateTimeConstants();
    }

    // Sidechain Bandpass Filter Settings
    void setSidechainFilter(float lowCutHz, float highCutHz) noexcept {
        scLowCut = std::clamp(lowCutHz, 40.0f, 1000.0f);
        scHighCut = std::clamp(highCutHz, 1500.0f, 12000.0f);
        updateFilterCoeffs();
    }

    void setMode(Mode m) noexcept { mode = m; }
    void setListenMode(ListenMode l) noexcept { listenMode = l; }

    // Telemetry
    [[nodiscard]] float getGainReductionL() const noexcept { return currentGRL; }
    [[nodiscard]] float getGainReductionR() const noexcept { return currentGRR; }

    // --- Audio Processing Block ---
    void process(float* const* channelData, int numChannels, int numSamples) noexcept {
        if (numChannels <= 0 || numSamples <= 0) return;

        float* left = channelData[0];
        float* right = (numChannels > 1) ? channelData[1] : nullptr;

        for (int i = 0; i < numSamples; ++i) {
            float inL = std::isfinite(left[i]) ? left[i] : 0.0f;
            float inR = right ? (std::isfinite(right[i]) ? right[i] : 0.0f) : inL;

            // 1. Sidechain Filtering (2-pole ZDF Bandpass for Vocal Formants)
            float scL = processSidechainFilterL(inL);
            float scR = right ? processSidechainFilterR(inR) : scL;

            // 2. State-Machine & Envelope Following
            float targetGainL = computeTargetGain(scL, detectorEnvL, gateStateL, holdCounterL);
            float targetGainR = right ? computeTargetGain(scR, detectorEnvR, gateStateR, holdCounterR) : targetGainL;

            // 3. Smooth Gain Envelope Interpolation
            float gainL = smoothGain(targetGainL, gainEnvL);
            float gainR = smoothGain(targetGainR, gainEnvR);

            // Record telemetry (in dB)
            currentGRL = (gainL > 1e-5f) ? -20.0f * std::log10(gainL) : -rangeDbValue;
            currentGRR = (gainR > 1e-5f) ? -20.0f * std::log10(gainR) : -rangeDbValue;

            // 4. Output Generation based on Listen Mode
            float outL = inL * gainL;
            float outR = inR * gainR;

            switch (listenMode) {
                case ListenMode::Sidechain:
                    left[i] = scL;
                    if (right) right[i] = scR;
                    break;

                case ListenMode::Delta:
                    // Delta: What was removed (leakage/noise/breaths)
                    left[i] = inL - outL;
                    if (right) right[i] = inR - outR;
                    break;

                case ListenMode::Audio:
                default:
                    left[i] = outL;
                    if (right) right[i] = outR;
                    break;
            }
        }
    }

private:
    enum class State : uint8_t {
        Open = 0,
        Hold,
        Release,
        Closed
    };

    double fs = 48000.0;
    double invFs = 1.0 / 48000.0;

    float thresholdDb = -42.0f;
    float hysteresisDb = 4.0f;
    float threshOpenLinear = 0.007943f;   // -42 dB
    float threshCloseLinear = 0.005011f;  // -46 dB

    float rangeDbValue = -30.0f;
    float floorLinear = 0.031622f; // -30 dB
    float ratio = 2.5f;

    float attackMs = 1.5f;
    float holdMs = 45.0f;
    float releaseMs = 120.0f;

    float attackCoeff = 0.95f;
    float releaseCoeff = 0.999f;
    int holdSamplesTarget = 2160;

    float scLowCut = 180.0f;
    float scHighCut = 4500.0f;

    Mode mode = Mode::DownwardExpander;
    ListenMode listenMode = ListenMode::Audio;

    // Runtime state
    float detectorEnvL = 0.0f;
    float detectorEnvR = 0.0f;
    float gainEnvL = 1.0f;
    float gainEnvR = 1.0f;
    float currentGRL = 0.0f;
    float currentGRR = 0.0f;

    State gateStateL = State::Closed;
    State gateStateR = State::Closed;
    int holdCounterL = 0;
    int holdCounterR = 0;

    // ZDF SVF State for Sidechain (Bandpass)
    ZDFSVF64 scSVF_L;
    ZDFSVF64 scSVF_R;

    void updateThresholds() noexcept {
        threshOpenLinear = std::pow(10.0f, thresholdDb * 0.05f);
        threshCloseLinear = std::pow(10.0f, (thresholdDb - hysteresisDb) * 0.05f);
    }

    void updateTimeConstants() noexcept {
        attackCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (attackMs * 0.001 * fs)));
        releaseCoeff = static_cast<float>(1.0 - std::exp(-1.0 / (releaseMs * 0.001 * fs)));
        holdSamplesTarget = static_cast<int>(holdMs * 0.001 * fs);
    }

    void updateFilterCoeffs() noexcept {
        double fCenter = std::sqrt(static_cast<double>(scLowCut) * static_cast<double>(scHighCut));
        double fBandwidth = static_cast<double>(scHighCut) - static_cast<double>(scLowCut);
        double Q = std::clamp(fCenter / (fBandwidth + 1e-4), 0.3, 4.0);
        scSVF_L.setParameters(static_cast<float>(fCenter), static_cast<float>(Q), static_cast<float>(fs));
        scSVF_R.setParameters(static_cast<float>(fCenter), static_cast<float>(Q), static_cast<float>(fs));
    }

    float processSidechainFilterL(float x) noexcept {
        auto out = scSVF_L.process(x);
        return 2.0f * static_cast<float>(scSVF_L.R) * out.bp;
    }

    float processSidechainFilterR(float x) noexcept {
        auto out = scSVF_R.process(x);
        return 2.0f * static_cast<float>(scSVF_R.R) * out.bp;
    }

    float computeTargetGain(float scSample, float& envFollower, State& state, int& holdCounter) noexcept {
        float absVal = std::abs(scSample);
        
        // Fast peak follower for detector
        const float alphaDet = (absVal > envFollower) ? 0.35f : 0.005f;
        envFollower += alphaDet * (absVal - envFollower);
        if (envFollower < 1.0e-25f) envFollower = 0.0f;

        // Schmitt-Trigger State Machine
        if (envFollower >= threshOpenLinear) {
            state = State::Open;
            holdCounter = holdSamplesTarget;
        } else if (state == State::Open) {
            if (envFollower < threshCloseLinear) {
                state = State::Hold;
                holdCounter = holdSamplesTarget;
            }
        } else if (state == State::Hold) {
            if (--holdCounter <= 0) {
                state = State::Release;
            }
        }

        // Gain Computation
        if (state == State::Open || state == State::Hold) {
            return 1.0f;
        }

        if (mode == Mode::HardGate) {
            return floorLinear;
        }

        // Downward Expander mode
        if (envFollower < 1e-6f) {
            return floorLinear;
        }

        float levelDb = 20.0f * std::log10(envFollower);
        if (levelDb < thresholdDb) {
            float diff = (levelDb - thresholdDb) * (ratio - 1.0f);
            float targetDb = std::max(rangeDbValue, diff);
            return std::pow(10.0f, targetDb * 0.05f);
        }

        return 1.0f;
    }

    float smoothGain(float targetGain, float& currentGain) noexcept {
        if (targetGain > currentGain) {
            currentGain += attackCoeff * (targetGain - currentGain);
        } else {
            currentGain += releaseCoeff * (targetGain - currentGain);
        }
        if (currentGain < 1.0e-25f) currentGain = 0.0f;
        return currentGain;
    }
};

} // namespace dsp171
