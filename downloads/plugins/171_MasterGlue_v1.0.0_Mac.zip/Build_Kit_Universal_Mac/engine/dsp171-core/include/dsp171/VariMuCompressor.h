#pragma once

#include <cmath>
#include <algorithm>
#include <array>
#include "Common.h"
#include "DCBlocker.h"
#include "FastMath.h"

namespace dsp171 {

// =============================================================================
// VariMuCompressor
// Crafted by: comp-optical-universal & analytical-math-physicist
// Supervised by: dsp-hire-manager
//
// Physical modeling of the legendary Fairchild 660 / 670 Variable-Mu Compressor:
// 1. Remote-Cutoff Push-Pull Dual-Triode 6386 Gain Reduction:
//    - Variable transconductance (gm) controlled by grid bias voltage.
//    - Transfer law: GR_dB = -(0.35 * V_bias + 0.02 * V_bias^2).
//    - Ultra-smooth parabolic knee that never turns into hard brickwall limiting.
// 2. Exact 6 Program-Dependent Time Constants:
//    - Pos 1: Attack 0.2 ms | Release 0.3 s (Snare / fast vocal)
//    - Pos 2: Attack 0.2 ms | Release 0.8 s (General tracking)
//    - Pos 3: Attack 0.4 ms | Release 2.0 s (Bass / piano glue)
//    - Pos 4: Attack 0.8 ms | Release 5.0 s (Slow mastering)
//    - Pos 5: Attack 0.4 ms | Dual Auto 1: 2.0s short peaks, 10.0s sustained body
//    - Pos 6: Attack 0.2 ms | Dual Auto 2: 0.8s isolated peaks, 3.0s medium, 25.0s forte
// 3. Lateral / Vertical (Mid/Side) and Left/Right Processing Modes.
// 4. Interstage audio transformer saturation (UTC A-20 / Marinair push-pull).
// =============================================================================

enum class FairchildTimeConstant : uint8_t {
    Pos1 = 0, // Att 0.2ms, Rel 0.3s
    Pos2,     // Att 0.2ms, Rel 0.8s
    Pos3,     // Att 0.4ms, Rel 2.0s
    Pos4,     // Att 0.8ms, Rel 5.0s
    Pos5,     // Att 0.4ms, Dual Auto 2.0s / 10.0s
    Pos6      // Att 0.2ms, Dual Auto 0.8s / 3.0s / 25.0s (Classic Bus)
};

enum class ChannelMode : uint8_t {
    LeftRight = 0,
    LatVert_MidSide
};

class VariMuCompressor {
public:
    VariMuCompressor() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        invSr = 1.0f / sr;
        dt = invSr;

        dcBlockerL.prepare(sampleRate, 10.0f);
        dcBlockerR.prepare(sampleRate, 10.0f);

        updateCoefficients();
        reset();
    }

    void reset() noexcept {
        vBiasL = 0.0f;
        vBiasR = 0.0f;
        biasSlowL = 0.0f;
        biasSlowR = 0.0f;
        currentGRL_dB = 0.0f;
        currentGRR_dB = 0.0f;
        scHPStateL = 0.0f;
        scHPStateR = 0.0f;
        dcBlockerL.reset();
        dcBlockerR.reset();
    }

    void setParameters(float threshold0To10, float inputGainDb, FairchildTimeConstant tc,
                       ChannelMode mode = ChannelMode::LeftRight, float scHPFreq = 80.0f) noexcept
    {
        threshKnob = std::clamp(threshold0To10, 0.0f, 10.0f);
        inGainDb = inputGainDb;
        inGainLin = dbToGain(inGainDb);
        timeConstant = tc;
        channelMode = mode;
        scFreq = std::clamp(scHPFreq, 20.0f, 250.0f);
        updateCoefficients();
    }

    [[nodiscard]] float getGainReductionL() const noexcept { return currentGRL_dB; }
    [[nodiscard]] float getGainReductionR() const noexcept { return currentGRR_dB; }

    // Process a stereo block with Left/Right or Mid/Side (Lat/Vert) processing
    void process(float* inOutL, float* inOutR, size_t numSamples) noexcept {
        if (!inOutL || !inOutR || numSamples == 0) return;

        for (size_t i = 0; i < numSamples; ++i) {
            float ch1 = inOutL[i] * inGainLin;
            float ch2 = inOutR[i] * inGainLin;

            // 1. Matrix encoding if Lat/Vert (Mid/Side) mode is selected
            if (channelMode == ChannelMode::LatVert_MidSide) {
                // Lat = (L + R) * 0.7071 (Mid), Vert = (L - R) * 0.7071 (Side)
                const float lat = (ch1 + ch2) * 0.70710678f;
                const float vert = (ch1 - ch2) * 0.70710678f;
                ch1 = lat;
                ch2 = vert;
            }

            // 2. Sidechain High-Pass Filter (prevents LF bass pumping)
            scHPStateL += scAlpha * (ch1 - scHPStateL);
            scHPStateR += scAlpha * (ch2 - scHPStateR);
            const float sc1 = ch1 - scHPStateL;
            const float sc2 = ch2 - scHPStateR;

            // 3. Peak Rectification & Remote-Cutoff Grid Bias Tracking
            const float peak1 = std::abs(sc1);
            const float peak2 = std::abs(sc2);

            currentGRL_dB = updateChannelBias(peak1, vBiasL, biasSlowL);
            currentGRR_dB = updateChannelBias(peak2, vBiasR, biasSlowR);

            // 4. Apply 6386 Tube Variable Gain
            const float gainLin1 = dbToGain(-currentGRL_dB);
            const float gainLin2 = dbToGain(-currentGRR_dB);

            float out1 = ch1 * gainLin1;
            float out2 = ch2 * gainLin2;

            // 5. Matrix decoding back to Left/Right if in Lat/Vert mode
            if (channelMode == ChannelMode::LatVert_MidSide) {
                // L = (Lat + Vert) * 0.7071, R = (Lat - Vert) * 0.7071
                const float left = (out1 + out2) * 0.70710678f;
                const float right = (out1 - out2) * 0.70710678f;
                out1 = left;
                out2 = right;
            }

            // 6. Push-Pull Tube Interstage Transformer Saturation
            out1 = saturateTube6386(out1);
            out2 = saturateTube6386(out2);

            inOutL[i] = dcBlockerL.processSample(out1);
            inOutR[i] = dcBlockerR.processSample(out2);
        }
    }

private:
    float updateChannelBias(float peak, float& biasFast, float& biasSlow) const noexcept {
        // Threshold mapping: Knob 0..10 maps input drive threshold from -8 dBFS to -40 dBFS
        const float thresholdLevel = dbToGain(-8.0f - (threshKnob * 3.2f));

        float targetBias = 0.0f;
        if (peak > thresholdLevel) {
            // Over-threshold signal drives the 12AU7 control amp to generate negative DC grid bias
            const float over = peak - thresholdLevel;
            targetBias = over * 14.0f;
        }

        // Ballistics update according to Fairchild 6 Time Constants
        if (targetBias > biasFast) {
            // Fast attack
            biasFast += attackAlpha * (targetBias - biasFast);
            biasSlow += slowAttackAlpha * (targetBias - biasSlow);
        } else {
            // Release: Dual-automatic recovery modes 5 & 6 vs fixed modes 1-4
            biasFast += releaseFastAlpha * (targetBias - biasFast);
            biasSlow += releaseSlowAlpha * (targetBias - biasSlow);
        }

        // Flush subnormal values
        if (biasFast < 1e-4f) biasFast = 0.0f;
        if (biasSlow < 1e-4f) biasSlow = 0.0f;

        // Effective bias is blended between fast envelope and slow recovery memory
        const float effBias = isDualAuto
            ? (0.50f * biasFast + 0.50f * biasSlow)
            : biasFast;

        // Remote-Cutoff 6386 Tube Gain Law:
        // GR_dB = 0.35 * V_bias + 0.02 * V_bias^2
        return (0.35f * effBias + 0.02f * (effBias * effBias));
    }

    static float saturateTube6386(float x) noexcept {
        // Push-pull Class-A 6386: odd harmonics with warm soft-saturation knee
        // Clamped at |x| = 3.0f to eliminate quadratic expansion blowup on extreme peaks
        const float k = 1.05f;
        const float xClamped = std::clamp(x, -3.0f, 3.0f);
        return std::tanh(k * x) * (1.0f + 0.025f * (xClamped * xClamped));
    }

    void updateCoefficients() noexcept {
        float attSec = 0.0002f;
        float relSec = 0.300f;
        float slowRelSec = 2.0f;
        isDualAuto = false;

        switch (timeConstant) {
            case FairchildTimeConstant::Pos1:
                attSec = 0.0002f; relSec = 0.300f; break;
            case FairchildTimeConstant::Pos2:
                attSec = 0.0002f; relSec = 0.800f; break;
            case FairchildTimeConstant::Pos3:
                attSec = 0.0004f; relSec = 2.000f; break;
            case FairchildTimeConstant::Pos4:
                attSec = 0.0008f; relSec = 5.000f; break;
            case FairchildTimeConstant::Pos5:
                attSec = 0.0004f; relSec = 2.000f; slowRelSec = 10.0f; isDualAuto = true; break;
            case FairchildTimeConstant::Pos6:
                attSec = 0.0002f; relSec = 0.800f; slowRelSec = 25.0f; isDualAuto = true; break;
        }

        attackAlpha = 1.0f - std::exp(-dt / attSec);
        slowAttackAlpha = 1.0f - std::exp(-dt / (attSec * 4.0f));
        releaseFastAlpha = 1.0f - std::exp(-dt / relSec);
        releaseSlowAlpha = 1.0f - std::exp(-dt / slowRelSec);

        scAlpha = std::clamp(2.0f * PI * scFreq * invSr, 0.001f, 0.5f);
    }

    float sr{44100.0f};
    float invSr{1.0f / 44100.0f};
    float dt{1.0f / 44100.0f};

    float threshKnob{0.0f};
    float inGainDb{0.0f};
    float inGainLin{1.0f};
    float scFreq{80.0f};
    FairchildTimeConstant timeConstant{FairchildTimeConstant::Pos1};
    ChannelMode channelMode{ChannelMode::LeftRight};

    bool isDualAuto{false};
    float attackAlpha{0.1f};
    float slowAttackAlpha{0.02f};
    float releaseFastAlpha{0.01f};
    float releaseSlowAlpha{0.001f};
    float scAlpha{0.01f};

    float vBiasL{0.0f};
    float vBiasR{0.0f};
    float biasSlowL{0.0f};
    float biasSlowR{0.0f};
    float scHPStateL{0.0f};
    float scHPStateR{0.0f};
    float currentGRL_dB{0.0f};
    float currentGRR_dB{0.0f};

    DCBlocker dcBlockerL;
    DCBlocker dcBlockerR;
};

} // namespace dsp171
