#pragma once
#include <cmath>
#include <algorithm>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// RetuneFilter
// Filtro avanzato di velocità di correzione vocale con doppio stadio
// conforme all'architettura di Waves Tune Real-Time & Antares Auto-Tune:
// 
// 1. Separazione ortogonale tra "Retune Speed" (tenuta del sustain) e "Note Transition" (glide).
// 2. Tolerance Deadband (Cents & Time) calcolata rispetto alla nota precedente per eliminare trap e glitch.
// 3. Natural Vibrato Tracking Engine (~5.8 Hz bandpass) con Vibrato Depth [0..200%].
// 4. Correction Limit (Cents): soglia oltre la quale la correzione non forza il salto.
// 5. Tracking esponenziale continuo su intra-note sustain (senza azzeramenti di fase casuali)
//    e Polinomio Quintico Smootherstep C^2: S(u) = 6u^5 - 15u^4 + 10u^3 per glide inter-note.
// =============================================================================
class RetuneFilter {
public:
    RetuneFilter() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        invSr = 1.0f / sr;
        updateTransitionDuration();
        updateVibratoFilter();
        smoothedCenterCents = 0.0f;
        reset();
    }

    void reset() noexcept {
        currentPitchRatio = 1.0f;
        targetPitchRatio = 1.0f;
        smoothedRatio = 1.0f;
        
        lastNoteMidi = -1;
        toleranceTimerSamples = 0;
        noteSustainSamples = 0;

        isGliding = false;
        glidePhase = 1.0f;
        glidePhaseStep = 1.0f;
        glideStartRatio = 1.0f;
        
        vibS1 = 0.0;
        vibS2 = 0.0;
        vibratoExtracted = 0.0f;
        smoothedCenterCents = 0.0f;
    }

    // Classic Mode (Auto-Tune 5): snap aggressivo istantaneo senza smootherstep
    void setClassicMode(bool enabled) noexcept {
        classicMode = enabled;
        if (enabled) {
            isGliding = false;
        }
    }

    [[nodiscard]] bool isClassicMode() const noexcept { return classicMode; }

    // Flex-Tune [0% .. 100%]: ritira la correzione quando il cantante si allontana dalla nota
    void setFlexTune(float flexPercent) noexcept {
        flexTune = std::clamp(flexPercent, 0.0f, 100.0f);
    }

    [[nodiscard]] float getFlexTune() const noexcept { return flexTune; }

    // Humanize [0% .. 100%]: permette correzione veloce sui passaggi rapidi e rilassa il retune sulle note tenute
    void setHumanize(float humanizePercent) noexcept {
        humanize = std::clamp(humanizePercent, 0.0f, 100.0f);
    }

    [[nodiscard]] float getHumanize() const noexcept { return humanize; }

    // Speed: tempo di correzione su nota sostenuta [0.0 .. 800 ms] (Default: 15 ms, 0.0 ms = Hard-Tune istantaneo)
    void setRetuneSpeedMs(float speedMs) noexcept {
        retuneSpeedMs = std::clamp(speedMs, 0.0f, 800.0f);
    }

    // Note Transition: tempo di glissando tra due note distinte [0.0 .. 800 ms] (Default: 120 ms)
    void setNoteTransitionMs(float transMs) noexcept {
        noteTransitionMs = std::clamp(transMs, 0.0f, 800.0f);
        updateTransitionDuration();
    }

    // Tolerance Cents [0 .. 40 cents]: allarga la zona morta oltre i +/-50 cents prima del cambio nota
    // Tolerance Time [0 .. 300 ms]: tempo minimo di permanenza fuori soglia per confermare il cambio nota
    void setTolerance(float cents, float timeMs) noexcept {
        toleranceCents = std::clamp(cents, 0.0f, 40.0f);
        toleranceTimeMs = std::clamp(timeMs, 0.0f, 300.0f);
        toleranceMaxSamples = static_cast<uint32_t>(toleranceTimeMs * 0.001f * sr);
    }

    // Vibrato On/Off e Vibrato Depth [0% .. 200%] (Default: On, 100%)
    void setVibrato(bool enabled, float depthPercent = 100.0f) noexcept {
        vibratoEnabled = enabled;
        vibratoDepth = std::clamp(depthPercent * 0.01f, 0.0f, 2.0f);
    }

    // Correction Limit [50 .. 600 cents]: oltre questo scarto la nota non viene forzata
    void setCorrectionLimitCents(float limitCents) noexcept {
        correctionLimitCents = std::clamp(limitCents, 50.0f, 600.0f);
    }

    // Intensità della correzione / Depth [0.0 .. 1.0] (1.0 = 100% accordato)
    void setAmount(float amt) noexcept {
        amount = std::clamp(amt, 0.0f, 1.0f);
    }

    void setDepth(float depth) noexcept {
        setAmount(depth);
    }

    [[nodiscard]] float getDepth() const noexcept { return amount; }

    // Elabora un singolo campione di rapporto di pitch
    inline float processSample(float rawRatio, float centsOffset = 0.0f, int targetMidiNote = -1) noexcept {
        // Se centsOffset eccede il limite di correzione, attenua con taper continuo (solo in modalità scala, mai in MIDI)
        if (targetMidiNote < 0 && std::abs(centsOffset) > correctionLimitCents) {
            const float excess = std::abs(centsOffset) - correctionLimitCents;
            constexpr float softKneeCents = 50.0f;
            if (excess >= softKneeCents) {
                centsOffset = 0.0f;
                rawRatio = 1.0f;
            } else {
                const float taper = 0.5f * (1.0f + std::cos(PI * excess / softKneeCents));
                centsOffset *= taper;
            }
        }

        // 1. Modulazione di base della deviazione in cents
        float effectiveCents = centsOffset;
        if (std::abs(effectiveCents) < 1e-6f && std::abs(rawRatio - 1.0f) > 1e-6f) {
            effectiveCents = 1200.0f * std::log2(std::max(0.01f, rawRatio));
        }

        // 2. Gestione Deadband e Conferma Cambio Nota (Note Transition Trigger)
        bool isInitialNote = false;
        bool isNoteTransition = false;
        if (targetMidiNote >= 0) {
            if (lastNoteMidi < 0) {
                // Prima nota rilevata
                lastNoteMidi = targetMidiNote;
                noteSustainSamples = 0;
                toleranceTimerSamples = 0;
                smoothedCenterCents = effectiveCents;
                isInitialNote = true;
            } else if (targetMidiNote != lastNoteMidi) {
                // Se la tolleranza è attiva (> 0), controlla se mantenere la nota precedente
                const float distFromPrevCents = std::abs(static_cast<float>(targetMidiNote - lastNoteMidi) * 100.0f - effectiveCents);
                const float leaveThreshold = 50.0f + toleranceCents;

                if (toleranceCents > 0.1f && distFromPrevCents < leaveThreshold) {
                    // Rimani sulla nota precedente ricalcolando effectiveCents relativo alla nota precedente
                    const float noteDiffCents = static_cast<float>(targetMidiNote - lastNoteMidi) * 100.0f;
                    effectiveCents -= noteDiffCents;
                    noteSustainSamples++;
                    toleranceTimerSamples = 0;
                } else if (toleranceTimeMs > 0.1f && distFromPrevCents < leaveThreshold && toleranceTimerSamples < toleranceMaxSamples) {
                    // Timer di tolleranza temporale ancora in corso (solo se entro leaveThreshold)
                    toleranceTimerSamples++;
                    const float noteDiffCents = static_cast<float>(targetMidiNote - lastNoteMidi) * 100.0f;
                    effectiveCents -= noteDiffCents;
                    noteSustainSamples++;
                } else {
                    // Cambio nota confermato tra due note distinte!
                    lastNoteMidi = targetMidiNote;
                    toleranceTimerSamples = 0;
                    noteSustainSamples = 0;
                    smoothedCenterCents = effectiveCents;
                    isNoteTransition = true;
                }
            } else {
                noteSustainSamples++;
                toleranceTimerSamples = 0;
                smoothedCenterCents += 0.001f * (effectiveCents - smoothedCenterCents);
            }
        }

        // Tolerance Deadband (Waves Tune RT): preserva il micro-vibrato e le articolazioni naturali entro +/- toleranceCents
        // NOTA ARCHITETTURALE: Humanize gestisce la distensione della costante di tempo tau sulle note tenute (linee 274-282),
        // NON deve MAI sottrarre centesimi di intonazione statica, altrimenti rende tutte le note calanti (-7.5 cents con Humanize al 25%)!
        const float deadband = toleranceCents;
        if (deadband > 0.05f) {
            if (std::abs(effectiveCents) <= deadband) {
                effectiveCents = 0.0f; // Entro il deadband naturale: passa intatto (target = 1.0)
            } else {
                effectiveCents = (effectiveCents > 0.0f) 
                               ? (effectiveCents - deadband)
                               : (effectiveCents + deadband);
            }
        }

        // Antares Flex-Tune: attenua la correzione man mano che la voce si allontana dal centro nota
        if (flexTune > 0.1f && std::abs(effectiveCents) > 0.01f) {
            const float dist = std::min(50.0f, std::abs(effectiveCents));
            const float wFlex = 0.5f * (1.0f + std::cos(PI * dist / 50.0f));
            const float blend = 1.0f - (1.0f - wFlex) * (flexTune * 0.01f);
            effectiveCents *= blend;
        }

        // Estrazione e preservazione del vibrato naturale vocale (~5.8 Hz bandpass)
        // vibratoDepth: 0.0 (0% = intonazione fissa robotica, vibrato rimosso)
        //               1.0 (100% = vibrato naturale del cantante interamente preservato attorno alla nota target)
        if (vibratoEnabled && vibratoDepth > 0.01f) {
            if (!isGliding && noteSustainSamples > static_cast<uint32_t>(0.10f * sr)) {
                const double x = static_cast<double>(effectiveCents - smoothedCenterCents);
                const double bp = vibB0 * x + vibS1;
                vibS1 = vibB1 * x - vibA1 * bp + vibS2;
                vibS2 = vibB2 * x - vibA2 * bp;
                if (std::abs(vibS1) < 1.0e-25) vibS1 = 0.0;
                if (std::abs(vibS2) < 1.0e-25) vibS2 = 0.0;
                vibratoExtracted = static_cast<float>(bp);

                // Sottraendo la componente di vibrato dall'errore di correzione,
                // il vibrato naturale della voce viene preservato attorno al centro nota
                const float vibratoKeep = std::clamp(vibratoDepth, 0.0f, 1.0f);
                effectiveCents -= vibratoExtracted * vibratoKeep;
            } else {
                vibratoExtracted = 0.0f;
                vibS1 = 0.0; vibS2 = 0.0;
            }
        } else {
            vibratoExtracted = 0.0f;
            vibS1 = 0.0; vibS2 = 0.0;
        }

        // Applicazione Amount (Depth [0..1])
        effectiveCents *= amount;

        // Calcolo del ratio target effettivo (amount=0 -> effectiveCents=0 -> target=1.0)
        const float effectiveTarget = std::pow(2.0f, effectiveCents / 1200.0f);

        // Se prima nota rilevata
        if (isInitialNote) {
            if (classicMode) {
                // Classic Mode (Auto-Tune 5): snap immediato al target sul primissimo campione
                isGliding = false;
                currentPitchRatio = effectiveTarget;
                targetPitchRatio = effectiveTarget;
                smoothedRatio = effectiveTarget;
                return smoothedRatio;
            }
            // In Modern Mode: l'onset iniziale non è una transizione tra note; segue retuneSpeedMs (Hard-Tune se <= 0.05ms)
        } else if (isNoteTransition) {
            if (classicMode) {
                // Classic Mode (Auto-Tune 5): snap aggressivo istantaneo a 0 ms senza glide
                isGliding = false;
                currentPitchRatio = effectiveTarget;
                targetPitchRatio = effectiveTarget;
                smoothedRatio = effectiveTarget;
                return smoothedRatio;
            } else {
                // Modern Mode: glide S-Curve quintico C^2 controllato da noteTransitionMs
                const float effectiveTransMs = (noteTransitionMs <= 0.5f)
                    ? 1.2f
                    : noteTransitionMs;

                if (effectiveTransMs > 0.1f) {
                    isGliding = true;
                    glidePhase = 0.0f;
                    glideStartRatio = currentPitchRatio;
                    const float transSamples = std::max(1.0f, effectiveTransMs * 0.001f * sr);
                    glidePhaseStep = 1.0f / transSamples;
                } else {
                    isGliding = false;
                }
            }
        } else if (targetMidiNote < 0 && std::abs(effectiveTarget - targetPitchRatio) > 0.001f && !isGliding && retuneSpeedMs > 0.05f) {
            if (classicMode) {
                isGliding = false;
                currentPitchRatio = effectiveTarget;
                targetPitchRatio = effectiveTarget;
                smoothedRatio = effectiveTarget;
                return smoothedRatio;
            } else {
                isGliding = true;
                glidePhase = 0.0f;
                glideStartRatio = currentPitchRatio;
                const float transSamples = std::max(1.0f, retuneSpeedMs * 0.001f * sr);
                glidePhaseStep = 1.0f / transSamples;
            }
        }

        // 3. Se è attivo un glide tra note distinte (Note Transition Smootherstep C^2)
        if (isGliding) {
            glidePhase += glidePhaseStep;
            if (glidePhase >= 1.0f) {
                glidePhase = 1.0f;
                isGliding = false;
                currentPitchRatio = effectiveTarget;
            } else {
                const float u = glidePhase;
                // Polinomio quintico smootherstep C^2: S(u) = u^3 * (10 - 15u + 6u^2)
                const float sCurve = u * u * u * (u * (u * 6.0f - 15.0f) + 10.0f);
                currentPitchRatio = glideStartRatio + (effectiveTarget - glideStartRatio) * sCurve;
            }
            targetPitchRatio = effectiveTarget;
            smoothedRatio = currentPitchRatio;
            return smoothedRatio;
        }

        // 4. Hard-Tune a 0 ms: snap istantaneo intra-nota
        if (retuneSpeedMs <= 0.05f) {
            currentPitchRatio = effectiveTarget;
            targetPitchRatio = effectiveTarget;
            smoothedRatio = effectiveTarget;
            return smoothedRatio;
        }

        // 5. Intra-note Sustain Tracking continuo con Humanize
        float effectiveSpeedMs = classicMode ? (retuneSpeedMs * 0.70f) : retuneSpeedMs;
        if (humanize > 0.1f) {
            const float sustainSec = static_cast<float>(noteSustainSamples) * invSr;
            if (sustainSec > 0.18f) {
                const float relax = (1.0f - std::exp(-(sustainSec - 0.18f) / 0.20f)) * (humanize * 0.01f);
                effectiveSpeedMs = effectiveSpeedMs + relax * (std::max(120.0f, effectiveSpeedMs) - effectiveSpeedMs);
            }
        }

        // Inseguimento esponenziale continuo garantito real-time safe (tau = effectiveSpeedMs * 0.001 s)
        const float tau = std::max(0.0001f, effectiveSpeedMs * 0.001f);
        const float alpha = std::clamp(1.0f - std::exp(-invSr / tau), 0.0001f, 1.0f);
        currentPitchRatio += alpha * (effectiveTarget - currentPitchRatio);

        targetPitchRatio = effectiveTarget;
        smoothedRatio = currentPitchRatio;
        return smoothedRatio;
    }

    void processBlock(const float* rawRatios, float* outSmoothedRatios, size_t numSamples) noexcept {
        for (size_t i = 0; i < numSamples; ++i) {
            outSmoothedRatios[i] = processSample(rawRatios[i]);
        }
    }

    [[nodiscard]] float getCurrentRatio() const noexcept { return smoothedRatio; }
    [[nodiscard]] float getRetuneSpeedMs() const noexcept { return retuneSpeedMs; }
    [[nodiscard]] float getNoteTransitionMs() const noexcept { return noteTransitionMs; }
    [[nodiscard]] float getAmount() const noexcept { return amount; }
    [[nodiscard]] int getActiveNoteMidi() const noexcept { return lastNoteMidi; }
    [[nodiscard]] bool isGlidingActive() const noexcept { return isGliding; }

private:
    void updateTransitionDuration() noexcept {
        const float transSamples = std::max(1.0f, noteTransitionMs * 0.001f * sr);
        glidePhaseStep = 1.0f / transSamples;
    }

    void updateVibratoFilter() noexcept {
        // Biquad bandpass a 5.8 Hz con Q = 0.707 calcolato a 64-bit per stabilità incondizionata
        const double fc = 5.8;
        const double Q = 0.707;
        const double w0 = 2.0 * PI_D * fc / static_cast<double>(sr);
        const double alpha = std::sin(w0) / (2.0 * Q);
        const double a0 = 1.0 + alpha;

        vibB0 = alpha / a0;
        vibB1 = 0.0;
        vibB2 = -alpha / a0;
        vibA1 = (-2.0 * std::cos(w0)) / a0;
        vibA2 = (1.0 - alpha) / a0;
    }

    float sr = 48000.0f;
    float invSr = 1.0f / 48000.0f;

    // Parametri
    float retuneSpeedMs = 15.0f;      // Waves default: 15 ms
    float noteTransitionMs = 120.0f;  // Waves default: 120 ms
    float toleranceCents = 0.0f;      // 0..40 cents
    float toleranceTimeMs = 0.0f;     // 0..300 ms
    uint32_t toleranceMaxSamples = 0;
    uint32_t toleranceTimerSamples = 0;
    int lastNoteMidi = -1;

    bool vibratoEnabled = true;       // Waves default: On
    float vibratoDepth = 1.0f;        // 100% natural
    float correctionLimitCents = 600.0f; // Waves default: 600 cents
    float amount = 1.0f;
    float humanize = 0.0f;

    bool classicMode = false;
    float flexTune = 0.0f;
    uint32_t noteSustainSamples = 0;

    // Filtro IIR Bandpass per Vibrato (coefficienti e stati a doppia precisione per stabilità @ 5.8 Hz)
    double vibB0{0.0}, vibB1{0.0}, vibB2{0.0}, vibA1{0.0}, vibA2{0.0};
    double vibS1{0.0}, vibS2{0.0};
    float vibratoExtracted{0.0f};
    float smoothedCenterCents{0.0f};

    // Dinamica Glide inter-note e tracking continuo
    bool isGliding = false;
    float glidePhase = 1.0f;
    float glidePhaseStep = 1.0f;
    float glideStartRatio = 1.0f;
    float currentPitchRatio = 1.0f;
    float targetPitchRatio = 1.0f;
    float smoothedRatio = 1.0f;
};

} // namespace dsp171
