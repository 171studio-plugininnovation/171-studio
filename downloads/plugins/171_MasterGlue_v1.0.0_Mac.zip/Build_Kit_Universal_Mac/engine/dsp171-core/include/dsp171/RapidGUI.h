#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_graphics/juce_graphics.h>
#include <vector>
#include <memory>
#include <functional>
#include <cmath>

namespace plugin_171
{
    // ==============================================================================
    // ENUMS & STYLES
    // ==============================================================================
    enum class ChassisTheme
    {
        VintageDarkBronze,
        BrushedGunmetal,
        MasteringObsidian,
        ClassicBritishMaroon
    };

    enum class KnobStyle
    {
        TeardropBronze,
        NeveMarconiRed,
        NeveMarconiBlue,
        APIAirconKnurled,
        LA2ABakeliteScalloped,
        ChickenHeadSelector,
        PrecisionGunmetalKnurled
    };

    enum class ScaleDialType
    {
        None,
        Percent0To100,
        Frequency20To20k,
        DecibelsMinusInfPlus12,
        Detented11Positions,
        DetentedCenterZero
    };

    enum class VUDialStyle
    {
        VU_Gain,
        GainReduction
    };

    enum class PointerStyle
    {
        ClassicNeedle,
        RadioSweeperWand
    };

    enum class SwitchStyle
    {
        HeavyDutyChromeBaton,
        BoutiqueBrassToggle,
        RockerPowerNeonRuby,
        SquareConsoleSoloAmber
    };

    // ==============================================================================
    // 1. RAPID KNOB COMPONENT
    // ==============================================================================
    class RapidKnob : public juce::Slider
    {
    public:
        RapidKnob(const juce::String& labelText = "", 
                  KnobStyle kStyle = KnobStyle::TeardropBronze,
                  ScaleDialType sStyle = ScaleDialType::Percent0To100)
            : label(labelText), knobStyle(kStyle), scaleStyle(sStyle)
        {
            setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
            setAngleRange(-145.0f, 145.0f);
            setColour(juce::Slider::rotarySliderFillColourId, juce::Colour(0xffd89f3c));
        }

        void setAngleRange(float minDegrees, float maxDegrees)
        {
            minAngleRad = juce::degreesToRadians(minDegrees);
            maxAngleRad = juce::degreesToRadians(maxDegrees);
        }

        void setCustomImages(const juce::Image& knob, const juce::Image& scale = juce::Image(), const juce::Image& collar = juce::Image())
        {
            knobImg = knob;
            scaleImg = scale;
            collarImg = collar;
            repaint();
        }

        void setKnobScaleRatio(float ratio) { knobScaleRatio = juce::jlimit(0.3f, 1.0f, ratio); repaint(); }
        void setLabel(const juce::String& newLabel) { label = newLabel; repaint(); }
        void setScaleType(ScaleDialType type) { scaleStyle = type; repaint(); }
        void setShowValue(bool show) { showValue = show; repaint(); }
        void setShowLabel(bool show) { showLabel = show; repaint(); }
        void setLedColour(juce::Colour c) { ledColour = c; repaint(); }
        void setShowLedTrack(bool show) { showLedTrack = show; repaint(); }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float labelHeight = showLabel ? 18.0f : 0.0f;
            const float valueHeight = showValue ? 14.0f : 0.0f;
            auto knobArea = bounds.withTrimmedBottom(labelHeight + valueHeight).reduced(2.0f);

            const float size = juce::jmin(knobArea.getWidth(), knobArea.getHeight());
            const float cx = knobArea.getCentreX();
            const float cy = knobArea.getCentreY();
            auto dialRect = knobArea.withSizeKeepingCentre(size, size);

            const float norm = (float)(getValue() - getMinimum()) / (float)(getMaximum() - getMinimum());
            const float angle = minAngleRad + norm * (maxAngleRad - minAngleRad);

            // 0. Draw Optional Knurled Collar Ring
            if (collarImg.isValid())
            {
                g.drawImage(collarImg, dialRect, juce::RectanglePlacement::centred);
            }

            // 1. Draw Scale Ring (Stationary background dial / plate)
            if (scaleImg.isValid())
            {
                g.drawImage(scaleImg, dialRect, juce::RectanglePlacement::centred);
            }
            else if (scaleStyle != ScaleDialType::None)
            {
                drawProceduralScale(g, cx, cy, size * 0.48f);
            }

            const float knobSize = size * knobScaleRatio;
            auto knobRect = knobArea.withSizeKeepingCentre(knobSize, knobSize);

            // 2. Draw Illuminated LED Track around the knob perimeter
            if (showLedTrack)
            {
                const float ledR = knobSize * 0.52f + 2.5f;
                juce::Path bgArc;
                bgArc.addCentredArc(cx, cy, ledR, ledR, 0.0f, minAngleRad, maxAngleRad, true);
                g.setColour(juce::Colour(0x28383020));
                g.strokePath(bgArc, juce::PathStrokeType(2.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

                if (norm > 0.005f)
                {
                    juce::Path activeArc;
                    activeArc.addCentredArc(cx, cy, ledR, ledR, 0.0f, minAngleRad, angle, true);

                    // Outer luminous halo
                    g.setColour(ledColour.withAlpha(0.25f));
                    g.strokePath(activeArc, juce::PathStrokeType(6.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

                    // Core bright track
                    g.setColour(ledColour.withAlpha(0.85f));
                    g.strokePath(activeArc, juce::PathStrokeType(3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

                    // Inner bright specular
                    g.setColour(juce::Colours::white.interpolatedWith(ledColour, 0.5f));
                    g.strokePath(activeArc, juce::PathStrokeType(1.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

                    // Tip LED bead at pointer position
                    float tipX = cx + std::sin(angle) * ledR;
                    float tipY = cy - std::cos(angle) * ledR;
                    g.setColour(ledColour.withAlpha(0.6f));
                    g.fillEllipse(tipX - 4.5f, tipY - 4.5f, 9.0f, 9.0f);
                    g.setColour(juce::Colours::white);
                    g.fillEllipse(tipX - 2.0f, tipY - 2.0f, 4.0f, 4.0f);
                }
            }

            if (knobImg.isValid())
            {
                juce::Graphics::ScopedSaveState state(g);
                g.addTransform(juce::AffineTransform::rotation(angle, cx, cy));
                g.drawImage(knobImg, knobRect, juce::RectanglePlacement::centred);
            }
            else
            {
                drawProceduralKnob(g, cx, cy, knobSize * 0.5f, angle);
            }

            // 3. Draw Serigraphic Parameter Label (High contrast bold gold)
            if (showLabel && label.isNotEmpty())
            {
                auto labelRect = juce::Rectangle<float>(bounds.getX(), bounds.getBottom() - labelHeight - valueHeight, bounds.getWidth(), labelHeight);
                g.setColour(juce::Colour(0xffffdf80));
                g.setFont(juce::FontOptions(12.0f, juce::Font::bold));
                g.drawText(label, labelRect, juce::Justification::centred, false);
            }

            // 4. Draw Parameter Value readout (Crisp high-definition text)
            if (showValue)
            {
                auto valueRect = juce::Rectangle<float>(bounds.getX(), bounds.getBottom() - valueHeight, bounds.getWidth(), valueHeight);
                g.setColour(juce::Colour(0xfff1f5f9));
                g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
                g.drawText(getTextFromValue(getValue()), valueRect, juce::Justification::centred, false);
            }
        }

    private:
        void drawProceduralScale(juce::Graphics& g, float cx, float cy, float radius)
        {
            const int numTicks = (scaleStyle == ScaleDialType::Detented11Positions) ? 11 : 21;
            for (int i = 0; i < numTicks; ++i)
            {
                float tNorm = (float)i / (float)(numTicks - 1);
                float a = minAngleRad + tNorm * (maxAngleRad - minAngleRad) - juce::MathConstants<float>::halfPi;
                float rInner = (i % 2 == 0) ? radius - 6.0f : radius - 3.5f;
                float rOuter = radius;

                float x1 = cx + std::cos(a) * rInner;
                float y1 = cy + std::sin(a) * rInner;
                float x2 = cx + std::cos(a) * rOuter;
                float y2 = cy + std::sin(a) * rOuter;

                bool isMajor = (i % 2 == 0);
                g.setColour(isMajor ? juce::Colour(0xffc59c52) : juce::Colour(0x88735c3a));
                g.drawLine(x1, y1, x2, y2, isMajor ? 1.4f : 1.0f);
            }
        }

        void drawProceduralKnob(juce::Graphics& g, float cx, float cy, float radius, float angle)
        {
            // Machined Bronze/Gunmetal cylindrical base
            juce::ColourGradient grad(juce::Colour(0xff3a352d), cx - radius, cy - radius,
                                     juce::Colour(0xff161411), cx + radius, cy + radius, true);
            g.setGradientFill(grad);
            g.fillEllipse(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f);

            // Beveled brass rim
            g.setColour(juce::Colour(0xffd89f3c).withAlpha(0.7f));
            g.drawEllipse(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f, 1.5f);

            // Top cap
            float innerR = radius * 0.78f;
            g.setColour(juce::Colour(0xff121214));
            g.fillEllipse(cx - innerR, cy - innerR, innerR * 2.0f, innerR * 2.0f);

            // Indicator notch
            juce::Graphics::ScopedSaveState state(g);
            g.addTransform(juce::AffineTransform::rotation(angle, cx, cy));
            g.setColour(juce::Colour(0xffffa726));
            g.drawLine(cx, cy - innerR, cx, cy - radius * 0.35f, 2.4f);
        }

        juce::String label;
        KnobStyle knobStyle;
        ScaleDialType scaleStyle;
        float minAngleRad = -juce::MathConstants<float>::pi * 0.80f;
        float maxAngleRad =  juce::MathConstants<float>::pi * 0.80f;
        float knobScaleRatio = 0.68f;
        bool showLabel = false;
        bool showValue = false;
        bool showLedTrack = true;
        juce::Colour ledColour { 0xffd89f3c };
        juce::Image knobImg;
        juce::Image scaleImg;
        juce::Image collarImg;
    };

    // ==============================================================================
    // 1B. RAPID DUAL-CONCENTRIC NEVE 1073 EQ KNOB (Frequency Outer + Gain Inner)
    // ==============================================================================
    class RapidDualConcentricKnob : public juce::Component
    {
    public:
        enum class BandType { LowShelf, MidPeak };

        RapidDualConcentricKnob(BandType type = BandType::LowShelf)
            : bandType(type)
        {
            setOpaque(false);

            gainSlider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            gainSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
            gainSlider.setRange(type == BandType::LowShelf ? -16.0 : -18.0,
                                type == BandType::LowShelf ?  16.0 :  18.0, 0.1);
            gainSlider.setValue(0.0);
            gainSlider.onValueChange = [this]() { repaint(); };
            addChildComponent(gainSlider);

            freqSlider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            freqSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
            freqSlider.setRange(0.0, type == BandType::LowShelf ? 4.0 : 6.0, 1.0);
            freqSlider.setValue(0.0);
            freqSlider.onValueChange = [this]() { repaint(); };
            addChildComponent(freqSlider);
        }

        juce::Slider& getGainSlider() { return gainSlider; }
        juce::Slider& getFreqSlider() { return freqSlider; }

        void setCustomImages(const juce::Image& innerKnob, const juce::Image& outerRing, const juce::Image& dialPlate)
        {
            innerKnobImg = innerKnob;
            outerRingImg = outerRing;
            dialPlateImg = dialPlate;
            repaint();
        }

        void setLedColour(juce::Colour c) { ledColour = c; repaint(); }

        void mouseDown(const juce::MouseEvent& e) override
        {
            auto bounds = getLocalBounds().toFloat();
            float cx = bounds.getCentreX();
            float cy = bounds.getCentreY();
            float dist = e.position.getDistanceFrom({cx, cy});
            float knobRadius = juce::jmin(bounds.getWidth(), bounds.getHeight()) * 0.5f;

            if (dist < knobRadius * 0.36f)
            {
                isDraggingGain = true;
                gainDragStartVal = (float)gainSlider.getValue();
                gainDragStartPos = e.position;
            }
            else
            {
                isDraggingGain = false;
                updateFreqFromPosition(e.position, cx, cy);
            }
        }

        void mouseDrag(const juce::MouseEvent& e) override
        {
            if (isDraggingGain)
            {
                float dy = gainDragStartPos.y - e.position.y;
                float range = (float)(gainSlider.getMaximum() - gainSlider.getMinimum());
                float newVal = gainDragStartVal + (dy / 100.0f) * range;
                gainSlider.setValue(juce::jlimit((float)gainSlider.getMinimum(), (float)gainSlider.getMaximum(), newVal),
                                    juce::sendNotificationAsync);
            }
            else
            {
                auto bounds = getLocalBounds().toFloat();
                updateFreqFromPosition(e.position, bounds.getCentreX(), bounds.getCentreY());
            }
        }

        void mouseWheelMove(const juce::MouseEvent& e, const juce::MouseWheelDetails& wheel) override
        {
            auto bounds = getLocalBounds().toFloat();
            float dist = e.position.getDistanceFrom({bounds.getCentreX(), bounds.getCentreY()});
            float knobRadius = juce::jmin(bounds.getWidth(), bounds.getHeight()) * 0.5f;

            if (dist < knobRadius * 0.36f)
            {
                float step = (wheel.deltaY > 0.0f ? 0.5f : -0.5f);
                gainSlider.setValue(gainSlider.getValue() + step, juce::sendNotificationAsync);
            }
            else
            {
                float step = (wheel.deltaY > 0.0f ? 1.0f : -1.0f);
                freqSlider.setValue(freqSlider.getValue() + step, juce::sendNotificationAsync);
            }
        }

        void paint(juce::Graphics& g) override
        {
            auto bounds = getLocalBounds().toFloat().reduced(2.0f);
            const float size = juce::jmin(bounds.getWidth(), bounds.getHeight());
            const float cx = bounds.getCentreX();
            const float cy = bounds.getCentreY();
            auto dialRect = bounds.withSizeKeepingCentre(size, size);

            // 1. Draw Stationary Dial Plate (Doppio Cerchio Frequenze & Gain ad Alto Contrasto)
            if (dialPlateImg.isValid())
            {
                g.drawImage(dialPlateImg, dialRect, juce::RectanglePlacement::centred);
            }

            // 2. Draw Outer Knurled Ring (Rotated to Frequency step)
            int step = (int)freqSlider.getValue();
            float freqAngleRad = getAngleForStep(step);

            const float ringSize = size * 0.40f;
            auto ringRect = bounds.withSizeKeepingCentre(ringSize, ringSize);

            if (outerRingImg.isValid())
            {
                juce::Graphics::ScopedSaveState state(g);
                g.addTransform(juce::AffineTransform::rotation(freqAngleRad, cx, cy));
                g.drawImage(outerRingImg, ringRect, juce::RectanglePlacement::centred);
            }

            // 3. Draw Illuminated LED Track for Gain
            float minGain = (float)gainSlider.getMinimum();
            float maxGain = (float)gainSlider.getMaximum();
            float gainNorm = (float)(gainSlider.getValue() - minGain) / (maxGain - minGain);
            float gainAngleRad = juce::degreesToRadians(-140.0f + gainNorm * 280.0f);

            const float knobSize = size * 0.24f;
            const float ledR = knobSize * 0.52f + 2.0f;

            juce::Path bgArc;
            bgArc.addCentredArc(cx, cy, ledR, ledR, 0.0f,
                                juce::degreesToRadians(-140.0f), juce::degreesToRadians(140.0f), true);
            g.setColour(juce::Colour(0x30383020));
            g.strokePath(bgArc, juce::PathStrokeType(2.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            if (gainNorm > 0.005f)
            {
                juce::Path activeArc;
                activeArc.addCentredArc(cx, cy, ledR, ledR, 0.0f,
                                        juce::degreesToRadians(-140.0f), gainAngleRad, true);

                g.setColour(ledColour.withAlpha(0.25f));
                g.strokePath(activeArc, juce::PathStrokeType(6.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

                g.setColour(ledColour.withAlpha(0.85f));
                g.strokePath(activeArc, juce::PathStrokeType(3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

                g.setColour(juce::Colours::white.interpolatedWith(ledColour, 0.5f));
                g.strokePath(activeArc, juce::PathStrokeType(1.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

                float tipX = cx + std::sin(gainAngleRad) * ledR;
                float tipY = cy - std::cos(gainAngleRad) * ledR;
                g.setColour(ledColour.withAlpha(0.6f));
                g.fillEllipse(tipX - 4.0f, tipY - 4.0f, 8.0f, 8.0f);
                g.setColour(juce::Colours::white);
                g.fillEllipse(tipX - 2.0f, tipY - 2.0f, 4.0f, 4.0f);
            }

            // 4. Draw Central Winged Chicken-Head Knob (Rotated by Gain Angle)
            auto knobRect = bounds.withSizeKeepingCentre(knobSize, knobSize);

            if (innerKnobImg.isValid())
            {
                juce::Graphics::ScopedSaveState state(g);
                g.addTransform(juce::AffineTransform::rotation(gainAngleRad, cx, cy));
                g.drawImage(innerKnobImg, knobRect, juce::RectanglePlacement::centred);
            }

            // 5. Spia Luminosa Attiva sul Passo Frequenza Selezionato (Esatta Correlazione sul Cerchio Esterno)
            if (step >= 0)
            {
                float a = getAngleForStep(step) - juce::MathConstants<float>::halfPi;
                const float pipR = size * 0.5f * 0.74f;
                float px = cx + std::cos(a) * pipR;
                float py = cy + std::sin(a) * pipR;

                g.setColour(juce::Colour(0x88ffe082));
                g.fillEllipse(px - 7.0f, py - 7.0f, 14.0f, 14.0f);
                g.setColour(juce::Colour(0xffffe082));
                g.fillEllipse(px - 4.5f, py - 4.5f, 9.0f, 9.0f);
                g.setColour(juce::Colours::white);
                g.fillEllipse(px - 2.0f, py - 2.0f, 4.0f, 4.0f);
            }

            // 6. Targhetta Inferiore Telemetrica Integrata con Indicatore di Sezione ad Alta Intelligibilità
            {
                auto pillRect = juce::Rectangle<float>(cx - 64.0f, bounds.getBottom() - 16.5f, 128.0f, 15.0f);
                g.setColour(juce::Colour(0xfa0a0c10));
                g.fillRoundedRectangle(pillRect, 3.5f);
                g.setColour(juce::Colour(0xaad4af37));
                g.drawRoundedRectangle(pillRect, 3.5f, 1.0f);

                const char* const lowFreqs[] = { "OFF", "35 Hz", "60 Hz", "110 Hz", "220 Hz" };
                const char* const midFreqs[] = { "OFF", "360 Hz", "700 Hz", "1.6k", "3.2k", "4.8k", "7.2k" };

                int safeStep = juce::jlimit(0, (bandType == BandType::LowShelf ? 4 : 6), step);
                juce::String bTitle = (bandType == BandType::LowShelf) ? "LOW SHELF : " : "MID PEAK : ";
                juce::String fStr = (bandType == BandType::LowShelf ? lowFreqs[safeStep] : midFreqs[safeStep]);
                float gVal = (float)gainSlider.getValue();
                juce::String gStr = (gVal > 0.05f ? "+" : "") + juce::String(gVal, 1) + " dB";
                juce::String teleStr = fStr + " | " + gStr;

                juce::Font font(juce::FontOptions(9.0f, juce::Font::bold));
                g.setFont(font);

                int titleWidth = font.getStringWidth(bTitle);
                int teleWidth  = font.getStringWidth(teleStr);
                int totalWidth = titleWidth + teleWidth;
                float startX = cx - (float)totalWidth * 0.5f;

                // Title in Warm Vintage Gold
                g.setColour(juce::Colour(0xffffe082));
                g.drawText(bTitle, juce::Rectangle<float>(startX, pillRect.getY(), (float)titleWidth, pillRect.getHeight()),
                           juce::Justification::centredLeft, false);

                // Telemetry in Neon Electric Blue
                g.setColour(safeStep > 0 ? juce::Colour(0xff38bdf8) : juce::Colour(0xff94a3b8));
                g.drawText(teleStr, juce::Rectangle<float>(startX + (float)titleWidth, pillRect.getY(), (float)teleWidth, pillRect.getHeight()),
                           juce::Justification::centredLeft, false);
            }
        }

    private:
        float getAngleForStep(int step) const
        {
            if (bandType == BandType::LowShelf)
            {
                const float angles[] = { -130.0f, -65.0f, 0.0f, 65.0f, 130.0f };
                int idx = juce::jlimit(0, 4, step);
                return juce::degreesToRadians(angles[idx]);
            }
            else
            {
                const float angles[] = { -135.0f, -90.0f, -45.0f, 0.0f, 45.0f, 90.0f, 135.0f };
                int idx = juce::jlimit(0, 6, step);
                return juce::degreesToRadians(angles[idx]);
            }
        }

        void updateFreqFromPosition(juce::Point<float> pos, float cx, float cy)
        {
            float dx = pos.x - cx;
            float dy = pos.y - cy;
            float angleDeg = juce::radiansToDegrees(std::atan2(dx, -dy));

            if (bandType == BandType::LowShelf)
            {
                const float angles[] = { -130.0f, -65.0f, 0.0f, 65.0f, 130.0f };
                int bestIdx = 0;
                float bestDist = 9999.0f;
                for (int i = 0; i < 5; ++i)
                {
                    float d = std::abs(angleDeg - angles[i]);
                    if (d < bestDist) { bestDist = d; bestIdx = i; }
                }
                freqSlider.setValue((double)bestIdx, juce::sendNotificationAsync);
            }
            else
            {
                const float angles[] = { -135.0f, -90.0f, -45.0f, 0.0f, 45.0f, 90.0f, 135.0f };
                int bestIdx = 0;
                float bestDist = 9999.0f;
                for (int i = 0; i < 7; ++i)
                {
                    float d = std::abs(angleDeg - angles[i]);
                    if (d < bestDist) { bestDist = d; bestIdx = i; }
                }
                freqSlider.setValue((double)bestIdx, juce::sendNotificationAsync);
            }
        }

        BandType bandType;
        juce::Slider gainSlider;
        juce::Slider freqSlider;
        juce::Image innerKnobImg;
        juce::Image outerRingImg;
        juce::Image dialPlateImg;
        juce::Colour ledColour { 0xffffb300 };

        bool isDraggingGain = true;
        float gainDragStartVal = 0.0f;
        juce::Point<float> gainDragStartPos;
    };

    // ==============================================================================
    // 2. RAPID CALIBRATED SVG VU METER COMPONENT
    // ==============================================================================
    class RapidVUMeter : public juce::Component, private juce::Timer
    {
    public:
        RapidVUMeter(VUDialStyle dStyle = VUDialStyle::VU_Gain,
                    PointerStyle pStyle = PointerStyle::ClassicNeedle)
            : dialStyle(dStyle), pointerStyle(pStyle)
        {
            setOpaque(false);
            setInterceptsMouseClicks(false, true);
            startTimerHz(60); // 60 FPS ultra-smooth physical movement
        }

        ~RapidVUMeter() override { stopTimer(); }

        void setAssets(const juce::Image& bezel, const juce::Image& dial, 
                       const juce::Image& needle, const juce::Image& sweeper = juce::Image(),
                       const juce::Image& glass = juce::Image())
        {
            bezelImg = bezel;
            dialImg = dial;
            needleImg = needle;
            sweeperImg = sweeper;
            glassImg = glass;
            repaint();
        }

        void bindLevel(std::function<float()> provider) { levelSource = provider; }

        void setDialStyle(VUDialStyle style) { dialStyle = style; repaint(); }
        void setPointerStyle(PointerStyle style) { pointerStyle = style; repaint(); }

        void timerCallback() override
        {
            float targetValue = 0.0f;
            if (levelSource)
                targetValue = juce::jlimit(0.0f, 1.0f, levelSource());

            // Authentic Analog Ballistics (300ms integration & smooth damping)
            const float attackCoeff = 0.28f;
            const float releaseCoeff = 0.08f;
            const float coeff = (targetValue > currentNorm) ? attackCoeff : releaseCoeff;
            currentNorm += (targetValue - currentNorm) * coeff;

            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float w = bounds.getWidth();
            const float h = bounds.getHeight();

            // Calibrated Geometry Constants (from user SVG project)
            const float NORM_PIVOT_X = 541.83f / 1024.0f; // 0.52913
            const float NORM_PIVOT_Y = 510.78f / 765.0f;  // 0.66769
            const float NORM_TIP_LEN = 318.94f / 1024.0f; // 0.31146

            const float pivotX = bounds.getX() + w * NORM_PIVOT_X;
            const float pivotY = bounds.getY() + h * NORM_PIVOT_Y;

            // 1. Dial Face Card (Clean SVG art inside bezel window)
            if (dialImg.isValid())
            {
                g.drawImage(dialImg, bounds, juce::RectanglePlacement::stretchToFit);
            }
            else
            {
                // Procedural vintage meter card
                g.setColour(juce::Colour(0xff221d15));
                g.fillRoundedRectangle(bounds.reduced(10.0f), 8.0f);
            }

            // 2. Pointer Movement (Needle or Radio Sweeper Wand)
            float angleDeg = 0.0f;
            if (dialStyle == VUDialStyle::VU_Gain)
            {
                // VU Scale: 0 (-20 VU) = -29.60 deg, 70% (0 VU) = +12.50 deg, 100% (+3 VU) = +28.20 deg
                if (currentNorm <= 0.70f)
                {
                    float sub = currentNorm / 0.70f;
                    angleDeg = -29.60f + sub * (12.50f - (-29.60f));
                }
                else
                {
                    float sub = (currentNorm - 0.70f) / 0.30f;
                    angleDeg = 12.50f + sub * (28.20f - 12.50f);
                }
            }
            else
            {
                // Gain Reduction Scale: 0 dB Rest = +34.50 deg, -20 dB GR = -26.10 deg
                angleDeg = 34.50f - currentNorm * (34.50f - (-26.10f));
            }

            const float angleRad = juce::degreesToRadians(angleDeg);

            // Draw Pointer (Needle or Radio Sweeper)
            const bool useSweeper = (pointerStyle == PointerStyle::RadioSweeperWand);
            const juce::Image& activePointer = useSweeper ? (sweeperImg.isValid() ? sweeperImg : needleImg) : needleImg;

            if (activePointer.isValid())
            {
                juce::Graphics::ScopedSaveState state(g);
                g.addTransform(juce::AffineTransform::rotation(angleRad, pivotX, pivotY));
                g.drawImage(activePointer, bounds, juce::RectanglePlacement::stretchToFit);
            }
            else
            {
                // Procedural needle fallback
                float tipLen = w * NORM_TIP_LEN;
                float tipX = pivotX + std::sin(angleRad) * tipLen;
                float tipY = pivotY - std::cos(angleRad) * tipLen;

                g.setColour(juce::Colours::black.withAlpha(0.4f));
                g.drawLine(pivotX + 2.0f, pivotY + 2.0f, tipX + 2.0f, tipY + 2.0f, 2.0f);

                g.setColour(useSweeper ? juce::Colour(0xffff2d55) : juce::Colour(0xffe63946));
                g.drawLine(pivotX, pivotY, tipX, tipY, useSweeper ? 3.0f : 1.8f);

                // Brass hub cap
                g.setColour(juce::Colour(0xffc59c52));
                g.fillEllipse(pivotX - 5.0f, pivotY - 5.0f, 10.0f, 10.0f);
            }

            // 3. Bezel Frame Overlay (With exact window cutout)
            if (bezelImg.isValid())
            {
                g.drawImage(bezelImg, bounds, juce::RectanglePlacement::stretchToFit);
            }

            // 4. Glass Reflection Overlay
            if (glassImg.isValid())
            {
                g.drawImage(glassImg, bounds, juce::RectanglePlacement::stretchToFit);
            }
        }

    private:
        VUDialStyle dialStyle;
        PointerStyle pointerStyle;
        float currentNorm = 0.0f;
        std::function<float()> levelSource;

        juce::Image bezelImg;
        juce::Image dialImg;
        juce::Image needleImg;
        juce::Image sweeperImg;
        juce::Image glassImg;
    };

    // ==============================================================================
    // 3. RAPID TOGGLE SWITCH COMPONENT
    // ==============================================================================
    class RapidToggleSwitch : public juce::ToggleButton
    {
    public:
        RapidToggleSwitch(const juce::String& text = "BYPASS", SwitchStyle sStyle = SwitchStyle::HeavyDutyChromeBaton)
            : switchLabel(text), switchStyle(sStyle)
        {
            setClickingTogglesState(true);
        }

        void setCustomImages(const juce::Image& onImg, const juce::Image& offImg)
        {
            upImg = onImg;
            downImg = offImg;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float labelH = switchLabel.isNotEmpty() ? 18.0f : 0.0f;
            auto switchArea = bounds.withTrimmedBottom(labelH).reduced(2.0f);
            const bool isEngaged = getToggleState();

            // 1. Draw 3D Baton Switch Image
            const juce::Image& activeImg = isEngaged ? upImg : downImg;
            if (activeImg.isValid())
            {
                g.drawImage(activeImg, switchArea, juce::RectanglePlacement::centred);
            }
            else
            {
                // Procedural toggle switch
                const float cx = switchArea.getCentreX();
                const float cy = switchArea.getCentreY();
                
                // Hex mounting nut
                g.setColour(juce::Colour(0xff3a3d45));
                g.fillEllipse(cx - 16.0f, cy - 16.0f, 32.0f, 32.0f);
                g.setColour(juce::Colour(0xffc59c52));
                g.drawEllipse(cx - 16.0f, cy - 16.0f, 32.0f, 32.0f, 1.5f);

                // Baton lever
                float leverAngle = isEngaged ? -0.4f : 0.4f;
                float lx = cx + std::sin(leverAngle) * 22.0f;
                float ly = cy - std::cos(leverAngle) * 22.0f;

                g.setColour(juce::Colour(0xffe0e4ea));
                g.drawLine(cx, cy, lx, ly, 4.5f);
                g.fillEllipse(lx - 4.5f, ly - 4.5f, 9.0f, 9.0f);
            }

            // 2. Serigraphic Label
            if (switchLabel.isNotEmpty())
            {
                auto labelRect = bounds.withTop(bounds.getBottom() - labelH);
                g.setColour(isEngaged ? juce::Colour(0xffff4d4d) : juce::Colour(0xffd89f3c));
                g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
                g.drawText(switchLabel, labelRect, juce::Justification::centred, false);
            }
        }

    private:
        juce::String switchLabel;
        SwitchStyle switchStyle;
        juce::Image upImg;
        juce::Image downImg;
    };

    // ==============================================================================
    // 4. RAPID LADDER METER (SPL DE-ESSER GAIN REDUCTION LED BARGRAPH)
    // ==============================================================================
    class RapidLadderMeter : public juce::Component, private juce::Timer
    {
    public:
        RapidLadderMeter(const juce::String& title = "S-REDUCTION (dB)")
            : meterTitle(title)
        {
            setOpaque(false);
            setInterceptsMouseClicks(false, true);
            startTimerHz(60);
        }

        ~RapidLadderMeter() override { stopTimer(); }

        void bindLevel(std::function<float()> provider) { levelSource = provider; }

        void timerCallback() override
        {
            float targetDb = 0.0f;
            if (levelSource)
                targetDb = levelSource(); // e.g. 0 to 18 dB of reduction

            // Ballistics: fast attack, smooth decay
            if (targetDb > currentReductionDb)
                currentReductionDb += (targetDb - currentReductionDb) * 0.45f;
            else
                currentReductionDb += (targetDb - currentReductionDb) * 0.08f;

            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            auto bounds = getLocalBounds().toFloat().reduced(2.0f);
            
            // Dark smoked acrylic window background
            g.setColour(juce::Colour(0xff0a0b0d));
            g.fillRoundedRectangle(bounds, 4.0f);

            // Title
            auto headerArea = bounds.removeFromTop(16.0f);
            g.setColour(juce::Colour(0xffd4af37).withAlpha(0.85f));
            g.setFont(juce::FontOptions(9.5f, juce::Font::bold));
            g.drawText(meterTitle, headerArea, juce::Justification::centred, false);

            // 12 LED segments from -1 dB to -18 dB
            const int numLeds = 12;
            const float ledThresholds[numLeds] = { 1.0f, 2.0f, 3.0f, 4.5f, 6.0f, 7.5f, 9.0f, 11.0f, 13.0f, 15.0f, 16.5f, 18.0f };
            const char* ledLabels[numLeds]     = { "-1", "-2", "-3", "-4", "-6", "-7", "-9", "-11", "-13", "-15", "-16", "-18" };

            auto ledArea = bounds.reduced(4.0f, 2.0f);
            const float ledWidth = (ledArea.getWidth() - (numLeds - 1) * 3.0f) / (float)numLeds;
            const float ledHeight = ledArea.getHeight() - 12.0f;

            for (int i = 0; i < numLeds; ++i)
            {
                auto r = juce::Rectangle<float>(ledArea.getX() + i * (ledWidth + 3.0f), ledArea.getY(), ledWidth, ledHeight);
                bool isActive = (currentReductionDb >= ledThresholds[i]);

                // Colors: Green (-1 to -6), Amber (-7 to -13), Red (-15 to -18)
                juce::Colour activeCol, dimCol;
                if (i < 5)
                {
                    activeCol = juce::Colour(0xff39e75f);
                    dimCol    = juce::Colour(0xff0d2b15);
                }
                else if (i < 9)
                {
                    activeCol = juce::Colour(0xffffb300);
                    dimCol    = juce::Colour(0xff332400);
                }
                else
                {
                    activeCol = juce::Colour(0xffff2d55);
                    dimCol    = juce::Colour(0xff3b0a13);
                }

                if (isActive)
                {
                    // Glowing active LED
                    g.setColour(activeCol.withAlpha(0.35f));
                    g.fillRoundedRectangle(r.expanded(1.5f), 1.5f);
                    g.setColour(activeCol);
                    g.fillRoundedRectangle(r, 1.0f);
                }
                else
                {
                    // Dark inactive LED segment
                    g.setColour(dimCol);
                    g.fillRoundedRectangle(r, 1.0f);
                }

                // Sub-label for major LEDs
                if (i == 0 || i == 4 || i == 8 || i == 11)
                {
                    auto txtRect = juce::Rectangle<float>(r.getX() - 6.0f, r.getBottom() + 1.0f, r.getWidth() + 12.0f, 10.0f);
                    g.setColour(isActive ? juce::Colour(0xffe0e0e0) : juce::Colour(0xff555a64));
                    g.setFont(juce::FontOptions(8.0f));
                    g.drawText(ledLabels[i], txtRect, juce::Justification::centred, false);
                }
            }
        }

    private:
        juce::String meterTitle;
        float currentReductionDb = 0.0f;
        std::function<float()> levelSource;
    };

    // ==============================================================================
    // 5. RAPID DE-ESSING SPECTRAL SCREEN (SIBILANCE CANCELLATION MONITOR)
    // ==============================================================================
    class RapidDeEssingScreen : public juce::Component, private juce::Timer
    {
    public:
        RapidDeEssingScreen()
        {
            setOpaque(false);
            setInterceptsMouseClicks(false, true);
            startTimerHz(60);
        }

        ~RapidDeEssingScreen() override { stopTimer(); }

        void bindData(std::function<float()> reductionSource,
                      std::function<float()> freqSource = nullptr,
                      std::function<bool()> isFemaleSource = nullptr)
        {
            getReduction = reductionSource;
            getFreq = freqSource;
            getIsFemale = isFemaleSource;
        }

        void timerCallback() override
        {
            float targetDb = 0.0f;
            if (getReduction)
                targetDb = getReduction();

            // Ballistics: fast attack, smooth decay
            if (targetDb > smoothedReductionDb)
                smoothedReductionDb += (targetDb - smoothedReductionDb) * 0.40f;
            else
                smoothedReductionDb += (targetDb - smoothedReductionDb) * 0.08f;

            if (getFreq)
                targetFreqHz = getFreq();

            if (getIsFemale)
                isFemaleMode = getIsFemale();

            phaseWave += 0.07f;
            if (phaseWave > juce::MathConstants<float>::twoPi)
                phaseWave -= juce::MathConstants<float>::twoPi;

            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            auto bounds = getLocalBounds().toFloat().reduced(2.0f);
            const float w = bounds.getWidth();
            const float h = bounds.getHeight();

            // 1. CRT Dark Glass Background
            g.setColour(juce::Colour(0xd4080a0e));
            g.fillRoundedRectangle(bounds, 4.0f);

            // 2. High-Frequency Grid (3 kHz to 16 kHz)
            g.setColour(juce::Colour(0x18c59c52));
            const float freqs[] = { 4000.0f, 6000.0f, 8000.0f, 10000.0f, 14000.0f };
            const char* fLabels[] = { "4k", "6k", "8k", "10k", "14k" };
            const float fMin = 3000.0f;
            const float fMax = 16000.0f;

            for (int i = 0; i < 5; ++i)
            {
                float normX = std::log(freqs[i] / fMin) / std::log(fMax / fMin);
                float x = bounds.getX() + normX * w;
                g.drawVerticalLine((int)x, bounds.getY() + 4.0f, bounds.getBottom() - 12.0f);

                g.setColour(juce::Colour(0x55ffe099));
                g.setFont(juce::FontOptions(7.5f));
                g.drawText(fLabels[i], (int)(x - 10.0f), (int)(bounds.getBottom() - 11.0f), 20, 10, juce::Justification::centred, false);
                g.setColour(juce::Colour(0x18c59c52));
            }

            // Horizontal Decibel Grids (-6, -12, -18 dB)
            for (float db : { 6.0f, 12.0f, 18.0f })
            {
                float normY = db / 20.0f;
                float y = bounds.getY() + 14.0f + normY * (h - 26.0f);
                g.drawHorizontalLine((int)y, bounds.getX() + 4.0f, bounds.getRight() - 4.0f);
            }

            // 3. Sibilance Detection Zone (Shaded Band)
            const float centerFreq = isFemaleMode ? 7600.0f : (targetFreqHz > 100.0f ? targetFreqHz : 6400.0f);
            const float centerNormX = std::log(centerFreq / fMin) / std::log(fMax / fMin);
            const float bandCenterX = bounds.getX() + centerNormX * w;
            const float bandWidth = w * 0.28f;

            auto bandRect = juce::Rectangle<float>(bandCenterX - bandWidth * 0.5f, bounds.getY() + 14.0f, bandWidth, h - 26.0f);
            g.setColour(juce::Colour(0x1400d2ff));
            g.fillRoundedRectangle(bandRect, 2.0f);
            g.setColour(juce::Colour(0x3500d2ff));
            g.drawRoundedRectangle(bandRect, 2.0f, 0.8f);

            // 4. Differential Phase Cancellation Dynamic Dip (Phosphor Amber/Cyan)
            const float midY = bounds.getY() + 14.0f;
            const float maxDip = (h - 28.0f);
            const float dipDepth = (smoothedReductionDb / 18.0f) * maxDip;

            juce::Path dipPath;
            dipPath.startNewSubPath(bounds.getX() + 4.0f, midY);

            for (float x = bounds.getX() + 4.0f; x <= bounds.getRight() - 4.0f; x += 3.0f)
            {
                float dist = (x - bandCenterX) / (bandWidth * 0.55f);
                float bell = std::exp(-0.5f * dist * dist);
                float dynamicY = midY + bell * dipDepth;

                // Subtle audio transient shimmer
                if (smoothedReductionDb > 0.5f)
                {
                    float shimmer = std::sin(dist * 6.0f + phaseWave) * 1.5f * (smoothedReductionDb / 12.0f);
                    dynamicY += shimmer;
                }

                dipPath.lineTo(x, dynamicY);
            }

            // Fill under dip
            juce::Path fillPath = dipPath;
            fillPath.lineTo(bounds.getRight() - 4.0f, midY);
            fillPath.closeSubPath();

            juce::ColourGradient fillGrad(juce::Colour(0x40ffb300), bandCenterX, midY,
                                         juce::Colour(0x05ffb300), bandCenterX, bounds.getBottom(), false);
            g.setGradientFill(fillGrad);
            g.fillPath(fillPath);

            // Glowing trace
            g.setColour(smoothedReductionDb > 0.5f ? juce::Colour(0xffffcc00) : juce::Colour(0xff00d2ff).withAlpha(0.6f));
            g.strokePath(dipPath, juce::PathStrokeType(1.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // 5. Digital Header Status
            auto headerArea = bounds.removeFromTop(13.0f);
            g.setColour(juce::Colour(0xffd4af37));
            g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
            juce::String status = isFemaleMode ? "PHASE DE-ESS: FEMALE [7.6k]" : "PHASE DE-ESS: MALE [6.4k]";
            if (smoothedReductionDb > 0.2f)
                status += "  -" + juce::String(smoothedReductionDb, 1) + " dB";
            g.drawText(status, headerArea, juce::Justification::centred, false);
        }

    private:
        float smoothedReductionDb = 0.0f;
        float targetFreqHz = 6800.0f;
        bool isFemaleMode = false;
        float phaseWave = 0.0f;

        std::function<float()> getReduction;
        std::function<float()> getFreq;
        std::function<bool()> getIsFemale;
    };

    // ==============================================================================
    // 5B. RAPID STEREO I/O LEVEL MONITOR SCREEN
    // ==============================================================================
    class RapidIOMonitorScreen : public juce::Component, private juce::Timer
    {
    public:
        RapidIOMonitorScreen()
        {
            setOpaque(false);
            setInterceptsMouseClicks(false, true);
            startTimerHz(60);
        }

        ~RapidIOMonitorScreen() override { stopTimer(); }

        void bindLevels(std::function<float()> inPeakSource,
                        std::function<float()> inRmsSource,
                        std::function<float()> outPeakSource,
                        std::function<float()> outRmsSource)
        {
            getInPeak  = inPeakSource;
            getInRms   = inRmsSource;
            getOutPeak = outPeakSource;
            getOutRms  = outRmsSource;
        }

        void timerCallback() override
        {
            float targetInP  = getInPeak  ? getInPeak()  : 0.0f;
            float targetInR  = getInRms   ? getInRms()   : 0.0f;
            float targetOutP = getOutPeak ? getOutPeak() : 0.0f;
            float targetOutR = getOutRms  ? getOutRms()  : 0.0f;

            smoothInPeak  += (targetInP  - smoothInPeak)  * 0.45f;
            smoothInRms   += (targetInR  - smoothInRms)   * 0.20f;
            smoothOutPeak += (targetOutP - smoothOutPeak) * 0.45f;
            smoothOutRms  += (targetOutR - smoothOutRms)  * 0.20f;

            if (smoothInPeak > peakHoldIn)   peakHoldIn = smoothInPeak;
            else peakHoldIn = std::max(0.0f, peakHoldIn - 0.008f);

            if (smoothOutPeak > peakHoldOut) peakHoldOut = smoothOutPeak;
            else peakHoldOut = std::max(0.0f, peakHoldOut - 0.008f);

            animPhase += 0.08f;
            if (animPhase > juce::MathConstants<float>::twoPi)
                animPhase -= juce::MathConstants<float>::twoPi;

            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            auto bounds = getLocalBounds().toFloat().reduced(2.0f);

            // 1. Dark Glass OLED/TFT Background
            g.setColour(juce::Colour(0xdc090c12));
            g.fillRoundedRectangle(bounds, 4.0f);

            // Subtle scanlines
            g.setColour(juce::Colour(0x0cffffff));
            for (float y = bounds.getY() + 3.0f; y < bounds.getBottom() - 3.0f; y += 3.0f)
                g.drawHorizontalLine((int)y, bounds.getX() + 3.0f, bounds.getRight() - 3.0f);

            // 2. Header
            auto headerArea = bounds.removeFromTop(18.0f);
            g.setColour(juce::Colour(0xff38bdf8).withAlpha(0.95f));
            g.setFont(juce::FontOptions(9.5f, juce::Font::bold));
            g.drawText("I/O STEREO LEVEL MONITOR", headerArea.withTrimmedLeft(8.0f), juce::Justification::centredLeft, false);

            g.setColour(juce::Colour(0xff94a3b8));
            g.setFont(juce::FontOptions(8.5f));
            g.drawText("24-BIT / 96kHz", headerArea.withTrimmedRight(8.0f), juce::Justification::centredRight, false);

            // 3. Dual Input & Output Meter Bars
            auto meterArea = bounds.reduced(6.0f, 4.0f);
            float rowH = 14.0f;

            // Draw IN Meter (Row 1)
            drawMeterRow(g, meterArea.getX(), meterArea.getY() + 2.0f, meterArea.getWidth(), rowH,
                         "IN", smoothInRms, smoothInPeak, peakHoldIn);

            // Draw Dynamic Oscilloscope / Wave Activity Line in the middle
            float waveY = meterArea.getY() + 30.0f;
            float waveW = meterArea.getWidth();
            juce::Path wavePath;
            wavePath.startNewSubPath(meterArea.getX(), waveY);
            float audioAmp = juce::jlimit(0.0f, 1.0f, (smoothInPeak + smoothOutPeak) * 0.5f);
            for (float x = 0.0f; x <= waveW; x += 4.0f)
            {
                float normX = x / waveW;
                float sinV = std::sin(normX * 12.0f + animPhase) * std::cos(normX * 4.0f - animPhase);
                float y = waveY + sinV * audioAmp * 9.0f;
                wavePath.lineTo(meterArea.getX() + x, y);
            }
            g.setColour(juce::Colour(0x3300e5ff));
            g.strokePath(wavePath, juce::PathStrokeType(3.0f));
            g.setColour(juce::Colour(0xcc00e5ff));
            g.strokePath(wavePath, juce::PathStrokeType(1.2f));

            // Draw OUT Meter (Row 2)
            drawMeterRow(g, meterArea.getX(), meterArea.getY() + 44.0f, meterArea.getWidth(), rowH,
                         "OUT", smoothOutRms, smoothOutPeak, peakHoldOut);
        }

    private:
        void drawMeterRow(juce::Graphics& g, float x, float y, float w, float h,
                          const juce::String& tag, float rms, float peak, float peakHold)
        {
            // Tag label
            g.setColour(juce::Colour(0xffcbd5e1));
            g.setFont(juce::FontOptions(9.0f, juce::Font::bold));
            g.drawText(tag, (int)x, (int)y, 24, (int)h, juce::Justification::centredLeft, false);

            float barX = x + 26.0f;
            float barW = w - 85.0f;
            auto barRect = juce::Rectangle<float>(barX, y + 2.0f, barW, h - 4.0f);

            // Background recessed bar
            g.setColour(juce::Colour(0xff161922));
            g.fillRoundedRectangle(barRect, 2.0f);

            // Segmented LEDs: 18 segments
            const int numSegs = 18;
            float segW = (barW - (numSegs - 1) * 1.5f) / numSegs;
            float normVal = juce::jlimit(0.0f, 1.0f, peak);

            for (int i = 0; i < numSegs; ++i)
            {
                float segNorm = (float)(i + 1) / (float)numSegs;
                float sx = barX + i * (segW + 1.5f);
                auto sRect = juce::Rectangle<float>(sx, y + 3.0f, segW, h - 6.0f);

                juce::Colour segCol;
                if (i < 11)      segCol = juce::Colour(0xff22c55e); // Green
                else if (i < 15) segCol = juce::Colour(0xffeab308); // Amber
                else             segCol = juce::Colour(0xffef4444); // Red

                if (segNorm <= normVal)
                {
                    g.setColour(segCol);
                    g.fillRoundedRectangle(sRect, 1.0f);
                }
                else
                {
                    g.setColour(segCol.withAlpha(0.12f));
                    g.fillRoundedRectangle(sRect, 1.0f);
                }
            }

            // Peak Hold Marker
            if (peakHold > 0.02f)
            {
                float phNorm = juce::jlimit(0.0f, 1.0f, peakHold);
                float px = barX + phNorm * (barW - 2.0f);
                g.setColour(juce::Colours::white);
                g.fillRect(px, y + 2.0f, 2.0f, h - 4.0f);
            }

            // Numeric dB readout
            float db = (peak > 0.0001f) ? 20.0f * std::log10(peak) : -60.0f;
            g.setColour(juce::Colour(0xff38bdf8));
            g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
            juce::String valStr = juce::String(db, 1) + " dB";
            g.drawText(valStr, (int)(barX + barW + 6.0f), (int)y, 50, (int)h, juce::Justification::centredRight, false);
        }

        std::function<float()> getInPeak;
        std::function<float()> getInRms;
        std::function<float()> getOutPeak;
        std::function<float()> getOutRms;

        float smoothInPeak = 0.0f;
        float smoothInRms = 0.0f;
        float smoothOutPeak = 0.0f;
        float smoothOutRms = 0.0f;
        float peakHoldIn = 0.0f;
        float peakHoldOut = 0.0f;
        float animPhase = 0.0f;
    };

    // ==============================================================================
    // 5C. RAPID ILLUMINATED BYPASS BUTTON
    // ==============================================================================
    class RapidBypassButton : public juce::Button
    {
    public:
        RapidBypassButton(const juce::String& name = "BYPASS")
            : juce::Button(name)
        {
            setClickingTogglesState(true);
        }

        void paintButton(juce::Graphics& g, bool /*shouldDrawButtonAsHighlighted*/, bool /*shouldDrawButtonAsDown*/) override
        {
            auto bounds = getLocalBounds().toFloat().reduced(2.0f);
            bool isBypassed = getToggleState();
            bool isActive = !isBypassed;

            // Outer drop shadow
            g.setColour(juce::Colours::black.withAlpha(0.6f));
            g.fillRoundedRectangle(bounds.translated(1.5f, 2.5f), 6.0f);

            // Beveled button border
            juce::Colour borderCol = isActive ? juce::Colour(0xffc59c52) : juce::Colour(0xff3f4450);
            g.setColour(borderCol);
            g.drawRoundedRectangle(bounds, 6.0f, 1.5f);

            // Button body gradient
            juce::Colour bgTop = isActive ? juce::Colour(0xff2a1a15) : juce::Colour(0xff181a1f);
            juce::Colour bgBot = isActive ? juce::Colour(0xff160c0a) : juce::Colour(0xff0d0e11);
            juce::ColourGradient grad(bgTop, bounds.getX(), bounds.getY(),
                                     bgBot, bounds.getX(), bounds.getBottom(), false);
            g.setGradientFill(grad);
            g.fillRoundedRectangle(bounds.reduced(1.0f), 5.0f);

            // Illuminated LED Lamp
            float ledX = bounds.getX() + 16.0f;
            float ledY = bounds.getCentreY();
            float ledR = 6.0f;

            if (isActive)
            {
                // Glowing active ruby lamp
                g.setColour(juce::Colour(0x66ff2244));
                g.fillEllipse(ledX - ledR - 4.0f, ledY - ledR - 4.0f, (ledR + 4.0f) * 2.0f, (ledR + 4.0f) * 2.0f);
                g.setColour(juce::Colour(0xffff2d55));
                g.fillEllipse(ledX - ledR, ledY - ledR, ledR * 2.0f, ledR * 2.0f);
                g.setColour(juce::Colours::white);
                g.fillEllipse(ledX - ledR * 0.4f, ledY - ledR * 0.4f, ledR * 0.8f, ledR * 0.8f);

                // Text
                g.setColour(juce::Colour(0xffffe099));
                g.setFont(juce::FontOptions(11.5f, juce::Font::bold));
                g.drawText("171 ACTIVE", bounds.withTrimmedLeft(30.0f), juce::Justification::centredLeft, false);
            }
            else
            {
                // Dim unlit gray lamp
                g.setColour(juce::Colour(0xff333a45));
                g.fillEllipse(ledX - ledR, ledY - ledR, ledR * 2.0f, ledR * 2.0f);

                // Text
                g.setColour(juce::Colour(0xff717888));
                g.setFont(juce::FontOptions(11.5f, juce::Font::bold));
                g.drawText("BYPASS", bounds.withTrimmedLeft(30.0f), juce::Justification::centredLeft, false);
            }
        }
    };

    // ==============================================================================
    // 6. RAPID MASTER GUI CONTROLLER
    // ==============================================================================
    class RapidGUI
    {
    public:
        RapidGUI(juce::AudioProcessorEditor& editor, juce::AudioProcessorValueTreeState& vts)
            : ownerEditor(editor), apvts(vts)
        {
        }

        void setChassis(ChassisTheme theme, int w, int h, const juce::String& pTitle = "171 STUDIO", const juce::String& pSubtitle = "ANALOG MASTERING CONSOLE")
        {
            currentTheme = theme;
            chassisWidth = w;
            chassisHeight = h;
            title = pTitle;
            subtitle = pSubtitle;
            ownerEditor.setSize(w, h);
        }

        // Add a photorealistic analog knob with 1 line of code!
        RapidKnob& addKnob(const juce::String& paramId, 
                           const juce::String& label,
                           KnobStyle kStyle = KnobStyle::TeardropBronze,
                           ScaleDialType sStyle = ScaleDialType::Percent0To100)
        {
            auto knob = std::make_unique<RapidKnob>(label, kStyle, sStyle);
            ownerEditor.addAndMakeVisible(*knob);

            // Connect APVTS attachment automatically!
            if (apvts.getParameter(paramId) != nullptr)
            {
                sliderAttachments.push_back(
                    std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, paramId, *knob)
                );
            }

            RapidKnob* ptr = knob.get();
            knobs.push_back(std::move(knob));
            return *ptr;
        }

        // Add calibrated SVG VU Meter with 1 line of code!
        RapidVUMeter& addVUMeter(const juce::String& meterName,
                                VUDialStyle dialStyle = VUDialStyle::VU_Gain,
                                PointerStyle pointerStyle = PointerStyle::ClassicNeedle)
        {
            juce::ignoreUnused(meterName);
            auto meter = std::make_unique<RapidVUMeter>(dialStyle, pointerStyle);
            ownerEditor.addAndMakeVisible(*meter);

            RapidVUMeter* ptr = meter.get();
            vuMeters.push_back(std::move(meter));
            return *ptr;
        }

        // Add heavy duty toggle switch with 1 line of code!
        RapidToggleSwitch& addToggleSwitch(const juce::String& paramId,
                                           const juce::String& label = "BYPASS",
                                           SwitchStyle sStyle = SwitchStyle::HeavyDutyChromeBaton)
        {
            auto sw = std::make_unique<RapidToggleSwitch>(label, sStyle);
            ownerEditor.addAndMakeVisible(*sw);

            // Connect APVTS attachment
            if (apvts.getParameter(paramId) != nullptr)
            {
                buttonAttachments.push_back(
                    std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(apvts, paramId, *sw)
                );
            }

            RapidToggleSwitch* ptr = sw.get();
            switches.push_back(std::move(sw));
            return *ptr;
        }

        void setBackplateImage(const juce::Image& backplate, const juce::Image& glass = juce::Image())
        {
            backplateImg = backplate;
            glassOverlayImg = glass;
            if (backplateImg.isValid())
                ownerEditor.setSize(backplateImg.getWidth(), backplateImg.getHeight());
        }

        // Add SPL LED Ladder Meter with 1 line of code!
        RapidLadderMeter& addLadderMeter(const juce::String& meterTitleText = "S-REDUCTION (dB)")
        {
            auto meter = std::make_unique<RapidLadderMeter>(meterTitleText);
            ownerEditor.addAndMakeVisible(*meter);

            RapidLadderMeter* ptr = meter.get();
            ladderMeters.push_back(std::move(meter));
            return *ptr;
        }

        // Render the boutique hardware chassis backplate
        void paintChassis(juce::Graphics& g)
        {
            const auto bounds = ownerEditor.getLocalBounds().toFloat();

            // 0. If photorealistic custom backplate image is provided, draw it!
            if (backplateImg.isValid())
            {
                g.drawImage(backplateImg, bounds, juce::RectanglePlacement::stretchToFit);
                return;
            }

            // 1. Brushed Gunmetal / Dark Bronze Faceplate
            juce::Colour cTop = (currentTheme == ChassisTheme::VintageDarkBronze) ? juce::Colour(0xff1f1b16) : juce::Colour(0xff16171a);
            juce::Colour cBot = (currentTheme == ChassisTheme::VintageDarkBronze) ? juce::Colour(0xff0d0c0a) : juce::Colour(0xff0b0b0d);
            
            juce::ColourGradient grad(cTop, 0.0f, 0.0f, cBot, 0.0f, bounds.getHeight(), false);
            g.setGradientFill(grad);
            g.fillRoundedRectangle(bounds, 6.0f);

            // 2. Precision Chamfer & Anodized Border
            g.setColour(juce::Colour(0xffd89f3c).withAlpha(0.6f));
            g.drawRoundedRectangle(bounds.reduced(1.5f), 5.0f, 1.5f);

            // 3. Corner Allen Screws (Boutique rackmount style)
            const float screwInset = 16.0f;
            drawCornerScrew(g, screwInset, screwInset);
            drawCornerScrew(g, bounds.getRight() - screwInset, screwInset);
            drawCornerScrew(g, screwInset, bounds.getBottom() - screwInset);
            drawCornerScrew(g, bounds.getRight() - screwInset, bounds.getBottom() - screwInset);

            // 4. Serigraphic Title Header
            if (title.isNotEmpty())
            {
                auto titleArea = juce::Rectangle<float>(40.0f, 14.0f, 240.0f, 22.0f);
                g.setColour(juce::Colour(0xffd89f3c));
                g.setFont(juce::FontOptions(15.0f, juce::Font::bold));
                g.drawText(title, titleArea, juce::Justification::left, false);

                auto subArea = juce::Rectangle<float>(40.0f, 34.0f, 240.0f, 14.0f);
                g.setColour(juce::Colour(0xff8e94a4));
                g.setFont(juce::FontOptions(9.5f));
                g.drawText(subtitle, subArea, juce::Justification::left, false);
            }
        }

        // Draw physical glass glare over screens
        void paintGlassOverlay(juce::Graphics& g)
        {
            if (glassOverlayImg.isValid())
            {
                g.drawImage(glassOverlayImg, ownerEditor.getLocalBounds().toFloat(), juce::RectanglePlacement::stretchToFit);
            }
        }

    private:
        void drawCornerScrew(juce::Graphics& g, float cx, float cy)
        {
            const float r = 5.5f;
            g.setColour(juce::Colour(0xff0d0e10));
            g.fillEllipse(cx - r, cy - r, r * 2.0f, r * 2.0f);
            g.setColour(juce::Colour(0xff3a3d45));
            g.drawEllipse(cx - r, cy - r, r * 2.0f, r * 2.0f, 1.0f);
            // Hex Allen hole
            g.setColour(juce::Colour(0xff050506));
            g.fillEllipse(cx - 2.2f, cy - 2.2f, 4.4f, 4.4f);
        }

        juce::AudioProcessorEditor& ownerEditor;
        juce::AudioProcessorValueTreeState& apvts;

        ChassisTheme currentTheme = ChassisTheme::VintageDarkBronze;
        int chassisWidth = 960;
        int chassisHeight = 480;
        juce::String title;
        juce::String subtitle;

        std::vector<std::unique_ptr<RapidKnob>> knobs;
        std::vector<std::unique_ptr<RapidVUMeter>> vuMeters;
        std::vector<std::unique_ptr<RapidToggleSwitch>> switches;
        std::vector<std::unique_ptr<RapidLadderMeter>> ladderMeters;

        juce::Image backplateImg;
        juce::Image glassOverlayImg;

        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAttachments;
        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAttachments;
    };
}
