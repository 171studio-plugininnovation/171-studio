#pragma once
#if __has_include(<juce_dsp/juce_dsp.h>)
#include <juce_dsp/juce_dsp.h>
#define DSP171_HAS_JUCE_DSP 1
#else
#define DSP171_HAS_JUCE_DSP 0
#endif
#include <memory>
#include <functional>

namespace dsp171 {

#if DSP171_HAS_JUCE_DSP
// Gestore Oversampling Multi-Rate da Studio (2x, 4x, 8x)
// Fornisce filtraggio anti-aliasing e anti-imaging ad elevatissima attenuazione (>100 dB stopband).
// Gestisce automaticamente la latenza verso la DAW e supporta la commutazione dinamica.
class Oversampler {
public:
    enum class Factor : int {
        Off = 0,
        x2  = 1,
        x4  = 2,
        x8  = 3
    };

    Oversampler() = default;

    void prepare(size_t numChannels, size_t maxBlockSize, double sampleRate,
                 Factor factor = Factor::x4, bool linearPhase = true)
    {
        currentChannels = numChannels;
        currentBlockSize = maxBlockSize;
        currentSampleRate = sampleRate;
        currentFactor = factor;
        isLinearPhase = linearPhase;

        rebuildOversampler();
    }

    void reset() {
        if (oversampler2x != nullptr) oversampler2x->reset();
        if (oversampler4x != nullptr) oversampler4x->reset();
        if (oversampler8x != nullptr) oversampler8x->reset();
    }

    void setFactor(Factor newFactor) {
        if (currentFactor != newFactor) {
            currentFactor = newFactor;
            reset();
        }
    }

    Factor getFactor() const noexcept { return currentFactor; }

    // Restituisce la latenza esatta in campioni a frequenza base (da passare a setLatencySamples() della DAW)
    int getLatencyInSamples() const noexcept {
        switch (currentFactor) {
            case Factor::x2: return oversampler2x ? static_cast<int>(std::round(oversampler2x->getLatencyInSamples())) : 0;
            case Factor::x4: return oversampler4x ? static_cast<int>(std::round(oversampler4x->getLatencyInSamples())) : 0;
            case Factor::x8: return oversampler8x ? static_cast<int>(std::round(oversampler8x->getLatencyInSamples())) : 0;
            case Factor::Off:
            default:
                return 0;
        }
    }

    // Esegue il processing dell'AudioBuffer con oversampling trasparente.
    // Il callback riceve il blocco (a frequenza base o sovracampionata) da processare.
    template <typename ProcessFn>
    void process(juce::AudioBuffer<float>& buffer, ProcessFn&& processCallback) {
        if (currentFactor == Factor::Off) {
            juce::dsp::AudioBlock<float> block(buffer);
            processCallback(block, static_cast<float>(currentSampleRate));
            return;
        }

        auto* activeOversampler = getActiveOversampler();
        if (activeOversampler == nullptr) {
            juce::dsp::AudioBlock<float> block(buffer);
            processCallback(block, static_cast<float>(currentSampleRate));
            return;
        }

        juce::dsp::AudioBlock<float> baseBlock(buffer);
        auto oversampledBlock = activeOversampler->processSamplesUp(baseBlock);

        const float oversampledRate = static_cast<float>(currentSampleRate) * static_cast<float>(1 << static_cast<int>(currentFactor));
        processCallback(oversampledBlock, oversampledRate);

        activeOversampler->processSamplesDown(baseBlock);
    }

private:
    void rebuildOversampler() {
        if (currentChannels == 0) return;

        const auto filterType = isLinearPhase
            ? juce::dsp::Oversampling<float>::filterHalfBandFIREquiripple
            : juce::dsp::Oversampling<float>::filterHalfBandPolyphaseIIR;

        oversampler2x = std::make_unique<juce::dsp::Oversampling<float>>(
            currentChannels, 1, filterType, true, true);
        oversampler2x->initProcessing(currentBlockSize);

        oversampler4x = std::make_unique<juce::dsp::Oversampling<float>>(
            currentChannels, 2, filterType, true, true);
        oversampler4x->initProcessing(currentBlockSize);

        oversampler8x = std::make_unique<juce::dsp::Oversampling<float>>(
            currentChannels, 3, filterType, true, true);
        oversampler8x->initProcessing(currentBlockSize);
    }

    juce::dsp::Oversampling<float>* getActiveOversampler() const noexcept {
        switch (currentFactor) {
            case Factor::x2: return oversampler2x.get();
            case Factor::x4: return oversampler4x.get();
            case Factor::x8: return oversampler8x.get();
            case Factor::Off:
            default:
                return nullptr;
        }
    }

    size_t currentChannels = 2;
    size_t currentBlockSize = 512;
    double currentSampleRate = 44100.0;
    Factor currentFactor = Factor::x4;
    bool isLinearPhase = true;

    std::unique_ptr<juce::dsp::Oversampling<float>> oversampler2x;
    std::unique_ptr<juce::dsp::Oversampling<float>> oversampler4x;
    std::unique_ptr<juce::dsp::Oversampling<float>> oversampler8x;
};
#endif

} // namespace dsp171
