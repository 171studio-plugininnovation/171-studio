#pragma once

#include <cmath>
#include <algorithm>
#include <cstdint>

namespace dsp171 {

// =============================================================================
// ADAA2HardClipper
// Crafted by: clipper-digital-hard-specialist (Reviewed by dsp-scientific-researcher)
//
// Analytical 2nd-Order Antiderivative Antialiasing (ADAA-2) Piecewise Hard Clipper.
// Mathematically eliminates alias foldover from sharp hard-clipping discontinuities
// without the massive CPU overhead and transient pre-ringing of extreme oversampling.
//
// Integrates:
// 1. Exact continuous piecewise antiderivatives F1(x) and F2(x).
// 2. Continuous Taylor expansions for local limits (|x0 - x1| < eps).
// 3. Exact L'Hopital limits for outer coincident points (|x0 - x2| < eps).
// 4. Arbitrary threshold scaling: y = T * ADAA2(x / T).
// 5. Guaranteed zero NaNs, zero Infs, and zero denormals.
// =============================================================================

class ADAA2HardClipper {
public:
    ADAA2HardClipper() noexcept {
        reset();
    }

    void reset() noexcept {
        x1 = 0.0;
        x2 = 0.0;
    }

    // --- Core Piecewise Hard Clipping Non-linearity ---
    // f(x) = sgn(x) * min(|x|, 1.0)
    static inline double f(double x) noexcept {
        if (x > 1.0)  return 1.0;
        if (x < -1.0) return -1.0;
        return x;
    }

    // Derivative: f'(x)
    static inline double fPrime(double x) noexcept {
        return (std::abs(x) < 1.0) ? 1.0 : 0.0;
    }

    // First Continuous Antiderivative: F1(x) = \int f(t) dt
    // Continuous everywhere, even function F1(-x) = F1(x), F1(1) = 0.5
    static inline double F1(double x) noexcept {
        const double ax = std::abs(x);
        if (ax <= 1.0) {
            return 0.5 * ax * ax;
        }
        return ax - 0.5;
    }

    // Second Continuous Antiderivative: F2(x) = \int F1(t) dt
    // Continuous everywhere, odd function F2(-x) = -F2(x), F2(1) = 1/6
    static inline double F2(double x) noexcept {
        if (x > 1.0) {
            return 0.5 * x * x - 0.5 * x + (1.0 / 6.0);
        }
        if (x < -1.0) {
            return -0.5 * x * x - 0.5 * x - (1.0 / 6.0);
        }
        return (1.0 / 6.0) * x * x * x;
    }

    // Difference quotient of F2: D(a, b) = (F2(a) - F2(b)) / (a - b)
    // Uses 2nd-order midpoint Taylor expansion when |a - b| < eps to avoid 0/0
    static inline double diffF2(double a, double b, double d, double eps) noexcept {
        if (std::abs(d) < eps) {
            const double mid = 0.5 * (a + b);
            return F1(mid) + (d * d / 24.0) * fPrime(mid);
        }
        return (F2(a) - F2(b)) / d;
    }

    // Process a single sample through the 2nd-order ADAA hard-clipper
    // threshold: normalized linear clipping ceiling (> 0.0f)
    inline float processSample(float inSample, float threshold = 1.0f) noexcept {
        if (!std::isfinite(inSample)) inSample = 0.0f;
        const double safeThresh = (threshold > 1.0e-6f) ? static_cast<double>(threshold) : 1.0e-6;
        const double invThresh = 1.0 / safeThresh;

        // Scale input into unit threshold domain [-1, 1]
        const double in = static_cast<double>(inSample) * invThresh;

        // Linear Pass-Through Fast Path:
        // When signal is below threshold, f(x) = x identically.
        // Bypassing moving-average filter preserves bit-exact transient fidelity, 0 phase smear,
        // and 0 dB flat frequency response!
        if (std::abs(in) <= 1.0 && std::abs(x1) <= 1.0 && std::abs(x2) <= 1.0) {
            x2 = (std::abs(x1) > 1.0e-25) ? x1 : 0.0;
            x1 = (std::abs(in) > 1.0e-25) ? in : 0.0;
            return inSample;
        }

        constexpr double eps = 1.0e-5;

        const double d0 = in - x1;
        const double d1 = x1 - x2;
        const double dTot = in - x2;

        double outNorm = 0.0;

        if (std::abs(dTot) < eps) {
            const double diff = x2 - x1;
            if (std::abs(diff) < eps || std::abs(d0) < eps) {
                // Triple-coincident limit (x0 ~ x1 ~ x2)
                const double mid = (in + x1 + x2) / 3.0;
                outNorm = f(mid);
            } else {
                // Analytical limit as x0 -> x2 with x1 != x2:
                // lim_{x0->x2} 2/(x0-x2) * [ (F2(x0)-F2(x1))/(x0-x1) - (F2(x1)-F2(x2))/(x1-x2) ]
                // = 2 * [ F1(x2)*(x2-x1) - (F2(x2)-F2(x1)) ] / (x2-x1)^2
                const double diffSq = diff * diff;
                const double safeDiffSq = (diffSq > 1.0e-12) ? diffSq : 1.0e-12;
                outNorm = 2.0 * (F1(x2) * diff - (F2(x2) - F2(x1))) / safeDiffSq;
            }
        } else {
            const double term0 = diffF2(in, x1, d0, eps);
            const double term1 = diffF2(x1, x2, d1, eps);
            outNorm = (2.0 / dTot) * (term0 - term1);
        }

        // Subnormal state protection
        x2 = (std::abs(x1) > 1.0e-25) ? x1 : 0.0;
        x1 = (std::abs(in) > 1.0e-25) ? in : 0.0;

        // Rescale output back from unit threshold domain
        const double finalOut = outNorm * safeThresh;
        const float res = static_cast<float>(finalOut);
        return std::isfinite(res) ? res : 0.0f;
    }

private:
    double x1 = 0.0;
    double x2 = 0.0;
};

} // namespace dsp171
