#pragma once
#include <cmath>
#include <algorithm>
#include <array>

namespace dsp171 {

/**
 * @brief WavesSilkEngine
 * Reverse-engineered from Waves Silk Vocal & Renaissance Vox (RVox).
 * Integrates an intelligent 3-band adaptive vocal resonance tracking processor
 * (Low Boxiness, Mid Harshness, High Sibilance) with the classic RVox optical leveling
 * dynamics engine and downward expander gate.
 */
class WavesSilkEngine {
public:
    WavesSilkEngine() noexcept 
        : m_sampleRate(44100.0f) {}

    void prepare(float sampleRate) noexcept {
        m_sampleRate = sampleRate;
        resetFilters();
        m_lowResEnv = 0.0f;
        m_midResEnv = 0.0f;
        m_highResEnv = 0.0f;
        m_rvoxCompEnv = 0.0f;
        m_rvoxGateEnv = 0.0f;

        // Sample-rate independent ballistic tracker coefficients
        m_alphaLow = 1.0f - std::exp(-1.0f / (0.0011f * m_sampleRate));
        m_alphaMid = 1.0f - std::exp(-1.0f / (0.00045f * m_sampleRate));
        m_alphaHigh = 1.0f - std::exp(-1.0f / (0.00022f * m_sampleRate));

        updateFilters();
    }

    void setSilkParameters(float lowResonanceReduction = 0.0f,
                           float midHarshnessReduction = 0.0f,
                           float highSibilanceReduction = 0.0f) noexcept {
        m_lowResReduction = std::clamp(lowResonanceReduction, 0.0f, 100.0f) * 0.01f;
        m_midResReduction = std::clamp(midHarshnessReduction, 0.0f, 100.0f) * 0.01f;
        m_highResReduction = std::clamp(highSibilanceReduction, 0.0f, 100.0f) * 0.01f;
    }

    void setRVoxParameters(float compThresholdDb = 0.0f, float gateThresholdDb = -80.0f,
                           float outputCeilingDb = 0.0f) noexcept {
        m_compThresholdDb = std::clamp(compThresholdDb, -36.0f, 0.0f);
        m_gateThresholdDb = std::clamp(gateThresholdDb, -80.0f, -20.0f);
        m_outputCeiling = std::pow(10.0f, std::clamp(outputCeilingDb, -18.0f, 0.0f) / 20.0f);
        
        // RVox automatic make-up gain: proportional to compression depth
        m_autoMakeup = std::pow(10.0f, (-m_compThresholdDb * 0.65f) / 20.0f);
    }

    inline void process(float inL, float inR, float& outL, float& outR) noexcept {
        // -----------------------------------------------------------------
        // STAGE 1: Adaptive Silk Resonance Suppression (3 Bands)
        // -----------------------------------------------------------------
        float sigM = 0.5f * (inL + inR);

        // Track Low Band (350 Hz, Boxiness)
        float lowEnergy = m_bpLow.process(sigM);
        m_lowResEnv += m_alphaLow * (std::fabs(lowEnergy) - m_lowResEnv);
        float lowGain = 1.0f - (m_lowResReduction * std::clamp(m_lowResEnv * 2.0f, 0.0f, 0.75f));

        // Track Mid Band (2.8 kHz, Harshness)
        float midEnergy = m_bpMid.process(sigM);
        m_midResEnv += m_alphaMid * (std::fabs(midEnergy) - m_midResEnv);
        float midGain = 1.0f - (m_midResReduction * std::clamp(m_midResEnv * 3.0f, 0.0f, 0.75f));

        // Track High Band (7.5 kHz, Sibilance De-Essing)
        float highEnergy = m_bpHigh.process(sigM);
        m_highResEnv += m_alphaHigh * (std::fabs(highEnergy) - m_highResEnv);
        float highGain = 1.0f - (m_highResReduction * std::clamp(m_highResEnv * 4.0f, 0.0f, 0.85f));

        // Apply dynamic notch filters
        float silkL = inL - (lowEnergy * (1.0f - lowGain)) 
                          - (midEnergy * (1.0f - midGain)) 
                          - (highEnergy * (1.0f - highGain));
        float silkR = inR - (lowEnergy * (1.0f - lowGain)) 
                          - (midEnergy * (1.0f - midGain)) 
                          - (highEnergy * (1.0f - highGain));

        // -----------------------------------------------------------------
        // STAGE 2: Renaissance Vox (RVox) Downward Gate
        // -----------------------------------------------------------------
        float peakDet = std::max(std::fabs(silkL), std::fabs(silkR));
        float peakDb = 20.0f * std::log10(std::max(peakDet, 1e-5f));

        float gateAlpha = 1.0f - std::exp(-1.0f / (0.015f * m_sampleRate));
        m_rvoxGateEnv += gateAlpha * (peakDb - m_rvoxGateEnv);

        float gateGain = 1.0f;
        if (m_rvoxGateEnv < m_gateThresholdDb) {
            float belowDb = m_gateThresholdDb - m_rvoxGateEnv;
            gateGain = std::pow(10.0f, -(belowDb * 1.5f) / 20.0f);
        }

        // -----------------------------------------------------------------
        // STAGE 3: RVox Optical Compressor with Auto-Makeup
        // -----------------------------------------------------------------
        float compAlphaAtt = 1.0f - std::exp(-1.0f / (0.003f * m_sampleRate)); // 3 ms
        float compAlphaRel = 1.0f - std::exp(-1.0f / (0.120f * m_sampleRate)); // 120 ms optical decay
        if (peakDb > m_rvoxCompEnv) m_rvoxCompEnv += compAlphaAtt * (peakDb - m_rvoxCompEnv);
        else m_rvoxCompEnv += compAlphaRel * (peakDb - m_rvoxCompEnv);

        float compGain = 1.0f;
        if (m_rvoxCompEnv > m_compThresholdDb) {
            float overDb = m_rvoxCompEnv - m_compThresholdDb;
            // Soft-knee ratio ~ 3.5:1
            float grDb = overDb * (1.0f - 1.0f / 3.5f);
            compGain = std::pow(10.0f, -grDb / 20.0f);
        }

        // Apply combined dynamic gain and auto-makeup
        float outSigL = silkL * gateGain * compGain * m_autoMakeup;
        float outSigR = silkR * gateGain * compGain * m_autoMakeup;

        // Brickwall ceiling safety clamp
        outL = std::clamp(outSigL, -m_outputCeiling, m_outputCeiling);
        outR = std::clamp(outSigR, -m_outputCeiling, m_outputCeiling);
    }

    void processBlock(float* left, float* right, int numSamples) noexcept {
        for (int i = 0; i < numSamples; ++i) {
            process(left[i], right[i], left[i], right[i]);
        }
    }

private:
    float m_sampleRate;
    float m_lowResReduction{0.0f};
    float m_midResReduction{0.0f};
    float m_highResReduction{0.0f};
    float m_alphaLow{0.02f};
    float m_alphaMid{0.05f};
    float m_alphaHigh{0.10f};
    float m_compThresholdDb{0.0f};
    float m_gateThresholdDb{-80.0f};
    float m_outputCeiling{1.0f};
    float m_autoMakeup{1.0f};

    struct BiquadBandpass {
        float b0{1}, b1{0}, b2{0}, a1{0}, a2{0};
        float z1{0}, z2{0};
        inline float process(float in) noexcept {
            float out = b0 * in + z1;
            z1 = b1 * in - a1 * out + z2;
            z2 = b2 * in - a2 * out;
            return out;
        }
        void reset() noexcept { z1 = 0.0f; z2 = 0.0f; }
    };

    BiquadBandpass m_bpLow;
    BiquadBandpass m_bpMid;
    BiquadBandpass m_bpHigh;

    float m_lowResEnv{0.0f};
    float m_midResEnv{0.0f};
    float m_highResEnv{0.0f};
    float m_rvoxCompEnv{0.0f};
    float m_rvoxGateEnv{0.0f};

    void resetFilters() noexcept {
        m_bpLow.reset(); m_bpMid.reset(); m_bpHigh.reset();
    }

    void updateFilters() noexcept {
        auto calcBP = [this](BiquadBandpass& b, float centerFreq, float q) {
            float omega = 2.0f * 3.14159265f * centerFreq / m_sampleRate;
            float alpha = std::sin(omega) / (2.0f * q);
            float a0 = 1.0f + alpha;
            b.b0 = alpha / a0;
            b.b1 = 0.0f;
            b.b2 = -alpha / a0;
            b.a1 = (-2.0f * std::cos(omega)) / a0;
            b.a2 = (1.0f - alpha) / a0;
        };

        calcBP(m_bpLow, 350.0f, 2.0f);   // 350 Hz mud/boxiness
        calcBP(m_bpMid, 2800.0f, 2.5f);  // 2.8 kHz nasal/bite
        calcBP(m_bpHigh, 7500.0f, 2.0f); // 7.5 kHz harsh sibilance
    }
};

} // namespace dsp171
