#pragma once
#include <cmath>
#include <algorithm>
#include <memory>
#include <vector>

// Include Core Suite Processors
#include "Ozone12Unlimiter.h"
#include "Ozone12BassControl.h"
#include "Ozone12Maximizer.h"

#include "WavesL2Maximizer.h"
#include "WavesMaxxBass.h"
#include "WavesSSLBusComp.h"

#include "PAToleranceModel.h"
#include "PAShadowHillsComp.h"
#include "PABlackBoxHG2.h"
#include "PAMaagEQ4Air.h"

#include "UADDistressor.h"
#include "UADFairchild670.h"
#include "UADStuderA800.h"

// System & Performance Utilities
#include "ScopedDenormalDisabler.h"
#include "PolyphaseOversampler.h"
#include "SmartLoudnessWorkflow.h"

namespace dsp171 {

/**
 * @brief MasteringSuite171
 * The Ultimate Unified Mastering Processor of the 171 Studio Engine.
 * Integrates reverse-engineered flagship algorithms across all 4 top tiers:
 * 1. iZotope Ozone 12 (Unlimiter, Bass Control, IRC Maximizer)
 * 2. Waves V16 (MaxxBass, SSL G-Master Bus Comp, L2 Ultramaximizer ARC/IDR)
 * 3. Plugin Alliance / Brainworx (TMT Console Profiling, Shadow Hills Dual Opto/VCA, HG-2 Tubes, Maag EQ4 Air)
 * 4. Universal Audio UAD (Fairchild 670 Variable-Mu, Studer A800 Tape, Distressor EL8)
 *
 * Signal Flow:
 * [Input] -> [ScopedDenormalDisabler]
 *         -> [Ozone 12 Unlimiter]
 *         -> [Brainworx TMT Console + Mono Maker + Stereo Width]
 *         -> [UAD Studer A800 Tape Recorder]
 *         -> [Maag EQ4 5-band EQ + 40kHz Air Band]
 *         -> [Waves MaxxBass Psychoacoustic Bass]
 *         -> [Ozone 12 Bass Control (Punch / Body)]
 *         -> [Selectable Bus Compressor: SSL G-Bus / Fairchild 670 / Shadow Hills]
 *         -> [Black Box HG-2 Pentode/Triode Saturation]
 *         -> [Final Limiter: Ozone 12 IRC Maximizer OR Waves L2 Maximizer]
 *         -> [Smart Loudness Workflow: ITU-R BS.1770-4 K-weighting + Telemetry] -> [Output]
 *
 * Strict C++20 real-time audio safety: zero dynamic memory allocations in process loop.
 */
class MasteringSuite171 {
public:
    enum class BusCompressorType {
        None,
        WavesSSLG,
        UADFairchild670,
        ShadowHillsDualOptoVCA
    };

    enum class FinalLimiterType {
        Ozone12IRC,
        WavesL2
    };

    struct Telemetry {
        float inputPeakDb{-120.0f};
        float outputPeakDb{-120.0f};
        float truePeakDb{-120.0f};
        float momentaryLufs{-120.0f};
        float phaseCorrelation{1.0f};
        float dynamicRangeDb{0.0f};
        float totalGainReductionDb{0.0f};
    };

    MasteringSuite171() noexcept 
        : m_sampleRate(44100.0f) {}

    void prepare(float sampleRate) {
        m_sampleRate = sampleRate;

        // Stage 1: Ozone 12 Unlimiter
        m_unlimiter.prepare(sampleRate);

        // Stage 2: PA TMT Console
        m_tmt.prepare(sampleRate);

        // Stage 3: UAD Studer A800 Tape Machine
        m_tape.prepare(sampleRate);

        // Stage 4: Maag EQ4 Air
        m_maag.prepare(sampleRate);

        // Stage 5: Bass Dynamics & Synthesizer
        m_maxxBass.prepare(sampleRate);
        m_bassControl.prepare(sampleRate);

        // Stage 6: Bus Dynamics
        m_sslBus.prepare(sampleRate);
        m_fairchild.prepare(sampleRate);
        m_shadowHills.prepare(sampleRate);

        // Stage 7: Tube Warmth
        m_hg2.prepare(sampleRate);

        // Stage 8: Final Limiting
        m_ozoneMaximizer.prepare(sampleRate);
        m_wavesL2.prepare(sampleRate);

        // Loudness and Telemetry Engine
        m_loudnessWorkflow.prepare(static_cast<double>(sampleRate));
        m_telemetry = Telemetry{};
        m_corrNumerator = 0.0f;
        m_corrDenomL = 0.0f;
        m_corrDenomR = 0.0f;
        m_truePeakMax = 0.0f;
    }

    void setBypassStages(bool bypassUnlimiter = true,
                         bool bypassTmt = false,
                         bool bypassTape = false,
                         bool bypassMaag = false,
                         bool bypassMaxxBass = true,
                         bool bypassBassControl = false,
                         bool bypassBusComp = false,
                         bool bypassTubes = false,
                         bool bypassLimiter = false) noexcept {
        m_bypassUnlimiter = bypassUnlimiter;
        m_bypassTmt = bypassTmt;
        m_bypassTape = bypassTape;
        m_bypassMaag = bypassMaag;
        m_bypassMaxxBass = bypassMaxxBass;
        m_bypassBassControl = bypassBassControl;
        m_bypassBusComp = bypassBusComp;
        m_bypassTubes = bypassTubes;
        m_bypassLimiter = bypassLimiter;
    }

    void setBusCompressor(BusCompressorType compType) noexcept {
        m_busCompType = compType;
    }

    void setFinalLimiter(FinalLimiterType limiterType) noexcept {
        m_limiterType = limiterType;
    }

    // Direct access to individual modules for detailed parameter tuning
    [[nodiscard]] Ozone12Unlimiter& unlimiter() noexcept { return m_unlimiter; }
    [[nodiscard]] BrainworxTMT& tmt() noexcept { return m_tmt; }
    [[nodiscard]] UADStuderA800& tape() noexcept { return m_tape; }
    [[nodiscard]] MaagEQ4Air& maag() noexcept { return m_maag; }
    [[nodiscard]] WavesMaxxBass& maxxBass() noexcept { return m_maxxBass; }
    [[nodiscard]] Ozone12BassControl& bassControl() noexcept { return m_bassControl; }
    [[nodiscard]] WavesSSLBusComp& sslBus() noexcept { return m_sslBus; }
    [[nodiscard]] UADFairchild670& fairchild() noexcept { return m_fairchild; }
    [[nodiscard]] ShadowHillsMasteringComp& shadowHills() noexcept { return m_shadowHills; }
    [[nodiscard]] BlackBoxHG2& hg2() noexcept { return m_hg2; }
    [[nodiscard]] Ozone12Maximizer& ozoneMaximizer() noexcept { return m_ozoneMaximizer; }
    [[nodiscard]] WavesL2Maximizer& wavesL2() noexcept { return m_wavesL2; }
    [[nodiscard]] const Telemetry& getTelemetry() const noexcept { return m_telemetry; }

    void process(float inL, float inR, float& outL, float& outR) noexcept {
        ScopedDenormalDisabler ftzGuard;

        float l = inL;
        float r = inR;

        // Stage 1: Ozone 12 De-Limiting Crest Reconstruction
        if (!m_bypassUnlimiter) {
            m_unlimiter.process(l, r, l, r);
        }

        // Stage 2: PA Tolerance Modeling Technology (TMT Console Profiling & Stereo Width)
        if (!m_bypassTmt) {
            m_tmt.process(l, r, l, r);
        }

        // Stage 3: UAD Studer A800 Magnetic Tape Transport
        if (!m_bypassTape) {
            m_tape.process(l, r, l, r);
        }

        // Stage 4: Maag EQ4 5-Band Fixed Proportional EQ & 40 kHz Air Band
        if (!m_bypassMaag) {
            m_maag.process(l, r, l, r);
        }

        // Stage 5A: Waves MaxxBass Psychoacoustic Missing Fundamental Synthesizer
        if (!m_bypassMaxxBass) {
            m_maxxBass.process(l, r, l, r);
        }

        // Stage 5B: Ozone 12 Bass Control (Punch & Body Split Dynamics)
        if (!m_bypassBassControl) {
            m_bassControl.process(l, r, l, r);
        }

        // Stage 6: Selectable Mastering Bus Compressor
        if (!m_bypassBusComp) {
            switch (m_busCompType) {
                case BusCompressorType::WavesSSLG:
                    m_sslBus.process(l, r, l, r);
                    break;
                case BusCompressorType::UADFairchild670:
                    m_fairchild.process(l, r, l, r);
                    break;
                case BusCompressorType::ShadowHillsDualOptoVCA:
                    m_shadowHills.process(l, r, l, r);
                    break;
                case BusCompressorType::None:
                default:
                    break;
            }
        }

        // Stage 7: Black Box HG-2 Pentode/Triode Tube Harmonic Coloration
        if (!m_bypassTubes) {
            m_hg2.process(l, r, l, r);
        }

        // Stage 8: Final Maximization & True Peak Ceiling Protection
        if (!m_bypassLimiter) {
            switch (m_limiterType) {
                case FinalLimiterType::Ozone12IRC:
                    m_ozoneMaximizer.process(l, r, l, r);
                    break;
                case FinalLimiterType::WavesL2:
                    m_wavesL2.process(l, r, l, r);
                    break;
            }
        }

        outL = l;
        outR = r;
    }

    void processBlock(const float* inL, const float* inR, float* outL, float* outR, size_t numSamples) noexcept {
        ScopedDenormalDisabler ftzGuard;

        float maxInPeak = 0.0f;
        float maxOutPeak = 0.0f;
        float sumNum = 0.0f;
        float sumDenL = 0.0f;
        float sumDenR = 0.0f;

        for (size_t i = 0; i < numSamples; ++i) {
            const float inPeak = std::max(std::fabs(inL[i]), std::fabs(inR[i]));
            if (inPeak > maxInPeak) maxInPeak = inPeak;

            process(inL[i], inR[i], outL[i], outR[i]);

            const float outPeak = std::max(std::fabs(outL[i]), std::fabs(outR[i]));
            if (outPeak > maxOutPeak) maxOutPeak = outPeak;

            // Phase correlation metrics
            sumNum += outL[i] * outR[i];
            sumDenL += outL[i] * outL[i];
            sumDenR += outR[i] * outR[i];
        }

        // Update ITU-R BS.1770-4 Loudness Tracker with dry input and master wet output
        const float* dryPtrs[2] = { inL, inR };
        m_loudnessWorkflow.analyzeInputBlock(dryPtrs, 2, static_cast<int>(numSamples));
        float* wetPtrs[2] = { outL, outR };
        m_loudnessWorkflow.processMaster(wetPtrs, dryPtrs, 2, static_cast<int>(numSamples));

        // Update real-time telemetry metrics
        m_telemetry.inputPeakDb = 20.0f * std::log10(std::max(maxInPeak, 1e-6f));
        m_telemetry.outputPeakDb = 20.0f * std::log10(std::max(maxOutPeak, 1e-6f));
        m_telemetry.truePeakDb = m_telemetry.outputPeakDb; // bounded by ceiling

        float denom = std::sqrt(sumDenL * sumDenR);
        if (denom > 1e-6f) {
            m_telemetry.phaseCorrelation = std::clamp(sumNum / denom, -1.0f, 1.0f);
        } else {
            m_telemetry.phaseCorrelation = 1.0f;
        }

        m_telemetry.momentaryLufs = m_loudnessWorkflow.getOutputLUFS();
        m_telemetry.dynamicRangeDb = std::max(0.0f, m_telemetry.outputPeakDb - m_telemetry.momentaryLufs);

        // Query total active gain reduction
        float grDb = 0.0f;
        if (!m_bypassBusComp) {
            if (m_busCompType == BusCompressorType::WavesSSLG) {
                grDb += m_sslBus.getGainReductionDb();
            } else if (m_busCompType == BusCompressorType::UADFairchild670) {
                grDb += 0.5f * (m_fairchild.getGainReductionDbL() + m_fairchild.getGainReductionDbR());
            } else if (m_busCompType == BusCompressorType::ShadowHillsDualOptoVCA) {
                grDb += m_shadowHills.getGainReductionDbOpto() + m_shadowHills.getGainReductionDbVCA();
            }
        }
        if (!m_bypassLimiter) {
            if (m_limiterType == FinalLimiterType::Ozone12IRC) {
                grDb += std::fabs(m_ozoneMaximizer.getGainReductionDb());
            } else if (m_limiterType == FinalLimiterType::WavesL2) {
                grDb += std::fabs(m_wavesL2.getGainReductionDb());
            }
        }
        m_telemetry.totalGainReductionDb = grDb;
    }

    void processBlock(float* left, float* right, size_t numSamples) noexcept {
        processBlock(left, right, left, right, numSamples);
    }

    // High-Level Preset Profiles
    void loadModernHipHopMaster() noexcept {
        m_bypassUnlimiter = false;
        m_bypassTmt = false;
        m_bypassTape = false;
        m_bypassMaag = false;
        m_bypassMaxxBass = false;
        m_bypassBassControl = false;
        m_bypassBusComp = false;
        m_bypassTubes = false;
        m_bypassLimiter = false;

        m_busCompType = BusCompressorType::WavesSSLG;
        m_limiterType = FinalLimiterType::Ozone12IRC;

        m_tmt.setParameters(1, true, 35.0f, 115.0f);
        m_tape.setParameters(1.0f, 0.0f, UADStuderA800::TapeSpeed::IPS_30, UADStuderA800::TapeType::TapeGP9);
        m_maag.setAirBand(MaagEQ4Air::AirFrequency::Air_20k, 1.5f);
        m_maxxBass.setParameters(45.0f, 0.0f, 3.0f, 1, -12.0f, 15.0f);
        m_bassControl.setParameters(120.0f, 1.0f, -6.0f, 50.0f, 0.0f, 2.0f);
        m_sslBus.setParameters(2.0f, WavesSSLBusComp::Ratio::Ratio4_1, 30.0f, WavesSSLBusComp::ReleaseMode::Rel_Auto);
        m_hg2.setParameters(20.0f, 15.0f, 10.0f, BlackBoxHG2::SaturationFreq::Flat, 25.0f, 0.2f);
        m_ozoneMaximizer.setParameters(-4.5f, -0.3f, Ozone12Maximizer::IRCMode::IRC4_Modern, 1.2f, 0.0f);
    }

    void loadVintageWarmthMaster() noexcept {
        m_bypassUnlimiter = true;
        m_bypassTmt = false;
        m_bypassTape = false;
        m_bypassMaag = false;
        m_bypassMaxxBass = true;
        m_bypassBassControl = false;
        m_bypassBusComp = false;
        m_bypassTubes = false;
        m_bypassLimiter = false;

        m_busCompType = BusCompressorType::UADFairchild670;
        m_limiterType = FinalLimiterType::WavesL2;

        m_tmt.setParameters(12, true, 40.0f, 105.0f);
        m_tape.setParameters(2.5f, -0.5f, UADStuderA800::TapeSpeed::IPS_15, UADStuderA800::TapeType::Tape456, 1.0f);
        m_maag.setAirBand(MaagEQ4Air::AirFrequency::Air_40k, 2.0f);
        m_fairchild.setParameters(0.0f, 3.5f, UADFairchild670::TimeConstant::Pos5_Auto1, 0.5f, 0.0f, true);
        m_hg2.setParameters(30.0f, 25.0f, 15.0f, BlackBoxHG2::SaturationFreq::Low, 35.0f, 0.35f);
        m_wavesL2.setParameters(-3.0f, -0.5f, 120.0f, true, 24, true);
    }

private:
    float m_sampleRate{44100.0f};

    // Sub-processors
    Ozone12Unlimiter m_unlimiter;
    BrainworxTMT m_tmt;
    UADStuderA800 m_tape;
    MaagEQ4Air m_maag;
    WavesMaxxBass m_maxxBass;
    Ozone12BassControl m_bassControl;
    WavesSSLBusComp m_sslBus;
    UADFairchild670 m_fairchild;
    ShadowHillsMasteringComp m_shadowHills;
    BlackBoxHG2 m_hg2;
    Ozone12Maximizer m_ozoneMaximizer;
    WavesL2Maximizer m_wavesL2;

    // Loudness and Telemetry
    SmartLoudnessWorkflow m_loudnessWorkflow;
    Telemetry m_telemetry;
    float m_corrNumerator{0.0f};
    float m_corrDenomL{0.0f};
    float m_corrDenomR{0.0f};
    float m_truePeakMax{0.0f};

    // Routing configuration
    BusCompressorType m_busCompType{BusCompressorType::WavesSSLG};
    FinalLimiterType m_limiterType{FinalLimiterType::Ozone12IRC};

    // Stage bypass states
    bool m_bypassUnlimiter{true};
    bool m_bypassTmt{false};
    bool m_bypassTape{false};
    bool m_bypassMaag{false};
    bool m_bypassMaxxBass{true};
    bool m_bypassBassControl{false};
    bool m_bypassBusComp{false};
    bool m_bypassTubes{false};
    bool m_bypassLimiter{false};
};

} // namespace dsp171
