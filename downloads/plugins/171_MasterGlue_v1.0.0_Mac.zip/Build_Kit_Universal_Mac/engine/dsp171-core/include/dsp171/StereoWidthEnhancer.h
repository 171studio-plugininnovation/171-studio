#pragma once
#include <cmath>
#include <array>
#include <algorithm>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// StereoWidthEnhancer
// Processore di ampiezza stereofonica Mid/Side con decorrelazione psicoacustica
// mono-compatibile (100% Mono Cancellation-Free).
//
// Specifiche Tecniche e Matematiche ispirate a Melda MAutoPitch:
// 1. Range di ampiezza stereo: 0% (Full Mono) -> 100% (Stereo invariato) -> 200% (Super-Wide).
// 2. Mono-compatibility assoluta:
//    L_out = M + w * S_orig + S_synth
//    R_out = M - w * S_orig - S_synth
//    Sum Mono = 0.5 * (L_out + R_out) = M IDENTICAMENTE.
//    Qualsiasi componente generata in S_synth si cancella algebricamente al 100%
//    nel sommatore mono (-144 dBFS, precisione macchina floating point IEEE-754).
//    Zero comb-filtering e zero distorsione di fase sul canale centrale vocale.
// 3. Decorrelatore Psicoacustico Lattice All-Pass:
//    Su tracce vocali mono (L == R, S_orig == 0), il widening convenzionale M/S
//    fallisce (S * w = 0). Questo modulo sintetizza un canale Side psicoacustico
//    diffuso attraverso una rete di 4 all-pass disaccoppiati in fase (lattice)
//    e micro-ritardo temporale asimmetrico (< 1.5 ms), creando un'immagine 3D
//    spaziale avvolgente per voci soliste e cori.
// 4. Mono-Maker Crossover (120 Hz ZDF 2nd-order Butterworth High-Pass):
//    Le frequenze sotto 120 Hz vengono forzate rigorosamente a mono (S -> 0),
//    garantendo la massima focalizzazione del punch e l'assenza di controfase sui bassi.
// 5. Zero allocazioni heap, real-time safe e noexcept.
// =============================================================================
class StereoWidthEnhancer {
public:
    StereoWidthEnhancer() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        invSr = 1.0f / sr;

        // Inizializza i coefficienti dei 4 all-pass a fase disaccoppiata
        // Frequenze caratteristiche scelte con rapporti incommensurabili per evitare risonanze
        setupAllPass(apStages[0], 280.0f);
        setupAllPass(apStages[1], 850.0f);
        setupAllPass(apStages[2], 2300.0f);
        setupAllPass(apStages[3], 5600.0f);

        // Inizializza il filtro Mono-Maker passa-alto a 120 Hz (ZDF 2nd-order SVF)
        setupMonoMaker(120.0f);

        // Parametro di lisciamento esponenziale (~15 ms time constant)
        smoothCoeff = std::clamp(1.0f - std::exp(-1.0f / (0.015f * sr)), 0.001f, 0.1f);

        reset();
    }

    void reset() noexcept {
        for (auto& stage : apStages) {
            stage.s = 0.0f;
        }

        // Reset buffer circolare micro-ritardo (128 campioni ~ 2.6 ms a 48 kHz)
        delayBuffer.fill(0.0f);
        delayWriteIdx = 0;

        // Reset stati Mono-Maker
        svfS1 = 0.0f;
        svfS2 = 0.0f;

        currentWidth = targetWidth;
        smoothedSideGain = 1.0f;
        smoothedSynthGain = 0.0f;
    }

    // Imposta la larghezza stereo in percentuale [0.0% .. 200.0%]
    //   0.0%   = Mono puro (L = R = M)
    // 100.0%   = Larghezza originale invariata
    // 200.0%   = Super-Wide stereo (Side boost + decorrelazione psicoacustica)
    void setWidth(float widthPercent) noexcept {
        targetWidth = std::clamp(widthPercent * 0.01f, 0.0f, 2.0f);
    }

    [[nodiscard]] float getWidth() const noexcept {
        return targetWidth * 100.0f;
    }

    // Elabora un singolo campione stereo (L, R) in-place o con ritorno di coppia
    inline void processSample(float inL, float inR, float& outL, float& outR) noexcept {
        // Fast-path bit-exact passthrough se larghezza a 100% (default originale intatto: zero alterazioni di fase)
        if (std::abs(targetWidth - 1.0f) < 0.001f && std::abs(currentWidth - 1.0f) < 0.001f) {
            outL = inL;
            outR = inR;
            return;
        }

        // Aggiorna lo smoothing continuo dei guadagni per evitare qualsiasi zipper noise
        currentWidth += smoothCoeff * (targetWidth - currentWidth);

        // Calcolo dei guadagni M/S:
        // Se currentWidth <= 1.0: scaling convenzionale da 0 a 1 del Side esistente
        // Se currentWidth > 1.0: boost del Side fino a 2.0 e iniezione progressiva del decorrelatore
        float sideScale = currentWidth;
        float synthScale = 0.0f;

        if (currentWidth > 1.0f) {
            // Guadagno progressivo della componente psicoacustica decorrelata [0.0 .. 0.45]
            synthScale = 0.45f * (currentWidth - 1.0f);
        }

        // 1. Matrice Mid/Side
        // M = 0.5 * (L + R)
        // S = 0.5 * (L - R)
        const float mid = 0.5f * (inL + inR);
        const float sideOrig = 0.5f * (inL - inR);

        // 2. Generazione del canale Side Psicoacustico Decorrelato da M (Zero comb-filtering)
        // A) Micro-delay di 48 campioni (~1.0 ms a 48 kHz)
        delayBuffer[delayWriteIdx & DELAY_MASK] = mid;
        constexpr size_t delayOffset = 48;
        const float delayedMid = delayBuffer[(delayWriteIdx - delayOffset) & DELAY_MASK];
        delayWriteIdx++;

        // B) Cascata di 4 filtri All-Pass per dispersione di fase a risposta in modulo rigorosamente piatta (|H(w)| == 1.0)
        float apSig = delayedMid;
        for (auto& ap : apStages) {
            apSig = processAllPass(ap, apSig);
        }

        // 3. Mono-Maker: Filtro passa-alto ZDF di 2° ordine a 120 Hz applicato al Side
        // Garantisce che sotto i 120 Hz il segnale sia rigorosamente mono (Side = 0)
        const float sideOrigFiltered = processMonoMaker(sideOrig);
        const float sideSynthFiltered = processMonoMaker(apSig);

        // 4. Somma delle componenti Side (Esistente scalato + Psicoacustico decorrelato)
        const float totalSide = (sideOrigFiltered * sideScale) + (sideSynthFiltered * synthScale);

        // 5. Ricostruzione Matrice Stereo Inversa
        // L_out = M + totalSide
        // R_out = M - totalSide
        //
        // DIMOSTRAZIONE DI MONO-COMPATIBILITÀ ASSOLUTA (CANCELLAZIONE 100%):
        // Mono Sum = 0.5 * (L_out + R_out)
        //          = 0.5 * [(M + totalSide) + (M - totalSide)]
        //          = 0.5 * [2 * M + 0]
        //          = M
        // Q.E.D. Nessuna alterazione o cancellazione spettrale in mono!
        outL = mid + totalSide;
        outR = mid - totalSide;
    }

    // Elabora un blocco audio stereo in-place
    void processBlock(float* left, float* right, size_t numSamples) noexcept {
        if (left == nullptr || right == nullptr || numSamples == 0) return;

        for (size_t i = 0; i < numSamples; ++i) {
            processSample(left[i], right[i], left[i], right[i]);
        }
    }

private:
    struct AllPassStage {
        float b0 = 1.0f;
        float b1 = 0.0f;
        float a1 = 0.0f;
        float s = 0.0f;
    };

    void setupAllPass(AllPassStage& stage, float fc) noexcept {
        const float clampedFc = std::clamp(fc, 20.0f, sr * 0.45f);
        // Filtro all-pass del 1° ordine con bilineare: H(s) = (s - w0) / (s + w0)
        const float t = std::tan(PI * clampedFc * invSr);
        const float alpha = (t - 1.0f) / (t + 1.0f);
        stage.b0 = alpha;
        stage.b1 = 1.0f;
        stage.a1 = alpha;
        stage.s = 0.0f;
    }

    static inline float processAllPass(AllPassStage& stage, float in) noexcept {
        // Transposed Direct Form II
        const float y = in * stage.b0 + stage.s;
        stage.s = in * stage.b1 - y * stage.a1;
        return y;
    }

    void setupMonoMaker(float fc) noexcept {
        const float clampedFc = std::clamp(fc, 20.0f, sr * 0.45f);
        svfG = std::tan(PI * clampedFc * invSr);
        constexpr float q = 0.70710678f; // Butterworth Q
        svfR = 1.0f / (2.0f * q);
        svfH = 1.0f / (1.0f + 2.0f * svfR * svfG + svfG * svfG);
    }

    inline float processMonoMaker(float in) noexcept {
        // ZDF State Variable Filter - Uscita Passa-Alto (HP)
        const float hp = (in - (2.0f * svfR + svfG) * svfS1 - svfS2) * svfH;
        const float v1 = svfG * hp;
        const float bp = v1 + svfS1;
        svfS1 = v1 + bp;
        const float v2 = svfG * bp;
        const float lp = v2 + svfS2;
        svfS2 = v2 + lp;

        // Anti-denormal
        if (std::abs(svfS1) < 1.0e-20f) svfS1 = 0.0f;
        if (std::abs(svfS2) < 1.0e-20f) svfS2 = 0.0f;

        return hp;
    }

    float sr = 48000.0f;
    float invSr = 1.0f / 48000.0f;

    float targetWidth = 1.0f; // 100%
    float currentWidth = 1.0f;
    float smoothCoeff = 0.01f;

    float smoothedSideGain = 1.0f;
    float smoothedSynthGain = 0.0f;

    // Rete All-Pass
    std::array<AllPassStage, 4> apStages{};

    // Buffer circolare micro-ritardo
    static constexpr size_t DELAY_SIZE = 128;
    static constexpr size_t DELAY_MASK = DELAY_SIZE - 1;
    std::array<float, DELAY_SIZE> delayBuffer{};
    size_t delayWriteIdx = 0;

    // Parametri e stati Mono-Maker ZDF SVF
    float svfG = 0.0f;
    float svfR = 0.5f;
    float svfH = 0.0f;
    float svfS1 = 0.0f;
    float svfS2 = 0.0f;
};

} // namespace dsp171
