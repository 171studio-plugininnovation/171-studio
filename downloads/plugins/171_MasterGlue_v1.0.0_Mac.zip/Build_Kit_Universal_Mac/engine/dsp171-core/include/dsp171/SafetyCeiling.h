#pragma once
#include <cmath>
#include <algorithm>
#include <array>

namespace dsp171 {

// =============================================================================
// Analog Safety Brickwall Soft-Ceiling a -0.09 dBFS (0.9900 max peak)
// Lineare fino a |x| <= 0.85; gomito morbido tanh asintotico a 0.9900 oltre 0.85.
// =============================================================================
inline float applySafetyCeiling(float x) noexcept {
    if (!std::isfinite(x)) return 0.0f;
    constexpr float threshold = 0.85f;
    constexpr float knee      = 0.14f; // 0.85 + 0.14 = 0.9900 max peak (-0.09 dBFS)

    const float absVal = std::abs(x);
    if (absVal <= threshold) return x;

    const float satMag = threshold + knee * std::tanh((absVal - threshold) / knee);
    const float outVal = (x > 0.0f) ? satMag : -satMag;
    return std::clamp(outVal, -0.9900f, 0.9900f);
}

// =============================================================================
// True-Peak Lookahead Limiter Conforme a ITU-R BS.1770-4
// Ricostruzione 4x a filtri polifase sinc (32 tap, 4 fasi da 8 tap con finestra Kaiser beta=7.0).
// Elimina alla radice qualsiasi errore di sotto-stima dei picchi inter-sample (ISP).
// Supporta stereo linking totale per preservare l'immagine del phantom center.
// =============================================================================
class TruePeakLimiter {
public:
    static constexpr size_t LookaheadLatency = 4; // Latenza di lookahead deterministica

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        // Rilascio trasparente a 35 ms (curva mastering priva di pumping)
        alphaRel = 1.0f - std::exp(-1.0f / (0.035f * sr));
        reset();
    }

    void reset() noexcept {
        delayBuffer.fill(0.0f);
        writeIdx = 0;
        envGain = 1.0f;
    }

    // Calcola il picco inter-sample massimo ricostruito (4x oversampled ITU-R BS.1770)
    inline float computeTruePeak(float in, float& outDelayedSample) noexcept {
        delayBuffer[writeIdx] = in;

        // Estrazione ordinata degli 8 campioni più recenti nel buffer circolare
        std::array<float, 8> x{};
        for (size_t k = 0; k < 8; ++k) {
            const size_t rIdx = (writeIdx + 8 - k) & 7;
            x[k] = delayBuffer[rIdx];
        }

        // Il campione al centro del filtro polifase ha ritardo di 4 campioni
        outDelayedSample = x[4];
        writeIdx = (writeIdx + 1) & 7;

        // Coefficienti filtro polifase sinc 4x con finestra Kaiser (beta=7.0)
        constexpr std::array<float, 8> p0 = { -0.00018644f,  0.00521061f, -0.02906569f,  0.11777836f,  0.97115730f, -0.08195030f,  0.02000363f, -0.00294746f };
        constexpr std::array<float, 8> p1 = { -0.00155133f,  0.02068537f, -0.09984114f,  0.43225564f,  0.76068446f, -0.14046621f,  0.03224937f, -0.00362388f };
        constexpr std::array<float, 8> p2 = { -0.00362388f,  0.03224937f, -0.14046621f,  0.76068446f,  0.43225564f, -0.09984114f,  0.02068537f, -0.00155133f };
        constexpr std::array<float, 8> p3 = { -0.00294746f,  0.02000363f, -0.08195030f,  0.97115730f,  0.11777836f, -0.02906569f,  0.00521061f, -0.00018644f };

        float s0 = 0.0f, s1 = 0.0f, s2 = 0.0f, s3 = 0.0f;
        for (size_t k = 0; k < 8; ++k) {
            s0 += x[k] * p0[k];
            s1 += x[k] * p1[k];
            s2 += x[k] * p2[k];
            s3 += x[k] * p3[k];
        }

        return std::max({ std::abs(s0), std::abs(s1), std::abs(s2), std::abs(s3), std::abs(in) });
    }

    inline static float ceilingDbToLinear(float db) noexcept {
        if (std::abs(db - (-0.10f)) < 0.001f) return 0.9885530946569388f; // -0.10 dBTP fast path
        return std::pow(10.0f, db * 0.05f);
    }

    // Processamento Mono Singolo Canale
    inline float processSample(float in, float ceilingDb = -0.10f) noexcept {
        if (!std::isfinite(in)) in = 0.0f;
        float delayed = 0.0f;
        const float peak = computeTruePeak(in, delayed);
        const float targetCeil = ceilingDbToLinear(ceilingDb);

        float targetGain = 1.0f;
        if (peak > targetCeil) {
            targetGain = targetCeil / peak;
        }

        if (targetGain < envGain) {
            envGain = targetGain;
        } else {
            envGain += alphaRel * (targetGain - envGain);
        }

        if (std::abs(delayed) < 1.0e-25f) delayed = 0.0f;
        const float outSample = delayed * envGain;
        return std::clamp(outSample, -targetCeil, targetCeil);
    }

    // Processamento Stereo con Stereo Linking Totale (100% Soundstage Integrity)
    static inline void processStereoPair(TruePeakLimiter& left, TruePeakLimiter& right,
                                         float inL, float inR, float& outL, float& outR,
                                         float ceilingDb = -0.10f) noexcept
    {
        if (!std::isfinite(inL)) inL = 0.0f;
        if (!std::isfinite(inR)) inR = 0.0f;
        float delayedL = 0.0f;
        float delayedR = 0.0f;
        const float peakL = left.computeTruePeak(inL, delayedL);
        const float peakR = right.computeTruePeak(inR, delayedR);

        // Collegamento stereo: il picco massimo tra L ed R pilota entrambi i canali
        const float stereoMaxPeak = std::max(peakL, peakR);
        const float targetCeil = ceilingDbToLinear(ceilingDb);

        float targetGain = 1.0f;
        if (stereoMaxPeak > targetCeil) {
            targetGain = targetCeil / stereoMaxPeak;
        }

        // Entrambi gli inviluppi seguono lo stesso guadagno sincronizzato
        if (targetGain < left.envGain) {
            left.envGain = targetGain;
        } else {
            left.envGain += left.alphaRel * (targetGain - left.envGain);
        }
        right.envGain = left.envGain;

        if (std::abs(delayedL) < 1.0e-25f) delayedL = 0.0f;
        if (std::abs(delayedR) < 1.0e-25f) delayedR = 0.0f;
        outL = std::clamp(delayedL * left.envGain, -targetCeil, targetCeil);
        outR = std::clamp(delayedR * left.envGain, -targetCeil, targetCeil);
    }

    float getLatencyInSamples() const noexcept {
        return static_cast<float>(LookaheadLatency);
    }

private:
    float sr = 44100.0f;
    float alphaRel = 0.001f;
    float envGain = 1.0f;
    std::array<float, 8> delayBuffer{ 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
    size_t writeIdx = 0;
};

} // namespace dsp171
