#pragma once
#include <cmath>
#include <algorithm>
#include <cstdint>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// IEC 60268-17 & ANSI C16.5-1954 Standard Physical VU Meter Ballistics Engine
//
// Designed under Agente 29 (gui-mathematician) & Agente 05 (boutique-gui-specialist).
//
// Mechanical Moving-Coil Equation of Motion:
//   d2theta/dt2 + 2 * zeta * omega0 * dtheta/dt + omega0^2 * theta = omega0^2 * T_mag(t)
//
// Calibration Constants:
// - Standard Integration Time: 300 ms to reach 99% deflection on 1 kHz tone burst.
// - Standard Overshoot: 1.0% - 1.5% (zeta = 0.7071 critical mechanical damping).
// - Calibration: Selectable -18 dBFS, -14 dBFS, -10 dBFS = 0 VU (100% deflection).
// - True Peak Overload LED: 1 ms instantaneous attack, 1.5 s peak hold.
// =============================================================================
class BoutiqueVUBallistics {
public:
    enum class Calibration : uint8_t {
        Minus18dBFS = 0, // EBU / Broadcast standard
        Minus14dBFS,     // Tracking / Pro Tools standard
        Minus10dBFS      // Mastering / High density standard
    };

    enum class Mode : uint8_t {
        VU = 0,         // Audio signal level (left to right)
        GainReduction   // Attenuation (0 dB rest on right, deflects left)
    };

    BoutiqueVUBallistics() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        invSr = 1.0f / sr;
        dt = invSr;

        // Natural frequency omega0 = 2 * pi * 2.12 Hz for exact 300 ms rise time
        constexpr float f0 = 2.12f;
        const float omega0 = 2.0f * PI * f0;
        constexpr float zeta = 0.7071f; // Critical damping (1.0% - 1.5% overshoot)

        // ZDF SVF trapezoidal discretization parameters
        g = std::tan(omega0 * dt * 0.5f);
        k_damp = 2.0f * zeta;
        denom = 1.0f / (1.0f + g * (g + k_damp));

        // Peak LED detector coefficients (1 ms attack, 1.5 s release)
        peakAttackCoeff = 1.0f - std::exp(-dt / 0.001f);
        peakReleaseCoeff = 1.0f - std::exp(-dt / 1.500f);

        reset();
    }

    void reset() noexcept {
        s1 = 0.0f;
        s2 = 0.0f;
        pos = (currentMode == Mode::GainReduction) ? 1.0f : 0.0f;
        vel = 0.0f;
        peakLevel = 0.0f;
        peakHoldTimer = 0.0f;
        peakLedOn = false;
    }

    void setCalibration(Calibration cal) noexcept {
        calibration = cal;
        switch (calibration) {
            case Calibration::Minus18dBFS:
                refLevelLinear = 0.12589254f; // -18 dBFS
                break;
            case Calibration::Minus14dBFS:
                refLevelLinear = 0.19952623f; // -14 dBFS
                break;
            case Calibration::Minus10dBFS:
                refLevelLinear = 0.31622777f; // -10 dBFS
                break;
        }
    }

    void setMode(Mode m) noexcept {
        currentMode = m;
        reset();
    }

    // Process a single audio sample (full-wave rectified driving force)
    inline void processSample(float inSample) noexcept {
        const float absIn = std::abs(inSample);

        // --- 1. Peak LED Detector (Instantaneous trigger on overload >= -0.2 dBFS, 1.5s hold) ---
        if (absIn >= 0.9772f) {
            peakLevel = absIn;
            peakLedOn = true;
            peakHoldTimer = 1.5f;
        } else if (absIn > peakLevel) {
            peakLevel += peakAttackCoeff * (absIn - peakLevel);
        } else {
            peakLevel += peakReleaseCoeff * (absIn - peakLevel);
        }

        if (peakHoldTimer > 0.0f) {
            peakHoldTimer -= dt;
            if (peakHoldTimer <= 0.0f) peakLedOn = false;
        }

        // --- 2. Driving Force to Mechanical Galvanometer ---
        float drive = 0.0f;
        if (currentMode == Mode::VU) {
            // Full-wave rectified signal scaled to calibrated 0 VU RMS reference
            // Form factor pi / (2 * sqrt(2)) ~ 1.11072 calibrates average rectifier reading to RMS
            constexpr float kRectifierFormFactor = 1.11072073f;
            const float normalizedAmp = (absIn / refLevelLinear) * kRectifierFormFactor;
            // Linear scale deflection: 0 VU = 1.0, +3 VU = 1.412
            drive = std::clamp(normalizedAmp, 0.0f, 2.5f);
        } else {
            // Gain Reduction: 0 dB GR is at rest position 1.0 (right).
            // Input sample represents linear attenuation factor in [0.0 .. 1.0].
            drive = std::clamp(absIn, 0.0f, 1.0f);
        }

        // --- 3. ZDF SVF 2nd-Order Continuous ODE Step ---
        const float hp = (drive - k_damp * s1 - s2) * denom;
        const float bp = g * hp + s1;
        s1 = bp + g * hp;
        const float lp = g * bp + s2;
        s2 = lp + g * bp;

        pos = lp;
        vel = bp;

        // Mechanical bumper stops:
        // Left rest bumper at 0.0, right maximum travel bumper at 2.2 (+6 dBVU)
        if (pos < 0.0f) {
            pos = 0.0f;
            s1 = 0.0f;
            s2 = 0.0f;
        } else if (pos > 2.2f) {
            pos = 2.2f;
            s1 = 0.0f;
            s2 = 2.2f;
        }

        // Denormal guard
        if (std::abs(s1) < 1e-25f) s1 = 0.0f;
        if (std::abs(s2) < 1e-25f) s2 = 0.0f;
    }

    // Telemetry for GUI Thread (60 FPS poll)
    [[nodiscard]] float getDeflectionNormalized() const noexcept {
        return pos;
    }

    // Returns needle angle in degrees for rendering (-38° at rest, 0° at 0 VU, +16° at +3 VU)
    [[nodiscard]] float getNeedleAngleDegrees() const noexcept {
        if (currentMode == Mode::VU) {
            // 0 deflection = -38 deg
            // 1.0 deflection (0 VU) = 0 deg
            // 1.412 deflection (+3 VU) = +16 deg
            if (pos <= 1.0f) {
                return -38.0f + pos * 38.0f;
            } else {
                return (pos - 1.0f) * (16.0f / 0.412f);
            }
        } else {
            // Gain reduction: pos = 1.0 (0 dB GR) -> 0 deg; pos = 0.0 (-20 dB GR) -> -38 deg
            return -38.0f + pos * 38.0f;
        }
    }

    [[nodiscard]] bool isPeakLedActive() const noexcept {
        return peakLedOn;
    }

private:
    float sr{44100.0f};
    float invSr{1.0f / 44100.0f};
    float dt{1.0f / 44100.0f};

    float g{0.00015f};
    float k_damp{1.4142f};
    float denom{1.0f};

    float s1{0.0f};
    float s2{0.0f};
    float pos{0.0f};
    float vel{0.0f};

    Calibration calibration{Calibration::Minus18dBFS};
    Mode currentMode{Mode::VU};
    float refLevelLinear{0.12589254f}; // -18 dBFS

    float peakLevel{0.0f};
    float peakAttackCoeff{0.05f};
    float peakReleaseCoeff{0.0001f};
    float peakHoldTimer{0.0f};
    bool peakLedOn{false};
};

} // namespace dsp171
