#pragma once
#include <cmath>
#include <algorithm>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// Stereo-Linked, Phase-Coherent Transient / Tonal Splitter
// 1. Stereo-Linked Sidechain: Uses max-envelope linking across channels
//    to guarantee identical splitting weight w[n] for L and R, completely
//    eliminating phantom center yaw and stereo stage tearing.
// 2. 110 Hz High-Pass Sidechain: Prevents 40-60 Hz fundamental bass humps
//    from triggering false transient chops and intermodulation ripple.
// 3. Fast-attack transient preservation (< 1.2 ms) with anti-flutter decay.
// 4. Maintains single-channel processSample() for backward compatibility.
// =============================================================================
class TransientSplitter {
public:
    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        updateCoefficients();
        reset();
    }

    void reset() noexcept {
        fastEnv = 0.0f;
        slowEnv = 0.0f;
        smoothWeight = 0.0f;
        scHpL = 0.0f;
        scHpR = 0.0f;
    }

    void setSensitivity(float sens) noexcept {
        sensitivity = std::clamp(sens, 0.5f, 4.0f);
    }

    struct SplitResult {
        float transientSample;
        float tonalSample;
        float transientRatio;
    };

    struct StereoSplitResult {
        float transL;
        float transR;
        float tonalL;
        float tonalR;
        float transientRatio;
    };

    // Stereo-Linked processing: guarantees rock-solid phantom center and zero stereo tearing
    inline StereoSplitResult processStereo(float inL, float inR) noexcept {
        // 1. High-Pass sidechain filter (~110 Hz) on absolute amplitudes to stop bass IMD
        const float absL = std::abs(inL);
        const float absR = std::abs(inR);
        scHpL += alphaHp * (absL - scHpL);
        scHpR += alphaHp * (absR - scHpR);
        const float detL = std::max(0.0f, absL - scHpL);
        const float detR = std::max(0.0f, absR - scHpR);

        // 2. Stereo Coupled Sidechain: Maximum envelope drives unified transient weight
        const float coupledDet = std::max(detL, detR);

        updateWeight(coupledDet);

        const float transL = inL * smoothWeight;
        const float transR = inR * smoothWeight;
        const float tonalL = inL * (1.0f - smoothWeight);
        const float tonalR = inR * (1.0f - smoothWeight);

        return { transL, transR, tonalL, tonalR, smoothWeight };
    }

    // Single-channel processing (backward-compatible for mono / individual channels)
    inline SplitResult processSample(float in) noexcept {
        const float absIn = std::abs(in);
        scHpL += alphaHp * (absIn - scHpL);
        const float detIn = std::max(0.0f, absIn - scHpL);

        updateWeight(detIn);

        const float transOut = in * smoothWeight;
        const float tonalOut = in * (1.0f - smoothWeight);

        return { transOut, tonalOut, smoothWeight };
    }

    float getTransientRatio() const noexcept {
        return smoothWeight;
    }

private:
    inline void updateWeight(float detIn) noexcept {
        // Fast envelope: tracks sharp attacks
        if (detIn > fastEnv) {
            fastEnv += alphaFastAtt * (detIn - fastEnv);
        } else {
            fastEnv += alphaFastRel * (detIn - fastEnv);
        }

        // Slow envelope: tracks RMS body and tonal sustain
        if (detIn > slowEnv) {
            slowEnv += alphaSlowAtt * (detIn - slowEnv);
        } else {
            slowEnv += alphaSlowRel * (detIn - slowEnv);
        }

        constexpr float eps = 1.0e-5f;
        const float ratio = fastEnv / (slowEnv + eps);

        float targetWeight = 0.0f;
        if (ratio > 1.0f) {
            targetWeight = std::clamp((ratio - 1.0f) * (sensitivity * 0.45f), 0.0f, 1.0f);
        }

        // Fast-attack transient smoothing with gentle release
        if (targetWeight > smoothWeight) {
            smoothWeight += alphaSmoothAtt * (targetWeight - smoothWeight);
        } else {
            smoothWeight += alphaSmoothRel * (targetWeight - smoothWeight);
        }

        // Hardware anti-denormal protection
        if (std::abs(fastEnv) < 1.0e-25f) fastEnv = 0.0f;
        if (std::abs(slowEnv) < 1.0e-25f) slowEnv = 0.0f;
        if (std::abs(smoothWeight) < 1.0e-25f) smoothWeight = 0.0f;
    }

    void updateCoefficients() noexcept {
        if (sr <= 0.0f) sr = 44100.0f;

        // Sidechain HP filter pole (~110 Hz)
        alphaHp = 1.0f - std::exp(-2.0f * PI * 110.0f / sr);

        // Fast attack: sub-millisecond ~0.6 ms, Fast release: ~22 ms
        alphaFastAtt = 1.0f - std::exp(-1.0f / (0.0006f * sr));
        alphaFastRel = 1.0f - std::exp(-1.0f / (0.0220f * sr));

        // Slow attack: ~35 ms, Slow release: ~180 ms
        alphaSlowAtt = 1.0f - std::exp(-1.0f / (0.0350f * sr));
        alphaSlowRel = 1.0f - std::exp(-1.0f / (0.1800f * sr));

        // Smoothing: nimble 0.6 ms sub-millisecond attack preserves initial transient wavefront, 14 ms release stops flutter
        alphaSmoothAtt = 1.0f - std::exp(-1.0f / (0.0006f * sr));
        alphaSmoothRel = 1.0f - std::exp(-1.0f / (0.0140f * sr));
    }

    float sr = 44100.0f;
    float fastEnv = 0.0f;
    float slowEnv = 0.0f;
    float smoothWeight = 0.0f;
    float sensitivity = 2.0f;

    float scHpL = 0.0f;
    float scHpR = 0.0f;
    float alphaHp = 0.01f;

    float alphaFastAtt = 0.1f;
    float alphaFastRel = 0.01f;
    float alphaSlowAtt = 0.01f;
    float alphaSlowRel = 0.001f;
    float alphaSmoothAtt = 0.02f;
    float alphaSmoothRel = 0.002f;
};

} // namespace dsp171
