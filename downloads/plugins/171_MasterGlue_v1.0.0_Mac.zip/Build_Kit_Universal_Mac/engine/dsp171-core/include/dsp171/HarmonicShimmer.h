#pragma once
#include <vector>
#include <cmath>
#include <algorithm>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// HARMONIC SHIMMER PITCH SHIFTER (+1 OTTAVA / FRACTIONAL DUAL-HEAD ENGINE)
//
// Pitch shifter granulare a doppia testina a ritardo frazionario con inviluppo
// a coseno rialzato continuo (w1 + w2 = 1) per assenza totale di glitch o click.
// Progettato per ricircolare all'interno del loop di riverbero (stile Valhalla
// Shimmer / Brian Eno / Daniel Lanois) o per essere usato come insert armonico.
// =============================================================================

class HarmonicShimmer {
public:
    HarmonicShimmer() = default;

    void prepare(double sampleRate) {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        bufferSize = static_cast<int>(sr * 0.15); // 150 ms buffer
        bufferL.assign(bufferSize, 0.0f);
        bufferR.assign(bufferSize, 0.0f);
        writePos = 0;
        phase = 0.0f;

        setParameters(12.0f, 45.0f); // Default: +1 ottava, 45 ms window
        reset();
    }

    void reset() noexcept {
        std::fill(bufferL.begin(), bufferL.end(), 0.0f);
        std::fill(bufferR.begin(), bufferR.end(), 0.0f);
        writePos = 0;
        phase = 0.0f;
    }

    void setParameters(float semitones = 12.0f, float windowSizeMs = 45.0f) noexcept {
        shiftSemitones = semitones;
        float pitchRatio = std::pow(2.0f, shiftSemitones / 12.0f);
        
        float wMs = std::clamp(windowSizeMs, 15.0f, 90.0f);
        windowSamples = static_cast<float>(wMs * 0.001 * sr);
        if (windowSamples < 10.0f) windowSamples = 10.0f;

        // Frequenza di avanzamento di fase della rampa
        rate = (1.0f - pitchRatio) / windowSamples;
    }

    inline void processSample(float inL, float inR, float& outL, float& outR, float amount = 1.0f) noexcept {
        if (amount <= 0.0001f) {
            outL = 0.0f;
            outR = 0.0f;
            return;
        }

        bufferL[writePos] = inL;
        bufferR[writePos] = inR;

        // Due testine sfasate di 180 gradi (0.5 di periodo)
        float phase1 = phase;
        while (phase1 < 0.0f) phase1 += 1.0f;
        while (phase1 >= 1.0f) phase1 -= 1.0f;

        float phase2 = phase1 + 0.5f;
        if (phase2 >= 1.0f) phase2 -= 1.0f;

        float delay1 = phase1 * windowSamples;
        float delay2 = phase2 * windowSamples;

        float s1L = readSample(bufferL, delay1);
        float s1R = readSample(bufferR, delay1);
        float s2L = readSample(bufferL, delay2);
        float s2R = readSample(bufferR, delay2);

        // Finestre a coseno rialzato (Hanning): w1 = sin^2(pi * p1), w2 = sin^2(pi * p2)
        // Proprieta: w1 + w2 = 1 identica costante, energia acustica perfettamente preservata
        float w1 = 0.5f * (1.0f - std::cos(phase1 * 2.0f * PI));
        float w2 = 0.5f * (1.0f - std::cos(phase2 * 2.0f * PI));

        float shiftedL = s1L * w1 + s2L * w2;
        float shiftedR = s1R * w1 + s2R * w2;

        // Saturazione analogica morbida anti-runaway via Pade fastTanh
        float satL = fastTanh(shiftedL * 1.35f) * 0.88f;
        float satR = fastTanh(shiftedR * 1.35f) * 0.88f;

        outL = satL * amount;
        outR = satR * amount;

        // Avanzamento rampa
        phase += rate;
        if (phase >= 1.0f) phase -= 1.0f;
        else if (phase < 0.0f) phase += 1.0f;

        writePos = (writePos + 1) % bufferSize;
    }

private:
    inline float readSample(const std::vector<float>& buf, float delay) const noexcept {
        float readF = static_cast<float>(writePos) - delay;
        while (readF < 0.0f) readF += static_cast<float>(bufferSize);
        int idx0 = static_cast<int>(readF);
        int idx1 = (idx0 + 1) % bufferSize;
        float frac = readF - static_cast<float>(idx0);
        return buf[idx0] + frac * (buf[idx1] - buf[idx0]);
    }

    double sr = 48000.0;
    int bufferSize = 7200;
    std::vector<float> bufferL;
    std::vector<float> bufferR;
    int writePos = 0;
    float phase = 0.0f;
    float windowSamples = 2160.0f;
    float rate = 0.00046f;
    float shiftSemitones = 12.0f;
};

} // namespace dsp171
