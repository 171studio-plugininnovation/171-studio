#pragma once

#include <cmath>
#include <algorithm>
#include <array>
#include <span>
#include <numbers>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// dsp171::StereoWidth - Studio Mastering & Spatial Audio Stereo Width Processor
// =============================================================================
// Caratteristiche e Requisiti Audiofili:
// 1. Matrice Mid/Side ad altissima precisione per controllo Width continuo
//    da 0% (mono puro) a 100% (stereo naturale) fino a 200% (super wide).
// 2. Decorrelatore mono-compatibile (comb-filter free) per segnali mono in ingresso
//    (Side = 0): genera un Side sintetico ad alta dispersione tramite rete allpass
//    in cascata e delay dispersivo proporzionale (7 - 12 ms).
// 3. Garanzia di compatibilità mono al 100%: quando sommato a mono ((L + R) * 0.5),
//    la componente Side decorrelata si cancella matematicamente e identicamente
//    a zero (+S - S = 0), lasciando il segnale Mid intatto senza buchi di fase o comb filtering.
// 4. Filtro passa-alto Zero-Delay Feedback (ZDF SVF 64-bit Butterworth) sul canale Side
//    calibrato a 120 Hz: azzera il Side in gamma sub/bassi, preservando kick punch,
//    basse frequenze e monocompatibilità assoluta su sistemi PA e vinile.
// 5. Zero allocazioni dinamiche nel thread audio, standard C++20, elaborazione noexcept.
// =============================================================================
class StereoWidth {
public:
    // Modalità operativa del decorrelatore di Side
    enum class DecorrelationMode {
        Auto,       // Inietta decorrelazione proporzionalmente alla monoicità del segnale
        AlwaysOn,   // Decorrelatore sempre attivo e miscelato proporzionalmente al Side
        Off         // Solo matrice M/S pura (nessuna decorrelazione per segnali mono)
    };

    // Struttura per output campione stereo
    struct StereoPair {
        float left = 0.0f;
        float right = 0.0f;
    };

    // Costanti per le linee di ritardo e rete allpass
    static constexpr size_t MAIN_BUFFER_SIZE = 8192; // Copre fino a >40ms a 192 kHz
    static constexpr size_t MAIN_BUFFER_MASK = MAIN_BUFFER_SIZE - 1;

    static constexpr size_t AP_BUFFER_SIZE = 2048;   // Buffer dedicato per ciascuno stadio Allpass
    static constexpr size_t AP_BUFFER_MASK = AP_BUFFER_SIZE - 1;
    static constexpr size_t NUM_ALLPASS_STAGES = 4;

    StereoWidth() noexcept {
        reset();
    }

    // Inizializzazione con sample rate (noexcept, zero heap allocations)
    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        
        // Calcolo coefficiente per smoothing parametri (~20 ms)
        updateSmoothingCoeff(0.020f);

        // Calcolo coefficiente per l'envelope detector mono (~30 ms)
        constexpr float envTimeSec = 0.030f;
        envCoeff = 1.0f - std::exp(-1.0f / (envTimeSec * sr));

        // Calcolo coefficiente per meter energetico correlazione (~50 ms)
        constexpr float meterTimeSec = 0.050f;
        meterCoeff = 1.0f - std::exp(-1.0f / (meterTimeSec * sr));

        // Configura il filtro passa-alto ZDF SVF a 64-bit sul Side
        updateSideHighPassCoeffs();

        // Configura gli stadi della rete allpass dispersiva con ritardi incommensurabili (rapporti primi)
        // t1 = 1.27 ms, t2 = 2.41 ms, t3 = 3.89 ms, t4 = 5.63 ms
        constexpr float apDelaysMs[NUM_ALLPASS_STAGES] = { 1.27f, 2.41f, 3.89f, 5.63f };
        // Coefficienti alternati per massima diffusione e zero risonanze modali
        constexpr float apGains[NUM_ALLPASS_STAGES]    = { 0.50f, -0.45f, 0.40f, -0.35f };

        for (size_t i = 0; i < NUM_ALLPASS_STAGES; ++i) {
            allpassStages[i].prepare(sr, apDelaysMs[i], apGains[i]);
        }

        reset();
    }

    // Reset degli stati interni, buffer e filtri
    void reset() noexcept {
        mainDelayBuffer.fill(0.0f);
        mainWritePos = 0;

        for (auto& ap : allpassStages) {
            ap.reset();
        }

        currentWidth = targetWidth;
        currentDelaySamples = calculateDelaySamples(currentWidth);

        // Reset stato filtro ZDF SVF
        hpS1 = 0.0;
        hpS2 = 0.0;

        // Reset detector di livello
        envMid = 0.0f;
        envSide = 0.0f;
        detectedMonoFactor = 0.0f;
        meterEnergyM = 0.0f;
        meterEnergyS = 0.0f;
    }

    // -------------------------------------------------------------------------
    // Parametri e Controlli
    // -------------------------------------------------------------------------

    // Controllo Width: 0.0f = 0% (mono puro), 1.0f = 100% (stereo naturale), 2.0f = 200% (super wide)
    void setWidth(float width) noexcept {
        targetWidth = std::clamp(width, 0.0f, 2.0f);
    }

    [[nodiscard]] float getWidth() const noexcept {
        return targetWidth;
    }

    // Frequenza di taglio per il filtro passa-alto sul Side (default 120 Hz)
    void setSideHighPassFrequency(float fcHz) noexcept {
        sideHpFc = std::clamp(fcHz, 20.0f, 500.0f);
        updateSideHighPassCoeffs();
    }

    [[nodiscard]] float getSideHighPassFrequency() const noexcept {
        return sideHpFc;
    }

    // Attivazione/disattivazione filtro passa-alto sul Side
    void setSideHighPassEnabled(bool enabled) noexcept {
        sideHpEnabled = enabled;
    }

    [[nodiscard]] bool isSideHighPassEnabled() const noexcept {
        return sideHpEnabled;
    }

    // Soglia di rilevamento segnale mono (default 0.02f = -34 dB di Side rispetto a Mid)
    void setMonoDetectionThreshold(float threshold) noexcept {
        monoThreshold = std::clamp(threshold, 0.001f, 0.5f);
    }

    [[nodiscard]] float getMonoDetectionThreshold() const noexcept {
        return monoThreshold;
    }

    // Modalità di decorrelazione per segnali mono
    void setDecorrelationMode(DecorrelationMode mode) noexcept {
        decorrMode = mode;
    }

    [[nodiscard]] DecorrelationMode getDecorrelationMode() const noexcept {
        return decorrMode;
    }

    // Quantità di decorrelazione mono (0.0f = disattivata, 1.0f = 100% full, default 1.0f)
    void setDecorrelationAmount(float amount) noexcept {
        decorrAmount = std::clamp(amount, 0.0f, 1.0f);
    }

    [[nodiscard]] float getDecorrelationAmount() const noexcept {
        return decorrAmount;
    }

    // Guadagno base del Side sintetico decorrelato a Width = 100% (default 0.5f = -6 dBFS)
    void setDecorrelationBaseGain(float gain) noexcept {
        decorrBaseGain = std::clamp(gain, 0.0f, 1.0f);
    }

    [[nodiscard]] float getDecorrelationBaseGain() const noexcept {
        return decorrBaseGain;
    }

    // Range ritardo dispersivo per segnali mono (default: min 7.0 ms, max 12.0 ms)
    void setDelayRangeMs(float minMs, float maxMs) noexcept {
        delayMinMs = std::clamp(minMs, 2.0f, 15.0f);
        delayMaxMs = std::clamp(maxMs, delayMinMs, 20.0f);
    }

    // Tempo di smoothing dei controlli (secondi)
    void setSmoothingTimeSec(float timeSec) noexcept {
        updateSmoothingCoeff(timeSec);
    }

    // -------------------------------------------------------------------------
    // Elaborazione Audio Campione per Campione (noexcept, zero allocations)
    // -------------------------------------------------------------------------

    // Elaborazione campione singolo stereo con ritorno per riferimento
    inline void processSample(float inL, float inR, float& outL, float& outR) noexcept {
        // 1. Rampa di smoothing su parametro Width e Delay
        currentWidth += widthSmoothCoeff * (targetWidth - currentWidth);
        const float targetDelaySamps = calculateDelaySamples(currentWidth);
        currentDelaySamples += widthSmoothCoeff * (targetDelaySamps - currentDelaySamples);

        // 2. Codifica Matrice Mid/Side
        // Mid: componente comune (somma)
        // Side: componente di differenza (larghezza)
        const float mid = 0.5f * (inL + inR);
        const float sideIn = 0.5f * (inL - inR);

        // 3. Rilevamento dinamico di segnale mono (Side = 0)
        const float absMid = std::abs(mid);
        const float absSide = std::abs(sideIn);
        envMid += envCoeff * (absMid - envMid);
        envSide += envCoeff * (absSide - envSide);
        flushDenormal(envMid);
        flushDenormal(envSide);

        // monoFactor in [0.0, 1.0]: è 1.0f quando Side = 0 (mono puro),
        // e sfuma a 0.0f quando il Side supera la soglia di monoicità
        float monoFactor = 0.0f;
        if (envMid > 1.0e-5f) {
            const float sideRatio = envSide / envMid;
            if (sideRatio < monoThreshold) {
                monoFactor = 1.0f - (sideRatio / monoThreshold);
            }
        }
        detectedMonoFactor = monoFactor;

        // 4. Calcolo componente Side naturale scalata da Width
        const float sideNatural = sideIn * currentWidth;

        // 5. Sintesi Side decorrelato tramite Rete Dispersiva Allpass (per segnali mono)
        float sideDecorr = 0.0f;
        if (decorrMode != DecorrelationMode::Off && (currentWidth > 0.0001f) && (decorrAmount > 0.0001f)) {
            // Scrittura nel buffer di ritardo circolare principale
            mainDelayBuffer[mainWritePos] = mid;

            // Lettura con interpolazione Hermite a 4 punti per evitare zipper noise e dispersione di fase HF
            const float delayedMid = readMainDelayHermite(currentDelaySamples);

            // Avanzamento indice di scrittura
            mainWritePos = (mainWritePos + 1) & MAIN_BUFFER_MASK;

            // Diffusione dispersiva attraverso la cascata di stadi Allpass
            float diffused = delayedMid;
            for (auto& ap : allpassStages) {
                diffused = ap.process(diffused);
            }

            // Pesatura del segnale decorrelato in funzione della modalità
            float decorrWeight = 0.0f;
            if (decorrMode == DecorrelationMode::Auto) {
                decorrWeight = monoFactor;
            } else if (decorrMode == DecorrelationMode::AlwaysOn) {
                decorrWeight = 1.0f;
            }

            // Il Side decorrelato è proporzionale a Width:
            // a Width = 0 -> gain = 0
            // a Width = 1.0 -> gain = decorrBaseGain
            // a Width = 2.0 -> gain = 2.0 * decorrBaseGain
            const float decorrGain = currentWidth * decorrBaseGain * decorrAmount * decorrWeight;
            sideDecorr = diffused * decorrGain;
        }

        // Combinazione componente Side naturale e decorrelata
        float sideCombined = sideNatural + sideDecorr;

        // 6. Filtro passa-alto sul Side a 120 Hz (ZDF SVF Butterworth del 2° ordine)
        // Preserva solidità, headroom e punch del kick/bassi al centro del fronte sonoro
        if (sideHpEnabled) {
            sideCombined = processSideHighPass(sideCombined);
        }

        // 7. Ricostruzione Stereo dalla Matrice Mid/Side:
        // outL = Mid + Side
        // outR = Mid - Side
        //
        // NOTA FONDAMENTALE SULLA MONO-COMPATIBILITÀ:
        // Quando outL e outR vengono sommati a mono:
        // (outL + outR) * 0.5 = ((Mid + Side) + (Mid - Side)) * 0.5
        //                     = (2 * Mid) * 0.5
        //                     = Mid = (inL + inR) * 0.5
        // Qualunque sia il valore di Side (naturale o decorrelato),
        // +Side e -Side si cancellano matematicamente ed esattamente a ZERO!
        // Il Mid in mono è al 100% identico al segnale originale, comb-filter free!
        outL = mid + sideCombined;
        outR = mid - sideCombined;

        // 8. Aggiornamento Meter Energetici per calcolo correlazione di fase
        const float instM2 = mid * mid;
        const float instS2 = sideCombined * sideCombined;
        meterEnergyM += meterCoeff * (instM2 - meterEnergyM);
        meterEnergyS += meterCoeff * (instS2 - meterEnergyS);
        flushDenormal(meterEnergyM);
        flushDenormal(meterEnergyS);
    }

    // Variante sovraccaricata che restituisce una struct StereoPair
    [[nodiscard]] inline StereoPair processSample(float inL, float inR) noexcept {
        StereoPair out{};
        processSample(inL, inR, out.left, out.right);
        return out;
    }

    // -------------------------------------------------------------------------
    // Elaborazione a Blocchi di Buffer Stereo (noexcept, zero allocations)
    // -------------------------------------------------------------------------
    void processBlock(float* leftChannel, float* rightChannel, size_t numSamples) noexcept {
        if (!leftChannel || !rightChannel) return;

        for (size_t i = 0; i < numSamples; ++i) {
            processSample(leftChannel[i], rightChannel[i], leftChannel[i], rightChannel[i]);
        }
    }

    void processBlock(std::span<float> leftChannel, std::span<float> rightChannel) noexcept {
        const size_t numSamples = std::min(leftChannel.size(), rightChannel.size());
        processBlock(leftChannel.data(), rightChannel.data(), numSamples);
    }

    // -------------------------------------------------------------------------
    // Metriche e Diagnostica in Tempo Reale
    // -------------------------------------------------------------------------

    // Coefficiente di correlazione stereo [-1.0, +1.0]:
    // +1.0 = Mono perfetto (L == R)
    //  0.0 = Stereo ortogonale / decorrelato ideale
    // -1.0 = Controfase pura (L == -R)
    [[nodiscard]] float getStereoCorrelation() const noexcept {
        const float sum = meterEnergyM + meterEnergyS;
        if (sum < 1.0e-7f) return 1.0f; // Silenzio = correlazione neutra
        return std::clamp((meterEnergyM - meterEnergyS) / sum, -1.0f, 1.0f);
    }

    // Fattore mono rilevato [0.0, 1.0] (1.0 = ingresso mono puro, 0.0 = stereo pieno)
    [[nodiscard]] float getDetectedMonoFactor() const noexcept {
        return detectedMonoFactor;
    }

    // Livello RMS istantaneo del Mid (lineare)
    [[nodiscard]] float getMidLevel() const noexcept {
        return std::sqrt(std::max(0.0f, meterEnergyM));
    }

    // Livello RMS istantaneo del Side (lineare)
    [[nodiscard]] float getSideLevel() const noexcept {
        return std::sqrt(std::max(0.0f, meterEnergyS));
    }

private:
    // -------------------------------------------------------------------------
    // Stadio di Diffusione Allpass (Schroeder Allpass con Buffer Statico Circolare)
    // -------------------------------------------------------------------------
    struct AllpassStage {
        std::array<float, AP_BUFFER_SIZE> buffer{};
        size_t writeIdx = 0;
        size_t delaySamples = 100;
        float g = 0.5f;

        void prepare(float sampleRate, float delayMs, float feedback) noexcept {
            const float d = (sampleRate * 0.001f) * delayMs;
            delaySamples = std::clamp(static_cast<size_t>(std::round(d)), size_t{1}, AP_BUFFER_MASK);
            g = feedback;
            reset();
        }

        void reset() noexcept {
            buffer.fill(0.0f);
            writeIdx = 0;
        }

        // Formula Schroeder:
        // w[n] = x[n] + g * w[n - d]
        // y[n] = -g * w[n] + w[n - d]
        // Magnitude |H(e^jw)| = 1.0 per qualunque frequenza w (puramente allpass)
        inline float process(float in) noexcept {
            const size_t readIdx = (writeIdx + AP_BUFFER_SIZE - delaySamples) & AP_BUFFER_MASK;
            const float bufOut = buffer[readIdx];
            float w = in + g * bufOut;
            if (std::abs(w) < 1.0e-20f) w = 0.0f; // Anti-denormal flush
            const float out = -g * w + bufOut;
            buffer[writeIdx] = w;
            writeIdx = (writeIdx + 1) & AP_BUFFER_MASK;
            return out;
        }
    };

    // -------------------------------------------------------------------------
    // Metodi Ausiliari Interni
    // -------------------------------------------------------------------------

    // Calcolo del ritardo dispersivo in campioni in funzione di Width:
    // a Width = 0.0 -> delayMinMs (7.0 ms)
    // a Width = 1.0 -> delayMinMs + 0.5 * (delayMaxMs - delayMinMs) (9.5 ms)
    // a Width = 2.0 -> delayMaxMs (12.0 ms)
    [[nodiscard]] inline float calculateDelaySamples(float width) const noexcept {
        const float normWidth = std::clamp(width * 0.5f, 0.0f, 1.0f);
        const float delayMs = delayMinMs + normWidth * (delayMaxMs - delayMinMs);
        return (sr * 0.001f) * delayMs;
    }

    // Lettura dal buffer principale con interpolazione polinomiale Hermite a 4 punti
    [[nodiscard]] inline float readMainDelayHermite(float delaySamples) const noexcept {
        const int dInt = static_cast<int>(delaySamples);
        const float frac = delaySamples - static_cast<float>(dInt);

        const size_t idx1 = static_cast<size_t>(mainWritePos + MAIN_BUFFER_SIZE - static_cast<size_t>(dInt)) & MAIN_BUFFER_MASK;
        const size_t idx0 = (idx1 + 1) & MAIN_BUFFER_MASK;
        const size_t idx2 = (idx1 + MAIN_BUFFER_MASK) & MAIN_BUFFER_MASK;
        const size_t idx3 = (idx1 + MAIN_BUFFER_SIZE - 2) & MAIN_BUFFER_MASK;

        const float y0 = mainDelayBuffer[idx0];
        const float y1 = mainDelayBuffer[idx1];
        const float y2 = mainDelayBuffer[idx2];
        const float y3 = mainDelayBuffer[idx3];

        const float c0 = y1;
        const float c1 = 0.5f * (y2 - y0);
        const float c2 = y0 - 2.5f * y1 + 2.0f * y2 - 0.5f * y3;
        const float c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);

        return ((c3 * frac + c2) * frac + c1) * frac + c0;
    }

    // Aggiornamento coefficienti del filtro passa-alto ZDF SVF Butterworth (12 dB/oct)
    void updateSideHighPassCoeffs() noexcept {
        const double safeSr = sr > 0.0f ? static_cast<double>(sr) : 44100.0;
        const double clampedFc = std::clamp(static_cast<double>(sideHpFc), 10.0, safeSr * 0.495);
        
        // Pre-warping bilineare: g = tan(pi * fc / sr)
        hpG = std::tan(std::numbers::pi * clampedFc / safeSr);
        // Q Butterworth = 1 / sqrt(2) ~ 0.70710678 -> R = 1 / (2 * Q) = 1 / sqrt(2) ~ 0.70710678
        hpR = 0.7071067811865475;
        hpH = 1.0 / (1.0 + 2.0 * hpR * hpG + hpG * hpG);
    }

    // Processamento filtro passa-alto ZDF SVF a 64-bit sul canale Side
    inline float processSideHighPass(float in) noexcept {
        const double inD = static_cast<double>(in);
        // Risoluzione implicita istantanea del loop ZDF:
        const double hpD = (inD - (2.0 * hpR + hpG) * hpS1 - hpS2) * hpH;
        const double v1 = hpG * hpD;
        const double bpD = v1 + hpS1;
        hpS1 = v1 + bpD;
        const double v2 = hpG * bpD;
        const double lpD = v2 + hpS2;
        hpS2 = v2 + lpD;

        // Protezione anti-denormal hardware
        if (std::abs(hpS1) < 1.0e-25) hpS1 = 0.0;
        if (std::abs(hpS2) < 1.0e-25) hpS2 = 0.0;

        return static_cast<float>(hpD);
    }

    void updateSmoothingCoeff(float timeSec) noexcept {
        const float safeTime = std::max(0.001f, timeSec);
        widthSmoothCoeff = 1.0f - std::exp(-1.0f / (safeTime * sr));
    }

    static inline void flushDenormal(float& v) noexcept {
        if (std::abs(v) < 1.0e-20f) v = 0.0f;
    }

    // -------------------------------------------------------------------------
    // Membri Dati Interni (Zero allocazioni dinamiche nel thread audio)
    // -------------------------------------------------------------------------
    float sr = 44100.0f;

    // Parametri operativi
    float targetWidth = 1.0f;           // Default 100% stereo
    float currentWidth = 1.0f;
    float widthSmoothCoeff = 0.005f;

    float delayMinMs = 7.0f;            // Delay minimo a Width = 0%
    float delayMaxMs = 12.0f;           // Delay massimo a Width = 200%
    float currentDelaySamples = 308.7f; // ~7 ms a 44.1k

    float decorrBaseGain = 0.50f;       // Calibrato per spread ideale e correlazione ~ +0.60
    float decorrAmount = 1.0f;          // 0.0f disattiva, 1.0f full
    DecorrelationMode decorrMode = DecorrelationMode::Auto;

    // Filtro passa-alto Side ZDF SVF
    bool sideHpEnabled = true;
    float sideHpFc = 120.0f;            // 120 Hz standard per mono bass
    double hpG = 0.0;
    double hpR = 0.7071067811865475;
    double hpH = 0.0;
    double hpS1 = 0.0;
    double hpS2 = 0.0;

    // Rete Allpass Dispersiva
    std::array<float, MAIN_BUFFER_SIZE> mainDelayBuffer{};
    size_t mainWritePos = 0;
    std::array<AllpassStage, NUM_ALLPASS_STAGES> allpassStages{};

    // Rilevamento dinamico mono (Side / Mid ratio)
    float envMid = 0.0f;
    float envSide = 0.0f;
    float envCoeff = 0.001f;
    float monoThreshold = 0.02f;        // Soglia di Side / Mid sotto cui il segnale è considerato mono
    float detectedMonoFactor = 0.0f;

    // Metering correlazione stereo
    float meterEnergyM = 0.0f;
    float meterEnergyS = 0.0f;
    float meterCoeff = 0.001f;
};

} // namespace dsp171
