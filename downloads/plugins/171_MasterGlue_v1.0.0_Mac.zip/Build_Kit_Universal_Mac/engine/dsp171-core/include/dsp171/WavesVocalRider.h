#pragma once
#include <cmath>
#include <algorithm>

namespace dsp171 {

/**
 * @brief WavesVocalRider
 * Reverse-engineered from Waves Vocal Rider.
 * Real-time automatic vocal fader rider that keeps vocal levels steady without compression artifacts.
 * Features true RMS squared detection with precomputed ballistic integrators,
 * speech bandpass voice filtering (150 Hz - 4500 Hz), instrumental spill discrimination,
 * and smooth idle park positioning with linear dB slew limiting.
 */
class WavesVocalRider {
public:
    enum class ResponseSpeed {
        Fast,
        Slow
    };

    WavesVocalRider() noexcept 
        : m_sampleRate(44100.0f) {}

    void prepare(float sampleRate) noexcept {
        m_sampleRate = sampleRate;
        m_vocalSq = 0.0f;
        m_musicSq = 0.0f;
        m_currentRideGainDb = 0.0f;
        m_holdCounter = 0;
        m_isVoiceActive = false;
        m_hpL = 0.0f;
        m_lp = 0.0f;
        updateCoefficients();
    }

    void setParameters(float targetDb = -18.0f, float rangeMinDb = -6.0f, float rangeMaxDb = 6.0f,
                       float spillThresholdDb = -36.0f, ResponseSpeed speed = ResponseSpeed::Fast,
                       float idleParkDb = 0.0f) noexcept {
        m_targetDb = std::clamp(targetDb, -42.0f, 0.0f);
        m_rangeMinDb = std::clamp(rangeMinDb, -12.0f, 0.0f);
        m_rangeMaxDb = std::clamp(rangeMaxDb, 0.0f, 12.0f);
        m_spillThreshold = std::pow(10.0f, std::clamp(spillThresholdDb, -48.0f, -12.0f) / 20.0f);
        m_speed = speed;
        m_idleParkDb = std::clamp(idleParkDb, -12.0f, 12.0f);
        updateCoefficients();
    }

    inline void process(float vocalL, float vocalR, float& outL, float& outR, float musicRef = 0.0f) noexcept {
        // 1. Bandpass filter vocal to focus on human voice intelligibility (150 Hz to 4500 Hz)
        float filteredVocal = applyVoiceFilter(0.5f * (vocalL + vocalR));

        // 2. True RMS Squared Integrator (zero std::exp in inner loop)
        m_vocalSq += m_rmsAlpha * (filteredVocal * filteredVocal - m_vocalSq);
        m_musicSq += m_rmsAlpha * (musicRef * musicRef - m_musicSq);

        float vocalRms = std::sqrt(std::max(m_vocalSq, 1e-12f));
        float musicRms = std::sqrt(std::max(m_musicSq, 1e-12f));

        // 3. Voice Activity Detection (VAD) & Spill Discrimination
        bool active = (vocalRms > m_spillThreshold) && (vocalRms > (musicRms * 1.2f));
        if (active) {
            m_isVoiceActive = true;
            m_holdCounter = m_holdSamples;
        } else {
            if (m_holdCounter > 0) {
                m_holdCounter--;
                m_isVoiceActive = true;
            } else {
                m_isVoiceActive = false;
            }
        }

        // 4. Target Ride Calculation
        float targetRideDb = m_idleParkDb;
        if (m_isVoiceActive && vocalRms > 1e-5f) {
            float vocalLoudnessDb = 20.0f * std::log10(vocalRms);
            // Delta needed to hit target loudness
            float neededGainDb = m_targetDb - vocalLoudnessDb;
            // Bound within configured range
            targetRideDb = std::clamp(neededGainDb, m_rangeMinDb, m_rangeMaxDb);
        }

        // 5. Smooth Slew-Rate Limiting of Fader Movement (dB domain)
        if (targetRideDb > m_currentRideGainDb) {
            m_currentRideGainDb = std::min(targetRideDb, m_currentRideGainDb + m_slewRateDbPerSample);
        } else {
            m_currentRideGainDb = std::max(targetRideDb, m_currentRideGainDb - m_slewRateDbPerSample);
        }

        // 6. Apply Floating Fader Gain
        float rideLinear = std::pow(10.0f, m_currentRideGainDb / 20.0f);
        outL = vocalL * rideLinear;
        outR = vocalR * rideLinear;
    }

    void processBlock(float* left, float* right, int numSamples, const float* musicSidechain = nullptr) noexcept {
        for (int i = 0; i < numSamples; ++i) {
            float ref = (musicSidechain != nullptr) ? musicSidechain[i] : 0.0f;
            process(left[i], right[i], left[i], right[i], ref);
        }
    }

    [[nodiscard]] float getCurrentRideDb() const noexcept { return m_currentRideGainDb; }
    [[nodiscard]] bool isVoiceActive() const noexcept { return m_isVoiceActive; }

private:
    float m_sampleRate{44100.0f};
    float m_targetDb{-18.0f};
    float m_rangeMinDb{-6.0f};
    float m_rangeMaxDb{6.0f};
    float m_spillThreshold{0.015f};
    ResponseSpeed m_speed{ResponseSpeed::Fast};
    float m_idleParkDb{0.0f};

    float m_vocalSq{0.0f};
    float m_musicSq{0.0f};
    float m_currentRideGainDb{0.0f};
    int m_holdCounter{0};
    int m_holdSamples{11025}; // 250 ms default @ 44.1k
    bool m_isVoiceActive{false};

    // Precomputed coefficients
    float m_rmsAlpha{0.0f};
    float m_alphaHP{0.0f};
    float m_alphaLP{0.0f};
    float m_slewRateDbPerSample{0.01f};

    // Filter states
    float m_hpL{0.0f};
    float m_lp{0.0f};

    void updateCoefficients() noexcept {
        // RMS integration alpha (20 ms window)
        m_rmsAlpha = 1.0f - std::exp(-1.0f / (0.020f * m_sampleRate));

        // Bandpass filter alphas (150 Hz HPF, 4500 Hz LPF)
        m_alphaHP = 150.0f / (150.0f + m_sampleRate / 6.2831853f);
        m_alphaLP = 4500.0f / (4500.0f + m_sampleRate / 6.2831853f);

        // Hold samples (250 ms)
        m_holdSamples = static_cast<int>(0.250f * m_sampleRate);

        // Slew rate (Fast = 15 ms, Slow = 60 ms full swing of 24 dB)
        m_slewRateDbPerSample = (m_speed == ResponseSpeed::Fast)
            ? (24.0f / (0.015f * m_sampleRate))
            : (24.0f / (0.060f * m_sampleRate));
    }

    inline float applyVoiceFilter(float in) noexcept {
        m_hpL += m_alphaHP * (in - m_hpL);
        float highpassed = in - m_hpL;
        m_lp += m_alphaLP * (highpassed - m_lp);
        return m_lp;
    }
};

} // namespace dsp171
