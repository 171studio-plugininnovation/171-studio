#pragma once
#include <cmath>
#include <algorithm>
#include <array>
#include <cstdint>
#include "Common.h"
#include "ZDFSVF.h"
#include "ZDFTiltFilter.h"
#include "DCBlocker.h"

namespace dsp171 {

// =============================================================================
// DecapitatorDSP
// Emulatore Analog Saturation & Drive modellato su Soundtoys Decapitator
//
// 5 Stili di Saturazione Analogica:
// - Style A: Ampex 350 tape recorder tube preamp (caldo, nastro, saturazione morbida)
// - Style E: EMI TG12345 console channel strip (punchy, aggressivo, ricche armoniche dispari)
// - Style N: Neve 1057 Germanium input stage (transistor al germanio, bias asimmetrico, scuro e grosso)
// - Style T: Culture Vulture Triode mode (armoniche pari dominanti 2nd harmonic, valvolare setoso)
// - Style P: Culture Vulture Pentode mode (armoniche dispari 3rd/5th harmonic, zanzaroso e tagliente)
//
// Controlli Chiave:
// - Drive [0.0 .. 10.0]: Guadagno di ingresso non-lineare
// - Punish [Off/On]: +20 dB boost con saturazione estrema
// - Tone [-12 dB .. +12 dB]: Filtro Tilt centrato a 250 Hz (Q = 0.35)
// - LowCut [20 Hz .. 1000 Hz]: Filtro passa-alto logaritmico
// - LowThump [Off/On]: Risonanza +4 dB intorno alla frequenza di taglio
// - HighCut [1000 Hz .. 20000 Hz]: Filtro passa-basso logaritmico
// - HighSlope [Gentle (6 dB/oct) / Steep (18 dB/oct)]
// - AutoGain [Off/On]: Compensazione automatica del volume percepito al variare del Drive
// - Mix [0% .. 100%]: Dry/Wet parallelo
// - OutputTrim [-24 dB .. 0 dB]
// =============================================================================
class DecapitatorDSP {
public:
    enum class SatStyle : uint8_t {
        StyleA = 0, // Ampex 350
        StyleE = 1, // EMI TG12345
        StyleN = 2, // Neve 1057 Germanium
        StyleT = 3, // Triode
        StyleP = 4  // Pentode
    };

    DecapitatorDSP() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        invSr = 1.0f / sr;
        
        lowCutSVF_L.reset();
        lowCutSVF_R.reset();
        highCutSVF_L.reset();
        highCutSVF_R.reset();
        highCut2_L.reset();
        highCut2_R.reset();
        
        tiltFilterL.prepare(sampleRate);
        tiltFilterR.prepare(sampleRate);
        
        dcBlockerL.prepare(sampleRate, 10.0f);
        dcBlockerR.prepare(sampleRate, 10.0f);
        
        updateFilters();
        reset();
    }

    void reset() noexcept {
        lowCutSVF_L.reset();
        lowCutSVF_R.reset();
        highCutSVF_L.reset();
        highCutSVF_R.reset();
        highCut2_L.reset();
        highCut2_R.reset();
        tiltFilterL.reset();
        tiltFilterR.reset();
        dcBlockerL.reset();
        dcBlockerR.reset();
    }

    // --- Parametri ---

    void setStyle(SatStyle style) noexcept {
        currentStyle = style;
    }

    void setStyleIndex(int idx) noexcept {
        idx = std::clamp(idx, 0, 4);
        currentStyle = static_cast<SatStyle>(idx);
    }

    void setDrive(float driveNorm0To10) noexcept {
        driveVal = std::clamp(driveNorm0To10, 0.0f, 10.0f);
        updateDriveGain();
    }

    void setPunish(bool enabled) noexcept {
        punish = enabled;
        updateDriveGain();
    }

    // LowCut: da 20 Hz a 1000 Hz (mappatura logaritmica f = 20 * 50^x)
    void setLowCutHz(float hz) noexcept {
        lowCutHz = std::clamp(hz, 20.0f, 1000.0f);
        updateFilters();
    }

    void setLowCutNormalized(float norm01) noexcept {
        norm01 = std::clamp(norm01, 0.0f, 1.0f);
        setLowCutHz(20.0f * std::pow(50.0f, norm01));
    }

    void setLowThump(bool enabled) noexcept {
        lowThump = enabled;
        updateFilters();
    }

    // HighCut: da 1000 Hz a 20000 Hz (mappatura logaritmica f = 1000 * 20^x)
    void setHighCutHz(float hz) noexcept {
        highCutHz = std::clamp(hz, 1000.0f, 20000.0f);
        updateFilters();
    }

    void setHighCutNormalized(float norm01) noexcept {
        norm01 = std::clamp(norm01, 0.0f, 1.0f);
        setHighCutHz(1000.0f * std::pow(20.0f, norm01));
    }

    void setHighSlopeSteep(bool steep) noexcept {
        highSlopeSteep = steep;
        updateFilters();
    }

    // Tone: da -12 dB (Dark) a +12 dB (Bright), centro a 0 dB (Flat)
    void setToneDb(float toneDb) noexcept {
        toneDbVal = std::clamp(toneDb, -12.0f, 12.0f);
        updateFilters();
    }

    void setToneNormalized(float norm01) noexcept {
        norm01 = std::clamp(norm01, 0.0f, 1.0f);
        setToneDb(-12.0f + 24.0f * norm01);
    }

    void setAutoGain(bool enabled) noexcept {
        autoGain = enabled;
        updateDriveGain();
    }

    void setMixPercent(float mixPct) noexcept {
        mix = std::clamp(mixPct * 0.01f, 0.0f, 1.0f);
    }

    void setMixNormalized(float norm01) noexcept {
        mix = std::clamp(norm01, 0.0f, 1.0f);
    }

    void setOutputTrimDb(float trimDb) noexcept {
        trimDbVal = std::clamp(trimDb, -24.0f, 0.0f);
        outputTrimGain = std::pow(10.0f, trimDbVal * 0.05f);
    }

    void setOutputTrimNormalized(float norm01) noexcept {
        norm01 = std::clamp(norm01, 0.0f, 1.0f);
        setOutputTrimDb(-24.0f + 24.0f * norm01);
    }

    // --- Processing Block ---
    void process(float* inOutL, float* inOutR, size_t numSamples) noexcept {
        if (!inOutL || !inOutR || numSamples == 0) return;

        for (size_t i = 0; i < numSamples; ++i) {
            const float dryL = inOutL[i];
            const float dryR = inOutR[i];

            // 1. Pre-Filtering (Low-Cut con Thump opzionale)
            float sL = lowCutSVF_L.process(dryL).hp;
            float sR = lowCutSVF_R.process(dryR).hp;

            // 2. Pre-Gain / Drive Stage
            sL *= inputDriveGain;
            sR *= inputDriveGain;

            // 3. Nonlinear Waveshaping (5 stili analogici)
            sL = shapeStyle(sL, currentStyle);
            sR = shapeStyle(sR, currentStyle);

            // 4. DC Offset Blocker post saturazione asimmetrica
            sL = dcBlockerL.processSample(sL);
            sR = dcBlockerR.processSample(sR);

            // 5. Tone Tilt Filter (Baxandall Pivot a 250 Hz)
            sL = tiltFilterL.processSample(sL);
            sR = tiltFilterR.processSample(sR);

            // 6. Post High-Cut (Gentle o Steep 18 dB/oct)
            sL = highCutSVF_L.process(sL).lp;
            sR = highCutSVF_R.process(sR).lp;
            if (highSlopeSteep) {
                sL = highCut2_L.process(sL).lp;
                sR = highCut2_R.process(sR).lp;
            }

            // 7. AutoGain compensation & Output Trim
            sL *= postGain * outputTrimGain;
            sR *= postGain * outputTrimGain;

            // 8. Dry / Wet Mix
            inOutL[i] = (1.0f - mix) * dryL + mix * sL;
            inOutR[i] = (1.0f - mix) * dryR + mix * sR;
        }
    }

private:
    // Waveshaping matematico per ciascuno dei 5 stili analogici
    float shapeStyle(float x, SatStyle style) const noexcept {
        switch (style) {
            case SatStyle::StyleA: {
                // Ampex 350 Tape Tube: saturazione morbida a nastro, compressione progressiva
                const float bias = 0.06f;
                float xb = x + bias;
                float y = std::tanh(xb) - std::tanh(bias);
                y = 1.05f * y - 0.05f * (y * y * y);
                return y;
            }
            case SatStyle::StyleE: {
                // EMI TG12345 Channel: solid state aggressivo, clip più duro, armoniche 3a e 5a
                // Curva algebrica C^infinito rigorosamente monotona e priva di discontinuita' o salti
                const float x2 = x * x;
                const float x4 = x2 * x2;
                return (x / std::sqrt(std::sqrt(1.0f + 0.65f * x4))) * 1.15f;
            }
            case SatStyle::StyleN: {
                // Neve 1057 Germanium: diodo al germanio asimmetrico, ginocchio molto morbido
                if (x >= 0.0f) {
                    return 1.0f - std::exp(-x * 0.9f);
                } else {
                    return -(1.0f - std::exp(x * 1.35f)) * 0.85f;
                }
            }
            case SatStyle::StyleT: {
                // Culture Vulture Triode: prevalenza armonica pari (2a armonica)
                // Protetto da foldback polinomiale oltre il vertice a x = -2.0
                const float a = 0.25f;
                const float safeX = std::max(-1.95f, x);
                float xt = safeX + a * safeX * safeX;
                return std::tanh(xt * 1.1f);
            }
            case SatStyle::StyleP: {
                // Culture Vulture Pentode: prevalenza armonica dispari (3a e 5a), taglio netto
                float xp = std::tanh(1.5f * x);
                return 0.8f * xp + 0.2f * std::tanh(3.0f * x);
            }
        }
        return std::tanh(x);
    }

    void updateDriveGain() noexcept {
        float driveDb = driveVal * 4.0f; // 0..40 dB
        if (punish) {
            driveDb += 20.0f; // Punish boost
        }
        inputDriveGain = std::pow(10.0f, driveDb * 0.05f);

        if (autoGain) {
            float compDb = driveDb * 0.72f;
            postGain = std::pow(10.0f, -compDb * 0.05f);
        } else {
            postGain = 1.0f;
        }
    }

    void updateFilters() noexcept {
        if (sr <= 0.0f) return;

        // 1. Low Cut: passa-alto
        float lq = lowThump ? 1.65f : 0.707f;
        lowCutSVF_L.setParameters(lowCutHz, lq, sr);
        lowCutSVF_R.setParameters(lowCutHz, lq, sr);

        // 2. High Cut: passa-basso
        highCutSVF_L.setParameters(highCutHz, 0.707f, sr);
        highCutSVF_R.setParameters(highCutHz, 0.707f, sr);
        if (highSlopeSteep) {
            highCut2_L.setParameters(highCutHz, 1.0f, sr);
            highCut2_R.setParameters(highCutHz, 1.0f, sr);
        }

        // 3. Tone Tilt Filter
        // Mapping -12 dB .. +12 dB su -1.0 .. +1.0
        tiltFilterL.setTilt(toneDbVal / 12.0f);
        tiltFilterR.setTilt(toneDbVal / 12.0f);
    }

    float sr{44100.0f};
    float invSr{1.0f / 44100.0f};

    SatStyle currentStyle{SatStyle::StyleA};
    float driveVal{0.0f};
    bool punish{false};
    bool autoGain{true};
    float mix{1.0f};
    float trimDbVal{0.0f};
    float outputTrimGain{1.0f};
    float inputDriveGain{1.0f};
    float postGain{1.0f};

    float lowCutHz{20.0f};
    bool lowThump{false};
    float highCutHz{20000.0f};
    bool highSlopeSteep{false};
    float toneDbVal{0.0f};

    // Filtri ZDF a 64-bit
    ZDFSVF64 lowCutSVF_L, lowCutSVF_R;
    ZDFSVF64 highCutSVF_L, highCutSVF_R;
    ZDFSVF64 highCut2_L, highCut2_R;
    ZDFTiltFilter tiltFilterL, tiltFilterR;
    DCBlocker dcBlockerL, dcBlockerR;
};

} // namespace dsp171
