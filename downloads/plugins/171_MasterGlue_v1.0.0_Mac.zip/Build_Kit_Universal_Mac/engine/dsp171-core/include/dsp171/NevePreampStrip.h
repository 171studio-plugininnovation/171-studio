#pragma once

#include <cmath>
#include <algorithm>
#include "Common.h"
#include "DCBlocker.h"
#include "FastMath.h"
#include "ZDFSVF.h"
#include "TransformerSaturator.h"

namespace dsp171 {

// =============================================================================
// NevePreampStrip
// Crafted by: sat-neve-specialist (Reviewed by dsp-math-bugfinder)
// Supervised by: dsp-hire-manager (Dispatch Ticket #PRE-NEVE-01)
//
// State-of-the-art physical modeling of the Neve 1073 Channel Strip & Preamp:
// 1. BA283 Single-Ended Class-A Gain Block:
//    - Single-ended 2N3055 transistor stage with dynamic bias sag.
//    - Musical 2nd harmonic (H2) rich warmth with gentle 3rd harmonic compression.
// 2. Marinair LO1166 Output Transformer:
//    - Faraday core flux integration: low-frequency heavy magnetizing excursion (<50 Hz).
//    - Silicon-steel lamination saturation and B-H hysteresis curve.
// 3. Authentic Neve 1073 Discrete Inductor Equalizer:
//    - High-Pass Filter: 18 dB/octave (3rd order Butterworth) at 50, 80, 160, 300 Hz.
//    - Low Shelf: Resonant LC tank at 35, 60, 110, 220 Hz (+/- 16 dB).
//    - Mid Band: Dual-tapped ferrite core inductor at 360, 700, 1600, 3200, 4800, 7200 Hz (+/- 18 dB).
//    - High Shelf: 12 kHz Baxandall smooth high-frequency sheen (+/- 16 dB).
// =============================================================================

enum class NeveHPFFreq : uint8_t {
    Off = 0,
    Hz_50,
    Hz_80,
    Hz_160,
    Hz_300
};

enum class NeveLowFreq : uint8_t {
    Hz_35 = 0,
    Hz_60,
    Hz_110,
    Hz_220
};

enum class NeveMidFreq : uint8_t {
    Hz_360 = 0,
    Hz_700,
    kHz_1_6,
    kHz_3_2,
    kHz_4_8,
    kHz_7_2
};

class NevePreampStrip {
public:
    NevePreampStrip() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        invSr = 1.0f / sr;

        transformer.prepare(sampleRate);
        dcBlocker.prepare(sampleRate, 10.0f);

        updateCoefficients();
        reset();
    }

    void reset() noexcept {
        transformer.reset();
        dcBlocker.reset();
        biasSag = 0.0f;

        hpfSvf.reset();
        hpfOnePole.reset();
        lowShelfSvf.reset();
        midSvf.reset();
        highShelfSvf.reset();
    }

    // Set preamp and drive parameters
    void setPreamp(float inputGainDb, float driveWarmth01 = 0.5f, bool pad = false) noexcept {
        inGainDb = inputGainDb - (pad ? 20.0f : 0.0f);
        inGainLin = dbToGain(inGainDb);
        warmth = std::clamp(driveWarmth01, 0.0f, 1.0f);
    }

    // Set 1073 Equalizer parameters
    void setEQ(NeveHPFFreq hpf,
               NeveLowFreq lowFreq, float lowGainDb,
               NeveMidFreq midFreq, float midGainDb,
               float highGainDb,
               bool eqBypass = false) noexcept
    {
        hpfSetting = hpf;
        lowSetting = lowFreq;
        lowGain = std::clamp(lowGainDb, -16.0f, 16.0f);
        midSetting = midFreq;
        midGain = std::clamp(midGainDb, -18.0f, 18.0f);
        highGain = std::clamp(highGainDb, -16.0f, 16.0f);
        isEqBypassed = eqBypass;

        updateCoefficients();
    }

    // Set Output Fader and Phase
    void setOutput(float outGainDb, bool phaseInvert = false) noexcept {
        outGainLin = dbToGain(outGainDb) * (phaseInvert ? -1.0f : 1.0f);
    }

    // Process a single audio sample through the entire Neve strip
    inline float processSample(float in) noexcept {
        if (!std::isfinite(in)) return 0.0f;
        // 1. Input Gain & BA283 Class-A Discrete Preamp with Dynamic Bias Sag
        float x = in * inGainLin;

        // Dynamic emitter bias tracking (analog sag)
        const float absX = std::abs(x);
        biasSag += (absX - biasSag) * (absX > biasSag ? (35.0f * invSr) : (4.0f * invSr));
        if (biasSag < 1e-6f) biasSag = 0.0f;

        // Asymmetric Class-A transistor curve with 2nd harmonic richness
        // Clamped at monotonic boundary to eliminate foldback
        const float asym = warmth * (0.24f + 0.10f * biasSag);
        const float clampedX = std::clamp(x, -2.5f, 2.5f);
        const float vClassA = clampedX + asym * (clampedX * clampedX) - 0.04f * (clampedX * clampedX * clampedX);

        // 2. Marinair LO1166 Output Transformer Physical Core Flux
        const float vTrans = transformer.processSample(vClassA, /*drive=*/ 1.0f + warmth * 0.75f, warmth);

        // 3. 1073 Inductor Equalizer Section
        float eqSignal = vTrans;
        if (!isEqBypassed) {
            // 3a. High-Pass Filter (18 dB/oct Butterworth)
            if (hpfSetting != NeveHPFFreq::Off) {
                const auto hpfOut = hpfSvf.process(eqSignal);
                eqSignal = hpfOnePole.process(hpfOut.hp);
            }

            // 3b. Low Shelf (Resonant Inductor Tank)
            if (std::abs(lowGain) > 0.01f) {
                const auto lsOut = lowShelfSvf.process(eqSignal);
                // Shelving reconstruction: in + gainFactor * lowPass
                const float gFactor = dbToGain(lowGain) - 1.0f;
                eqSignal = eqSignal + lsOut.lp * gFactor;
            }

            // 3c. Mid Band (Dual-tapped Ferrite Inductor Asymmetric Bell)
            if (std::abs(midGain) > 0.01f) {
                const auto midOut = midSvf.process(eqSignal);
                const float gFactor = dbToGain(midGain) - 1.0f;
                eqSignal = eqSignal + midOut.bp * gFactor;
            }

            // 3d. High Shelf (12 kHz Baxandall Smooth Sheen)
            if (std::abs(highGain) > 0.01f) {
                const auto hsOut = highShelfSvf.process(eqSignal);
                const float gFactor = dbToGain(highGain) - 1.0f;
                eqSignal = eqSignal + hsOut.hp * gFactor;
            }
        }

        // 4. Output Trim & DC Blocking
        const float out = eqSignal * outGainLin;
        return dcBlocker.processSample(out);
    }

    // Process a block of audio samples
    void processBlock(float* buffer, size_t numSamples) noexcept {
        if (!buffer || numSamples == 0) return;
        for (size_t i = 0; i < numSamples; ++i) {
            buffer[i] = processSample(buffer[i]);
        }
    }

private:
    void updateCoefficients() noexcept {
        // HPF Cutoff Frequency mapping
        float hpfFc = 50.0f;
        switch (hpfSetting) {
            case NeveHPFFreq::Hz_50:  hpfFc = 50.0f;  break;
            case NeveHPFFreq::Hz_80:  hpfFc = 80.0f;  break;
            case NeveHPFFreq::Hz_160: hpfFc = 160.0f; break;
            case NeveHPFFreq::Hz_300: hpfFc = 300.0f; break;
            default: break;
        }
        if (hpfSetting != NeveHPFFreq::Off) {
            // 2-pole Butterworth (Q = 1.0) + 1-pole Butterworth for 18 dB/oct
            hpfSvf.setParameters(hpfFc, 1.0f, sr);
            hpfOnePole.setCutoff(hpfFc, sr);
        }

        // Low Shelf Frequency mapping
        float lowFc = 60.0f;
        switch (lowSetting) {
            case NeveLowFreq::Hz_35:  lowFc = 35.0f;  break;
            case NeveLowFreq::Hz_60:  lowFc = 60.0f;  break;
            case NeveLowFreq::Hz_110: lowFc = 110.0f; break;
            case NeveLowFreq::Hz_220: lowFc = 220.0f; break;
        }
        lowShelfSvf.setParameters(lowFc, 0.707f, sr);

        // Mid Band Frequency mapping (Dual-tapped Ferrite Inductor)
        float midFc = 1600.0f;
        switch (midSetting) {
            case NeveMidFreq::Hz_360: midFc = 360.0f;  break;
            case NeveMidFreq::Hz_700: midFc = 700.0f;  break;
            case NeveMidFreq::kHz_1_6: midFc = 1600.0f; break;
            case NeveMidFreq::kHz_3_2: midFc = 3200.0f; break;
            case NeveMidFreq::kHz_4_8: midFc = 4800.0f; break;
            case NeveMidFreq::kHz_7_2: midFc = 7200.0f; break;
        }
        // Inductor Q narrows moderately on extreme boost/cut
        const float midQ = 1.4f + 0.035f * std::abs(midGain);
        midSvf.setParameters(midFc, midQ, sr);

        // High Shelf fixed at 12 kHz Baxandall
        highShelfSvf.setParameters(12000.0f, 0.707f, sr);
    }

    float sr{44100.0f};
    float invSr{1.0f / 44100.0f};

    float inGainDb{0.0f};
    float inGainLin{1.0f};
    float warmth{0.5f};
    float outGainLin{1.0f};
    float biasSag{0.0f};

    NeveHPFFreq hpfSetting{NeveHPFFreq::Off};
    NeveLowFreq lowSetting{NeveLowFreq::Hz_60};
    float lowGain{0.0f};
    NeveMidFreq midSetting{NeveMidFreq::kHz_1_6};
    float midGain{0.0f};
    float highGain{0.0f};
    bool isEqBypassed{false};

    TransformerSaturator transformer;
    DCBlocker dcBlocker;

    ZDFSVF64 hpfSvf;
    ZDFOnePoleHP64 hpfOnePole;
    ZDFSVF64 lowShelfSvf;
    ZDFSVF64 midSvf;
    ZDFSVF64 highShelfSvf;
};

} // namespace dsp171
