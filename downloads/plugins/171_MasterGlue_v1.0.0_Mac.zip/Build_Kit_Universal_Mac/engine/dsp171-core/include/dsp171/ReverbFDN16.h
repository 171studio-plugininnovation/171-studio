#pragma once
#include <vector>
#include <array>
#include <cmath>
#include <algorithm>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// REVERB FDN-16 (16-CHANNEL ORTHOGONAL HOUSEHOLDER FEEDBACK DELAY NETWORK)
//
// Motore di riverbero a 16 rami con matrice ortogonale di Householder O(N).
// Garantisce conservazione unitaria dell'energia (matrice Hermitiana priva di
// autovalori instabili), densita modale massima ed assenza totale di risonanze.
//
// Caratteristiche d'avanguardia:
// 1. Ritardi primi coprimi per evitare battimenti e comb filtering.
// 2. Modulazione dei puntatori di lettura in quadratura di fase (Sean Costello/Lexicon)
//    per dissolvere i modi stazionari in una nuvola acustica omogenea.
// 3. Smorzamento per frequenza (High-Damping ed estensione Low-Warmth).
// 4. Modalita Freeze infinita priva di degrado o accumulo di offset DC.
// 5. Ingressi dedicati per segnale di shimmer o rigenerazione armonica.
// =============================================================================

class ReverbFDN16 {
public:
    static constexpr int NUM_LINES = 16;

    // Ritardi primi accuratamente spaziati (base 48 kHz)
    static constexpr int PRIME_DELAYS[NUM_LINES] = {
        1039, 1153, 1283, 1429, 1579, 1753, 1949, 2153,
        2381, 2633, 2909, 3217, 3557, 3931, 4349, 4801
    };

    ReverbFDN16() {
        delayLengths.fill(1000);
        writePointers.fill(0);
        feedbackGains.fill(0.85f);
        dampState.fill(0.0f);
    }

    void prepare(double sampleRate) {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        scaleFactor = static_cast<float>(sr / 48000.0);
        lfoPhase = 0.0f;
        lfoRate = static_cast<float>(2.0 * PI_D * 0.65 / sr); // 0.65 Hz rate

        for (int i = 0; i < NUM_LINES; ++i) {
            int len = static_cast<int>(PRIME_DELAYS[i] * scaleFactor);
            delayLengths[i] = len;
            int maxCap = std::max(16384, len * 4);
            delayBuffers[i].assign(maxCap, 0.0f);
            writePointers[i] = 0;
            feedbackGains[i] = 0.85f;
            dampState[i] = 0.0f;
        }

        updateDecay(2.5f, 1.0f, 0.0f);
        updateDamping(6500.0f);
    }

    void reset() noexcept {
        for (int i = 0; i < NUM_LINES; ++i) {
            std::fill(delayBuffers[i].begin(), delayBuffers[i].end(), 0.0f);
            writePointers[i] = 0;
            dampState[i] = 0.0f;
        }
        lfoPhase = 0.0f;
    }

    void updateDecay(float decayTimeSec, float roomSizeFactor = 1.0f, float lowWarmthDb = 0.0f) noexcept {
        currentDecay = std::max(0.1f, decayTimeSec);
        isFreeze = (decayTimeSec >= 19.5f);
        float bassMult = 1.0f + std::clamp(lowWarmthDb, -6.0f, 6.0f) * 0.04f;

        for (int i = 0; i < NUM_LINES; ++i) {
            float effLen = static_cast<float>(delayLengths[i]) * std::clamp(roomSizeFactor, 0.5f, 2.0f);
            if (isFreeze) {
                feedbackGains[i] = 0.999f;
            } else {
                float targetDecay = (i >= 8) ? (currentDecay * bassMult) : currentDecay;
                targetDecay = std::max(0.1f, targetDecay);
                float exponent = -3.0f * effLen / (targetDecay * static_cast<float>(sr));
                feedbackGains[i] = std::pow(10.0f, exponent);
                feedbackGains[i] = std::clamp(feedbackGains[i], 0.0f, 0.985f);
            }
        }
    }

    void updateDamping(float highDampingHz) noexcept {
        float fCut = std::clamp(highDampingHz, 800.0f, 20000.0f);
        dampAlpha = 1.0f - std::exp(-2.0f * PI * fCut / static_cast<float>(sr));
    }

    void setModulation(float depthSamples = 3.2f, float rateHz = 0.65f) noexcept {
        modDepth = std::clamp(depthSamples, 0.0f, 12.0f);
        lfoRate = static_cast<float>(2.0 * PI_D * std::clamp(rateHz, 0.05f, 5.0f) / sr);
    }

    inline void processSample(float inL, float inR,
                              float extFeedL, float extFeedR,
                              float& outL, float& outR) noexcept {
        std::array<float, NUM_LINES> readSamples;

        // Avanzamento LFO di modulazione
        lfoPhase += lfoRate;
        if (lfoPhase >= 2.0f * PI) lfoPhase -= 2.0f * PI;

        // 1. Lettura con modulazione di fase in quadratura distribuita
        for (int i = 0; i < NUM_LINES; ++i) {
            float phaseOffset = static_cast<float>(i) * (PI / 8.0f); // 22.5 gradi tra linee
            float modOffset = std::sin(lfoPhase + phaseOffset) * modDepth;
            float rPosF = static_cast<float>(writePointers[i] - delayLengths[i]) + modOffset;
            int cap = static_cast<int>(delayBuffers[i].size());
            while (rPosF < 0.0f) rPosF += static_cast<float>(cap);
            int idx0 = static_cast<int>(rPosF);
            int idx1 = (idx0 + 1) % cap;
            float frac = rPosF - static_cast<float>(idx0);

            float raw = delayBuffers[i][idx0] + frac * (delayBuffers[i][idx1] - delayBuffers[i][idx0]);

            // Smorzamento passa-basso analogico
            dampState[i] += (raw - dampState[i]) * dampAlpha;
            readSamples[i] = dampState[i] * feedbackGains[i];
        }

        // 2. Matrice di Scattering Ortogonale di Householder O(N)
        // H = I - (2/N) * 1 * 1^T
        float sum = 0.0f;
        for (int i = 0; i < NUM_LINES; ++i) {
            sum += readSamples[i];
        }
        float householderFactor = sum * (2.0f / static_cast<float>(NUM_LINES));

        std::array<float, NUM_LINES> scattered;
        for (int i = 0; i < NUM_LINES; ++i) {
            scattered[i] = readSamples[i] - householderFactor;
        }

        // 3. Iniezione ingresso stereo + rigenerazione + feedback
        float sumL = 0.0f;
        float sumR = 0.0f;

        for (int i = 0; i < NUM_LINES; ++i) {
            float inSig = (i % 2 == 0) ? inL : inR;
            if (i % 4 == 0) inSig += extFeedL;
            if (i % 4 == 1) inSig += extFeedR;

            float toWrite = inSig + scattered[i];

            // Soft-saturation analogica anti-clipping di sicurezza (fastTanh)
            if (toWrite > 1.2f || toWrite < -1.2f) {
                toWrite = fastTanh(toWrite * 0.75f) * 1.333f;
            }

            delayBuffers[i][writePointers[i]] = toWrite;
            writePointers[i] = (writePointers[i] + 1) % static_cast<int>(delayBuffers[i].size());

            // Decodifica stereofonica decorrelata a polarita alternata
            if (i % 2 == 0) sumL += scattered[i] * ((i < 8) ? 1.0f : -0.7f);
            else            sumR += scattered[i] * ((i < 8) ? 0.7f : -1.0f);
        }

        constexpr float NORM = 0.35f;
        outL = sumL * NORM;
        outR = sumR * NORM;
    }

private:
    double sr = 48000.0;
    float scaleFactor = 1.0f;
    float currentDecay = 2.5f;
    float dampAlpha = 0.5f;
    bool isFreeze = false;
    float lfoPhase = 0.0f;
    float lfoRate = 0.000085f;
    float modDepth = 3.2f;

    std::array<int, NUM_LINES> delayLengths;
    std::array<std::vector<float>, NUM_LINES> delayBuffers;
    std::array<int, NUM_LINES> writePointers;
    std::array<float, NUM_LINES> dampState;
    std::array<float, NUM_LINES> feedbackGains;
};

} // namespace dsp171
