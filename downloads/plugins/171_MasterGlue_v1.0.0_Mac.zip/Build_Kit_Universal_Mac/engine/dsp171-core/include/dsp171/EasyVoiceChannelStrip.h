#pragma once

#include <cmath>
#include <algorithm>
#include <array>
#include "Common.h"
#include "FastMath.h"
#include "SafetyCeiling.h"
#include "SmoothBypass.h"
#include "NLSSummingDSP.h"
#include "TransformerSaturator.h"
#include "RenaissanceDeEsser.h"
#include "SSLGChannelEQ.h"
#include "CLA76Compressor.h"
#include "CLA2ACompressor.h"
#include "VocalNoiseExpander.h"
#include "MaagAirResonance.h"
#include "VocalDoublerSpatial.h"
#include "SmartLoudnessWorkflow.h"

namespace dsp171 {

// =============================================================================
// EasyVoiceChannelStrip (171EasyVoice Pro)
// All-Star Vocal Channel Strip & Modern Workflow Master
//
// Complete 8-Stage Series Signal Chain:
// 1. EXPANDER / GATE:  Vocal Noise Expander with Schmitt Hysteresis & Vocal Bandpass SC
// 2. PREAMP:           Neve 5116 'Nevo' Console + Marinair LO1166 Core Saturation
// 3. DE-ESSER:         Waves Renaissance DeEsser (Split-Band / Wideband Crossover)
// 4. EQUALIZER:        SSL 4000 G-Series 242 Black Knob 4-Band Parametric + HPF/LPF
// 5. AIR & DE-HARSH:   Maag Audio EQ4 Air Band (2.5k-40kHz) + Adaptive Dynamic Resonance Notch
// 6. DUAL DYNAMICS:
//    - Stage 6A:       Teletronix LA-2A T4B Opto Leveler (Smooth 2-4 dB macro leveling)
//    - Stage 6B:       UAD 1176LN FET Peak Limiter (Ultra-fast peak catching, All-Buttons)
// 7. DIMENSION:        Vocal Doubler & Micro-Pitch (Hermite fractional, 100% mono-safe)
// 8. MASTER WORKFLOW:  Smart Loudness Matching (ITU-R BS.1770-4), Delta Listen, Safety Soft Ceiling
//
// Hard Real-Time: strictly 0 heap allocations, deterministic 0 samples latency.
// =============================================================================

class EasyVoiceChannelStrip {
public:
    EasyVoiceChannelStrip() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);

        // 1. Expander / Gate
        expander.prepare(sampleRate);

        // 2. Preamp (Neve 5116 + Marinair)
        nlsPreamp.prepare(sampleRate);
        nlsPreamp.setConsole(NLSSummingDSP::ConsoleType::Nevo);
        nlsPreamp.setMode(NLSSummingDSP::ComponentMode::Channel);
        nlsPreamp.setChannelIndex(1);
        nlsPreamp.setNoise(false);

        marinairSatL.prepare(sampleRate);
        marinairSatR.prepare(sampleRate);

        // 3. De-Esser
        deEsser.prepare(sampleRate);

        // 4. SSL 4000 G EQ
        sslEQ.prepare(sampleRate);

        // 5. Maag Air & De-Harsh
        maagAir.prepare(sampleRate);

        // 6. Dual-Stage Dynamics (LA-2A + 1176)
        optoComp.prepare(sampleRate);
        fetComp.prepare(sampleRate);

        // 7. Vocal Doubler
        doubler.prepare(sampleRate);

        // 8. Smart Master
        smartMaster.prepare(sampleRate);
        masterBypass.prepare(sampleRate, 0.015);

        reset();
    }

    void reset() noexcept {
        expander.reset();
        nlsPreamp.reset();
        marinairSatL.reset();
        marinairSatR.reset();
        deEsser.reset();
        sslEQ.reset();
        maagAir.reset();
        optoComp.reset();
        fetComp.reset();
        doubler.reset();
        smartMaster.reset();
        masterBypass.reset();

        inputMeterL = 0.0f;
        inputMeterR = 0.0f;
        outputMeterL = 0.0f;
        outputMeterR = 0.0f;

        dryL.fill(0.0f);
        dryR.fill(0.0f);
        preCompL.fill(0.0f);
        preCompR.fill(0.0f);
    }

    // =========================================================================
    // 1. EXPANDER / GATE CONTROLS
    // =========================================================================
    void setExpanderEnabled(bool enabled) noexcept { expanderEnabled = enabled; }
    void setExpanderThreshold(float threshDb) noexcept { expander.setThreshold(threshDb); }
    void setExpanderHysteresis(float hystDb) noexcept { expander.setHysteresis(hystDb); }
    void setExpanderRange(float rangeDb) noexcept { expander.setRange(rangeDb); }
    void setExpanderRatio(float ratio) noexcept { expander.setRatio(ratio); }
    void setExpanderHoldMs(float holdMs) noexcept { expander.setHoldMs(holdMs); }
    void setExpanderReleaseMs(float relMs) noexcept { expander.setReleaseMs(relMs); }
    void setExpanderMode(VocalNoiseExpander::Mode m) noexcept { expander.setMode(m); }

    // =========================================================================
    // 2. PREAMP CONTROLS (Neve 5116 + Marinair LO1166)
    // =========================================================================
    void setPreampEnabled(bool enabled) noexcept { preampBypass = !enabled; }
    void setPreampDrive(float drive0To12) noexcept {
        preampDrive = std::clamp(drive0To12, 0.0f, 12.0f);
        nlsPreamp.setDrive(preampDrive);
    }
    void setPreampWarmth(float warmth0To10) noexcept {
        preampWarmth = std::clamp(warmth0To10, 0.0f, 10.0f);
    }
    void setPreampTrim(float trimDb) noexcept {
        nlsPreamp.setTrimDb(trimDb);
    }
    void setPreampConsole(NLSSummingDSP::ConsoleType type) noexcept {
        nlsPreamp.setConsole(type);
    }
    [[nodiscard]] NLSSummingDSP::ConsoleType getPreampConsole() const noexcept {
        return nlsPreamp.getConsole();
    }

    // =========================================================================
    // 3. DE-ESSER CONTROLS (Waves Renaissance DeEsser)
    // =========================================================================
    void setDeEsserEnabled(bool enabled) noexcept { deEsserBypass = !enabled; }
    void setDeEsserFrequency(float freqHz) noexcept { deEsser.setFrequency(freqHz); }
    void setDeEsserThreshold(float threshDb) noexcept { deEsser.setThresholdDb(threshDb); }
    void setDeEsserThresholdDb(float threshDb) noexcept { deEsser.setThresholdDb(threshDb); }
    void setDeEsserRange(float rangeDb) noexcept { deEsser.setRangeDb(rangeDb); }
    void setDeEsserRangeDb(float rangeDb) noexcept { deEsser.setRangeDb(rangeDb); }
    void setDeEsserMode(RenaissanceDeEsser::DeEsserMode m) noexcept { deEsser.setMode(m); }
    void setDeEsserSidechainType(RenaissanceDeEsser::SidechainType t) noexcept { deEsser.setSidechainType(t); }
    void setDeEsserListenMode(RenaissanceDeEsser::ListenMode l) noexcept { deEsser.setListenMode(l); }

    // =========================================================================
    // 4. EQUALIZER CONTROLS (SSL 4000 G-Series 242)
    // =========================================================================
    void setEQEnabled(bool enabled) noexcept { eqBypass = !enabled; }
    void setHPFFreq(float freqHz) noexcept { sslEQ.setHPFFreq(freqHz); }
    void setLPFFreq(float freqHz) noexcept { sslEQ.setLPFFreq(freqHz); }
    void setLF(float freqHz, float gainDb, SSLGChannelEQ::BandType type) noexcept {
        sslEQ.setLF(freqHz, gainDb, type);
    }
    void setLF(float freqHz, float gainDb, bool bell) noexcept {
        sslEQ.setLF(freqHz, gainDb, bell ? SSLGChannelEQ::BandType::Bell : SSLGChannelEQ::BandType::Shelf);
    }
    void setLMF(float freqHz, float gainDb, float q) noexcept { sslEQ.setLMF(freqHz, gainDb, q); }
    void setHMF(float freqHz, float gainDb, float q) noexcept { sslEQ.setHMF(freqHz, gainDb, q); }
    void setHF(float freqHz, float gainDb, SSLGChannelEQ::BandType type) noexcept {
        sslEQ.setHF(freqHz, gainDb, type);
    }
    void setHF(float freqHz, float gainDb, bool bell) noexcept {
        sslEQ.setHF(freqHz, gainDb, bell ? SSLGChannelEQ::BandType::Bell : SSLGChannelEQ::BandType::Shelf);
    }

    // =========================================================================
    // 5. AIR BAND & DE-HARSH CONTROLS (Maag Audio EQ4 + Dynamic Tamer)
    // =========================================================================
    void setAirEnabled(bool enabled) noexcept { maagAir.setAirEnabled(enabled); }
    void setAirGain(float gainDb) noexcept { maagAir.setAirGain(gainDb); }
    void setAirFrequency(MaagAirResonance::AirFreq freq) noexcept { maagAir.setAirFrequency(freq); }
    void setDeHarshEnabled(bool enabled) noexcept { maagAir.setDeHarshEnabled(enabled); }
    void setDeHarshThreshold(float threshDb) noexcept { maagAir.setDeHarshThreshold(threshDb); }
    void setDeHarshDepth(float depthDb) noexcept { maagAir.setDeHarshDepth(depthDb); }
    void setDeHarshCenterFreq(float centerHz) noexcept { maagAir.setDeHarshCenterFreq(centerHz); }

    // =========================================================================
    // 6. DUAL DYNAMICS CONTROLS (LA-2A Opto + 1176 FET)
    // =========================================================================
    // 6A. LA-2A Opto Leveler
    void setOptoEnabled(bool enabled) noexcept { optoEnabled = enabled; }
    void setOptoPeakReduction(float pr0To100) noexcept { optoComp.setPeakReduction(pr0To100); }
    void setOptoGain(float gain0To100) noexcept { optoComp.setGain(gain0To100); }
    void setOptoMode(CLA2ACompressor::Mode m) noexcept { optoComp.setMode(m); }
    void setOptoCompressMode(bool isCompress) noexcept { optoComp.setLimitMode(!isCompress); }
    void setOptoHiFreq(float hf0To100) noexcept { optoComp.setHiFreq(hf0To100); }
    [[nodiscard]] int getLatencyInSamples() const noexcept { return 0; }

    // 6B. 1176 FET Peak Limiter
    void setCompressorEnabled(bool enabled) noexcept { compBypass = !enabled; }
    void setCompInput(float inDb) noexcept { fetComp.setInputDb(inDb); }
    void setCompInputDb(float inDb) noexcept { fetComp.setInputDb(inDb); }
    void setCompOutput(float outDb) noexcept { fetComp.setOutputDb(outDb); }
    void setCompOutputDb(float outDb) noexcept { fetComp.setOutputDb(outDb); }
    void setCompAttack(float attackMicroSec) noexcept {
        float knob = (attackMicroSec >= 1.0f && attackMicroSec <= 7.0f) ? attackMicroSec
                   : (7.0f - (attackMicroSec - 20.0f) / 130.0f);
        fetComp.setAttackKnob(std::clamp(knob, 1.0f, 7.0f));
    }
    void setCompAttackKnob(float knob1To7) noexcept { fetComp.setAttackKnob(knob1To7); }
    void setCompRelease(float releaseMilliSec) noexcept {
        float knob = (releaseMilliSec >= 1.0f && releaseMilliSec <= 7.0f) ? releaseMilliSec
                   : (7.0f - (releaseMilliSec - 50.0f) / 160.0f);
        fetComp.setReleaseKnob(std::clamp(knob, 1.0f, 7.0f));
    }
    void setCompReleaseKnob(float knob1To7) noexcept { fetComp.setReleaseKnob(knob1To7); }
    void setCompRatio(CLA76Compressor::Ratio r) noexcept { fetComp.setRatio(r); }
    void setCompRevision(CLA76Compressor::Revision rev) noexcept { fetComp.setRevision(rev); }
    void setCompSCFilter(bool enabled) noexcept { fetComp.setSidechainHighPass(enabled); }
    [[nodiscard]] bool isCompSCFilter() const noexcept { return fetComp.isSidechainHighPass(); }
    void setCompMix(float mix0To100) noexcept { compMix = std::clamp(mix0To100 * 0.01f, 0.0f, 1.0f); }

    // =========================================================================
    // 7. VOCAL DOUBLER & MICRO-PITCH CONTROLS
    // =========================================================================
    void setDoublerEnabled(bool enabled) noexcept { doubler.setEnabled(enabled); }
    void setDoublerDetune(float cents) noexcept { doubler.setDetuneCents(cents); }
    void setDoublerDelay(float ms) noexcept { doubler.setDelayMs(ms); }
    void setDoublerWidth(float w) noexcept { doubler.setWidth(w); }
    void setDoublerMix(float mix0To100) noexcept { doubler.setMix(mix0To100 * 0.01f); }

    // =========================================================================
    // 8. MASTER & WORKFLOW CONTROLS
    // =========================================================================
    void setBypass(bool bypassed) noexcept { masterBypass.setBypassTarget(bypassed); }
    [[nodiscard]] bool isBypassed() const noexcept { return masterBypass.isFullyBypassed(); }

    void setMasterTrim(float trimDb) noexcept {
        masterTrim = std::clamp(trimDb, -18.0f, 18.0f);
        smartMaster.setMasterTrim(masterTrim);
    }
    void setMasterOutputTrimDb(float trimDb) noexcept { setMasterTrim(trimDb); }

    void setGlobalMix(float mix0To100) noexcept {
        globalMix = std::clamp(mix0To100 * 0.01f, 0.0f, 1.0f);
    }
    void setGlobalMixPercent(float mix0To100) noexcept { setGlobalMix(mix0To100); }

    void setAutoGainEnabled(bool enable) noexcept { smartMaster.setAutoGainEnabled(enable); }
    void setDeltaListenEnabled(bool enable) noexcept { smartMaster.setDeltaListenEnabled(enable); }

    // =========================================================================
    // TELEMETRY & METERING
    // =========================================================================
    [[nodiscard]] float getExpanderGR() const noexcept {
        return std::max(expander.getGainReductionL(), expander.getGainReductionR());
    }
    [[nodiscard]] float getDeEsserGR() const noexcept { return deEsser.getGainReductionL(); }
    [[nodiscard]] float getDeEsserGR_dB() const noexcept { return deEsser.getGainReductionL(); }
    [[nodiscard]] float getDeHarshGR() const noexcept { return maagAir.getDeHarshGainReduction(); }
    [[nodiscard]] float getOptoGR() const noexcept { return optoComp.getGainReductionL(); }
    [[nodiscard]] float getCompGR() const noexcept { return fetComp.getGainReductionL(); }
    [[nodiscard]] float getCompressorGR_dB() const noexcept { return fetComp.getGainReductionL(); }
    [[nodiscard]] float getInputLUFS() const noexcept { return smartMaster.getInputLUFS(); }
    [[nodiscard]] float getOutputLUFS() const noexcept { return smartMaster.getOutputLUFS(); }
    [[nodiscard]] float getInputPeak() const noexcept { return std::max(inputMeterL, inputMeterR); }
    [[nodiscard]] float getOutputPeak() const noexcept { return std::max(outputMeterL, outputMeterR); }
    [[nodiscard]] float getOutputMeterL() const noexcept { return outputMeterL; }
    [[nodiscard]] float getOutputMeterR() const noexcept { return outputMeterR; }

    void processBlock(float* left, float* right, int numSamples) noexcept {
        float* channels[2] = { left, right };
        process(channels, right ? 2 : 1, numSamples);
    }

    // =========================================================================
    // AUDIO PROCESSING BLOCK
    // =========================================================================
    void process(float* const* channelData, int numChannels, int numSamples) noexcept {
        if (numChannels <= 0 || numSamples <= 0) return;

        float* left = channelData[0];
        float* right = (numChannels > 1) ? channelData[1] : nullptr;

        // Peak tracking on Input
        float inMaxL = 0.0f, inMaxR = 0.0f;
        for (int i = 0; i < numSamples; ++i) {
            inMaxL = std::max(inMaxL, std::abs(left[i]));
            if (right) inMaxR = std::max(inMaxR, std::abs(right[i]));
        }
        inputMeterL = inMaxL;
        inputMeterR = right ? inMaxR : inMaxL;

        // Store dry input block for Dry/Wet mix & Delta auditioning
        int safeSamples = std::min(numSamples, MAX_BLOCK);

        for (int i = 0; i < safeSamples; ++i) {
            dryL[i] = left[i];
            dryR[i] = right ? right[i] : left[i];
        }

        const float* dryPointers[2] = { dryL.data(), dryR.data() };

        // Analyze input block for K-weighted loudness
        smartMaster.analyzeInputBlock(dryPointers, numChannels, safeSamples);

        // --- STAGE 1: VOCAL NOISE EXPANDER / GATE ---
        if (expanderEnabled) {
            expander.process(channelData, numChannels, numSamples);
        }

        // --- STAGE 2: PREAMP (Neve 5116 + Marinair LO1166) ---
        if (!preampBypass) {
            nlsPreamp.process(left, right ? right : left, static_cast<size_t>(numSamples));

            if (preampWarmth > 0.01f) {
                float satDrive = preampWarmth * 0.15f;
                for (int i = 0; i < numSamples; ++i) {
                    left[i] = marinairSatL.processSample(left[i], satDrive, 0.40f);
                    if (right) {
                        right[i] = marinairSatR.processSample(right[i], satDrive, 0.40f);
                    }
                }
            }
        }

        // --- STAGE 3: WAVES R-DEESSER ---
        if (!deEsserBypass) {
            for (int i = 0; i < numSamples; ++i) {
                float outL = 0.0f, outR = 0.0f;
                deEsser.processSample(left[i], right ? right[i] : left[i], outL, outR);
                left[i] = outL;
                if (right) right[i] = outR;
            }
        }

        // --- STAGE 4: SSL 4000 G-SERIES 242 EQ ---
        if (!eqBypass) {
            for (int i = 0; i < numSamples; ++i) {
                float outL = 0.0f, outR = 0.0f;
                sslEQ.processSample(left[i], right ? right[i] : left[i], outL, outR);
                left[i] = outL;
                if (right) right[i] = outR;
            }
        }

        // --- STAGE 5: MAAG AIR BAND & DE-HARSH ---
        maagAir.process(channelData, numChannels, numSamples);

        // --- STAGE 6A: LA-2A T4B OPTO LEVELER ---
        if (optoEnabled) {
            optoComp.process(left, right ? right : left, static_cast<size_t>(numSamples));
        }

        // --- STAGE 6B: UAD 1176LN FET PEAK LIMITER ---
        if (!compBypass) {
            if (compMix < 0.999f) {
                // Parallel FET compression
                for (int i = 0; i < safeSamples; ++i) {
                    preCompL[i] = left[i];
                    preCompR[i] = right ? right[i] : left[i];
                }

                fetComp.process(left, right ? right : left, static_cast<size_t>(numSamples));

                for (int i = 0; i < safeSamples; ++i) {
                    left[i] = preCompL[i] * (1.0f - compMix) + left[i] * compMix;
                    if (right) {
                        right[i] = preCompR[i] * (1.0f - compMix) + right[i] * compMix;
                    }
                }
            } else {
                fetComp.process(left, right ? right : left, static_cast<size_t>(numSamples));
            }
        }

        // --- STAGE 7: VOCAL DOUBLER & MICRO-PITCH ---
        doubler.process(channelData, numChannels, numSamples);

        // --- STAGE 8: GLOBAL PARALLEL MIX & SMART MASTER ---
        if (globalMix < 0.999f) {
            for (int i = 0; i < safeSamples; ++i) {
                left[i] = dryL[i] * (1.0f - globalMix) + left[i] * globalMix;
                if (right) {
                    right[i] = dryR[i] * (1.0f - globalMix) + right[i] * globalMix;
                }
            }
        }

        // Smart Master (Loudness Matching, Delta Solo, Hermite Soft Ceiling)
        smartMaster.processMaster(channelData, dryPointers, numChannels, safeSamples);

        // Pop-free master clickless bypass
        for (int i = 0; i < numSamples; ++i) {
            float bpVal = masterBypass.getNextValue();
            left[i] = dryL[i] * bpVal + left[i] * (1.0f - bpVal);
            if (right) {
                right[i] = dryR[i] * bpVal + right[i] * (1.0f - bpVal);
            }
        }

        // Output Peak Metering
        float outMaxL = 0.0f, outMaxR = 0.0f;
        for (int i = 0; i < numSamples; ++i) {
            outMaxL = std::max(outMaxL, std::abs(left[i]));
            if (right) outMaxR = std::max(outMaxR, std::abs(right[i]));
        }
        outputMeterL = outMaxL;
        outputMeterR = right ? outMaxR : outMaxL;
    }

private:
    static constexpr int MAX_BLOCK = 4096;
    float sr = 48000.0f;

    // Submodules
    VocalNoiseExpander expander;
    NLSSummingDSP nlsPreamp;
    TransformerSaturator marinairSatL;
    TransformerSaturator marinairSatR;
    RenaissanceDeEsser deEsser;
    SSLGChannelEQ sslEQ;
    MaagAirResonance maagAir;
    CLA2ACompressor optoComp;
    CLA76Compressor fetComp;
    VocalDoublerSpatial doubler;
    SmartLoudnessWorkflow smartMaster;
    SmoothBypass masterBypass;

    // Bypasses & States
    bool expanderEnabled = false; // Off by default until dialed in
    bool preampBypass = false;
    bool deEsserBypass = false;
    bool eqBypass = false;
    bool optoEnabled = true;      // Dual-Stage Active
    bool compBypass = false;

    // Parameters
    float preampDrive = 3.0f;
    float preampWarmth = 4.0f;
    float compMix = 1.0f;
    float masterTrim = 0.0f;
    float globalMix = 1.0f;

    // Telemetry
    float inputMeterL = 0.0f;
    float inputMeterR = 0.0f;
    float outputMeterL = 0.0f;
    float outputMeterR = 0.0f;

    // Pre-allocated Real-Time Scratch Buffers (Zero Stack & Zero Heap Allocations)
    std::array<float, MAX_BLOCK> dryL{};
    std::array<float, MAX_BLOCK> dryR{};
    std::array<float, MAX_BLOCK> preCompL{};
    std::array<float, MAX_BLOCK> preCompR{};
};

} // namespace dsp171
