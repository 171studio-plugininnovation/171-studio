#pragma once
#include <cmath>
#include <algorithm>
#include <vector>

namespace dsp171 {

/**
 * @brief WavesHDelay
 * Reverse-engineered from Waves H-Delay Hybrid Delay.
 * Classic analog-modeled delay featuring tape-style pitch-glide modulation,
 * ping-pong stereo bouncing, resonant low-cut/high-cut filters, lo-fi bitcrushing,
 * and up to 200% self-oscillating feedback with an internal protection limiter.
 */
class WavesHDelay {
public:
    enum class AnalogMode {
        Off,
        Mode1, // 50 Hz transformer warm
        Mode2, // 60 Hz bright tape
        Mode3, // Heavy tube saturation
        Mode4  // Dark vintage console
    };

    WavesHDelay() noexcept 
        : m_sampleRate(44100.0f) {}

    void prepare(float sampleRate) noexcept {
        m_sampleRate = sampleRate;
        size_t maxDelaySamples = static_cast<size_t>(sampleRate * 4.0f); // 4 seconds max
        m_bufferL.assign(maxDelaySamples, 0.0f);
        m_bufferR.assign(maxDelaySamples, 0.0f);
        m_writeIdx = 0;
        m_lfoPhase = 0.0f;
        m_hpL = 0.0f; m_hpR = 0.0f;
        m_lpL = 0.0f; m_lpR = 0.0f;
    }

    void setParameters(float delayTimeMs = 350.0f, float feedbackPercent = 50.0f,
                       bool pingPong = false, float hpFreq = 20.0f, float lpFreq = 16000.0f,
                       AnalogMode analog = AnalogMode::Mode1, bool loFi = false,
                       float modDepthPercent = 10.0f, float modRateHz = 1.0f,
                       float mixPercent = 50.0f) noexcept {
        m_targetDelaySamples = std::clamp(delayTimeMs * 0.001f * m_sampleRate, 1.0f, m_sampleRate * 3.5f);
        m_feedback = std::clamp(feedbackPercent, 0.0f, 200.0f) * 0.01f;
        m_pingPong = pingPong;
        m_hpFreq = std::clamp(hpFreq, 20.0f, 2000.0f);
        m_lpFreq = std::clamp(lpFreq, 1000.0f, 20000.0f);
        m_analog = analog;
        m_loFi = loFi;
        m_modDepth = std::clamp(modDepthPercent, 0.0f, 100.0f) * 0.01f * 15.0f; // max 15 samples of flutter
        m_modRate = std::clamp(modRateHz, 0.1f, 6.0f);
        m_mix = std::clamp(mixPercent, 0.0f, 100.0f) * 0.01f;
    }

    inline void process(float inL, float inR, float& outL, float& outR) noexcept {
        size_t bufSize = m_bufferL.size();

        // 1. LFO Pitch Glide Modulation
        m_lfoPhase += (2.0f * 3.14159265f * m_modRate) / m_sampleRate;
        if (m_lfoPhase >= 2.0f * 3.14159265f) m_lfoPhase -= 2.0f * 3.14159265f;
        float flutterOffset = std::sin(m_lfoPhase) * m_modDepth;

        // Smooth delay time glide (tape pitch-shift behavior)
        m_currentDelaySamples += 0.0005f * (m_targetDelaySamples - m_currentDelaySamples);
        float totalDelaySamples = std::clamp(m_currentDelaySamples + flutterOffset, 2.0f, static_cast<float>(bufSize - 4));

        // 2. Read from delay buffer with 4-point Cubic Hermite Spline interpolation (zero HF roll-off)
        float readPos = static_cast<float>(m_writeIdx) - totalDelaySamples;
        while (readPos < 0.0f) readPos += static_cast<float>(bufSize);

        size_t idx0 = static_cast<size_t>(readPos) % bufSize;
        size_t idx_m1 = (idx0 + bufSize - 1) % bufSize;
        size_t idx1 = (idx0 + 1) % bufSize;
        size_t idx2 = (idx0 + 2) % bufSize;
        float frac = readPos - static_cast<float>(static_cast<size_t>(readPos));

        auto hermite4p = [](float ym1, float y0, float y1, float y2, float t) noexcept {
            float c0 = y0;
            float c1 = 0.5f * (y1 - ym1);
            float c2 = ym1 - 2.5f * y0 + 2.0f * y1 - 0.5f * y2;
            float c3 = 0.5f * (y2 - ym1) + 1.5f * (y0 - y1);
            return ((c3 * t + c2) * t + c1) * t + c0;
        };

        float delayedL = hermite4p(m_bufferL[idx_m1], m_bufferL[idx0], m_bufferL[idx1], m_bufferL[idx2], frac);
        float delayedR = hermite4p(m_bufferR[idx_m1], m_bufferR[idx0], m_bufferR[idx1], m_bufferR[idx2], frac);

        // 3. Lo-Fi Decimation & Bit-crush
        if (m_loFi) {
            delayedL = std::round(delayedL * 128.0f) / 128.0f; // 8-bit quantization
            delayedR = std::round(delayedR * 128.0f) / 128.0f;
        }

        // 4. Analog Saturation & Headroom Limiter on Feedback Loop
        float fbL = delayedL;
        float fbR = delayedR;
        if (m_analog != AnalogMode::Off) {
            fbL = std::tanh(fbL * 1.15f);
            fbR = std::tanh(fbR * 1.15f);
        }

        // Internal feedback protection limiter (allows self-oscillation without digital wrap)
        fbL = std::clamp(fbL, -1.8f, 1.8f);
        fbR = std::clamp(fbR, -1.8f, 1.8f);

        // 5. Feedback Filtering (HPF and LPF)
        float alphaHP = m_hpFreq / (m_hpFreq + m_sampleRate / 6.2831853f);
        m_hpL += alphaHP * (fbL - m_hpL);
        m_hpR += alphaHP * (fbR - m_hpR);
        fbL -= m_hpL;
        fbR -= m_hpR;

        float alphaLP = m_lpFreq / (m_lpFreq + m_sampleRate / 6.2831853f);
        m_lpL += alphaLP * (fbL - m_lpL);
        m_lpR += alphaLP * (fbR - m_lpR);
        fbL = m_lpL;
        fbR = m_lpR;

        // 6. Ping-Pong routing
        if (m_pingPong) {
            float temp = fbL;
            fbL = fbR;
            fbR = temp;
        }

        // 7. Write into delay line
        m_bufferL[m_writeIdx] = inL + (fbL * m_feedback);
        m_bufferR[m_writeIdx] = inR + (fbR * m_feedback);
        m_writeIdx = (m_writeIdx + 1) % bufSize;

        // 8. Wet/Dry Output Mix
        outL = inL * (1.0f - m_mix) + delayedL * m_mix;
        outR = inR * (1.0f - m_mix) + delayedR * m_mix;
    }

    void processBlock(float* left, float* right, int numSamples) noexcept {
        for (int i = 0; i < numSamples; ++i) {
            process(left[i], right[i], left[i], right[i]);
        }
    }

private:
    float m_sampleRate;
    float m_targetDelaySamples{15435.0f};
    float m_currentDelaySamples{15435.0f};
    float m_feedback{0.5f};
    bool m_pingPong{false};
    float m_hpFreq{20.0f};
    float m_lpFreq{16000.0f};
    AnalogMode m_analog{AnalogMode::Mode1};
    bool m_loFi{false};
    float m_modDepth{0.0f};
    float m_modRate{1.0f};
    float m_mix{0.5f};

    std::vector<float> m_bufferL;
    std::vector<float> m_bufferR;
    size_t m_writeIdx{0};
    float m_lfoPhase{0.0f};

    float m_hpL{0.0f}, m_hpR{0.0f};
    float m_lpL{0.0f}, m_lpR{0.0f};
};

} // namespace dsp171
