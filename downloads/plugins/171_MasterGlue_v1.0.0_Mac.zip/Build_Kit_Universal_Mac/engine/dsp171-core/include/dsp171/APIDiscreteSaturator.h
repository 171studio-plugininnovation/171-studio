#pragma once

#include <cmath>
#include <algorithm>
#include "Common.h"
#include "DCBlocker.h"
#include "FastMath.h"

namespace dsp171 {

// =============================================================================
// APIDiscreteSaturator
// Crafted by: sat-api-specialist (Supervised by dsp-hire-manager)
//
// Physical modeling of classic American analog console punch:
// 1. API 2520 Discrete Operational Amplifier:
//    - Slew-rate limiting on fast transients (approx. 15 V/us equivalent in digital).
//    - Class-AB complementary bipolar output pair rail compression.
// 2. API 2503 Multi-Tap Steel Lamination Transformer:
//    - Distinct odd-order 3rd harmonic (H3) generation when driven hard.
//    - Preserves low-end transient snap while thickening 200 Hz - 2 kHz body.
// 3. API 2500 "Thrust" Sidechain Filter Option:
//    - 10 dB per decade slope (+3 dB/octave tilt) equalizing energy distribution.
// =============================================================================

class APIDiscreteSaturator {
public:
    APIDiscreteSaturator() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        // Slew rate limit in amplitude change per sample
        // Nominal max slope at 0 dBFS before slew compression
        maxSlewPerSample = 35000.0f / sr;

        // Thrust filter pre-emphasis state
        thrustAlpha = 1.0f - std::exp(-2.0f * PI * 1000.0f / sr);

        dcBlocker.prepare(sampleRate, 10.0f);
        reset();
    }

    void reset() noexcept {
        prevSample = 0.0f;
        thrustState = 0.0f;
        transformerFlux = 0.0f;
        dcBlocker.reset();
    }

    // Process a single audio sample
    inline float processSample(float in, float driveDb, float punch01 = 0.5f, bool thrust = false) noexcept {
        if (!std::isfinite(in)) return 0.0f;
        const float driveGain = dbToGain(driveDb);
        float x = in * driveGain;

        // 1. Optional API 2500 Thrust Pre-weighting (10 dB/decade tilt)
        if (thrust) {
            thrustState += thrustAlpha * (x - thrustState);
            if (std::abs(thrustState) < 1.0e-25f) thrustState = 0.0f;
            x = (x - thrustState) * 1.45f + thrustState * 0.70f;
        }

        // 2. API 2520 Discrete Op-Amp Slew-Rate Limiter (Transient Punch)
        const float effectiveMaxSlew = maxSlewPerSample * (1.2f - 0.4f * punch01);
        const float delta = x - prevSample;
        const float clampedDelta = std::clamp(delta, -effectiveMaxSlew, effectiveMaxSlew);
        const float slewed = prevSample + clampedDelta;
        prevSample = slewed;
        if (std::abs(prevSample) < 1.0e-25f) prevSample = 0.0f;

        // 3. API 2503 Steel Transformer Core H3 Saturation
        // Symmetrical cubic polynomial non-linearity producing rich 3rd harmonics
        // Clamped at monotonic vertex |u| = 1.666f to eliminate foldback
        constexpr float fcCore = 35.0f;
        const float wCore = 2.0f * PI * fcCore / sr;
        transformerFlux += wCore * (slewed - transformerFlux);
        if (std::abs(transformerFlux) < 1.0e-25f) transformerFlux = 0.0f;

        const float ironExcursion = slewed + transformerFlux * 0.35f;
        const float clampedExc = std::clamp(ironExcursion, -1.666f, 1.666f);
        const float ironSaturated = clampedExc - 0.12f * (clampedExc * clampedExc * clampedExc);

        // 4. Class-AB Rail Soft Clipping (API 2520 discrete rail swing +/-15V)
        const float outSaturated = (std::abs(ironSaturated) < 1.0f)
            ? ironSaturated
            : std::copysign(1.0f + 0.20f * fastTanh((std::abs(ironSaturated) - 1.0f) * 3.5f), ironSaturated);

        // 5. Output DC Decoupling
        return dcBlocker.processSample(outSaturated);
    }

private:
    float sr = 44100.0f;
    float maxSlewPerSample = 0.8f;
    float prevSample = 0.0f;
    float thrustAlpha = 0.1f;
    float thrustState = 0.0f;
    float transformerFlux = 0.0f;
    DCBlocker dcBlocker;
};

} // namespace dsp171
