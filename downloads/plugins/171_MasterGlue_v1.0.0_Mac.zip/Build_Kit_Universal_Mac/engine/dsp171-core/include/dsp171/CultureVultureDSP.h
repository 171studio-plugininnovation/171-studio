#pragma once

#include <cmath>
#include <algorithm>
#include "Common.h"
#include "DCBlocker.h"
#include "FastMath.h"
#include "ZDFSVF.h"
#include "ZDFTiltFilter.h"

namespace dsp171 {

// =============================================================================
// CultureVultureDSP
// Crafted by: sat-tape-modern-specialist & sat-avalon-specialist
// Reviewed by: dsp-math-bugfinder & dsp-audit-scalability
// Supervised by: dsp-hire-manager (Dispatch Ticket #SAT-VULTURE-02)
//
// Authentic physical simulation of the Thermionic Culture Vulture:
// 1. Dual Miniature Pentode 6AS6 Topology:
//    - Triode Mode: Screen grid tied to plate. Dominant warm 2nd harmonic (H2).
//    - Pentode Mode: Independent screen grid. Dominant aggressive odd harmonics (H3, H5).
// 2. Continuous Starvation Control (Screen Grid Vg2 Voltage Collapse):
//    - Vg2 voltage varies from 120V (clean nominal headroom) down to 15V (deep starvation).
//    - Under starvation, electron emission collapses, creating variable-threshold gating
//      fuzz, asymmetrical clipping, and non-linear release.
// 3. Overdrive / +20 dB Boost:
//    - High-gain cascading with dynamic anti-runaway headroom limiting.
// 4. Pre/Post Tone Filter:
//    - Tilt filter and low/high cut filters to focus distortion into specific spectrum.
// 5. Push-Pull Iron Core Transformer Saturation.
// =============================================================================

enum class VultureMode : uint8_t {
    Triode = 0, // Dominant H2 (warm, musical)
    Pentode,    // Dominant H3/H5 (biting, aggressive)
    P2_Starve   // Extreme starving pentode fuzz
};

class CultureVultureDSP {
public:
    CultureVultureDSP() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);

        dcBlocker.prepare(sampleRate, 10.0f);
        tiltFilter.prepare(sampleRate);
        highCutFilter.setParameters(16000.0f, 0.707f, sr);

        updateParameters();
        reset();
    }

    void reset() noexcept {
        dcBlocker.reset();
        tiltFilter.reset();
        highCutFilter.reset();
        prevSample = 0.0f;
    }

    // Set Culture Vulture Parameters
    void setParameters(VultureMode mode, float driveNorm0To10,
                       float biasStarve01 = 0.0f,
                       float toneDb = 0.0f,
                       bool overdrive = false) noexcept
    {
        currentMode = mode;
        drive = std::clamp(driveNorm0To10, 0.0f, 10.0f);
        starvation = std::clamp(biasStarve01, 0.0f, 1.0f);
        tone = std::clamp(toneDb, -10.0f, 10.0f);
        useOverdrive = overdrive;

        updateParameters();
    }

    // Set Master Output Trim
    void setOutput(float outGainDb) noexcept {
        outGainLin = dbToGain(outGainDb);
    }

    // Process a single audio sample
    inline float processSample(float in) noexcept {
        // 1. Pre-emphasis Tone Shaping (Tilt Filter)
        const float shaped = tiltFilter.processSample(in);

        // 2. Input Gain & Overdrive Boost
        float x = shaped * totalInputGain;

        // 3. 6AS6 Dual-Mode Valve Saturation Engine
        float valveOut = 0.0f;

        if (currentMode == VultureMode::Triode) {
            // Triode Mode: Quadratic asymmetry with rich 2nd harmonic (H2)
            // Protetto da foldback oltre il vertice a x = -1 / (2 * asym)
            const float asym = 0.28f * (1.0f + 0.5f * starvation);
            const float minX = -0.5f / std::max(0.01f, asym);
            const float safeX = std::max(minX, x);
            const float xt = safeX + asym * (safeX * safeX);
            valveOut = std::tanh(xt * 1.15f);
        } else if (currentMode == VultureMode::Pentode) {
            // Pentode Mode: Sharp clipping with odd harmonics (H3, H5)
            const float xp = std::tanh(1.45f * x);
            valveOut = 0.75f * xp + 0.25f * std::tanh(3.2f * x);
        } else {
            // P2 Starve Mode: Screen grid Vg2 collapsed (<30V)
            // Asymmetric variable-threshold gating distortion con continuita' C^0 a soglia
            const float thresh = 0.15f + (1.0f - starvation) * 0.35f;
            constexpr float deadzoneGain = 0.45f;
            const float threshVal = thresh * deadzoneGain;
            if (x > thresh) {
                valveOut = threshVal + std::tanh((x - thresh) * 2.5f) * (1.0f - threshVal);
            } else if (x < -thresh) {
                valveOut = -threshVal + std::tanh((x + thresh) * 3.5f) * (1.0f - threshVal);
            } else {
                // Starvation crossover deadzone / soft compression
                valveOut = x * deadzoneGain;
            }
        }

        // 4. Push-Pull Iron Transformer Output Core
        const float ironSat = std::tanh(valveOut * 0.95f) * (1.0f + 0.04f * (valveOut * valveOut));

        // 5. Post High-Cut Filter (smoothes extreme HF hash)
        const float filtered = highCutFilter.process(ironSat).lp;

        // 6. Master Output & DC Decoupling
        const float out = filtered * outGainLin;
        return dcBlocker.processSample(out);
    }

    // Process a buffer of audio samples
    void processBlock(float* buffer, size_t numSamples) noexcept {
        if (!buffer || numSamples == 0) return;
        for (size_t i = 0; i < numSamples; ++i) {
            buffer[i] = processSample(buffer[i]);
        }
    }

private:
    void updateParameters() noexcept {
        // Drive mapping: 0..10 maps to 0 dB .. 36 dB
        float driveDb = drive * 3.6f;
        if (useOverdrive) {
            driveDb += 18.0f; // +18 dB Overdrive boost
        }
        totalInputGain = dbToGain(driveDb);

        // Pre-emphasis tilt (mappa -10..+10 dB in -1.0..+1.0 per ZDFTiltFilter)
        tiltFilter.setTilt(tone * 0.10f);
    }

    float sr{44100.0f};

    VultureMode currentMode{VultureMode::Triode};
    float drive{2.0f};
    float starvation{0.0f};
    float tone{0.0f};
    bool useOverdrive{false};
    float totalInputGain{1.0f};
    float outGainLin{1.0f};

    float prevSample{0.0f};

    DCBlocker dcBlocker;
    ZDFTiltFilter tiltFilter;
    ZDFSVF64 highCutFilter;
};

} // namespace dsp171
