#pragma once

#include <cmath>
#include <algorithm>
#include "Common.h"
#include "DCBlocker.h"
#include "FastMath.h"

namespace dsp171 {

// =============================================================================
// VCABusCompressor
// Crafted by: comp-optical-universal (Supervised by dsp-hire-manager)
//
// Authentic physical modeling of the iconic VCA Master Bus Compressor:
// 1. Feedforward Logarithmic VCA Level Detector.
// 2. Continuous Soft-Knee Gain Reduction Characteristic.
// 3. Programmatic Auto-Release (Dual-decay: fast on transients, slow on body).
// 4. Sidechain High-Pass Filter (eliminates kick-drum bass pumping).
// 5. Zero-Latency Real-Time Audio Block Processing.
// =============================================================================

enum class ThrustMode : uint8_t {
    Norm = 0, // Flat sidechain (SSL 4000 style)
    Med  = 1, // API 2500 Medium Thrust (-3 dB LF, +3 dB HF tilt)
    Loud = 2  // API 2500 Loud Thrust (10 dB/decade equal energy slope)
};

enum class VCATopology : uint8_t {
    Feedforward_New = 0, // Aggressive punch, precise mathematical ratio
    Feedback_Old    = 1  // Vintage smooth behavior, sidechain detector tapped post-VCA
};

enum class KneeType : uint8_t {
    Soft   = 0, // 8 dB progressive parabolic knee
    Medium = 1, // 4 dB semi-soft knee
    Hard   = 2  // 0.5 dB fast sharp knee
};

class VCABusCompressor {
public:
    VCABusCompressor() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        updateCoefficients();
        reset();
    }

    void reset() noexcept {
        envelopeDb = -120.0f;
        autoReleaseSlowDb = -120.0f;
        sidechainHPState = 0.0f;
        thrustFilterState = 0.0f;
        prevOut = 0.0f;
    }

    void setParameters(float thresholdDb, float ratio, float attackMs, float releaseMs,
                       bool autoRelease = false, float sidechainHPFreq = 80.0f,
                       ThrustMode thrust = ThrustMode::Norm,
                       VCATopology topology = VCATopology::Feedforward_New,
                       KneeType knee = KneeType::Medium) noexcept
    {
        thresh = thresholdDb;
        r = std::max(1.0f, ratio);
        attMs = std::max(0.05f, attackMs);
        relMs = std::max(10.0f, releaseMs);
        useAutoRelease = autoRelease;
        scHPFreq = std::clamp(sidechainHPFreq, 20.0f, 300.0f);
        thrustMode = thrust;
        vcaTopology = topology;
        kneeType = knee;
        updateCoefficients();
    }

    // Process a single audio sample (returns compressed sample, optionally updates outGainReductionDb)
    inline float processSample(float in, float* outGainReductionDb = nullptr) noexcept {
        // 1. Determine Sidechain Source (Feedforward vs Feedback Old API style)
        const float detectorInput = (vcaTopology == VCATopology::Feedback_Old) ? prevOut : in;

        // 2. Sidechain High-Pass Filter
        sidechainHPState += scHPAlpha * (detectorInput - sidechainHPState);
        float scSignal = detectorInput - sidechainHPState;

        // 3. API 2500 Thrust Sidechain Weighting Filter
        if (thrustMode == ThrustMode::Med) {
            // Medium Thrust: Tilt filter (+3 dB at 10 kHz, -3 dB at 50 Hz)
            thrustFilterState += thrustAlpha * (scSignal - thrustFilterState);
            scSignal = (scSignal - thrustFilterState) * 1.35f + thrustFilterState * 0.75f;
        } else if (thrustMode == ThrustMode::Loud) {
            // Loud Thrust: Linear 10 dB/decade slope
            thrustFilterState += thrustAlpha * (scSignal - thrustFilterState);
            scSignal = (scSignal - thrustFilterState) * 1.85f + thrustFilterState * 0.45f;
        }

        // 4. Peak Level Detection in Logarithmic Decibels
        const float absVal = std::abs(scSignal);
        const float inputDb = (absVal > 1e-6f) ? 20.0f * std::log10(absVal) : -120.0f;

        // 5. Attack / Release Envelope Smoothing
        if (inputDb > envelopeDb) {
            envelopeDb += attackAlpha * (inputDb - envelopeDb);
        } else {
            float effReleaseAlpha = releaseAlpha;
            if (useAutoRelease) {
                // Dual-decay auto release: track slow sustained level
                autoReleaseSlowDb += autoReleaseSlowAlpha * (envelopeDb - autoReleaseSlowDb);
                const float diff = std::abs(envelopeDb - autoReleaseSlowDb);
                // On large transient delta, release fast; on sustained body, release slow
                effReleaseAlpha = (diff > 4.0f) ? releaseAlpha : autoReleaseSlowAlpha;
            }
            envelopeDb += effReleaseAlpha * (inputDb - envelopeDb);
        }

        // 6. Configurable Soft / Med / Hard Knee Compression Curve
        float kneeWidth = 4.0f;
        if (kneeType == KneeType::Soft) kneeWidth = 8.0f;
        else if (kneeType == KneeType::Hard) kneeWidth = 0.5f;

        const float delta = envelopeDb - thresh;
        float grDb = 0.0f;

        if (delta <= -kneeWidth * 0.5f) {
            grDb = 0.0f;
        } else if (delta >= kneeWidth * 0.5f) {
            grDb = (thresh + delta / r) - envelopeDb;
        } else {
            // Parabolic interpolation inside soft knee
            const float k = delta + kneeWidth * 0.5f;
            grDb = ((1.0f / r - 1.0f) * (k * k)) / (2.0f * kneeWidth);
        }

        if (outGainReductionDb != nullptr) {
            *outGainReductionDb = -grDb; // Positive GR display (e.g. 4 dB reduction)
        }

        // 7. Apply VCA Linear Gain
        const float linearGR = dbToGain(grDb);
        const float outSample = in * linearGR;
        prevOut = outSample;
        return outSample;
    }

private:
    void updateCoefficients() noexcept {
        attackAlpha = 1.0f - std::exp(-1.0f / (attMs * 0.001f * sr));
        releaseAlpha = 1.0f - std::exp(-1.0f / (relMs * 0.001f * sr));
        // Auto release slow stage (~1.2 seconds)
        autoReleaseSlowAlpha = 1.0f - std::exp(-1.0f / (1.20f * sr));
        // Sidechain HP filter
        scHPAlpha = std::clamp(2.0f * PI * scHPFreq / sr, 0.001f, 0.8f);
        // Thrust filter pole (~1000 Hz)
        thrustAlpha = std::clamp(2.0f * PI * 1000.0f / sr, 0.001f, 0.8f);
    }

    float sr = 44100.0f;
    float thresh = -14.0f;
    float r = 4.0f;
    float attMs = 10.0f;
    float relMs = 100.0f;
    bool useAutoRelease = false;
    float scHPFreq = 80.0f;
    ThrustMode thrustMode = ThrustMode::Norm;
    VCATopology vcaTopology = VCATopology::Feedforward_New;
    KneeType kneeType = KneeType::Medium;

    float attackAlpha = 0.1f;
    float releaseAlpha = 0.01f;
    float autoReleaseSlowAlpha = 0.0005f;
    float scHPAlpha = 0.01f;
    float thrustAlpha = 0.1f;

    float envelopeDb = -120.0f;
    float autoReleaseSlowDb = -120.0f;
    float sidechainHPState = 0.0f;
    float thrustFilterState = 0.0f;
    float prevOut = 0.0f;
};

} // namespace dsp171
