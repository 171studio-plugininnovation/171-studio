#pragma once

#include <cmath>
#include <algorithm>
#include "Common.h"
#include "DCBlocker.h"
#include "FastMath.h"

namespace dsp171 {

// =============================================================================
// AvalonTubeSaturator
// Crafted by: sat-avalon-specialist (Supervised by dsp-hire-manager)
//
// Physical simulation of the Avalon VT-737sp high-voltage Class-A vacuum tube:
// 1. Dual Triodes (6922 / 12AX7) with High-Voltage Class-A Topology (150V+ Plate):
//    - Child-Langmuir law non-linear plate current equation.
//    - Dominant musical second harmonic (H2) warmth without harsh odd harmonics.
// 2. High-Voltage Headroom:
//    - Ultra-wide dynamic range, soft triode compression knee.
// 3. Avalon 32 kHz Air Sheen Network:
//    - Gentle passive shelving boost lifting high air presence from 10 kHz to 32 kHz.
// =============================================================================

class AvalonTubeSaturator {
public:
    AvalonTubeSaturator() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        dcBlocker.prepare(sampleRate, 10.0f);

        // Air filter pole (~16 kHz base for 32 kHz shelf transition)
        constexpr float fcAir = 16000.0f;
        airAlpha = std::clamp(2.0f * PI * fcAir / sr, 0.01f, 0.95f);

        reset();
    }

    void reset() noexcept {
        dcBlocker.reset();
        airState = 0.0f;
        gridCapState = 0.0f;
    }

    // Process a single sample through high-voltage Class-A triode
    inline float processSample(float in, float driveDb, float warmth01 = 0.5f, float airDb = 0.0f) noexcept {
        const float driveGain = dbToGain(driveDb);
        const float x = in * driveGain;

        // 1. Dual-Triode Class-A Plate Non-Linearity (Taylor expansion of Child-Langmuir law)
        // Authentic quadratic asymmetry generates pure H2 warmth: f(v) = v + alpha * v^2
        const float asymAlpha = 0.22f * warmth01;
        const float vTriode = x + asymAlpha * (x * x);

        // 2. High-Voltage Plate Headroom & Soft Triode Saturation Knee
        // Soft positive clipping (grid conduction) and gradual negative cutoff
        float tubeOut;
        if (vTriode > 0.0f) {
            // Positive grid swing: soft compression
            tubeOut = vTriode / (1.0f + 0.25f * vTriode);
        } else {
            // Negative plate swing: gentle cutoff
            tubeOut = -fastTanh(-vTriode * 0.95f);
        }

        // 3. Avalon 32 kHz Air Sheen Filter
        float out = tubeOut;
        if (airDb > 0.01f) {
            const float airGain = dbToGain(airDb);
            airState += airAlpha * (tubeOut - airState);
            out = airState + (tubeOut - airState) * airGain;
        }

        // 4. Output DC Decoupling
        return dcBlocker.processSample(out);
    }

private:
    float sr = 44100.0f;
    float airAlpha = 0.5f;
    float airState = 0.0f;
    float gridCapState = 0.0f;
    DCBlocker dcBlocker;
};

} // namespace dsp171
