#pragma once

#include <cmath>
#include <algorithm>
#include <array>
#include "Common.h"
#include "DCBlocker.h"
#include "FastMath.h"
#include "ZDFSVF.h"
#include "APIDiscreteSaturator.h"

namespace dsp171 {

// =============================================================================
// APIVisionStrip
// Crafted by: sat-api-specialist (Reviewed by dsp-math-bugfinder)
// Supervised by: dsp-hire-manager (Dispatch Ticket #PRE-API-02)
//
// Physical modeling of the API Vision Console Strip & API 550 EQ:
// 1. API 2520 Discrete Operational Amplifier Slew-Rate Limiting:
//    - 15 V/us max slope clamping producing transient edge punch and snap.
//    - Class-AB rail swing soft limiting.
// 2. AP2503 Quad-Filar Steel Lamination Transformer:
//    - Symmetrical 3rd harmonic (H3) saturation across 200 Hz - 2 kHz body.
// 3. Iconic Proportional-Q Equalizer (API 550A / 550B):
//    - Bandwidth Q automatically scales with gain:
//      At +/-2 dB: Q ~ 0.65 (wide musical contour)
//      At +/-12 dB: Q ~ 2.80 (surgical tight notch/boost)
//    - 4 Swappable bands (Low, Low-Mid, High-Mid, High) with Peak/Shelf modes.
// 4. API Bandpass Filter (50 Hz High-Pass + 15 kHz Low-Pass).
// =============================================================================

enum class APIBandMode : uint8_t {
    Peak = 0,
    Shelf
};

struct APIBandParam {
    float freq{1000.0f};
    float gainDb{0.0f};
    APIBandMode mode{APIBandMode::Peak};
};

class APIVisionStrip {
public:
    APIVisionStrip() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);

        saturator.prepare(sampleRate);
        dcBlocker.prepare(sampleRate, 10.0f);

        // API 50 Hz HP + 15 kHz LP Bandpass Filters
        bpfHP.setParameters(50.0f, 0.707f, sr);
        bpfLP.setParameters(15000.0f, 0.707f, sr);

        updateBands();
        reset();
    }

    void reset() noexcept {
        saturator.reset();
        dcBlocker.reset();
        bpfHP.reset();
        bpfLP.reset();
        for (auto& svf : bandSvfs) {
            svf.reset();
        }
    }

    // Set Preamp Drive & Punch (API 2520 & AP2503)
    void setPreamp(float driveDb, float punch01 = 0.5f, bool thrust = false) noexcept {
        preampDriveDb = driveDb;
        punch = std::clamp(punch01, 0.0f, 1.0f);
        useThrust = thrust;
    }

    // Configure 4 Bands of API 550 Proportional-Q
    void setBand(size_t index, float freqHz, float gainDb, APIBandMode mode = APIBandMode::Peak) noexcept {
        if (index >= 4) return;
        bands[index].freq = std::clamp(freqHz, 20.0f, sr * 0.45f);
        bands[index].gainDb = std::clamp(gainDb, -12.0f, 12.0f);
        bands[index].mode = mode;
        updateBandCoeffs(index);
    }

    // Toggle Bandpass filter (50 Hz HP + 15 kHz LP)
    void setBandpassFilter(bool enable) noexcept {
        enableBPF = enable;
    }

    // Set Output Fader & EQ In/Out
    void setOutput(float outGainDb, bool eqIn = true) noexcept {
        outGainLin = dbToGain(outGainDb);
        isEqActive = eqIn;
    }

    // Process a single audio sample
    inline float processSample(float in) noexcept {
        // 1. API 2520 Discrete Op-Amp & 2503 Steel Transformer
        float sig = saturator.processSample(in, preampDriveDb, punch, useThrust);

        // 2. Bandpass Filter (50 Hz HP + 15 kHz LP)
        if (enableBPF) {
            const auto hpOut = bpfHP.process(sig);
            const auto lpOut = bpfLP.process(hpOut.hp);
            sig = lpOut.lp;
        }

        // 3. API Proportional-Q Equalizer (4 Bands)
        if (isEqActive) {
            for (size_t i = 0; i < 4; ++i) {
                const float gDb = bands[i].gainDb;
                if (std::abs(gDb) < 0.01f) continue;

                const float gFactor = dbToGain(gDb) - 1.0f;
                const auto svfOut = bandSvfs[i].process(sig);

                if (bands[i].mode == APIBandMode::Shelf) {
                    if (i == 0) {
                        // Low Shelf
                        sig = sig + svfOut.lp * gFactor;
                    } else if (i == 3) {
                        // High Shelf
                        sig = sig + svfOut.hp * gFactor;
                    } else {
                        // Mid bands default to proportional bell
                        sig = sig + svfOut.bp * gFactor;
                    }
                } else {
                    // Proportional-Q Bell
                    sig = sig + svfOut.bp * gFactor;
                }
            }
        }

        // 4. Output Gain & Clean DC Decoupling
        const float out = sig * outGainLin;
        return dcBlocker.processSample(out);
    }

    // Process a buffer of audio samples
    void processBlock(float* buffer, size_t numSamples) noexcept {
        if (!buffer || numSamples == 0) return;
        for (size_t i = 0; i < numSamples; ++i) {
            buffer[i] = processSample(buffer[i]);
        }
    }

private:
    void updateBandCoeffs(size_t index) noexcept {
        if (index >= 4) return;
        const float f = bands[index].freq;
        const float gAbs = std::abs(bands[index].gainDb);

        // API Proportional-Q Law:
        // Base Q = 0.65; scales up to 2.8 at +12 dB
        const float propQ = 0.65f * (1.0f + 0.27f * gAbs);
        bandSvfs[index].setParameters(f, propQ, sr);
    }

    void updateBands() noexcept {
        for (size_t i = 0; i < 4; ++i) {
            updateBandCoeffs(i);
        }
    }

    float sr{44100.0f};

    float preampDriveDb{0.0f};
    float punch{0.5f};
    bool useThrust{false};
    bool enableBPF{false};
    bool isEqActive{true};
    float outGainLin{1.0f};

    APIDiscreteSaturator saturator;
    DCBlocker dcBlocker;

    ZDFSVF64 bpfHP;
    ZDFSVF64 bpfLP;

    std::array<APIBandParam, 4> bands{
        APIBandParam{ 100.0f, 0.0f, APIBandMode::Shelf }, // Low
        APIBandParam{ 500.0f, 0.0f, APIBandMode::Peak  }, // Low-Mid
        APIBandParam{ 2500.0f, 0.0f, APIBandMode::Peak }, // High-Mid
        APIBandParam{ 10000.0f, 0.0f, APIBandMode::Shelf} // High
    };

    std::array<ZDFSVF64, 4> bandSvfs;
};

} // namespace dsp171
