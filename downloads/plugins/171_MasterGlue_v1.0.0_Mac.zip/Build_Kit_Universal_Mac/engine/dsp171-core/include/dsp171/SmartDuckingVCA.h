#pragma once
#include <cmath>
#include <algorithm>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// SMART DUCKING & TAIL BLOOM DYNAMIC VCA v2
//
// VCA dinamico logaritmico d'avanguardia con 5 innovazioni integrate:
// 1. Auto-Sensing Floating Threshold: traccia il livello RMS a lungo termine
//    della voce e fissa la soglia 10 dB sotto il canto, eliminando la calibrazione dB.
// 2. Tail Bloom (Rialzo Coda): nelle pause vocali il guadagno della coda sale
//    automaticamente da 0 dB a +6 dB per far risaltare il riverbero nel vuoto.
// 3. Syllabic Hold Gate: timer di protezione (80-120 ms) che evita il pumping
//    tra sillabe veloci, innescando il Bloom solo al termine reale della frase.
// 4. Stereo Width Bloom: calcola un fattore di espansione stereofonica per
//    aprire a ventaglio la coda di riverbero quando fiorisce.
// 5. Supporto doppio pilota: Internal Dry e External Aux Sidechain.
// =============================================================================

class SmartDuckingVCA {
public:
    SmartDuckingVCA() = default;

    void prepare(double sampleRate) {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        updateAlphas();
        reset();
    }

    void reset() noexcept {
        currentEnvelope = 0.0f;
        currentGainReductionDb = 0.0f;
        currentBloomGainDb = 0.0f;
        smoothedGain = 1.0f;
        maxObservedGR = 0.0f;
        maxObservedBloom = 0.0f;
        longTermRms = 0.001f;
        silenceCounter = 0;
        effectiveThreshold = -24.0f;
    }

    // Configurazione avanzata v2 con Auto-Sense, Tail Bloom e Syllabic Hold
    void setParametersV2(float duckDepthDb,
                         float tailBloomDb = 0.0f,
                         bool autoSense = true,
                         float manualThresholdDb = -24.0f,
                         float attackMs = 5.0f,
                         float releaseMs = 180.0f,
                         float holdMs = 90.0f) noexcept
    {
        maxDepth = std::max(0.0f, duckDepthDb);
        maxBloomDb = std::clamp(tailBloomDb, 0.0f, 8.0f);
        useAutoSense = autoSense;
        manualThreshold = manualThresholdDb;
        attMs = std::clamp(attackMs, 0.2f, 100.0f);
        relMs = std::clamp(releaseMs, 10.0f, 2000.0f);
        holdSamples = static_cast<int>(std::clamp(holdMs, 10.0f, 300.0f) * 0.001f * static_cast<float>(sr));
        updateAlphas();
    }

    // Firma di compatibilità v1
    void setParameters(float thresholdDb, float depthDb, float attackMs = 5.0f, float releaseMs = 120.0f) noexcept {
        setParametersV2(depthDb, 0.0f, false, thresholdDb, attackMs, releaseMs, 60.0f);
    }

    // Calcola il moltiplicatore di guadagno lineare VCA in base al segnale pilota (key)
    inline float computeGain(float keyL, float keyR) noexcept {
        float peak = std::max(std::abs(keyL), std::abs(keyR));

        // 1. Tracciamento RMS vocale a lungo termine per Auto-Threshold
        float sq = peak * peak;
        longTermRms += (sq - longTermRms) * longTermAlpha;

        if (useAutoSense) {
            float rmsDb = 10.0f * std::log10(std::max(1.0e-5f, longTermRms));
            effectiveThreshold = std::clamp(rmsDb - 10.0f, -55.0f, -12.0f);
        } else {
            effectiveThreshold = manualThreshold;
        }

        // 2. Inseguitore analogico asimmetrico
        if (peak > currentEnvelope) {
            currentEnvelope += (peak - currentEnvelope) * attackAlpha;
            silenceCounter = 0;
        } else {
            currentEnvelope += (peak - currentEnvelope) * releaseAlpha;
            if (silenceCounter < holdSamples * 4) {
                silenceCounter++;
            }
        }

        float envDb = (currentEnvelope > 1.0e-5f) 
            ? 20.0f * std::log10(currentEnvelope) 
            : -100.0f;

        float targetGain = 1.0f;

        if (envDb > effectiveThreshold) {
            // FASE 1: VOCE PRESENTE -> DUCKING ATTIVO
            silenceCounter = 0;
            float excess = envDb - effectiveThreshold;
            float attenDb = std::min(maxDepth, excess * 0.95f);
            currentGainReductionDb = attenDb;
            currentBloomGainDb = 0.0f;
            if (attenDb > maxObservedGR) maxObservedGR = attenDb;
            targetGain = std::pow(10.0f, -attenDb / 20.0f);
        } else {
            // FASE 2: VOCE SOTTO SOGLIA -> VERIFICA SYLLABIC HOLD
            currentGainReductionDb = 0.0f;
            if (silenceCounter >= holdSamples && maxBloomDb > 0.05f) {
                // Frase canora realmente conclusa: TAIL BLOOM ATTIVO!
                currentBloomGainDb = maxBloomDb;
                if (maxBloomDb > maxObservedBloom) maxObservedBloom = maxBloomDb;
                targetGain = std::pow(10.0f, maxBloomDb / 20.0f);
            } else {
                // Micro-pausa tra sillabe: mantieni guadagno nominale 1.0 (zero pumping)
                currentBloomGainDb = 0.0f;
                targetGain = 1.0f;
            }
        }

        // 3. Lisciamento anti-zipper a 1-polo
        smoothedGain += (targetGain - smoothedGain) * smoothAlpha;
        return smoothedGain;
    }

    // Applica direttamente il ducking e bloom a una coppia stereo
    inline void applyDucking(float& l, float& r, float keyL, float keyR) noexcept {
        float gain = computeGain(keyL, keyR);
        l *= gain;
        r *= gain;
    }

    // Ritorna il coefficiente di allargamento stereofonico generato dal bloom (1.0 = neutro, 1.25 = +25%)
    inline float getStereoBloomMultiplier() const noexcept {
        if (maxBloomDb <= 0.05f || smoothedGain <= 1.01f) return 1.0f;
        float maxLinearBloom = std::pow(10.0f, maxBloomDb / 20.0f);
        float bloomRatio = std::clamp((smoothedGain - 1.0f) / (maxLinearBloom - 1.0f), 0.0f, 1.0f);
        return 1.0f + 0.20f * bloomRatio; // Allargamento fino a +20%
    }

    float getGainReductionDb() const noexcept { return currentGainReductionDb; }
    float getBloomGainDb() const noexcept { return currentBloomGainDb; }
    float getMaxObservedGR() const noexcept { return maxObservedGR; }
    float getMaxObservedBloom() const noexcept { return maxObservedBloom; }
    float getEffectiveThresholdDb() const noexcept { return effectiveThreshold; }
    bool isDuckingActive() const noexcept { return currentGainReductionDb > 0.5f; }
    bool isBloomActive() const noexcept { return smoothedGain > 1.05f; }
    void resetStats() noexcept { maxObservedGR = 0.0f; maxObservedBloom = 0.0f; }

private:
    void updateAlphas() noexcept {
        attackAlpha    = 1.0f - std::exp(-1.0f / (float(attMs * 0.001 * sr)));
        releaseAlpha   = 1.0f - std::exp(-1.0f / (float(relMs * 0.001 * sr)));
        smoothAlpha    = 1.0f - std::exp(-1.0f / (float(0.003 * sr))); // 3 ms anti-zipper
        longTermAlpha  = 1.0f - std::exp(-1.0f / (float(1.500 * sr))); // 1.5 s RMS tracker
    }

    double sr = 48000.0;
    float maxDepth = 12.0f;
    float maxBloomDb = 0.0f;
    bool useAutoSense = true;
    float manualThreshold = -24.0f;
    float effectiveThreshold = -24.0f;

    float attMs = 5.0f;
    float relMs = 180.0f;
    int holdSamples = 4320; // 90 ms a 48 kHz
    int silenceCounter = 0;

    float attackAlpha = 0.1f;
    float releaseAlpha = 0.01f;
    float smoothAlpha = 0.05f;
    float longTermAlpha = 0.0001f;

    float currentEnvelope = 0.0f;
    float currentGainReductionDb = 0.0f;
    float currentBloomGainDb = 0.0f;
    float smoothedGain = 1.0f;
    float maxObservedGR = 0.0f;
    float maxObservedBloom = 0.0f;
    float longTermRms = 0.001f;
};

} // namespace dsp171
