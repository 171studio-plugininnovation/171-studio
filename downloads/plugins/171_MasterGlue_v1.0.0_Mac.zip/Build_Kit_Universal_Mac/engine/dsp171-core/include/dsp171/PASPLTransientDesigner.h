#pragma once
#include <cmath>
#include <algorithm>

namespace dsp171 {

/**
 * @brief SPLTransientDesigner
 * Reverse-engineered from SPL Transient Designer Plus.
 * Uses Ruben Tilgner's Differential Envelope Technology (DET) to process audio transients
 * completely independent of signal level (no threshold, no ratio).
 * Provides continuous Attack boost/cut (+-15 dB) and Sustain boost/cut (+-24 dB).
 */
class SPLTransientDesigner {
public:
    SPLTransientDesigner() noexcept 
        : m_sampleRate(44100.0f) {}

    void prepare(float sampleRate) noexcept {
        m_sampleRate = sampleRate;
        m_attFastL = 0.0f; m_attSlowL = 0.0f; m_susSlowL = 0.0f;
        m_attFastR = 0.0f; m_attSlowR = 0.0f; m_susSlowR = 0.0f;

        // Precompute ballistic filter coefficients (zero transcendent math in audio loop)
        m_alphaFastAtt = 1.0f - std::exp(-1.0f / (0.0015f * m_sampleRate));
        m_alphaSlowAtt = 1.0f - std::exp(-1.0f / (0.020f * m_sampleRate));
        m_alphaRel     = 1.0f - std::exp(-1.0f / (0.040f * m_sampleRate));
        m_alphaSusRel  = 1.0f - std::exp(-1.0f / (0.250f * m_sampleRate));
    }

    void setParameters(float attackDb = 0.0f, float sustainDb = 0.0f, 
                       float outputGainDb = 0.0f, bool softClip = true) noexcept {
        m_attackGain = std::pow(10.0f, std::clamp(attackDb, -15.0f, 15.0f) / 20.0f) - 1.0f;
        m_sustainGain = std::pow(10.0f, std::clamp(sustainDb, -24.0f, 24.0f) / 20.0f) - 1.0f;
        m_outputGain = std::pow(10.0f, std::clamp(outputGainDb, -24.0f, 24.0f) / 20.0f);
        m_softClip = softClip;
    }

    inline void process(float inL, float inR, float& outL, float& outR) noexcept {
        outL = processChannel(inL, m_attFastL, m_attSlowL, m_susSlowL);
        outR = processChannel(inR, m_attFastR, m_attSlowR, m_susSlowR);
    }

    void processBlock(float* left, float* right, int numSamples) noexcept {
        for (int i = 0; i < numSamples; ++i) {
            process(left[i], right[i], left[i], right[i]);
        }
    }

private:
    float m_sampleRate;
    float m_attackGain{0.0f};
    float m_sustainGain{0.0f};
    float m_outputGain{1.0f};
    bool m_softClip{true};

    float m_attFastL{0}, m_attSlowL{0}, m_susSlowL{0};
    float m_attFastR{0}, m_attSlowR{0}, m_susSlowR{0};

    float m_alphaFastAtt{0.0f};
    float m_alphaSlowAtt{0.0f};
    float m_alphaRel{0.0f};
    float m_alphaSusRel{0.0f};

    inline float processChannel(float in, float& attFast, float& attSlow, float& susSlow) noexcept {
        float absVal = std::fabs(in);

        // 1. Differential Attack Follower
        if (absVal > attFast) attFast += m_alphaFastAtt * (absVal - attFast);
        else attFast += m_alphaRel * (absVal - attFast);

        if (absVal > attSlow) attSlow += m_alphaSlowAtt * (absVal - attSlow);
        else attSlow += m_alphaRel * (absVal - attSlow);

        // 2. Differential Sustain Follower
        if (absVal > susSlow) susSlow += m_alphaSlowAtt * (absVal - susSlow);
        else susSlow += m_alphaSusRel * (absVal - susSlow);

        // 3. Compute DET Differential Multipliers
        float diffAtt = std::max(0.0f, attFast - attSlow);
        float diffSus = std::max(0.0f, susSlow - attSlow);

        // Modulate VCA Gain without threshold!
        float normPeak = std::max(attFast, 1e-4f);
        float vcaGain = 1.0f + m_attackGain * (diffAtt / normPeak) 
                             + m_sustainGain * (diffSus / normPeak);

        vcaGain = std::max(0.0f, vcaGain);
        float out = in * vcaGain * m_outputGain;

        // 4. Output Safety Soft Clipper
        if (m_softClip) {
            if (std::fabs(out) > 0.95f) {
                out = std::copysign(0.95f + 0.05f * std::tanh((std::fabs(out) - 0.95f) / 0.05f), out);
            }
        }

        return out;
    }
};

} // namespace dsp171
