#pragma once
#include <cmath>
#include <algorithm>
#include <vector>

namespace dsp171 {

/**
 * @brief WavesSmackAttack
 * Reverse-engineered from Waves Smack Attack.
 * Transient shaper with independent Attack and Sustain dynamic modification,
 * pulse-width contour shaping (Sharp, Normal, Wide), sensitivity thresholding,
 * lookahead alignment, and an output safety clipper.
 */
class WavesSmackAttack {
public:
    enum class PulseShape {
        Sharp,
        Normal,
        Wide
    };

    WavesSmackAttack() noexcept 
        : m_sampleRate(44100.0f) {}

    void prepare(float sampleRate) noexcept {
        m_sampleRate = sampleRate;
        size_t delaySamples = static_cast<size_t>(sampleRate * 0.005f); // 5 ms lookahead
        m_delayL.assign(delaySamples, 0.0f);
        m_delayR.assign(delaySamples, 0.0f);
        m_bufIdx = 0;
        m_fastEnvL = 0.0f; m_slowEnvL = 0.0f;
        m_fastEnvR = 0.0f; m_slowEnvR = 0.0f;
    }

    void setParameters(float attackGainPercent = 0.0f, PulseShape attackShape = PulseShape::Normal,
                       float sustainGainPercent = 0.0f, PulseShape sustainShape = PulseShape::Normal,
                       float sensitivity = 50.0f, float clipLevelDb = 0.0f) noexcept {
        m_attackGain = std::clamp(attackGainPercent, -100.0f, 100.0f) * 0.01f * 2.0f;
        m_attackShape = attackShape;
        m_sustainGain = std::clamp(sustainGainPercent, -100.0f, 100.0f) * 0.01f * 2.0f;
        m_sustainShape = sustainShape;
        m_sensitivityThreshold = (100.0f - std::clamp(sensitivity, 0.0f, 100.0f)) * 0.005f;
        m_clipLevel = std::pow(10.0f, std::clamp(clipLevelDb, -24.0f, 0.0f) / 20.0f);

        // Configure attack time constants based on shape
        switch (attackShape) {
            case PulseShape::Sharp:  m_attackDurationMs = 1.0f; break;
            case PulseShape::Normal: m_attackDurationMs = 15.0f; break;
            case PulseShape::Wide:   m_attackDurationMs = 40.0f; break;
        }

        // Configure sustain time constants based on shape
        switch (sustainShape) {
            case PulseShape::Sharp:  m_sustainDurationMs = 60.0f; break;
            case PulseShape::Normal: m_sustainDurationMs = 200.0f; break;
            case PulseShape::Wide:   m_sustainDurationMs = 600.0f; break;
        }
    }

    inline void process(float inL, float inR, float& outL, float& outR) noexcept {
        // 1. Lookahead delay line
        size_t len = m_delayL.size();
        float delayedL = m_delayL[m_bufIdx];
        float delayedR = m_delayR[m_bufIdx];
        m_delayL[m_bufIdx] = inL;
        m_delayR[m_bufIdx] = inR;
        m_bufIdx = (m_bufIdx + 1) % len;

        // 2. Extract transient and sustain gains
        float modL = computeTransientGain(inL, m_fastEnvL, m_slowEnvL);
        float modR = computeTransientGain(inR, m_fastEnvR, m_slowEnvR);

        // 3. Apply to delayed audio
        float resL = delayedL * modL;
        float resR = delayedR * modR;

        // 4. Output Safety Clipper
        outL = std::clamp(resL, -m_clipLevel, m_clipLevel);
        outR = std::clamp(resR, -m_clipLevel, m_clipLevel);
    }

    void processBlock(float* left, float* right, int numSamples) noexcept {
        for (int i = 0; i < numSamples; ++i) {
            process(left[i], right[i], left[i], right[i]);
        }
    }

private:
    float m_sampleRate;
    float m_attackGain{0.0f};
    PulseShape m_attackShape{PulseShape::Normal};
    float m_attackDurationMs{15.0f};

    float m_sustainGain{0.0f};
    PulseShape m_sustainShape{PulseShape::Normal};
    float m_sustainDurationMs{200.0f};

    float m_sensitivityThreshold{0.025f};
    float m_clipLevel{1.0f};

    std::vector<float> m_delayL;
    std::vector<float> m_delayR;
    size_t m_bufIdx{0};

    float m_fastEnvL{0.0f}, m_slowEnvL{0.0f};
    float m_fastEnvR{0.0f}, m_slowEnvR{0.0f};

    inline float computeTransientGain(float in, float& fastEnv, float& slowEnv) noexcept {
        float absVal = std::fabs(in);
        if (absVal < m_sensitivityThreshold) {
            return 1.0f;
        }

        // Fast tracker for initial hit
        float alphaFast = 1.0f - std::exp(-1.0f / ((m_attackDurationMs * 0.001f) * m_sampleRate));
        if (absVal > fastEnv) fastEnv += alphaFast * (absVal - fastEnv);
        else fastEnv += (alphaFast * 0.2f) * (absVal - fastEnv);

        // Slow tracker for body
        float alphaSlow = 1.0f - std::exp(-1.0f / ((m_sustainDurationMs * 0.001f) * m_sampleRate));
        if (absVal > slowEnv) slowEnv += alphaSlow * (absVal - slowEnv);
        else slowEnv += (alphaSlow * 0.2f) * (absVal - slowEnv);

        // Differential crest factor
        float diff = fastEnv - slowEnv;
        float gainMod = 1.0f;

        if (diff > 0.0f) {
            // Transient portion: apply Attack gain
            gainMod += m_attackGain * (diff / (fastEnv + 1e-4f));
        } else {
            // Sustain tail: apply Sustain gain
            gainMod += m_sustainGain * (-diff / (slowEnv + 1e-4f));
        }

        return std::max(0.0f, gainMod);
    }
};

} // namespace dsp171
