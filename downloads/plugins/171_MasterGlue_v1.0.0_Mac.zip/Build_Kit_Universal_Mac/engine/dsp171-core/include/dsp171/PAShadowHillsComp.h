#pragma once
#include <cmath>
#include <algorithm>

namespace dsp171 {

/**
 * @brief ShadowHillsMasteringComp
 * Reverse-engineered from Shadow Hills Mastering Compressor / Class A.
 * Dual-stage compressor featuring an Optical section in series with a Discrete VCA section,
 * followed by a switchable 3-position custom Output Transformer Matrix (Nickel, Iron, Steel).
 */
class ShadowHillsMasteringComp {
public:
    enum class TransformerType {
        Nickel, // Cleanest, subtle top sheen (+0.2 dB @ 10 kHz), pristine phase
        Iron,   // Punchy, low-mid push (+1.5 dB @ 100 Hz), rich 3rd harmonics
        Steel   // Aggressive, heavy low-end magnetic hysteresis & 2nd/3rd saturation
    };

    ShadowHillsMasteringComp() noexcept 
        : m_sampleRate(44100.0f) {}

    void prepare(float sampleRate) noexcept {
        m_sampleRate = sampleRate;
        m_optoEnvL = 0.0f; m_optoEnvR = 0.0f;
        m_optoGrL = 1.0f;  m_optoGrR = 1.0f;
        m_vcaGrL = 1.0f;   m_vcaGrR = 1.0f;
        m_ironL = 0.0f;    m_ironR = 0.0f;
    }

    void setOpticalParameters(float thresholdDb = 0.0f, float gainDb = 0.0f) noexcept {
        m_optoThreshold = std::pow(10.0f, std::clamp(thresholdDb, -30.0f, 0.0f) / 20.0f);
        m_optoGain = std::pow(10.0f, std::clamp(gainDb, 0.0f, 20.0f) / 20.0f);
    }

    void setDiscreteParameters(float thresholdDb = 0.0f, float ratio = 4.0f,
                               float attackMs = 10.0f, float releaseSec = 0.4f,
                               float gainDb = 0.0f) noexcept {
        m_vcaThresholdDb = std::clamp(thresholdDb, -30.0f, 0.0f);
        m_vcaRatio = std::clamp(ratio, 1.2f, 20.0f);
        m_vcaAttackMs = std::clamp(attackMs, 0.1f, 30.0f);
        m_vcaReleaseSec = std::clamp(releaseSec, 0.1f, 1.2f);
        m_vcaGain = std::pow(10.0f, std::clamp(gainDb, 0.0f, 20.0f) / 20.0f);
    }

    void setTransformer(TransformerType transformer) noexcept {
        m_transformer = transformer;
    }

    inline void process(float inL, float inR, float& outL, float& outR) noexcept {
        // =================================================================
        // STAGE 1: Optical Compressor (T4 Cell Smooth Leveling)
        // =================================================================
        float optoL = processOptical(inL, m_optoEnvL, m_optoGrL) * m_optoGain;
        float optoR = processOptical(inR, m_optoEnvR, m_optoGrR) * m_optoGain;

        // =================================================================
        // STAGE 2: Discrete VCA Compressor (Fast Transient Peak Limiter)
        // =================================================================
        float vcaL = processDiscrete(optoL, m_vcaGrL) * m_vcaGain;
        float vcaR = processDiscrete(optoR, m_vcaGrR) * m_vcaGain;

        // =================================================================
        // STAGE 3: Custom Output Transformer Matrix (Nickel / Iron / Steel)
        // =================================================================
        outL = applyTransformer(vcaL, m_ironL);
        outR = applyTransformer(vcaR, m_ironR);
    }

    void processBlock(float* left, float* right, int numSamples) noexcept {
        for (int i = 0; i < numSamples; ++i) {
            process(left[i], right[i], left[i], right[i]);
        }
    }

    [[nodiscard]] float getOpticalGainReductionDb() const noexcept {
        float minGr = std::min(m_optoGrL, m_optoGrR);
        return 20.0f * std::log10(std::max(minGr, 1e-4f));
    }

    [[nodiscard]] float getDiscreteGainReductionDb() const noexcept {
        float minGr = std::min(m_vcaGrL, m_vcaGrR);
        return 20.0f * std::log10(std::max(minGr, 1e-4f));
    }

    [[nodiscard]] float getGainReductionDbOpto() const noexcept {
        return -getOpticalGainReductionDb();
    }

    [[nodiscard]] float getGainReductionDbVCA() const noexcept {
        return -getDiscreteGainReductionDb();
    }

    [[nodiscard]] float getOpticalGrDb() const noexcept {
        return -getOpticalGainReductionDb();
    }

    [[nodiscard]] float getDiscreteGrDb() const noexcept {
        return -getDiscreteGainReductionDb();
    }

private:
    float m_sampleRate;
    float m_optoThreshold{1.0f};
    float m_optoGain{1.0f};

    float m_vcaThresholdDb{0.0f};
    float m_vcaRatio{4.0f};
    float m_vcaAttackMs{10.0f};
    float m_vcaReleaseSec{0.4f};
    float m_vcaGain{1.0f};

    TransformerType m_transformer{TransformerType::Nickel};

    float m_optoEnvL{0}, m_optoEnvR{0};
    float m_optoGrL{1}, m_optoGrR{1};
    float m_vcaGrL{1}, m_vcaGrR{1};
    float m_ironL{0}, m_ironR{0};

    inline float processOptical(float in, float& env, float& gr) noexcept {
        float absVal = std::fabs(in);
        // Optical dual-stage attack/release ballistics
        float attAlpha = 1.0f - std::exp(-1.0f / (0.010f * m_sampleRate)); // 10 ms
        float relAlpha = 1.0f - std::exp(-1.0f / (0.350f * m_sampleRate)); // 350 ms
        if (absVal > env) env += attAlpha * (absVal - env);
        else env += relAlpha * (absVal - env);

        float target = (env > m_optoThreshold) ? (m_optoThreshold / env) : 1.0f;
        gr += 0.05f * (target - gr);
        return in * gr;
    }

    inline float processDiscrete(float in, float& gr) noexcept {
        float absVal = std::fabs(in);
        float detDb = 20.0f * std::log10(std::max(absVal, 1e-5f));
        float overDb = detDb - m_vcaThresholdDb;

        float targetGr = 1.0f;
        if (overDb > 0.0f) {
            float grDb = overDb * (1.0f - 1.0f / m_vcaRatio);
            targetGr = std::pow(10.0f, -grDb / 20.0f);
        }

        float attCoeff = 1.0f - std::exp(-1.0f / ((m_vcaAttackMs * 0.001f) * m_sampleRate));
        float relCoeff = 1.0f - std::exp(-1.0f / (m_vcaReleaseSec * m_sampleRate));
        if (targetGr < gr) gr += attCoeff * (targetGr - gr);
        else gr += relCoeff * (targetGr - gr);

        return in * gr;
    }

    inline float applyTransformer(float in, float& ironState) noexcept {
        switch (m_transformer) {
            case TransformerType::Nickel: {
                // Permalloy Nickel Transformer: Pristine phase with authentic +0.2 dB shelf @ 10 kHz
                float alphaNickel = 10000.0f / (10000.0f + m_sampleRate / 6.2831853f);
                ironState += alphaNickel * (in - ironState);
                float hfSheen = in - ironState;
                return in + 0.023f * hfSheen;
            }

            case TransformerType::Iron: {
                // Iron core: +1.5 dB resonant low-mid weight @ 100 Hz and smooth 3rd harmonic saturation
                float alphaIron = 100.0f / (100.0f + m_sampleRate / 6.2831853f);
                ironState += alphaIron * (in - ironState);
                float xClamped = std::clamp(in, -2.5f, 2.5f);
                float sat = xClamped - 0.08f * (xClamped * xClamped * xClamped);
                return std::tanh(sat) + 0.15f * ironState;
            }

            case TransformerType::Steel: {
                // Silicon Steel: Heavy magnetic hysteresis & asymmetric 2nd/3rd harmonic saturation
                float sat = std::tanh(in * 1.15f);
                float evenHarm = 0.025f * (sat * sat); // 2nd harmonic
                return sat + evenHarm;
            }
        }
        return in;
    }
};

} // namespace dsp171
