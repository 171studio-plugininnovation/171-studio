#pragma once
#include <cmath>
#include <algorithm>
#include "Common.h"
#include "ZDFSVF.h"

namespace dsp171 {

// =============================================================================
// VINTAGE COLOR & CONVERTER UNIT (1970s / 1980s / NOW)
//
// Ispirato alle modalità di Valhalla VintageVerb e ai preamplificatori Waves NLS:
//
// 1. Era 1970s:
//    - Downsampling interno / decimazione (simulazione Lexicon 224 / 11 kHz)
//    - Quantizzazione non-lineare a 12-bit mantissa
//    - Filtro di ricostruzione analogico a 4 poli a 8.5 kHz
//
// 2. Era 1980s:
//    - Risoluzione a 16-bit
//    - Pre-emphasis (+6 dB @ 4 kHz) e De-emphasis (-6 dB) simmetrica
//    - Bandwidth roll-off a 15 kHz (Lexicon 480L style)
//
// 3. Era NOW:
//    - Precisione nativa a 32/64-bit IEEE float, banda passante 20 Hz - 24 kHz
// =============================================================================

enum class VintageEra : uint8_t {
    Era1970s = 0,
    Era1980s = 1,
    EraNOW   = 2
};

class VintageColorUnit {
public:
    VintageColorUnit() = default;

    void prepare(double sampleRate) {
        sr = sampleRate > 1000.0 ? sampleRate : 48000.0;
        
        filterReconstructL1.reset();
        filterReconstructL2.reset();
        filterReconstructR1.reset();
        filterReconstructR2.reset();

        filterEmphasisL.reset();
        filterEmphasisR.reset();

        updateFilters();
        reset();
    }

    void reset() noexcept {
        filterReconstructL1.reset();
        filterReconstructL2.reset();
        filterReconstructR1.reset();
        filterReconstructR2.reset();

        filterEmphasisL.reset();
        filterEmphasisR.reset();

        decimCounter = 0;
        heldL = 0.0f;
        heldR = 0.0f;
    }

    void setEra(VintageEra era, float driveDb = 0.0f) noexcept {
        currentEra = era;
        currentDrive = dbToGain(std::clamp(driveDb, -12.0f, 18.0f));
        updateFilters();
    }

    inline void processSample(float inL, float inR, float& outL, float& outR) noexcept {
        // 1. Console Transformer Drive (NLS Stage)
        float driveL = inL * currentDrive;
        float driveR = inR * currentDrive;

        if (currentDrive > 1.05f) {
            // Generazione armoniche pari e dispari (H2 + H3)
            driveL = fastTanh(driveL) + 0.05f * (driveL * driveL);
            driveR = fastTanh(driveR) + 0.05f * (driveR * driveR);
        }

        switch (currentEra) {
            case VintageEra::Era1970s: {
                // Decimazione campioni (rate reduction 3:1 o 4:1)
                decimCounter++;
                if (decimCounter >= 3) {
                    decimCounter = 0;
                    // Quantizzazione a 12-bit (4096 livelli tra -1.0 e +1.0)
                    constexpr float STEPS_12BIT = 2048.0f;
                    heldL = std::round(driveL * STEPS_12BIT) / STEPS_12BIT;
                    heldR = std::round(driveR * STEPS_12BIT) / STEPS_12BIT;
                }

                // Filtro analogico di ricostruzione a 4 poli (due stadi ZDF SVF in cascata a 8.5 kHz)
                auto s1L = filterReconstructL1.process(heldL);
                auto s2L = filterReconstructL2.process(s1L.lp);
                auto s1R = filterReconstructR1.process(heldR);
                auto s2R = filterReconstructR2.process(s1R.lp);

                outL = s2L.lp;
                outR = s2R.lp;
                break;
            }

            case VintageEra::Era1980s: {
                // Quantizzazione a 16-bit
                constexpr float STEPS_16BIT = 32768.0f;
                float qL = std::round(driveL * STEPS_16BIT) / STEPS_16BIT;
                float qR = std::round(driveR * STEPS_16BIT) / STEPS_16BIT;

                // De-emphasis e roll-off a 15 kHz
                auto sL = filterEmphasisL.process(qL);
                auto sR = filterEmphasisR.process(qR);

                outL = sL.lp;
                outR = sR.lp;
                break;
            }

            case VintageEra::EraNOW:
            default: {
                outL = driveL;
                outR = driveR;
                break;
            }
        }
    }

private:
    void updateFilters() noexcept {
        float fsr = static_cast<float>(sr);
        // 1970s: 8.5 kHz 4-pole Butterworth
        filterReconstructL1.setParameters(8500.0f, 0.7071f, fsr);
        filterReconstructL2.setParameters(8500.0f, 0.7071f, fsr);
        filterReconstructR1.setParameters(8500.0f, 0.7071f, fsr);
        filterReconstructR2.setParameters(8500.0f, 0.7071f, fsr);

        // 1980s: 15.0 kHz 2-pole
        filterEmphasisL.setParameters(15000.0f, 0.7071f, fsr);
        filterEmphasisR.setParameters(15000.0f, 0.7071f, fsr);
    }

    double sr = 48000.0;
    VintageEra currentEra = VintageEra::EraNOW;
    float currentDrive = 1.0f;

    int decimCounter = 0;
    float heldL = 0.0f;
    float heldR = 0.0f;

    ZDFSVF64 filterReconstructL1;
    ZDFSVF64 filterReconstructL2;
    ZDFSVF64 filterReconstructR1;
    ZDFSVF64 filterReconstructR2;

    ZDFSVF64 filterEmphasisL;
    ZDFSVF64 filterEmphasisR;
};

} // namespace dsp171
