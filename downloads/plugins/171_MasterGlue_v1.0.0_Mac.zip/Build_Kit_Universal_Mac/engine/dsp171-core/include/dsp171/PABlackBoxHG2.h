#pragma once
#include <cmath>
#include <algorithm>

namespace dsp171 {

/**
 * @brief BlackBoxHG2
 * Reverse-engineered from Black Box Analog Design HG-2 / HG-2MS.
 * Emulates the boutique stereo tube processor with 6U8A Pentode & Triode tubes,
 * a parallel Saturation circuit with frequency voicing, and an Air Band high-frequency exciter.
 */
class BlackBoxHG2 {
public:
    enum class SaturationFreq {
        Flat,
        Low,  // Sub & low-mid focus (< 500 Hz)
        High  // Presence & high focus (> 2.5 kHz)
    };

    BlackBoxHG2() noexcept 
        : m_sampleRate(44100.0f) {}

    void prepare(float sampleRate) noexcept {
        m_sampleRate = sampleRate;
        m_satFilterL = 0.0f; m_satFilterR = 0.0f;
        m_airFilterL = 0.0f; m_airFilterR = 0.0f;
    }

    void setParameters(float pentodeDrive = 20.0f, float triodeDrive = 20.0f,
                       float satDrive = 15.0f, SaturationFreq satFreq = SaturationFreq::Flat,
                       float airPercent = 25.0f, float outputGainDb = 0.0f) noexcept {
        m_pentodeGain = 1.0f + std::clamp(pentodeDrive, 0.0f, 100.0f) * 0.04f; // 1.0 to 5.0
        m_triodeGain = 1.0f + std::clamp(triodeDrive, 0.0f, 100.0f) * 0.03f;
        m_satGain = std::clamp(satDrive, 0.0f, 100.0f) * 0.035f;
        m_satFreq = satFreq;
        m_airGain = std::clamp(airPercent, 0.0f, 100.0f) * 0.01f * 1.5f;
        m_outputGain = std::pow(10.0f, std::clamp(outputGainDb, -24.0f, 24.0f) / 20.0f);
    }

    inline void process(float inL, float inR, float& outL, float& outR) noexcept {
        outL = processChannel(inL, m_satFilterL, m_airFilterL);
        outR = processChannel(inR, m_satFilterR, m_airFilterR);
    }

    void processBlock(float* left, float* right, int numSamples) noexcept {
        for (int i = 0; i < numSamples; ++i) {
            process(left[i], right[i], left[i], right[i]);
        }
    }

private:
    float m_sampleRate;
    float m_pentodeGain{1.8f};
    float m_triodeGain{1.6f};
    float m_satGain{0.5f};
    SaturationFreq m_satFreq{SaturationFreq::Flat};
    float m_airGain{0.25f};
    float m_outputGain{1.0f};

    float m_satFilterL{0}, m_satFilterR{0};
    float m_airFilterL{0}, m_airFilterR{0};

    inline float processChannel(float in, float& satFilt, float& airFilt) noexcept {
        // -----------------------------------------------------------------
        // 1. Pentode Tube Stage (6U8A Pentode - Aggressive, Odd Harmonics)
        // -----------------------------------------------------------------
        float pIn = in * m_pentodeGain;
        // Symmetric hyperbolic tangent with soft clipping compression
        float pentodeOut = std::tanh(pIn) * 0.85f;

        // -----------------------------------------------------------------
        // 2. Triode Tube Stage (12AX7 / Triode - Warm, Even Harmonics)
        // -----------------------------------------------------------------
        float tIn = pentodeOut * m_triodeGain;
        // Asymmetric transfer function injecting 2nd harmonic
        float triodeOut = tIn - 0.12f * (tIn * tIn) - 0.04f * (tIn * tIn * tIn);

        // -----------------------------------------------------------------
        // 3. Parallel Saturation Circuit (Voiced Saturator)
        // -----------------------------------------------------------------
        float satPath = in;
        if (m_satFreq == SaturationFreq::Low) {
            // Lowpass at 500 Hz for low-end grit
            float alpha = 500.0f / (500.0f + m_sampleRate / 6.2831853f);
            satFilt += alpha * (in - satFilt);
            satPath = satFilt;
        } else if (m_satFreq == SaturationFreq::High) {
            // Highpass at 2500 Hz for presence sizzle
            float alpha = 2500.0f / (2500.0f + m_sampleRate / 6.2831853f);
            satFilt += alpha * (in - satFilt);
            satPath = in - satFilt;
        }

        // Heavy tube overdrive on parallel path
        float overdrivenSat = std::tanh(satPath * (1.0f + m_satGain * 6.0f));

        // -----------------------------------------------------------------
        // 4. Air Band (Sweet ultrasonic shelf above 10 kHz)
        // -----------------------------------------------------------------
        float alphaAir = 10000.0f / (10000.0f + m_sampleRate / 6.2831853f);
        airFilt += alphaAir * (triodeOut - airFilt);
        float highAir = triodeOut - airFilt; // Highpass 10k component

        // -----------------------------------------------------------------
        // 5. Final Summation & Output Gain
        // -----------------------------------------------------------------
        float mixed = triodeOut + (overdrivenSat * m_satGain) + (highAir * m_airGain);
        return mixed * m_outputGain;
    }
};

} // namespace dsp171
