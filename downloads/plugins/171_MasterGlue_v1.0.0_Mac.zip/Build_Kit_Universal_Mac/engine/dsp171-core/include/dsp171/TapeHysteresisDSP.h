#pragma once

#include <cmath>
#include <algorithm>
#include "Common.h"
#include "DCBlocker.h"
#include "FastMath.h"

namespace dsp171 {

// =============================================================================
// TapeHysteresisDSP
// Crafted by: sat-tape-modern-specialist (Supervised by dsp-hire-manager)
//
// Physical modeling of analog reel-to-reel magnetic tape machines:
// 1. Magnetic Domain Hysteresis:
//    - Jiles-Atherton differential approximation with magnetic memory lag.
//    - Natural tape compression on high-velocity transients.
// 2. Repro Head Bump Resonance:
//    - Low-frequency pole contour (approx. 50-70 Hz at 15 IPS, 90-120 Hz at 30 IPS).
// 3. High-Frequency Tape Head Gap Loss:
//    - Sinc-attenuation of extreme frequencies and gentle tape saturation warmth.
// =============================================================================

enum class TapeSpeed : uint8_t {
    IPS_15 = 0, // 15 inches per second: Warm, deep bass head bump, gentle top
    IPS_30      // 30 inches per second: Modern punch, linear extended highs
};

class TapeHysteresisDSP {
public:
    TapeHysteresisDSP() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        dcBlocker.prepare(sampleRate, 10.0f);
        updateSpeedTuning();
        reset();
    }

    void reset() noexcept {
        dcBlocker.reset();
        magnetizationM = 0.0f;
        headBumpState1 = 0.0f;
        headBumpState2 = 0.0f;
        gapLossState = 0.0f;
    }

    void setSpeed(TapeSpeed speed) noexcept {
        if (currentSpeed != speed) {
            currentSpeed = speed;
            updateSpeedTuning();
        }
    }

    // Process a single audio sample through the analog tape engine
    inline float processSample(float in, float driveDb, float tapeWarmth01 = 0.5f) noexcept {
        const float driveGain = dbToGain(driveDb);
        const float H = in * driveGain; // Magnetic field intensity

        // 1. Head Bump Low-Frequency Contour (2nd-order resonant pole)
        headBumpState1 += headBumpAlpha * (H - headBumpState1);
        headBumpState2 += headBumpAlpha * (headBumpState1 - headBumpState2);
        const float bumpedH = H + headBumpGain * (headBumpState1 - headBumpState2);

        // 2. Magnetic Domain Hysteresis Loop
        // Differential domain lag: dM/dt relaxation towards anhysteretic magnetization Man(H)
        const float Man = fastTanh(bumpedH * 1.15f); // Anhysteretic curve
        const float domainLagAlpha = 0.45f - 0.15f * tapeWarmth01;
        magnetizationM += domainLagAlpha * (Man - magnetizationM);

        // Magnetic output voltage is proportional to dM/dt + linear leakage
        const float tapeOut = magnetizationM * 0.85f + bumpedH * 0.15f;

        // 3. High-Frequency Gap Loss (Repro Head Gap Sinc Roll-Off)
        gapLossState += gapLossAlpha * (tapeOut - gapLossState);
        const float finalTape = gapLossState + (tapeOut - gapLossState) * gapLossMix;

        // 4. Output DC Decoupling
        return dcBlocker.processSample(finalTape);
    }

private:
    void updateSpeedTuning() noexcept {
        if (currentSpeed == TapeSpeed::IPS_15) {
            // 15 IPS: Head bump around 60 Hz, warmer top end
            headBumpAlpha = std::clamp(2.0f * PI * 60.0f / sr, 0.001f, 0.5f);
            headBumpGain = 0.40f;
            gapLossAlpha = std::clamp(2.0f * PI * 19000.0f / sr, 0.01f, 0.95f);
            gapLossMix = 0.80f;
        } else {
            // 30 IPS: Head bump around 100 Hz, transparent extended highs
            headBumpAlpha = std::clamp(2.0f * PI * 105.0f / sr, 0.001f, 0.5f);
            headBumpGain = 0.22f;
            gapLossAlpha = std::clamp(2.0f * PI * 28000.0f / sr, 0.01f, 0.99f);
            gapLossMix = 0.94f;
        }
    }

    float sr = 44100.0f;
    TapeSpeed currentSpeed = TapeSpeed::IPS_15;
    float headBumpAlpha = 0.01f;
    float headBumpGain = 0.35f;
    float gapLossAlpha = 0.5f;
    float gapLossMix = 0.85f;
    float magnetizationM = 0.0f;
    float headBumpState1 = 0.0f;
    float headBumpState2 = 0.0f;
    float gapLossState = 0.0f;
    DCBlocker dcBlocker;
};

} // namespace dsp171
