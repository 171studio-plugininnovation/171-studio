#pragma once
#include <cmath>
#include <algorithm>

namespace dsp171 {

// =============================================================================
// Authentic Antiparallel Diode Clipper with C-inf Analytic ADAA-2
// Models physical Shockley exponential diode knee using smooth algebraic
// conduction transfer function: f(x) = x / sqrt(1 + x^2).
// Primitives are infinitely smooth (C-inf) across (-inf, +inf) with zero branch
// cuts, zero derivative jumps, and exact analytical L'Hopital limits for
// both d0 -> 0 and dTot -> 0, eliminating all group delay/amplitude glitches.
// =============================================================================
class ADAA2Clipper {
public:
    void reset() noexcept {
        x1 = 0.0;
        x2 = 0.0;
    }

    // Diode Conduction Law: f(x) = x / sqrt(1 + x^2)
    static inline double f(double x) noexcept {
        return x / std::sqrt(1.0 + x * x);
    }

    // First Continuous Antiderivative: F1(x) = sqrt(1 + x^2) - 1.0
    static inline double F1(double x) noexcept {
        return std::sqrt(1.0 + x * x) - 1.0;
    }

    // Second Continuous Antiderivative: F2(x) = 0.5 * (x * sqrt(1 + x^2) + asinh(x)) - x
    static inline double F2(double x) noexcept {
        const double root = std::sqrt(1.0 + x * x);
        return 0.5 * (x * root + std::asinh(x)) - x;
    }

    inline float processSample(float x0, float drive) noexcept {
        // Guard input audio and drive against non-finite values (NaN / Inf)
        if (!std::isfinite(x0)) x0 = 0.0f;
        if (!std::isfinite(drive)) drive = 1.0f;
        const double safeDrive = std::max(0.0, static_cast<double>(drive));

        const double kneeScale = 1.5;
        const double in = static_cast<double>(x0) * safeDrive * kneeScale;
        constexpr double eps = 1.0e-5;

        const double d0 = in - x1;
        const double d1 = x1 - x2;
        const double dTot = in - x2;

        auto diffF2 = [](double a, double b, double d) noexcept -> double {
            if (std::abs(d) < eps) {
                const double mid = 0.5 * (a + b);
                const double denom = std::sqrt(1.0 + mid * mid);
                const double fPrimeMid = 1.0 / (denom * denom * denom); // d/dx [x / sqrt(1+x^2)]
                return F1(mid) + (d * d / 24.0) * fPrimeMid;
            }
            return (F2(a) - F2(b)) / d;
        };

        double out = 0.0;

        if (std::abs(dTot) < eps) {
            const double diff = x2 - x1;
            if (std::abs(diff) < eps || std::abs(d0) < eps) {
                // Triple-coincident / small diff limit:
                // Analytical Taylor expansion of L'Hopital branch: f(x2) - (diff / 3.0) * fPrime(x2)
                const double denom = std::sqrt(1.0 + x2 * x2);
                const double fPrimeX2 = 1.0 / (denom * denom * denom);
                out = f(x2) - (diff / 3.0) * fPrimeX2;
            } else {
                // Exact limit of ADAA-2 as x0 -> x2 (with |diff| >= eps):
                // lim_{x0->x2} 2/(x0-x2) * [ (F2(x0)-F2(x1))/(x0-x1) - (F2(x1)-F2(x2))/(x1-x2) ]
                // = 2 * [ F1(x2)*(x2-x1) - (F2(x2)-F2(x1)) ] / (x2-x1)^2
                const double diffSq = diff * diff;
                const double safeDiffSq = (diffSq > 1.0e-12) ? diffSq : 1.0e-12;
                out = 2.0 * (F1(x2) * diff - (F2(x2) - F2(x1))) / safeDiffSq;
            }
        } else {
            const double term0 = diffF2(in, x1, d0);
            const double term1 = diffF2(x1, x2, d1);
            out = (2.0 / dTot) * (term0 - term1);
        }

        // Subnormal / denormal state hygiene
        x2 = (std::abs(x1) > 1.0e-25) ? x1 : 0.0;
        x1 = (std::abs(in) > 1.0e-25) ? in : 0.0;

        // Dynamic equal-loudness calibration with robust minimum clamp guard
        // Denominator (kneeScale * (1.0 + 0.30 * (drive - 1.0))) cannot be zero or negative
        const double driveTerm = 1.0 + 0.30 * (safeDrive - 1.0);
        const double safeDenom = kneeScale * std::max(0.01, driveTerm);
        const double normFactor = 1.0 / safeDenom;

        const float result = static_cast<float>(out * normFactor);
        return std::isfinite(result) ? result : 0.0f;
    }

private:
    double x1 = 0.0;
    double x2 = 0.0;
};

} // namespace dsp171
