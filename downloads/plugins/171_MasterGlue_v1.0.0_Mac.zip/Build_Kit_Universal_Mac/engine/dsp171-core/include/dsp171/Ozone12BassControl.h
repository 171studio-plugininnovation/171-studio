#pragma once
#include <cmath>
#include <algorithm>
#include <array>

namespace dsp171 {

/**
 * @brief Ozone12BassControl
 * Reverse-engineered from iZotope Ozone 12 Bass Control module.
 * Decomposes sub-bass frequencies below CutoffFreq into transient Punch (kick drum attacks)
 * and sustained Body (808s, synth subs, bass guitar notes), providing independent dynamic shaping.
 */
class Ozone12BassControl {
public:
    Ozone12BassControl() noexcept 
        : m_sampleRate(44100.0f), m_cutoff(140.0f) {}

    void prepare(float sampleRate) noexcept {
        m_sampleRate = sampleRate;
        resetFilters();
        m_fastEnvL = 0.0f; m_slowEnvL = 0.0f;
        m_fastEnvR = 0.0f; m_slowEnvR = 0.0f;
        m_smoothGainL = 1.0f; m_smoothGainR = 1.0f;
        updateBallistics();
        updateCrossover();
    }

    void setParameters(float cutoffHz, float punchDb, float peakThresholdDb,
                       float sustainAmountPercent, float balanceDb, float character = 2.0f) noexcept {
        m_cutoff = std::clamp(cutoffHz, 20.0f, 350.0f);
        m_punchGain = std::pow(10.0f, std::clamp(punchDb, -5.0f, 5.0f) / 20.0f);
        m_peakThreshold = std::pow(10.0f, std::clamp(peakThresholdDb, -30.0f, 0.0f) / 20.0f);
        m_sustainAmount = std::clamp(sustainAmountPercent, 0.0f, 100.0f) * 0.01f;
        
        // Balance: -10 dB (favor sustain) to +10 dB (favor punch)
        float balLinear = std::pow(10.0f, std::clamp(balanceDb, -10.0f, 10.0f) / 20.0f);
        m_punchBalance = balLinear / (1.0f + balLinear) * 2.0f;
        m_sustainBalance = 2.0f - m_punchBalance;

        m_character = std::clamp(character, 0.0f, 6.0f); // 0 = sharp clip, 6 = smooth tube
        updateCrossover();
    }

    inline void process(float inL, float inR, float& outL, float& outR) noexcept {
        // 1. Crossover Split: Low vs High
        float lowL, highL, lowR, highR;
        filterLR4(inL, inR, lowL, highL, lowR, highR);

        // 2. Decompose Low into Transient (Punch) vs Sustain
        float punchL, sustainL, punchR, sustainR;
        decompose(lowL, m_fastEnvL, m_slowEnvL, punchL, sustainL);
        decompose(lowR, m_fastEnvR, m_slowEnvR, punchR, sustainR);

        // 3. Process Punch (Dynamic Peak Limiter / Saturation)
        punchL = processPunch(punchL * m_punchGain);
        punchR = processPunch(punchR * m_punchGain);

        // 4. Process Sustain (Adaptive Sub Leveler with anti-zipper smoothing)
        sustainL = processSustain(sustainL, m_slowEnvL, m_smoothGainL);
        sustainR = processSustain(sustainR, m_slowEnvR, m_smoothGainR);

        // 5. Recombine sub-bass with balance and add unaffected high-frequency audio
        float recombinedLowL = (punchL * m_punchBalance) + (sustainL * m_sustainBalance);
        float recombinedLowR = (punchR * m_punchBalance) + (sustainR * m_sustainBalance);

        outL = highL + recombinedLowL;
        outR = highR + recombinedLowR;
    }

    void processBlock(float* left, float* right, int numSamples) noexcept {
        for (int i = 0; i < numSamples; ++i) {
            process(left[i], right[i], left[i], right[i]);
        }
    }

private:
    float m_sampleRate;
    float m_cutoff;
    float m_punchGain{1.0f};
    float m_peakThreshold{0.89f};
    float m_sustainAmount{0.5f};
    float m_punchBalance{1.0f};
    float m_sustainBalance{1.0f};
    float m_character{2.0f};

    // Linkwitz-Riley 4th Order (2x cascaded 2nd order Butterworth)
    struct Biquad {
        float b0{1}, b1{0}, b2{0}, a1{0}, a2{0};
        float z1{0}, z2{0};

        inline float process(float in) noexcept {
            float out = b0 * in + z1;
            z1 = b1 * in - a1 * out + z2;
            z2 = b2 * in - a2 * out;
            return out;
        }

        void reset() noexcept { z1 = 0.0f; z2 = 0.0f; }
    };

    Biquad m_lpL1, m_lpL2, m_hpL1, m_hpL2;
    Biquad m_lpR1, m_lpR2, m_hpR1, m_hpR2;

    float m_fastEnvL{0}, m_slowEnvL{0};
    float m_fastEnvR{0}, m_slowEnvR{0};
    float m_smoothGainL{1.0f}, m_smoothGainR{1.0f};

    // Precomputed ballistic alphas (avoids 8 std::exp calls per stereo frame in inner loop)
    float m_attackCoeffFast{0.0f};
    float m_releaseCoeffFast{0.0f};
    float m_attackCoeffSlow{0.0f};
    float m_releaseCoeffSlow{0.0f};
    float m_compGainAlpha{0.0f};

    void updateBallistics() noexcept {
        m_attackCoeffFast = 1.0f - std::exp(-1.0f / (0.005f * m_sampleRate));
        m_releaseCoeffFast = 1.0f - std::exp(-1.0f / (0.020f * m_sampleRate));
        m_attackCoeffSlow = 1.0f - std::exp(-1.0f / (0.015f * m_sampleRate));
        m_releaseCoeffSlow = 1.0f - std::exp(-1.0f / (0.150f * m_sampleRate));
        m_compGainAlpha = 1.0f - std::exp(-1.0f / (0.025f * m_sampleRate)); // 25 ms anti-zipper smoothing
    }

    void resetFilters() noexcept {
        m_lpL1.reset(); m_lpL2.reset(); m_hpL1.reset(); m_hpL2.reset();
        m_lpR1.reset(); m_lpR2.reset(); m_hpR1.reset(); m_hpR2.reset();
    }

    void updateCrossover() noexcept {
        // Compute 2nd order Butterworth coefficients
        float omega = 2.0f * 3.14159265f * m_cutoff / m_sampleRate;
        float sinOmega = std::sin(omega);
        float cosOmega = std::cos(omega);
        float alpha = sinOmega * 0.70710678f; // Q = 1 / sqrt(2)

        float a0 = 1.0f + alpha;

        // Lowpass
        float lpB0 = ((1.0f - cosOmega) * 0.5f) / a0;
        float lpB1 = (1.0f - cosOmega) / a0;
        float lpB2 = ((1.0f - cosOmega) * 0.5f) / a0;
        float a1 = (-2.0f * cosOmega) / a0;
        float a2 = (1.0f - alpha) / a0;

        // Highpass
        float hpB0 = ((1.0f + cosOmega) * 0.5f) / a0;
        float hpB1 = -(1.0f + cosOmega) / a0;
        float hpB2 = ((1.0f + cosOmega) * 0.5f) / a0;

        auto applyCoeffs = [=](Biquad& b, float b0, float b1, float b2) {
            b.b0 = b0; b.b1 = b1; b.b2 = b2;
            b.a1 = a1; b.a2 = a2;
        };

        applyCoeffs(m_lpL1, lpB0, lpB1, lpB2);
        applyCoeffs(m_lpL2, lpB0, lpB1, lpB2);
        applyCoeffs(m_hpL1, hpB0, hpB1, hpB2);
        applyCoeffs(m_hpL2, hpB0, hpB1, hpB2);

        applyCoeffs(m_lpR1, lpB0, lpB1, lpB2);
        applyCoeffs(m_lpR2, lpB0, lpB1, lpB2);
        applyCoeffs(m_hpR1, hpB0, hpB1, hpB2);
        applyCoeffs(m_hpR2, hpB0, hpB1, hpB2);
    }

    inline void filterLR4(float inL, float inR, float& lowL, float& highL, float& lowR, float& highR) noexcept {
        lowL = m_lpL2.process(m_lpL1.process(inL));
        highL = m_hpL2.process(m_hpL1.process(inL));

        lowR = m_lpR2.process(m_lpR1.process(inR));
        highR = m_hpR2.process(m_hpR1.process(inR));
    }

    inline void decompose(float x, float& fastEnv, float& slowEnv, float& punch, float& sustain) noexcept {
        float absX = std::fabs(x);
        
        // Fast detector (5 ms attack, 20 ms release) - using precomputed ballistic alphas
        if (absX > fastEnv) fastEnv += m_attackCoeffFast * (absX - fastEnv);
        else fastEnv += m_releaseCoeffFast * (absX - fastEnv);

        // Slow detector (15 ms attack, 150 ms release) - using precomputed ballistic alphas
        if (absX > slowEnv) slowEnv += m_attackCoeffSlow * (absX - slowEnv);
        else slowEnv += m_releaseCoeffSlow * (absX - slowEnv);

        // Separation ratio based on crest differential
        float diff = std::max(0.0f, fastEnv - slowEnv);
        float transRatio = std::clamp(diff / (fastEnv + 1e-5f), 0.0f, 1.0f);

        punch = x * transRatio;
        sustain = x * (1.0f - transRatio);
    }

    inline float processPunch(float x) noexcept {
        float absX = std::fabs(x);
        if (absX > m_peakThreshold) {
            float excess = absX - m_peakThreshold;
            // Character blend: 0 = hard limiter, 6 = smooth tanh saturation
            float satK = 1.0f + m_character * 0.5f;
            float limited = m_peakThreshold + std::tanh(excess * satK) / satK;
            return std::copysign(limited, x);
        }
        return x;
    }

    inline float processSustain(float x, float slowEnv, float& smoothGain) noexcept {
        // Upward/downward leveling towards nominal energy
        float targetEnergy = 0.25f;
        float diff = targetEnergy - slowEnv;
        float targetCompGain = 1.0f + m_sustainAmount * std::clamp(diff * 2.0f, -0.6f, 0.6f);
        // Anti-zipper smoothing filter
        smoothGain += m_compGainAlpha * (targetCompGain - smoothGain);
        return x * smoothGain;
    }
};

} // namespace dsp171
