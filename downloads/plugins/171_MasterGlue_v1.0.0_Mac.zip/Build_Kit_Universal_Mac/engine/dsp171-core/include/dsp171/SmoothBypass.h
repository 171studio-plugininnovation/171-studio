#pragma once
#include <algorithm>
#include <cmath>

#if __has_include(<juce_audio_basics/juce_audio_basics.h>)
#include <juce_audio_basics/juce_audio_basics.h>
#define DSP171_HAS_JUCE_SMOOTHED_VALUE 1
#else
#define DSP171_HAS_JUCE_SMOOTHED_VALUE 0
#endif

namespace dsp171 {

// Gestore Bypass Pop-Free con Crossfade Continuo a Rampa Lineare (default 15ms)
class SmoothBypass {
public:
    void prepare(double sampleRate, double rampTimeSec = 0.015) noexcept {
#if DSP171_HAS_JUCE_SMOOTHED_VALUE
        smoothedBypass.reset(sampleRate, rampTimeSec);
        smoothedBypass.setCurrentAndTargetValue(0.0f);
#else
        rampStep = 1.0f / static_cast<float>(std::max(1.0, rampTimeSec * sampleRate));
        currentVal = 0.0f;
        targetVal = 0.0f;
#endif
    }

    void reset() noexcept {
#if DSP171_HAS_JUCE_SMOOTHED_VALUE
        smoothedBypass.setCurrentAndTargetValue(0.0f);
#else
        currentVal = 0.0f;
        targetVal = 0.0f;
#endif
    }

    // bypassActive == true -> target = 1.0 (Dry), bypassActive == false -> target = 0.0 (Wet)
    void setBypassTarget(bool bypassActive) noexcept {
#if DSP171_HAS_JUCE_SMOOTHED_VALUE
        smoothedBypass.setTargetValue(bypassActive ? 1.0f : 0.0f);
#else
        targetVal = bypassActive ? 1.0f : 0.0f;
#endif
    }

    // Restituisce il valore del bypass per il campione corrente: 0.0f = Wet (plugin attivo), 1.0f = Dry (bypassato)
    inline float getNextValue() noexcept {
#if DSP171_HAS_JUCE_SMOOTHED_VALUE
        return smoothedBypass.getNextValue();
#else
        if (currentVal < targetVal) {
            currentVal = std::min(targetVal, currentVal + rampStep);
        } else if (currentVal > targetVal) {
            currentVal = std::max(targetVal, currentVal - rampStep);
        }
        return currentVal;
#endif
    }

    // Applica il crossfade bypass sul campione wet e dry
    inline float crossfade(float wetSample, float drySample, float bypassWeight) noexcept {
        return (wetSample * (1.0f - bypassWeight)) + (drySample * bypassWeight);
    }

    // Controlla se il plugin è completamente in bypass stabile (utile per saltare calcoli pesanti se desiderato)
    bool isFullyBypassed() const noexcept {
#if DSP171_HAS_JUCE_SMOOTHED_VALUE
        return smoothedBypass.getCurrentValue() >= 0.999f && smoothedBypass.getTargetValue() >= 0.999f;
#else
        return currentVal >= 0.999f && targetVal >= 0.999f;
#endif
    }

private:
#if DSP171_HAS_JUCE_SMOOTHED_VALUE
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> smoothedBypass;
#else
    float currentVal{0.0f};
    float targetVal{0.0f};
    float rampStep{0.001f};
#endif
};

} // namespace dsp171
