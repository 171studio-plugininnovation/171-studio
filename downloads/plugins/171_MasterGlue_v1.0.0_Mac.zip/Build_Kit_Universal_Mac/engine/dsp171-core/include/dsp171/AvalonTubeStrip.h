#pragma once

#include <cmath>
#include <algorithm>
#include <array>
#include "Common.h"
#include "DCBlocker.h"
#include "FastMath.h"
#include "ZDFSVF.h"
#include "AvalonTubeSaturator.h"

namespace dsp171 {

// =============================================================================
// AvalonTubeStrip
// Crafted by: sat-avalon-specialist (Reviewed by dsp-math-bugfinder)
// Supervised by: dsp-hire-manager (Dispatch Ticket #PRE-AVALON-03)
//
// Physical modeling of the Avalon VT-737sp Vacuum Tube Channel Strip:
// 1. High-Voltage Class-A Dual-Triodes (6922 / 12AX7, 150V+ Plate):
//    - Child-Langmuir law non-linear plate conduction.
//    - Dominant musical second harmonic (H2) warmth without harsh odd harmonics.
// 2. Class-A Headroom & Gentle Dynamic Soft Clipping Knee.
// 3. Avalon Iconic 32 kHz Ultra-Air Sheen:
//    - Phase-coherent passive LC air shelf centered at 32 kHz.
// 4. Discrete 4-Band Vacuum Tube Equalizer:
//    - Bass Band: Shelf/Bell (15, 30, 60, 150 Hz, +/- 24 dB).
//    - Low-Mid Band: Sweepable (35 Hz - 450 Hz, variable Q).
//    - High-Mid Band: Sweepable (200 Hz - 2.8 kHz / 2 kHz - 28 kHz, variable Q).
//    - Treble Band: Shelf/Bell (10 kHz, 15 kHz, 20 kHz, 32 kHz Air Sheen, +/- 20 dB).
// =============================================================================

class AvalonTubeStrip {
public:
    AvalonTubeStrip() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);

        saturator.prepare(sampleRate);
        dcBlocker.prepare(sampleRate, 10.0f);

        // Preamp Low Cut filter (variable 30 Hz - 140 Hz 6 dB/octave passive)
        hpfSvf.setParameters(30.0f, 0.707f, sr);

        updateEQCoeffs();
        reset();
    }

    void reset() noexcept {
        saturator.reset();
        dcBlocker.reset();
        hpfSvf.reset();
        for (auto& svf : eqSvfs) {
            svf.reset();
        }
    }

    // Set Preamp Parameters (Drive, Warmth, Air Sheen, HPF)
    void setPreamp(float driveDb, float warmth01 = 0.5f, float airSheenDb = 3.0f,
                   bool enableHpf = false, float hpfFreq = 60.0f) noexcept
    {
        tubeDriveDb = driveDb;
        tubeWarmth = std::clamp(warmth01, 0.0f, 1.0f);
        airSheen = std::clamp(airSheenDb, 0.0f, 10.0f);
        hpfEnabled = enableHpf;
        if (hpfEnabled) {
            hpfSvf.setParameters(std::clamp(hpfFreq, 20.0f, 200.0f), 0.707f, sr);
        }
    }

    // Configure 4-band tube EQ
    void setEQ(float bassGainDb, float lowMidGainDb, float lowMidFreq,
               float highMidGainDb, float highMidFreq,
               float trebleGainDb, bool eqIn = true) noexcept
    {
        bassGain = std::clamp(bassGainDb, -24.0f, 24.0f);
        lmGain = std::clamp(lowMidGainDb, -16.0f, 16.0f);
        lmFreq = std::clamp(lowMidFreq, 35.0f, 450.0f);
        hmGain = std::clamp(highMidGainDb, -16.0f, 16.0f);
        hmFreq = std::clamp(highMidFreq, 200.0f, 8000.0f);
        trebleGain = std::clamp(trebleGainDb, -20.0f, 20.0f);
        isEqActive = eqIn;

        updateEQCoeffs();
    }

    // Set Master Output
    void setOutput(float outGainDb) noexcept {
        outGainLin = dbToGain(outGainDb);
    }

    // Process a single audio sample
    inline float processSample(float in) noexcept {
        // 1. High-Voltage Dual-Triode 6922/12AX7 Class-A Warmth & 32 kHz Air Sheen
        float sig = saturator.processSample(in, tubeDriveDb, tubeWarmth, airSheen);

        // 2. Passive High-Pass Filter
        if (hpfEnabled) {
            const auto hpfOut = hpfSvf.process(sig);
            sig = hpfOut.hp;
        }

        // 3. Discrete Class-A Tube 4-Band Equalizer
        if (isEqActive) {
            // Band 0: Bass Shelf (100 Hz)
            if (std::abs(bassGain) > 0.01f) {
                const auto out = eqSvfs[0].process(sig);
                sig = sig + out.lp * (dbToGain(bassGain) - 1.0f);
            }
            // Band 1: Low-Mid Bell (Sweepable)
            if (std::abs(lmGain) > 0.01f) {
                const auto out = eqSvfs[1].process(sig);
                sig = sig + out.bp * (dbToGain(lmGain) - 1.0f);
            }
            // Band 2: High-Mid Bell (Sweepable)
            if (std::abs(hmGain) > 0.01f) {
                const auto out = eqSvfs[2].process(sig);
                sig = sig + out.bp * (dbToGain(hmGain) - 1.0f);
            }
            // Band 3: Treble Shelf (10 kHz / 32 kHz LC Sheen)
            if (std::abs(trebleGain) > 0.01f) {
                const auto out = eqSvfs[3].process(sig);
                sig = sig + out.hp * (dbToGain(trebleGain) - 1.0f);
            }
        }

        // 4. Output Trim & DC Decoupling
        return dcBlocker.processSample(sig * outGainLin);
    }

    // Process a buffer of audio samples
    void processBlock(float* buffer, size_t numSamples) noexcept {
        if (!buffer || numSamples == 0) return;
        for (size_t i = 0; i < numSamples; ++i) {
            buffer[i] = processSample(buffer[i]);
        }
    }

private:
    void updateEQCoeffs() noexcept {
        // Bass Shelf fixed at 80 Hz
        eqSvfs[0].setParameters(80.0f, 0.707f, sr);
        // Low-Mid Bell
        eqSvfs[1].setParameters(lmFreq, 1.0f, sr);
        // High-Mid Bell
        eqSvfs[2].setParameters(hmFreq, 1.2f, sr);
        // Treble High Shelf at 12 kHz
        eqSvfs[3].setParameters(12000.0f, 0.707f, sr);
    }

    float sr{44100.0f};

    float tubeDriveDb{0.0f};
    float tubeWarmth{0.5f};
    float airSheen{3.0f};
    bool hpfEnabled{false};
    bool isEqActive{true};
    float outGainLin{1.0f};

    float bassGain{0.0f};
    float lmGain{0.0f};
    float lmFreq{250.0f};
    float hmGain{0.0f};
    float hmFreq{2500.0f};
    float trebleGain{0.0f};

    AvalonTubeSaturator saturator;
    DCBlocker dcBlocker;

    ZDFSVF64 hpfSvf;
    std::array<ZDFSVF64, 4> eqSvfs;
};

} // namespace dsp171
