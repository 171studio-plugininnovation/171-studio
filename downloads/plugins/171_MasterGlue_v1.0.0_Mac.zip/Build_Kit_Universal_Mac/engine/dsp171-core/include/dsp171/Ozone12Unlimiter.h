#pragma once
#include <cmath>
#include <array>
#include <vector>
#include <algorithm>

namespace dsp171 {

/**
 * @brief Ozone12Unlimiter
 * Reverse-engineered from iZotope Ozone 12 Unlimiter module.
 * Restores transients and dynamic crest factor from severely brickwalled, clipped,
 * or over-compressed masters using cubic Hermite spline extrapolation and auto-threshold learning.
 */
class Ozone12Unlimiter {
public:
    Ozone12Unlimiter() noexcept 
        : m_sampleRate(44100.0f), m_amount(1.0f), m_thresholdLinear(0.988f) {}

    void prepare(float sampleRate) noexcept {
        m_sampleRate = sampleRate;
        m_historyL.fill(0.0f);
        m_historyR.fill(0.0f);
        m_consecutiveClipsL = 0;
        m_consecutiveClipsR = 0;
    }

    void setParameters(float amountPercent, float thresholdDb, float inGainDb = 0.0f, float outGainDb = 0.0f) noexcept {
        m_amount = std::clamp(amountPercent, 0.0f, 200.0f) * 0.01f;
        m_thresholdLinear = std::pow(10.0f, std::clamp(thresholdDb, -6.0f, 0.0f) / 20.0f);
        m_inputGain = std::pow(10.0f, inGainDb / 20.0f);
        m_outputGain = std::pow(10.0f, outGainDb / 20.0f);
    }

    /**
     * @brief Automatically analyzes a signal buffer to detect the brickwall clipping ceiling
     */
    float learnThreshold(const float* buffer, size_t numSamples) noexcept {
        if (!buffer || numSamples < 64) return -0.1f;
        float maxPeak = 0.0f;
        for (size_t i = 0; i < numSamples; ++i) {
            float absVal = std::fabs(buffer[i]);
            if (absVal > maxPeak) maxPeak = absVal;
        }

        int clipCount = 0;
        for (size_t i = 0; i < numSamples; ++i) {
            float absVal = std::fabs(buffer[i]);
            if (absVal >= (maxPeak * 0.995f) && maxPeak > 0.05f) {
                clipCount++;
            }
        }

        if (clipCount >= 4 && maxPeak > 0.05f) {
            m_thresholdLinear = maxPeak;
            return 20.0f * std::log10(maxPeak);
        }
        return -0.1f;
    }

    inline void process(float inL, float inR, float& outL, float& outR) noexcept {
        inL *= m_inputGain;
        inR *= m_inputGain;

        outL = reconstructCrest(inL, m_historyL, m_consecutiveClipsL) * m_outputGain;
        outR = reconstructCrest(inR, m_historyR, m_consecutiveClipsR) * m_outputGain;
    }

    void processBlock(float* left, float* right, int numSamples) noexcept {
        for (int i = 0; i < numSamples; ++i) {
            process(left[i], right[i], left[i], right[i]);
        }
    }

    [[nodiscard]] float getThresholdLinear() const noexcept { return m_thresholdLinear; }
    [[nodiscard]] float getAmount() const noexcept { return m_amount; }

private:
    float m_sampleRate;
    float m_amount;
    float m_thresholdLinear;
    float m_inputGain{1.0f};
    float m_outputGain{1.0f};

    std::array<float, 4> m_historyL{};
    std::array<float, 4> m_historyR{};
    int m_consecutiveClipsL{0};
    int m_consecutiveClipsR{0};

    inline float reconstructCrest(float x, std::array<float, 4>& hist, int& clipCount) noexcept {
        // Shift history: [0] = oldest, [3] = current
        hist[0] = hist[1];
        hist[1] = hist[2];
        hist[2] = hist[3];
        hist[3] = x;

        float absX = std::fabs(x);
        float thresholdBase = m_thresholdLinear * 0.98f;

        if (absX >= thresholdBase) {
            clipCount++;
            // Calculate velocity entering the threshold before clipping
            float vEnter = std::fabs(hist[1] - hist[0]);
            float arcGain = std::max(vEnter * 1.5f, 0.035f);

            // C1-continuous smoothstep threshold entrance (zero jump, zero derivative jump at boundary)
            float u = std::clamp((absX - thresholdBase) / (m_thresholdLinear - thresholdBase + 1e-6f), 0.0f, 1.0f);
            float smoothKnee = u * u * (3.0f - 2.0f * u);

            // Temporal Hermite envelope over clipping duration
            float t = std::clamp(static_cast<float>(clipCount) / 4.0f, 0.0f, 1.0f);
            float hermiteSmoothEnvelope = 4.0f * t * (1.0f - t * 0.75f);

            float restoredCrest = arcGain * m_amount * hermiteSmoothEnvelope * smoothKnee;
            float sgn = (x >= 0.0f) ? 1.0f : -1.0f;

            return x + sgn * restoredCrest;
        } else {
            clipCount = 0;
            return x;
        }
    }
};

} // namespace dsp171
