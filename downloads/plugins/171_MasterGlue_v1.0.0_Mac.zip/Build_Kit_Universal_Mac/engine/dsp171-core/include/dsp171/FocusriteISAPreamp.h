#pragma once

#include <cmath>
#include <algorithm>
#include "Common.h"
#include "DCBlocker.h"
#include "FastMath.h"

namespace dsp171 {

// =============================================================================
// FocusriteISAPreamp
// Crafted by: sat-focusrite-specialist (Supervised by dsp-hire-manager)
//
// Physical modeling of the legendary Rupert Neve Focusrite ISA 110 / ISA 430:
// 1. Lundahl LL1538 / LL1538XL mu-metal core audio input transformer:
//    - Ultra-linear magnetic permeability across 20 Hz to 20 kHz.
//    - Sub-25 Hz subtle core saturation under massive low-frequency drive.
// 2. Variable Input Impedance Loading (ISA Four-Z):
//    - Low:  600 Ohm  (heavily damped, dark/warm ribbon microphone loading)
//    - ISA: 1400 Ohm  (authentic ISA 110 AIR Montserrat console loading)
//    - Med: 2400 Ohm  (balanced dynamic / condenser loading)
//    - High: 6800 Ohm (undamped, maximum high-frequency transient openness)
// 3. Wideband Discrete Class-AB Output Stage (+24 dBu headroom, clean punch).
// =============================================================================

enum class ISAImpedance : uint8_t {
    Low_600Ohm = 0,
    ISA110_1400Ohm,
    Med_2400Ohm,
    High_6800Ohm
};

class FocusriteISAPreamp {
public:
    FocusriteISAPreamp() noexcept {
        reset();
    }

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        dcBlocker.prepare(sampleRate, 10.0f);
        updateImpedanceDamping();
        reset();
    }

    void reset() noexcept {
        dcBlocker.reset();
        muMetalFlux = 0.0f;
        zFilterState = 0.0f;
        airShelfState = 0.0f;
    }

    void setImpedance(ISAImpedance z) noexcept {
        if (currentZ != z) {
            currentZ = z;
            updateImpedanceDamping();
        }
    }

    // Process a single audio sample through the Focusrite ISA 110 topology
    inline float processSample(float in, float gainDb, float airBoostDb = 0.0f) noexcept {
        if (!std::isfinite(in)) return 0.0f;
        const float linearGain = dbToGain(gainDb);
        float x = in * linearGain;

        // 1. Variable Impedance Damping Network (Models microphone coil loading)
        // High Z: wider HF bandwidth; Low Z: heavier acoustic damping
        zFilterState += zDampingAlpha * (x - zFilterState);
        if (std::abs(zFilterState) < 1.0e-25f) zFilterState = 0.0f;
        x = zFilterState + (x - zFilterState) * zHFRatio;

        // 2. Lundahl LL1538 Mu-Metal Transformer Flux Integration (< 25 Hz)
        // Mu-metal is exceptionally transparent in the midband, saturating only under deep LF swing
        constexpr float fcCore = 22.0f;
        const float wCore = 2.0f * PI * fcCore / sr;
        muMetalFlux += wCore * (x - muMetalFlux);
        if (std::abs(muMetalFlux) < 1.0e-25f) muMetalFlux = 0.0f;

        // Core non-linearity: gentle cubic saturation clamped at monotonic vertex |u| = 2.886f
        const float coreExc = x + muMetalFlux * 0.15f;
        const float clampedCoreExc = std::clamp(coreExc, -2.886f, 2.886f);
        const float saturatedCore = clampedCoreExc - 0.04f * (clampedCoreExc * clampedCoreExc * clampedCoreExc);

        // 3. Wideband Class-AB Discrete Amp Rail Limiting (+24 dBu nominal headroom)
        // Extremely high linearity, smooth tanh compression only at extreme peak excursions (> +20 dBFS)
        const float ampOut = (std::abs(saturatedCore) < 1.25f)
            ? saturatedCore
            : std::copysign(1.25f + 0.25f * fastTanh((std::abs(saturatedCore) - 1.25f) * 4.0f), saturatedCore);

        // 4. Optional ISA Air Shelving EQ (+0 to +10 dB @ 25 kHz)
        float out = ampOut;
        if (airBoostDb > 0.01f) {
            const float airGain = dbToGain(airBoostDb);
            constexpr float fcAir = 18000.0f;
            const float wAir = std::min(0.85f, 2.0f * PI * fcAir / sr);
            airShelfState += wAir * (ampOut - airShelfState);
            if (std::abs(airShelfState) < 1.0e-25f) airShelfState = 0.0f;
            out = airShelfState + (ampOut - airShelfState) * airGain;
        }

        // 5. Output DC Decoupling
        return dcBlocker.processSample(out);
    }

private:
    void updateImpedanceDamping() noexcept {
        switch (currentZ) {
            case ISAImpedance::Low_600Ohm:
                // Heavily damped: subtle HF rolloff around 18 kHz, thickened low-end
                zDampingAlpha = std::clamp(2.0f * PI * 18000.0f / sr, 0.01f, 0.95f);
                zHFRatio = 0.88f;
                break;
            case ISAImpedance::ISA110_1400Ohm:
                // Nominal classic ISA 110 AIR Montserrat console loading
                zDampingAlpha = std::clamp(2.0f * PI * 45000.0f / sr, 0.01f, 0.99f);
                zHFRatio = 1.00f;
                break;
            case ISAImpedance::Med_2400Ohm:
                // Slightly lighter loading, open air presence
                zDampingAlpha = std::clamp(2.0f * PI * 60000.0f / sr, 0.01f, 0.99f);
                zHFRatio = 1.04f;
                break;
            case ISAImpedance::High_6800Ohm:
                // Completely undamped: crisp transient attack, fast rise-time
                zDampingAlpha = std::clamp(2.0f * PI * 90000.0f / sr, 0.01f, 0.99f);
                zHFRatio = 1.08f;
                break;
        }
    }

    float sr = 44100.0f;
    ISAImpedance currentZ = ISAImpedance::ISA110_1400Ohm;
    float zDampingAlpha = 0.5f;
    float zHFRatio = 1.0f;
    float muMetalFlux = 0.0f;
    float zFilterState = 0.0f;
    float airShelfState = 0.0f;
    DCBlocker dcBlocker;
};

} // namespace dsp171
