#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <dsp171/SerumVMeterEngine.h>
#include <cmath>

namespace studio171
{

/**
 * @brief Boutique VU & MU Meter Component for 171 Studio SerumV.
 * Fits into a 292x168 window (or 584x336 @2x).
 * Supports both continuous needle rotation with dynamic glass reflections
 * and audio-thread continuous ZDF SVF galvanometer ODE synchronization.
 */
class SerumVMeterComponent : public juce::Component, public juce::Timer
{
public:
    SerumVMeterComponent();
    ~SerumVMeterComponent() override;

    // Component lifecycle
    void paint(juce::Graphics& g) override;
    void resized() override;
    void timerCallback() override;

    // Direct synchronization with SerumVMeterEngine from audio thread
    void setPhysicalDeflection(float deflection) noexcept;

    // Standalone meter control API
    void setMeterMode(dsp171::MeterMode mode) noexcept;
    void setHeadroom(float headroomDb) noexcept;
    void updateLevel(float instantaneousLinearLevel) noexcept;
    void updateGainReduction(float reductionDb) noexcept;

    // Manual image assignment (or loads default from BinaryData)
    void setCustomImages(const juce::Image& dial, const juce::Image& needle, const juce::Image& glass);

    // Helpers
    float getSmoothedAngleDeg() const noexcept { return smoothedAngleDeg; }

private:
    float deflectionToAngleDeg(float deflection) const noexcept;
    float gainReductionToAngleDeg(float grDb) const noexcept;

    void loadBinaryDataAssets();

    // Cached image assets
    juce::Image dialFaceImage;
    juce::Image needleImage;
    juce::Image glassReflectionImage;

    // Ballistics & state
    dsp171::MeterMode currentMode = dsp171::MeterMode::Input;
    float currentHeadroomDb = 18.0f;
    float currentDeflection = 0.0f;
    float targetAngleDeg = -36.0f;
    float smoothedAngleDeg = -36.0f;
    bool hasDirectDeflection = false;

    // Internal fallback ballistics when not driven by SerumVMeterEngine
    float ballisticsPos = 0.0f;
    float ballisticsVel = 0.0f;

    static constexpr float kPivotXNorm = 146.0f / 292.0f; // 0.50
    static constexpr float kPivotYNorm = 214.0f / 168.0f; // 1.2738 (46px below visible dial)

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SerumVMeterComponent)
};

} // namespace studio171
