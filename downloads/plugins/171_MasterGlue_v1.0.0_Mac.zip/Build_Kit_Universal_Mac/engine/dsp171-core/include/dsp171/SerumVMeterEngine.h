#pragma once

#include <cmath>
#include <algorithm>
#include <array>
#include <cstdint>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// SerumV Meter Engine - Operating Modes & Channel Modes
// =============================================================================
enum class MeterMode : uint8_t {
    Input = 0,        // Monitors input signal
    Output,           // Monitors output signal post-trim (+/- 18 dB)
    GainReduction     // Monitors dynamic attenuation (0 dB rest, deflecting left to -20 dB)
};

enum class ChannelMode : uint8_t {
    Stereo = 0,       // Needle 0 = Left, Needle 1 = Right
    MonoSum,          // Needle 0 & 1 = (L + R) * 0.5 (-6 dB mono sum)
    MidSide           // Needle 0 = Mid (L + R)*0.5, Needle 1 = Side (L - R)*0.5
};

// =============================================================================
// TruePeakDetector: 4x Oversampling Polyphase Sinc Filter (ITU-R BS.1770-4)
// Accurately reconstructs inter-sample peaks (ISP) with zero allocations.
// =============================================================================
class TruePeakDetector {
public:
    void reset() noexcept {
        m_delayBuffer.fill(0.0f);
        m_writeIdx = 0;
    }

    // Process a single sample and return the reconstructed true-peak magnitude
    inline float processSample(float inSample) noexcept {
        // Sanitize incoming sample against NaN and Inf
        if (!std::isfinite(inSample)) {
            inSample = 0.0f;
        }

        m_delayBuffer[m_writeIdx] = inSample;

        // Extract ordered 8 most recent samples in circular buffer
        std::array<float, 8> x{};
        for (size_t k = 0; k < 8; ++k) {
            const size_t rIdx = (m_writeIdx + 8 - k) & 7;
            x[k] = m_delayBuffer[rIdx];
        }
        m_writeIdx = (m_writeIdx + 1) & 7;

        // 4x polyphase sinc filter coefficients with Kaiser window (beta = 7.0)
        constexpr std::array<float, 8> p0 = { -0.00018644f,  0.00521061f, -0.02906569f,  0.11777836f,  0.97115730f, -0.08195030f,  0.02000363f, -0.00294746f };
        constexpr std::array<float, 8> p1 = { -0.00155133f,  0.02068537f, -0.09984114f,  0.43225564f,  0.76068446f, -0.14046621f,  0.03224937f, -0.00362388f };
        constexpr std::array<float, 8> p2 = { -0.00362388f,  0.03224937f, -0.14046621f,  0.76068446f,  0.43225564f, -0.09984114f,  0.02068537f, -0.00155133f };
        constexpr std::array<float, 8> p3 = { -0.00294746f,  0.02000363f, -0.08195030f,  0.97115730f,  0.11777836f, -0.02906569f,  0.00521061f, -0.00018644f };

        float s0 = 0.0f, s1 = 0.0f, s2 = 0.0f, s3 = 0.0f;
        for (size_t k = 0; k < 8; ++k) {
            s0 += x[k] * p0[k];
            s1 += x[k] * p1[k];
            s2 += x[k] * p2[k];
            s3 += x[k] * p3[k];
        }

        const float inAbs = std::abs(inSample);
        return std::max({ std::abs(s0), std::abs(s1), std::abs(s2), std::abs(s3), inAbs });
    }

private:
    std::array<float, 8> m_delayBuffer{ 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
    size_t m_writeIdx = 0;
};

// =============================================================================
// GalvanometerMovement: Discretized 2nd-Order Continuous Physical Ballistics
// Models moving-coil galvanometer conforming to ANSI C16.5-1954 & IEC 60268-17:
//   m * d2x/dt2 + c * dx/dt + k * x = F(t)
// Discretized via Zero-Delay Feedback (ZDF) SVF integrator for unconditional
// numerical stability, denormal immunity, and exact frequency response.
// =============================================================================
class GalvanometerMovement {
public:
    // Physical mechanical limits
    static constexpr float REST_POSITION_VU = 0.0f;     // Rest stop at silence (0 deflection)
    static constexpr float REST_POSITION_GR = 1.0f;     // Rest stop at 0 dB GR (100% deflection / 0 dB mark)
    static constexpr float MAX_DEFLECTION   = 2.5f;     // Hard physical stop bumper (+8 dBVU)

    void reset(float initialPosition = 0.0f) noexcept {
        m_s1 = 0.0f;
        m_s2 = initialPosition;
        m_position = initialPosition;
        m_velocity = 0.0f;
    }

    // Step continuous ODE forward by one discrete audio sample
    inline float step(float drive, float g, float k_damp, float denom, bool isGainReductionMode) noexcept {
        // Denormal flushing
        if (std::abs(m_s1) < DENORMAL_EPSILON) m_s1 = 0.0f;
        if (std::abs(m_s2) < DENORMAL_EPSILON) m_s2 = 0.0f;

        // ZDF SVF trapezoidal state integration
        const float hp = (drive - k_damp * m_s1 - m_s2) * denom;
        const float bp = g * hp + m_s1;
        m_s1 = bp + g * hp;
        const float lp = g * bp + m_s2;
        m_s2 = lp + g * bp;

        float pos = lp;
        float vel = bp;

        // Physical mechanical stops
        if (isGainReductionMode) {
            // In GR mode: 0 dB is at 1.0 (right). Attenuation moves towards 0.0 (left).
            // Mechanical rest stop on right allows slight analog release overshoot up to 1.15 (+1.2 dB)
            if (pos < 0.0f) {
                pos = 0.0f;
                vel = 0.0f;
                m_s1 = 0.0f;
                m_s2 = 0.0f;
            } else if (pos > MAX_DEFLECTION) {
                pos = MAX_DEFLECTION;
                vel = 0.0f;
                m_s1 = 0.0f;
                m_s2 = MAX_DEFLECTION;
            }
        } else {
            // In VU mode: 0.0 is rest stop pin on left.
            if (pos < REST_POSITION_VU) {
                pos = REST_POSITION_VU;
                vel = 0.0f;
                m_s1 = 0.0f;
                m_s2 = REST_POSITION_VU;
            } else if (pos > MAX_DEFLECTION) {
                pos = MAX_DEFLECTION;
                vel = 0.0f;
                m_s1 = 0.0f;
                m_s2 = MAX_DEFLECTION;
            }
        }

        m_position = pos;
        m_velocity = vel;
        return m_position;
    }

    float getPosition() const noexcept { return m_position; }
    float getVelocity() const noexcept { return m_velocity; }

    void setPosition(float pos) noexcept {
        m_position = pos;
        m_s2 = pos;
        m_velocity = 0.0f;
        m_s1 = 0.0f;
    }

private:
    float m_s1 = 0.0f;        // Internal ZDF bandpass/velocity state
    float m_s2 = 0.0f;        // Internal ZDF lowpass/displacement state
    float m_position = 0.0f;  // Instantaneous pointer deflection
    float m_velocity = 0.0f;  // Instantaneous pointer angular velocity
};

// =============================================================================
// SerumVMeterEngine: Boutique Precision Analog VU & MU Meter Engine
// Fully compliant with ANSI C16.5-1954 and IEC 60268-17 standards.
// Hard real-time audio thread safety: noexcept, zero allocations, denormal-safe.
// =============================================================================
class SerumVMeterEngine {
public:
    // Standard Constants & Calibration Parameters
    static constexpr float DEFAULT_HEADROOM_DB    = 18.0f;   // -18 dBFS = 0 VU
    static constexpr float MIN_HEADROOM_DB        = 4.0f;
    static constexpr float MAX_HEADROOM_DB        = 26.0f;

    static constexpr float MIN_OUTPUT_TRIM_DB     = -18.0f;
    static constexpr float MAX_OUTPUT_TRIM_DB     = 18.0f;

    // True Peak & Clip Threshold: -0.01 dBFS
    static constexpr float CLIP_THRESHOLD_DB      = -0.01f;
    static constexpr float CLIP_THRESHOLD_LINEAR  = 0.9988493699365053f; // 10^(-0.01/20)

    static constexpr float PEAK_HOLD_TIME_SEC     = 1.5f;    // 1.5 s clip/peak hold

    // Optimal ANSI C16.5-1954 / IEC 60268-17 Galvanometer Ballistics:
    // Reaches 99% in exactly 300 ms with overshoot calibrated between 1.0% and 1.5%.
    static constexpr float DEFAULT_ZETA           = 0.816f;  // Damping ratio (~1.18% overshoot)
    static constexpr float DEFAULT_OMEGA_N        = 13.63f;  // Natural resonance frequency in rad/s

    SerumVMeterEngine() noexcept {
        prepare(48000.0);
    }

    ~SerumVMeterEngine() noexcept = default;

    // Hard Real-Time Lifecycle
    void prepare(double sampleRate, int maxBlockSize = 512) noexcept {
        (void)maxBlockSize;
        m_sampleRate = (sampleRate > 1000.0) ? static_cast<float>(sampleRate) : 48000.0f;
        m_invSampleRate = 1.0f / m_sampleRate;
        m_holdDurationSamples = static_cast<uint32_t>(PEAK_HOLD_TIME_SEC * m_sampleRate);

        // Dynamic envelope follower coefficient for input/output delta (~10 ms)
        m_alphaEnv = 1.0f - std::exp(-1.0f / (0.010f * m_sampleRate));

        updateBallisticsCoefficients();
        updateHeadroomScale();
        updateTrimGain();
        reset();
    }

    void reset() noexcept {
        const float initPos = (m_meterMode == MeterMode::GainReduction)
            ? GalvanometerMovement::REST_POSITION_GR
            : GalvanometerMovement::REST_POSITION_VU;

        for (size_t ch = 0; ch < 2; ++ch) {
            m_needle[ch].reset(initPos);
            m_truePeakDetector[ch].reset();
            m_instantTruePeak[ch] = 0.0f;
            m_peakHoldValue[ch] = 0.0f;
            m_peakHoldTimer[ch] = 0;
            m_clipLedActive[ch] = false;
            m_clipTimer[ch] = 0;
            m_envIn[ch] = 0.0f;
            m_envOut[ch] = 0.0f;
        }
        m_dedicatedGrLinear[0] = 1.0f;
        m_dedicatedGrLinear[1] = 1.0f;
    }

    // -------------------------------------------------------------------------
    // Configuration & Calibration Setters / Getters
    // -------------------------------------------------------------------------
    void setHeadroom(float headroomDb) noexcept {
        m_headroomDb = std::clamp(headroomDb, MIN_HEADROOM_DB, MAX_HEADROOM_DB);
        updateHeadroomScale();
    }

    float getHeadroom() const noexcept {
        return m_headroomDb;
    }

    void setOutputTrim(float trimDb) noexcept {
        m_outputTrimDb = std::clamp(trimDb, MIN_OUTPUT_TRIM_DB, MAX_OUTPUT_TRIM_DB);
        updateTrimGain();
    }

    float getOutputTrim() const noexcept {
        return m_outputTrimDb;
    }

    void setMeterMode(MeterMode mode) noexcept {
        if (m_meterMode != mode) {
            m_meterMode = mode;
            // Re-align needle rest states when switching to/from Gain Reduction
            const float targetRest = (m_meterMode == MeterMode::GainReduction)
                ? GalvanometerMovement::REST_POSITION_GR
                : GalvanometerMovement::REST_POSITION_VU;
            for (size_t ch = 0; ch < 2; ++ch) {
                m_needle[ch].reset(targetRest);
            }
        }
    }

    MeterMode getMeterMode() const noexcept {
        return m_meterMode;
    }

    void setChannelMode(ChannelMode mode) noexcept {
        m_channelMode = mode;
    }

    ChannelMode getChannelMode() const noexcept {
        return m_channelMode;
    }

    void setBallistics(float zeta, float omega_n) noexcept {
        m_zeta = std::clamp(zeta, 0.5f, 1.2f);
        m_omegaN = std::clamp(omega_n, 5.0f, 40.0f);
        updateBallisticsCoefficients();
    }

    float getZeta() const noexcept { return m_zeta; }
    float getOmegaN() const noexcept { return m_omegaN; }

    // Dedicated Gain Reduction
    void setDedicatedGainReduction(float grDbL, float grDbR) noexcept {
        // grDb is <= 0 dB (e.g. -6 dB -> 0.501)
        m_dedicatedGrLinear[0] = std::clamp(std::pow(10.0f, grDbL * 0.05f), 0.0f, 1.5f);
        m_dedicatedGrLinear[1] = std::clamp(std::pow(10.0f, grDbR * 0.05f), 0.0f, 1.5f);
        m_useDedicatedGR = true;
    }

    void setDedicatedGainReductionLinear(float grL, float grR) noexcept {
        m_dedicatedGrLinear[0] = std::clamp(grL, 0.0f, 1.5f);
        m_dedicatedGrLinear[1] = std::clamp(grR, 0.0f, 1.5f);
        m_useDedicatedGR = true;
    }

    void enableDedicatedGainReduction(bool enable) noexcept {
        m_useDedicatedGR = enable;
    }

    bool isDedicatedGainReductionEnabled() const noexcept {
        return m_useDedicatedGR;
    }

    // -------------------------------------------------------------------------
    // Audio Processing Methods (Hard Real-Time, noexcept, zero allocations)
    // -------------------------------------------------------------------------

    // Standard block processor for FX inserts / master bus
    void processBlock(const float* const* inputs, float* const* outputs, int numChannels, int numSamples) noexcept {
        if (numSamples <= 0) return;

        m_instantTruePeak[0] = 0.0f;
        m_instantTruePeak[1] = 0.0f;

        const float* inL = (inputs && numChannels > 0 && inputs[0]) ? inputs[0] : nullptr;
        const float* inR = (inputs && numChannels > 1 && inputs[1]) ? inputs[1] : inL;

        float* outL = (outputs && numChannels > 0 && outputs[0]) ? outputs[0] : nullptr;
        float* outR = (outputs && numChannels > 1 && outputs[1]) ? outputs[1] : outL;

        const bool hasDistinctOutputs = (outputs != nullptr && outL != nullptr && inputs != outputs && inL != outL);

        for (int i = 0; i < numSamples; ++i) {
            float rawInL = inL ? inL[i] : 0.0f;
            float rawInR = inR ? inR[i] : 0.0f;

            if (!std::isfinite(rawInL)) rawInL = 0.0f;
            if (!std::isfinite(rawInR)) rawInR = 0.0f;

            float rawOutL = 0.0f;
            float rawOutR = 0.0f;

            if (hasDistinctOutputs) {
                // Host provided external processed output
                rawOutL = outL[i];
                rawOutR = outR ? outR[i] : rawOutL;
                if (!std::isfinite(rawOutL)) rawOutL = 0.0f;
                if (!std::isfinite(rawOutR)) rawOutR = 0.0f;
            } else {
                // Apply internal analog output trim
                rawOutL = rawInL * m_trimGain;
                rawOutR = rawInR * m_trimGain;
                if (outL) outL[i] = rawOutL;
                if (outR) outR[i] = rawOutR;
            }

            processSampleInternal(rawInL, rawInR, rawOutL, rawOutR);
        }
    }

    // Convenience process for input monitoring
    void process(const float* inL, const float* inR, int numSamples) noexcept {
        if (numSamples <= 0) return;
        m_instantTruePeak[0] = 0.0f;
        m_instantTruePeak[1] = 0.0f;
        const float* rPtr = inR ? inR : inL;
        for (int i = 0; i < numSamples; ++i) {
            const float sL = inL ? inL[i] : 0.0f;
            const float sR = rPtr ? rPtr[i] : 0.0f;
            processSampleInternal(sL, sR, sL * m_trimGain, sR * m_trimGain);
        }
    }

    // Convenience process for side-by-side input and output monitoring
    void process(const float* inL, const float* inR, const float* outL, const float* outR, int numSamples) noexcept {
        if (numSamples <= 0) return;
        m_instantTruePeak[0] = 0.0f;
        m_instantTruePeak[1] = 0.0f;
        const float* inRPtr  = inR  ? inR  : inL;
        const float* outRPtr = outR ? outR : outL;
        for (int i = 0; i < numSamples; ++i) {
            const float sInL  = inL     ? inL[i]     : 0.0f;
            const float sInR  = inRPtr  ? inRPtr[i]  : 0.0f;
            const float sOutL = outL    ? outL[i]    : sInL;
            const float sOutR = outRPtr ? outRPtr[i] : sInR;
            processSampleInternal(sInL, sInR, sOutL, sOutR);
        }
    }

    // Single sample processor
    inline void processSample(float inL, float inR, float outL = 0.0f, float outR = 0.0f) noexcept {
        if (!std::isfinite(inL)) inL = 0.0f;
        if (!std::isfinite(inR)) inR = 0.0f;
        if (!std::isfinite(outL)) outL = inL * m_trimGain;
        if (!std::isfinite(outR)) outR = inR * m_trimGain;
        processSampleInternal(inL, inR, outL, outR);
    }

    // -------------------------------------------------------------------------
    // Needle Readouts
    // -------------------------------------------------------------------------
    // Linear deflection: 0.0 = rest pin, 1.0 = 0 VU / 0 dB GR, 1.412 = +3 VU
    float getNeedleDeflection(int channel) const noexcept {
        const int ch = (channel == 1) ? 1 : 0;
        return m_needle[ch].getPosition();
    }

    // Needle reading in dB:
    // In VU mode: 20*log10(deflection) where 1.0 = 0.0 VU, 1.412 = +3.0 VU
    // In GR mode: 20*log10(deflection) where 1.0 = 0.0 dB, 0.5 = -6.02 dB, 0.1 = -20.0 dB
    float getNeedleDb(int channel) const noexcept {
        const int ch = (channel == 1) ? 1 : 0;
        const float def = m_needle[ch].getPosition();
        if (def <= 0.0001f) {
            return -80.0f;
        }
        return 20.0f * std::log10(def);
    }

    float getNeedleVelocity(int channel) const noexcept {
        const int ch = (channel == 1) ? 1 : 0;
        return m_needle[ch].getVelocity();
    }

    // -------------------------------------------------------------------------
    // True Peak Readouts & Clip LED
    // -------------------------------------------------------------------------
    float getTruePeakLinear(int channel) const noexcept {
        const int ch = (channel == 1) ? 1 : 0;
        return m_instantTruePeak[ch];
    }

    float getTruePeakDb(int channel) const noexcept {
        const int ch = (channel == 1) ? 1 : 0;
        return gainToDb(m_instantTruePeak[ch]);
    }

    float getTruePeakHoldLinear(int channel) const noexcept {
        const int ch = (channel == 1) ? 1 : 0;
        return m_peakHoldValue[ch];
    }

    float getTruePeakHoldDb(int channel) const noexcept {
        const int ch = (channel == 1) ? 1 : 0;
        return gainToDb(m_peakHoldValue[ch]);
    }

    bool isClipLedActive(int channel) const noexcept {
        const int ch = (channel == 1) ? 1 : 0;
        return m_clipLedActive[ch];
    }

    // Click-to-reset: resets clip LED and peak hold for channel (-1 for both channels)
    void resetClip(int channel = -1) noexcept {
        if (channel < 0 || channel > 1) {
            m_clipLedActive[0] = false;
            m_clipLedActive[1] = false;
            m_clipTimer[0] = 0;
            m_clipTimer[1] = 0;
            m_peakHoldValue[0] = 0.0f;
            m_peakHoldValue[1] = 0.0f;
            m_peakHoldTimer[0] = 0;
            m_peakHoldTimer[1] = 0;
        } else {
            m_clipLedActive[channel] = false;
            m_clipTimer[channel] = 0;
            m_peakHoldValue[channel] = 0.0f;
            m_peakHoldTimer[channel] = 0;
        }
    }

private:
    inline void processSampleInternal(float inL, float inR, float outL, float outR) noexcept {
        // 1. Channel Routing Matrix for Input and Output signals
        float routedIn0 = inL;
        float routedIn1 = inR;
        float routedOut0 = outL;
        float routedOut1 = outR;

        switch (m_channelMode) {
            case ChannelMode::Stereo:
                // Left / Right direct
                break;

            case ChannelMode::MonoSum:
                // Mono Sum: (L + R) * 0.5 (-6 dB sum)
                routedIn0  = (inL + inR) * 0.5f;
                routedIn1  = routedIn0;
                routedOut0 = (outL + outR) * 0.5f;
                routedOut1 = routedOut0;
                break;

            case ChannelMode::MidSide:
                // Mid = (L + R) * 0.5, Side = (L - R) * 0.5
                routedIn0  = (inL + inR) * 0.5f;
                routedIn1  = (inL - inR) * 0.5f;
                routedOut0 = (outL + outR) * 0.5f;
                routedOut1 = (outL - outR) * 0.5f;
                break;
        }

        // 2. Select Monitored Signal based on Meter Mode
        float sig0 = routedIn0;
        float sig1 = routedIn1;

        if (m_meterMode == MeterMode::Output) {
            sig0 = routedOut0;
            sig1 = routedOut1;
        }

        // 3. True Peak Sub-Sample Detection & Clip LED Logic
        const float tp0 = m_truePeakDetector[0].processSample(sig0);
        const float tp1 = m_truePeakDetector[1].processSample(sig1);

        m_instantTruePeak[0] = std::max(m_instantTruePeak[0], tp0);
        m_instantTruePeak[1] = std::max(m_instantTruePeak[1], tp1);

        updateClipAndPeakHold(0, tp0);
        updateClipAndPeakHold(1, tp1);

        // 4. Calculate Driving Term for Galvanometer Needles
        float drive0 = 0.0f;
        float drive1 = 0.0f;

        const bool isGRMode = (m_meterMode == MeterMode::GainReduction);

        if (isGRMode) {
            if (m_useDedicatedGR) {
                // Use dedicated gain reduction directly
                drive0 = m_dedicatedGrLinear[0];
                drive1 = m_dedicatedGrLinear[1];
            } else {
                // Calculate dynamic gain delta from input and output envelopes
                m_envIn[0]  += m_alphaEnv * (std::abs(routedIn0)  - m_envIn[0]);
                m_envIn[1]  += m_alphaEnv * (std::abs(routedIn1)  - m_envIn[1]);
                m_envOut[0] += m_alphaEnv * (std::abs(routedOut0) - m_envOut[0]);
                m_envOut[1] += m_alphaEnv * (std::abs(routedOut1) - m_envOut[1]);

                // When signal is present (> -60 dBFS = 0.001), compute ratio out/in
                constexpr float SILENCE_THRESHOLD = 0.001f;
                drive0 = (m_envIn[0] > SILENCE_THRESHOLD)
                    ? std::clamp(m_envOut[0] / m_envIn[0], 0.0f, 1.0f)
                    : 1.0f; // 0 dB GR at silence

                drive1 = (m_envIn[1] > SILENCE_THRESHOLD)
                    ? std::clamp(m_envOut[1] / m_envIn[1], 0.0f, 1.0f)
                    : 1.0f;
            }
        } else {
            // Full-wave rectification scaled to meter calibration
            // u(t) = |v(t)| * (pi / 2) * 10^(Headroom / 20)
            drive0 = std::abs(sig0) * m_headroomScale;
            drive1 = std::abs(sig1) * m_headroomScale;
        }

        // 5. Physical Galvanometer Ballistic Update
        m_needle[0].step(drive0, m_zdfG, m_zdfK, m_zdfDenom, isGRMode);
        m_needle[1].step(drive1, m_zdfG, m_zdfK, m_zdfDenom, isGRMode);
    }

    inline void updateClipAndPeakHold(int ch, float tp) noexcept {
        // Clip LED Trigger and Hold (1.5 s)
        if (tp >= CLIP_THRESHOLD_LINEAR) {
            m_clipLedActive[ch] = true;
            m_clipTimer[ch] = m_holdDurationSamples;
        } else if (m_clipTimer[ch] > 0) {
            --m_clipTimer[ch];
            if (m_clipTimer[ch] == 0) {
                m_clipLedActive[ch] = false;
            }
        }

        // Peak Hold Logic (1.5 s hold time)
        if (tp >= m_peakHoldValue[ch]) {
            m_peakHoldValue[ch] = tp;
            m_peakHoldTimer[ch] = m_holdDurationSamples;
        } else if (m_peakHoldTimer[ch] > 0) {
            --m_peakHoldTimer[ch];
            if (m_peakHoldTimer[ch] == 0) {
                // Decay peak hold towards current instant peak
                m_peakHoldValue[ch] = tp;
            }
        }
    }

    void updateBallisticsCoefficients() noexcept {
        // ZDF SVF trapezoidal integrator coefficients
        // g = tan(omega_n / (2 * fs))
        m_zdfG = std::tan(m_omegaN * 0.5f * m_invSampleRate);
        m_zdfK = 2.0f * m_zeta;
        m_zdfDenom = 1.0f / (1.0f + m_zdfG * (m_zdfG + m_zdfK));
    }

    void updateHeadroomScale() noexcept {
        // Average of |sin(t)| is 2 / pi. To make sine of peak 10^(-Headroom/20)
        // produce steady-state deflection 1.0 (0 VU), scale factor is:
        // (pi / 2) * 10^(Headroom / 20).
        m_headroomScale = (PI * 0.5f) * std::pow(10.0f, m_headroomDb * 0.05f);
    }

    void updateTrimGain() noexcept {
        m_trimGain = std::pow(10.0f, m_outputTrimDb * 0.05f);
    }

    // Engine parameters
    float m_sampleRate = 48000.0f;
    float m_invSampleRate = 1.0f / 48000.0f;
    uint32_t m_holdDurationSamples = 72000;

    float m_headroomDb = DEFAULT_HEADROOM_DB;
    float m_headroomScale = 1.0f;
    float m_outputTrimDb = 0.0f;
    float m_trimGain = 1.0f;

    MeterMode m_meterMode = MeterMode::Input;
    ChannelMode m_channelMode = ChannelMode::Stereo;

    // Galvanometer Ballistics Parameters
    float m_zeta = DEFAULT_ZETA;
    float m_omegaN = DEFAULT_OMEGA_N;
    float m_zdfG = 0.0f;
    float m_zdfK = 0.0f;
    float m_zdfDenom = 1.0f;

    // Dedicated Gain Reduction
    bool m_useDedicatedGR = false;
    std::array<float, 2> m_dedicatedGrLinear{ 1.0f, 1.0f };

    // Dynamic Delta Envelopes
    float m_alphaEnv = 0.01f;
    std::array<float, 2> m_envIn{ 0.0f, 0.0f };
    std::array<float, 2> m_envOut{ 0.0f, 0.0f };

    // Galvanometer Movements (Ch 0, Ch 1)
    std::array<GalvanometerMovement, 2> m_needle{};

    // True Peak Detectors (Ch 0, Ch 1)
    std::array<TruePeakDetector, 2> m_truePeakDetector{};
    std::array<float, 2> m_instantTruePeak{ 0.0f, 0.0f };

    // Clip & Peak Hold states
    std::array<bool, 2> m_clipLedActive{ false, false };
    std::array<uint32_t, 2> m_clipTimer{ 0, 0 };
    std::array<float, 2> m_peakHoldValue{ 0.0f, 0.0f };
    std::array<uint32_t, 2> m_peakHoldTimer{ 0, 0 };
};

} // namespace dsp171
