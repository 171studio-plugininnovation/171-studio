#pragma once
#include <cmath>
#include <array>
#include <algorithm>
#include <cstdint>
#include <numbers>
#include <span>
#include "Common.h"

namespace dsp171 {

// =============================================================================
// Modalita' di risintesi vocale Antares Auto-Tune Pro
// =============================================================================
enum class LPCResynthesisMode : uint8_t {
    Classic = 0,  // Auto-Tune 5: snap istantaneo sui confini delle epoche glottiche, azzeramento ciclico
    Modern = 1    // Auto-Tune Pro: allineamento continuo con Perlin Smootherstep e conservazione continua
};

// =============================================================================
// LPCFrameData
// Dati spettrali ricavati dall'analisi del tratto vocale
// =============================================================================
template <size_t MaxOrder = 24>
struct LPCFrameData {
    std::array<float, MaxOrder + 1> a{};        // Coefficienti predittivi A(z) = 1 + sum(a_k * z^-k)
    std::array<float, MaxOrder + 1> k{};        // Coefficienti di riflessione PARCOR kappa_i (-1..+1)
    std::array<float, MaxOrder + 1> lambdaPowers{}; // Potenze precalcolate (-lambda)^k
    float gain = 0.0f;                          // Guadagno del residuo G = sqrt(E)
    float throatLengthPercent = 100.0f;         // Lunghezza del tratto vocale (50% .. 150%)
    float lambda = 0.0f;                        // Parametro conforme allpass lambda = (1-alpha)/(1+alpha)
    float loopDenominator = 1.0f;               // Denominatore ZDF precalcolato 1 + sum(a_k * (-lambda)^k)
    size_t order = 20;                          // Ordine effettivo
    bool isVoiced = false;
};

// =============================================================================
// LPCVocalTract
// Motore di Modellazione del Tratto Vocale LPC (Linear Predictive Coding)
// conforme all'architettura originale Antares Auto-Tune Pro:
//
// 1. Analisi LPC tramite Autocorrelazione e Ricorsione di Levinson-Durbin (p = 16..24).
// 2. Deconvoluzione del Tratto Vocale: Filtraggio inverso FIR per estrazione
//    del residuo glottico d'eccitazione e[n] = x[n] + sum(a_k * x[n-k]).
// 3. Throat Length (50% .. 150%): Modellazione fisica della lunghezza del tratto
//    vocale tramite trasformazione conforme bilineare Allpass:
//      z^-1 -> (z^-1 - lambda) / (1 - lambda * z^-1)
//      lambda = (1 - alpha) / (1 + alpha), alpha = ThroatLength / 100.
// 4. Risintesi Vocale ZDF Allpass Ladder IIR a circuito chiuso:
//    Ricostruzione ad altissima risoluzione senza effetto chipmunk né effetto troll.
// 5. Classic Mode DSP (Auto-Tune 5): Snap aggressivo sui confini d'epoca glottica.
// 6. Modern Mode DSP: Interpolazione continua con polinomio quintico smootherstep
//    di Perlin e conservazione della stabilita' minima di fase sui riflessi kappa_i.
// 7. Flex-Tune & Humanize:
//    - Flex-Tune: Weight = max(0, 1 - (|cents| / 50) * (Flex / 100))
//    - Humanize: rilassamento dinamico della velocita' oltre i 250 ms di sustain.
// =============================================================================
template <size_t MaxOrder = 24>
class LPCVocalTract {
public:
    static constexpr size_t MAX_ORDER = MaxOrder;
    static constexpr size_t ANALYSIS_WINDOW_SIZE = 512;
    static constexpr size_t ANALYSIS_HOP_SIZE = 128;
    static constexpr size_t BUFFER_MASK = ANALYSIS_WINDOW_SIZE - 1;

    LPCVocalTract() noexcept {
        reset();
    }

    void prepare(double sampleRate, size_t order = 20) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        invSr = 1.0f / sr;
        currentOrder = std::clamp(order, size_t(4), MAX_ORDER);

        // Precalcolo della finestra di Hamming
        for (size_t i = 0; i < ANALYSIS_WINDOW_SIZE; ++i) {
            const float phase = 2.0f * PI * static_cast<float>(i) / static_cast<float>(ANALYSIS_WINDOW_SIZE - 1);
            hammingWindow[i] = 0.54f - 0.46f * std::cos(phase);
        }

        updateThroatLengthParams();
        reset();
    }

    void reset() noexcept {
        analysisRingBuffer.fill(0.0f);
        writeIndex = 0;
        samplesSinceLastHop = 0;

        invFilterMemory.fill(0.0f);
        synthAllpassStates.fill(0.0f);

        prevPreEmphasisSample = 0.0f;
        prevDeEmphasisSample = 0.0f;

        currentFrame = LPCFrameData<MAX_ORDER>{};
        targetFrame = LPCFrameData<MAX_ORDER>{};
        currentFrame.order = currentOrder;
        targetFrame.order = currentOrder;
        currentFrame.loopDenominator = 1.0f;
        targetFrame.loopDenominator = 1.0f;

        transitionPhase = 1.0f;
        phaseIncrement = 1.0f;

        sustainCounterSamples = 0;
        lastCentsOffset = 0.0f;
    }

    // Imposta l'ordine LPC di predizione (16 o 20)
    void setOrder(size_t order) noexcept {
        currentOrder = std::clamp(order, size_t(4), MAX_ORDER);
        currentFrame.order = currentOrder;
        targetFrame.order = currentOrder;
        updateWarpingPowers(currentFrame);
        updateWarpingPowers(targetFrame);
    }

    [[nodiscard]] size_t getOrder() const noexcept { return currentOrder; }

    // Throat Length [50% .. 150%] (Default: 100% = naturale)
    // 50% = tratto vocale accorciato (timbro femminile/infantile)
    // 150% = tratto vocale allungato (timbro cavernoso/maschile profondo)
    void setThroatLength(float percent) noexcept {
        throatLengthPercent = std::clamp(percent, 50.0f, 150.0f);
        updateThroatLengthParams();
    }

    [[nodiscard]] float getThroatLength() const noexcept { return throatLengthPercent; }
    [[nodiscard]] float getLambda() const noexcept { return throatLambda; }

    // Modalita' DSP: Classic (Auto-Tune 5) o Modern (Auto-Tune Pro)
    void setResynthesisMode(LPCResynthesisMode mode) noexcept {
        resynthesisMode = mode;
    }

    [[nodiscard]] LPCResynthesisMode getResynthesisMode() const noexcept { return resynthesisMode; }
    [[nodiscard]] bool isClassicMode() const noexcept { return resynthesisMode == LPCResynthesisMode::Classic; }

    // Flex-Tune [0% .. 100%]: ritira la correzione man mano che la voce devia dal centro nota
    void setFlexTune(float flexPercent) noexcept {
        flexTune = std::clamp(flexPercent, 0.0f, 100.0f);
    }

    [[nodiscard]] float getFlexTune() const noexcept { return flexTune; }

    // Humanize [0% .. 100%]: rilassa il retune sulle note sostenute > 250 ms
    void setHumanize(float humanizePercent) noexcept {
        humanize = std::clamp(humanizePercent, 0.0f, 100.0f);
    }

    [[nodiscard]] float getHumanize() const noexcept { return humanize; }

    // Calcola il fattore di peso Flex-Tune per un dato scostamento in cents:
    // Weight = max(0, 1 - (|cents| / 50) * (Flex / 100))
    [[nodiscard]] inline float calculateFlexTuneWeight(float centsOffset) const noexcept {
        if (flexTune < 0.1f) return 1.0f;
        const float dist = std::abs(centsOffset);
        const float weight = 1.0f - (dist / 50.0f) * (flexTune * 0.01f);
        return std::max(0.0f, weight);
    }

    // Calcola il rilassamento dinamico Humanize in base alla durata del sustain vocale
    [[nodiscard]] inline float calculateHumanizeRelaxation() const noexcept {
        if (humanize < 0.1f) return 0.0f;
        const float sustainSec = static_cast<float>(sustainCounterSamples) * invSr;
        if (sustainSec <= 0.25f) return 0.0f; // Sotto 250 ms: retune rapido pieno
        // Rilassamento progressivo da 250 ms a 750 ms
        const float normSustain = std::min(1.0f, (sustainSec - 0.25f) / 0.50f);
        return normSustain * (humanize * 0.01f);
    }

    // Registra la durata della vocalizzazione per Humanize
    inline void updateVoicingState(bool isVoiced, float centsOffset = 0.0f) noexcept {
        if (isVoiced) {
            sustainCounterSamples++;
            lastCentsOffset = centsOffset;
        } else {
            sustainCounterSamples = 0;
        }
    }

    // --- Deconvoluzione del Tratto Vocale (Inverse FIR Filtering) ---

    // Elabora un campione audio grezzo e restituisce il residuo di eccitazione glottica e[n]
    // e[n] = x[n] + sum_{k=1}^p a_k * x[n-k]
    inline float deconvolveSample(float inputSample) noexcept {
        // Pre-emphasis a 0.95 per bilanciare la pendenza spettrale naturale della voce
        const float preEmphasized = inputSample - 0.95f * prevPreEmphasisSample;
        prevPreEmphasisSample = inputSample;

        // Filtraggio inverso FIR: e = x + sum(a_k * x[n-k])
        float residual = preEmphasized;
        for (size_t k = 1; k <= currentOrder; ++k) {
            residual += currentFrame.a[k] * invFilterMemory[k - 1];
        }

        // Shift della memoria del filtro inverso
        for (size_t k = currentOrder; k > 1; --k) {
            invFilterMemory[k - 1] = invFilterMemory[k - 2];
        }
        invFilterMemory[0] = preEmphasized;

        return residual;
    }

    // --- Risintesi Vocale con Throat Length Conforme Bilineare (Allpass Ladder ZDF) ---

    // Risintetizza un campione vocale a partire dal segnale residuo (eventualmente pitch-shifted)
    // Applicando la trasformazione conforme Allpass z^-1 -> (z^-1 - lambda)/(1 - lambda * z^-1)
    // Risolve il Zero-Delay Feedback in forma chiusa esatta:
    //   y[n] = (e[n] - sum_{k=1}^p a_k * q_k) / D_loop
    inline float synthesizeSample(float residualSample) noexcept {
        const float lambda = currentFrame.lambda;
        const size_t p = currentOrder;

        // 1. Calcolo ricorsivo in avanti di q_k = s_k[n-1] - lambda * q_{k-1}
        std::array<float, MAX_ORDER + 1> q{};
        q[0] = 0.0f;
        for (size_t k = 1; k <= p; ++k) {
            q[k] = synthAllpassStates[k] - lambda * q[k - 1];
        }

        // 2. Accumulo del feedback dello stato: fb = sum(a_k * q_k)
        float stateFeedback = 0.0f;
        for (size_t k = 1; k <= p; ++k) {
            stateFeedback += currentFrame.a[k] * q[k];
        }

        // 3. Risoluzione algebrica esatta del campione di sintesi y[n]
        const float dLoop = currentFrame.loopDenominator;
        const float safeDLoop = (std::abs(dLoop) > 1e-6f) ? dLoop : 1.0f;
        const float y = (residualSample - stateFeedback) / safeDLoop;

        // 4. Aggiornamento in avanti degli stati della catena passa-tutto:
        //    v_k[n] = (-lambda)^k * y[n] + q_k
        //    s_k[n] = v_{k-1}[n] + lambda * v_k[n]  (con v_0[n] = y[n])
        float prevV = y;
        for (size_t k = 1; k <= p; ++k) {
            const float v_k = currentFrame.lambdaPowers[k] * y + q[k];
            synthAllpassStates[k] = prevV + lambda * v_k;
            prevV = v_k;
        }

        // 5. De-emphasis integratore del 1° ordine: y_out = y + 0.95 * y_out[n-1]
        const float deEmphasized = y + 0.95f * prevDeEmphasisSample;
        prevDeEmphasisSample = (std::abs(deEmphasized) < 1e-15f) ? 0.0f : deEmphasized;

        return deEmphasized;
    }

    // Notifica un'epoca glottica (GCI) per il Classic Mode DSP (Auto-Tune 5):
    // Preserva rigorosamente la continuita' fisica degli stati passa-tutto ZDF senza alterazioni impulsive
    inline void triggerGlottalEpochSnap() noexcept {
        // Safe no-op: mai scalare synthAllpassStates per eliminare alla radice click e glitch
    }

    // --- Analisi Vocale a Finestra Mobile (Zero Allocazioni) ---

    // Inserisce un campione nel buffer circolare di analisi.
    // Restituisce true se un nuovo frame di predizione lineare e' stato calcolato.
    inline bool pushSampleForAnalysis(float sample, bool isVoiced) noexcept {
        analysisRingBuffer[writeIndex] = sample;
        writeIndex = (writeIndex + 1) & BUFFER_MASK;

        samplesSinceLastHop++;
        if (samplesSinceLastHop >= ANALYSIS_HOP_SIZE) {
            samplesSinceLastHop = 0;
            computeLPCFrame(isVoiced);
            return true;
        }

        // Interpola gradualmente i coefficienti tra hop con smootherstep quintico per eliminare click impulsivi
        if (transitionPhase < 1.0f) {
            interpolateFrameModern();
        }

        return false;
    }

    // Analizza direttamente un blocco lineare di campioni
    void analyzeBlock(const float* samples, size_t count, bool isVoiced) noexcept {
        if (samples == nullptr || count == 0) return;
        for (size_t i = 0; i < count; ++i) {
            pushSampleForAnalysis(samples[i], isVoiced);
        }
    }

    // --- Accessori e Telemetria ---

    [[nodiscard]] const LPCFrameData<MAX_ORDER>& getCurrentFrame() const noexcept { return currentFrame; }
    [[nodiscard]] const LPCFrameData<MAX_ORDER>& getTargetFrame() const noexcept { return targetFrame; }
    [[nodiscard]] float getResidualGain() const noexcept { return currentFrame.gain; }

    // Coefficienti predittivi correnti A(z)
    [[nodiscard]] std::span<const float> getPredictorCoefficients() const noexcept {
        return std::span<const float>(currentFrame.a.data(), currentOrder + 1);
    }

    // Coefficienti di riflessione correnti kappa_i
    [[nodiscard]] std::span<const float> getReflectionCoefficients() const noexcept {
        return std::span<const float>(currentFrame.k.data(), currentOrder + 1);
    }

private:
    void updateThroatLengthParams() noexcept {
        const float alpha = throatLengthPercent * 0.01f;
        // Trasformazione conforme bilineare: lambda = (alpha - 1.0f) / (alpha + 1.0f)
        // Conforme al modello acustico Webster: L > L0 (alpha > 1) -> lambda > 0 (compressione HF, formanti abbassate)
        throatLambda = (alpha - 1.0f) / (alpha + 1.0f);
        currentFrame.throatLengthPercent = throatLengthPercent;
        currentFrame.lambda = throatLambda;
        targetFrame.throatLengthPercent = throatLengthPercent;
        targetFrame.lambda = throatLambda;

        updateWarpingPowers(currentFrame);
        updateWarpingPowers(targetFrame);
    }

    void updateWarpingPowers(LPCFrameData<MAX_ORDER>& frame) noexcept {
        const float negLambda = -frame.lambda;
        frame.lambdaPowers[0] = 1.0f;
        float powVal = 1.0f;
        for (size_t k = 1; k <= frame.order; ++k) {
            powVal *= negLambda;
            frame.lambdaPowers[k] = powVal;
        }

        // Calcola il denominatore del loop ZDF: 1 + sum_{k=1}^p a_k * (-lambda)^k
        float sum = 1.0f;
        for (size_t k = 1; k <= frame.order; ++k) {
            sum += frame.a[k] * frame.lambdaPowers[k];
        }
        frame.loopDenominator = sum;
    }

    // Calcolo completo dell'analisi LPC: Autocorrelazione + Levinson-Durbin
    void computeLPCFrame(bool isVoiced) noexcept {
        std::array<float, ANALYSIS_WINDOW_SIZE> windowed{};
        const size_t startIdx = (writeIndex + ANALYSIS_WINDOW_SIZE) & BUFFER_MASK;

        // Estrazione e finestraggio con Hamming
        float prevS = analysisRingBuffer[startIdx];
        for (size_t i = 0; i < ANALYSIS_WINDOW_SIZE; ++i) {
            const size_t idx = (startIdx + i) & BUFFER_MASK;
            const float s = analysisRingBuffer[idx];
            // Pre-emphasis prima dell'autocorrelazione
            const float pe = s - 0.95f * prevS;
            prevS = s;
            windowed[i] = pe * hammingWindow[i];
        }

        // 1. Calcolo dei coefficienti di autocorrelazione R[0 .. currentOrder]
        std::array<float, MAX_ORDER + 1> R{};
        for (size_t k = 0; k <= currentOrder; ++k) {
            float sum = 0.0f;
            for (size_t i = 0; i < ANALYSIS_WINDOW_SIZE - k; ++i) {
                sum += windowed[i] * windowed[i + k];
            }
            R[k] = sum;
        }

        // Se silenzio o energia trascurabile
        if (R[0] < 1e-9f) {
            targetFrame.a.fill(0.0f);
            targetFrame.k.fill(0.0f);
            targetFrame.gain = 0.0f;
            targetFrame.isVoiced = false;
            targetFrame.loopDenominator = 1.0f;
            if (resynthesisMode == LPCResynthesisMode::Classic) {
                currentFrame = targetFrame;
            }
            return;
        }

        // Regolarizzazione di cresta (White Noise Floor 0.01% per stabilita' assoluta)
        R[0] *= 1.0001f;

        // 2. Ricorsione di Levinson-Durbin (O(p^2) operazioni in virgola mobile)
        std::array<float, MAX_ORDER + 1> aPrev{};
        std::array<float, MAX_ORDER + 1> aCur{};
        std::array<float, MAX_ORDER + 1> kCoeffs{};

        float E = R[0];

        for (size_t i = 1; i <= currentOrder; ++i) {
            float sum = 0.0f;
            for (size_t j = 1; j < i; ++j) {
                sum += aPrev[j] * R[i - j];
            }

            // Calcolo coefficiente di riflessione PARCOR kappa_i
            float ki = -(R[i] + sum) / (E + 1e-12f);

            // Clamp di stabilita' rigorosa (strettamente all'interno del cerchio unitario)
            ki = std::clamp(ki, -0.9995f, 0.9995f);
            kCoeffs[i] = ki;
            aCur[i] = ki;

            for (size_t j = 1; j < i; ++j) {
                aCur[j] = aPrev[j] + ki * aPrev[i - j];
            }

            // Aggiornamento dell'energia dell'errore di predizione
            E *= (1.0f - ki * ki);
            if (E < 1e-12f) E = 1e-12f;

            aPrev = aCur;
        }

        // 3. Espansione di banda (Bandwidth Expansion a gamma = 0.994)
        // Sposta i poli del tratto vocale verso l'interno di 15-20 Hz per eliminare picchi risonanti taglienti
        float gammaPow = 0.994f;
        for (size_t i = 1; i <= currentOrder; ++i) {
            aCur[i] *= gammaPow;
            gammaPow *= 0.994f;
        }

        // Memorizza il risultato nel targetFrame
        targetFrame.a = aCur;
        targetFrame.k = kCoeffs;
        targetFrame.gain = std::sqrt(std::max(0.0f, E));
        targetFrame.isVoiced = isVoiced;
        targetFrame.order = currentOrder;
        targetFrame.lambda = throatLambda;
        targetFrame.throatLengthPercent = throatLengthPercent;

        updateWarpingPowers(targetFrame);

        // Transizione continua Smootherstep tra hop di analisi
        transitionPhase = 0.0f;
        phaseIncrement = 1.0f / static_cast<float>(ANALYSIS_HOP_SIZE);
    }

    // Modern Mode: Interpolazione continua con polinomio quintico Smootherstep di Perlin
    // Interpola i coefficienti di riflessione kappa_i per garantire stabilita' minima di fase
    inline void interpolateFrameModern() noexcept {
        transitionPhase += phaseIncrement;
        if (transitionPhase >= 1.0f) {
            transitionPhase = 1.0f;
            currentFrame = targetFrame;
            return;
        }

        // Polinomio quintico di Perlin: S(u) = 6u^5 - 15u^4 + 10u^3
        const float u = transitionPhase;
        const float sCurve = u * u * u * (u * (u * 6.0f - 15.0f) + 10.0f);

        // Interpola reflection coefficients kappa_i (preserva rigorosamente |kappa| < 1)
        std::array<float, MAX_ORDER + 1> interpK{};
        for (size_t i = 1; i <= currentOrder; ++i) {
            interpK[i] = currentFrame.k[i] + sCurve * (targetFrame.k[i] - currentFrame.k[i]);
            interpK[i] = std::clamp(interpK[i], -0.9995f, 0.9995f);
        }

        // Step-up forward algorithm per convertire kappa_i -> a_k interpolati
        std::array<float, MAX_ORDER + 1> aPrev{};
        std::array<float, MAX_ORDER + 1> aCur{};
        for (size_t i = 1; i <= currentOrder; ++i) {
            const float ki = interpK[i];
            aCur[i] = ki;
            for (size_t j = 1; j < i; ++j) {
                aCur[j] = aPrev[j] + ki * aPrev[i - j];
            }
            aPrev = aCur;
        }

        currentFrame.a = aCur;
        currentFrame.k = interpK;
        currentFrame.gain = currentFrame.gain + sCurve * (targetFrame.gain - currentFrame.gain);
        currentFrame.loopDenominator = currentFrame.loopDenominator + sCurve * (targetFrame.loopDenominator - currentFrame.loopDenominator);
    }

    float sr = 48000.0f;
    float invSr = 1.0f / 48000.0f;
    size_t currentOrder = 20;

    // Parametri Antares Auto-Tune Pro
    float throatLengthPercent = 100.0f;
    float throatLambda = 0.0f;
    LPCResynthesisMode resynthesisMode = LPCResynthesisMode::Modern;
    float flexTune = 0.0f;
    float humanize = 0.0f;

    // Buffer di analisi circolare e finestra di Hamming
    std::array<float, ANALYSIS_WINDOW_SIZE> analysisRingBuffer{};
    std::array<float, ANALYSIS_WINDOW_SIZE> hammingWindow{};
    size_t writeIndex = 0;
    size_t samplesSinceLastHop = 0;

    // Memoria di stato per filtraggio inverso FIR
    std::array<float, MAX_ORDER + 1> invFilterMemory{};

    // Memoria di stato per risintesi ZDF Allpass Ladder
    std::array<float, MAX_ORDER + 1> synthAllpassStates{};

    // Filtri pre-emphasis e de-emphasis
    float prevPreEmphasisSample = 0.0f;
    float prevDeEmphasisSample = 0.0f;

    // Frame LPC correnti e target
    LPCFrameData<MAX_ORDER> currentFrame{};
    LPCFrameData<MAX_ORDER> targetFrame{};

    // Dinamica di transizione Modern Smootherstep
    float transitionPhase = 1.0f;
    float phaseIncrement = 1.0f;

    // Timer per Humanize
    uint32_t sustainCounterSamples = 0;
    float lastCentsOffset = 0.0f;
};

} // namespace dsp171
