#pragma once

#include <cmath>
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include "Common.h"
#include "FastMath.h"
#include "ADAA2HardClipper.h"
#include "ADAA2Clipper.h"
#include "AcousticThermalDiodeClipper.h"
#include "TransDetailMatrix.h"
#include "TruePeakLimiterBS1770.h"
#include "ZDFSVF.h"
#include "DCBlocker.h"

namespace dsp171 {

// =============================================================================
// 171PerfectClipEngine
// Master Audio Engine for 171PerfectClip VST3 / AU / Standalone
//
// Unifies:
// 1. Multi-Topology ADAA-2 Clipping (Precision Digital, Gold Converter, Tube, Diode).
// 2. 171 TransDetail™ Matrix: Zero-latency transient preservation & Alchemy air.
// 3. Continuously Variable Soft Knee [0% (Brickwall) to 100% (Pure Smooth)].
// 4. Stereo & Mid/Side Processing with Sub-Bass Mono-Maker (< 80 Hz).
// 5. ITU-R BS.1770-4 Compliant True-Peak / Inter-Sample Peak Safety Ceiling.
// 6. Delta Audition Mode (solo clipped content).
// 7. 60 FPS Lock-Free Atomic Telemetry & Bipolar Scope Ringbuffer.
// =============================================================================

enum class ClipperMode : uint32_t {
    PrecisionDigital = 0, // Analytical ADAA-2 Piecewise Hard Clip (Max RMS)
    GoldConverter122,     // Lavry Gold 122-96 ADC Soft Knee & Harmonic Mojo
    TubeTriodeClassA,     // Asymmetric Class-A Tube Warmth (H2/H3 morphing)
    GermaniumDiode        // Organic Germanium Diode Knee (Punchy & Gritty)
};

enum class ChannelRouting : uint32_t {
    StereoLR = 0,
    MidSideSplit,
    MidOnly,
    SideOnly
};

class PerfectClipEngine {
public:
    static constexpr size_t SCOPE_BUFFER_SIZE = 1024;

    struct TelemetryData {
        float inPeakDbL = -100.0f;
        float inPeakDbR = -100.0f;
        float outPeakDbL = -100.0f;
        float outPeakDbR = -100.0f;
        float maxGainReductionDb = 0.0f;
        float crestFactorDb = 0.0f;
        bool isClippingNow = false;
    };

    struct ScopeSample {
        float inSample;
        float outSample;
        float deltaSample;
        bool clipped;
    };

    PerfectClipEngine() noexcept {
        reset();
    }

    void prepare(double sampleRate, size_t /*maxBlockSize*/ = 512) noexcept {
        sr = (sampleRate > 0.0) ? static_cast<float>(sampleRate) : 44100.0f;

        for (int ch = 0; ch < 2; ++ch) {
            hardClippers[ch].reset();
            analogClippers[ch].reset();
            goldClippers[ch].prepare(sr);
            transDetail[ch].prepare(sr);
            dcBlockers[ch].prepare(sr, 5.0f);
            ispLimiters[ch].prepare(sr, 64);
            monoMakerFilters[ch].setParameters(monoMakerFreqHz, 0.7071f, sr);
        }

        ballisticsAlpha = 1.0f - std::exp(-1.0f / (0.050f * sr)); // 50 ms meter decay
        reset();
    }

    void reset() noexcept {
        for (int ch = 0; ch < 2; ++ch) {
            hardClippers[ch].reset();
            analogClippers[ch].reset();
            goldClippers[ch].reset();
            transDetail[ch].reset();
            dcBlockers[ch].reset();
            ispLimiters[ch].reset();
            monoMakerFilters[ch].reset();
        }

        scopeWriteIndex.store(0, std::memory_order_relaxed);
        for (auto& s : scopeRingBuffer) {
            s = { 0.0f, 0.0f, 0.0f, false };
        }

        deltaDelayL.fill(0.0f);
        deltaDelayR.fill(0.0f);
        deltaDelayIdx = 0;

        peakInL = 0.0f;
        peakInR = 0.0f;
        peakOutL = 0.0f;
        peakOutR = 0.0f;
        maxGR = 0.0f;
        rmsSum = 0.0f;
        sampleCount = 0;
    }

    // --- Parameter Setters ---
    void setInputGainDb(float gainDb) noexcept {
        inGainDb = gainDb;
        inGainLinear = dbToGain(gainDb);
    }

    void setCeilingDb(float ceilingDbVal) noexcept {
        ceilingDb = std::clamp(ceilingDbVal, -24.0f, 0.0f);
        ceilingLinear = dbToGain(ceilingDb);
        for (int ch = 0; ch < 2; ++ch) {
            ispLimiters[ch].setCeilingDb(ceilingDb);
        }
    }

    void setOutputGainDb(float gainDb) noexcept {
        outGainDb = gainDb;
        outGainLinear = dbToGain(gainDb);
    }

    void setClipperMode(ClipperMode mode) noexcept {
        currentMode = mode;
    }

    void setSoftKnee(float knee) noexcept {
        softKnee = std::clamp(knee, 0.0f, 1.0f);
    }

    void setDetailPreservation(float amount) noexcept {
        detailPreserve = std::clamp(amount, 0.0f, 1.0f);
        for (int ch = 0; ch < 2; ++ch) {
            transDetail[ch].setDetailPreservation(detailPreserve);
        }
    }

    void setAlchemyAirDb(float gainDb) noexcept {
        alchemyAirDb = std::clamp(gainDb, -6.0f, 6.0f);
        for (int ch = 0; ch < 2; ++ch) {
            transDetail[ch].setAlchemyAirDb(alchemyAirDb);
        }
    }

    void setRouting(ChannelRouting routing) noexcept {
        currentRouting = routing;
    }

    void setMonoMaker(bool enable, float freqHz = 80.0f) noexcept {
        monoMakerEnabled = enable;
        monoMakerFreqHz = std::clamp(freqHz, 20.0f, 300.0f);
        for (int ch = 0; ch < 2; ++ch) {
            monoMakerFilters[ch].setParameters(monoMakerFreqHz, 0.7071f, sr);
        }
    }

    void setTruePeakGuard(bool enable) noexcept {
        truePeakGuardEnabled = enable;
    }

    void setDeltaAudition(bool enable) noexcept {
        deltaAudition = enable;
    }

    [[nodiscard]] size_t getLatencySamples() const noexcept {
        return truePeakGuardEnabled ? 64 : 0;
    }

    // --- Core Stereo Audio Processing Block ---
    void processBlock(float* leftChannel, float* rightChannel, size_t numSamples) noexcept {
        if (numSamples == 0 || leftChannel == nullptr) return;
        const bool isStereo = (rightChannel != nullptr);

        float blockMaxGR = 0.0f;
        float blockMaxInL = 0.0f;
        float blockMaxInR = 0.0f;
        float blockMaxOutL = 0.0f;
        float blockMaxOutR = 0.0f;
        bool anyClipping = false;

        size_t writeIdx = scopeWriteIndex.load(std::memory_order_relaxed);

        for (size_t i = 0; i < numSamples; ++i) {
            const float inL = leftChannel[i] * inGainLinear;
            const float inR = isStereo ? (rightChannel[i] * inGainLinear) : inL;

            blockMaxInL = std::max(blockMaxInL, std::abs(inL));
            blockMaxInR = std::max(blockMaxInR, std::abs(inR));

            // 1. Channel Routing (Stereo L/R vs Mid/Side)
            float ch1 = inL;
            float ch2 = inR;

            if (currentRouting != ChannelRouting::StereoLR && isStereo) {
                // MS Encoding: M = (L+R)*0.7071, S = (L-R)*0.7071
                constexpr float invSqrt2 = 0.7071067811865475f;
                ch1 = (inL + inR) * invSqrt2; // Mid
                ch2 = (inL - inR) * invSqrt2; // Side

                // MonoMaker: highpass filter on Side channel (<80 Hz mono bass)
                if (monoMakerEnabled) {
                    const auto svfOut = monoMakerFilters[1].process(ch2);
                    ch2 = svfOut.hp;
                }
            }

            // 2. Process Channel 1 (Left or Mid)
            bool clippedCh1 = false;
            float grCh1 = 0.0f;
            float out1 = processSingleChannel(ch1, 0, clippedCh1, grCh1);

            // 3. Process Channel 2 (Right or Side)
            bool clippedCh2 = false;
            float grCh2 = 0.0f;
            float out2 = out1;
            if (isStereo) {
                if (currentRouting == ChannelRouting::MidOnly) {
                    // Mid clipped, Side untouched
                    out2 = ch2;
                } else if (currentRouting == ChannelRouting::SideOnly) {
                    // Side clipped, Mid untouched
                    out1 = ch1;
                    out2 = processSingleChannel(ch2, 1, clippedCh2, grCh2);
                } else {
                    out2 = processSingleChannel(ch2, 1, clippedCh2, grCh2);
                }
            }

            // 4. MS Decoding back to L/R if needed
            float clippedL = out1;
            float clippedR = out2;

            if (currentRouting != ChannelRouting::StereoLR && isStereo) {
                constexpr float invSqrt2 = 0.7071067811865475f;
                clippedL = (out1 + out2) * invSqrt2;
                clippedR = (out1 - out2) * invSqrt2;
            }

            // 5. Shaved Peak Delta (pure pre-clip minus post-clip material)
            const float deltaRawL = inL - clippedL;
            const float deltaRawR = inR - clippedR;

            // Delta delay compensation to align with ISP lookahead (64 samples)
            const float deltaDelayedL = deltaDelayL[deltaDelayIdx];
            const float deltaDelayedR = deltaDelayR[deltaDelayIdx];
            deltaDelayL[deltaDelayIdx] = deltaRawL;
            deltaDelayR[deltaDelayIdx] = deltaRawR;
            deltaDelayIdx = (deltaDelayIdx + 1) % 64;

            const float finalDeltaL = truePeakGuardEnabled ? deltaDelayedL : deltaRawL;
            const float finalDeltaR = truePeakGuardEnabled ? deltaDelayedR : deltaRawR;

            // 6. Apply Output Makeup Gain
            float finalL = clippedL * outGainLinear;
            float finalR = clippedR * outGainLinear;

            // 7. DC Blocking
            finalL = dcBlockers[0].processSample(finalL);
            if (isStereo) finalR = dcBlockers[1].processSample(finalR);

            // 8. True Peak Inter-Sample Peak Guard (or strict ceiling safety clamp)
            if (truePeakGuardEnabled) {
                finalL = ispLimiters[0].processSample(finalL);
                if (isStereo) finalR = ispLimiters[1].processSample(finalR);
            } else {
                if (outGainLinear <= 1.001f) {
                    finalL = std::clamp(finalL, -ceilingLinear, ceilingLinear);
                    if (isStereo) finalR = std::clamp(finalR, -ceilingLinear, ceilingLinear);
                }
            }

            const bool sampleClipped = (clippedCh1 || clippedCh2);
            if (sampleClipped) anyClipping = true;

            const float sampleGR = std::max(grCh1, grCh2);
            blockMaxGR = std::max(blockMaxGR, sampleGR);

            // 9. Delta Audition Mode (Output = isolated shaved peaks)
            float outSampleL = finalL;
            float outSampleR = finalR;

            if (deltaAudition) {
                outSampleL = finalDeltaL;
                outSampleR = finalDeltaR;
            }

            leftChannel[i] = outSampleL;
            if (isStereo) rightChannel[i] = outSampleR;

            blockMaxOutL = std::max(blockMaxOutL, std::abs(outSampleL));
            blockMaxOutR = std::max(blockMaxOutR, std::abs(outSampleR));

            // 10. Scope Snapshot Streaming (Lock-free triple-ring)
            scopeRingBuffer[writeIdx] = {
                (inL + inR) * 0.5f,
                (outSampleL + outSampleR) * 0.5f,
                (finalDeltaL + finalDeltaR) * 0.5f,
                sampleClipped
            };
            writeIdx = (writeIdx + 1) % SCOPE_BUFFER_SIZE;

            // RMS accumulation
            const float sumSq = outSampleL * outSampleL + outSampleR * outSampleR;
            rmsSum += sumSq;
            sampleCount += 2;
        }

        scopeWriteIndex.store(writeIdx, std::memory_order_relaxed);

        // Update telemetry ballistics
        peakInL += ballisticsAlpha * (blockMaxInL - peakInL);
        peakInR += ballisticsAlpha * (blockMaxInR - peakInR);
        peakOutL += ballisticsAlpha * (blockMaxOutL - peakOutL);
        peakOutR += ballisticsAlpha * (blockMaxOutR - peakOutR);
        maxGR += ballisticsAlpha * (blockMaxGR - maxGR);
        isClippingFlag.store(anyClipping, std::memory_order_relaxed);
    }

    TelemetryData getTelemetry() noexcept {
        TelemetryData d;
        d.inPeakDbL = gainToDb(std::max(1.0e-5f, peakInL));
        d.inPeakDbR = gainToDb(std::max(1.0e-5f, peakInR));
        d.outPeakDbL = gainToDb(std::max(1.0e-5f, peakOutL));
        d.outPeakDbR = gainToDb(std::max(1.0e-5f, peakOutR));
        d.maxGainReductionDb = maxGR;
        d.isClippingNow = isClippingFlag.load(std::memory_order_relaxed);

        // Calculate Crest Factor = Peak (dB) - RMS (dB)
        if (sampleCount > 100) {
            const float meanSq = rmsSum / static_cast<float>(sampleCount);
            const float rms = std::sqrt(std::max(1.0e-8f, meanSq));
            const float peak = std::max(peakOutL, peakOutR);
            d.crestFactorDb = std::max(0.0f, gainToDb(peak) - gainToDb(rms));

            // Reset RMS window every buffer read
            rmsSum = 0.0f;
            sampleCount = 0;
        }
        return d;
    }

    // Read a coherent snapshot of the scope buffer for 60 FPS GUI rendering
    void copyScopeSnapshot(std::array<ScopeSample, SCOPE_BUFFER_SIZE>& dest) noexcept {
        const size_t currentWrite = scopeWriteIndex.load(std::memory_order_relaxed);
        for (size_t i = 0; i < SCOPE_BUFFER_SIZE; ++i) {
            const size_t srcIdx = (currentWrite + i) % SCOPE_BUFFER_SIZE;
            dest[i] = scopeRingBuffer[srcIdx];
        }
    }

private:
    // Process a single channel through TransDetail + Selected Clipper Engine
    inline float processSingleChannel(float in, int chIdx, bool& outClipped, float& outGR) noexcept {
        const float absIn = std::abs(in);
        outClipped = (absIn > ceilingLinear);

        if (outClipped) {
            outGR = gainToDb(absIn) - ceilingDb;
        } else {
            outGR = 0.0f;
        }

        // 1. TransDetail Orthogonal Carrier / Detail Split
        const auto split = transDetail[chIdx].split(in);

        // 2. Apply Selected Clipper Topology to Carrier
        float clippedCarrier = split.carrier;

        switch (currentMode) {
            case ClipperMode::PrecisionDigital: {
                // ADAA-2 Bit-exact piecewise Hard Clip
                const float digitalOut = hardClippers[chIdx].processSample(split.carrier, ceilingLinear);
                // Blend with C2-continuous quintic acoustic corridor if soft knee is engaged
                if (softKnee > 0.001f) {
                    const float c2AcousticOut = goldClippers[chIdx].processSample(split.carrier, ceilingLinear, false);
                    clippedCarrier = (1.0f - softKnee) * digitalOut + softKnee * c2AcousticOut;
                } else {
                    clippedCarrier = digitalOut;
                }
                break;
            }

            case ClipperMode::GoldConverter122: {
                // Lavry Gold 122-96 ADC Authentic Physical Emulation:
                // 1. Discrete JFET input buffer with calibrated H2 @ -52 dBFS (bounded to prevent IMD)
                // 2. Dynamic Joule heating thermal sag (tau = 35 ms)
                // 3. C2-continuous quintic smoothing eliminating acoustic shockwaves & transducer jerk
                clippedCarrier = goldClippers[chIdx].processSample(split.carrier, ceilingLinear, true);
                break;
            }

            case ClipperMode::TubeTriodeClassA: {
                // Asymmetric Class-A Tube warmth with bounded 2nd harmonic and soft saturation
                const float scaled = split.carrier / ceilingLinear;
                const float tubeIn = scaled + 0.08f * std::tanh(scaled * scaled) * (scaled >= 0.0f ? 1.0f : -0.5f);
                const float tubeOut = analogClippers[chIdx].processSample(tubeIn, 1.0f);
                clippedCarrier = std::clamp(tubeOut * ceilingLinear, -ceilingLinear, ceilingLinear);
                break;
            }

            case ClipperMode::GermaniumDiode: {
                // Vintage Germanium diode conduction with lower threshold knee & aggressive punch
                const float scaled = split.carrier / ceilingLinear;
                const float diodeOut = analogClippers[chIdx].processSample(scaled * 1.2f, 1.0f);
                clippedCarrier = std::clamp(diodeOut * ceilingLinear, -ceilingLinear, ceilingLinear);
                break;
            }
        }

        // 3. Recombine Carrier and Detail with Dynamic Transient Protection
        return transDetail[chIdx].recombine(split.rawIn, clippedCarrier, split.detail, split.transientWeight, ceilingLinear);
    }

    float sr = 44100.0f;
    float inGainDb = 0.0f;
    float inGainLinear = 1.0f;
    float ceilingDb = 0.0f;
    float ceilingLinear = 1.0f;
    float outGainDb = 0.0f;
    float outGainLinear = 1.0f;
    float softKnee = 0.0f;
    float detailPreserve = 1.0f;
    float alchemyAirDb = 0.0f;
    float monoMakerFreqHz = 80.0f;

    bool monoMakerEnabled = true;
    bool truePeakGuardEnabled = true;
    bool deltaAudition = false;

    ClipperMode currentMode = ClipperMode::PrecisionDigital;
    ChannelRouting currentRouting = ChannelRouting::StereoLR;

    // Channels
    ADAA2HardClipper hardClippers[2];
    ADAA2Clipper analogClippers[2];
    AcousticThermalDiodeClipper goldClippers[2];
    TransDetailMatrix transDetail[2];
    DCBlocker dcBlockers[2];
    TruePeakLimiterBS1770 ispLimiters[2];
    ZDFSVF64 monoMakerFilters[2];

    // Delta latency alignment delay buffers (64 samples matching TruePeak lookahead)
    std::array<float, 64> deltaDelayL{};
    std::array<float, 64> deltaDelayR{};
    size_t deltaDelayIdx = 0;

    // Telemetry & Scope
    float peakInL = 0.0f;
    float peakInR = 0.0f;
    float peakOutL = 0.0f;
    float peakOutR = 0.0f;
    float maxGR = 0.0f;
    float ballisticsAlpha = 0.05f;
    float rmsSum = 0.0f;
    size_t sampleCount = 0;
    std::atomic<bool> isClippingFlag{ false };

    alignas(64) std::array<ScopeSample, SCOPE_BUFFER_SIZE> scopeRingBuffer{};
    std::atomic<size_t> scopeWriteIndex{ 0 };
};

} // namespace dsp171
