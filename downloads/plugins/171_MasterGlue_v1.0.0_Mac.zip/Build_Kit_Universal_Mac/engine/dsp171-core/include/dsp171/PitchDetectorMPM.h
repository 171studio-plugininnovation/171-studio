#pragma once
#include <cmath>
#include <array>
#include <algorithm>
#include <cstdint>
#include <span>
#include "Common.h"
#include "VocalCleanFilter.h"

namespace dsp171 {

// =============================================================================
// Risultato della stima del pitch per frame audio
// =============================================================================
struct PitchResult {
    float frequencyHz = 0.0f;       // Frequenza fondamentale stimata f0 in Hz
    float periodSamples = 0.0f;     // Periodo fondamentale in sample (fs / f0)
    float clarity = 0.0f;           // Chiarezza/periodicità NSDF [0.0, 1.0]
    bool isVoiced = false;          // True se segnale vocalizzato (clarity >= soglia)
    bool isPlosive = false;         // True se transiente anomalo / air burst microfonico
};

// =============================================================================
// Range di ricerca del pitch vocale (Input Type - Auto-Tune & Waves Tune RT)
// =============================================================================
enum class VocalRange : uint8_t {
    AltoTenor = 0,   // ~85 Hz to 620 Hz (Standard vocale pop, trap, rap maschile/femminile medio)
    Soprano = 1,     // ~125 Hz to 1100 Hz (Voci femminili acute, falsetto, registro fischio)
    LowMale = 2,     // ~55 Hz to 360 Hz (Baritoni profondi, bassi, speech profondo)
    Wide = 3         // ~45 Hz to 1250 Hz (Intero spettro vocale e strumentale)
};

// =============================================================================
// Modulo di Pitch Detection MPM (McLeod Pitch Method) basato su NSDF
// Caratteristiche di produzione:
// 1. Zero allocazioni dinamiche nel process thread (real-time safe, noexcept).
// 2. Calcolo NSDF (Normalized Square Difference Function) ad alta efficienza:
//    - Running energy accumulator O(1) in precisione double per sumYY.
//    - Dot-product sumXY vettorizzabile SIMD (AVX2/FMA).
// 3. Peak-picking con soglia dinamica (cutoff 0.85 * maxPeak) per prevenire
//    errori di ottava inferiore (period doubling).
// 4. Interpolazione parabolica quadratica sub-sample per precisione < 0.1 Hz.
// 5. Isteresi e filtro di continuità anti-jitter per pitch tracking solido.
// =============================================================================
class PitchDetectorMPM {
public:
    static constexpr size_t MAX_WINDOW_SIZE = 2048;
    static constexpr size_t MAX_LAG = 4096;
    static constexpr size_t MAX_REQUIRED_BUFFER = MAX_WINDOW_SIZE + MAX_LAG; // 6144
    static constexpr size_t MAX_ANALYSIS_BUFFER = 8192;
    static constexpr size_t ANALYSIS_BUFFER_MASK = MAX_ANALYSIS_BUFFER - 1;
    static constexpr size_t MAX_PEAKS = 128;

    PitchDetectorMPM() noexcept {
        reset();
    }

    void prepare(double sampleRate, size_t windowSize = 1024, size_t hopSize = 128) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 48000.0);
        
        // Limiti sicuri su window size e hop size proporzionali al sample rate
        const size_t scaledWin = (windowSize == 1024 && sr > 48000.0f)
                               ? std::min(MAX_WINDOW_SIZE, static_cast<size_t>(sr * 0.02133f))
                               : windowSize;
        winSize = std::clamp(scaledWin, size_t(256), MAX_WINDOW_SIZE);
        hop = std::clamp(hopSize, size_t(32), winSize / 2);
        
        // Range di ricerca pitch vocale basato su VocalRange (Input Type)
        updatePeriodBounds();

        reset();
    }

    void setVocalRange(VocalRange range) noexcept {
        vocalRange = range;
        updatePeriodBounds();
    }

    [[nodiscard]] VocalRange getVocalRange() const noexcept {
        return vocalRange;
    }

    void updatePeriodBounds() noexcept {
        float minF = 40.0f;
        float maxF = 1400.0f;
        float cleanCutoff = 55.0f;
        switch (vocalRange) {
            case VocalRange::AltoTenor: minF = 80.0f;  maxF = 800.0f;  cleanCutoff = 65.0f; break;
            case VocalRange::Soprano:   minF = 120.0f; maxF = 1350.0f; cleanCutoff = 85.0f; break;
            case VocalRange::LowMale:   minF = 50.0f;  maxF = 450.0f;  cleanCutoff = 45.0f; break;
            case VocalRange::Wide:
            default:                    minF = 40.0f;  maxF = 1400.0f; cleanCutoff = 40.0f; break;
        }
        minPeriod = std::max(size_t(2), static_cast<size_t>(sr / maxF));
        maxPeriod = std::min(MAX_LAG - 1, static_cast<size_t>(sr / minF));
        trackingHPF.prepare(sr, cleanCutoff);
    }

    void reset() noexcept {
        inputBuffer.fill(0.0f);
        nsdfBuffer.fill(0.0f);
        energyYY.fill(0.0f);
        scratchBuffer.fill(0.0f);
        writeIndex = 0;
        samplesSinceLastEstimate = 0;
        lastResult = PitchResult{};
        smoothedFreq = 0.0f;
        candidateJumpFreq = 0.0f;
        octaveJumpCandidateCount = 0;
        wasVoiced = false;
        trackingHPF.reset();
    }

    // Configura la soglia di periodicità con isteresi Schmitt Trigger (Dual-Threshold)
    void setVoicingThreshold(float threshold) noexcept {
        voicingThresholdOn = std::clamp(threshold, 0.25f, 0.95f);
        voicingThresholdOff = voicingThresholdOn * 0.82f; // Isteresi anti-chatter
    }

    // Configura il fattore di cutoff McLeod per prevenire il dimezzamento d'ottava (default 0.85)
    void setCutoffThreshold(float cutoff) noexcept {
        cutoffThreshold = std::clamp(cutoff, 0.50f, 0.99f);
    }

    // Filtro di pre-tracking vocale passa-alto ZDF SVF Butterworth 2° ordine:
    // Elimina radicalmente offset continui, plosive e sub-rumble prima della correlazione NSDF
    inline float filterDC(float in) noexcept {
        return trackingHPF.processSample(in);
    }

    // Push di un singolo campione nell'anello di analisi (restituisce true se un nuovo frame è stato analizzato)
    inline bool pushSample(float sample, PitchResult& outResult) noexcept {
        const float cleanSample = filterDC(sample);
        inputBuffer[writeIndex] = cleanSample;
        writeIndex = (writeIndex + 1) & ANALYSIS_BUFFER_MASK;
        
        samplesSinceLastEstimate++;
        if (samplesSinceLastEstimate >= hop) {
            samplesSinceLastEstimate = 0;
            outResult = computePitch();
            lastResult = outResult;
            return true;
        }

        outResult = lastResult;
        return false;
    }

    // Elaborazione a blocchi: aggiorna l'analisi audio e restituisce la stima più recente
    inline PitchResult processBlock(const float* input, size_t numSamples) noexcept {
        for (size_t i = 0; i < numSamples; ++i) {
            const float cleanSample = filterDC(input[i]);
            inputBuffer[writeIndex] = cleanSample;
            writeIndex = (writeIndex + 1) & ANALYSIS_BUFFER_MASK;
        }

        samplesSinceLastEstimate += numSamples;
        if (samplesSinceLastEstimate >= hop) {
            samplesSinceLastEstimate = 0;
            lastResult = computePitch();
        }

        return lastResult;
    }

    // Accessori telemetrici immediati
    [[nodiscard]] const PitchResult& getLatestResult() const noexcept { return lastResult; }
    [[nodiscard]] float getSampleRate() const noexcept { return sr; }
    [[nodiscard]] size_t getWindowSize() const noexcept { return winSize; }
    [[nodiscard]] size_t getHopSize() const noexcept { return hop; }

private:
    struct PeakCandidate {
        size_t lag = 0;
        float value = 0.0f;
    };

    // Estrae una finestra lineare contigua di W + maxPeriod campioni
    void extractLinearBuffer(std::span<float, MAX_REQUIRED_BUFFER> dest, size_t totalSamples) const noexcept {
        const size_t start = (writeIndex + MAX_ANALYSIS_BUFFER - totalSamples) & ANALYSIS_BUFFER_MASK;
        for (size_t i = 0; i < totalSamples; ++i) {
            dest[i] = inputBuffer[(start + i) & ANALYSIS_BUFFER_MASK];
        }
    }

    // Calcolo ottimizzato di NSDF:
    // r(tau) = 2 * sum(x[j] * x[j + tau]) / ( sum(x[j]^2) + sum(x[j + tau]^2) )
    PitchResult computePitch() noexcept {
        const size_t totalNeeded = winSize + maxPeriod;
        extractLinearBuffer(scratchBuffer, totalNeeded);
        const float* buffer = scratchBuffer.data();

        // 1. Calcolo di sumXX = sum_{j=0}^{W-1} x[j]^2 in precisione double per stabilità
        double runningEnergy = 0.0;
        for (size_t j = 0; j < winSize; ++j) {
            const double s = static_cast<double>(buffer[j]);
            runningEnergy += s * s;
        }

        const float sumXX = static_cast<float>(runningEnergy);

        // Se silenzio digitale (sotto noise floor)
        if (sumXX < 1e-7f) {
            wasVoiced = false;
            lastResult = PitchResult{ 0.0f, 0.0f, 0.0f, false };
            return lastResult;
        }

        // 2. Pre-calcolo O(1) di sumYY per ogni tau da 0 a maxPeriod:
        // sumYY[t] = sumYY[t-1] - buffer[t-1]^2 + buffer[t-1+winSize]^2
        energyYY[0] = sumXX;
        for (size_t t = 1; t <= maxPeriod; ++t) {
            const double subS = static_cast<double>(buffer[t - 1]);
            const double addS = static_cast<double>(buffer[t - 1 + winSize]);
            runningEnergy = runningEnergy - (subS * subS) + (addS * addS);
            energyYY[t] = static_cast<float>(std::max(0.0, runningEnergy));
        }

        // 3. Calcolo del numeratore di correlazione sumXY con 4 accumulatori vettoriali paralleli (AVX2/FMA)
        // L'esplicitazione dei 4 rami paralleli elimina le dipendenze seriali IEEE-754 consentendo la piena SIMD pipelining
        nsdfBuffer[0] = 1.0f;
        for (size_t tau = 1; tau <= maxPeriod; ++tau) {
            float sum0 = 0.0f;
            float sum1 = 0.0f;
            float sum2 = 0.0f;
            float sum3 = 0.0f;
            const float* const p0 = buffer;
            const float* const pt = buffer + tau;

            size_t j = 0;
            const size_t unrollEnd = winSize >= 4 ? winSize - 3 : 0;
            for (; j < unrollEnd; j += 4) {
                sum0 += p0[j] * pt[j];
                sum1 += p0[j + 1] * pt[j + 1];
                sum2 += p0[j + 2] * pt[j + 2];
                sum3 += p0[j + 3] * pt[j + 3];
            }
            for (; j < winSize; ++j) {
                sum0 += p0[j] * pt[j];
            }

            const float sumXY = (sum0 + sum1) + (sum2 + sum3);
            const float denom = sumXX + energyYY[tau];
            if (denom > 1e-9f) {
                nsdfBuffer[tau] = (2.0f * sumXY) / denom;
            } else {
                nsdfBuffer[tau] = 0.0f;
            }
        }

        // 4. Peak-picking tra zero-crossing positivi (escludendo il lobo principale a lag 0)
        std::array<PeakCandidate, MAX_PEAKS> peaks{};
        size_t peakCount = 0;
        float maxPeakValue = -1.0f;

        bool sawNegativeRegion = false;
        bool inPositiveRegion = false;
        size_t curPeakLag = 0;
        float curPeakVal = -1.0f;

        for (size_t tau = 1; tau <= maxPeriod; ++tau) {
            const float cur = nsdfBuffer[tau];
            const float prev = nsdfBuffer[tau - 1];

            // Rileva quando il lobo principale a lag 0 scende sotto lo zero
            if (cur <= 0.0f) {
                sawNegativeRegion = true;
            }

            // Solo dopo aver visto la prima regione negativa possiamo accettare lobi periodici
            if (sawNegativeRegion && tau >= minPeriod) {
                // Attraversamento dello zero da negativo a positivo
                if (!inPositiveRegion && prev <= 0.0f && cur > 0.0f) {
                    inPositiveRegion = true;
                    curPeakLag = tau;
                    curPeakVal = cur;
                } else if (inPositiveRegion) {
                    if (cur > curPeakVal) {
                        curPeakVal = cur;
                        curPeakLag = tau;
                    }
                    // Zero-crossing da positivo a negativo (o fine del buffer di analisi)
                    if (cur <= 0.0f || tau == maxPeriod) {
                        inPositiveRegion = false;
                        if (peakCount < MAX_PEAKS && curPeakVal > 0.0f) {
                            peaks[peakCount++] = PeakCandidate{ curPeakLag, curPeakVal };
                            if (curPeakVal > maxPeakValue) {
                                maxPeakValue = curPeakVal;
                            }
                        }
                    }
                }
            }
        }

        // Soglia con isteresi di Schmitt: previene oscillazioni su whispering e transienti
        const float activeVoicingThreshold = wasVoiced ? voicingThresholdOff : voicingThresholdOn;

        // Se non troviamo picchi positivi o maxPeakValue è inferiore alla soglia di periodicità
        if (peakCount == 0 || maxPeakValue < activeVoicingThreshold) {
            wasVoiced = false;
            lastResult.clarity = std::max(0.0f, maxPeakValue);
            lastResult.isVoiced = false;
            return lastResult;
        }

        // 5. Regola di selezione McLeod: primo picco che supera il cutoff threshold
        const float threshold = maxPeakValue * cutoffThreshold;
        size_t chosenLag = 0;
        float chosenVal = 0.0f;

        for (size_t i = 0; i < peakCount; ++i) {
            if (peaks[i].value >= threshold) {
                chosenLag = peaks[i].lag;
                chosenVal = peaks[i].value;
                break;
            }
        }

        if (chosenLag == 0 || chosenLag <= minPeriod || chosenLag >= maxPeriod) {
            wasVoiced = false;
            lastResult.clarity = chosenVal;
            lastResult.isVoiced = false;
            return lastResult;
        }

        // 6. Interpolazione parabolica con verifica analitica di curvatura negativa
        const float alpha = nsdfBuffer[chosenLag - 1];
        const float beta  = nsdfBuffer[chosenLag];
        const float gamma = nsdfBuffer[chosenLag + 1];

        const float denom = 2.0f * (alpha - 2.0f * beta + gamma);
        float delta = 0.0f;
        // Solo se curvatura strettamente concava (vertice è un massimo, non sella o rumore piatto)
        if (denom < -1e-4f) {
            delta = (alpha - gamma) / denom;
            delta = std::clamp(delta, -1.0f, 1.0f);
        }

        const float refinedPeriod = static_cast<float>(chosenLag) + delta;
        const float refinedClarity = beta - 0.25f * (alpha - gamma) * delta;

        if (refinedPeriod <= 0.0f) {
            wasVoiced = false;
            lastResult.isVoiced = false;
            return lastResult;
        }

        const float rawFreq = sr / refinedPeriod;

        // Protezione esclusiva dai soli salti d'ottava spuri (period doubling / halving).
        // NOTA FONDAMENTALE (Waves Tune RT & Auto-Tune parity):
        // La frequenza stimata NON deve subire alcun lag o filtro IIR sulle variazioni melodiche!
        // Se la stima ritarda (f_lagged != f_in), il rapporto di pitch targetFreq / f_lagged 
        // non cancella f_in: quando la voce scende, f_in < f_lagged rendendo il pitch sistematicamente CALANTE (-15..-35 ct);
        // quando la voce sale, f_in > f_lagged rendendo il pitch CRESCENTE.
        // Utilizzando rawFreq istantaneo, f_in si cancella perfettamente: f_in * (f_target / f_in) = f_target esatto!
        if (wasVoiced && smoothedFreq > 20.0f) {
            const bool isOctaveJump = (std::abs(rawFreq - 2.0f * smoothedFreq) < 0.20f * smoothedFreq) ||
                                      (std::abs(rawFreq - 0.5f * smoothedFreq) < 0.12f * smoothedFreq);
            if (isOctaveJump) {
                if (candidateJumpFreq > 10.0f && std::abs(rawFreq - candidateJumpFreq) < 0.08f * candidateJumpFreq) {
                    octaveJumpCandidateCount++;
                } else {
                    candidateJumpFreq = rawFreq;
                    octaveJumpCandidateCount = 1;
                }

                if (octaveJumpCandidateCount >= 2) {
                    smoothedFreq = rawFreq;
                    octaveJumpCandidateCount = 0;
                    candidateJumpFreq = 0.0f;
                }
            } else {
                smoothedFreq = rawFreq;
                octaveJumpCandidateCount = 0;
                candidateJumpFreq = 0.0f;
            }
        } else {
            smoothedFreq = rawFreq;
            octaveJumpCandidateCount = 0;
            candidateJumpFreq = 0.0f;
        }

        // Plosive & Air Blast Transient Guard:
        // Se la frequenza stimata è anomala o molto alta (es. > 600 Hz), ma il segnale nella finestra
        // ha un numero di zero-crossing drasticamente inferiore a quello matematicamente
        // richiesto da una vera armonica vocale, si tratta di un fronte d'onda transiente o un pop microfonico!
        size_t zcCount = 0;
        for (size_t j = 1; j < winSize; ++j) {
            if ((buffer[j] > 0.0f && buffer[j - 1] <= 0.0f) || (buffer[j] < 0.0f && buffer[j - 1] >= 0.0f)) {
                zcCount++;
            }
        }

        const float minExpectedZC = (rawFreq * static_cast<float>(winSize) / sr) * 0.40f;
        const bool isPlosiveAirBurst = (rawFreq > 600.0f && static_cast<float>(zcCount) < minExpectedZC && zcCount < 20);

        if (isPlosiveAirBurst) {
            wasVoiced = false;
            lastResult.clarity = 0.0f;
            lastResult.isVoiced = false;
            lastResult.isPlosive = true;
            lastResult.frequencyHz = 0.0f;
            lastResult.periodSamples = 0.0f;
            return lastResult;
        }

        lastResult.isPlosive = false;
        lastResult.frequencyHz = smoothedFreq;
        lastResult.periodSamples = sr / smoothedFreq;
        lastResult.clarity = std::clamp(refinedClarity, 0.0f, 1.0f);
        lastResult.isVoiced = (lastResult.clarity >= activeVoicingThreshold);
        wasVoiced = lastResult.isVoiced;

        return lastResult;
    }

    float sr = 48000.0f;
    size_t winSize = 1024;
    size_t hop = 128;
    size_t minPeriod = 40;
    size_t maxPeriod = 960;
    VocalRange vocalRange = VocalRange::Wide;

    float voicingThresholdOn = 0.55f;
    float voicingThresholdOff = 0.45f;
    float cutoffThreshold = 0.90f;
    bool wasVoiced = false;

    float candidateJumpFreq = 0.0f;
    int octaveJumpCandidateCount = 0;

    VocalCleanFilter trackingHPF;

    std::array<float, MAX_ANALYSIS_BUFFER> inputBuffer{};
    std::array<float, MAX_REQUIRED_BUFFER> scratchBuffer{};
    std::array<float, MAX_LAG + 1> nsdfBuffer{};
    std::array<float, MAX_LAG + 1> energyYY{};
    size_t writeIndex = 0;
    size_t samplesSinceLastEstimate = 0;

    PitchResult lastResult{};
    float smoothedFreq = 0.0f;
};

} // namespace dsp171
