# 🎚️ DOSSIER TECNICO DI TRASPOSIZIONE — 171 MASTERGLUE
### Analog Master Bus Compressor & TrueSpace Imager per Apple macOS

**Progetto:** 171 MasterGlue (`v1.0.0`)  
**Architettura:** Universal Binary Fat (`arm64` Apple Silicon M1-M4 + `x86_64` Intel)  
**Deployment Target Minimo:** macOS 11.0 Big Sur  
**Approvato da:** Il Direttore  
**Coordinamento:** `dsp-hire-manager`, `comp-optical-universal` & `apple-macos-engineer`  

---

## 1. SPECIFICHE FORMATI & METADATI APPLE AUDIOUNIT

| Parametro | Valore Configurato | Specifiche per DAW macOS |
|---|---|---|
| **AudioUnit Type** | `kAudioUnitType_Effect` (`'aufx'`) | Inseribile come master bus compressor in **Logic Pro** e GarageBand |
| **Manufacturer Code** | `'171P'` | Conforme alle specifiche Apple (include almeno una maiuscola) |
| **Plugin Code / Subtype** | `'171G'` | Identificativo univoco a 4 caratteri per scansione AU |
| **Target Formati Mac** | **AU (`.component`)**, **VST3 (`.vst3`)**, **Standalone (`.app`)** | AU per Logic Pro; VST3 per Ableton, Cubase, Studio One, Reaper, FL |
| **Sicurezza Gatekeeper** | Hardened Runtime attivo | Flag `--options runtime` + entitlements JIT e Unsigned Memory |

---

## 2. MODELLAZIONE ALGORITMICA SU APPLE SILICON (M1–M4)

171 MasterGlue fonde la coesione dinamica dei grandi banchi di mixaggio analogici:

1. **Doppia Topologia Analogica Selezionabile**:
   - **VCA Quad-Gold (SSL 4000 G Bus)**: Punch scattante, feedforward VCA con costanti di tempo esponenziali e auto-release logaritmico anti-distorsione.
   - **Diode-Bridge (Neve 33609 Vintage)**: Compressione cremosa e morbida con colorazione armonica calda.
2. **Analog Tone & 3 Nuclei Magnetici Reali (ADAA-2)**:
   - **Iron Core (Trasformatore Marinair LO1166)**: Enfasi di 2ª armonica ($H_2$) sulle basse frequenze.
   - **Nickel Core**: Trasparenza assoluta e aria sulle alte frequenze ($H_3$).
   - **American Steel**: Saturazione incisiva per bus di batteria e musica moderna.
3. **TrueSpace Stereo Imager**:
   - Elaborazione Mid/Side a matrice ellittica con mono-maker sotto i 90 Hz per preservare la fase del kick e del basso.

---

## 3. INTERFACCIA RETINA A 60 FPS (BOUTIQUE LUXURY)

- **Doppio VU Meter Galvanometrico**: Aghi balistici conformi a standard IEC 60268-17 per Gain Reduction e VU Output.
- **Manopole Zigrinate in Acciaio Satinato Nero**: Quadranti con ghiere neon luminescenti e badge 171 Studio satinato in oro.
- **Pre-rendering su Display Liquid Retina**: Fluido e privo di sovraccarico sulla GPU unificata Apple Silicon.

---

## 4. COMANDO DI COMPILAZIONE RAPIDA

```bash
# Esegui da terminale Mac:
./scripts/build_171masterglue_mac.sh

# Validazione Apple auval per Logic Pro:
auval -v aufx 171G 171P
```
