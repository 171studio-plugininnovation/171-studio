================================================================================
171 STUDIO INNOVATIO — 171 VocalCraft v2.2.0 (macOS)
Rilascio Ufficiale: Novembre 2026
Architetture Supportate: Apple Silicon (ARM64: M1, M2, M3, M4) & Intel (x86_64)
================================================================================

CONTENUTO DEL PACCHETTO MAC:
1. 171VocalCraft.component   (AudioUnit v2 per Logic Pro, GarageBand, Final Cut Pro)
2. 171VocalCraft.vst3        (VST3 a 64-bit per Ableton Live, FL Studio, Cubase, Studio One, Reaper)
3. 171VocalCraft.app         (Applicazione Standalone nativa macOS)
4. INSTALLA_SU_MAC.command (Installatore rapido a doppio clic con rimozione quarantena)
5. Build_Kit_Universal_Mac/ (Sorgenti C++ JUCE e build toolchain vDSP / NEON)
6. 171VocalCraft_Retina_GUI.png (Anteprima interfaccia grafica HD Retina)
7. SCHEDA_TECNICA_APPLE_MACOS.md (Dossier tecnico ufficiale di certificazione)

ISTRUZIONI DI INSTALLAZIONE RAPIDA:
Metodo 1 (Consigliato - Automatico):
- Fai doppio clic sul file 'INSTALLA_SU_MAC.command'.
- Lo script installera automaticamente i bundle nelle directory audio corrette del tuo Mac:
    * AudioUnit: ~/Library/Audio/Plug-Ins/Components/
    * VST3:      ~/Library/Audio/Plug-Ins/VST3/
    * Standalone: /Applications/171 Studio/
- Rimuovera automaticamente il blocco di sicurezza Apple Gatekeeper (quarantena).

Metodo 2 (Manuale):
- Copia '171VocalCraft.component' in: ~/Library/Audio/Plug-Ins/Components/
- Copia '171VocalCraft.vst3' in:      ~/Library/Audio/Plug-Ins/VST3/
- Rimuovi l'attributo quarantine aprendo il Terminale e digitando:
    xattr -dr com.apple.quarantine ~/Library/Audio/Plug-Ins/Components/171VocalCraft.component
    xattr -dr com.apple.quarantine ~/Library/Audio/Plug-Ins/VST3/171VocalCraft.vst3
- Riavvia Logic Pro o la tua DAW preferita.

COMPILAZIONE NATIVA DA SORGENTI (OPZIONALE PER MASSIME PRESTAZIONI):
Se desideri ricompilare il plugin con ottimizzazioni SIMD NEON e Apple Accelerate vDSP
specifiche per il processore del tuo Mac (M1-M4 o Intel):
1. Apri il Terminale ed entra nella cartella 'Build_Kit_Universal_Mac'.
2. Esegui: chmod +x build_mac.sh && ./build_mac.sh --install
3. I binari compilati verranno generati e installati direttamente nelle cartelle di sistema.

VALIDAZIONE AUDIOUNIT IN APPLE LOGIC PRO:
Per verificare la corretta registrazione AU in Logic Pro, digita nel Terminale:
    auval -v aufx 17VC 171P

NOVITA DELLA RELEASE v2.2.0:
Suite Unified Release v2.2.0: Integrazione Motore Fisico Analogico dsp171 (Marinair LO1166 DC Blocker trasparente 0.01 dB sub-bass, Triode Dynamic Miller Effect con reattanza HF e B+ sag, compressore dinamico multi-stile con auto-makeup percettivo, interfaccia boutique con doppio oscilloscopio a 60 FPS).

Sito Ufficiale: https://171studio.it
Supporto Tecnico: 171studioinnovatio@gmail.com
================================================================================
