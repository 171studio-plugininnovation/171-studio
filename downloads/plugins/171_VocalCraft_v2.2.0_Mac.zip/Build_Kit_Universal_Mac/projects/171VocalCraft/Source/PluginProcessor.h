#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include <dsp171/VocalCraftEngine.h>

class VocalCraftAudioProcessor : public juce::AudioProcessor {
public:
    VocalCraftAudioProcessor();
    ~VocalCraftAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "171VocalCraft"; }

    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int index) override { juce::ignoreUnused(index); }
    const juce::String getProgramName(int index) override { juce::ignoreUnused(index); return {}; }
    void changeProgramName(int index, const juce::String& newName) override { juce::ignoreUnused(index, newName); }

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }
    dsp171::VocalCraftEngine& getEngine() noexcept { return engine; }

    void triggerCalibration() noexcept {
        engine.triggerCalibration();
    }

    void setLookaheadMode(bool studioMixMode) noexcept {
        engine.setLookaheadMode(studioMixMode);
    }
    bool isLookaheadMode() const noexcept {
        return engine.isLookaheadMode();
    }

    void setDeltaMode(bool enabled) noexcept {
        deltaMode.store(enabled, std::memory_order_relaxed);
    }
    bool isDeltaMode() const noexcept {
        return deltaMode.load(std::memory_order_relaxed);
    }

    void setTargetProfile(int profileIndex) noexcept {
        targetProfile.store(std::clamp(profileIndex, 0, 3), std::memory_order_relaxed);
    }
    int getTargetProfile() const noexcept {
        return targetProfile.load(std::memory_order_relaxed);
    }

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    void updateEngineParameters() noexcept;

    juce::AudioProcessorValueTreeState apvts;
    dsp171::VocalCraftEngine engine;

    std::atomic<bool> deltaMode{ false };
    std::atomic<int>  targetProfile{ 0 };
    juce::AudioBuffer<float> inputDeltaBuffer;

    std::atomic<float>* compAmountParam = nullptr;
    std::atomic<float>* styleParam = nullptr;
    std::atomic<float>* linearizerDepthParam = nullptr;
    std::atomic<float>* consonantPunchParam = nullptr;
    std::atomic<float>* unmaskAmountParam = nullptr;
    std::atomic<float>* airSheenParam = nullptr;
    std::atomic<float>* deessAmountParam = nullptr;
    std::atomic<float>* clipperDriveParam = nullptr;
    std::atomic<float>* manualTrimParam = nullptr;
    std::atomic<float>* autoMakeupParam = nullptr;
    std::atomic<float>* bypassParam = nullptr;
    std::atomic<float>* studioLookaheadParam = nullptr;
    std::atomic<float>* plosiveSuppressionParam = nullptr;
    std::atomic<float>* plosiveSensitivityParam = nullptr;
    std::atomic<float>* debreatherAmountParam = nullptr;
    std::atomic<float>* debreatherReductionParam = nullptr;

    // Phase 2 Hardware Mojo & Mono-Safe Hilbert Stereo Parameters
    std::atomic<float>* mojoModelParam = nullptr;
    std::atomic<float>* mojoDriveParam = nullptr;
    std::atomic<float>* hilbertWidthParam = nullptr;
    std::atomic<float>* hilbertHpfParam = nullptr;

    // Phase 3 Multi-Track Vocal Cluster Synchronizer Parameters
    std::atomic<float>* clusterRoleParam = nullptr;
    std::atomic<float>* clusterChannelParam = nullptr;
    std::atomic<float>* clusterPocketDepthParam = nullptr;
    std::atomic<float>* clusterTightenParam = nullptr;

    // Delta Audition Alignment Ring-Buffer (matching engine lookahead latency)
    static constexpr size_t kDeltaRingCapacity = 2048;
    static constexpr size_t kDeltaRingMask = kDeltaRingCapacity - 1;
    std::array<float, kDeltaRingCapacity> deltaRingL{};
    std::array<float, kDeltaRingCapacity> deltaRingR{};
    size_t deltaRingWritePos = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalCraftAudioProcessor)
};
