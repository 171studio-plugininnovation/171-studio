#include "PluginProcessor.h"
#include "PluginEditor.h"

VocalCraftAudioProcessor::VocalCraftAudioProcessor()
    : AudioProcessor(BusesProperties()
                     .withInput("Input", juce::AudioChannelSet::stereo(), true)
                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)
                     .withInput("Beat Sidechain", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "Parameters", createParameterLayout())
{
    compAmountParam      = apvts.getRawParameterValue("comp_amount");
    styleParam           = apvts.getRawParameterValue("style");
    linearizerDepthParam = apvts.getRawParameterValue("linearizer_depth");
    consonantPunchParam  = apvts.getRawParameterValue("consonant_punch");
    unmaskAmountParam    = apvts.getRawParameterValue("unmask_amount");
    airSheenParam        = apvts.getRawParameterValue("air_sheen");
    deessAmountParam     = apvts.getRawParameterValue("deess_amount");
    clipperDriveParam    = apvts.getRawParameterValue("clipper_drive");
    manualTrimParam      = apvts.getRawParameterValue("manual_trim");
    autoMakeupParam          = apvts.getRawParameterValue("auto_makeup");
    bypassParam              = apvts.getRawParameterValue("bypass");
    studioLookaheadParam     = apvts.getRawParameterValue("studio_lookahead");
    plosiveSuppressionParam  = apvts.getRawParameterValue("plosive_suppression");
    plosiveSensitivityParam  = apvts.getRawParameterValue("plosive_sensitivity");
    debreatherAmountParam    = apvts.getRawParameterValue("debreather_amount");
    debreatherReductionParam = apvts.getRawParameterValue("debreather_reduction");

    mojoModelParam    = apvts.getRawParameterValue("mojo_model");
    mojoDriveParam    = apvts.getRawParameterValue("mojo_drive");
    hilbertWidthParam = apvts.getRawParameterValue("hilbert_width");
    hilbertHpfParam   = apvts.getRawParameterValue("hilbert_hpf");

    clusterRoleParam        = apvts.getRawParameterValue("cluster_role");
    clusterChannelParam     = apvts.getRawParameterValue("cluster_channel");
    clusterPocketDepthParam = apvts.getRawParameterValue("cluster_pocket_depth");
    clusterTightenParam     = apvts.getRawParameterValue("cluster_tighten");
}

VocalCraftAudioProcessor::~VocalCraftAudioProcessor() {}

juce::AudioProcessorValueTreeState::ParameterLayout VocalCraftAudioProcessor::createParameterLayout() {
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"comp_amount", 1},
        "Compression Amount",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f),
        50.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")
    ));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"style", 1},
        "Vocal Style",
        juce::StringArray{"Hip-Hop / Rap", "Modern Pop", "Trap / Drill", "R&B / Soul"},
        0
    ));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"linearizer_depth", 1},
        "Linearizer Neutrality",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f),
        85.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")
    ));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"consonant_punch", 1},
        "Consonant Punch",
        juce::NormalisableRange<float>(-6.0f, 6.0f, 0.1f),
        0.0f,
        juce::AudioParameterFloatAttributes().withLabel("dB")
    ));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"unmask_amount", 1},
        "Beat Unmask & Pocket",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f),
        60.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")
    ));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"air_sheen", 1},
        "Mix-Ready Air Sheen",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f),
        50.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")
    ));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"deess_amount", 1},
        "Pre-Drive De-Esser",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f),
        50.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")
    ));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"clipper_drive", 1},
        "Mastering Vocal Clipper",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f),
        35.0f,
        juce::AudioParameterFloatAttributes().withLabel("%")
    ));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"manual_trim", 1},
        "Input Manual Trim",
        juce::NormalisableRange<float>(-24.0f, 24.0f, 0.1f),
        0.0f,
        juce::AudioParameterFloatAttributes().withLabel("dB")
    ));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"auto_makeup", 1},
        "Perceptual Auto-Makeup",
        true
    ));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"bypass", 1},
        "Bypass",
        false
    ));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"studio_lookahead", 1},
        "Studio Lookahead (PDC)",
        false
    ));

    // Phase 1 Micro-Acoustics & Biological Cleaning Parameters (VocalCraft 3.0)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"plosive_suppression", 1},
        "Smart Plosive Annihilator",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f),
        0.0f, // Default 0% (100% retro-compatible)
        juce::AudioParameterFloatAttributes().withLabel("%")
    ));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"plosive_sensitivity", 1},
        "Plosive Sensitivity",
        juce::NormalisableRange<float>(-6.0f, 6.0f, 0.1f),
        0.0f,
        juce::AudioParameterFloatAttributes().withLabel("dB")
    ));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"debreather_amount", 1},
        "Neural De-Breather Amount",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f),
        0.0f, // Default 0% (100% retro-compatible)
        juce::AudioParameterFloatAttributes().withLabel("%")
    ));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"debreather_reduction", 1},
        "De-Breather Reduction",
        juce::NormalisableRange<float>(-24.0f, 0.0f, 0.1f),
        -7.5f,
        juce::AudioParameterFloatAttributes().withLabel("dB")
    ));

    // Phase 2 Hardware Mojo & Mono-Safe Hilbert Stereo Parameters (VocalCraft 3.0)
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"mojo_model", 1},
        "Hardware Mojo Model",
        juce::StringArray{"Modern Pure", "British 1073 Iron", "American Blue FET", "Scandinavian Tube CL1B"},
        0 // Default Modern Pure (100% retro-compatible)
    ));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"mojo_drive", 1},
        "Hardware Mojo Drive",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f),
        0.0f, // Default 0% (bit-exact passthrough)
        juce::AudioParameterFloatAttributes().withLabel("%")
    ));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"hilbert_width", 1},
        "Hilbert Stereo Width",
        juce::NormalisableRange<float>(0.0f, 200.0f, 0.1f),
        0.0f, // Default 0% (pure dry/original stereo, 100% retro-compatible)
        juce::AudioParameterFloatAttributes().withLabel("%")
    ));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"hilbert_hpf", 1},
        "Hilbert Side HPF",
        juce::NormalisableRange<float>(40.0f, 400.0f, 1.0f),
        160.0f, // Default 160 Hz (sub protection)
        juce::AudioParameterFloatAttributes().withLabel("Hz")
    ));

    // Phase 3 Multi-Track Vocal Cluster Synchronizer Parameters (VocalCraft 3.0)
    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"cluster_role", 1},
        "Vocal Cluster Role",
        juce::StringArray{"Off / Standalone", "Lead Conductor", "Satellite (Double/Backing)"},
        0 // Default Off / Standalone (100% retro-compatible)
    ));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"cluster_channel", 1},
        "Cluster Channel Group",
        juce::StringArray{"Group 1", "Group 2", "Group 3", "Group 4", "Group 5", "Group 6", "Group 7", "Group 8"},
        0 // Default Group 1
    ));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"cluster_pocket_depth", 1},
        "Cluster Pocket Depth",
        juce::NormalisableRange<float>(-8.0f, 0.0f, 0.1f),
        -3.5f,
        juce::AudioParameterFloatAttributes().withLabel("dB")
    ));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"cluster_tighten", 1},
        "Cluster Auto-Tighten",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f),
        0.0f, // Default 0% (passthrough)
        juce::AudioParameterFloatAttributes().withLabel("%")
    ));

    return { params.begin(), params.end() };
}

void VocalCraftAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock) {
    inputDeltaBuffer.setSize(2, 8192, false, true, true);
    deltaRingL.fill(0.0f);
    deltaRingR.fill(0.0f);
    deltaRingWritePos = 0;
    engine.prepare(sampleRate, samplesPerBlock);
    updateEngineParameters();
    setLatencySamples(engine.getLatencySamples());
}

void VocalCraftAudioProcessor::releaseResources() {
    engine.reset();
}

bool VocalCraftAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const {
    // Main input and output must match and be mono or stereo
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
        && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;

    // Auxiliary sidechain (Beat Input) can be disabled, mono, or stereo
    const auto sidechainSet = layouts.getChannelSet(true, 1);
    if (!sidechainSet.isDisabled()
        && sidechainSet != juce::AudioChannelSet::mono()
        && sidechainSet != juce::AudioChannelSet::stereo())
        return false;

    return true;
}

void VocalCraftAudioProcessor::updateEngineParameters() noexcept {
    if (compAmountParam != nullptr)
        engine.setCompressionAmount(compAmountParam->load(std::memory_order_relaxed) * 0.01f);

    if (styleParam != nullptr)
        engine.setStyle(static_cast<int>(styleParam->load(std::memory_order_relaxed)));

    if (linearizerDepthParam != nullptr)
        engine.setLinearizerDepth(linearizerDepthParam->load(std::memory_order_relaxed) * 0.01f);

    if (consonantPunchParam != nullptr)
        engine.setConsonantPunch(consonantPunchParam->load(std::memory_order_relaxed));

    if (unmaskAmountParam != nullptr)
        engine.setUnmaskAmount(unmaskAmountParam->load(std::memory_order_relaxed) * 0.01f);

    if (airSheenParam != nullptr)
        engine.setAirSheen(airSheenParam->load(std::memory_order_relaxed) * 0.01f);

    if (deessAmountParam != nullptr)
        engine.setDeessAmount(deessAmountParam->load(std::memory_order_relaxed) * 0.01f);

    if (clipperDriveParam != nullptr)
        engine.setClipperDrive(clipperDriveParam->load(std::memory_order_relaxed) * 0.01f);

    if (manualTrimParam != nullptr)
        engine.setManualTrimDb(manualTrimParam->load(std::memory_order_relaxed));

    if (autoMakeupParam != nullptr)
        engine.setAutoMakeupEnabled(autoMakeupParam->load(std::memory_order_relaxed) > 0.5f);

    if (bypassParam != nullptr)
        engine.setBypass(bypassParam->load(std::memory_order_relaxed) > 0.5f);

    if (studioLookaheadParam != nullptr) {
        const bool lookaheadOn = studioLookaheadParam->load(std::memory_order_relaxed) > 0.5f;
        engine.setLookaheadMode(lookaheadOn);
        const int targetLatency = engine.getLatencySamples();
        if (getLatencySamples() != targetLatency) {
            setLatencySamples(targetLatency);
        }
    }

    if (plosiveSuppressionParam != nullptr) {
        const float plosAmount = plosiveSuppressionParam->load(std::memory_order_relaxed) * 0.01f;
        const float plosSens = plosiveSensitivityParam ? plosiveSensitivityParam->load(std::memory_order_relaxed) : 0.0f;
        engine.setPlosiveParameters(plosAmount, plosSens, true);
    }

    if (debreatherAmountParam != nullptr) {
        const float debAmount = debreatherAmountParam->load(std::memory_order_relaxed) * 0.01f;
        const float debRed = debreatherReductionParam ? debreatherReductionParam->load(std::memory_order_relaxed) : -7.5f;
        engine.setDeBreatherParameters(debAmount, debRed, true);
    }

    if (mojoModelParam != nullptr) {
        const int modelIdx = static_cast<int>(mojoModelParam->load(std::memory_order_relaxed));
        engine.setHardwareMojoModel(modelIdx);
    }

    if (mojoDriveParam != nullptr) {
        const float drive = mojoDriveParam->load(std::memory_order_relaxed) * 0.01f;
        engine.setHardwareMojoDrive(drive);
    }

    if (hilbertWidthParam != nullptr) {
        const float width = hilbertWidthParam->load(std::memory_order_relaxed) * 0.01f;
        engine.setHilbertStereoWidth(width);
    }

    if (hilbertHpfParam != nullptr) {
        const float hpf = hilbertHpfParam->load(std::memory_order_relaxed);
        engine.setHilbertSideHpf(hpf);
    }

    if (clusterRoleParam != nullptr) {
        const int roleIdx = static_cast<int>(clusterRoleParam->load(std::memory_order_relaxed));
        dsp171::ClusterRole role = dsp171::ClusterRole::Disabled;
        if (roleIdx == 1) role = dsp171::ClusterRole::Lead;
        else if (roleIdx == 2) role = dsp171::ClusterRole::Satellite;
        engine.setClusterRole(role);
    }

    if (clusterChannelParam != nullptr) {
        const int ch = static_cast<int>(clusterChannelParam->load(std::memory_order_relaxed)) + 1;
        engine.setClusterChannel(ch);
    }

    if (clusterPocketDepthParam != nullptr) {
        const float depth = clusterPocketDepthParam->load(std::memory_order_relaxed);
        engine.setClusterPocketDepthDb(depth);
    }

    if (clusterTightenParam != nullptr) {
        const float tighten = clusterTightenParam->load(std::memory_order_relaxed) * 0.01f;
        engine.setClusterTighten(tighten);
    }
}

void VocalCraftAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages) {
    juce::ignoreUnused(midiMessages);
    juce::ScopedNoDenormals noDenormals;

    updateEngineParameters();

    if (auto* playHead = getPlayHead()) {
        if (auto posOpt = playHead->getPosition()) {
            if (posOpt->getTimeInSamples().hasValue()) {
                const int64_t posInSamples = *(posOpt->getTimeInSamples());
                if (posInSamples >= 0) {
                    engine.setTimelineSamplePosition(static_cast<uint64_t>(posInSamples));
                }
            }
        }
    }

    const int curLat = engine.getLatencySamples();
    if (getLatencySamples() != curLat) {
        setLatencySamples(curLat);
    }

    const int numSamples = buffer.getNumSamples();
    if (numSamples == 0) return;

    auto mainBus = getBusBuffer(buffer, true, 0);
    auto sidechainBus = getBusBuffer(buffer, true, 1);

    const float* const* beatPointers = nullptr;
    int beatChannels = 0;
    if (sidechainBus.getNumChannels() > 0 && !getChannelLayoutOfBus(true, 1).isDisabled()) {
        beatPointers = sidechainBus.getArrayOfReadPointers();
        beatChannels = sidechainBus.getNumChannels();
    }

    const bool isDelta = deltaMode.load(std::memory_order_relaxed);
    if (isDelta) {
        const int numDeltaSamples = std::min(numSamples, inputDeltaBuffer.getNumSamples());
        const int numChannels = std::min(mainBus.getNumChannels(), inputDeltaBuffer.getNumChannels());
        const int lat = engine.getLatencySamples();
        if (lat > 0) {
            const float* inL = mainBus.getReadPointer(0);
            const float* inR = (numChannels > 1) ? mainBus.getReadPointer(1) : inL;
            float* outDeltaL = inputDeltaBuffer.getWritePointer(0);
            float* outDeltaR = inputDeltaBuffer.getWritePointer(std::min(1, inputDeltaBuffer.getNumChannels() - 1));
            for (int i = 0; i < numDeltaSamples; ++i) {
                deltaRingL[deltaRingWritePos] = inL[i];
                deltaRingR[deltaRingWritePos] = inR[i];
                const size_t rPos = (deltaRingWritePos + kDeltaRingCapacity - static_cast<size_t>(lat)) & kDeltaRingMask;
                outDeltaL[i] = deltaRingL[rPos];
                outDeltaR[i] = deltaRingR[rPos];
                deltaRingWritePos = (deltaRingWritePos + 1) & kDeltaRingMask;
            }
        } else {
            for (int ch = 0; ch < numChannels; ++ch)
                inputDeltaBuffer.copyFrom(ch, 0, mainBus, ch, 0, numDeltaSamples);
        }
    }

    engine.processWithBeat(mainBus.getArrayOfWritePointers(), mainBus.getNumChannels(),
                           beatPointers, beatChannels, numSamples);

    if (isDelta) {
        const int numDeltaSamples = std::min(numSamples, inputDeltaBuffer.getNumSamples());
        const int numChannels = std::min(mainBus.getNumChannels(), inputDeltaBuffer.getNumChannels());
        for (int ch = 0; ch < numChannels; ++ch) {
            float* w = mainBus.getWritePointer(ch);
            const float* in = inputDeltaBuffer.getReadPointer(ch);
            for (int i = 0; i < numDeltaSamples; ++i) {
                // In - Out = residual suppressed harsh resonances (boosted 6 dB for clear listening)
                w[i] = (in[i] - w[i]) * 2.0f;
            }
        }
    }
}

juce::AudioProcessorEditor* VocalCraftAudioProcessor::createEditor() {
    return new VocalCraftAudioProcessorEditor(*this);
}

void VocalCraftAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void VocalCraftAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState.get() != nullptr && xmlState->hasTagName(apvts.state.getType())) {
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
    }
}

// JUCE Plugin Factory
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new VocalCraftAudioProcessor();
}
