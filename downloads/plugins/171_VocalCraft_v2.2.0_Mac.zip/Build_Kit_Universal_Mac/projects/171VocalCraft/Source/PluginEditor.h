#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <BinaryData.h>
#include "PluginProcessor.h"
#include "GUI/CurvesEquatorTheme.h"
#include "GUI/CurvesEquatorVisualizer.h"
#include "GUI/CurvesCentralDial.h"
#include "GUI/CurvesLookAndFeel.h"
#include "GUI/CurvesBoutiqueButtons.h"

// ==============================================================================
// 171 VOCALCRAFT - HARDWARE AUDIO PROCESSOR EDITOR (JUCE 8 / 60 FPS)
// CURVES EQUATOR BOUTIQUE EDITION (ENHANCED TYPOGRAPHY & SCREEN CONTROLS)
// ==============================================================================
class VocalCraftAudioProcessorEditor : public juce::AudioProcessorEditor,
                                      public juce::ComboBox::Listener,
                                      public juce::Timer
{
public:
    explicit VocalCraftAudioProcessorEditor(VocalCraftAudioProcessor& p);
    ~VocalCraftAudioProcessorEditor() override;

    void paint(juce::Graphics& g) override;
    void resized() override;
    void timerCallback() override;
    void comboBoxChanged(juce::ComboBox* comboBoxThatHasChanged) override;

private:
    void setupKnobWithSub(juce::Slider& slider, juce::Label& title, const juce::String& titleText,
                          juce::Label& sub, const juce::String& subText,
                          gui171::CurvesLookAndFeel::KnobColorTheme theme, const juce::String& suffix = "");

    VocalCraftAudioProcessor& processor;

    // Look and Feel Boutique
    gui171::CurvesLookAndFeel curvesLookAndFeel;
    juce::TooltipWindow tooltipWindow { this, 350 };

    // --- Header Section ---
    juce::Label  presetTitleLabel;
    juce::ComboBox presetBox;
    juce::TextButton prevPresetBtn { "<" };
    juce::TextButton nextPresetBtn { ">" };

    // --- Hero Visualizer (Waves Curves Equator Spectral Canvas) ---
    gui171::CurvesEquatorVisualizer equatorVisualizer;

    // --- Centerpiece: Dominant Central Suppression Master Dial ---
    gui171::CurvesCentralDial centralSuppressionDial;
    juce::Label centralDialLabel;
    juce::Label centralDialSubLabel;

    // --- Left Flank: Detection, Neutrality & Learn ---
    gui171::CurvesLearnButton learnButton;

    juce::Slider linearizerKnob;
    juce::Label  linearizerLabel;
    juce::Label  linearizerSubLabel;

    juce::Slider manualTrimKnob;
    juce::Label  manualTrimLabel;
    juce::Label  manualTrimSubLabel;

    juce::Slider consonantKnob;
    juce::Label  consonantLabel;
    juce::Label  consonantSubLabel;

    juce::ComboBox styleBox;
    juce::Label    styleLabel;

    juce::Slider unmaskKnob;
    juce::Label  unmaskLabel;
    juce::Label  unmaskSubLabel;

    // --- Right Flank: Sculpting, Sheen, De-Esser & Mastering ---
    juce::Slider deessKnob;
    juce::Label  deessLabel;
    juce::Label  deessSubLabel;

    juce::Slider airSheenKnob;
    juce::Label  airSheenLabel;
    juce::Label  airSheenSubLabel;

    juce::Slider clipperKnob;
    juce::Label  clipperLabel;
    juce::Label  clipperSubLabel;

    gui171::CurvesBoutiqueToggle autoMakeupToggle { gui171::CurvesBoutiqueToggle::ToggleStyle::AutoMakeup, "AUTO MAKEUP" };
    gui171::CurvesBoutiqueToggle bypassToggle     { gui171::CurvesBoutiqueToggle::ToggleStyle::MasterBypass, "MASTER BYPASS" };

    gui171::CurvesDualBargraph outputBargraph;

    // --- APVTS Attachments ---
    using SliderAttachment   = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment   = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using ComboBoxAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    std::unique_ptr<SliderAttachment>   compAmountAttach;
    std::unique_ptr<SliderAttachment>   linearizerDepthAttach;
    std::unique_ptr<SliderAttachment>   consonantPunchAttach;
    std::unique_ptr<SliderAttachment>   airSheenAttach;
    std::unique_ptr<SliderAttachment>   deessAttach;
    std::unique_ptr<SliderAttachment>   unmaskAttach;
    std::unique_ptr<SliderAttachment>   clipperAttach;
    std::unique_ptr<SliderAttachment>   manualTrimAttach;
    std::unique_ptr<ComboBoxAttachment> styleAttach;
    std::unique_ptr<ButtonAttachment>   autoMakeupAttach;
    std::unique_ptr<ButtonAttachment>   bypassAttach;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalCraftAudioProcessorEditor)
};
