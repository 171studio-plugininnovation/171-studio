#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_graphics/juce_graphics.h>
#include <cmath>
#include "CurvesEquatorTheme.h"

namespace gui171 {

// ==============================================================================
// 171 VOCALCRAFT - CURVES EQUATOR DOMINANT CENTRAL MASTER DIAL
// The centerpiece of the plugin:
// - Heavy weighted 150x150 mm boutique rotary dial
// - 36-tooth precision CNC diamond knurled skirt
// - Glowing electric cyan / amber dual-mode neon arc
// - Smoked glass central OLED displaying dynamic reduction readout
// - Fully compatible with JUCE Slider & APVTS SliderAttachment
// ==============================================================================
class CurvesCentralDial : public juce::Slider {
public:
    CurvesCentralDial() {
        setSliderStyle(juce::Slider::RotaryVerticalDrag);
        setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        setRotaryParameters(juce::MathConstants<float>::pi * 1.25f,
                            juce::MathConstants<float>::pi * 2.75f,
                            true);
        setRange(0.0, 100.0, 0.1);
        setValue(50.0);
        setDoubleClickReturnValue(true, 50.0);
        setOpaque(false);
    }

    ~CurvesCentralDial() override = default;

    void setRealtimeReductionDb(float redDb) noexcept {
        currentRedDb = redDb;
    }

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat();
        if (bounds.isEmpty()) return;

        const float diameter = std::min(bounds.getWidth(), bounds.getHeight()) - 8.0f;
        const float cx = bounds.getCentreX();
        const float cy = bounds.getCentreY();
        const float rBase = diameter * 0.5f;

        const auto rotaryParams = getRotaryParameters();
        const float startAngle  = rotaryParams.startAngleRadians;
        const float endAngle    = rotaryParams.endAngleRadians;
        const float normVal     = static_cast<float>(valueToProportionOfLength(getValue()));
        const float curAngle    = startAngle + normVal * (endAngle - startAngle);

        // ----------------------------------------------------------------------
        // 1. OMBRA PORTATA SUL TELAIO (Luce zenitale fissa ore 10:30)
        // ----------------------------------------------------------------------
        g.setColour(juce::Colours::black.withAlpha(0.70f));
        g.fillEllipse(cx - rBase + 3.0f, cy - rBase + 6.0f, rBase * 2.0f, rBase * 2.0f);

        // ----------------------------------------------------------------------
        // 2. SCALA CIRCOLARE GRADUATA CON PISTA INCASSATA
        // ----------------------------------------------------------------------
        const float rTrack = rBase - 2.0f;

        // Pista scura incassata
        juce::Path trackPath;
        trackPath.addCentredArc(cx, cy, rTrack, rTrack, 0.0f, startAngle, endAngle, true);
        g.setColour(juce::Colour(0xff090c12));
        g.strokePath(trackPath, juce::PathStrokeType(6.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // ----------------------------------------------------------------------
        // 3. ARCO ATTIVO LUMINOSO NEON (Electric Cyan -> Golden Amber se > 50%)
        // ----------------------------------------------------------------------
        if (normVal > 0.005f) {
            juce::Path activePath;
            activePath.addCentredArc(cx, cy, rTrack, rTrack, 0.0f, startAngle, curAngle, true);

            // Colore dinamico: da ciano puro (#00F0FF) ad ambra/oro (#FFB800) ad alta compressione
            juce::Colour arcNeon = (normVal < 0.65f)
                ? CurvesTheme::cyanElectric
                : CurvesTheme::cyanElectric.interpolatedWith(CurvesTheme::goldPrimary, (normVal - 0.65f) / 0.35f);

            // Bagliore bloom esterno
            g.setColour(arcNeon.withAlpha(0.28f));
            g.strokePath(activePath, juce::PathStrokeType(12.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Linea centrale incandescente
            g.setColour(arcNeon);
            g.strokePath(activePath, juce::PathStrokeType(4.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Core bianco brillante
            g.setColour(juce::Colours::white.withAlpha(0.85f));
            g.strokePath(activePath, juce::PathStrokeType(1.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }

        // Tacche serigrafate calibrate (21 micro-tacche con tacche maggiori dorate)
        constexpr int numTicks = 21;
        const float rTickIn = rTrack + 6.0f;
        for (int i = 0; i < numTicks; ++i) {
            float frac = static_cast<float>(i) / static_cast<float>(numTicks - 1);
            float a = startAngle + frac * (endAngle - startAngle);
            bool isMajor = (i % 5 == 0);
            float tickLen = isMajor ? 6.0f : 3.5f;

            float x1 = cx + std::sin(a) * rTickIn;
            float y1 = cy - std::cos(a) * rTickIn;
            float x2 = cx + std::sin(a) * (rTickIn + tickLen);
            float y2 = cy - std::cos(a) * (rTickIn + tickLen);

            if (frac <= normVal && normVal > 0.005f) {
                g.setColour(CurvesTheme::cyanElectric.brighter(0.2f));
            } else {
                g.setColour(isMajor ? CurvesTheme::goldLaserHairline : CurvesTheme::textDim);
            }
            g.drawLine(x1, y1, x2, y2, isMajor ? 1.8f : 1.0f);
        }

        // ----------------------------------------------------------------------
        // 4. GONNA CILINDRICA ZIGRINATA IN TITANIO (KNURLED SKIRT 36 DENTI)
        // ----------------------------------------------------------------------
        const float rSkirt = rBase * 0.78f;

        juce::ColourGradient skirtGrad(
            CurvesTheme::metalSkirtLight, cx - rSkirt, cy - rSkirt,
            CurvesTheme::metalSkirtDark, cx + rSkirt, cy + rSkirt, false);
        g.setGradientFill(skirtGrad);
        g.fillEllipse(cx - rSkirt, cy - rSkirt, rSkirt * 2.0f, rSkirt * 2.0f);

        // 36 dentellature CNC diamantate
        constexpr int numKnurlTeeth = 36;
        for (int i = 0; i < numKnurlTeeth; ++i) {
            float toothAngle = (static_cast<float>(i) / numKnurlTeeth) * juce::MathConstants<float>::twoPi;
            float cosA = std::cos(toothAngle);
            float sinA = std::sin(toothAngle);

            float xIn  = cx + sinA * (rSkirt - 3.5f);
            float yIn  = cy - cosA * (rSkirt - 3.5f);
            float xOut = cx + sinA * rSkirt;
            float yOut = cy - cosA * rSkirt;

            bool isLit = (sinA - cosA) < 0.2f;
            g.setColour(isLit ? juce::Colour(0x60ffffff) : juce::Colour(0x90000000));
            g.drawLine(xIn, yIn, xOut, yOut, 1.4f);
        }

        // ----------------------------------------------------------------------
        // 5. OBLO' SMOKED-GLASS CENTRALE CON DISPLAY DIGITALE OLED
        // ----------------------------------------------------------------------
        const float rDisplay = rSkirt * 0.76f;

        // Cornice in metallo scuro lucido
        g.setColour(CurvesTheme::metalRimBezel);
        g.drawEllipse(cx - rDisplay, cy - rDisplay, rDisplay * 2.0f, rDisplay * 2.0f, 2.0f);

        // Fondo vetro fumé nero ossidiana profondo
        juce::ColourGradient oledGrad(
            CurvesTheme::displayGlassDark, cx, cy - rDisplay,
            juce::Colour(0xff06070a), cx, cy + rDisplay, false);
        g.setGradientFill(oledGrad);
        g.fillEllipse(cx - rDisplay, cy - rDisplay, rDisplay * 2.0f, rDisplay * 2.0f);

        // Bordo interno dorato sottilissimo
        g.setColour(CurvesTheme::goldPrimary.withAlpha(0.35f));
        g.drawEllipse(cx - rDisplay + 1.0f, cy - rDisplay + 1.0f, (rDisplay - 1.0f) * 2.0f, (rDisplay - 1.0f) * 2.0f, 0.8f);

        // Riflesso speculare della curvatura del vetro
        g.setColour(juce::Colours::white.withAlpha(0.08f));
        g.fillEllipse(cx - rDisplay * 0.75f, cy - rDisplay * 0.85f, rDisplay * 1.5f, rDisplay * 0.85f);

        // ----------------------------------------------------------------------
        // 6. TIPOGRAFIA DIGITALE DENTRO L'OBLO'
        // ----------------------------------------------------------------------
        // Etichetta superiore "SUPPRESSION"
        g.setFont(juce::FontOptions(10.5f, juce::Font::bold));
        g.setColour(CurvesTheme::goldPrimary);
        g.drawText("SUPPRESSION", juce::Rectangle<float>(cx - rDisplay, cy - 28.0f, rDisplay * 2.0f, 14.0f),
                   juce::Justification::centred, false);

        // Grande valore numerico percentuale o dB
        g.setFont(juce::FontOptions(22.0f, juce::Font::bold));
        g.setColour(CurvesTheme::cyanElectric);
        juce::String valStr = juce::String(getValue(), 1) + "%";
        g.drawText(valStr, juce::Rectangle<float>(cx - rDisplay, cy - 12.0f, rDisplay * 2.0f, 26.0f),
                   juce::Justification::centred, false);

        // Etichetta inferiore: stato o soppressione dB
        g.setFont(juce::FontOptions(9.0f, juce::Font::bold));
        juce::String subStr = (currentRedDb > 0.1f)
            ? "-" + juce::String(currentRedDb, 1) + " dB GR"
            : "EQUATOR TRACK";
        g.setColour(CurvesTheme::textMuted);
        g.drawText(subStr, juce::Rectangle<float>(cx - rDisplay, cy + 15.0f, rDisplay * 2.0f, 13.0f),
                   juce::Justification::centred, false);

        // ----------------------------------------------------------------------
        // 7. PUNTO INDICATORE MECCANICO SULLA CORONA ESTERNA
        // ----------------------------------------------------------------------
        const float rPip = rSkirt - 5.0f;
        float pipX = cx + std::sin(curAngle) * rPip;
        float pipY = cy - std::cos(curAngle) * rPip;

        // Alone neon sull'indicatore
        g.setColour(CurvesTheme::cyanElectric.withAlpha(0.6f));
        g.fillEllipse(pipX - 4.5f, pipY - 4.5f, 9.0f, 9.0f);

        // Core bianco luminoso
        g.setColour(juce::Colours::white);
        g.fillEllipse(pipX - 2.5f, pipY - 2.5f, 5.0f, 5.0f);
    }

private:
    float currentRedDb = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(CurvesCentralDial)
};

} // namespace gui171
