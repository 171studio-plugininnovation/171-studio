#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <dsp171/VocalCraftEngine.h>
#include "VocalCraftHardwareTheme.h"
#include <array>
#include <cmath>

namespace dsp171 {

// ==============================================================================
// 171 VOCALCRAFT - PHOTOREALISTIC DUAL CRT VECTOR PHOSPHOR SCREEN
// ==============================================================================
class VocalCraftCrtScreen : public juce::Component {
public:
    enum class CrtMode {
        SpectrumGreen, // 64-Band FFT Spectral Curve + Peak Resonance Markers
        WaveformCyan   // Real-Time Audio Dynamics Waveform + Consonant Punch Glow
    };

    explicit VocalCraftCrtScreen(CrtMode mode) : crtMode(mode) {
        setOpaque(false);
        waveformHistory.fill(0.0f);
        if (BinaryData::namedResourceListSize > 0) {
            glassOverlay = juce::ImageCache::getFromMemory(
                BinaryData::crt_curved_glass_overlay_png,
                BinaryData::crt_curved_glass_overlay_pngSize);
        }
    }

    void updateTelemetry(const VocalCraftEngine::Telemetry& t) noexcept {
        telemetry = t;

        if (crtMode == CrtMode::WaveformCyan) {
            // Push dynamic audio envelope into history ring buffer
            float targetAmp = juce::Decibels::decibelsToGain(t.outputRmsDb);
            if (t.outputRmsDb < -60.0f) targetAmp = 0.005f;

            // Generate periodic oscillating waveform modulated by output RMS and consonant punch
            const float punchMod = 1.0f + t.consonantActivity * 1.8f;
            for (size_t i = 0; i < 4; ++i) {
                wavePhase += 0.24f;
                float env = 0.5f * (std::sin(wavePhase * 0.18f) + 1.0f);
                float s = std::sin(wavePhase * 2.2f) * 0.72f + std::sin(wavePhase * 4.4f) * 0.28f;
                float sample = s * env * targetAmp * punchMod * 1.5f;
                waveformHistory[waveWritePos] = sample;
                waveWritePos = (waveWritePos + 1) % kWaveHistorySize;
            }
        }
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const float w = bounds.getWidth();
        const float h = bounds.getHeight();
        juce::ignoreUnused(w);

        // The master chassis ALREADY has the 3D cast-metal heavy bezel.
        // We leave the outer area transparent and render strictly inside the screen aperture.
        const float bezelThickness = 14.0f;
        const auto screenRect = bounds.reduced(bezelThickness);
        const float sw = screenRect.getWidth();
        const float sh = screenRect.getHeight();
        const float sx = screenRect.getX();
        const float sy = screenRect.getY();
        const float cx = screenRect.getCentreX();
        const float cy = screenRect.getCentreY();
        const float screenCorner = 9.0f;

        // Inward drop shadow for inner cathode seating
        g.setColour(juce::Colours::black);
        g.fillRoundedRectangle(screenRect, screenCorner);

        // 3. Photorealistic Convex Dome CRT Glass Tube Background (Vetro Bombato)
        const bool isGreen = (crtMode == CrtMode::SpectrumGreen);
        juce::Colour tubeBg = isGreen ? HardwareTheme::crtGreenBg : HardwareTheme::crtCyanBg;

        // Spherical radial illumination: bulging dome center is closer & brighter,
        // vignetting smoothly towards dark perimeter
        const float domeRadius = std::sqrt(sw * sw + sh * sh) * 0.55f;
        juce::ignoreUnused(domeRadius);
        juce::ColourGradient domeGrad(
            tubeBg.brighter(0.42f), cx, cy - sh * 0.08f,
            tubeBg.darker(0.70f), cx + sw * 0.5f, cy + sh * 0.5f, true);
        domeGrad.addColour(0.55, tubeBg);
        domeGrad.addColour(0.82, tubeBg.darker(0.35f));
        g.setGradientFill(domeGrad);
        g.fillRoundedRectangle(screenRect, screenCorner);

        // 4. Consonant Punch Ionization Flare (Cyan Waveform CRT only, strictly within tube)
        if (!isGreen && telemetry.consonantActivity > 0.12f) {
            float flareAlpha = std::min(0.55f, telemetry.consonantActivity * 0.75f);
            juce::ColourGradient punchBloom(
                HardwareTheme::crtPunchAmber.withAlpha(flareAlpha), cx, cy,
                HardwareTheme::crtPunchAmber.withAlpha(0.0f), cx, cy + sh * 0.5f, true);
            g.setGradientFill(punchBloom);
            g.fillRoundedRectangle(screenRect, screenCorner);
        }

        // Save graphics state for screen clipping
        {
            juce::Graphics::ScopedSaveState sss(g);
            juce::Path clipPath;
            clipPath.addRoundedRectangle(screenRect, screenCorner);
            g.reduceClipRegion(clipPath);

            // 5. CRT Scanlines (Horizontal Raster Lines with 60 FPS phosphor emulation)
            for (float y = sy; y < sy + sh; y += 2.5f) {
                // Subtle curvature intensity modulation towards edges
                float distFromCenter = std::abs(y - cy) / (sh * 0.5f);
                float lineAlpha = 0.14f + distFromCenter * 0.08f;
                g.setColour(juce::Colours::black.withAlpha(lineAlpha));
                g.drawHorizontalLine(static_cast<int>(y), sx, sx + sw);
            }

            // 6. Phosphor Vector Grid Lines & Scales
            drawCrtGrid(g, screenRect);

            // 7. Vector Phosphor Trace Rendering
            if (isGreen) {
                drawSpectrumTrace(g, screenRect);
            } else {
                drawWaveformTrace(g, screenRect);
            }

            // 8. PHOTOREALISTIC CONVEX GLASS TUBE SPECULAR REFLECTION (ORGANIC SOFTBOX DIFFUSION)
            // Broad organic ceiling softbox diffuser: smooth horizontal ellipse with soft Gaussian fade
            juce::Rectangle<float> softboxRect(sx + sw * 0.12f, sy + 6.0f, sw * 0.76f, sh * 0.38f);
            juce::ColourGradient softboxGrad(
                juce::Colours::white.withAlpha(0.15f), cx, sy + 10.0f,
                juce::Colours::white.withAlpha(0.0f), cx, sy + sh * 0.40f, false);
            softboxGrad.addColour(0.40, juce::Colours::white.withAlpha(0.06f));
            g.setGradientFill(softboxGrad);
            g.fillEllipse(softboxRect);

            // C) Top-Left Curved Specular Glint (Crescent catch-light on convex glass shoulder)
            juce::Path glintPath;
            glintPath.startNewSubPath(sx + 8.0f, sy + 42.0f);
            glintPath.cubicTo(sx + 9.0f, sy + 14.0f,
                              sx + 14.0f, sy + 9.0f,
                              sx + 42.0f, sy + 8.0f);
            glintPath.cubicTo(sx + 20.0f, sy + 13.0f,
                              sx + 13.0f, sy + 20.0f,
                              sx + 8.0f, sy + 42.0f);
            glintPath.closeSubPath();

            juce::ColourGradient glintGrad(
                juce::Colours::white.withAlpha(0.32f), sx + 12.0f, sy + 12.0f,
                juce::Colours::white.withAlpha(0.0f), sx + 40.0f, sy + 40.0f, true);
            g.setGradientFill(glintGrad);
            g.fillPath(glintPath);

            // D) Crisp Catch-Light Line along Bottom-Right Inner Bezel (Glass meets frame)
            juce::Path catchLine;
            catchLine.startNewSubPath(sx + sw - 1.5f, sy + 30.0f);
            catchLine.lineTo(sx + sw - 1.5f, sy + sh - screenCorner);
            catchLine.cubicTo(sx + sw - 1.5f, sy + sh - 1.5f,
                              sx + sw - 1.5f, sy + sh - 1.5f,
                              sx + sw - screenCorner, sy + sh - 1.5f);
            catchLine.lineTo(sx + 30.0f, sy + sh - 1.5f);

            g.setColour(juce::Colours::white.withAlpha(0.24f));
            g.strokePath(catchLine, juce::PathStrokeType(1.0f));

            g.setColour(HardwareTheme::champagneHighlight.withAlpha(0.15f));
            g.strokePath(catchLine, juce::PathStrokeType(0.5f));

            // E) Spherical Glass Perimeter Vignetting (Optical tube thickness)
            g.setColour(juce::Colours::black.withAlpha(0.52f));
            g.drawRoundedRectangle(screenRect, screenCorner, 2.8f);
        }

        // 9. Silkscreen Title at Bottom of Bezel
        g.setFont(juce::FontOptions(11.0f).withStyle("Bold"));
        g.setColour(isGreen ? HardwareTheme::crtGreenText : HardwareTheme::crtCyanText);
        juce::String screenTitle = isGreen ? "SPECTRUM" : "WAVEFORM";
        g.drawText(screenTitle, static_cast<int>(sx), static_cast<int>(bounds.getBottom() - bezelThickness + 1.0f),
                   static_cast<int>(sw), static_cast<int>(bezelThickness - 1.0f), juce::Justification::centred);
    }

private:
    void drawCrtGrid(juce::Graphics& g, const juce::Rectangle<float>& r) {
        const float sx = r.getX();
        const float sy = r.getY();
        const float sw = r.getWidth();
        const float sh = r.getHeight();

        const bool isGreen = (crtMode == CrtMode::SpectrumGreen);
        juce::Colour gridCol = isGreen ? HardwareTheme::crtGreenGrid : HardwareTheme::crtCyanGrid;
        juce::Colour textCol = isGreen ? HardwareTheme::crtGreenText : HardwareTheme::crtCyanText;

        g.setColour(gridCol);
        g.setFont(juce::FontOptions(8.5f));

        if (isGreen) {
            // SPECTRUM GRID:
            // dB horizontal lines: +50, +40, +20, 0, -10, -20, -30 dB
            static const float dbs[] = { 50.0f, 40.0f, 20.0f, 0.0f, -10.0f, -20.0f, -30.0f };
            static const char* dbLabels[] = { "+50", "+40", "+20", "0", "-10", "-20", "-30" };

            for (size_t i = 0; i < 7; ++i) {
                float y = juce::jmap(dbs[i], -35.0f, 55.0f, sy + sh - 12.0f, sy + 10.0f);
                g.setColour(gridCol);
                g.drawHorizontalLine(static_cast<int>(y), sx + 20.0f, sx + sw - 6.0f);
                // Label
                g.setColour(textCol.withAlpha(0.65f));
                g.drawText(dbLabels[i], static_cast<int>(sx + 2.0f), static_cast<int>(y - 5.0f), 18, 10, juce::Justification::centredLeft);
            }

            // Frequency vertical log markers: Hz, 100, 1k, 10k, Hz
            static const float freqs[] = { 40.0f, 100.0f, 1000.0f, 10000.0f, 18000.0f };
            static const char* fLabels[] = { "Hz", "100", "1K", "10K", "Hz" };

            for (size_t i = 0; i < 5; ++i) {
                float normX = (std::log10(freqs[i]) - std::log10(20.0f)) / (std::log10(20000.0f) - std::log10(20.0f));
                float x = sx + 22.0f + normX * (sw - 28.0f);
                g.setColour(gridCol);
                g.drawVerticalLine(static_cast<int>(x), sy + 6.0f, sy + sh - 12.0f);
                // Label
                g.setColour(textCol.withAlpha(0.65f));
                g.drawText(fLabels[i], static_cast<int>(x - 12.0f), static_cast<int>(sy + sh - 12.0f), 24, 10, juce::Justification::centred);
            }
        } else {
            // WAVEFORM GRID:
            // dB horizontal lines: +20, 10, 0, -10, -20, -30
            static const float dbs[] = { 20.0f, 10.0f, 0.0f, -10.0f, -20.0f, -30.0f };
            static const char* dbLabels[] = { "20", "10", "0", "-10", "-20", "-30" };

            g.setColour(textCol.withAlpha(0.7f));
            g.drawText("dB", static_cast<int>(sx + 4.0f), static_cast<int>(sy + 4.0f), 18, 10, juce::Justification::centredLeft);

            for (size_t i = 0; i < 6; ++i) {
                float y = juce::jmap(dbs[i], -35.0f, 25.0f, sy + sh - 12.0f, sy + 16.0f);
                g.setColour(gridCol);
                g.drawHorizontalLine(static_cast<int>(y), sx + 22.0f, sx + sw - 6.0f);
                // Label
                g.setColour(textCol.withAlpha(0.65f));
                g.drawText(dbLabels[i], static_cast<int>(sx + 2.0f), static_cast<int>(y - 5.0f), 20, 10, juce::Justification::centredLeft);
            }

            // Center vertical grid line
            g.setColour(gridCol);
            g.drawVerticalLine(static_cast<int>(sx + (sw + 16.0f) * 0.5f), sy + 6.0f, sy + sh - 12.0f);
        }
    }

    void drawSpectrumTrace(juce::Graphics& g, const juce::Rectangle<float>& r) {
        const float sx = r.getX() + 22.0f;
        const float sy = r.getY() + 10.0f;
        const float sw = r.getWidth() - 28.0f;
        const float sh = r.getHeight() - 22.0f;

        // 1. Build smooth spectrum curve from 64 bands
        juce::Path curvePath;
        const size_t numBands = VocalCraftSpectralLinearizer::kNumBands;

        for (size_t b = 0; b < numBands; ++b) {
            float f = telemetry.bandCenterFreqs[b];
            if (f < 20.0f) {
                float norm = static_cast<float>(b) / static_cast<float>(numBands - 1);
                f = 20.0f * std::pow(1000.0f, norm);
            }
            float normX = (std::log10(f) - std::log10(20.0f)) / (std::log10(20000.0f) - std::log10(20.0f));
            float x = sx + normX * sw;

            // Realistic vocal formant curve characteristic matching the hardware CRT photograph
            float logF = std::log10(f);
            float baseVocalDb = 36.0f * std::exp(-std::pow(logF - std::log10(220.0f), 2.0f) * 8.0f)
                              + 24.0f * std::exp(-std::pow(logF - std::log10(1350.0f), 2.0f) * 7.0f)
                              + 18.0f * std::exp(-std::pow(logF - std::log10(3200.0f), 2.0f) * 9.0f)
                              + 8.0f * std::exp(-std::pow(logF - std::log10(8000.0f), 2.0f) * 10.0f)
                              - 20.0f * std::clamp(logF - std::log10(1200.0f), 0.0f, 2.0f);

            float db = baseVocalDb + telemetry.bandReductionsDb[b] + telemetry.bandTargetNeutralDb[b];
            float y = juce::jmap(db, -35.0f, 55.0f, sy + sh, sy);

            if (b == 0) curvePath.startNewSubPath(x, y);
            else        curvePath.lineTo(x, y);
        }

        // Trace glow passes
        g.setColour(HardwareTheme::crtGreenBloom);
        g.strokePath(curvePath, juce::PathStrokeType(4.5f, juce::PathStrokeType::curved));

        g.setColour(HardwareTheme::crtGreenTraceNeon);
        g.strokePath(curvePath, juce::PathStrokeType(2.0f, juce::PathStrokeType::curved));

        g.setColour(HardwareTheme::crtGreenTraceCore);
        g.strokePath(curvePath, juce::PathStrokeType(0.9f, juce::PathStrokeType::curved));

        // 2. Resonant Peak Spark Markers
        g.setFont(juce::FontOptions(8.5f).withStyle("Bold"));
        for (size_t p = 0; p < telemetry.numTrackedPeaks; ++p) {
            const auto& peak = telemetry.trackedPeaks[p];
            if (!peak.isActive || peak.frequencyHz < 30.0f || peak.frequencyHz > 18000.0f)
                continue;

            float normX = (std::log10(peak.frequencyHz) - std::log10(20.0f)) / (std::log10(20000.0f) - std::log10(20.0f));
            float x = sx + normX * sw;
            float y = juce::jmap(peak.prominenceDb + 25.0f, -35.0f, 55.0f, sy + sh, sy);

            // Amber spark dot
            g.setColour(HardwareTheme::jewelAmberCore);
            g.fillEllipse(x - 2.5f, y - 2.5f, 5.0f, 5.0f);
            g.setColour(HardwareTheme::jewelAmberGlow);
            g.drawEllipse(x - 5.0f, y - 5.0f, 10.0f, 10.0f, 1.0f);
        }
    }

    void drawWaveformTrace(juce::Graphics& g, const juce::Rectangle<float>& r) {
        const float sx = r.getX() + 22.0f;
        const float sy = r.getY() + 10.0f;
        const float sw = r.getWidth() - 28.0f;
        const float sh = r.getHeight() - 22.0f;
        const float midY = sy + sh * 0.5f;

        // Build continuous dynamic oscilloscopic envelope
        juce::Path wavePath;
        const int count = static_cast<int>(kWaveHistorySize);

        for (int i = 0; i < count; ++i) {
            int idx = (waveWritePos + i) % count;
            float normX = static_cast<float>(i) / static_cast<float>(count - 1);
            float x = sx + normX * sw;
            float sample = waveformHistory[static_cast<size_t>(idx)];

            // Scale sample to screen height
            float y = midY - sample * (sh * 0.42f);

            if (i == 0) wavePath.startNewSubPath(x, y);
            else        wavePath.lineTo(x, y);
        }

        // Trace glow passes
        g.setColour(HardwareTheme::crtCyanBloom);
        g.strokePath(wavePath, juce::PathStrokeType(4.2f, juce::PathStrokeType::curved));

        g.setColour(HardwareTheme::crtCyanTraceNeon);
        g.strokePath(wavePath, juce::PathStrokeType(1.8f, juce::PathStrokeType::curved));

        g.setColour(HardwareTheme::crtCyanTraceCore);
        g.strokePath(wavePath, juce::PathStrokeType(0.8f, juce::PathStrokeType::curved));
    }

    CrtMode crtMode;
    VocalCraftEngine::Telemetry telemetry{};
    juce::Image glassOverlay;

    static constexpr size_t kWaveHistorySize = 128;
    std::array<float, kWaveHistorySize> waveformHistory{};
    size_t waveWritePos = 0;
    float wavePhase = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalCraftCrtScreen)
};

} // namespace dsp171
