#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_graphics/juce_graphics.h>

namespace gui171 {

// ==============================================================================
// 171 VOCALCRAFT - CURVES EQUATOR BOUTIQUE PALETTE & DESIGN SYSTEM
// Inspired by Waves Curves Equator, 171SpaceLuxe, and 171PerfectPre.
// High-tech obsidian carbon, laser-cut gold serigraphy, electric neon cyan flows.
// ==============================================================================
struct CurvesTheme {
    // Canvas & Chassis
    static inline const juce::Colour bgChassisOuter      { 0xff090b0f };
    static inline const juce::Colour bgChassisInner      { 0xff12151d };
    static inline const juce::Colour displayGlassDark    { 0xff080a0e };
    static inline const juce::Colour displayGlassSheen   { 0xff161b26 };
    static inline const juce::Colour panelBezelBorder    { 0xff252b3b };

    // Gold / Brass Master Accents (171 Studio Signature)
    static inline const juce::Colour goldPrimary         { 0xfff0c43f };
    static inline const juce::Colour goldBright          { 0xffffe873 };
    static inline const juce::Colour goldDeep            { 0xff9c781e };
    static inline const juce::Colour goldLaserHairline   { 0xffd4af37 };
    static inline const juce::Colour goldBezelShadow     { 0xff3b2e10 };

    // Equator Signature Yellow
    static inline const juce::Colour equatorYellow       { 0xfff7d028 };
    static inline const juce::Colour equatorYellowGlow   { 0x55ffd933 };

    // Electric Cyan Resonance Suppression (Waves Curves Signature)
    static inline const juce::Colour cyanElectric        { 0xff00f0ff };
    static inline const juce::Colour cyanDeepTeal        { 0xff057d88 };
    static inline const juce::Colour cyanFlowGlow        { 0x4400e5ff };
    static inline const juce::Colour cyanActiveCore      { 0xffe0ffff };

    // Spectral Inflow & Secondary
    static inline const juce::Colour spectrumInputFill   { 0x228a4aff };
    static inline const juce::Colour spectrumInputLine   { 0x77ab7aff };
    static inline const juce::Colour peakResonanceAlert  { 0xffff4455 };
    static inline const juce::Colour peakResonanceGold   { 0xffffaa00 };

    // Typography
    static inline const juce::Colour textWhite           { 0xfff8fafc };
    static inline const juce::Colour textMuted           { 0xff8b9bb4 };
    static inline const juce::Colour textDim             { 0xff4b5568 };
    static inline const juce::Colour textGold            { 0xfff0c43f };
    static inline const juce::Colour textCyan            { 0xff38e8ff };

    // Frequency Grid
    static inline const juce::Colour gridMajorLine       { 0x2a546788 };
    static inline const juce::Colour gridMinorLine       { 0x143c4a62 };
    static inline const juce::Colour gridBaselineZero    { 0x44c5a059 };

    // Knurled Dial Metals
    static inline const juce::Colour metalSkirtDark      { 0xff16181f };
    static inline const juce::Colour metalSkirtLight     { 0xff3f4654 };
    static inline const juce::Colour metalCapCenter      { 0xff1d212b };
    static inline const juce::Colour metalRimBezel       { 0xff545c6e };
};

} // namespace gui171
