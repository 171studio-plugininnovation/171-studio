#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <dsp171/VocalCraftEngine.h>
#include <cmath>

namespace dsp171 {

// ==============================================================================
// 171 VocalCraft - 60 FPS CRT Consonant & Dynamics Vector Scope
//
// Shows real-time waveform AC dynamics with amber phosphor highlights on
// detected consonants and transient bursts, coupled with an analog-modeled
// Gain Reduction needle meter and Auto-Stage telemetry lock banner.
// ==============================================================================
class VocalCraftConsonantScope : public juce::Component {
public:
    VocalCraftConsonantScope() {
        setOpaque(true);
    }

    void updateTelemetry(const VocalCraftEngine::Telemetry& t) noexcept {
        gainReductionDb = t.gainReductionDb;
        consonantActivity = t.consonantActivity;
        autoMakeupDb = t.autoMakeupDb;
        isCalibrating = t.isCalibrating;
        isLocked = t.isLocked;
        autoTrimDb = t.autoTrimDb;

        isNeuralActive = t.isNeuralBrainActive;
        neuralPhonemeClass = t.neuralPhonemeClass;
        neuralRatio = t.neuralPredictedRatio;
        neuralPunch = t.neuralConsonantPunch;
        neuralLatencyUs = t.neuralInferenceTimeUs;
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const float w = bounds.getWidth();
        const float h = bounds.getHeight();

        // 1. Dark Titanium CRT Screen background
        g.fillAll(juce::Colour(0xFF0F141C));

        // 2. Vector Grid
        g.setColour(juce::Colour(0x1AD4AF37));
        g.drawHorizontalLine(static_cast<int>(h * 0.5f), 0.0f, w);
        g.drawVerticalLine(static_cast<int>(w * 0.5f), 0.0f, h);

        // 3. Status Banner
        g.setFont(juce::FontOptions(11.0f).withStyle("Bold"));
        if (isCalibrating) {
            g.setColour(juce::Colour(0xFFFF9100)); // Blinking Orange
            g.drawText("SMART GAIN-STAGING: [ CALIBRATING... ]", 10, 6, 260, 14, juce::Justification::left);
        } else if (isLocked) {
            g.setColour(juce::Colour(0xFF00E676)); // Locked Green
            juce::String lockStr = juce::String::formatted("AUTO-STAGE: LOCKED (-18 dBFS | TRIM: %+.1f dB)", autoTrimDb);
            g.drawText(lockStr, 10, 6, 320, 14, juce::Justification::left);
        } else {
            g.setColour(juce::Colour(0xFFD4AF37));
            g.drawText("SMART GAIN-STAGING: [ READY ]", 10, 6, 260, 14, juce::Justification::left);
        }

        // Auto-Makeup Telemetry
        g.setColour(juce::Colour(0xFFB0BEC5));
        g.setFont(juce::FontOptions(10.0f));
        juce::String makeupStr = juce::String::formatted("AUTO-MAKEUP: +%.1f dB", autoMakeupDb);
        g.drawText(makeupStr, static_cast<int>(w) - 160, 6, 150, 14, juce::Justification::right);

        // 3b. Real-Time Neural Brain GRU Inference Readout
        juce::String phonemeStr = "SILENCE / IDLE";
        juce::Colour phonemeCol = juce::Colour(0xFF78909C);
        if (neuralPhonemeClass == 1) {
            phonemeStr = "VOWEL (BODY)";
            phonemeCol = juce::Colour(0xFF4FC3F7); // Cyan Blue
        } else if (neuralPhonemeClass == 2) {
            phonemeStr = "PLOSIVE (PUNCH)";
            phonemeCol = juce::Colour(0xFFFFD54F); // Gold
        } else if (neuralPhonemeClass == 3) {
            phonemeStr = "SIBILANT (ESS)";
            phonemeCol = juce::Colour(0xFFFF4081); // Magenta
        }

        g.setFont(juce::FontOptions(10.0f).withStyle("Bold"));
        g.setColour(phonemeCol);
        juce::String neuralStr = juce::String::formatted("AI BRAIN: [%s] • RATIO: %.1f:1 • PUNCH: %d%% • LATENCY: %.1f us",
            phonemeStr.toRawUTF8(), neuralRatio, static_cast<int>(neuralPunch * 100.0f), neuralLatencyUs);
        g.drawText(neuralStr, 10, 24, static_cast<int>(w) - 20, 14, juce::Justification::left);

        // 4. Consonant Burst Highlight Aura
        if (consonantActivity > 0.15f) {
            juce::Colour sparkCol = juce::Colour(0xFFFFD54F).withAlpha(std::min(0.6f, consonantActivity * 0.8f));
            g.setColour(sparkCol);
            g.fillRoundedRectangle(bounds.reduced(4.0f), 4.0f);

            g.setColour(juce::Colour(0xFFFFD700));
            g.setFont(juce::FontOptions(10.0f).withStyle("Bold"));
            g.drawText("CONSONANT PUNCH DETECTED", 10, static_cast<int>(h) - 22, 220, 16, juce::Justification::left);
        }

        // 5. Analog Gain Reduction Needle Meter (Top-Right / Center)
        const float meterY = h * 0.75f;
        const float meterW = w - 40.0f;
        const float meterX = 20.0f;

        // Meter Track
        g.setColour(juce::Colour(0x3337474F));
        g.fillRoundedRectangle(meterX, meterY, meterW, 10.0f, 3.0f);

        // GR Reduction Bar (from 0 dB down to -24 dB)
        // Normal range: 0 dB (right) to -24 dB (left)
        const float clampedGr = std::clamp(gainReductionDb, -24.0f, 0.0f);
        const float grNorm = -clampedGr / 24.0f; // 0.0 at 0dB, 1.0 at -24dB
        const float fillW = grNorm * meterW;

        if (fillW > 0.0f) {
            juce::Colour grColor = (grNorm > 0.6f) ? juce::Colour(0xFFFF5252) : juce::Colour(0xFFFFB300);
            g.setColour(grColor);
            g.fillRoundedRectangle(meterX + meterW - fillW, meterY, fillW, 10.0f, 3.0f);
        }

        // Meter Labels
        g.setColour(juce::Colour(0xFFD4AF37));
        g.setFont(juce::FontOptions(9.0f));
        g.drawText("-24 dB", static_cast<int>(meterX), static_cast<int>(meterY) + 12, 40, 12, juce::Justification::left);
        g.drawText("-12 dB", static_cast<int>(meterX + meterW * 0.5f - 20.0f), static_cast<int>(meterY) + 12, 40, 12, juce::Justification::centred);
        g.drawText("0 dB (GR)", static_cast<int>(meterX + meterW - 50.0f), static_cast<int>(meterY) + 12, 50, 12, juce::Justification::right);

        // Scope Bezel
        g.setColour(juce::Colour(0x55333F48));
        g.drawRect(bounds, 1.0f);
    }

private:
    float gainReductionDb = 0.0f;
    float consonantActivity = 0.0f;
    float autoMakeupDb = 0.0f;
    float autoTrimDb = 0.0f;
    bool  isCalibrating = false;
    bool  isLocked = false;

    bool  isNeuralActive = false;
    int   neuralPhonemeClass = 0;
    float neuralRatio = 4.0f;
    float neuralPunch = 0.0f;
    float neuralLatencyUs = 0.0f;
};

} // namespace dsp171
