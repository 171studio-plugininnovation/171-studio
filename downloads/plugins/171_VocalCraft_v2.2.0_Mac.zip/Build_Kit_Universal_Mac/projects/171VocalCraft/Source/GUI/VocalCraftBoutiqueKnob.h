#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <BinaryData.h>
#include "VocalCraftHardwareTheme.h"
#include <cmath>

namespace dsp171 {

// ==============================================================================
// 171 VOCALCRAFT - BOUTIQUE KNURLED ALUMINUM & BRASS HARDWARE KNOB
// ==============================================================================
class VocalCraftBoutiqueKnob : public juce::Slider {
public:
    enum class DialStyle {
        Calibrated0To11,      // Standard laser-etched 0..11 calibration ring
        CompressorQuadrant    // Quadrant style modes (PEAK, RMS, PEAK, LIMIT) + Style LED
    };

    explicit VocalCraftBoutiqueKnob(const juce::String& title, DialStyle style = DialStyle::Calibrated0To11, bool isLarge = false)
        : knobTitle(title), dialStyle(style), isLargeKnob(isLarge)
    {
        setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        setRotaryParameters(juce::MathConstants<float>::pi * 1.25f,
                            juce::MathConstants<float>::pi * 2.75f, true);
        setMouseCursor(juce::MouseCursor::NormalCursor);
    }

    void setDrawOuterMarkings(bool draw) noexcept {
        drawOuterMarkings = draw;
        repaint();
    }

    void setTitleAtTop(bool top) noexcept {
        titleAtTop = top;
        repaint();
    }

    void setCompressorStyleIndex(int index) noexcept {
        if (activeStyleIndex != index) {
            activeStyleIndex = index;
            repaint();
        }
    }

    void setSubTitle(const juce::String& sub) noexcept {
        subTitle = sub;
        repaint();
    }

    std::function<void(int)> onStyleChanged;

    void mouseDown(const juce::MouseEvent& e) override {
        if (dialStyle == DialStyle::CompressorQuadrant) {
            const float w = static_cast<float>(getWidth());
            const float h = static_cast<float>(getHeight());
            const float cx = w * 0.5f;
            const float cy = (h - 26.0f) * 0.5f + 4.0f;
            const float dx = static_cast<float>(e.x) - cx;
            const float dy = static_cast<float>(e.y) - cy;
            const float dist = std::sqrt(dx * dx + dy * dy);
            const float radius = std::min(w, h - 26.0f) * 0.36f;
            if (dist > radius * 1.05f || e.mods.isRightButtonDown()) {
                int chosenIdx = activeStyleIndex;
                if (e.mods.isRightButtonDown()) {
                    chosenIdx = (activeStyleIndex + 1) % 4;
                } else {
                    float angleDeg = juce::radiansToDegrees(std::atan2(dx, -dy));
                    if (angleDeg < -90.0f)      chosenIdx = 0; // Top-Left: Hip-Hop
                    else if (angleDeg < 0.0f)   chosenIdx = 2; // Bottom-Left: Trap
                    else if (angleDeg < 90.0f)  chosenIdx = 1; // Top-Right: Pop
                    else                        chosenIdx = 3; // Bottom-Right: R&B
                }
                if (onStyleChanged) onStyleChanged(chosenIdx);
                return;
            }
        }
        juce::Slider::mouseDown(e);
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const float w = bounds.getWidth();
        const float h = bounds.getHeight();

        float cx = w * 0.5f;
        float cy = h * 0.5f;
        float radius = std::min(w, h) * 0.44f;

        if (drawOuterMarkings) {
            const float titleH = 26.0f;
            const float dialAreaH = h - titleH;
            const float size = std::min(w, dialAreaH);
            cx = w * 0.5f;
            cy = titleAtTop ? (dialAreaH * 0.5f + titleH - 2.0f) : (dialAreaH * 0.5f + 4.0f);
            radius = size * (isLargeKnob ? 0.30f : 0.28f);
        }

        const auto rotaryParams = getRotaryParameters();
        const float startAngle = rotaryParams.startAngleRadians;
        const float endAngle = rotaryParams.endAngleRadians;
        const float currentAngle = startAngle + static_cast<float>(valueToProportionOfLength(getValue())) * (endAngle - startAngle);

        // 1. Draw Outer Laser Markings
        if (drawOuterMarkings) {
            if (dialStyle == DialStyle::Calibrated0To11) {
                drawLaserCalibratedScale(g, cx, cy, radius, startAngle, endAngle);
            } else {
                drawCompressorQuadrantScale(g, cx, cy, radius);
            }
        }

        // 2. Nano Banana Photorealistic Rotating Knob Bitmap (Google Imagen)
        if (BinaryData::namedResourceListSize > 0) {
            juce::Image nanoKnob = juce::ImageCache::getFromMemory(
                BinaryData::knob_photoreal_nano_256_png,
                BinaryData::knob_photoreal_nano_256_pngSize);

            if (nanoKnob.isValid()) {
                // Drop shadow behind brass skirt
                g.setColour(juce::Colours::black.withAlpha(0.68f));
                g.fillEllipse(cx - radius * 1.05f + 1.2f, cy - radius * 1.05f + 2.5f, radius * 2.10f, radius * 2.10f);

                // Rotating 100% circular photorealistic dial
                const float imgSize = static_cast<float>(nanoKnob.getWidth());
                const float scale = (radius * 2.06f) / imgSize;

                auto transform = juce::AffineTransform::translation(-imgSize * 0.5f, -imgSize * 0.5f)
                                    .rotated(currentAngle)
                                    .scaled(scale)
                                    .translated(cx, cy);

                g.drawImageTransformed(nanoKnob, transform, true);

                drawTitleSilkscreen(g, w, h);
                return;
            }
        }

        // 2. Brass Skirt Drop Shadow
        g.setColour(juce::Colours::black.withAlpha(0.7f));
        g.fillEllipse(cx - radius * 1.08f + 1.8f, cy - radius * 1.08f + 3.0f, radius * 2.16f, radius * 2.16f);

        // 3. Chamfered Champagne Brass Skirt Ring
        const float skirtR = radius * 1.06f;
        juce::ColourGradient skirtGrad(
            HardwareTheme::champagneHighlight, cx - skirtR * 0.6f, cy - skirtR * 0.6f,
            HardwareTheme::champagneDeep, cx + skirtR * 0.6f, cy + skirtR * 0.6f, false);
        skirtGrad.addColour(0.35, HardwareTheme::champagneLight);
        skirtGrad.addColour(0.70, HardwareTheme::champagneDark);
        g.setGradientFill(skirtGrad);
        g.fillEllipse(cx - skirtR, cy - skirtR, skirtR * 2.0f, skirtR * 2.0f);

        // Skirt beveled rim
        g.setColour(HardwareTheme::champagneHighlight.withAlpha(0.6f));
        g.drawEllipse(cx - skirtR + 0.5f, cy - skirtR + 0.5f, skirtR * 2.0f - 1.0f, skirtR * 2.0f - 1.0f, 0.9f);

        // 4. Knurled Aluminum Body (Dark Gunmetal with 3D Teeth)
        const float bodyR = radius * 0.92f;
        g.setColour(juce::Colour(0xFF0F1216));
        g.fillEllipse(cx - bodyR, cy - bodyR, bodyR * 2.0f, bodyR * 2.0f);

        // 3D Knurling teeth texture around perimeter (Physical shadow & specular facets)
        const int numKnurlTeeth = 42;
        for (int k = 0; k < numKnurlTeeth; ++k) {
            float ka = static_cast<float>(k) * juce::MathConstants<float>::twoPi / static_cast<float>(numKnurlTeeth);
            float cosK = std::cos(ka);
            float sinK = std::sin(ka);

            // Shadow groove on right
            float sx = cx + (cosK - sinK * 0.08f) * (bodyR - 1.2f);
            float sy = cy + (sinK + cosK * 0.08f) * (bodyR - 1.2f);
            g.setColour(juce::Colour(0xFF08090C));
            g.fillEllipse(sx - 0.9f, sy - 0.9f, 1.8f, 1.8f);

            // Specular highlighted ridge on left
            float hx = cx + (cosK + sinK * 0.08f) * (bodyR - 1.2f);
            float hy = cy + (sinK - cosK * 0.08f) * (bodyR - 1.2f);
            g.setColour(HardwareTheme::chromeHighlight.withAlpha(0.60f));
            g.fillEllipse(hx - 0.6f, hy - 0.6f, 1.2f, 1.2f);
        }

        // 5. CD Lathe-Turned Aluminum Cap Face (1:1 Circular Vector Rotor)
        const float capR = bodyR * 0.84f;
        juce::ColourGradient capGrad(
            HardwareTheme::chromeHighlight, cx - capR * 0.4f, cy - capR * 0.4f,
            HardwareTheme::titaniumDeep, cx + capR * 0.5f, cy + capR * 0.5f, false);
        capGrad.addColour(0.35, HardwareTheme::chromeMid);
        capGrad.addColour(0.65, HardwareTheme::chromeDark);
        g.setGradientFill(capGrad);
        g.fillEllipse(cx - capR, cy - capR, capR * 2.0f, capR * 2.0f);

        // CD Lathe-Turned Hourglass Anisotropic Specular Highlight Cones (at 45° and 225°)
        auto drawAnisotropicWedge = [&](float centerAngle, float sweep) {
            juce::Path wedge;
            wedge.startNewSubPath(cx, cy);
            wedge.addArc(cx - capR, cy - capR, capR * 2.0f, capR * 2.0f,
                         centerAngle - sweep * 0.5f, centerAngle + sweep * 0.5f, true);
            wedge.closeSubPath();

            juce::ColourGradient wedgeGrad(
                juce::Colours::white.withAlpha(0.24f), cx, cy,
                juce::Colours::white.withAlpha(0.06f),
                cx + std::cos(centerAngle) * capR, cy + std::sin(centerAngle) * capR, false);
            g.setGradientFill(wedgeGrad);
            g.fillPath(wedge);
        };

        drawAnisotropicWedge(juce::MathConstants<float>::pi * 0.25f, 0.82f);
        drawAnisotropicWedge(juce::MathConstants<float>::pi * 1.25f, 0.82f);

        // Machined Concentric Micro-Grooves on Top Cap Face
        g.setColour(juce::Colours::white.withAlpha(0.12f));
        g.drawEllipse(cx - capR * 0.86f, cy - capR * 0.86f, capR * 1.72f, capR * 1.72f, 0.6f);
        g.drawEllipse(cx - capR * 0.48f, cy - capR * 0.48f, capR * 0.96f, capR * 0.96f, 0.6f);

        g.setColour(juce::Colours::black.withAlpha(0.22f));
        g.drawEllipse(cx - capR * 0.68f, cy - capR * 0.68f, capR * 1.36f, capR * 1.36f, 0.6f);
        g.drawEllipse(cx - capR * 0.28f, cy - capR * 0.28f, capR * 0.56f, capR * 0.56f, 0.6f);

        // Cap Outer Chamfer Bevel Catch
        juce::ColourGradient capBevel(
            juce::Colours::white.withAlpha(0.48f), cx - capR, cy - capR,
            juce::Colours::black.withAlpha(0.65f), cx + capR, cy + capR, false);
        g.setGradientFill(capBevel);
        g.drawEllipse(cx - capR + 0.5f, cy - capR + 0.5f, capR * 2.0f - 1.0f, capR * 2.0f - 1.0f, 1.0f);

        // 6. Laser-Milled Rotating Pointer Indicator
        const float ptrInner = capR * 0.28f;
        const float ptrOuter = capR * 0.94f;
        const float cosA = std::sin(currentAngle);
        const float sinA = -std::cos(currentAngle);

        juce::Path ptrPath;
        ptrPath.startNewSubPath(cx + cosA * ptrInner, cy + sinA * ptrInner);
        ptrPath.lineTo(cx + cosA * ptrOuter, cy + sinA * ptrOuter);

        // Pointer notch shadow & highlight
        g.setColour(juce::Colours::black.withAlpha(0.85f));
        g.strokePath(ptrPath, juce::PathStrokeType(3.5f, juce::PathStrokeType::mitered, juce::PathStrokeType::rounded));

        g.setColour(juce::Colours::white);
        g.strokePath(ptrPath, juce::PathStrokeType(2.0f, juce::PathStrokeType::mitered, juce::PathStrokeType::rounded));

        drawTitleSilkscreen(g, w, h);
    }

    void drawTitleSilkscreen(juce::Graphics& g, float w, float h) {
        if (!drawOuterMarkings) return;
        const float titleH = 28.0f;
        const int titleY = titleAtTop ? 2 : static_cast<int>(h - titleH);
        if (knobTitle.containsChar('\n') || knobTitle == "STYLE COMPRESSOR") {
            juce::String line1 = knobTitle.containsChar('\n') ? knobTitle.upToFirstOccurrenceOf("\n", false, false) : "STYLE";
            juce::String line2 = knobTitle.containsChar('\n') ? knobTitle.fromFirstOccurrenceOf("\n", false, false) : "COMPRESSOR";
            g.setFont(juce::FontOptions(10.0f).withStyle("Bold"));
            g.setColour(HardwareTheme::silkscreenText);
            g.drawText(line1, 0, titleY, static_cast<int>(w), 12, juce::Justification::centred);
            g.drawText(line2, 0, titleY + 12, static_cast<int>(w), 12, juce::Justification::centred);
        } else {
            float fontSize = 11.0f;
            juce::Font f = juce::FontOptions(fontSize).withStyle("Bold");
            while (f.getStringWidth(knobTitle) > (w - 4.0f) && fontSize > 8.0f) {
                fontSize -= 0.5f;
                f = juce::FontOptions(fontSize).withStyle("Bold");
            }
            g.setFont(f);
            g.setColour(HardwareTheme::silkscreenText);
            g.drawText(knobTitle, 0, titleY + 2, static_cast<int>(w), 14, juce::Justification::centred);
        }

        if (subTitle.isNotEmpty()) {
            g.setFont(juce::FontOptions(8.5f));
            g.setColour(HardwareTheme::champagneLight);
            g.drawText(subTitle, 0, static_cast<int>(h - titleH + 15.0f), static_cast<int>(w), 12, juce::Justification::centred);
        }
    }

private:
    void drawLaserCalibratedScale(juce::Graphics& g, float cx, float cy, float radius, float startAngle, float endAngle) {
        const float trackR = radius * 1.22f;
        const float numR = radius * 1.44f;
        const int numMarks = 11; // 0 to 11

        g.setFont(juce::FontOptions(9.5f).withStyle("Bold"));

        for (int i = 0; i <= numMarks; ++i) {
            float norm = static_cast<float>(i) / static_cast<float>(numMarks);
            float a = startAngle + norm * (endAngle - startAngle);

            float cosA = std::sin(a);
            float sinA = -std::cos(a);

            // Major tick line
            float x1 = cx + cosA * (trackR - 3.0f);
            float y1 = cy + sinA * (trackR - 3.0f);
            float x2 = cx + cosA * (trackR + 3.0f);
            float y2 = cy + sinA * (trackR + 3.0f);

            g.setColour(HardwareTheme::silkscreenText);
            g.drawLine(x1, y1, x2, y2, 1.2f);

            // Number label
            float nx = cx + cosA * numR;
            float ny = cy + sinA * numR;
            g.setColour(HardwareTheme::silkscreenText);
            g.drawText(juce::String(i), static_cast<int>(nx - 10.0f), static_cast<int>(ny - 7.0f), 20, 14, juce::Justification::centred);

            // Minor half-tick
            if (i < numMarks) {
                float midNorm = (static_cast<float>(i) + 0.5f) / static_cast<float>(numMarks);
                float ma = startAngle + midNorm * (endAngle - startAngle);
                float mcosA = std::sin(ma);
                float msinA = -std::cos(ma);
                float mx1 = cx + mcosA * trackR;
                float my1 = cy + msinA * trackR;
                float mx2 = cx + mcosA * (trackR + 3.0f);
                float my2 = cy + msinA * (trackR + 3.0f);
                g.setColour(HardwareTheme::silkscreenText.withAlpha(0.6f));
                g.drawLine(mx1, my1, mx2, my2, 0.8f);
            }
        }
    }

    void drawCompressorQuadrantScale(juce::Graphics& g, float cx, float cy, float radius) {
        const float textR = radius * 1.42f;

        // 4 Quadrants: Top-Left (Hip-Hop / PEAK), Top-Right (Modern Pop / RMS),
        //              Bottom-Left (Trap / PEAK), Bottom-Right (R&B / LIMIT)
        struct ModeTag {
            const char* label;
            float angleDeg;
            int styleIdx;
        };

        static const ModeTag tags[4] = {
            { "PEAK",  -135.0f, 0 }, // Hip-Hop / Rap
            { "RMS",     45.0f, 1 }, // Modern Pop
            { "PEAK",  -45.0f, 2 },  // Trap / Drill
            { "LIMIT",  135.0f, 3 }  // R&B / Soul
        };

        g.setFont(juce::FontOptions(10.0f).withStyle("Bold"));

        for (int i = 0; i < 4; ++i) {
            float rad = juce::degreesToRadians(tags[i].angleDeg);
            float tx = cx + std::sin(rad) * textR;
            float ty = cy - std::cos(rad) * textR;

            bool isActive = (tags[i].styleIdx == activeStyleIndex);

            // Active indicator amber LED dot in recessed bezel (Zero chassis bloom)
            if (isActive) {
                float ledDist = textR + 9.0f;
                float lx = cx + std::sin(rad) * ledDist;
                float ly = cy - std::cos(rad) * ledDist;

                // Micro recessed dark socket
                g.setColour(juce::Colours::black.withAlpha(0.80f));
                g.fillEllipse(lx - 3.2f, ly - 3.2f, 6.4f, 6.4f);

                g.setColour(juce::Colour(0xFF14181F));
                g.fillEllipse(lx - 2.8f, ly - 2.8f, 5.6f, 5.6f);

                g.setColour(HardwareTheme::chromeDark);
                g.drawEllipse(lx - 2.8f, ly - 2.8f, 5.6f, 5.6f, 0.6f);

                // Concentrated active LED lens core (no fuzzy chassis bleed)
                juce::ColourGradient ledCore(juce::Colours::white.withAlpha(0.96f), lx, ly - 0.7f,
                                            HardwareTheme::ledAmberOn, lx, ly + 2.0f, true);
                g.setGradientFill(ledCore);
                g.fillEllipse(lx - 2.0f, ly - 2.0f, 4.0f, 4.0f);

                // Specular glint on epoxy dome
                g.setColour(juce::Colours::white.withAlpha(0.85f));
                g.fillEllipse(lx - 1.1f, ly - 1.3f, 1.3f, 0.8f);
            }

            g.setColour(isActive ? HardwareTheme::champagneHighlight : HardwareTheme::silkscreenText.withAlpha(0.6f));
            g.drawText(tags[i].label, static_cast<int>(tx - 18.0f), static_cast<int>(ty - 7.0f), 36, 14, juce::Justification::centred);
        }
    }

    juce::String knobTitle;
    juce::String subTitle;
    DialStyle dialStyle;
    int activeStyleIndex = 1; // 1 = RMS / Pop default
    bool isLargeKnob = false;
    bool drawOuterMarkings = true;
    bool titleAtTop = false;
    juce::Image nanoKnobCapImg;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalCraftBoutiqueKnob)
};

} // namespace dsp171
