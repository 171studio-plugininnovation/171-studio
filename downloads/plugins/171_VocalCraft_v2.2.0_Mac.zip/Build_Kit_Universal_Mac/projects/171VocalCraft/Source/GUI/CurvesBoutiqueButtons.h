#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_graphics/juce_graphics.h>
#include <cmath>
#include "CurvesEquatorTheme.h"

namespace gui171 {

// ==============================================================================
// 171 VOCALCRAFT - CURVES BOUTIQUE LEARN BUTTON
// Inspired by Waves Curves Equator dynamic profiling:
// - Animated breathing neon halo when calibrating/learning
// - Gold laser-etched border and high-tech typography
// ==============================================================================
class CurvesLearnButton : public juce::Button {
public:
    CurvesLearnButton() : juce::Button("LearnButton") {
        setOpaque(false);
    }

    ~CurvesLearnButton() override = default;

    void setCalibrating(bool calibrating) noexcept {
        if (isCalibrating != calibrating) {
            isCalibrating = calibrating;
            repaint();
        }
    }

    void setLocked(bool locked) noexcept {
        if (isLocked != locked) {
            isLocked = locked;
            repaint();
        }
    }

    void advanceAnimation() noexcept {
        pulsePhase += 0.12f;
        if (pulsePhase > juce::MathConstants<float>::twoPi)
            pulsePhase -= juce::MathConstants<float>::twoPi;
        if (isCalibrating) {
            repaint();
        }
    }

    void paintButton(juce::Graphics& g, bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override {
        auto bounds = getLocalBounds().toFloat().reduced(2.0f);
        if (bounds.isEmpty()) return;

        float corner = bounds.getHeight() * 0.5f;

        // Ombra portata
        g.setColour(juce::Colours::black.withAlpha(0.60f));
        g.fillRoundedRectangle(bounds.translated(1.0f, 2.5f), corner);

        // Corpo del pulsante (Titanio scuro sfumato)
        juce::Colour topCol = shouldDrawButtonAsDown ? juce::Colour(0xff12141a) : juce::Colour(0xff222733);
        juce::Colour botCol = shouldDrawButtonAsDown ? juce::Colour(0xff090a0d) : juce::Colour(0xff101217);
        juce::ColourGradient grad(topCol, bounds.getX(), bounds.getY(), botCol, bounds.getX(), bounds.getBottom(), false);
        g.setGradientFill(grad);
        g.fillRoundedRectangle(bounds, corner);

        // Bordo neon / dorato con alone di pulsazione se in apprendimento
        juce::Colour glowCol = CurvesTheme::goldPrimary;
        if (isCalibrating) {
            float pulse = 0.5f + 0.5f * std::sin(pulsePhase);
            glowCol = CurvesTheme::cyanElectric.interpolatedWith(CurvesTheme::goldPrimary, pulse);

            // Alone esterno bloom
            g.setColour(glowCol.withAlpha(0.35f * pulse + 0.15f));
            g.drawRoundedRectangle(bounds.expanded(1.5f), corner + 1.5f, 3.5f);
        } else if (isLocked) {
            glowCol = CurvesTheme::cyanElectric;
        }

        g.setColour(glowCol);
        g.drawRoundedRectangle(bounds, corner, 1.4f);

        // Micro-pip indicatore
        float pipRadius = 4.0f;
        float pipX = bounds.getX() + 16.0f;
        float pipY = bounds.getCentreY();

        g.setColour(glowCol);
        g.fillEllipse(pipX - pipRadius, pipY - pipRadius, pipRadius * 2.0f, pipRadius * 2.0f);
        g.setColour(juce::Colours::white);
        g.fillEllipse(pipX - 1.5f, pipY - 1.5f, 3.0f, 3.0f);

        // Testo del pulsante
        g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        juce::String btnLabel = isCalibrating ? "LEARNING..." : (isLocked ? "TARGET LOCKED" : "LEARN TARGET");
        g.setColour(shouldDrawButtonAsHighlighted ? juce::Colours::white : CurvesTheme::textWhite);
        g.drawText(btnLabel, juce::Rectangle<float>(bounds.getX() + 24.0f, bounds.getY(), bounds.getWidth() - 28.0f, bounds.getHeight()),
                   juce::Justification::centred, false);
    }

private:
    bool isCalibrating = false;
    bool isLocked = false;
    float pulsePhase = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(CurvesLearnButton)
};

// ==============================================================================
// 171 VOCALCRAFT - CURVES BOUTIQUE TOGGLE BUTTON (AUTO MAKEUP / BYPASS)
// ==============================================================================
class CurvesBoutiqueToggle : public juce::ToggleButton {
public:
    enum class ToggleStyle {
        AutoMakeup,
        MasterBypass
    };

    explicit CurvesBoutiqueToggle(ToggleStyle style, const juce::String& label = "")
        : toggleStyle(style), customLabel(label)
    {
        setOpaque(false);
    }

    ~CurvesBoutiqueToggle() override = default;

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat().reduced(1.0f);
        if (bounds.isEmpty()) return;

        bool on = getToggleState();
        float corner = 4.0f;

        // Ombra
        g.setColour(juce::Colours::black.withAlpha(0.50f));
        g.fillRoundedRectangle(bounds.translated(1.0f, 2.0f), corner);

        // Corpo
        juce::Colour topCol = on ? juce::Colour(0xff222b3a) : juce::Colour(0xff161922);
        juce::Colour botCol = on ? juce::Colour(0xff0e131c) : juce::Colour(0xff0d0f14);
        juce::ColourGradient grad(topCol, bounds.getX(), bounds.getY(), botCol, bounds.getX(), bounds.getBottom(), false);
        g.setGradientFill(grad);
        g.fillRoundedRectangle(bounds, corner);

        // Bordo dorato o ciano
        juce::Colour borderCol;
        if (toggleStyle == ToggleStyle::MasterBypass) {
            borderCol = on ? juce::Colour(0xffff4455) : CurvesTheme::goldLaserHairline;
        } else {
            borderCol = on ? CurvesTheme::cyanElectric : CurvesTheme::goldLaserHairline;
        }

        g.setColour(borderCol);
        g.drawRoundedRectangle(bounds, corner, 1.2f);

        // Micro LED di stato
        float ledX = bounds.getX() + 12.0f;
        float ledY = bounds.getCentreY();
        float ledR = 3.5f;

        juce::Colour ledCol = on ? borderCol : juce::Colour(0xff2c3444);
        g.setColour(ledCol);
        g.fillEllipse(ledX - ledR, ledY - ledR, ledR * 2.0f, ledR * 2.0f);

        if (on) {
            g.setColour(juce::Colours::white.withAlpha(0.85f));
            g.fillEllipse(ledX - 1.2f, ledY - 1.2f, 2.4f, 2.4f);
        }

        // Testo etichetta
        g.setFont(juce::FontOptions(10.5f, juce::Font::bold));
        g.setColour(on ? juce::Colours::white : CurvesTheme::textMuted);
        g.drawText(customLabel, juce::Rectangle<float>(bounds.getX() + 20.0f, bounds.getY(), bounds.getWidth() - 24.0f, bounds.getHeight()),
                   juce::Justification::centred, false);
    }

private:
    ToggleStyle toggleStyle;
    juce::String customLabel;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(CurvesBoutiqueToggle)
};

// ==============================================================================
// 171 VOCALCRAFT - HORIZONTAL DUAL LED BARGRAPH (OUTPUT RMS & GAIN REDUCTION)
// ==============================================================================
class CurvesDualBargraph : public juce::Component {
public:
    CurvesDualBargraph() {
        setOpaque(false);
    }

    ~CurvesDualBargraph() override = default;

    void setLevels(float outputRmsDb, float reductionDb) noexcept {
        outDb = outputRmsDb;
        grDb  = reductionDb;
        repaint();
    }

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat();
        if (bounds.isEmpty()) return;

        float hBar = (bounds.getHeight() - 6.0f) * 0.5f;
        auto barOut = juce::Rectangle<float>(bounds.getX(), bounds.getY(), bounds.getWidth(), hBar);
        auto barGR  = juce::Rectangle<float>(bounds.getX(), bounds.getY() + hBar + 4.0f, bounds.getWidth(), hBar);

        drawBar(g, barOut, outDb, -48.0f, 0.0f, CurvesTheme::cyanElectric, "OUT RMS");
        drawBar(g, barGR, -grDb, -24.0f, 0.0f, CurvesTheme::goldPrimary, "GR DYN");
    }

private:
    void drawBar(juce::Graphics& g, const juce::Rectangle<float>& r, float valDb, float minDb, float maxDb,
                 const juce::Colour& activeCol, const char* label)
    {
        // Pista sfondo
        g.setColour(juce::Colour(0xff0a0c10));
        g.fillRoundedRectangle(r, 2.0f);
        g.setColour(juce::Colour(0xff222733));
        g.drawRoundedRectangle(r, 2.0f, 1.0f);

        float norm = std::clamp((valDb - minDb) / (maxDb - minDb), 0.0f, 1.0f);
        if (norm > 0.01f) {
            auto fillR = r.reduced(1.0f);
            fillR.setWidth(fillR.getWidth() * norm);

            juce::ColourGradient grad(
                activeCol.withAlpha(0.6f), fillR.getX(), fillR.getY(),
                activeCol, fillR.getRight(), fillR.getY(), false);
            g.setGradientFill(grad);
            g.fillRoundedRectangle(fillR, 2.0f);
        }

        // Etichetta micro
        g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
        g.setColour(CurvesTheme::textWhite.withAlpha(0.7f));
        g.drawText(label, r.reduced(4.0f, 0.0f), juce::Justification::left, false);
    }

    float outDb = -60.0f;
    float grDb  = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(CurvesDualBargraph)
};

} // namespace gui171
