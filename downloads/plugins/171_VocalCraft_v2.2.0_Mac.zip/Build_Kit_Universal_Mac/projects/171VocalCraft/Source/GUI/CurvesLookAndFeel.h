#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_graphics/juce_graphics.h>
#include <cmath>
#include "CurvesEquatorTheme.h"

namespace gui171 {

// ==============================================================================
// 171 VOCALCRAFT - CURVES BOUTIQUE LOOK AND FEEL
// Knurled dials, glowing neon arcs, laser serigraphy & luxury typography
// ==============================================================================
class CurvesLookAndFeel : public juce::LookAndFeel_V4 {
public:
    enum class KnobColorTheme {
        CyanEquator,     // Linearizer Depth, Air Sheen
        GoldPunch,       // Consonant Punch
        AmberDeess,      // Pre-Drive De-Esser
        TitaniumMaster,  // Input Trim, Clipper, Beat Unmask
        VioletSidechain  // Sidechain / Triangulator
    };

    CurvesLookAndFeel() {
        setColour(juce::Slider::textBoxTextColourId, juce::Colour(0xffffe899));
        setColour(juce::Slider::textBoxBackgroundColourId, juce::Colour(0xff07090d));
        setColour(juce::Slider::textBoxOutlineColourId, juce::Colour(0x60c5a059));

        setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff12161f));
        setColour(juce::ComboBox::outlineColourId, juce::Colour(0xffc5a059));
        setColour(juce::ComboBox::textColourId, juce::Colour(0xffffe899));
        setColour(juce::ComboBox::arrowColourId, juce::Colour(0xffd4af37));

        setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xff0d0f15));
        setColour(juce::PopupMenu::textColourId, juce::Colour(0xffffe899));
        setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xff222a38));
        setColour(juce::PopupMenu::highlightedTextColourId, juce::Colour(0xffffffff));

        setColour(juce::TooltipWindow::backgroundColourId, juce::Colour(0xff10131b));
        setColour(juce::TooltipWindow::textColourId, juce::Colour(0xffffe899));
        setColour(juce::TooltipWindow::outlineColourId, juce::Colour(0xff73562a));
    }

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPosProportional, float rotaryStartAngle, float rotaryEndAngle,
                          juce::Slider& slider) override
    {
        const auto bounds = juce::Rectangle<float>(static_cast<float>(x), static_cast<float>(y),
                                                   static_cast<float>(width), static_cast<float>(height));
        if (bounds.isEmpty()) return;

        KnobColorTheme theme = KnobColorTheme::CyanEquator;
        if (slider.getProperties().contains("Theme")) {
            theme = static_cast<KnobColorTheme>((int)slider.getProperties()["Theme"]);
        }

        juce::Colour neonCol = CurvesTheme::cyanElectric;
        switch (theme) {
            case KnobColorTheme::CyanEquator:     neonCol = CurvesTheme::cyanElectric; break;
            case KnobColorTheme::GoldPunch:       neonCol = CurvesTheme::goldPrimary; break;
            case KnobColorTheme::AmberDeess:      neonCol = juce::Colour(0xffff9900); break;
            case KnobColorTheme::TitaniumMaster:  neonCol = CurvesTheme::goldLaserHairline; break;
            case KnobColorTheme::VioletSidechain: neonCol = juce::Colour(0xffc05aff); break;
        }

        // Riserva spazio per la pillola del valore numerico sotto
        float textBoxHeight = 16.0f;
        auto knobArea = bounds;
        if (slider.getTextBoxPosition() == juce::Slider::TextBoxBelow) {
            knobArea.removeFromBottom(textBoxHeight);
        }

        const float diameter = std::min(knobArea.getWidth(), knobArea.getHeight());
        const float cx = knobArea.getCentreX();
        const float cy = knobArea.getCentreY();
        const float rBase = diameter * 0.44f;

        const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

        // ----------------------------------------------------------------------
        // 1. SCALA CIRCOLARE GRADUATA CON TACCHE SERIGRAFATE & PISTA SCURA
        // ----------------------------------------------------------------------
        const float rTrack = rBase + 1.2f;

        juce::Path trackPath;
        trackPath.addCentredArc(cx, cy, rTrack, rTrack, 0.0f, rotaryStartAngle, rotaryEndAngle, true);
        g.setColour(juce::Colour(0xff090c12));
        g.strokePath(trackPath, juce::PathStrokeType(3.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // Arco attivo luminoso neon
        if (sliderPosProportional > 0.005f) {
            juce::Path activePath;
            activePath.addCentredArc(cx, cy, rTrack, rTrack, 0.0f, rotaryStartAngle, angle, true);

            g.setColour(neonCol.withAlpha(0.28f));
            g.strokePath(activePath, juce::PathStrokeType(7.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            g.setColour(neonCol);
            g.strokePath(activePath, juce::PathStrokeType(2.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            g.setColour(juce::Colours::white.withAlpha(0.70f));
            g.strokePath(activePath, juce::PathStrokeType(0.9f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }

        // Tacche serigrafate calibrate (11 tacche da 0 a 10)
        constexpr int numTicks = 11;
        const float rTickIn = rTrack + 3.0f;
        for (int i = 0; i < numTicks; ++i) {
            float frac = static_cast<float>(i) / static_cast<float>(numTicks - 1);
            float a = rotaryStartAngle + frac * (rotaryEndAngle - rotaryStartAngle);
            bool isMajor = (i == 0 || i == 5 || i == 10);
            float tickLen = isMajor ? 4.5f : 2.5f;

            float x1 = cx + std::sin(a) * rTickIn;
            float y1 = cy - std::cos(a) * rTickIn;
            float x2 = cx + std::sin(a) * (rTickIn + tickLen);
            float y2 = cy - std::cos(a) * (rTickIn + tickLen);

            if (frac <= sliderPosProportional && sliderPosProportional > 0.005f) {
                g.setColour(neonCol.brighter(0.2f));
            } else {
                g.setColour(isMajor ? CurvesTheme::goldLaserHairline : juce::Colour(0x608b9bb4));
            }
            g.drawLine(x1, y1, x2, y2, isMajor ? 1.4f : 0.8f);
        }

        // ----------------------------------------------------------------------
        // 2. GONNA CILINDRICA ZIGRINATA IN METALLO (KNURLED SKIRT 32 DENTI)
        // ----------------------------------------------------------------------
        const float rSkirt = rBase * 0.82f;

        g.setColour(juce::Colours::black.withAlpha(0.65f));
        g.fillEllipse(cx - rSkirt + 1.5f, cy - rSkirt + 3.0f, rSkirt * 2.0f, rSkirt * 2.0f);

        juce::ColourGradient skirtGrad(
            juce::Colour(0xff525a68), cx - rSkirt, cy - rSkirt,
            juce::Colour(0xff16181e), cx + rSkirt, cy + rSkirt, false);
        g.setGradientFill(skirtGrad);
        g.fillEllipse(cx - rSkirt, cy - rSkirt, rSkirt * 2.0f, rSkirt * 2.0f);

        constexpr int numTeeth = 32;
        for (int i = 0; i < numTeeth; ++i) {
            float toothAngle = (static_cast<float>(i) / numTeeth) * juce::MathConstants<float>::twoPi;
            float cosA = std::cos(toothAngle);
            float sinA = std::sin(toothAngle);

            float xIn  = cx + sinA * (rSkirt - 2.8f);
            float yIn  = cy - cosA * (rSkirt - 2.8f);
            float xOut = cx + sinA * rSkirt;
            float yOut = cy - cosA * rSkirt;

            bool isLit = (sinA - cosA) < 0.2f;
            g.setColour(isLit ? juce::Colour(0x50ffffff) : juce::Colour(0x80000000));
            g.drawLine(xIn, yIn, xOut, yOut, 1.0f);
        }

        // ----------------------------------------------------------------------
        // 3. CAPELLOTTO CENTRALE SPAZZOLATO CON RIFLESSO CIRCOLARE ANISOTROPO
        // ----------------------------------------------------------------------
        const float rCap = rSkirt * 0.76f;

        g.setColour(CurvesTheme::goldPrimary.withAlpha(0.55f));
        g.drawEllipse(cx - rCap, cy - rCap, rCap * 2.0f, rCap * 2.0f, 1.2f);

        juce::ColourGradient capGrad(
            juce::Colour(0xff2d3340), cx, cy - rCap,
            juce::Colour(0xff12141a), cx, cy + rCap, false);
        g.setGradientFill(capGrad);
        g.fillEllipse(cx - rCap + 0.5f, cy - rCap + 0.5f, (rCap - 0.5f) * 2.0f, (rCap - 0.5f) * 2.0f);

        g.setColour(juce::Colours::white.withAlpha(0.06f));
        g.drawEllipse(cx - rCap * 0.5f, cy - rCap * 0.5f, rCap, rCap, 1.0f);

        // ----------------------------------------------------------------------
        // 4. INDICATORE LUMINOSO (Pip neon / linea radiale)
        // ----------------------------------------------------------------------
        const float rPip = rCap - 3.5f;
        float pipX = cx + std::sin(angle) * rPip;
        float pipY = cy - std::cos(angle) * rPip;

        g.setColour(neonCol.withAlpha(0.70f));
        g.fillEllipse(pipX - 3.0f, pipY - 3.0f, 6.0f, 6.0f);

        g.setColour(juce::Colours::white);
        g.fillEllipse(pipX - 1.5f, pipY - 1.5f, 3.0f, 3.0f);
    }

    // --------------------------------------------------------------------------
    // PILLOLA DEL VALORE SOTTO LA MANOPOLA (Solo per caselle numeriche di Slider)
    // --------------------------------------------------------------------------
    void drawLabel(juce::Graphics& g, juce::Label& label) override {
        auto bounds = label.getLocalBounds().toFloat();
        if (bounds.isEmpty()) return;

        // Verifica se è la casella numerica creata internamente da un juce::Slider
        bool isSliderTextBox = (dynamic_cast<juce::Slider*>(label.getParentComponent()) != nullptr);

        if (isSliderTextBox) {
            // Sfondo incassato nero ossidiana profondo
            g.setColour(juce::Colour(0xff06070a));
            g.fillRoundedRectangle(bounds, 3.5f);

            // Bordo laser oro brunito
            g.setColour(CurvesTheme::goldLaserHairline.withAlpha(0.45f));
            g.drawRoundedRectangle(bounds, 3.5f, 1.0f);

            // Micro-ombra interna in alto
            g.setColour(juce::Colours::black.withAlpha(0.60f));
            g.drawHorizontalLine(juce::roundToInt(bounds.getY() + 1.0f), bounds.getX() + 2.0f, bounds.getRight() - 2.0f);

            // Testo valore numerico
            g.setFont(juce::FontOptions(10.5f, juce::Font::bold));
            g.setColour(juce::Colour(0xffffe899));
            g.drawFittedText(label.getText(), bounds.toNearestInt(), juce::Justification::centred, 1);
            return;
        }

        // Per tutte le altre etichette (titoli, sottotitoli): serigrafia pulita senza riquadro!
        g.setFont(label.getFont());
        g.setColour(label.findColour(juce::Label::textColourId));
        g.drawFittedText(label.getText(), bounds.toNearestInt(), label.getJustificationType(), 1);
    }

    void drawComboBox(juce::Graphics& g, int width, int height, bool isButtonDown,
                      int buttonX, int buttonY, int buttonW, int buttonH, juce::ComboBox& box) override
    {
        juce::ignoreUnused(isButtonDown);
        auto bounds = juce::Rectangle<float>(0.0f, 0.0f, static_cast<float>(width), static_cast<float>(height)).reduced(1.0f);

        // 1. Ombra portata incassata
        g.setColour(juce::Colours::black.withAlpha(0.50f));
        g.fillRoundedRectangle(bounds.translated(1.0f, 2.0f), 4.0f);

        // 2. Corpo metallico in titanio scuro
        juce::ColourGradient grad(juce::Colour(0xff222632), bounds.getX(), bounds.getY(),
                                  juce::Colour(0xff0e1015), bounds.getX(), bounds.getBottom(), false);
        g.setGradientFill(grad);
        g.fillRoundedRectangle(bounds, 4.0f);

        // 3. Bordo dorato satinato
        g.setColour(box.hasKeyboardFocus(true) ? CurvesTheme::goldBright : CurvesTheme::goldLaserHairline);
        g.drawRoundedRectangle(bounds, 4.0f, 1.2f);

        // Divisore verticale tra testo e freccia
        float divX = static_cast<float>(buttonX);
        g.setColour(CurvesTheme::goldPrimary.withAlpha(0.25f));
        g.drawVerticalLine(juce::roundToInt(divX), bounds.getY() + 3.0f, bounds.getBottom() - 3.0f);

        // Freccia chevron dorata
        float arrowCx = static_cast<float>(buttonX) + static_cast<float>(buttonW) * 0.5f;
        float arrowCy = static_cast<float>(buttonY) + static_cast<float>(buttonH) * 0.5f;

        juce::Path arrow;
        arrow.startNewSubPath(arrowCx - 4.0f, arrowCy - 2.5f);
        arrow.lineTo(arrowCx, arrowCy + 2.5f);
        arrow.lineTo(arrowCx + 4.0f, arrowCy - 2.5f);

        g.setColour(CurvesTheme::goldPrimary);
        g.strokePath(arrow, juce::PathStrokeType(1.8f, juce::PathStrokeType::mitered, juce::PathStrokeType::rounded));
    }

    juce::Font getComboBoxFont(juce::ComboBox&) override {
        return juce::FontOptions(11.5f, juce::Font::bold);
    }

    void positionComboBoxText(juce::ComboBox& box, juce::Label& label) override {
        label.setBounds(8, 1, box.getWidth() - 28, box.getHeight() - 2);
        label.setFont(getComboBoxFont(box));
    }
};

} // namespace gui171
