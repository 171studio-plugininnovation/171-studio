#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include "VocalCraftHardwareTheme.h"
#include <cmath>

namespace dsp171 {

// ==============================================================================
// 171 VOCALCRAFT - PRECISION RECESSED HARDWARE MINI-TRIMMER
// ==============================================================================
class VocalCraftMiniTrim : public juce::Slider {
public:
    explicit VocalCraftMiniTrim(const juce::String& title) : trimTitle(title) {
        setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        setRotaryParameters(juce::MathConstants<float>::pi * 1.25f,
                            juce::MathConstants<float>::pi * 2.75f, true);
        setMouseCursor(juce::MouseCursor::NormalCursor);
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const float w = bounds.getWidth();
        const float h = bounds.getHeight();

        const float labelH = 13.0f;
        const float potAreaH = h - labelH;
        const float size = std::min(w, potAreaH);
        const float cx = w * 0.5f;
        const float cy = potAreaH * 0.5f;
        const float radius = size * 0.38f;

        const auto rotaryParams = getRotaryParameters();
        const float startAngle = rotaryParams.startAngleRadians;
        const float endAngle = rotaryParams.endAngleRadians;
        const float currentAngle = startAngle + static_cast<float>(valueToProportionOfLength(getValue())) * (endAngle - startAngle);

        // 1. Recessed Counter-Bore Well (Hole in Chassis)
        const float wellR = radius * 1.22f;
        g.setColour(juce::Colour(0xFF07090C));
        g.fillEllipse(cx - wellR, cy - wellR, wellR * 2.0f, wellR * 2.0f);

        // Recess upper inner shadow & lower bevel reflection
        juce::ColourGradient wellGrad(juce::Colours::black.withAlpha(0.9f), cx, cy - wellR,
                                      HardwareTheme::titaniumLight.withAlpha(0.4f), cx, cy + wellR, false);
        g.setGradientFill(wellGrad);
        g.drawEllipse(cx - wellR, cy - wellR, wellR * 2.0f, wellR * 2.0f, 1.2f);

        // 2. Calibrated Peripheral Tick Dots
        const float dotR = radius * 1.12f;
        const int numDots = 8;
        for (int i = 0; i <= numDots; ++i) {
            float norm = static_cast<float>(i) / static_cast<float>(numDots);
            float a = startAngle + norm * (endAngle - startAngle);
            float dx = cx + std::sin(a) * dotR;
            float dy = cy - std::cos(a) * dotR;
            g.setColour(HardwareTheme::champagneBorder.withAlpha(0.6f));
            g.fillEllipse(dx - 0.9f, dy - 0.9f, 1.8f, 1.8f);
        }

        // 3. Brass Trimmer Dial Body
        juce::ColourGradient dialGrad(HardwareTheme::champagneHighlight, cx - radius * 0.5f, cy - radius * 0.5f,
                                      HardwareTheme::champagneDeep, cx + radius * 0.6f, cy + radius * 0.6f, false);
        dialGrad.addColour(0.4, HardwareTheme::champagneLight);
        dialGrad.addColour(0.75, HardwareTheme::champagneDark);
        g.setGradientFill(dialGrad);
        g.fillEllipse(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f);

        // Knurled Edge Rim
        const int teeth = 20;
        for (int t = 0; t < teeth; ++t) {
            float a = static_cast<float>(t) * juce::MathConstants<float>::twoPi / static_cast<float>(teeth);
            float tx = cx + std::cos(a) * (radius - 1.0f);
            float ty = cy + std::sin(a) * (radius - 1.0f);
            g.setColour(HardwareTheme::champagneDeep);
            g.fillEllipse(tx - 0.7f, ty - 0.7f, 1.4f, 1.4f);
        }

        // Center Screwdriver Slot Indicator (Rotates with Angle)
        const float slotLen = radius * 0.72f;
        const float cosA = std::sin(currentAngle);
        const float sinA = -std::cos(currentAngle);

        juce::Path slotPath;
        slotPath.startNewSubPath(cx - cosA * slotLen * 0.5f, cy - sinA * slotLen * 0.5f);
        slotPath.lineTo(cx + cosA * slotLen, cy + sinA * slotLen);

        // Slot shadow
        g.setColour(juce::Colours::black.withAlpha(0.9f));
        g.strokePath(slotPath, juce::PathStrokeType(2.8f, juce::PathStrokeType::mitered, juce::PathStrokeType::rounded));

        // White enamel pointer fill
        g.setColour(juce::Colours::white);
        g.strokePath(slotPath, juce::PathStrokeType(1.4f, juce::PathStrokeType::mitered, juce::PathStrokeType::rounded));

        // 4. Silkscreen Label Beneath Trimmer (Dynamic Font Sizing - ZERO Clipping!)
        float fontSize = 8.0f;
        juce::Font f = juce::FontOptions(fontSize).withStyle("Bold");
        while (f.getStringWidth(trimTitle) > (w - 2.0f) && fontSize > 6.0f) {
            fontSize -= 0.5f;
            f = juce::FontOptions(fontSize).withStyle("Bold");
        }
        g.setFont(f);
        g.setColour(HardwareTheme::silkscreenText);
        g.drawText(trimTitle, 0, static_cast<int>(h - labelH), static_cast<int>(w), static_cast<int>(labelH),
                   juce::Justification::centred);
    }

private:
    juce::String trimTitle;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalCraftMiniTrim)
};

} // namespace dsp171
