#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <dsp171/VocalCraftEngine.h>
#include <array>

namespace dsp171 {

// ==============================================================================
// 171 VocalCraft - 60 FPS Full-Spectrum Resonance & Peak Scope
//
// Exhaustive 20 Hz - 20,000 Hz analyzer displaying:
// 1. Live 64-band dynamic linearization & flattening curve across all frequencies.
// 2. Ideal Neutral Studio Vocal reference curve.
// 3. Glowing amber markers and exact frequency tags on EVERY detected peak.
// ==============================================================================
class VocalCraftSpectralScope : public juce::Component {
public:
    VocalCraftSpectralScope() {
        setOpaque(true);
    }

    void updateTelemetry(const VocalCraftEngine::Telemetry& t) noexcept {
        activePeakCount = t.activePeakCount;
        numTrackedPeaks = t.numTrackedPeaks;
        trackedPeaks = t.trackedPeaks;
        bandReductionsDb = t.bandReductionsDb;
        bandCenterFreqs = t.bandCenterFreqs;
        bandTargetNeutralDb = t.bandTargetNeutralDb;
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const float w = bounds.getWidth();
        const float h = bounds.getHeight();

        // 1. Dark Glass Background
        g.fillAll(juce::Colour(0xFF0D1117));

        // 2. Frequency and dB Grid Lines
        g.setColour(juce::Colour(0x22D4AF37));

        // dB horizontal grid lines (-18, -12, -6, 0, +6 dB)
        for (float db = -18.0f; db <= 6.0f; db += 6.0f) {
            float y = juce::jmap(db, -24.0f, 12.0f, h - 14.0f, 14.0f);
            g.drawHorizontalLine(static_cast<int>(y), 0.0f, w);
        }

        // Frequency vertical log markers: 100 Hz, 500 Hz, 1 kHz, 5 kHz, 10 kHz
        const std::array<float, 5> freqs = { 100.0f, 500.0f, 1000.0f, 5000.0f, 10000.0f };
        for (float f : freqs) {
            float normX = (std::log10(f) - std::log10(20.0f)) / (std::log10(20000.0f) - std::log10(20.0f));
            float x = normX * w;
            g.drawVerticalLine(static_cast<int>(x), 0.0f, h);
        }

        // 3. Draw Target Neutral Vocal Curve Reference (Dashed Gold)
        juce::Path targetPath;
        for (size_t b = 0; b < VocalCraftSpectralLinearizer::kNumBands; ++b) {
            const float f = bandCenterFreqs[b];
            if (f < 20.0f) continue;
            const float normX = (std::log10(f) - std::log10(20.0f)) / (std::log10(20000.0f) - std::log10(20.0f));
            const float x = normX * w;
            // Target curve scaled to display range
            const float targetDb = bandTargetNeutralDb[b] + 20.0f; // offset to fit around 0 dB line
            const float y = juce::jmap(targetDb, -24.0f, 12.0f, h - 14.0f, 14.0f);

            if (b == 0) targetPath.startNewSubPath(x, y);
            else targetPath.lineTo(x, y);
        }
        g.setColour(juce::Colour(0x55D4AF37));
        g.drawDashedLine(juce::Line<float>(0.0f, juce::jmap(0.0f, -24.0f, 12.0f, h - 14.0f, 14.0f),
                                           w, juce::jmap(0.0f, -24.0f, 12.0f, h - 14.0f, 14.0f)),
                         dashPattern, 2, 1.0f);

        // 4. Live Full-Spectrum Dynamic Linearization Curve (64 Bands across 20 Hz - 20 kHz)
        juce::Path curvePath;
        for (size_t b = 0; b < VocalCraftSpectralLinearizer::kNumBands; ++b) {
            const float f = bandCenterFreqs[b];
            if (f < 20.0f) continue;
            const float normX = (std::log10(f) - std::log10(20.0f)) / (std::log10(20000.0f) - std::log10(20.0f));
            const float x = normX * w;
            const float attenDb = bandReductionsDb[b];
            const float y = juce::jmap(attenDb, -24.0f, 12.0f, h - 14.0f, 14.0f);

            if (b == 0) curvePath.startNewSubPath(x, y);
            else curvePath.lineTo(x, y);
        }

        // Cyan glow & bright core
        g.setColour(juce::Colour(0x3300E5FF));
        g.strokePath(curvePath, juce::PathStrokeType(4.0f, juce::PathStrokeType::curved));
        g.setColour(juce::Colour(0xFF00E5FF));
        g.strokePath(curvePath, juce::PathStrokeType(1.8f, juce::PathStrokeType::curved));

        // 5. Draw EVERY Detected Peak across the Full Spectrum (Amber Markers + Frequency Tags)
        g.setFont(juce::FontOptions(9.0f).withStyle("Bold"));
        for (size_t p = 0; p < numTrackedPeaks; ++p) {
            const auto& peak = trackedPeaks[p];
            if (!peak.isActive || peak.frequencyHz < 20.0f || peak.frequencyHz > 20000.0f)
                continue;

            const float normX = (std::log10(peak.frequencyHz) - std::log10(20.0f)) / (std::log10(20000.0f) - std::log10(20.0f));
            const float x = normX * w;
            const float y = juce::jmap(peak.prominenceDb * 0.5f, -24.0f, 12.0f, h - 14.0f, 14.0f);

            // Resonant Peak Spark Circle
            g.setColour(juce::Colour(0xFFFFD54F));
            g.fillEllipse(x - 3.5f, y - 3.5f, 7.0f, 7.0f);

            // Aura ring
            g.setColour(juce::Colour(0x66FFB300));
            g.drawEllipse(x - 6.0f, y - 6.0f, 12.0f, 12.0f, 1.2f);

            // Frequency label tag (e.g. "420 Hz" or "3.4 kHz")
            juce::String tag = (peak.frequencyHz >= 1000.0f)
                ? juce::String::formatted("%.1fk", peak.frequencyHz / 1000.0f)
                : juce::String::formatted("%d", static_cast<int>(peak.frequencyHz));

            g.setColour(juce::Colour(0xFFFFD700));
            g.drawText(tag, static_cast<int>(x - 18.0f), static_cast<int>(y - 15.0f), 36, 12, juce::Justification::centred);
        }

        // 6. Header Silkscreen Banner
        g.setColour(juce::Colour(0xFFD4AF37));
        g.setFont(juce::FontOptions(11.0f).withStyle("Bold"));
        g.drawText("EXHAUSTIVE SPECTRAL RESONANCE & PEAK MAP", 10, 6, 280, 14, juce::Justification::left);

        // Active Peaks Count Status
        g.setFont(juce::FontOptions(10.0f).withStyle("Bold"));
        if (activePeakCount > 0) {
            g.setColour(juce::Colour(0xFF00E676)); // Green
            juce::String status = juce::String::formatted("ALL PEAKS TRACKED: [ %d ACTIVE RESONANCES ]", activePeakCount);
            g.drawText(status, static_cast<int>(w) - 270, 6, 260, 14, juce::Justification::right);
        } else {
            g.setColour(juce::Colour(0xFF90A4AE));
            g.drawText("FULL SPECTRUM: LINEARIZED & CLEAN", static_cast<int>(w) - 270, 6, 260, 14, juce::Justification::right);
        }

        // Scope Bezel Border
        g.setColour(juce::Colour(0x55333F48));
        g.drawRect(bounds, 1.0f);
    }

private:
    int activePeakCount = 0;
    size_t numTrackedPeaks = 0;
    std::array<VocalCraftSpectralAnalyzer::DetectedPeak, 16> trackedPeaks{};
    std::array<float, VocalCraftSpectralLinearizer::kNumBands> bandReductionsDb{};
    std::array<float, VocalCraftSpectralLinearizer::kNumBands> bandCenterFreqs{};
    std::array<float, VocalCraftSpectralLinearizer::kNumBands> bandTargetNeutralDb{};

    static constexpr float dashPattern[2] = { 4.0f, 4.0f };
};

} // namespace dsp171
