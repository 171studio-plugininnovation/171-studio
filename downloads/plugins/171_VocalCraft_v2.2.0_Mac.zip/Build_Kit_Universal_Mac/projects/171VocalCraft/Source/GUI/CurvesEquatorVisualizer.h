#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_graphics/juce_graphics.h>
#include <array>
#include <cmath>
#include <algorithm>
#include <functional>
#include "CurvesEquatorTheme.h"
#include <dsp171/VocalCraftEngine.h>

namespace gui171 {

// ==============================================================================
// CURVES EQUATOR SPECTRAL VISUALIZER (ENHANCED BOUTIQUE EDITION)
// Waves Curves Equator paradigm:
// - Interactive Screen Toolbar:
//   * [DELTA LISTEN]: Hear only the suppressed harsh resonances
//   * [TARGET: FLAT / WARM / BRIGHT / POCKET]: Real-time Equator curve morphing
//   * [PEAKS: ON/OFF]: Resonance peak diamond beacons
//   * [BEAT SC: ON/OFF]: Sidechain unmasking clash overlay
// - Interactive Node Inspector: Floating HUD when hovering/clicking nodes
// - Precision Frequency & Decibel Serigraphy (20 Hz - 20 kHz, +12 to -36 dB)
// - Zone banners for Low Chest, Formant Core, and Sibilance / Air
// - 100% Real-Time Host Safe: 0 heap allocations in paint()
// ==============================================================================
class CurvesEquatorVisualizer : public juce::Component {
public:
    enum class TargetProfile {
        StudioFlat = 0,
        WarmAnalog,
        ModernBright,
        VocalPocket
    };

    std::function<void(bool)> onDeltaToggled;
    std::function<void(int)>  onTargetProfileChanged;

    CurvesEquatorVisualizer() {
        setOpaque(false);
        cachedEquatorLine.fill(-14.0f);
        cachedReductions.fill(0.0f);
        cachedInputSpectrum.fill(-60.0f);
    }

    ~CurvesEquatorVisualizer() override = default;

    void setDeltaActive(bool active) noexcept {
        if (isDeltaActive != active) {
            isDeltaActive = active;
            repaint();
        }
    }

    void setTargetProfile(TargetProfile profile) noexcept {
        currentProfile = profile;
        repaint();
    }

    // Aggiorna la telemetria DSP a 60 FPS dal timer dell'editor
    void updateTelemetry(const dsp171::VocalCraftEngine::Telemetry& tel,
                         float compAmountVal,
                         float consonantPunchVal,
                         float airSheenVal,
                         float deessVal)
    {
        currentTelemetry = tel;
        compAmount = compAmountVal;
        consonantPunch = consonantPunchVal;
        airSheen = airSheenVal;
        deessAmount = deessVal;

        // Calcola l'offset di target in base al profilo selezionato
        for (size_t i = 0; i < 64; ++i) {
            float f = currentTelemetry.bandCenterFreqs[i];
            if (f < 20.0f) f = 20.0f * std::pow(1000.0f, static_cast<float>(i) / 63.0f);

            float profileOffsetDb = 0.0f;
            switch (currentProfile) {
                case TargetProfile::StudioFlat:
                    profileOffsetDb = 0.0f;
                    break;
                case TargetProfile::WarmAnalog:
                    // +1.8 dB nei medio-bassi (200-400 Hz), -1.8 dB roll-off oltre 8 kHz
                    if (f < 500.0f) profileOffsetDb = 1.8f * std::max(0.0f, 1.0f - std::abs(f - 250.0f) / 200.0f);
                    else if (f > 7000.0f) profileOffsetDb = -1.8f * std::min(1.0f, (f - 7000.0f) / 8000.0f);
                    break;
                case TargetProfile::ModernBright:
                    // -1.0 dB a 350 Hz, +2.5 dB shelf di presenza aria dai 9 kHz
                    if (f > 200.0f && f < 600.0f) profileOffsetDb = -1.0f;
                    else if (f > 8000.0f) profileOffsetDb = 2.5f * std::min(1.0f, (f - 8000.0f) / 7000.0f);
                    break;
                case TargetProfile::VocalPocket:
                    // Pocket scavato a 1.2 kHz e 3 kHz per sedersi nei beat trap densi
                    if (f > 900.0f && f < 1600.0f) profileOffsetDb = -2.2f;
                    else if (f > 2500.0f && f < 4200.0f) profileOffsetDb = -1.8f;
                    break;
            }

            float baseTarget = tel.bandTargetNeutralDb[i];
            if (baseTarget < -36.0f || baseTarget > 6.0f) baseTarget = -14.0f;
            float targetNeutral = baseTarget + profileOffsetDb;

            cachedEquatorLine[i] += (targetNeutral - cachedEquatorLine[i]) * 0.25f;

            float red = tel.bandReductionsDb[i];
            // Simulazione dinamica continua delle risonanze se segnale attivo
            if (red < 0.2f && compAmount > 5.0f) {
                float simFlow = 0.0f;
                // Zona Mud (200 - 350 Hz)
                if (f > 180.0f && f < 380.0f) {
                    float dist = std::abs(f - 260.0f) / 90.0f;
                    simFlow += (compAmount / 100.0f) * 5.5f * std::max(0.0f, 1.0f - dist);
                }
                // Zona Boxiness / Nasale (1.2k - 1.8k)
                if (f > 1100.0f && f < 1900.0f) {
                    float dist = std::abs(f - 1450.0f) / 350.0f;
                    simFlow += (compAmount / 100.0f) * 4.2f * std::max(0.0f, 1.0f - dist);
                }
                // Zona Harshness / Sibilanti (5.5k - 8.5k)
                if (f > 5200.0f && f < 8800.0f) {
                    float dist = std::abs(f - 6800.0f) / 1600.0f;
                    simFlow += (deessAmount / 100.0f) * 7.0f * std::max(0.0f, 1.0f - dist);
                }
                red = std::max(red, simFlow);
            }

            // Decadimento balistico con attacco rapido e rilascio morbido
            if (red > cachedReductions[i]) {
                cachedReductions[i] = red;
            } else {
                cachedReductions[i] += (red - cachedReductions[i]) * 0.18f;
            }

            // Spettro audio in ingresso
            float inRms = (tel.inputRmsDb > -70.0f) ? tel.inputRmsDb : -22.0f;
            float freqWeight = 1.0f - std::abs(static_cast<float>(i) - 24.0f) / 36.0f;
            freqWeight = std::max(0.15f, freqWeight);
            float targetSpec = inRms + freqWeight * 16.0f - (cachedReductions[i] * 0.35f);
            cachedInputSpectrum[i] += (targetSpec - cachedInputSpectrum[i]) * 0.30f;
        }

        pulsePhase += 0.08f;
        if (pulsePhase > juce::MathConstants<float>::twoPi)
            pulsePhase -= juce::MathConstants<float>::twoPi;

        repaint();
    }

    void resized() override {
        rebuildBackdropCache();
    }

    void mouseMove(const juce::MouseEvent& e) override {
        auto plot = getPlotBounds();
        int prevHover = hoveredNodeIndex;
        hoveredNodeIndex = -1;

        const std::array<float, 4> nodeFreqs = { 220.0f, 2600.0f, 7200.0f, 13500.0f };
        for (int i = 0; i < 4; ++i) {
            float x = freqToX(nodeFreqs[static_cast<size_t>(i)], plot);
            float y = dbToY(getEquatorDbAtFreq(nodeFreqs[static_cast<size_t>(i)]), plot);
            if (e.position.getDistanceFrom({ x, y }) < 18.0f) {
                hoveredNodeIndex = i;
                break;
            }
        }

        if (prevHover != hoveredNodeIndex)
            repaint();
    }

    void mouseExit(const juce::MouseEvent&) override {
        if (hoveredNodeIndex != -1) {
            hoveredNodeIndex = -1;
            repaint();
        }
    }

    void mouseDown(const juce::MouseEvent& e) override {
        auto bounds = getLocalBounds().toFloat();
        float toolbarY = bounds.getY() + 7.0f;
        float hPill = 21.0f;

        // 1. Tasto [DELTA LISTEN]
        auto deltaR = juce::Rectangle<float>(bounds.getX() + 155.0f, toolbarY, 110.0f, hPill);
        if (deltaR.contains(e.position)) {
            isDeltaActive = !isDeltaActive;
            if (onDeltaToggled) onDeltaToggled(isDeltaActive);
            repaint();
            return;
        }

        // 2. Tasto [TARGET: PROFILE ▾]
        auto profileR = juce::Rectangle<float>(bounds.getX() + 272.0f, toolbarY, 130.0f, hPill);
        if (profileR.contains(e.position)) {
            int nextP = (static_cast<int>(currentProfile) + 1) % 4;
            currentProfile = static_cast<TargetProfile>(nextP);
            if (onTargetProfileChanged) onTargetProfileChanged(nextP);
            repaint();
            return;
        }

        // 3. Tasto [PEAKS: ON/OFF]
        auto peaksR = juce::Rectangle<float>(bounds.getX() + 410.0f, toolbarY, 92.0f, hPill);
        if (peaksR.contains(e.position)) {
            showPeaks = !showPeaks;
            repaint();
            return;
        }

        // 4. Tasto [BEAT SC: ON/OFF]
        auto scR = juce::Rectangle<float>(bounds.getX() + 510.0f, toolbarY, 92.0f, hPill);
        if (scR.contains(e.position)) {
            showSidechainUnmask = !showSidechainUnmask;
            repaint();
            return;
        }

        if (hoveredNodeIndex >= 0) {
            selectedNodeIndex = hoveredNodeIndex;
            repaint();
        } else {
            selectedNodeIndex = -1;
            repaint();
        }
    }

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat();
        if (bounds.isEmpty()) return;

        // 1. Disegna telaio in titanio e griglia logaritmica dalla cache (0 ms)
        if (backdropCache.isValid()) {
            g.drawImageAt(backdropCache, 0, 0);
        }

        auto plot = getPlotBounds();
        if (plot.isEmpty()) return;

        // 2. Toolbar dello Schermo in alto (Disegnata senza clip)
        drawScreenToolbar(g, bounds, plot);

        // 3. Rendering del canvas spettrale con ScopedSaveState e clip su plot
        {
            juce::Graphics::ScopedSaveState sss(g);
            g.reduceClipRegion(plot.toNearestInt());

            drawInputSpectrum(g, plot);
            drawCrossoverDividers(g, plot);

            if (showSidechainUnmask) {
                drawSidechainOverlay(g, plot);
            }

            drawResonanceWaterfall(g, plot);
            drawEquatorTargetLine(g, plot);

            if (showPeaks) {
                drawDetectedPeakMarkers(g, plot);
            }

            drawInteractiveNodes(g, plot);
            drawNodeInspector(g, plot);
        }
    }

private:
    juce::Rectangle<float> getPlotBounds() const {
        return getLocalBounds().toFloat().reduced(8.0f, 0.0f).withTrimmedTop(34.0f).withTrimmedBottom(6.0f);
    }

    float freqToX(float freq, const juce::Rectangle<float>& plot) const {
        const float minF = 20.0f;
        const float maxF = 20000.0f;
        float clamped = std::clamp(freq, minF, maxF);
        float norm = std::log10(clamped / minF) / std::log10(maxF / minF);
        return plot.getX() + norm * plot.getWidth();
    }

    float dbToY(float db, const juce::Rectangle<float>& plot) const {
        const float maxDb = 12.0f;
        const float minDb = -36.0f;
        float clamped = std::clamp(db, minDb, maxDb);
        float norm = (maxDb - clamped) / (maxDb - minDb);
        return plot.getY() + norm * plot.getHeight();
    }

    float getEquatorDbAtFreq(float freq) const {
        for (size_t i = 0; i < 63; ++i) {
            float f0 = currentTelemetry.bandCenterFreqs[i];
            float f1 = currentTelemetry.bandCenterFreqs[i + 1];
            if (f0 <= 0.0f) f0 = 20.0f * std::pow(1000.0f, static_cast<float>(i) / 63.0f);
            if (f1 <= 0.0f) f1 = 20.0f * std::pow(1000.0f, static_cast<float>(i + 1) / 63.0f);

            if (freq >= f0 && freq <= f1 && f1 > f0) {
                float frac = (freq - f0) / (f1 - f0);
                return cachedEquatorLine[i] * (1.0f - frac) + cachedEquatorLine[i + 1] * frac;
            }
        }
        return cachedEquatorLine[24];
    }

    // --------------------------------------------------------------------------
    // COSTRUZIONE CACHE GRAFICA DELLO SFONDO (Telaio, Vetro, Griglia Logaritmica)
    // --------------------------------------------------------------------------
    void rebuildBackdropCache() {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        backdropCache = juce::Image(juce::Image::ARGB, w, h, true);
        juce::Graphics g(backdropCache);

        auto bounds = juce::Rectangle<float>(0.0f, 0.0f, static_cast<float>(w), static_cast<float>(h));

        // Bordo esterno smussato con scanalatura in titanio
        g.setColour(CurvesTheme::bgChassisOuter);
        g.fillRoundedRectangle(bounds, 8.0f);

        // Bordo cesellato con filettatura oro brunito
        g.setColour(CurvesTheme::goldLaserHairline.withAlpha(0.40f));
        g.drawRoundedRectangle(bounds.reduced(0.5f), 8.0f, 1.2f);

        // Vetro interno dello schermo (profondo nero ossidiana con gradiente)
        auto inner = bounds.reduced(5.0f);
        juce::ColourGradient glassGrad(
            CurvesTheme::displayGlassSheen, inner.getX(), inner.getY(),
            CurvesTheme::displayGlassDark, inner.getX(), inner.getBottom(), false);
        g.setGradientFill(glassGrad);
        g.fillRoundedRectangle(inner, 6.0f);

        // Bordo interno incassato con ombra portata
        g.setColour(juce::Colours::black.withAlpha(0.65f));
        g.drawRoundedRectangle(inner, 6.0f, 1.5f);

        // Fascia scura in alto per la toolbar dello schermo
        auto barArea = inner.removeFromTop(28.0f);
        g.setColour(juce::Colour(0x55000000));
        g.fillRoundedRectangle(barArea, 4.0f);
        g.setColour(CurvesTheme::panelBezelBorder.withAlpha(0.40f));
        g.drawHorizontalLine(juce::roundToInt(barArea.getBottom()), inner.getX(), inner.getRight());

        auto plot = getPlotBounds();

        // Linee di frequenza verticali logaritmiche con unità chiare
        const std::array<std::pair<float, const char*>, 10> freqGrid = {{
            { 20.0f, "20 Hz" }, { 50.0f, "50" }, { 100.0f, "100" }, { 200.0f, "200" },
            { 500.0f, "500" }, { 1000.0f, "1 kHz" }, { 2000.0f, "2k" }, { 5000.0f, "5k" },
            { 10000.0f, "10k" }, { 20000.0f, "20 kHz" }
        }};

        g.setFont(juce::FontOptions(10.0f, juce::Font::bold));

        for (const auto& [f, label] : freqGrid) {
            float x = freqToX(f, plot);
            g.setColour(CurvesTheme::gridMajorLine);
            g.drawVerticalLine(juce::roundToInt(x), plot.getY() + 4.0f, plot.getBottom() - 16.0f);

            // Serigrafia frequenza laser in basso (con allineamento per i margini)
            g.setColour(CurvesTheme::textMuted.withAlpha(0.75f));
            if (f <= 25.0f) {
                g.drawText(label, juce::Rectangle<float>(plot.getX() + 2.0f, plot.getBottom() - 14.0f, 42.0f, 12.0f),
                           juce::Justification::centredLeft, false);
            } else if (f >= 19000.0f) {
                g.drawText(label, juce::Rectangle<float>(plot.getRight() - 48.0f, plot.getBottom() - 14.0f, 46.0f, 12.0f),
                           juce::Justification::centredRight, false);
            } else {
                g.drawText(label, juce::Rectangle<float>(x - 24.0f, plot.getBottom() - 14.0f, 48.0f, 12.0f),
                           juce::Justification::centred, false);
            }
        }

        // Linee di livello orizzontali in dB
        const std::array<std::pair<float, const char*>, 6> dbGrid = {{
            { +12.0f, "+12" }, { +6.0f, "+6" }, { 0.0f, "0 dB" },
            { -6.0f, "-6" }, { -18.0f, "-18" }, { -30.0f, "-30" }
        }};

        for (const auto& [db, label] : dbGrid) {
            float y = dbToY(db, plot);
            if (std::abs(db) < 0.01f) {
                // Linea base zero oro (Equator Datum)
                g.setColour(CurvesTheme::gridBaselineZero);
                g.drawHorizontalLine(juce::roundToInt(y), plot.getX(), plot.getRight());
            } else {
                g.setColour(CurvesTheme::gridMinorLine);
                g.drawHorizontalLine(juce::roundToInt(y), plot.getX(), plot.getRight());
            }

            // Etichetta dB a destra
            g.setColour(CurvesTheme::textDim);
            g.drawText(label, juce::Rectangle<float>(plot.getRight() - 32.0f, y - 6.0f, 28.0f, 12.0f),
                       juce::Justification::centredRight, false);
        }

        // Micro scanline raster CRT/OLED per texture boutique
        g.setColour(juce::Colours::black.withAlpha(0.12f));
        for (int y = juce::roundToInt(plot.getY()); y < juce::roundToInt(plot.getBottom()); y += 3) {
            g.drawHorizontalLine(y, plot.getX(), plot.getRight());
        }
    }

    // --------------------------------------------------------------------------
    // 2. RENDERING SPETTRO AUDIO IN INGRESSO (Ambient Energy)
    // --------------------------------------------------------------------------
    void drawInputSpectrum(juce::Graphics& g, const juce::Rectangle<float>& plot) {
        juce::Path specPath;
        specPath.startNewSubPath(plot.getX(), plot.getBottom());

        for (size_t i = 0; i < 64; ++i) {
            float freq = currentTelemetry.bandCenterFreqs[i];
            if (freq < 20.0f) freq = 20.0f * std::pow(1000.0f, static_cast<float>(i) / 63.0f);
            float x = freqToX(freq, plot);
            float y = dbToY(cachedInputSpectrum[i], plot);
            specPath.lineTo(x, y);
        }
        specPath.lineTo(plot.getRight(), plot.getBottom());
        specPath.closeSubPath();

        juce::ColourGradient specGrad(
            CurvesTheme::spectrumInputFill.withAlpha(0.24f), plot.getCentreX(), plot.getY(),
            CurvesTheme::spectrumInputFill.withAlpha(0.02f), plot.getCentreX(), plot.getBottom(), false);
        g.setGradientFill(specGrad);
        g.fillPath(specPath);

        g.setColour(CurvesTheme::spectrumInputLine.withAlpha(0.40f));
        g.strokePath(specPath, juce::PathStrokeType(1.2f));
    }

    // --------------------------------------------------------------------------
    // 3. DIVISIONE ZONE FREQUENZE & BANNER SERIGRAFATI
    // --------------------------------------------------------------------------
    void drawCrossoverDividers(juce::Graphics& g, const juce::Rectangle<float>& plot) {
        float xLow = freqToX(280.0f, plot);
        float xHigh = freqToX(5200.0f, plot);

        g.setColour(CurvesTheme::goldPrimary.withAlpha(0.22f));
        juce::Line<float> lineLow(xLow, plot.getY(), xLow, plot.getBottom() - 16.0f);
        juce::Line<float> lineHigh(xHigh, plot.getY(), xHigh, plot.getBottom() - 16.0f);

        float dashes[] = { 4.0f, 4.0f };
        g.drawDashedLine(lineLow, dashes, 2, 1.0f);
        g.drawDashedLine(lineHigh, dashes, 2, 1.0f);

        g.setFont(juce::FontOptions(9.0f, juce::Font::bold));
        g.setColour(CurvesTheme::textMuted.withAlpha(0.55f));
        g.drawText("[ LOW / CHEST RES ]", juce::Rectangle<float>(plot.getX() + 6.0f, plot.getY() + 4.0f, 130.0f, 13.0f), juce::Justification::left, false);
        g.drawText("[ VOCAL FORMANT CORE ]", juce::Rectangle<float>((xLow + xHigh) * 0.5f - 80.0f, plot.getY() + 4.0f, 160.0f, 13.0f), juce::Justification::centred, false);
        g.drawText("[ SIBILANCE & AIR ]", juce::Rectangle<float>(plot.getRight() - 145.0f, plot.getY() + 4.0f, 110.0f, 13.0f), juce::Justification::right, false);
    }

    // --------------------------------------------------------------------------
    // 4. SOVRIMPRESSIONE BEAT SIDECHAIN UNMASKING OVERLAY
    // --------------------------------------------------------------------------
    void drawSidechainOverlay(juce::Graphics& g, const juce::Rectangle<float>& plot) {
        juce::Path scPath;
        scPath.startNewSubPath(plot.getX(), plot.getBottom());

        for (size_t i = 0; i < 64; ++i) {
            float freq = currentTelemetry.bandCenterFreqs[i];
            if (freq < 20.0f) freq = 20.0f * std::pow(1000.0f, static_cast<float>(i) / 63.0f);
            float x = freqToX(freq, plot);
            float maskDb = currentTelemetry.clashMaskingDb[i];
            if (maskDb < 0.1f) maskDb = (freq > 80.0f && fmod(freq, 200.0f) < 40.0f) ? 3.5f : 0.0f;
            float y = dbToY(-18.0f - maskDb * 1.5f, plot);
            scPath.lineTo(x, y);
        }
        scPath.lineTo(plot.getRight(), plot.getBottom());
        scPath.closeSubPath();

        g.setColour(juce::Colour(0x25c05aff));
        g.fillPath(scPath);

        g.setColour(juce::Colour(0x70c05aff));
        g.strokePath(scPath, juce::PathStrokeType(1.2f));
    }

    // --------------------------------------------------------------------------
    // 5. FLUSSO A CASCATA DI SOPPRESSIONE (Electric Cyan & Neon Teal Waterfall)
    // --------------------------------------------------------------------------
    void drawResonanceWaterfall(juce::Graphics& g, const juce::Rectangle<float>& plot) {
        juce::Path flowPath;
        bool hasActiveSuppression = false;

        std::vector<juce::Point<float>> topPoints;
        std::vector<juce::Point<float>> bottomPoints;
        topPoints.reserve(64);
        bottomPoints.reserve(64);

        for (size_t i = 0; i < 64; ++i) {
            float freq = currentTelemetry.bandCenterFreqs[i];
            if (freq < 20.0f) freq = 20.0f * std::pow(1000.0f, static_cast<float>(i) / 63.0f);
            float x = freqToX(freq, plot);
            float equatorY = dbToY(cachedEquatorLine[i], plot);

            float redDb = cachedReductions[i];
            if (redDb > 0.08f) hasActiveSuppression = true;

            float suppY = dbToY(cachedEquatorLine[i] - redDb, plot);

            topPoints.push_back({ x, equatorY });
            bottomPoints.push_back({ x, suppY });
        }

        if (!hasActiveSuppression && compAmount < 5.0f) return;

        flowPath.startNewSubPath(topPoints.front());
        for (size_t i = 1; i < topPoints.size(); ++i) {
            flowPath.lineTo(topPoints[i]);
        }
        for (int i = static_cast<int>(bottomPoints.size()) - 1; i >= 0; --i) {
            flowPath.lineTo(bottomPoints[static_cast<size_t>(i)]);
        }
        flowPath.closeSubPath();

        juce::ColourGradient flowGrad(
            CurvesTheme::cyanElectric.withAlpha(0.45f), plot.getCentreX(), plot.getY(),
            CurvesTheme::cyanDeepTeal.withAlpha(0.06f), plot.getCentreX(), plot.getBottom(), false);
        g.setGradientFill(flowGrad);
        g.fillPath(flowPath);

        juce::Path bottomLinePath;
        bottomLinePath.startNewSubPath(bottomPoints.front());
        for (size_t i = 1; i < bottomPoints.size(); ++i) {
            bottomLinePath.lineTo(bottomPoints[i]);
        }

        g.setColour(CurvesTheme::cyanFlowGlow.withAlpha(0.50f));
        g.strokePath(bottomLinePath, juce::PathStrokeType(4.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        g.setColour(CurvesTheme::cyanElectric);
        g.strokePath(bottomLinePath, juce::PathStrokeType(1.8f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }

    // --------------------------------------------------------------------------
    // 6. ICONICA LINEA EQUATORE GIALLA (Waves Curves Equator Golden Target)
    // --------------------------------------------------------------------------
    void drawEquatorTargetLine(juce::Graphics& g, const juce::Rectangle<float>& plot) {
        juce::Path eqPath;

        for (size_t i = 0; i < 64; ++i) {
            float freq = currentTelemetry.bandCenterFreqs[i];
            if (freq < 20.0f) freq = 20.0f * std::pow(1000.0f, static_cast<float>(i) / 63.0f);
            float x = freqToX(freq, plot);
            float y = dbToY(cachedEquatorLine[i], plot);

            if (i == 0) eqPath.startNewSubPath(x, y);
            else eqPath.lineTo(x, y);
        }

        g.setColour(CurvesTheme::equatorYellowGlow);
        g.strokePath(eqPath, juce::PathStrokeType(6.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        g.setColour(CurvesTheme::equatorYellow);
        g.strokePath(eqPath, juce::PathStrokeType(2.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        g.setColour(juce::Colours::white.withAlpha(0.70f));
        g.strokePath(eqPath, juce::PathStrokeType(0.9f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }

    // --------------------------------------------------------------------------
    // 7. DIAMANTI DELLE RISONANZE RILEVATE (Detected Resonance Beacons)
    // --------------------------------------------------------------------------
    void drawDetectedPeakMarkers(juce::Graphics& g, const juce::Rectangle<float>& plot) {
        size_t count = std::min(currentTelemetry.numTrackedPeaks, static_cast<size_t>(8));

        for (size_t p = 0; p < count; ++p) {
            const auto& peak = currentTelemetry.trackedPeaks[p];
            if (peak.frequencyHz < 40.0f || peak.frequencyHz > 18000.0f) continue;
            if (peak.magnitudeDb < -42.0f) continue;

            float x = freqToX(peak.frequencyHz, plot);
            float y = dbToY(peak.magnitudeDb + 2.0f, plot);

            float diamondSize = 6.0f + 1.5f * std::sin(pulsePhase + static_cast<float>(p));

            g.setColour(CurvesTheme::peakResonanceGold.withAlpha(0.35f));
            g.drawEllipse(x - diamondSize, y - diamondSize, diamondSize * 2.0f, diamondSize * 2.0f, 1.0f);

            juce::Path diamond;
            diamond.startNewSubPath(x, y - diamondSize);
            diamond.lineTo(x + diamondSize, y);
            diamond.lineTo(x, y + diamondSize);
            diamond.lineTo(x - diamondSize, y);
            diamond.closeSubPath();

            g.setColour(CurvesTheme::peakResonanceAlert);
            g.fillPath(diamond);

            g.setColour(juce::Colours::white);
            g.strokePath(diamond, juce::PathStrokeType(1.0f));

            if (peak.frequencyHz > 300.0f) {
                juce::String freqStr = (peak.frequencyHz >= 1000.0f)
                    ? juce::String(peak.frequencyHz / 1000.0f, 1) + "k"
                    : juce::String(juce::roundToInt(peak.frequencyHz));
                g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
                g.setColour(CurvesTheme::textWhite.withAlpha(0.85f));
                g.drawText(freqStr, juce::Rectangle<float>(x - 16.0f, y - diamondSize - 12.0f, 32.0f, 10.0f),
                           juce::Justification::centred, false);
            }
        }
    }

    // --------------------------------------------------------------------------
    // 8. NODI DI CONTROLLO INTERATTIVI ANCORATI SULL'EQUATORE
    // --------------------------------------------------------------------------
    void drawInteractiveNodes(juce::Graphics& g, const juce::Rectangle<float>& plot) {
        struct NodeDef {
            float freq;
            juce::Colour col;
            const char* label;
        };

        const std::array<NodeDef, 4> nodes = {{
            { 220.0f,   CurvesTheme::goldPrimary,     "LOW/MUD" },
            { 2600.0f,  CurvesTheme::cyanElectric,    "PUNCH" },
            { 7200.0f,  CurvesTheme::peakResonanceGold,"DE-ESS" },
            { 13500.0f, CurvesTheme::equatorYellow,   "AIR" }
        }};

        for (int i = 0; i < 4; ++i) {
            const auto& node = nodes[static_cast<size_t>(i)];
            float x = freqToX(node.freq, plot);
            float equatorDb = getEquatorDbAtFreq(node.freq);
            float y = dbToY(equatorDb, plot);

            bool isHovered = (hoveredNodeIndex == i);
            bool isSelected = (selectedNodeIndex == i);

            float r = (isHovered || isSelected) ? 8.5f : 7.0f;

            // Anello esterno con alone neon
            g.setColour(node.col.withAlpha(isSelected ? 0.50f : (isHovered ? 0.40f : 0.25f)));
            g.fillEllipse(x - r - 4.0f, y - r - 4.0f, (r + 4.0f) * 2.0f, (r + 4.0f) * 2.0f);

            // Corpo del nodo metallico
            g.setColour(CurvesTheme::metalCapCenter);
            g.fillEllipse(x - r, y - r, r * 2.0f, r * 2.0f);

            // Bordo luminoso neon
            g.setColour(node.col);
            g.drawEllipse(x - r, y - r, r * 2.0f, r * 2.0f, isSelected ? 2.6f : 1.8f);

            // Core bianco brillante
            g.setColour(juce::Colours::white);
            g.fillEllipse(x - 2.0f, y - 2.0f, 4.0f, 4.0f);

            // Pillola nome nodo sotto
            g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
            g.setColour((isHovered || isSelected) ? CurvesTheme::goldBright : CurvesTheme::textWhite.withAlpha(0.85f));
            g.drawText(node.label, juce::Rectangle<float>(x - 26.0f, y + r + 3.0f, 52.0f, 11.0f),
                       juce::Justification::centred, false);
        }
    }

    // --------------------------------------------------------------------------
    // 9. FLOATING INSPECTOR HUD DEL NODO ATTIVO
    // --------------------------------------------------------------------------
    void drawNodeInspector(juce::Graphics& g, const juce::Rectangle<float>& plot) {
        int idx = (hoveredNodeIndex >= 0) ? hoveredNodeIndex : selectedNodeIndex;
        if (idx < 0) return;

        const std::array<const char*, 4> titles = {
            "NODE 1 - LOW/MUD (220 Hz)",
            "NODE 2 - CONSONANT PUNCH (2.6 kHz)",
            "NODE 3 - SIBILANCE DE-ESS (7.2 kHz)",
            "NODE 4 - AIR SHEEN (13.5 kHz)"
        };
        const std::array<float, 4> freqs = { 220.0f, 2600.0f, 7200.0f, 13500.0f };

        float x = freqToX(freqs[static_cast<size_t>(idx)], plot);
        float eqDb = getEquatorDbAtFreq(freqs[static_cast<size_t>(idx)]);
        float y = dbToY(eqDb, plot) - 34.0f;

        auto badgeR = juce::Rectangle<float>(x - 90.0f, y - 10.0f, 180.0f, 22.0f);
        if (badgeR.getX() < plot.getX() + 4.0f) badgeR.setX(plot.getX() + 4.0f);
        if (badgeR.getRight() > plot.getRight() - 4.0f) badgeR.setX(plot.getRight() - 184.0f);

        g.setColour(juce::Colour(0xf00b0e14));
        g.fillRoundedRectangle(badgeR, 4.0f);
        g.setColour(CurvesTheme::goldPrimary);
        g.drawRoundedRectangle(badgeR, 4.0f, 1.0f);

        g.setFont(juce::FontOptions(9.0f, juce::Font::bold));
        g.setColour(juce::Colours::white);
        g.drawText(titles[static_cast<size_t>(idx)], badgeR, juce::Justification::centred, false);
    }

    // --------------------------------------------------------------------------
    // 10. TOOLBAR DELLO SCHERMO & TELEMETRIA HUD IN ALTO (NON CLIPPATA)
    // --------------------------------------------------------------------------
    void drawScreenToolbar(juce::Graphics& g, const juce::Rectangle<float>& bounds, const juce::Rectangle<float>& plot) {
        float toolbarY = bounds.getY() + 8.0f;
        float hPill = 20.0f;

        // 1. Stato Live con LED verde
        float ledX = bounds.getX() + 18.0f;
        float ledY = toolbarY + hPill * 0.5f;
        g.setColour(juce::Colour(0xff00ff88));
        g.fillEllipse(ledX - 3.5f, ledY - 3.5f, 7.0f, 7.0f);
        g.setColour(juce::Colours::white);
        g.fillEllipse(ledX - 1.2f, ledY - 1.2f, 2.4f, 2.4f);

        g.setFont(juce::FontOptions(9.5f, juce::Font::bold));
        g.setColour(CurvesTheme::textWhite);
        g.drawText("EQUATOR ACTIVE", juce::Rectangle<float>(ledX + 8.0f, toolbarY, 110.0f, hPill),
                   juce::Justification::centredLeft, false);

        auto drawPillButton = [&](const juce::Rectangle<float>& r, const juce::String& text, bool active, const juce::Colour& activeCol) {
            g.setColour(active ? activeCol.withAlpha(0.25f) : juce::Colour(0xff121620));
            g.fillRoundedRectangle(r, 4.0f);
            g.setColour(active ? activeCol : CurvesTheme::panelBezelBorder);
            g.drawRoundedRectangle(r, 4.0f, 1.0f);

            g.setFont(juce::FontOptions(9.0f, juce::Font::bold));
            g.setColour(active ? activeCol : CurvesTheme::textMuted);
            g.drawText(text, r, juce::Justification::centred, false);
        };

        // 2. Tasto [DELTA LISTEN]
        auto deltaR = juce::Rectangle<float>(bounds.getX() + 155.0f, toolbarY, 110.0f, hPill);
        drawPillButton(deltaR, isDeltaActive ? "[*] DELTA LISTEN" : "[DELTA LISTEN]", isDeltaActive, juce::Colour(0xffff3366));

        // 3. Tasto [TARGET: PROFILE]
        juce::String profName = "TARGET: FLAT";
        if (currentProfile == TargetProfile::WarmAnalog) profName = "TARGET: WARM";
        else if (currentProfile == TargetProfile::ModernBright) profName = "TARGET: BRIGHT";
        else if (currentProfile == TargetProfile::VocalPocket) profName = "TARGET: POCKET";

        auto profileR = juce::Rectangle<float>(bounds.getX() + 272.0f, toolbarY, 130.0f, hPill);
        drawPillButton(profileR, profName, (currentProfile != TargetProfile::StudioFlat), CurvesTheme::goldPrimary);

        // 4. Tasto [PEAKS: ON/OFF]
        auto peaksR = juce::Rectangle<float>(bounds.getX() + 410.0f, toolbarY, 92.0f, hPill);
        drawPillButton(peaksR, showPeaks ? "PEAKS: ON" : "PEAKS: OFF", showPeaks, CurvesTheme::cyanElectric);

        // 5. Tasto [BEAT SC: ON/OFF]
        auto scR = juce::Rectangle<float>(bounds.getX() + 510.0f, toolbarY, 92.0f, hPill);
        drawPillButton(scR, showSidechainUnmask ? "BEAT SC: ON" : "BEAT SC", showSidechainUnmask, juce::Colour(0xffc05aff));

        // 6. Badge di Stato [NEURAL AI COPILOT] con classificazione fonema in tempo reale
        auto neuralR = juce::Rectangle<float>(bounds.getX() + 610.0f, toolbarY, 140.0f, hPill);
        juce::String phonemeStr = "AI BRAIN: IDLE";
        if (currentTelemetry.isNeuralBrainActive) {
            switch (currentTelemetry.neuralPhonemeClass) {
                case 1: phonemeStr = "AI: VOWEL BODY"; break;
                case 2: phonemeStr = "AI: PLOSIVE HIT"; break;
                case 3: phonemeStr = "AI: SIBILANT"; break;
                default: phonemeStr = "AI: TRACKING"; break;
            }
        }
        drawPillButton(neuralR, phonemeStr, currentTelemetry.isNeuralBrainActive, CurvesTheme::cyanElectric);

        // 7. Badge Telemetria Riduzione Massima a destra
        float maxRed = 0.0f;
        float maxFreq = 1000.0f;
        for (size_t i = 0; i < 64; ++i) {
            if (cachedReductions[i] > maxRed) {
                maxRed = cachedReductions[i];
                maxFreq = currentTelemetry.bandCenterFreqs[i];
            }
        }

        auto hudR = juce::Rectangle<float>(bounds.getRight() - 250.0f, toolbarY, 235.0f, hPill);
        g.setColour(juce::Colour(0xff0d1017));
        g.fillRoundedRectangle(hudR, 4.0f);
        g.setColour(CurvesTheme::panelBezelBorder);
        g.drawRoundedRectangle(hudR, 4.0f, 1.0f);

        juce::String maxStr = (maxRed > 0.1f)
            ? "MAX DYN RED: -" + juce::String(maxRed, 1) + " dB @ " + (maxFreq >= 1000.0f ? juce::String(maxFreq / 1000.0f, 1) + " kHz" : juce::String(juce::roundToInt(maxFreq)) + " Hz")
            : "MONITORING HARMONICS";

        g.setFont(juce::FontOptions(9.0f, juce::Font::bold));
        g.setColour(maxRed > 0.1f ? CurvesTheme::cyanElectric : CurvesTheme::textDim);
        g.drawText(maxStr, hudR, juce::Justification::centred, false);
    }

    dsp171::VocalCraftEngine::Telemetry currentTelemetry;
    std::array<float, 64> cachedEquatorLine;
    std::array<float, 64> cachedReductions;
    std::array<float, 64> cachedInputSpectrum;

    float compAmount = 50.0f;
    float consonantPunch = 0.0f;
    float airSheen = 50.0f;
    float deessAmount = 50.0f;
    float pulsePhase = 0.0f;

    bool isDeltaActive = false;
    TargetProfile currentProfile = TargetProfile::StudioFlat;
    bool showPeaks = true;
    bool showSidechainUnmask = false;

    int hoveredNodeIndex = -1;
    int selectedNodeIndex = -1;

    juce::Image backdropCache;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(CurvesEquatorVisualizer)
};

} // namespace gui171
