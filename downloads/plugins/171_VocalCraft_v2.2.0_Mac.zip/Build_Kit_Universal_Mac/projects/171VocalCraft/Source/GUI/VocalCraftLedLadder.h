#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include "VocalCraftHardwareTheme.h"
#include <array>
#include <algorithm>

namespace dsp171 {

// ==============================================================================
// PRECISION DUAL-COLUMN STEREO 11-SEGMENT LED LADDER METER
// Features Left & Right ballistic columns with a central laser-calibrated dB scale.
// ==============================================================================
class VocalCraftLedLadder : public juce::Component {
public:
    enum class MeterType {
        GainReduction, // 0 dB at top, fills downwards as GR increases
        RmsOutput      // -35 dB at bottom, fills upwards as signal rises
    };

    explicit VocalCraftLedLadder(MeterType type) : meterType(type) {
        setOpaque(false);
        if (meterType == MeterType::GainReduction) {
            currentDbL = 0.0f; targetDbL = 0.0f;
            currentDbR = 0.0f; targetDbR = 0.0f;
        } else {
            currentDbL = -60.0f; targetDbL = -60.0f;
            currentDbR = -60.0f; targetDbR = -60.0f;
        }
    }

    void setValue(float dbValue) noexcept {
        setValue(dbValue, dbValue);
    }

    void setValue(float leftDb, float rightDb) noexcept {
        targetDbL = leftDb;
        targetDbR = (rightDb > -200.0f) ? rightDb : leftDb;

        auto updateBallistics = [this](float& current, float target, float& peak, int& hold) {
            if (meterType == MeterType::GainReduction) {
                if (target < current) {
                    current = target; // instant attack
                } else {
                    current += (target - current) * 0.18f; // smooth release
                }
            } else {
                if (target > current) {
                    current = target;
                } else {
                    current += (target - current) * 0.15f;
                }
                if (current > peak) {
                    peak = current;
                    hold = 30; // ~0.5s at 60 FPS
                } else if (hold > 0) {
                    --hold;
                } else {
                    peak += (current - peak) * 0.08f;
                }
            }
        };

        updateBallistics(currentDbL, targetDbL, peakDbL, peakHoldFramesL);
        updateBallistics(currentDbR, targetDbR, peakDbR, peakHoldFramesR);
        repaint();
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const float w = bounds.getWidth();
        const float h = bounds.getHeight();

        const float labelH = 20.0f;
        const float meterH = h - labelH;

        static const float thresholds[11] = {
            0.0f, -2.0f, -4.0f, -6.0f, -8.0f, -10.0f, -15.0f, -20.0f, -25.0f, -30.0f, -35.0f
        };
        static const char* labels[11] = {
            "0", "-2", "-4", "-6", "-8", "-10", "-15", "-20", "-25", "-30", "-35"
        };

        const float topMargin = 6.0f;
        const float bottomMargin = 6.0f;
        const float availH = meterH - topMargin - bottomMargin;
        const int numSegments = 11;
        const float segGap = 3.0f;
        const float segH = (availH - (numSegments - 1) * segGap) / static_cast<float>(numSegments);

        // Center dB scale geometry
        const float textW = 22.0f;
        const float textX = (w - textW) * 0.5f;

        // Dual columns (Left & Right)
        const float colMargin = 4.0f;
        const float colW = std::max(12.0f, (textX - colMargin - 4.0f));
        const float col1X = textX - colW - 3.0f;
        const float col2X = textX + textW + 3.0f;

        // 1. Recessed Bezel Track for Dual-Column Meter Channel
        juce::Rectangle<float> trackRect(col1X - 3.0f, topMargin - 3.0f, (col2X + colW + 3.0f) - (col1X - 3.0f), availH + 6.0f);
        g.setColour(juce::Colour(0xFF07090C));
        g.fillRoundedRectangle(trackRect, 3.5f);
        g.setColour(juce::Colour(0xFF282F3A));
        g.drawRoundedRectangle(trackRect, 3.5f, 1.0f);

        // Inner shadow
        g.setColour(juce::Colours::black.withAlpha(0.6f));
        g.drawRoundedRectangle(trackRect.reduced(0.5f), 3.0f, 0.8f);

        // 2. Render 11 Segments for Both Columns + Central Scale
        g.setFont(juce::FontOptions(8.0f).withStyle("Bold"));

        for (int i = 0; i < numSegments; ++i) {
            float y = topMargin + static_cast<float>(i) * (segH + segGap);
            juce::Rectangle<float> segRectL(col1X, y, colW, segH);
            juce::Rectangle<float> segRectR(col2X, y, colW, segH);

            // Determine if lit
            bool isLitL = false;
            bool isLitR = false;
            if (meterType == MeterType::GainReduction) {
                if (currentDbL <= -0.4f) isLitL = (thresholds[i] >= currentDbL);
                if (currentDbR <= -0.4f) isLitR = (thresholds[i] >= currentDbR);
            } else {
                isLitL = (currentDbL >= thresholds[i]);
                isLitR = (currentDbR >= thresholds[i]);
            }

            // Determine Color: Top 2 Red, next 3 Amber, bottom 6 Green
            juce::Colour onCol = HardwareTheme::ledGreenOn;
            juce::Colour offCol = HardwareTheme::ledGreenOff;

            if (i <= 1) {
                onCol = HardwareTheme::ledRedOn;
                offCol = HardwareTheme::ledRedOff;
            } else if (i <= 4) {
                onCol = HardwareTheme::ledAmberOn;
                offCol = HardwareTheme::ledAmberOff;
            }

            auto drawSegment = [&](const juce::Rectangle<float>& rect, bool lit) {
                // Segment cup
                g.setColour(juce::Colour(0xFF040608));
                g.fillRoundedRectangle(rect, 1.5f);

                if (lit) {
                    // Saturated LED core
                    juce::ColourGradient ledGrad(juce::Colours::white.withAlpha(0.92f), rect.getX(), rect.getY(),
                                                onCol, rect.getX(), rect.getBottom(), false);
                    g.setGradientFill(ledGrad);
                    g.fillRoundedRectangle(rect, 1.5f);

                    // Internal horizontal cathode wire
                    g.setColour(juce::Colours::white.withAlpha(0.70f));
                    g.drawHorizontalLine(static_cast<int>(rect.getCentreY()), rect.getX() + 1.5f, rect.getRight() - 1.5f);
                } else {
                    g.setColour(offCol);
                    g.fillRoundedRectangle(rect, 1.5f);
                    g.setColour(juce::Colours::black.withAlpha(0.55f));
                    g.drawRoundedRectangle(rect, 1.5f, 0.6f);
                }
            };

            drawSegment(segRectL, isLitL);
            drawSegment(segRectR, isLitR);

            // Central dB Scale Label
            bool anyLit = isLitL || isLitR;
            g.setColour(anyLit ? HardwareTheme::champagneHighlight : HardwareTheme::silkscreenText.withAlpha(0.60f));
            g.drawText(labels[i], static_cast<int>(textX), static_cast<int>(y - 2.0f), static_cast<int>(textW), static_cast<int>(segH + 4.0f),
                       juce::Justification::centred);
        }

        // 3. Silkscreen Label at bottom (Dynamic Sizing - ZERO Clipping!)
        float fontSize = 8.5f;
        juce::Font f = juce::FontOptions(fontSize).withStyle("Bold");
        juce::String title = (meterType == MeterType::GainReduction) ? "GAIN REDUCTION" : "RMS OUTPUT";
        while (f.getStringWidth(title) > (w - 2.0f) && fontSize > 6.0f) {
            fontSize -= 0.5f;
            f = juce::FontOptions(fontSize).withStyle("Bold");
        }
        g.setFont(f);
        g.setColour(HardwareTheme::silkscreenText);
        g.drawText(title, 0, static_cast<int>(h - labelH + 2.0f), static_cast<int>(w), static_cast<int>(labelH),
                   juce::Justification::centred);
    }

private:
    MeterType meterType;
    float currentDbL = -60.0f;
    float targetDbL = -60.0f;
    float peakDbL = -60.0f;
    int peakHoldFramesL = 0;

    float currentDbR = -60.0f;
    float targetDbR = -60.0f;
    float peakDbR = -60.0f;
    int peakHoldFramesR = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalCraftLedLadder)
};

} // namespace dsp171
