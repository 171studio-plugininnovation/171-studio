#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <BinaryData.h>
#include "../PluginProcessor.h"
#include "VocalCraftHardwareTheme.h"
#include "VocalCraftJewelLamp.h"
#include "VocalCraftToggleSwitch.h"
#include "VocalCraftLedLadder.h"
#include "VocalCraftCrtScreen.h"
#include "VocalCraftBoutiqueKnob.h"
#include "VocalCraftSubControls.h"
#include "ResizableHandleComponent.h"

namespace VocalCraftBinaryData = BinaryData;

namespace dsp171 {

// ==============================================================================
// 171 VOCALCRAFT - BOUTIQUE HARDWARE LOOK AND FEEL
// ==============================================================================
class VocalCraftHardwareLookAndFeel : public juce::LookAndFeel_V4 {
public:
    VocalCraftHardwareLookAndFeel() {
        setColour(juce::TooltipWindow::backgroundColourId, juce::Colour(0xFF0F1318));
        setColour(juce::TooltipWindow::textColourId,       HardwareTheme::champagneHighlight);
        setColour(juce::TooltipWindow::outlineColourId,    HardwareTheme::champagneBorder);
    }
};

} // namespace dsp171

// ==============================================================================
// 171 VOCALCRAFT - HARDWARE AUDIO PROCESSOR EDITOR
// ==============================================================================
class VocalCraftAudioProcessorEditor : public juce::AudioProcessorEditor,
                                      private juce::Timer
{
public:
    explicit VocalCraftAudioProcessorEditor(VocalCraftAudioProcessor& p);
    ~VocalCraftAudioProcessorEditor() override;

    void paint(juce::Graphics& g) override;
    void resized() override;
    void timerCallback() override;

private:
    void drawRackChassis(juce::Graphics& g, float w, float h);

    VocalCraftAudioProcessor& processor;
    dsp171::VocalCraftHardwareLookAndFeel customLookAndFeel;

    // Tooltip Window Luxury Styling
    juce::TooltipWindow tooltipWindow { this, 350 };

    // --- Top Left Section: Vintage Lamps & Power Switch ---
    dsp171::VocalCraftFacetedJewelLamp     sidechainJewelLamp;
    dsp171::VocalCraftIncandescentPowerLamp powerLamp;
    dsp171::VocalCraftToggleSwitch         powerToggle { "ON", "OFF" };
    dsp171::VocalCraftMicroLedPip          powerLedPip { dsp171::VocalCraftMicroLedPip::LedColour::Amber };

    // --- Center Section: Dual CRT Phosphor Screens ---
    dsp171::VocalCraftCrtScreen spectrumCrt { dsp171::VocalCraftCrtScreen::CrtMode::SpectrumGreen };
    dsp171::VocalCraftCrtScreen waveformCrt { dsp171::VocalCraftCrtScreen::CrtMode::WaveformCyan };

    // --- Vertical LED Ladders ---
    dsp171::VocalCraftLedLadder gainReductionLadder { dsp171::VocalCraftLedLadder::MeterType::GainReduction };
    dsp171::VocalCraftLedLadder rmsOutputLadder     { dsp171::VocalCraftLedLadder::MeterType::RmsOutput };

    // --- Top Right Section: Chrome Toggle Switches ---
    dsp171::VocalCraftToggleSwitch bypassToggle { "ON", "BYPASS" };
    dsp171::VocalCraftMicroLedPip  bypassLedPip { dsp171::VocalCraftMicroLedPip::LedColour::Amber };

    dsp171::VocalCraftToggleSwitch linkToggle   { "LINK", "A/B" };
    dsp171::VocalCraftMicroLedPip  linkLedPip   { dsp171::VocalCraftMicroLedPip::LedColour::Cyan };

    // --- Bottom Bay: 5 Primary Boutique Knobs ---
    dsp171::VocalCraftBoutiqueKnob smartGainKnob       { "SMART GAIN",        dsp171::VocalCraftBoutiqueKnob::DialStyle::Calibrated0To11, true };
    dsp171::VocalCraftBoutiqueKnob styleCompKnob       { "STYLE COMPRESSOR",  dsp171::VocalCraftBoutiqueKnob::DialStyle::CompressorQuadrant };
    dsp171::VocalCraftBoutiqueKnob spectralLinearKnob  { "SPECTRAL LINEAR",   dsp171::VocalCraftBoutiqueKnob::DialStyle::Calibrated0To11 };
    dsp171::VocalCraftBoutiqueKnob consonantPunchKnob  { "CONSONANT PUNCH",   dsp171::VocalCraftBoutiqueKnob::DialStyle::Calibrated0To11 };
    dsp171::VocalCraftBoutiqueKnob airLiftKnob         { "AIR LIFT",          dsp171::VocalCraftBoutiqueKnob::DialStyle::Calibrated0To11 };

    // --- Dedicated Sub-Controls: Precision Recessed Trimmers ---
    dsp171::VocalCraftMiniTrim deessTrim   { "DE-ESS" };
    dsp171::VocalCraftMiniTrim unmaskTrim  { "BEAT UNMASK" };
    dsp171::VocalCraftMiniTrim clipperTrim { "CLIPPER" };

    // --- APVTS Attachments ---
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> smartGainAttach;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> compAmountAttach;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> linearizerDepthAttach;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> consonantPunchAttach;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> airSheenAttach;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> deessAttach;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> unmaskAttach;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> clipperAttach;

    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bypassAttach;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> autoMakeupAttach;

    plugin_171::ResizableHandleComponent resizerHandle;

    // Cached photorealistic master chassis image
    juce::Image masterChassisImg;
    juce::Image logo171Img;

    // Cached anisotropic brushed background texture
    juce::Image cachedPanelBg;
    int cachedW = 0;
    int cachedH = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalCraftAudioProcessorEditor)
};
