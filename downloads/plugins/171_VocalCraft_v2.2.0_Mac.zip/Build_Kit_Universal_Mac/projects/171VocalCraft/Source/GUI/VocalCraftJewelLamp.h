#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <BinaryData.h>
#include "VocalCraftHardwareTheme.h"
#include <cmath>

namespace dsp171 {

// ==============================================================================
// 1. VINTAGE FACETED AMBER JEWEL LAMP (Sidechain & AI Brain Activity)
// ==============================================================================
// Pure internal optical glass refraction & incandescent filament glow.
// Zero external bloom halos on the chassis.
// ==============================================================================
class VocalCraftFacetedJewelLamp : public juce::Component, public juce::SettableTooltipClient {
public:
    VocalCraftFacetedJewelLamp() {
        setOpaque(false);
    }

    void setActivity(float activity0to1, bool isActive) noexcept {
        float targetBrightness = isActive ? juce::jlimit(0.25f, 1.0f, 0.35f + activity0to1 * 0.65f) : 0.04f;
        brightness += (targetBrightness - brightness) * 0.28f;
        repaint();
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const float size = std::min(bounds.getWidth(), bounds.getHeight());
        const float cx = bounds.getCentreX();
        const float cy = bounds.getCentreY();
        const float r = size * 0.46f;
        const float b = juce::jlimit(0.0f, 1.0f, brightness);
        const bool isOn = (b > 0.08f);

        // 171 Studio Official Boutique Jewel Lamp (Faceted Glass + Knurled Bezel)
        if (BinaryData::namedResourceListSize > 0) {
            juce::Image jewelOn  = juce::ImageCache::getFromMemory(BinaryData::jewel_lamp_amber_on_png, BinaryData::jewel_lamp_amber_on_pngSize);
            juce::Image jewelOff = juce::ImageCache::getFromMemory(BinaryData::jewel_lamp_amber_off_png, BinaryData::jewel_lamp_amber_off_pngSize);
            juce::Image bezelImg = juce::ImageCache::getFromMemory(BinaryData::jewel_lamp_bezel_png, BinaryData::jewel_lamp_bezel_pngSize);

            if (jewelOn.isValid() && jewelOff.isValid()) {
                g.setColour(juce::Colours::black.withAlpha(0.70f));
                g.fillEllipse(cx - r + 1.0f, cy - r + 2.0f, r * 2.0f, r * 2.0f);

                if (bezelImg.isValid()) {
                    g.drawImageWithin(bezelImg, static_cast<int>(cx - r * 1.15f), static_cast<int>(cy - r * 1.15f),
                                      static_cast<int>(r * 2.30f), static_cast<int>(r * 2.30f),
                                      juce::RectanglePlacement::centred);
                }

                // Base unlit lamp
                g.drawImageWithin(jewelOff, static_cast<int>(cx - r), static_cast<int>(cy - r),
                                  static_cast<int>(r * 2.0f), static_cast<int>(r * 2.0f),
                                  juce::RectanglePlacement::centred);

                // Crossfade glowing lit lamp with brightness alpha
                if (b > 0.05f) {
                    g.setOpacity(b);
                    g.drawImageWithin(jewelOn, static_cast<int>(cx - r), static_cast<int>(cy - r),
                                      static_cast<int>(r * 2.0f), static_cast<int>(r * 2.0f),
                                      juce::RectanglePlacement::centred);
                    g.setOpacity(1.0f);

                    // Warm volumetric amber aura
                    float glowAlpha = juce::jlimit(0.10f, 0.55f, b * 0.55f);
                    g.setColour(juce::Colour(0xFFFFB030).withAlpha(glowAlpha));
                    g.fillEllipse(cx - r * 0.5f, cy - r * 0.5f, r, r);
                }
                return;
            }
        }

        // 1. Crisp Bezel Drop Shadow
        g.setColour(juce::Colours::black.withAlpha(0.78f));
        g.fillEllipse(cx - r + 1.2f, cy - r + 2.0f, r * 2.0f, r * 2.0f);

        // 2. Heavy Knurled Brass Bezel Ring
        juce::ColourGradient bezelGrad(
            HardwareTheme::champagneLight, cx - r * 0.7f, cy - r * 0.7f,
            HardwareTheme::champagneDeep, cx + r * 0.7f, cy + r * 0.7f, false);
        bezelGrad.addColour(0.40, HardwareTheme::champagneMid);
        bezelGrad.addColour(0.75, HardwareTheme::champagneDark);
        g.setGradientFill(bezelGrad);
        g.fillEllipse(cx - r, cy - r, r * 2.0f, r * 2.0f);

        // Outer specular rim
        g.setColour(HardwareTheme::champagneHighlight.withAlpha(0.7f));
        g.drawEllipse(cx - r + 0.5f, cy - r + 0.5f, r * 2.0f - 1.0f, r * 2.0f - 1.0f, 0.8f);

        // Circular knurl notches (Machined teeth)
        const float rKnurl = r * 0.88f;
        const int numKnurls = 28;
        for (int k = 0; k < numKnurls; ++k) {
            float a = static_cast<float>(k) * juce::MathConstants<float>::twoPi / static_cast<float>(numKnurls);
            float kx = cx + std::cos(a) * rKnurl;
            float ky = cy + std::sin(a) * rKnurl;
            g.setColour(HardwareTheme::champagneDeep);
            g.fillEllipse(kx - 1.0f, ky - 1.0f, 2.0f, 2.0f);
            g.setColour(HardwareTheme::champagneHighlight.withAlpha(0.75f));
            g.fillEllipse(kx - 0.5f, ky - 0.5f, 1.0f, 1.0f);
        }

        // Inner recessed dark collar rim
        const float rCollar = r * 0.76f;
        g.setColour(juce::Colour(0xFF140F09));
        g.fillEllipse(cx - rCollar, cy - rCollar, rCollar * 2.0f, rCollar * 2.0f);

        juce::ColourGradient innerBezel(
            HardwareTheme::champagneHighlight, cx, cy - rCollar,
            HardwareTheme::champagneDark, cx, cy + rCollar, false);
        g.setGradientFill(innerBezel);
        g.drawEllipse(cx - rCollar, cy - rCollar, rCollar * 2.0f, rCollar * 2.0f, 1.2f);

        // 3. Faceted Diamond Glass Lens (High-Contrast Prisms)
        const float rGem = r * 0.70f;
        const float rTable = rGem * 0.38f;

        juce::Colour gemBase = isOn
            ? HardwareTheme::jewelAmberMid.darker(0.35f)
            : HardwareTheme::jewelAmberDeep.darker(0.75f);
        g.setColour(gemBase);
        g.fillEllipse(cx - rGem, cy - rGem, rGem * 2.0f, rGem * 2.0f);

        const int numFacets = 8;
        for (int i = 0; i < numFacets; ++i) {
            float a1 = static_cast<float>(i) * juce::MathConstants<float>::twoPi / static_cast<float>(numFacets);
            float a2 = static_cast<float>(i + 1) * juce::MathConstants<float>::twoPi / static_cast<float>(numFacets);

            float xOut1 = cx + std::cos(a1) * rGem;
            float yOut1 = cy + std::sin(a1) * rGem;
            float xOut2 = cx + std::cos(a2) * rGem;
            float yOut2 = cy + std::sin(a2) * rGem;

            float xIn1 = cx + std::cos(a1) * rTable;
            float yIn1 = cy + std::sin(a1) * rTable;
            float xIn2 = cx + std::cos(a2) * rTable;
            float yIn2 = cy + std::sin(a2) * rTable;

            juce::Path facet;
            facet.startNewSubPath(xIn1, yIn1);
            facet.lineTo(xOut1, yOut1);
            facet.lineTo(xOut2, yOut2);
            facet.lineTo(xIn2, yIn2);
            facet.closeSubPath();

            float facetLum = 0.5f + 0.4f * std::cos(a1 - 0.8f);
            juce::Colour facetCol = isOn
                ? HardwareTheme::jewelAmberMid.interpolatedWith(HardwareTheme::jewelAmberGlow, facetLum * b)
                : HardwareTheme::jewelAmberDeep.interpolatedWith(juce::Colours::black, 0.4f + facetLum * 0.3f);

            g.setColour(facetCol);
            g.fillPath(facet);

            g.setColour(HardwareTheme::jewelAmberDeep.darker(0.6f).withAlpha(isOn ? 0.85f : 0.45f));
            g.strokePath(facet, juce::PathStrokeType(0.75f));
        }

        // 4. Central Octagonal Table Facet
        juce::Path tableFacet;
        for (int i = 0; i < numFacets; ++i) {
            float a = static_cast<float>(i) * juce::MathConstants<float>::twoPi / static_cast<float>(numFacets);
            float tx = cx + std::cos(a) * rTable;
            float ty = cy + std::sin(a) * rTable;
            if (i == 0) tableFacet.startNewSubPath(tx, ty);
            else        tableFacet.lineTo(tx, ty);
        }
        tableFacet.closeSubPath();

        if (isOn) {
            juce::ColourGradient tableGrad(
                HardwareTheme::jewelAmberCore, cx - rTable * 0.3f, cy - rTable * 0.3f,
                HardwareTheme::jewelAmberMid, cx + rTable * 0.5f, cy + rTable * 0.5f, false);
            g.setGradientFill(tableGrad);
        } else {
            g.setColour(HardwareTheme::jewelAmberDeep.darker(0.6f));
        }
        g.fillPath(tableFacet);

        g.setColour(HardwareTheme::jewelAmberDeep.darker(0.6f).withAlpha(isOn ? 0.95f : 0.5f));
        g.strokePath(tableFacet, juce::PathStrokeType(0.85f));

        // 5. Specular Glint on Upper-Left Facet
        if (isOn) {
            g.setColour(juce::Colours::white.withAlpha(0.92f * b));
            g.fillEllipse(cx - rGem * 0.35f, cy - rGem * 0.40f, 4.0f, 3.0f);
        }
    }

private:
    float brightness = 0.04f;
    juce::Image nanoJewelImg;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalCraftFacetedJewelLamp)
};

// ==============================================================================
// 2. VINTAGE WARM INCANDESCENT "POWER" PILOT LAMP
// ==============================================================================
class VocalCraftIncandescentPowerLamp : public juce::Component, public juce::SettableTooltipClient {
public:
    VocalCraftIncandescentPowerLamp() {
        setOpaque(false);
    }

    void setPowered(bool p) noexcept {
        isPowered = p;
        float target = isPowered ? 1.0f : 0.05f;
        brightness += (target - brightness) * 0.22f;
        repaint();
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const float size = std::min(bounds.getWidth(), bounds.getHeight());
        const float cx = bounds.getCentreX();
        const float cy = bounds.getCentreY();
        const float r = size * 0.46f;
        const float b = juce::jlimit(0.0f, 1.0f, brightness);
        const bool isOn = (b > 0.08f);

        // Nano Banana Photorealistic Tungsten Power Lamp Asset
        if (BinaryData::namedResourceListSize > 0) {
            juce::Image pwrImg = juce::ImageCache::getFromMemory(
                BinaryData::power_lamp_tungsten_nano_128_png,
                BinaryData::power_lamp_tungsten_nano_128_pngSize);

            if (pwrImg.isValid()) {
                g.setColour(juce::Colours::black.withAlpha(0.70f));
                g.fillEllipse(cx - r + 1.0f, cy - r + 2.0f, r * 2.0f, r * 2.0f);

                g.drawImageWithin(pwrImg, static_cast<int>(cx - r), static_cast<int>(cy - r),
                                  static_cast<int>(r * 2.0f), static_cast<int>(r * 2.0f),
                                  juce::RectanglePlacement::centred);

                if (isPowered) {
                    g.setColour(juce::Colour(0xFFFF9520).withAlpha(0.48f));
                    g.fillEllipse(cx - r * 0.35f, cy - r * 0.35f, r * 0.70f, r * 0.70f);
                }
                return;
            }
        }

        // 1. Crisp Collar Shadow
        g.setColour(juce::Colours::black.withAlpha(0.78f));
        g.fillEllipse(cx - r + 1.2f, cy - r + 2.0f, r * 2.0f, r * 2.0f);

        // 2. Heavy Hexagonal Chrome Locking Nut
        const float rHex = r * 0.98f;
        juce::Path hexNut;
        for (int i = 0; i < 6; ++i) {
            float a = static_cast<float>(i) * juce::MathConstants<float>::twoPi / 6.0f + 0.26f;
            float hx = cx + std::cos(a) * rHex;
            float hy = cy + std::sin(a) * rHex;
            if (i == 0) hexNut.startNewSubPath(hx, hy);
            else        hexNut.lineTo(hx, hy);
        }
        hexNut.closeSubPath();

        juce::ColourGradient nutGrad(HardwareTheme::chromeHighlight, cx - rHex, cy - rHex,
                                     HardwareTheme::chromeDeep, cx + rHex, cy + rHex, false);
        nutGrad.addColour(0.35, HardwareTheme::chromeMid);
        nutGrad.addColour(0.70, HardwareTheme::chromeDark);
        g.setGradientFill(nutGrad);
        g.fillPath(hexNut);

        g.setColour(juce::Colours::white.withAlpha(0.6f));
        g.strokePath(hexNut, juce::PathStrokeType(1.0f));

        // Circular Recessed Collar Inside Nut
        const float rCollar = r * 0.78f;
        juce::ColourGradient collarGrad(HardwareTheme::chromeDark, cx, cy - rCollar,
                                        HardwareTheme::chromeDeep, cx, cy + rCollar, false);
        g.setGradientFill(collarGrad);
        g.fillEllipse(cx - rCollar, cy - rCollar, rCollar * 2.0f, rCollar * 2.0f);

        // Threaded Brass Ring Bezel
        const float rBezel = rCollar * 0.88f;
        juce::ColourGradient ringGrad(HardwareTheme::champagneHighlight, cx - rBezel, cy - rBezel,
                                      HardwareTheme::champagneDeep, cx + rBezel, cy + rBezel, false);
        ringGrad.addColour(0.4, HardwareTheme::champagneLight);
        ringGrad.addColour(0.7, HardwareTheme::champagneDark);
        g.setGradientFill(ringGrad);
        g.fillEllipse(cx - rBezel, cy - rBezel, rBezel * 2.0f, rBezel * 2.0f);

        // Dark Reflector Interior
        const float rLens = rBezel * 0.82f;
        g.setColour(juce::Colour(0xFF140802));
        g.fillEllipse(cx - rLens, cy - rLens, rLens * 2.0f, rLens * 2.0f);

        // 3. Convex Amber Pilot Glass Dome
        juce::Colour domeBright = HardwareTheme::pilotPowerOrange.interpolatedWith(HardwareTheme::pilotPowerHot, b);
        juce::Colour domeDark = HardwareTheme::pilotPowerDark;

        juce::ColourGradient lensGrad(isOn ? domeBright : domeDark.brighter(0.2f), cx, cy - rLens * 0.3f,
                                      domeDark.darker(0.5f), cx, cy + rLens, true);
        g.setGradientFill(lensGrad);
        g.fillEllipse(cx - rLens, cy - rLens, rLens * 2.0f, rLens * 2.0f);

        // 4. Coiled Tungsten Filament Inside Bulb
        const float filR = rLens * 0.42f;
        juce::Path filament;
        filament.startNewSubPath(cx - filR, cy + filR * 0.5f);
        filament.cubicTo(cx - filR * 0.6f, cy - filR * 0.8f,
                         cx + filR * 0.6f, cy - filR * 0.8f,
                         cx + filR, cy + filR * 0.5f);

        if (isOn) {
            // Hot Incandescent Tungsten Core
            g.setColour(HardwareTheme::pilotPowerHot.withAlpha(0.95f * b));
            g.strokePath(filament, juce::PathStrokeType(1.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Inner Filament Glow
            g.setColour(HardwareTheme::pilotPowerOrange.withAlpha(0.75f * b));
            g.strokePath(filament, juce::PathStrokeType(3.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        } else {
            // Unlit Dark Tungsten Wire
            g.setColour(juce::Colour(0xFF332015));
            g.strokePath(filament, juce::PathStrokeType(1.0f));
        }

        // 5. Specular Glints on Outer Glass Dome
        g.setColour(juce::Colours::white.withAlpha(isOn ? 0.75f : 0.35f));
        g.fillEllipse(cx - rLens * 0.48f, cy - rLens * 0.52f, rLens * 0.32f, rLens * 0.18f);

        g.setColour(juce::Colours::white.withAlpha(isOn ? 0.45f : 0.15f));
        g.fillEllipse(cx + rLens * 0.30f, cy + rLens * 0.32f, rLens * 0.15f, rLens * 0.09f);
    }

private:
    float brightness = 1.0f;
    bool isPowered = true;
    juce::Image nanoPowerImg;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalCraftIncandescentPowerLamp)
};

// ==============================================================================
// 3. PRECISION MICRO-LED INDICATOR PIP
// ==============================================================================
class VocalCraftMicroLedPip : public juce::Component {
public:
    enum class LedColour { Amber, Cyan, Green, Red };

    explicit VocalCraftMicroLedPip(LedColour col = LedColour::Amber) : ledColour(col) {
        setOpaque(false);
        if (BinaryData::namedResourceListSize > 0) {
            if (ledColour == LedColour::Amber) {
                ledOnImg = juce::ImageCache::getFromMemory(BinaryData::led_micro_pip_amber_on_png, BinaryData::led_micro_pip_amber_on_pngSize);
            } else {
                ledOnImg = juce::ImageCache::getFromMemory(BinaryData::led_micro_pip_blue_on_png, BinaryData::led_micro_pip_blue_on_pngSize);
            }
            ledOffImg = juce::ImageCache::getFromMemory(BinaryData::led_micro_pip_unlit_off_png, BinaryData::led_micro_pip_unlit_off_pngSize);
        }
    }

    void setLit(bool lit) noexcept {
        if (isLit != lit) {
            isLit = lit;
            repaint();
        }
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        if (isLit ? ledOnImg.isValid() : ledOffImg.isValid()) {
            const float size = std::min(bounds.getWidth(), bounds.getHeight());
            const float cx = bounds.getCentreX();
            const float cy = bounds.getCentreY();
            const juce::Rectangle<float> imgRect(cx - size * 0.5f, cy - size * 0.5f, size, size);
            g.drawImage(isLit ? ledOnImg : ledOffImg, imgRect);
            return;
        }

        const float size = std::min(bounds.getWidth(), bounds.getHeight());
        const float cx = bounds.getCentreX();
        const float cy = bounds.getCentreY();
        const float r = size * 0.45f;

        juce::Colour activeCol = HardwareTheme::ledAmberOn;
        juce::Colour offCol = HardwareTheme::ledAmberOff;

        if (ledColour == LedColour::Cyan) {
            activeCol = HardwareTheme::crtCyanTraceNeon;
            offCol = juce::Colour(0xFF042028);
        } else if (ledColour == LedColour::Green) {
            activeCol = HardwareTheme::ledGreenOn;
            offCol = HardwareTheme::ledGreenOff;
        } else if (ledColour == LedColour::Red) {
            activeCol = HardwareTheme::ledRedOn;
            offCol = HardwareTheme::ledRedOff;
        }

        g.setColour(juce::Colours::black.withAlpha(0.8f));
        g.fillEllipse(cx - r + 0.8f, cy - r + 1.2f, r * 2.0f, r * 2.0f);

        g.setColour(juce::Colour(0xFF0A0C0F));
        g.fillEllipse(cx - r, cy - r, r * 2.0f, r * 2.0f);

        g.setColour(HardwareTheme::chromeDark);
        g.drawEllipse(cx - r, cy - r, r * 2.0f, r * 2.0f, 0.75f);

        const float rLed = r * 0.72f;
        if (isLit) {
            juce::ColourGradient core(juce::Colours::white.withAlpha(0.95f), cx, cy - rLed * 0.2f,
                                      activeCol, cx, cy + rLed, true);
            g.setGradientFill(core);
            g.fillEllipse(cx - rLed, cy - rLed, rLed * 2.0f, rLed * 2.0f);

            g.setColour(juce::Colours::white.withAlpha(0.85f));
            g.fillEllipse(cx - rLed * 0.45f, cy - rLed * 0.52f, rLed * 0.35f, rLed * 0.20f);
        } else {
            g.setColour(offCol);
            g.fillEllipse(cx - rLed, cy - rLed, rLed * 2.0f, rLed * 2.0f);
            g.setColour(juce::Colours::white.withAlpha(0.12f));
            g.drawEllipse(cx - rLed, cy - rLed, rLed * 2.0f, rLed * 2.0f, 0.5f);
        }
    }

private:
    LedColour ledColour;
    bool isLit = true;
    juce::Image ledOnImg;
    juce::Image ledOffImg;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalCraftMicroLedPip)
};

} // namespace dsp171
