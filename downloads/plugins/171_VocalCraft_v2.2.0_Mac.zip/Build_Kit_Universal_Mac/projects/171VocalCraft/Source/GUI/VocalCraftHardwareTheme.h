#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_graphics/juce_graphics.h>
#include <cmath>
#include <algorithm>

namespace dsp171 {

// ==============================================================================
// 171 VOCALCRAFT - BOUTIQUE HARDWARE PBR DESIGN SYSTEM & COLOR TOKENS
// ==============================================================================
namespace HardwareTheme {

    // --- Champagne Brass / Gold Anodized ---
    inline const juce::Colour champagneHighlight { 0xFFFFF6D8 };
    inline const juce::Colour champagneLight     { 0xFFDFC48B };
    inline const juce::Colour champagneMid       { 0xFFB28F4C };
    inline const juce::Colour champagneDark      { 0xFF6F5322 };
    inline const juce::Colour champagneDeep      { 0xFF36250B };
    inline const juce::Colour champagneBorder    { 0xFF8A6E37 };

    // --- Brushed Dark Slate Titanium Panel ---
    inline const juce::Colour titaniumLight      { 0xFF282F3A };
    inline const juce::Colour titaniumMid        { 0xFF1B2027 };
    inline const juce::Colour titaniumDark       { 0xFF12151B };
    inline const juce::Colour titaniumDeep       { 0xFF0B0D11 };

    // --- Rack Ears & Mounting Slots ---
    inline const juce::Colour rackEarLight       { 0xFF2D333D };
    inline const juce::Colour rackEarMid         { 0xFF1C2027 };
    inline const juce::Colour rackEarDark        { 0xFF101217 };
    inline const juce::Colour slotBevel          { 0xFF454F5E };
    inline const juce::Colour slotInterior       { 0xFF07080B };

    // --- Hex Allen Socket Bolts ---
    inline const juce::Colour boltMetalLight     { 0xFF4A5463 };
    inline const juce::Colour boltMetalMid       { 0xFF2A303A };
    inline const juce::Colour boltMetalDark      { 0xFF161A20 };
    inline const juce::Colour boltSocketHole     { 0xFF0A0C0E };

    // --- CRT Vector Phosphor: P1 Green (Spectrum) ---
    inline const juce::Colour crtGreenBg         { 0xFF021408 };
    inline const juce::Colour crtGreenGrid       { 0x3300FF66 };
    inline const juce::Colour crtGreenGridSub    { 0x1A00FF66 };
    inline const juce::Colour crtGreenTraceCore  { 0xFFEAFFE8 };
    inline const juce::Colour crtGreenTraceNeon  { 0xFF00FF66 };
    inline const juce::Colour crtGreenBloom      { 0x5500E552 };
    inline const juce::Colour crtGreenText       { 0xFF4DFF88 };

    // --- CRT Vector Phosphor: P31 Cyan (Waveform) ---
    inline const juce::Colour crtCyanBg          { 0xFF02141C };
    inline const juce::Colour crtCyanGrid        { 0x3300F0FF };
    inline const juce::Colour crtCyanGridSub     { 0x1A00F0FF };
    inline const juce::Colour crtCyanTraceCore   { 0xFFE0FFFF };
    inline const juce::Colour crtCyanTraceNeon   { 0xFF00E5FF };
    inline const juce::Colour crtCyanBloom       { 0x5500B4D8 };
    inline const juce::Colour crtCyanText        { 0xFF38E5FF };
    inline const juce::Colour crtPunchAmber      { 0x77FFB300 };

    // --- CRT Glass & Bezel Framing ---
    inline const juce::Colour crtBezelOuterLight { 0xFF3A424E };
    inline const juce::Colour crtBezelOuterMid   { 0xFF1E232B };
    inline const juce::Colour crtBezelOuterDark  { 0xFF0F1115 };
    inline const juce::Colour crtBezelRimChamp   { 0xFF7A6438 };
    inline const juce::Colour crtGlassReflection { 0x18FFFFFF };

    // --- LED Ladder Segments ---
    inline const juce::Colour ledHousingOff      { 0xFF101416 };
    inline const juce::Colour ledGreenOn         { 0xFF00E676 };
    inline const juce::Colour ledGreenGlow       { 0x6600E676 };
    inline const juce::Colour ledGreenOff        { 0xFF0A2B18 };
    inline const juce::Colour ledAmberOn         { 0xFFFFB300 };
    inline const juce::Colour ledAmberGlow       { 0x66FFB300 };
    inline const juce::Colour ledAmberOff        { 0xFF2D1E08 };
    inline const juce::Colour ledRedOn           { 0xFFFF1744 };
    inline const juce::Colour ledRedGlow         { 0x66FF1744 };
    inline const juce::Colour ledRedOff          { 0xFF2D0A10 };

    // --- Vintage Lamps & Switches ---
    inline const juce::Colour jewelAmberCore     { 0xFFFFF176 };
    inline const juce::Colour jewelAmberMid      { 0xFFFF9800 };
    inline const juce::Colour jewelAmberDeep     { 0xFF8D4000 };
    inline const juce::Colour jewelAmberGlow     { 0x88FF9800 };

    inline const juce::Colour pilotPowerHot      { 0xFFFFF9C4 };
    inline const juce::Colour pilotPowerOrange   { 0xFFFF8F00 };
    inline const juce::Colour pilotPowerDark     { 0xFF7E3900 };

    inline const juce::Colour chromeHighlight    { 0xFFFFFFFF };
    inline const juce::Colour chromeMid          { 0xFFCCD1D6 };
    inline const juce::Colour chromeDark         { 0xFF656B73 };
    inline const juce::Colour chromeDeep         { 0xFF22262B };

    // --- Laser-Etched Silkscreen ---
    inline const juce::Colour silkscreenText     { 0xFFD7CFBF };
    inline const juce::Colour silkscreenGold     { 0xFFE0C489 };
    inline const juce::Colour silkscreenShadow   { 0x99000000 };

    // ==========================================================================
    // PROCEDURAL ANISOTROPIC TEXTURE GENERATOR (Cached for 60 FPS performance)
    // ==========================================================================
    inline juce::Image createBrushedTitaniumTexture(int width, int height)
    {
        if (width <= 0 || height <= 0) return {};

        juce::Image img(juce::Image::ARGB, width, height, false);
        juce::Graphics g(img);

        const float fw = static_cast<float>(width);
        const float fh = static_cast<float>(height);

        // 1. Base metallic gradient (deep slate titanium)
        juce::ColourGradient baseGrad(titaniumLight, 0.0f, 0.0f,
                                      titaniumDeep, 0.0f, fh, false);
        baseGrad.addColour(0.35, titaniumMid);
        baseGrad.addColour(0.70, titaniumDark);
        g.setGradientFill(baseGrad);
        g.fillAll();

        // 2. Multi-scale horizontal micro-brush striations
        juce::Random rnd(171); // Deterministic seed for identical gorgeous grain

        // Pass A: Fine 1px hairline micro-striations
        for (int y = 0; y < height; ++y)
        {
            float noise = rnd.nextFloat();
            float alpha = (noise - 0.48f) * 0.052f;
            if (alpha > 0.0f)
            {
                g.setColour(juce::Colours::white.withAlpha(alpha));
                g.drawHorizontalLine(y, 0.0f, fw);
            }
            else
            {
                g.setColour(juce::Colours::black.withAlpha(-alpha * 1.6f));
                g.drawHorizontalLine(y, 0.0f, fw);
            }
        }

        // Pass B: Medium multi-pixel grain bands (2-4px)
        for (int y = 0; y < height; y += 3)
        {
            float bandNoise = rnd.nextFloat();
            if (bandNoise > 0.65f)
            {
                float bandAlpha = (bandNoise - 0.65f) * 0.045f;
                g.setColour(juce::Colours::white.withAlpha(bandAlpha));
                g.fillRect(0.0f, static_cast<float>(y), fw, 2.0f);
            }
            else if (bandNoise < 0.28f)
            {
                float bandAlpha = (0.28f - bandNoise) * 0.06f;
                g.setColour(juce::Colours::black.withAlpha(bandAlpha));
                g.fillRect(0.0f, static_cast<float>(y), fw, 2.0f);
            }
        }

        // 3. Dual Vertical Studio Lighting Sheen Bands (Professional Studio Photography Rig)
        // Sheen Band 1: ~28% width
        const float sheen1X = fw * 0.28f;
        const float sheen1W = fw * 0.22f;
        juce::ColourGradient sheen1(
            juce::Colours::white.withAlpha(0.046f), sheen1X, 0.0f,
            juce::Colours::transparentBlack, sheen1X + sheen1W * 0.5f, 0.0f, true);
        g.setGradientFill(sheen1);
        g.fillRect(sheen1X - sheen1W * 0.5f, 0.0f, sheen1W, fh);

        // Sheen Band 2: ~72% width
        const float sheen2X = fw * 0.72f;
        const float sheen2W = fw * 0.24f;
        juce::ColourGradient sheen2(
            juce::Colours::white.withAlpha(0.042f), sheen2X, 0.0f,
            juce::Colours::transparentBlack, sheen2X + sheen2W * 0.5f, 0.0f, true);
        g.setGradientFill(sheen2);
        g.fillRect(sheen2X - sheen2W * 0.5f, 0.0f, sheen2W, fh);

        // 4. Subtle Perimeter Vignette for Physical Panel Depth
        juce::ColourGradient vigH(
            juce::Colours::black.withAlpha(0.18f), 0.0f, 0.0f,
            juce::Colours::transparentBlack, fw * 0.04f, 0.0f, false);
        g.setGradientFill(vigH);
        g.fillRect(0.0f, 0.0f, fw * 0.04f, fh);

        juce::ColourGradient vigHR(
            juce::Colours::black.withAlpha(0.18f), fw, 0.0f,
            juce::Colours::transparentBlack, fw * 0.96f, 0.0f, false);
        g.setGradientFill(vigHR);
        g.fillRect(fw * 0.96f, 0.0f, fw * 0.04f, fh);

        return img;
    }

    // ==========================================================================
    // PROCEDURAL HEX ALLEN BOLT RENDERER
    // ==========================================================================
    inline void drawHexAllenBolt(juce::Graphics& g, float cx, float cy, float radius)
    {
        // 1. Recessed Countersink Bore in Titanium Panel
        const float counterR = radius * 1.18f;
        g.setColour(juce::Colours::black.withAlpha(0.85f));
        g.fillEllipse(cx - counterR, cy - counterR, counterR * 2.0f, counterR * 2.0f);

        // Countersink Lower Bevel Catch-Light (Specular reflection on machined edge)
        juce::ColourGradient boreCatch(
            juce::Colours::transparentBlack, cx, cy - counterR,
            champagneHighlight.withAlpha(0.35f), cx, cy + counterR, false);
        g.setGradientFill(boreCatch);
        g.drawEllipse(cx - counterR, cy - counterR, counterR * 2.0f, counterR * 2.0f, 1.0f);

        // 2. Bolt Head Cylindrical Chamfer (CNC Dark Titanium)
        juce::ColourGradient boltHead(boltMetalLight, cx - radius * 0.6f, cy - radius * 0.6f,
                                      boltMetalDark, cx + radius * 0.6f, cy + radius * 0.6f, false);
        boltHead.addColour(0.4, boltMetalMid);
        g.setGradientFill(boltHead);
        g.fillEllipse(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f);

        // Lathe-Turned Concentric Micro-Grooves on Bolt Face
        g.setColour(juce::Colours::white.withAlpha(0.12f));
        g.drawEllipse(cx - radius * 0.78f, cy - radius * 0.78f, radius * 1.56f, radius * 1.56f, 0.6f);
        g.setColour(juce::Colours::black.withAlpha(0.25f));
        g.drawEllipse(cx - radius * 0.62f, cy - radius * 0.62f, radius * 1.24f, radius * 1.24f, 0.6f);

        // Specular outer rim highlight (top-left)
        g.setColour(juce::Colours::white.withAlpha(0.45f));
        g.drawEllipse(cx - radius + 0.4f, cy - radius + 0.4f, radius * 2.0f - 0.8f, radius * 2.0f - 0.8f, 0.8f);

        // 3. Hexagonal Allen Socket
        const float hexR = radius * 0.50f;
        juce::Path hexPath;
        for (int i = 0; i < 6; ++i)
        {
            float a = static_cast<float>(i) * juce::MathConstants<float>::twoPi / 6.0f + 0.26f;
            float px = cx + std::cos(a) * hexR;
            float py = cy + std::sin(a) * hexR;
            if (i == 0) hexPath.startNewSubPath(px, py);
            else        hexPath.lineTo(px, py);
        }
        hexPath.closeSubPath();

        // Inner deep socket hole
        g.setColour(boltSocketHole);
        g.fillPath(hexPath);

        // Inner shadow on top facets
        g.setColour(juce::Colours::black.withAlpha(0.92f));
        g.strokePath(hexPath, juce::PathStrokeType(1.1f));

        // Reflected catch-light on socket bottom lip
        g.setColour(boltMetalLight.withAlpha(0.55f));
        g.drawLine(cx - hexR * 0.45f, cy + hexR * 0.45f, cx + hexR * 0.45f, cy + hexR * 0.45f, 0.8f);
    }

} // namespace HardwareTheme

} // namespace dsp171
