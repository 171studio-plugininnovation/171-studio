#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include "VocalCraftHardwareTheme.h"

namespace dsp171 {

// ==============================================================================
// VINTAGE CHROME BAT-HANDLE TOGGLE SWITCH
// ==============================================================================
class VocalCraftToggleSwitch : public juce::ToggleButton {
public:
    VocalCraftToggleSwitch(const juce::String& upperText, const juce::String& lowerText)
        : topLabel(upperText), bottomLabel(lowerText)
    {
        setMouseCursor(juce::MouseCursor::PointingHandCursor);
        setOpaque(false);
    }

    void paint(juce::Graphics& g) override {
        const auto bounds = getLocalBounds().toFloat();
        const bool isUp = getToggleState();

        // 1. Official 171 Studio Heavy-Duty Chrome Baton Switch
        if (BinaryData::namedResourceListSize > 0) {
            auto img = juce::ImageCache::getFromMemory(
                isUp ? BinaryData::switch_baton_up_png : BinaryData::switch_baton_down_png,
                isUp ? BinaryData::switch_baton_up_pngSize : BinaryData::switch_baton_down_pngSize);
            if (!img.isValid()) {
                img = juce::ImageCache::getFromMemory(
                    isUp ? BinaryData::toggle_baton_up_nano_128_png : BinaryData::toggle_baton_down_nano_128_png,
                    isUp ? BinaryData::toggle_baton_up_nano_128_pngSize : BinaryData::toggle_baton_down_nano_128_pngSize);
            }

            if (img.isValid()) {
                // Reserve 14px top and 14px bottom for silkscreen labels
                const float labelH = 14.0f;
                const float switchH = bounds.getHeight() - labelH * 2.0f;
                juce::Rectangle<float> switchRect(bounds.getX(), bounds.getY() + labelH, bounds.getWidth(), switchH);

                g.drawImageWithin(img, static_cast<int>(switchRect.getX()), static_cast<int>(switchRect.getY()),
                                  static_cast<int>(switchRect.getWidth()), static_cast<int>(switchRect.getHeight()),
                                  juce::RectanglePlacement::centred);

                // Silkscreen Labels (Above and Below)
                g.setFont(juce::FontOptions(10.0f).withStyle("Bold"));
                g.setColour(isUp ? HardwareTheme::champagneHighlight : HardwareTheme::silkscreenText.withAlpha(0.65f));
                g.drawText(topLabel, 0, 0, static_cast<int>(bounds.getWidth()), static_cast<int>(labelH), juce::Justification::centred);

                g.setColour(!isUp ? HardwareTheme::champagneHighlight : HardwareTheme::silkscreenText.withAlpha(0.65f));
                g.drawText(bottomLabel, 0, static_cast<int>(bounds.getBottom() - labelH), static_cast<int>(bounds.getWidth()), static_cast<int>(labelH), juce::Justification::centred);
                return;
            }
        }

        const float w = bounds.getWidth();
        const float h = bounds.getHeight();
        const float cx = w * 0.5f;
        const float cy = h * 0.5f;

        // 1. Threaded Bushing / Chrome Nut at Center
        const float nutR = std::min(w, h) * 0.32f;

        // Nut Drop Shadow
        g.setColour(juce::Colours::black.withAlpha(0.65f));
        g.fillEllipse(cx - nutR + 1.2f, cy - nutR + 2.0f, nutR * 2.0f, nutR * 2.0f);

        // Hexagonal Locking Nut
        juce::Path hexNut;
        for (int i = 0; i < 6; ++i) {
            float a = static_cast<float>(i) * juce::MathConstants<float>::twoPi / 6.0f;
            float hx = cx + std::cos(a) * nutR;
            float hy = cy + std::sin(a) * nutR;
            if (i == 0) hexNut.startNewSubPath(hx, hy);
            else        hexNut.lineTo(hx, hy);
        }
        hexNut.closeSubPath();

        juce::ColourGradient nutGrad(HardwareTheme::chromeHighlight, cx - nutR, cy - nutR,
                                     HardwareTheme::chromeDeep, cx + nutR, cy + nutR, false);
        nutGrad.addColour(0.4, HardwareTheme::chromeMid);
        nutGrad.addColour(0.7, HardwareTheme::chromeDark);
        g.setGradientFill(nutGrad);
        g.fillPath(hexNut);

        g.setColour(juce::Colours::white.withAlpha(0.5f));
        g.strokePath(hexNut, juce::PathStrokeType(0.8f));

        // Circular Threaded Bushing Inside Nut
        const float bushR = nutR * 0.65f;
        juce::ColourGradient bushGrad(HardwareTheme::chromeDark, cx, cy - bushR,
                                      HardwareTheme::chromeDeep, cx, cy + bushR, false);
        g.setGradientFill(bushGrad);
        g.fillEllipse(cx - bushR, cy - bushR, bushR * 2.0f, bushR * 2.0f);

        // Dark slot cavity
        g.setColour(juce::Colours::black.withAlpha(0.9f));
        g.fillEllipse(cx - bushR * 0.45f, cy - bushR * 0.65f, bushR * 0.9f, bushR * 1.3f);

        // 2. Bat-Handle Lever
        // Lever pivots: pointing UP (~ -40 degrees) or DOWN (~ +40 degrees)
        const float leverLength = nutR * 1.85f;
        const float baseWidth = nutR * 0.48f;
        const float tipWidth = nutR * 0.72f;

        const float tipY = isUp ? (cy - leverLength * 0.88f) : (cy + leverLength * 0.88f);
        const float tipX = cx + (isUp ? -2.0f : 2.0f);

        // Bat lever shadow on backplate
        juce::Path shadowPath;
        shadowPath.startNewSubPath(cx - baseWidth * 0.5f + 2.0f, cy + 3.0f);
        shadowPath.lineTo(cx + baseWidth * 0.5f + 2.0f, cy + 3.0f);
        shadowPath.lineTo(tipX + tipWidth * 0.5f + 3.0f, tipY + 4.0f);
        shadowPath.lineTo(tipX - tipWidth * 0.5f + 3.0f, tipY + 4.0f);
        shadowPath.closeSubPath();
        g.setColour(juce::Colours::black.withAlpha(0.55f));
        g.fillPath(shadowPath);

        // Chrome Bat Lever Stem
        juce::Path leverPath;
        leverPath.startNewSubPath(cx - baseWidth * 0.5f, cy);
        leverPath.lineTo(cx + baseWidth * 0.5f, cy);
        leverPath.lineTo(tipX + tipWidth * 0.5f, tipY);
        leverPath.lineTo(tipX - tipWidth * 0.5f, tipY);
        leverPath.closeSubPath();

        juce::ColourGradient leverGrad(HardwareTheme::chromeHighlight, cx - baseWidth, cy,
                                       HardwareTheme::chromeDark, cx + tipWidth, cy, false);
        leverGrad.addColour(0.3, HardwareTheme::chromeMid);
        leverGrad.addColour(0.65, HardwareTheme::chromeDeep);
        g.setGradientFill(leverGrad);
        g.fillPath(leverPath);

        // Bat Spherical Tip
        const float tipRadius = tipWidth * 0.62f;
        juce::ColourGradient tipGrad(HardwareTheme::chromeHighlight, tipX - tipRadius * 0.4f, tipY - tipRadius * 0.4f,
                                     HardwareTheme::chromeDark, tipX + tipRadius * 0.6f, tipY + tipRadius * 0.6f, true);
        tipGrad.addColour(0.5, HardwareTheme::chromeMid);
        tipGrad.addColour(0.85, HardwareTheme::chromeDeep);
        g.setGradientFill(tipGrad);
        g.fillEllipse(tipX - tipRadius, tipY - tipRadius, tipRadius * 2.0f, tipRadius * 2.0f);

        // Specular glint on bat tip
        g.setColour(juce::Colours::white.withAlpha(0.85f));
        g.fillEllipse(tipX - tipRadius * 0.45f, tipY - tipRadius * 0.45f, tipRadius * 0.45f, tipRadius * 0.28f);

        // 3. Silkscreen Labels (Above and Below)
        g.setFont(juce::FontOptions(10.0f).withStyle("Bold"));

        // Top Label
        g.setColour(isUp ? HardwareTheme::champagneHighlight : HardwareTheme::silkscreenText.withAlpha(0.65f));
        g.drawText(topLabel, 0, 0, static_cast<int>(w), 14, juce::Justification::centred);

        // Bottom Label
        g.setColour(!isUp ? HardwareTheme::champagneHighlight : HardwareTheme::silkscreenText.withAlpha(0.65f));
        g.drawText(bottomLabel, 0, static_cast<int>(h - 14), static_cast<int>(w), 14, juce::Justification::centred);
    }

private:
    juce::String topLabel;
    juce::String bottomLabel;
    juce::Image batonUpImg;
    juce::Image batonDownImg;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalCraftToggleSwitch)
};

} // namespace dsp171
