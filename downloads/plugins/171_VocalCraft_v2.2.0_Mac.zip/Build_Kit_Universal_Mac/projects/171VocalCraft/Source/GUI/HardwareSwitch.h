#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <dsp171/BoutiqueStepperButton.h>

namespace gui171 {

class HardwareSwitch : public juce::Component, public juce::SettableTooltipClient {
public:
    void setTooltip(const juce::String& t) override { juce::SettableTooltipClient::setTooltip(t); button.setTooltip(t); }
    enum class SwitchStyle {
        PushBypass,   // Bottone push metallico con anello/lampada LED
        MetalToggle,  // Levetta metallica a 2 posizioni (Up/Down)
        SidechainBtn  // Bottone quadrato/tondo hardware
    };

    HardwareSwitch(const juce::String& label, juce::Colour ledColor,
                   juce::Image switchImage, SwitchStyle style = SwitchStyle::MetalToggle)
        : switchText(label), activeLedColor(ledColor),
          swImg(switchImage), currentStyle(style)
    {
        setOpaque(false);

        button.setClickingTogglesState(true);
        button.setAlpha(0.0f);
        button.onClick = [this]() {
            repaint();
        };

        addAndMakeVisible(button);
    }

    void resized() override {
        button.setBounds(getLocalBounds());
    }

    void paint(juce::Graphics& g) override {
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());
        const bool isOn = button.getToggleState();

        const float imgAreaH = h - 18.0f;

        // 1. Disegna l'immagine dell'interruttore hardware
        if (swImg.isValid()) {
            float scale = std::min(w / static_cast<float>(swImg.getWidth()),
                                   imgAreaH / static_cast<float>(swImg.getHeight())) * 0.76f;
            float dw = static_cast<float>(swImg.getWidth()) * scale;
            float dh = static_cast<float>(swImg.getHeight()) * scale;
            float dx = (w - dw) * 0.5f;
            float dy = (imgAreaH - dh) * 0.5f - 2.0f;

            if (currentStyle == SwitchStyle::MetalToggle && !isOn) {
                auto xform = juce::AffineTransform::scale(1.0f, -0.90f)
                                .translated(0.0f, dh * 0.90f)
                                .scaled(scale)
                                .translated(dx, dy);
                g.drawImageTransformed(swImg, xform);
            } else {
                g.drawImage(swImg, juce::roundToInt(dx), juce::roundToInt(dy),
                            juce::roundToInt(dw), juce::roundToInt(dh),
                            0, 0, swImg.getWidth(), swImg.getHeight());
            }
        } else {
            float cx = w * 0.5f;
            float cy = imgAreaH * 0.5f - 2.0f;
            g.setColour(juce::Colour(0xff16181c));
            g.fillRoundedRectangle(cx - 12.0f, cy - 15.0f, 24.0f, 30.0f, 4.0f);
            g.setColour(juce::Colour(0xff554838));
            g.drawRoundedRectangle(cx - 12.0f, cy - 15.0f, 24.0f, 30.0f, 4.0f, 1.2f);

            float tipY = isOn ? cy - 8.0f : cy + 8.0f;
            g.setColour(juce::Colour(0xffdcdfe5));
            g.fillEllipse(cx - 5.0f, tipY - 5.0f, 10.0f, 10.0f);
        }

        // 2. LED di Stato luminoso
        const float ledX = w * 0.5f;
        const float ledY = imgAreaH - 3.0f;
        if (isOn) {
            g.setColour(activeLedColor.withAlpha(0.40f));
            g.fillEllipse(ledX - 6.0f, ledY - 6.0f, 12.0f, 12.0f);
            g.setColour(activeLedColor);
            g.fillEllipse(ledX - 3.0f, ledY - 3.0f, 6.0f, 6.0f);
            g.setColour(juce::Colours::white.withAlpha(0.90f));
            g.fillEllipse(ledX - 1.2f, ledY - 1.2f, 2.4f, 2.4f);
        } else {
            g.setColour(juce::Colour(0xff121418));
            g.fillEllipse(ledX - 3.0f, ledY - 3.0f, 6.0f, 6.0f);
            g.setColour(juce::Colour(0x50000000));
            g.drawEllipse(ledX - 3.0f, ledY - 3.0f, 6.0f, 6.0f, 0.8f);
        }

        // 3. Etichetta inferiore
        g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        juce::Colour txtCol = isOn ? activeLedColor.brighter(0.2f) : juce::Colour(0xffb59a78);

        g.setColour(txtCol);
        g.drawText(switchText, 0, static_cast<int>(h - 15), static_cast<int>(w), 15, juce::Justification::centred, false);
    }

    juce::Button& getButton() noexcept { return button; }

private:
    juce::String switchText;
    juce::Colour activeLedColor;
    juce::Image swImg;
    SwitchStyle currentStyle;
    juce::ToggleButton button;
};

// ==============================================================================
// Heavy-Duty Studio Bypass Module (Placca in metallo, 4 viti Allen e spia rubino)
// ==============================================================================
class HeavyDutyBypassModule : public juce::Component, public juce::SettableTooltipClient {
public:
    void setTooltip(const juce::String& t) override { juce::SettableTooltipClient::setTooltip(t); button.setTooltip(t); }
    HeavyDutyBypassModule(juce::Image activeImg, juce::Image engagedImg)
        : imgActive(activeImg), imgEngaged(engagedImg)
    {
        setOpaque(false);
        button.setClickingTogglesState(true);
        button.setAlpha(0.0f);
        button.setMouseCursor(juce::MouseCursor::PointingHandCursor);
        button.setTooltip("Master DSP Bypass (15ms Pop-Free Crossfade)");
        button.onClick = [this]() { repaint(); };
        addAndMakeVisible(button);
    }

    void resized() override {
        button.setBounds(getLocalBounds());
    }

    void paint(juce::Graphics& g) override {
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());
        const bool isBypassed = button.getToggleState();

        const auto& curImg = isBypassed ? imgEngaged : imgActive;
        if (curImg.isValid()) {
            const float margin = 3.0f;
            const float size = std::min(w, h) - margin * 2.0f;
            const float dx = (w - size) * 0.5f;
            const float dy = (h - size) * 0.5f;

            // Ombra cadente incassata nel pannello
            g.setColour(juce::Colour(0x90000000));
            g.fillRoundedRectangle(dx + 2.0f, dy + 2.0f, size - 4.0f, size - 4.0f, 6.0f);

            // Bordo metallico dorato incassato nel rack
            g.setColour(juce::Colour(0x40c59c52));
            g.drawRoundedRectangle(dx, dy, size, size, 5.0f, 1.0f);

            // Alone additivo rosso rubino se il Bypass e' attivo
            if (isBypassed) {
                g.setColour(juce::Colour(0x35ff2030));
                g.fillRoundedRectangle(dx - 3.0f, dy - 3.0f, size + 6.0f, size + 6.0f, 8.0f);
            }

            g.drawImage(curImg,
                        juce::roundToInt(dx), juce::roundToInt(dy),
                        juce::roundToInt(size), juce::roundToInt(size),
                        0, 0, curImg.getWidth(), curImg.getHeight());
        }
    }

    juce::Button& getButton() noexcept { return button; }

private:
    juce::ToggleButton button;
    juce::Image imgActive;
    juce::Image imgEngaged;
};

// ==============================================================================
// Square Console Button (Pulsanti Quadrati Master con feedback Ambra)
// ==============================================================================
class SquareConsoleButton : public juce::Component, public juce::SettableTooltipClient {
public:
    void setTooltip(const juce::String& t) override { juce::SettableTooltipClient::setTooltip(t); button.setTooltip(t); }
    SquareConsoleButton(const juce::String& title,
                        const juce::String& offLabel,
                        const juce::String& onLabel,
                        juce::Image onImg,
                        juce::Image offImg)
        : switchTitle(title),
          offText(offLabel),
          onText(onLabel),
          imgLitOn(onImg),
          imgDarkOff(offImg)
    {
        setOpaque(false);
        button.setClickingTogglesState(true);
        button.setAlpha(0.0f);
        button.onClick = [this]() { repaint(); };
        button.onStateChange = [this]() { repaint(); };
        addAndMakeVisible(button);
    }

    void resized() override {
        button.setBounds(getLocalBounds());
    }

    void paint(juce::Graphics& g) override {
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());
        const bool isOn = button.getToggleState();
        const auto& curImg = isOn ? imgLitOn : imgDarkOff;

        if (w > h * 1.35f && h <= 42.0f) {
            // Modalità Orizzontale Compatta (Side-by-side per barre header di canale)
            // 100% Solido per coprire serigrafie e bordi dello chassis
            g.setColour(juce::Colour(0xff0d1017));
            g.fillRoundedRectangle(0.0f, 0.0f, w, h, 4.0f);
            g.setColour(juce::Colour(0x50c5a059));
            g.drawRoundedRectangle(0.5f, 0.5f, w - 1.0f, h - 1.0f, 4.0f, 1.0f);

            const float btnSize = juce::jmin(h - 4.0f, 24.0f);
            const float bx = 3.0f;
            const float by = (h - btnSize) * 0.5f;

            if (curImg.isValid()) {
                g.setColour(juce::Colour(0x75000000));
                g.fillRoundedRectangle(bx + 1.5f, by + 1.5f, btnSize, btnSize, 3.5f);

                g.drawImage(curImg,
                            juce::roundToInt(bx), juce::roundToInt(by),
                            juce::roundToInt(btnSize), juce::roundToInt(btnSize),
                            0, 0, curImg.getWidth(), curImg.getHeight());
            }

            const float textX = bx + btnSize + 5.0f;
            const float textW = w - textX - 2.0f;

            // Titolo
            g.setFont(juce::FontOptions(9.5f, juce::Font::bold));
            g.setColour(juce::Colour(0x90000000));
            g.drawText(switchTitle, juce::roundToInt(textX), 1, juce::roundToInt(textW), 14, juce::Justification::centredLeft, false);
            g.setColour(juce::Colour(0xffe6d2b5));
            g.drawText(switchTitle, juce::roundToInt(textX), 0, juce::roundToInt(textW), 14, juce::Justification::centredLeft, false);

            // Stato ON/OFF
            g.setFont(juce::FontOptions(9.0f, juce::Font::bold));
            const juce::String currentText = isOn ? onText : offText;
            juce::Colour textCol = isOn ? juce::Colour(0xffffbf40) : juce::Colour(0x809c8e7e);
            g.setColour(textCol);
            g.drawText(currentText, juce::roundToInt(textX), 13, juce::roundToInt(textW), 13, juce::Justification::centredLeft, false);
        } else {
            // Modalità Verticale Standard
            g.setFont(juce::FontOptions(10.5f, juce::Font::bold));
            g.setColour(juce::Colour(0x90000000));
            g.drawText(switchTitle, 0, 2, static_cast<int>(w), 16, juce::Justification::centred, false);
            g.setColour(juce::Colour(0xffe6d2b5));
            g.drawText(switchTitle, 0, 1, static_cast<int>(w), 16, juce::Justification::centred, false);

            if (curImg.isValid()) {
                const float btnSize = juce::jmin(w - 6.0f, h - 30.0f);
                const float bx = (w - btnSize) * 0.5f;
                const float by = 16.0f;

                g.setColour(juce::Colour(0x75000000));
                g.fillRoundedRectangle(bx + 1.5f, by + 2.0f, btnSize, btnSize, 4.0f);

                g.drawImage(curImg,
                            juce::roundToInt(bx), juce::roundToInt(by),
                            juce::roundToInt(btnSize), juce::roundToInt(btnSize),
                            0, 0, curImg.getWidth(), curImg.getHeight());
            }

            g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
            const int labelY = static_cast<int>(h - 14.0f);
            const juce::String currentText = isOn ? onText : offText;
            juce::Colour textCol = isOn ? juce::Colour(0xffffbf40) : juce::Colour(0x809c8e7e);
            g.setColour(textCol);
            g.drawText(currentText, 0, labelY, static_cast<int>(w), 14, juce::Justification::centred, false);
        }
    }

    juce::ToggleButton& getButton() noexcept { return button; }

private:
    juce::ToggleButton button;
    juce::String switchTitle;
    juce::String offText;
    juce::String onText;
    juce::Image imgLitOn;
    juce::Image imgDarkOff;
};

// ==============================================================================
// Vintage Mechanical Push Button Bank (UAD 1176 Style Interlocking Radio Buttons)
// ==============================================================================
class VintageMechanicalPushBank : public juce::Component, public juce::SettableTooltipClient {
public:
    explicit VintageMechanicalPushBank(const juce::StringArray& buttonLabels)
        : labels(buttonLabels)
    {
        setOpaque(false);
    }

    void setSelectedRatio(int index, juce::NotificationType notify = juce::sendNotification) {
        if (index >= 0 && index < labels.size()) {
            selectedIndex = index;
            repaint();
            if (notify != juce::dontSendNotification && onSelectionChanged) {
                onSelectionChanged(selectedIndex);
            }
        }
    }

    int getSelectedRatio() const noexcept { return selectedIndex; }

    void setOnSelectionChanged(std::function<void(int)> cb) {
        onSelectionChanged = std::move(cb);
    }

    void mouseDown(const juce::MouseEvent& e) override {
        const float w = static_cast<float>(getWidth());
        const int numBtns = labels.size();
        if (numBtns <= 0) return;

        const float btnW = w / static_cast<float>(numBtns);
        int clicked = std::clamp(static_cast<int>(e.position.x / btnW), 0, numBtns - 1);
        setSelectedRatio(clicked, juce::sendNotification);
    }

    void paint(juce::Graphics& g) override {
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());
        const int numBtns = labels.size();
        if (numBtns <= 0) return;

        // 1. Telaio incassato lavorato CNC con bevel profondo (Ambient Occlusion a 105°)
        auto bezelBounds = juce::Rectangle<float>(0.0f, 0.0f, w, h);
        g.setColour(juce::Colour(0xff0b0d11));
        g.fillRoundedRectangle(bezelBounds, 4.0f);
        g.setColour(juce::Colour(0x60000000));
        g.drawRoundedRectangle(bezelBounds.reduced(0.5f), 4.0f, 1.2f);
        g.setColour(juce::Colour(0x35c5a059));
        g.drawRoundedRectangle(bezelBounds, 4.0f, 1.0f);

        const float pad = 3.0f;
        const float totalInnerW = w - pad * 2.0f;
        const float spacing = 2.0f;
        const float btnW = (totalInnerW - static_cast<float>(numBtns - 1) * spacing) / static_cast<float>(numBtns);
        const float btnH = h - pad * 2.0f;

        const bool isAllSelected = (selectedIndex == 4); // ALL-IN British Mode

        for (int i = 0; i < numBtns; ++i) {
            const float bx = pad + static_cast<float>(i) * (btnW + spacing);
            const float by = pad;
            auto btnRect = juce::Rectangle<float>(bx, by, btnW, btnH);

            const bool isPressed = (i == selectedIndex) || (isAllSelected && i < 4);

            if (isPressed) {
                // Tasto premuto (incassato con ombra superiore e glow dorato)
                auto pressedRect = btnRect.translated(0.0f, 1.0f).reduced(0.5f, 0.5f);
                g.setColour(juce::Colour(0x95000000));
                g.fillRoundedRectangle(btnRect, 2.5f);

                juce::ColourGradient gradP(juce::Colour(0xff181a20), pressedRect.getX(), pressedRect.getY(),
                                           juce::Colour(0xff2a2e38), pressedRect.getX(), pressedRect.getBottom(), false);
                g.setGradientFill(gradP);
                g.fillRoundedRectangle(pressedRect, 2.5f);

                // Lampada retroilluminata ambra/oro
                g.setColour(juce::Colour(0xffffbf40));
                g.drawRoundedRectangle(pressedRect, 2.5f, 1.2f);

                g.setFont(juce::FontOptions(10.5f, juce::Font::bold));
                g.setColour(juce::Colour(0xffffe082));
                g.drawText(labels[i], pressedRect.toNearestInt(), juce::Justification::centred, false);
            } else {
                // Tasto sporgente (finitura alluminio spazzolato con smusso luce superiore 1px)
                g.setColour(juce::Colour(0x80000000));
                g.fillRoundedRectangle(btnRect.translated(0.0f, 1.5f), 2.5f);

                juce::ColourGradient gradU(juce::Colour(0xff4a5160), btnRect.getX(), btnRect.getY(),
                                           juce::Colour(0xff222731), btnRect.getX(), btnRect.getBottom(), false);
                g.setGradientFill(gradU);
                g.fillRoundedRectangle(btnRect, 2.5f);

                // Bordo luce superiore
                g.setColour(juce::Colour(0x55ffffff));
                g.drawHorizontalLine(juce::roundToInt(btnRect.getY() + 1.0f), btnRect.getX() + 1.0f, btnRect.getRight() - 1.0f);

                g.setColour(juce::Colour(0x40000000));
                g.drawRoundedRectangle(btnRect, 2.5f, 0.8f);

                g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
                g.setColour(juce::Colour(0xffd1d5db));
                g.drawText(labels[i], btnRect.toNearestInt(), juce::Justification::centred, false);
            }
        }
    }

private:
    juce::StringArray labels;
    int selectedIndex = 0;
    std::function<void(int)> onSelectionChanged;
};

// ==============================================================================
// Vintage Console Push Selector (NLS 3 Consoles: Snow, SpikeProtein, Maik)
// ==============================================================================
class VintageConsolePushBank : public juce::Component, public juce::SettableTooltipClient {
public:
    VintageConsolePushBank()
        : labels({ "Snow", "SpikeProtein", "Maik" })
    {
        setOpaque(false);
    }

    void setSelectedConsole(int index, juce::NotificationType notify = juce::sendNotification) {
        if (index >= 0 && index < labels.size()) {
            selectedIndex = index;
            repaint();
            if (notify != juce::dontSendNotification && onSelectionChanged) {
                onSelectionChanged(selectedIndex);
            }
        }
    }

    int getSelectedConsole() const noexcept { return selectedIndex; }

    void setOnSelectionChanged(std::function<void(int)> cb) {
        onSelectionChanged = std::move(cb);
    }

    void mouseDown(const juce::MouseEvent& e) override {
        const float w = static_cast<float>(getWidth());
        const int numBtns = labels.size();
        const float btnW = w / static_cast<float>(numBtns);
        int clicked = std::clamp(static_cast<int>(e.position.x / btnW), 0, numBtns - 1);
        setSelectedConsole(clicked, juce::sendNotification);
    }

    void paint(juce::Graphics& g) override {
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());
        const int numBtns = labels.size();

        auto bezelBounds = juce::Rectangle<float>(0.0f, 0.0f, w, h);
        g.setColour(juce::Colour(0xff0e1014));
        g.fillRoundedRectangle(bezelBounds, 4.0f);
        g.setColour(juce::Colour(0x35c5a059));
        g.drawRoundedRectangle(bezelBounds, 4.0f, 1.0f);

        const float pad = 2.0f;
        const float spacing = 2.0f;
        const float btnW = (w - pad * 2.0f - static_cast<float>(numBtns - 1) * spacing) / static_cast<float>(numBtns);
        const float btnH = h - pad * 2.0f;

        for (int i = 0; i < numBtns; ++i) {
            const float bx = pad + static_cast<float>(i) * (btnW + spacing);
            auto btnRect = juce::Rectangle<float>(bx, pad, btnW, btnH);
            const bool isSelected = (i == selectedIndex);

            if (isSelected) {
                juce::Colour activeCol = (i == 0) ? juce::Colour(0xffff2030) : // Nevo: Red Neve
                                         (i == 1) ? juce::Colour(0xff3b82f6) : // Spike: Blue SSL
                                                    juce::Colour(0xfffbbf24);  // Mike: Amber EMI

                juce::ColourGradient gradP(juce::Colour(0xff181b22), btnRect.getX(), btnRect.getY(),
                                           juce::Colour(0xff2b303c), btnRect.getX(), btnRect.getBottom(), false);
                g.setGradientFill(gradP);
                g.fillRoundedRectangle(btnRect, 2.5f);

                g.setColour(activeCol);
                g.drawRoundedRectangle(btnRect, 2.5f, 1.2f);

                // LED Pip
                g.setColour(activeCol);
                g.fillEllipse(btnRect.getRight() - 7.0f, btnRect.getCentreY() - 2.0f, 4.0f, 4.0f);

                g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
                g.setColour(juce::Colours::white);
                g.drawText(labels[i], btnRect.toNearestInt().withTrimmedRight(6), juce::Justification::centred, false);
            } else {
                juce::ColourGradient gradU(juce::Colour(0xff373c47), btnRect.getX(), btnRect.getY(),
                                           juce::Colour(0xff1e2128), btnRect.getX(), btnRect.getBottom(), false);
                g.setGradientFill(gradU);
                g.fillRoundedRectangle(btnRect, 2.5f);
                g.setColour(juce::Colour(0x30ffffff));
                g.drawRoundedRectangle(btnRect, 2.5f, 0.8f);

                g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
                g.setColour(juce::Colour(0xff9ca3af));
                g.drawText(labels[i], btnRect.toNearestInt(), juce::Justification::centred, false);
            }
        }
    }

private:
    juce::StringArray labels;
    int selectedIndex = 0;
    std::function<void(int)> onSelectionChanged;
};

} // namespace gui171
