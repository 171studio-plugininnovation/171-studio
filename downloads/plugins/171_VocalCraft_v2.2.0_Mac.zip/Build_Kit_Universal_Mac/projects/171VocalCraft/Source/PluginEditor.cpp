#include "PluginEditor.h"

// ==============================================================================
// 171 VOCALCRAFT - CURVES EQUATOR BOUTIQUE EDITION (JUCE 8 / 60 FPS)
// ==============================================================================
VocalCraftAudioProcessorEditor::VocalCraftAudioProcessorEditor(VocalCraftAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    setSize(1080, 640);

    setLookAndFeel(&curvesLookAndFeel);

    // --------------------------------------------------------------------------
    // 1. HEADER & PRESET MANAGER
    // --------------------------------------------------------------------------
    presetTitleLabel.setText("FACTORY PRESET BANK", juce::dontSendNotification);
    presetTitleLabel.setFont(juce::FontOptions(8.5f, juce::Font::bold));
    presetTitleLabel.setColour(juce::Label::textColourId, gui171::CurvesTheme::goldLaserHairline);
    presetTitleLabel.setJustificationType(juce::Justification::centred);
    addAndMakeVisible(presetTitleLabel);

    presetBox.addItem("01. Studio Modern Pop Lead", 1);
    presetBox.addItem("02. Aggressive Trap / Drill", 2);
    presetBox.addItem("03. Warm R&B Vocal Velvet", 3);
    presetBox.addItem("04. Crisp Hip-Hop Articulation", 4);
    presetBox.addItem("05. Female Acoustic Intimacy", 5);
    presetBox.addItem("06. Harsh Sibilance & Boxiness Tamer", 6);
    presetBox.setSelectedId(1, juce::dontSendNotification);
    presetBox.addListener(this);
    addAndMakeVisible(presetBox);

    prevPresetBtn.onClick = [this] {
        int cur = presetBox.getSelectedId();
        if (cur > 1) presetBox.setSelectedId(cur - 1, juce::sendNotificationSync);
        else presetBox.setSelectedId(presetBox.getNumItems(), juce::sendNotificationSync);
    };
    addAndMakeVisible(prevPresetBtn);

    nextPresetBtn.onClick = [this] {
        int cur = presetBox.getSelectedId();
        if (cur < presetBox.getNumItems()) presetBox.setSelectedId(cur + 1, juce::sendNotificationSync);
        else presetBox.setSelectedId(1, juce::sendNotificationSync);
    };
    addAndMakeVisible(nextPresetBtn);

    addAndMakeVisible(bypassToggle);

    // --------------------------------------------------------------------------
    // 2. HERO SPECTRAL VISUALIZER (CURVES EQUATOR CANVAS & SCREEN TOOLBAR)
    // --------------------------------------------------------------------------
    equatorVisualizer.onDeltaToggled = [this](bool active) {
        processor.setDeltaMode(active);
    };
    equatorVisualizer.onTargetProfileChanged = [this](int prof) {
        processor.setTargetProfile(prof);
    };
    addAndMakeVisible(equatorVisualizer);

    // --------------------------------------------------------------------------
    // 3. CENTERPIECE: GIANT DOMINANT SUPPRESSION DIAL
    // --------------------------------------------------------------------------
    addAndMakeVisible(centralSuppressionDial);

    centralDialLabel.setText("MASTER EQUATOR DEPTH", juce::dontSendNotification);
    centralDialLabel.setFont(juce::FontOptions(11.5f, juce::Font::bold));
    centralDialLabel.setColour(juce::Label::textColourId, gui171::CurvesTheme::goldPrimary);
    centralDialLabel.setJustificationType(juce::Justification::centred);
    addAndMakeVisible(centralDialLabel);

    centralDialSubLabel.setText("DYNAMIC 64-BAND THRESHOLD", juce::dontSendNotification);
    centralDialSubLabel.setFont(juce::FontOptions(8.5f, juce::Font::bold));
    centralDialSubLabel.setColour(juce::Label::textColourId, gui171::CurvesTheme::textMuted);
    centralDialSubLabel.setJustificationType(juce::Justification::centred);
    addAndMakeVisible(centralDialSubLabel);

    // --------------------------------------------------------------------------
    // 4. LEFT SATELLITES: DETECTION, NEUTRALITY & LEARN
    // --------------------------------------------------------------------------
    learnButton.onClick = [this] {
        processor.triggerCalibration();
    };
    addAndMakeVisible(learnButton);

    setupKnobWithSub(linearizerKnob, linearizerLabel, "LINEARIZER", linearizerSubLabel, "64-BAND FLAT",
                     gui171::CurvesLookAndFeel::KnobColorTheme::CyanEquator, "%");
    setupKnobWithSub(manualTrimKnob, manualTrimLabel, "INPUT TRIM", manualTrimSubLabel, "PRE-GAIN STAGE",
                     gui171::CurvesLookAndFeel::KnobColorTheme::TitaniumMaster, "dB");

    setupKnobWithSub(consonantKnob, consonantLabel, "CONSONANT", consonantSubLabel, "PHONEME ATTACK",
                     gui171::CurvesLookAndFeel::KnobColorTheme::GoldPunch, "dB");
    setupKnobWithSub(unmaskKnob, unmaskLabel, "SC UNMASK", unmaskSubLabel, "BEAT CARVE RIDER",
                     gui171::CurvesLookAndFeel::KnobColorTheme::VioletSidechain, "%");

    styleBox.addItem("Hip-Hop / Rap", 1);
    styleBox.addItem("Modern Pop", 2);
    styleBox.addItem("Trap / Drill", 3);
    styleBox.addItem("R&B / Soul", 4);
    styleBox.setSelectedId(1, juce::dontSendNotification);
    addAndMakeVisible(styleBox);

    styleLabel.setText("VOCAL PROFILE", juce::dontSendNotification);
    styleLabel.setFont(juce::FontOptions(9.5f, juce::Font::bold));
    styleLabel.setColour(juce::Label::textColourId, gui171::CurvesTheme::goldLaserHairline);
    styleLabel.setJustificationType(juce::Justification::centred);
    addAndMakeVisible(styleLabel);

    // --------------------------------------------------------------------------
    // 5. RIGHT SATELLITES: POLISH, DE-ESSER & MASTERING
    // --------------------------------------------------------------------------
    setupKnobWithSub(deessKnob, deessLabel, "DE-ESSER", deessSubLabel, "HARSH SIBILANCE",
                     gui171::CurvesLookAndFeel::KnobColorTheme::AmberDeess, "%");
    setupKnobWithSub(airSheenKnob, airSheenLabel, "AIR SHEEN", airSheenSubLabel, "12 kHz SILKY LIFT",
                     gui171::CurvesLookAndFeel::KnobColorTheme::CyanEquator, "%");
    setupKnobWithSub(clipperKnob, clipperLabel, "CLIPPER", clipperSubLabel, "ADAA-2 SOFT PEAK",
                     gui171::CurvesLookAndFeel::KnobColorTheme::TitaniumMaster, "%");

    addAndMakeVisible(autoMakeupToggle);
    addAndMakeVisible(outputBargraph);

    // --------------------------------------------------------------------------
    // 6. COLLEGAMENTO APVTS ATTACHMENTS
    // --------------------------------------------------------------------------
    auto& apvts = processor.getAPVTS();

    compAmountAttach      = std::make_unique<SliderAttachment>(apvts, "comp_amount", centralSuppressionDial);
    linearizerDepthAttach = std::make_unique<SliderAttachment>(apvts, "linearizer_depth", linearizerKnob);
    consonantPunchAttach  = std::make_unique<SliderAttachment>(apvts, "consonant_punch", consonantKnob);
    airSheenAttach        = std::make_unique<SliderAttachment>(apvts, "air_sheen", airSheenKnob);
    deessAttach           = std::make_unique<SliderAttachment>(apvts, "deess_amount", deessKnob);
    unmaskAttach          = std::make_unique<SliderAttachment>(apvts, "unmask_amount", unmaskKnob);
    clipperAttach         = std::make_unique<SliderAttachment>(apvts, "clipper_drive", clipperKnob);
    manualTrimAttach      = std::make_unique<SliderAttachment>(apvts, "manual_trim", manualTrimKnob);

    styleAttach           = std::make_unique<ComboBoxAttachment>(apvts, "style", styleBox);
    autoMakeupAttach      = std::make_unique<ButtonAttachment>(apvts, "auto_makeup", autoMakeupToggle);
    bypassAttach          = std::make_unique<ButtonAttachment>(apvts, "bypass", bypassToggle);

    // --------------------------------------------------------------------------
    // 7. TOOLTIPS ESPLICATIVI GUIDA BOUTIQUE
    // --------------------------------------------------------------------------
    centralSuppressionDial.setTooltip("MASTER EQUATOR DEPTH (0% - 100%)\nRegola la profondita dinamica del processore di risonanze vocali multidimensionale.");
    linearizerKnob.setTooltip("LINEARIZER NEUTRALITY (0% - 100%)\nNeutralizza le formanti aspre e le colorazioni sgradevoli della capsula microfonica.");
    consonantKnob.setTooltip("CONSONANT PUNCH (-6 dB a +6 dB)\nModella l'attacco e la definizione delle consonanti per massima intellegibilita vocale.");
    unmaskKnob.setTooltip("BEAT UNMASK & POCKET (0% - 100%)\nCrea spazio spettrale istantaneo nella base musicale per incastonare la voce nel mix.");
    airSheenKnob.setTooltip("AIR SHEEN (0% - 100%)\nInietta una setosa lucentezza aerea ad altissima risoluzione oltre i 12 kHz a fase lineare.");
    deessKnob.setTooltip("PRE-DRIVE DE-ESSER (0% - 100%)\nAttenua selettivamente le sibilanti e le asprezze dell'alta frequenza prima degli stadi non-lineari.");
    clipperKnob.setTooltip("VOCAL CLIPPER (0% - 100%)\nClipper analogico ADAA-2 per domare i picchi transitori veloci senza distorsione udibile.");
    manualTrimKnob.setTooltip("INPUT TRIM (-24 dB a +24 dB)\nRegola con precisione il livello di guadagno in ingresso per ottimizzare il gain staging.");
    styleBox.setTooltip("VOCAL STYLE PROFILE\nSeleziona il profilo di modellazione spettrale calibrato (Hip-Hop, Pop, Trap, R&B).");
    autoMakeupToggle.setTooltip("AUTO MAKEUP\nCompensazione automatica intelligente del guadagno percepito RMS.");
    bypassToggle.setTooltip("TRUE HARDWARE BYPASS\nBypass pop-free a fase coerente con crossfade istantaneo.");

    startTimerHz(60);
}

VocalCraftAudioProcessorEditor::~VocalCraftAudioProcessorEditor() {
    stopTimer();
    setLookAndFeel(nullptr);
}

void VocalCraftAudioProcessorEditor::setupKnobWithSub(juce::Slider& slider,
                                                     juce::Label& title, const juce::String& titleText,
                                                     juce::Label& sub, const juce::String& subText,
                                                     gui171::CurvesLookAndFeel::KnobColorTheme theme,
                                                     const juce::String& suffix)
{
    slider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 56, 16);
    slider.setTextValueSuffix(" " + suffix);
    slider.getProperties().set("Theme", static_cast<int>(theme));
    addAndMakeVisible(slider);

    title.setText(titleText, juce::dontSendNotification);
    title.setFont(juce::FontOptions(10.0f, juce::Font::bold));
    title.setColour(juce::Label::textColourId, gui171::CurvesTheme::goldPrimary);
    title.setJustificationType(juce::Justification::centred);
    addAndMakeVisible(title);

    sub.setText(subText, juce::dontSendNotification);
    sub.setFont(juce::FontOptions(8.0f, juce::Font::bold));
    sub.setColour(juce::Label::textColourId, gui171::CurvesTheme::textMuted);
    sub.setJustificationType(juce::Justification::centred);
    addAndMakeVisible(sub);
}

void VocalCraftAudioProcessorEditor::comboBoxChanged(juce::ComboBox* box) {
    if (box == &presetBox) {
        int id = presetBox.getSelectedId();
        switch (id) {
            case 1: // Studio Modern Pop Lead
                if (auto* p = processor.getAPVTS().getParameter("comp_amount")) p->setValueNotifyingHost(0.55f);
                if (auto* p = processor.getAPVTS().getParameter("linearizer_depth")) p->setValueNotifyingHost(0.85f);
                if (auto* p = processor.getAPVTS().getParameter("consonant_punch")) p->setValueNotifyingHost(0.58f);
                if (auto* p = processor.getAPVTS().getParameter("air_sheen")) p->setValueNotifyingHost(0.65f);
                if (auto* p = processor.getAPVTS().getParameter("deess_amount")) p->setValueNotifyingHost(0.52f);
                if (auto* p = processor.getAPVTS().getParameter("clipper_drive")) p->setValueNotifyingHost(0.40f);
                break;
            case 2: // Aggressive Trap / Drill
                if (auto* p = processor.getAPVTS().getParameter("comp_amount")) p->setValueNotifyingHost(0.72f);
                if (auto* p = processor.getAPVTS().getParameter("linearizer_depth")) p->setValueNotifyingHost(0.92f);
                if (auto* p = processor.getAPVTS().getParameter("consonant_punch")) p->setValueNotifyingHost(0.75f);
                if (auto* p = processor.getAPVTS().getParameter("air_sheen")) p->setValueNotifyingHost(0.80f);
                if (auto* p = processor.getAPVTS().getParameter("deess_amount")) p->setValueNotifyingHost(0.68f);
                if (auto* p = processor.getAPVTS().getParameter("clipper_drive")) p->setValueNotifyingHost(0.60f);
                break;
            case 3: // Warm R&B Vocal Velvet
                if (auto* p = processor.getAPVTS().getParameter("comp_amount")) p->setValueNotifyingHost(0.42f);
                if (auto* p = processor.getAPVTS().getParameter("linearizer_depth")) p->setValueNotifyingHost(0.75f);
                if (auto* p = processor.getAPVTS().getParameter("consonant_punch")) p->setValueNotifyingHost(0.50f);
                if (auto* p = processor.getAPVTS().getParameter("air_sheen")) p->setValueNotifyingHost(0.45f);
                if (auto* p = processor.getAPVTS().getParameter("deess_amount")) p->setValueNotifyingHost(0.48f);
                if (auto* p = processor.getAPVTS().getParameter("clipper_drive")) p->setValueNotifyingHost(0.25f);
                break;
            case 4: // Crisp Hip-Hop Articulation
                if (auto* p = processor.getAPVTS().getParameter("comp_amount")) p->setValueNotifyingHost(0.60f);
                if (auto* p = processor.getAPVTS().getParameter("linearizer_depth")) p->setValueNotifyingHost(0.88f);
                if (auto* p = processor.getAPVTS().getParameter("consonant_punch")) p->setValueNotifyingHost(0.82f);
                if (auto* p = processor.getAPVTS().getParameter("air_sheen")) p->setValueNotifyingHost(0.55f);
                if (auto* p = processor.getAPVTS().getParameter("deess_amount")) p->setValueNotifyingHost(0.50f);
                if (auto* p = processor.getAPVTS().getParameter("clipper_drive")) p->setValueNotifyingHost(0.50f);
                break;
            case 5: // Female Acoustic Intimacy
                if (auto* p = processor.getAPVTS().getParameter("comp_amount")) p->setValueNotifyingHost(0.35f);
                if (auto* p = processor.getAPVTS().getParameter("linearizer_depth")) p->setValueNotifyingHost(0.70f);
                if (auto* p = processor.getAPVTS().getParameter("consonant_punch")) p->setValueNotifyingHost(0.52f);
                if (auto* p = processor.getAPVTS().getParameter("air_sheen")) p->setValueNotifyingHost(0.70f);
                if (auto* p = processor.getAPVTS().getParameter("deess_amount")) p->setValueNotifyingHost(0.62f);
                if (auto* p = processor.getAPVTS().getParameter("clipper_drive")) p->setValueNotifyingHost(0.15f);
                break;
            case 6: // Harsh Sibilance & Boxiness Tamer
                if (auto* p = processor.getAPVTS().getParameter("comp_amount")) p->setValueNotifyingHost(0.65f);
                if (auto* p = processor.getAPVTS().getParameter("linearizer_depth")) p->setValueNotifyingHost(0.95f);
                if (auto* p = processor.getAPVTS().getParameter("consonant_punch")) p->setValueNotifyingHost(0.48f);
                if (auto* p = processor.getAPVTS().getParameter("air_sheen")) p->setValueNotifyingHost(0.35f);
                if (auto* p = processor.getAPVTS().getParameter("deess_amount")) p->setValueNotifyingHost(0.85f);
                if (auto* p = processor.getAPVTS().getParameter("clipper_drive")) p->setValueNotifyingHost(0.30f);
                break;
        }
    }
}

void VocalCraftAudioProcessorEditor::paint(juce::Graphics& g) {
    auto bounds = getLocalBounds().toFloat();

    // 1. Telaio di fondo in carbonio ossidiana profondo
    juce::ColourGradient bgGrad(
        gui171::CurvesTheme::bgChassisInner, bounds.getX(), bounds.getY(),
        gui171::CurvesTheme::bgChassisOuter, bounds.getX(), bounds.getBottom(), false);
    g.setGradientFill(bgGrad);
    g.fillAll();

    // 2. Micro-trama serigrafica a linee orizzontali in metallo spazzolato
    g.setColour(juce::Colours::black.withAlpha(0.25f));
    for (float y = 0.0f; y < bounds.getHeight(); y += 2.0f) {
        g.drawHorizontalLine(juce::roundToInt(y), 0.0f, bounds.getWidth());
    }

    // 3. Cornice esterna cesellata in oro brunito 171 Studio Signature
    g.setColour(gui171::CurvesTheme::goldLaserHairline.withAlpha(0.45f));
    g.drawRect(bounds.reduced(0.5f), 1.0f);
    g.setColour(gui171::CurvesTheme::goldPrimary.withAlpha(0.15f));
    g.drawRect(bounds.reduced(2.5f), 1.0f);

    // 4. HEADER BAR (Y = 0 a 54)
    g.setColour(gui171::CurvesTheme::goldLaserHairline.withAlpha(0.35f));
    g.drawHorizontalLine(53, 0.0f, bounds.getWidth());

    // Logo 171 Studio Gold laser serigrafato
    g.setFont(juce::FontOptions(15.0f, juce::Font::bold));
    g.setColour(gui171::CurvesTheme::goldPrimary);
    g.drawText("171 VOCALCRAFT", juce::Rectangle<float>(20.0f, 10.0f, 190.0f, 18.0f), juce::Justification::left, false);

    g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
    g.setColour(gui171::CurvesTheme::textMuted);
    g.drawText("SPECTRAL EQUATOR & HARMONIC RESONANCE LINEARIZER", juce::Rectangle<float>(20.0f, 28.0f, 320.0f, 14.0f), juce::Justification::left, false);

    // Pillola badge "64-BAND LINEAR PHASE"
    auto badgeBounds = juce::Rectangle<float>(330.0f, 16.0f, 105.0f, 20.0f);
    g.setColour(juce::Colour(0xff121620));
    g.fillRoundedRectangle(badgeBounds, 3.0f);
    g.setColour(gui171::CurvesTheme::goldLaserHairline.withAlpha(0.4f));
    g.drawRoundedRectangle(badgeBounds, 3.0f, 1.0f);
    g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
    g.setColour(gui171::CurvesTheme::cyanElectric);
    g.drawText("64-BAND LINEAR", badgeBounds, juce::Justification::centred, false);

    // 5. LOWER DECK PANELS (Y = 386 a 630) - Targhette metalliche incise a laser
    auto drawBoutiqueBay = [&](const juce::Rectangle<float>& r, const char* plateTitle) {
        g.setColour(juce::Colour(0xff0b0d13));
        g.fillRoundedRectangle(r, 6.0f);
        g.setColour(gui171::CurvesTheme::panelBezelBorder.withAlpha(0.60f));
        g.drawRoundedRectangle(r, 6.0f, 1.2f);

        auto plateR = juce::Rectangle<float>(r.getX() + 8.0f, r.getY() + 4.0f, r.getWidth() - 16.0f, 16.0f);
        juce::ColourGradient plateGrad(
            juce::Colour(0xff1f2430), plateR.getX(), plateR.getY(),
            juce::Colour(0xff11141c), plateR.getX(), plateR.getBottom(), false);
        g.setGradientFill(plateGrad);
        g.fillRoundedRectangle(plateR, 3.0f);

        g.setColour(gui171::CurvesTheme::goldLaserHairline.withAlpha(0.35f));
        g.drawRoundedRectangle(plateR, 3.0f, 0.9f);

        g.setColour(gui171::CurvesTheme::goldPrimary.withAlpha(0.65f));
        g.fillEllipse(plateR.getX() + 4.0f, plateR.getCentreY() - 1.5f, 3.0f, 3.0f);
        g.fillEllipse(plateR.getRight() - 7.0f, plateR.getCentreY() - 1.5f, 3.0f, 3.0f);

        g.setFont(juce::FontOptions(9.0f, juce::Font::bold));
        g.setColour(gui171::CurvesTheme::goldPrimary);
        g.drawText(plateTitle, plateR, juce::Justification::centred, false);
    };

    drawBoutiqueBay(juce::Rectangle<float>(18.0f, 388.0f, 180.0f, 240.0f), "01 - DETECTION & STAGING");
    drawBoutiqueBay(juce::Rectangle<float>(206.0f, 388.0f, 226.0f, 240.0f), "02 - TRANSIENTS & PROFILE");
    drawBoutiqueBay(juce::Rectangle<float>(440.0f, 388.0f, 200.0f, 240.0f), "03 - MASTER EQUATOR DEPTH");
    drawBoutiqueBay(juce::Rectangle<float>(648.0f, 388.0f, 226.0f, 240.0f), "04 - SPECTRAL HARMONICS");
    drawBoutiqueBay(juce::Rectangle<float>(882.0f, 388.0f, 180.0f, 240.0f), "05 - MASTERING & CLIPPER");
}

void VocalCraftAudioProcessorEditor::resized() {
    // 1. Header
    presetTitleLabel.setBounds(474, 3, 160, 12);
    prevPresetBtn.setBounds(446, 17, 24, 24);
    presetBox.setBounds(474, 17, 160, 24);
    nextPresetBtn.setBounds(638, 17, 24, 24);
    bypassToggle.setBounds(946, 14, 114, 24);

    // 2. Hero Visualizer (Waves Curves Equator Canvas)
    equatorVisualizer.setBounds(18, 58, 1044, 320);

    // 3. Center Bay: Giant Dominant Suppression Master Dial
    centralSuppressionDial.setBounds(463, 412, 154, 164);
    centralDialLabel.setBounds(445, 582, 190, 16);
    centralDialSubLabel.setBounds(445, 598, 190, 14);

    // 4. Bay 1: Detection & Learn
    learnButton.setBounds(34, 412, 148, 34);
    linearizerKnob.setBounds(28, 456, 76, 88);
    manualTrimKnob.setBounds(112, 456, 76, 88);
    linearizerLabel.setBounds(24, 546, 84, 13);
    linearizerSubLabel.setBounds(24, 559, 84, 11);
    manualTrimLabel.setBounds(108, 546, 84, 13);
    manualTrimSubLabel.setBounds(108, 559, 84, 11);

    // 5. Bay 2: Acoustic Punch & Style
    consonantKnob.setBounds(218, 436, 86, 96);
    consonantLabel.setBounds(214, 534, 94, 13);
    consonantSubLabel.setBounds(214, 547, 94, 11);

    styleLabel.setBounds(318, 412, 102, 14);
    styleBox.setBounds(318, 428, 102, 24);

    unmaskKnob.setBounds(328, 462, 82, 92);
    unmaskLabel.setBounds(324, 556, 90, 13);
    unmaskSubLabel.setBounds(324, 569, 90, 11);

    // 6. Bay 4: Spectral Polish (De-Ess & Air)
    deessKnob.setBounds(660, 436, 86, 96);
    deessLabel.setBounds(656, 534, 94, 13);
    deessSubLabel.setBounds(656, 547, 94, 11);

    airSheenKnob.setBounds(764, 436, 86, 96);
    airSheenLabel.setBounds(760, 534, 94, 13);
    airSheenSubLabel.setBounds(760, 547, 94, 11);

    autoMakeupToggle.setBounds(700, 584, 122, 26);

    // 7. Bay 5: Master Stage
    clipperKnob.setBounds(928, 436, 86, 96);
    clipperLabel.setBounds(924, 534, 94, 13);
    clipperSubLabel.setBounds(924, 547, 94, 11);

    outputBargraph.setBounds(906, 584, 132, 26);
}

void VocalCraftAudioProcessorEditor::timerCallback() {
    const auto tel = processor.getEngine().getTelemetrySnapshot();

    // 1. Aggiorna lo Spettrogramma Equatore a 60 FPS
    equatorVisualizer.updateTelemetry(
        tel,
        static_cast<float>(centralSuppressionDial.getValue()),
        static_cast<float>(consonantKnob.getValue()),
        static_cast<float>(airSheenKnob.getValue()),
        static_cast<float>(deessKnob.getValue())
    );

    // Sincronizza stato Delta se modificato esternamente
    equatorVisualizer.setDeltaActive(processor.isDeltaMode());

    // 2. Aggiorna la soppressione in tempo reale sulla manopola centrale
    centralSuppressionDial.setRealtimeReductionDb(tel.gainReductionDb);

    // 3. Aggiorna l'animazione e lo stato del pulsante LEARN
    learnButton.setCalibrating(tel.isCalibrating);
    learnButton.setLocked(tel.isLocked);
    learnButton.advanceAnimation();

    // 4. Aggiorna il bargraph orizzontale di uscita
    outputBargraph.setLevels(tel.outputRmsDb, tel.gainReductionDb);
}
