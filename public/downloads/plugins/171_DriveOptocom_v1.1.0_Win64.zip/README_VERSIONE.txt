================================================================================
 171 STUDIO INNOVATIO - SCHEDA TECNICA & VERSIONE
================================================================================
PLUGIN:          171 Drive Optocom (DRIVE OPTOCOM)
CATEGORIA:       Vintage Opto Compressor & Tube Limiter
VERSIONE:        1.1.0
DATA RILASCIO:   2026-10-29
ORA RILASCIO:    18:02:47 (CET)
TIMESTAMP:       2026-10-29T18:02:47+01:00
SVILUPPATORE:    171 Studio Innovatio
STATO:           Ufficiale di Produzione (v1.1.0)
FORMATI:         VST3, Standalone .EXE

DESCRIZIONE:
Emulazione elettro-ottica vintage stile T4B/LA-2A con modello di memoria fotochimica a doppia costante di tempo, stadio valvolare e saturatore push-pull.

MODULO DSP ENGINE:
dsp171::OptoT4B

STORICO MODIFICHE & CHANGELOG:
[1.1.0] - 2026-10-29 18:02:47
- Integrazione ufficiale Serum-V VU Meter con Mode Bank (IN/OUT/GR) e Channel Bank (ST/MONO/MS)

[1.0.0] - 2026-10-27 21:44:16
- Rilascio ufficiale unificato Suite 171 Studio Innovatio v1.0 con standard DSP & GUI professionali.

================================================================================
