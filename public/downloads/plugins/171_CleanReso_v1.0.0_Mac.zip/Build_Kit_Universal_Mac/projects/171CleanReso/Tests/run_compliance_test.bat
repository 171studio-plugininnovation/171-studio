@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
cd /d "C:\Users\171Studio\.gemini\antigravity\scratch\171CleanReso"
cl.exe /EHsc /std:c++20 /O2 /I "C:\Users\171Studio\.gemini\antigravity\scratch\dsp171-core\include" Tests\dsp_compliance_test.cpp /Fe:Tests\dsp_compliance_test.exe
if %ERRORLEVEL% EQU 0 (
    echo [OK] Compilation successful. Running compliance test...
    Tests\dsp_compliance_test.exe
)
