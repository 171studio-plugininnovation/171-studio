#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <chrono>
#include <juce_core/juce_core.h>
#include <juce_events/juce_events.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <dsp171/SafetyCeiling.h>
#include "../Source/PluginProcessor.h"

struct TestResult {
    juce::String testName;
    juce::String inputFileName;
    double durationSec = 0.0;
    float peakInDb = -100.0f;
    float peakOutDb = -100.0f;
    float truePeakInDb = -100.0f;
    float truePeakOutDb = -100.0f;
    float rmsInDb = -100.0f;
    float rmsOutDb = -100.0f;
    float maxGRDb = 0.0f;
    float avgGRDb = 0.0f;
    float maxTransientActivity = 0.0f;
    int safetyCeilingClips = 0;
    int nanOrInfCount = 0;
    bool visualFifoActive = false;
    juce::File outputFile;
};

TestResult runAudioTest(const juce::File& inputFile,
                         const juce::File& outputDir,
                         const juce::String& testName,
                         int presetIndex,
                         bool hardMode,
                         bool deltaListen,
                         float customDepth = -1.0f,
                         float customTransShield = -1.0f)
{
    TestResult res;
    res.testName = testName;
    res.inputFileName = inputFile.getFileName();

    juce::AudioFormatManager formatManager;
    formatManager.registerBasicFormats();

    std::unique_ptr<juce::AudioFormatReader> reader(formatManager.createReaderFor(inputFile));
    if (!reader) {
        std::cerr << "[-] ERRORE: Impossibile leggere il file audio: " << inputFile.getFullPathName() << std::endl;
        return res;
    }

    const double sampleRate = reader->sampleRate;
    const int numChannels = static_cast<int>(reader->numChannels);
    const int totalLength = static_cast<int>(reader->lengthInSamples);
    res.durationSec = static_cast<double>(totalLength) / sampleRate;

    // Buffer audio per l'intero file
    juce::AudioBuffer<float> inBuffer(numChannels, totalLength);
    reader->read(&inBuffer, 0, totalLength, 0, true, true);

    // Istanza del plugin 171CleanReso
    AudioPluginAudioProcessor processor;
    constexpr int blockSize = 512;
    processor.prepareToPlay(sampleRate, blockSize);

    // Detector ITU-R BS.1770 True-Peak indipendenti per audit matematico
    dsp171::TruePeakLimiter tpDetectorIn[2];
    dsp171::TruePeakLimiter tpDetectorOut[2];
    tpDetectorIn[0].prepare(sampleRate);
    tpDetectorIn[1].prepare(sampleRate);
    tpDetectorOut[0].prepare(sampleRate);
    tpDetectorOut[1].prepare(sampleRate);

    // Imposta il preset
    if (presetIndex >= 0) {
        processor.setCurrentProgram(presetIndex);
    }

    auto& apvts = processor.getAPVTS();
    if (hardMode) {
        if (auto* p = apvts.getParameter("mode_hard")) p->setValueNotifyingHost(1.0f);
    }
    if (deltaListen) {
        if (auto* p = apvts.getParameter("delta_listen")) p->setValueNotifyingHost(1.0f);
    }
    if (customDepth >= 0.0f) {
        if (auto* p = apvts.getParameter("depth")) p->setValueNotifyingHost(p->convertTo0to1(customDepth));
    }
    if (customTransShield >= 0.0f) {
        if (auto* p = apvts.getParameter("trans_shield")) p->setValueNotifyingHost(p->convertTo0to1(customTransShield));
    }

    // Buffer di output
    juce::AudioBuffer<float> outBuffer(numChannels, totalLength);
    juce::MidiBuffer midi;

    double sumSqIn = 0.0;
    double sumSqOut = 0.0;
    float peakIn = 0.0f;
    float peakOut = 0.0f;
    float maxTpIn = 0.0f;
    float maxTpOut = 0.0f;

    double totalGRSum = 0.0;
    int grSampleCount = 0;

    int numBlocks = (totalLength + blockSize - 1) / blockSize;

    for (int b = 0; b < numBlocks; ++b) {
        const int startSample = b * blockSize;
        const int currentBlockSize = std::min(blockSize, totalLength - startSample);

        // Prepariamo il blocco stereo (se il file è mono, espandiamo a stereo)
        juce::AudioBuffer<float> blockBuffer(2, currentBlockSize);
        for (int ch = 0; ch < 2; ++ch) {
            const int inCh = std::min(ch, numChannels - 1);
            blockBuffer.copyFrom(ch, 0, inBuffer, inCh, startSample, currentBlockSize);
        }

        // Misura ingresso (Sample Peak + ITU-R BS.1770 True-Peak + RMS)
        for (int ch = 0; ch < 2; ++ch) {
            for (int i = 0; i < currentBlockSize; ++i) {
                float s = blockBuffer.getSample(ch, i);
                float a = std::abs(s);
                if (a > peakIn) peakIn = a;
                sumSqIn += s * s;

                float dummy = 0.0f;
                float tp = tpDetectorIn[ch].computeTruePeak(s, dummy);
                if (tp > maxTpIn) maxTpIn = tp;
            }
        }

        // ELABORAZIONE ATTRAVERSO IL PLUGIN 171CleanReso
        processor.processBlock(blockBuffer, midi);

        // Controllo e lettura FIFO visuale 60 FPS
        dsp171::ResoVisualFrame frame;
        while (processor.getVisualFIFO().pop(frame)) {
            res.visualFifoActive = true;
            if (frame.maxReductionDb > res.maxGRDb) res.maxGRDb = frame.maxReductionDb;
            if (frame.transientActivity > res.maxTransientActivity) res.maxTransientActivity = frame.transientActivity;
            totalGRSum += frame.maxReductionDb;
            grSampleCount++;
        }

        // Misura uscita e verifica sicurezza True-Peak & NaN/Inf
        for (int ch = 0; ch < 2; ++ch) {
            for (int i = 0; i < currentBlockSize; ++i) {
                float s = blockBuffer.getSample(ch, i);

                // Controllo NaN / Infinito
                if (std::isnan(s) || std::isinf(s)) {
                    res.nanOrInfCount++;
                }

                float a = std::abs(s);
                if (a > peakOut) peakOut = a;
                sumSqOut += s * s;

                float dummy = 0.0f;
                float tp = tpDetectorOut[ch].computeTruePeak(s, dummy);
                if (tp > maxTpOut) maxTpOut = tp;

                // Controllo Safety Ceiling (-0.10 dBTP = 0.988553f con margine di tolleranza floating point a 0.98865f)
                if (tp > 0.98865f) {
                    res.safetyCeilingClips++;
                }
            }
        }

        // Copia nel buffer di output
        for (int ch = 0; ch < std::min(2, numChannels); ++ch) {
            outBuffer.copyFrom(ch, startSample, blockBuffer, ch, 0, currentBlockSize);
        }
    }

    const double totalSamplesIn = static_cast<double>(totalLength * 2);
    res.peakInDb      = peakIn > 1.0e-5f ? 20.0f * std::log10(peakIn) : -100.0f;
    res.peakOutDb     = peakOut > 1.0e-5f ? 20.0f * std::log10(peakOut) : -100.0f;
    res.truePeakInDb  = maxTpIn > 1.0e-5f ? 20.0f * std::log10(maxTpIn) : -100.0f;
    res.truePeakOutDb = maxTpOut > 1.0e-5f ? 20.0f * std::log10(maxTpOut) : -100.0f;
    res.rmsInDb       = sumSqIn > 0.0 ? 20.0f * std::log10(std::sqrt(sumSqIn / totalSamplesIn)) : -100.0f;
    res.rmsOutDb      = sumSqOut > 0.0 ? 20.0f * std::log10(std::sqrt(sumSqOut / totalSamplesIn)) : -100.0f;
    res.avgGRDb       = grSampleCount > 0 ? static_cast<float>(totalGRSum / grSampleCount) : 0.0f;

    // Salvataggio del file WAV risultante per ascolto
    outputDir.createDirectory();
    juce::File outFile = outputDir.getChildFile(testName + ".wav");
    outFile.deleteFile();

    juce::WavAudioFormat wavFormat;
    std::unique_ptr<juce::AudioFormatWriter> writer(
        wavFormat.createWriterFor(new juce::FileOutputStream(outFile),
                                  sampleRate,
                                  static_cast<unsigned int>(numChannels),
                                  24, {}, 0));
    if (writer) {
        writer->writeFromAudioSampleBuffer(outBuffer, 0, totalLength);
        writer.reset();
        res.outputFile = outFile;
    }

    return res;
}

int main(int argc, char* argv[]) {
    juce::ScopedJuceInitialiser_GUI guiInit;

    // Cattura Snapshot Ufficiale GUI del plugin live
    {
        AudioPluginAudioProcessor proc;
        std::unique_ptr<juce::AudioProcessorEditor> ed(proc.createEditorIfNeeded());
        if (ed) {
            ed->setSize(1024, 571);
            auto snap = ed->createComponentSnapshot(ed->getLocalBounds());

            std::vector<juce::File> snapFiles = {
                juce::File(R"(C:\Users\171Studio\.gemini\antigravity\brain\09083e63-7efb-4e38-b54a-484d18d4fb1f\171CleanReso_Final_GUI.png)"),
                juce::File(R"(C:\Users\171Studio\.gemini\antigravity\brain\947230ff-c9a3-4709-a320-b596b6ee2c5f\171CleanReso_Final_GUI.png)"),
                juce::File(R"(C:\Users\171Studio\.gemini\antigravity\scratch\171CleanReso\171CleanReso_Final_GUI.png)"),
                juce::File(R"(C:\Users\171Studio\Desktop\171PluginInnovation - CleanReso\171CleanReso_Final_GUI.png)"),
                juce::File(R"(C:\Users\171Studio\.gemini\antigravity\brain\a512c5b2-faa2-4a19-af6f-b21bbccd03db\171CleanReso_Live_AluminumKnobs.png)")
            };

            juce::PNGImageFormat png;
            for (auto& sf : snapFiles) {
                sf.getParentDirectory().createDirectory();
                sf.deleteFile();
                juce::FileOutputStream stream(sf);
                if (stream.openedOk()) {
                    png.writeImageToStream(snap, stream);
                    std::cout << "[+] Screenshot GUI salvato con successo: " << sf.getFullPathName() << "\n";
                }
            }
        }
    }

    if (argc > 1 && juce::String(argv[1]) == "--snap-only") {
        return 0;
    }

    std::cout << "======================================================================================\n";
    std::cout << " 171CleanReso - AUDIT DINAMICO DI QUALITA' SU AUDIO REALE (BEAT & REC ALBUM)         \n";
    std::cout << "======================================================================================\n\n";

    const juce::File beatMixtapeDir(R"(C:\Users\171Studio\Desktop\beat mixtape)");
    const juce::File outputDir(R"(C:\Users\171Studio\Desktop\beat mixtape\171CleanReso_Test_Outputs)");

    std::vector<TestResult> results;

    // 1. BEAT COMPLETO (Brother.wav)
    juce::File beatFile = beatMixtapeDir.getChildFile("brother").getChildFile("Brother.wav");
    if (beatFile.existsAsFile()) {
        std::cout << "[*] Collaudo 1: BEAT COMPLETO (" << beatFile.getFileName() << ")\n";
        // Test 1A: Master Bus Tamer (Preset 05 - Soft Mode)
        std::cout << "    -> Esecuzione Test 1A: Master Bus Tamer (Soft Mode)...\n";
        results.push_back(runAudioTest(beatFile, outputDir, "01_Brother_Beat_MasterTamer_Soft", 4, false, false));

        // Test 1B: Surgical Resonance Hunter (Preset 08 - Hard Mode)
        std::cout << "    -> Esecuzione Test 1B: Surgical Hunter (Hard Mode)...\n";
        results.push_back(runAudioTest(beatFile, outputDir, "02_Brother_Beat_SurgicalHunter_Hard", 7, true, false));
    } else {
        std::cout << "[-] File beat non trovato: " << beatFile.getFullPathName() << "\n";
    }

    // 2. STEM BATTERIA / PERCUSSIONI (0 Drums.wav)
    juce::File drumsFile = beatMixtapeDir.getChildFile("brother").getChildFile("0 Drums.wav");
    if (drumsFile.existsAsFile()) {
        std::cout << "\n[*] Collaudo 2: STEM BATTERIA CON TRANSIENT SHIELD (" << drumsFile.getFileName() << ")\n";
        // Test 2A: Snare Ring & Boxiness Kill (Preset 02) con Transient Shield al 85%
        std::cout << "    -> Esecuzione Test 2A: Snare Ring Kill + Transient Shield 85%...\n";
        results.push_back(runAudioTest(drumsFile, outputDir, "03_Drums_SnareRing_TransShield85", 1, false, false, 0.65f, 0.85f));

        // Test 2B: Harsh Hi-Hats & Cymbals (Preset 04)
        std::cout << "    -> Esecuzione Test 2B: Harsh Cymbals Tamer...\n";
        results.push_back(runAudioTest(drumsFile, outputDir, "04_Drums_Cymbals_Tamed", 3, false, false));
    } else {
        std::cout << "[-] File drums non trovato: " << drumsFile.getFullPathName() << "\n";
    }

    // 3. VOCE LEAD REC ALBUM (04-251202_1939.wav)
    juce::File vocalFile1 = beatMixtapeDir.getChildFile("REC ALBUM").getChildFile("REC BROTHER").getChildFile("Media").getChildFile("04-251202_1939.wav");
    if (vocalFile1.existsAsFile()) {
        std::cout << "\n[*] Collaudo 3: VOCE REC ALBUM BROTHER (" << vocalFile1.getFileName() << ")\n";
        // Test 3A: Vocal De-Harsh & Sibilance (Preset 01 - Soft Mode + Analog Silk)
        std::cout << "    -> Esecuzione Test 3A: Vocal De-Harsh & Sibilance (Soft + Silk)...\n";
        results.push_back(runAudioTest(vocalFile1, outputDir, "05_Vocal_DeHarsh_Silk_Soft", 0, false, false));

        // Test 3B: DELTA LISTEN SOLO (Ascolto isolato delle sole frequenze aspre rimosse)
        std::cout << "    -> Esecuzione Test 3B: DELTA LISTEN SOLO (Risonanze aspre estratte)...\n";
        results.push_back(runAudioTest(vocalFile1, outputDir, "06_Vocal_DeltaListen_IsolatedHarshness", 0, false, true));
    } else {
        std::cout << "[-] File vocal 1 non trovato: " << vocalFile1.getFullPathName() << "\n";
    }

    // 4. SECONDA VOCE LEAD (01-260220_1830.wav)
    juce::File vocalFile2 = beatMixtapeDir.getChildFile("REC ALBUM").getChildFile("REC BROTHER").getChildFile("Media").getChildFile("01-260220_1830.wav");
    if (vocalFile2.existsAsFile()) {
        std::cout << "\n[*] Collaudo 4: SECONDA TAKE VOCE (" << vocalFile2.getFileName() << ")\n";
        // Test 4A: Vocal Sibilance Clamp (Hard Mode)
        std::cout << "    -> Esecuzione Test 4A: Vocal Sibilance Clamp (Hard Mode)...\n";
        results.push_back(runAudioTest(vocalFile2, outputDir, "07_VocalTake_HardClamp", 0, true, false, 0.70f));
    }

    // 5. PROGETTO NICARAGUA BEAT (nicaragua BEAT.wav) - TEST MIX 100% PUNCH & TRASPARENZA
    juce::File nicaraguaFile(R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\ADRIANO\nicaragua BEAT.wav)");
    if (nicaraguaFile.existsAsFile()) {
        std::cout << "\n[*] Collaudo 5: PROGETTO NICARAGUA BEAT - TEST MIX 100% TRASPARENZA (" << nicaraguaFile.getFileName() << ")\n";
        std::cout << "    -> Esecuzione Test 5A: Nicaragua Beat (Preset 05 - Master Bus Harshness Tamer, Mix 100%)...\n";
        results.push_back(runAudioTest(nicaraguaFile, outputDir, "08_Nicaragua_Beat_Mix100_Tamed", 4, false, false));
    }

    // STAMPA REPORT DETTAGLIATO DEI RISULTATI
    std::cout << "\n===================================================================================================================================\n";
    std::cout << " TABELLA RISULTATI AUDIT INGEGNERISTICO 171CleanReso (MSVC C++20 Release)\n";
    std::cout << "===================================================================================================================================\n";
    std::cout << std::left
              << std::setw(36) << "Test ID / Modalita"
              << std::setw(10) << "Durata(s)"
              << std::setw(11) << "Pk In(dB)"
              << std::setw(11) << "TP In(dBTP)"
              << std::setw(11) << "Pk Out(dB)"
              << std::setw(12) << "TP Out(dBTP)"
              << std::setw(11) << "RMS In"
              << std::setw(11) << "RMS Out"
              << std::setw(10) << "Max GR"
              << std::setw(11) << "TP<=-0.10"
              << std::setw(9)  << "NaN/Inf"
              << "Esito\n";
    std::cout << "-----------------------------------------------------------------------------------------------------------------------------------\n";

    bool allPassed = true;

    for (const auto& r : results) {
        bool pass = (r.nanOrInfCount == 0) && (r.safetyCeilingClips == 0) && (r.truePeakOutDb <= -0.095f);
        if (!pass) allPassed = false;

        std::cout << std::left
                  << std::setw(36) << r.testName.substring(0, 35).toStdString()
                  << std::setw(10) << std::fixed << std::setprecision(1) << r.durationSec
                  << std::setw(11) << (juce::String(r.peakInDb, 1) + " dB").toStdString()
                  << std::setw(11) << (juce::String(r.truePeakInDb, 1) + " TP").toStdString()
                  << std::setw(11) << (juce::String(r.peakOutDb, 1) + " dB").toStdString()
                  << std::setw(12) << (juce::String(r.truePeakOutDb, 1) + " TP").toStdString()
                  << std::setw(11) << (juce::String(r.rmsInDb, 1) + " dB").toStdString()
                  << std::setw(11) << (juce::String(r.rmsOutDb, 1) + " dB").toStdString()
                  << std::setw(10) << ("-" + juce::String(r.maxGRDb, 1) + " dB").toStdString()
                  << std::setw(11) << (r.safetyCeilingClips == 0 ? "SICURO" : "CLIPPED")
                  << std::setw(9)  << r.nanOrInfCount
                  << (pass ? "[SUPERATO]" : "[FALLITO]")
                  << "\n";
    }

    std::cout << "-----------------------------------------------------------------------------------------------------------------------------------\n";
    std::cout << "\nEsito complessivo: " << (allPassed ? "TUTTI I TEST SUPERATI CON SUCCESSO (100% PASS)" : "ATTENZIONE: ALCUNI TEST HANNO SEGNALATO ANOMALIE") << "\n";
    std::cout << "File audio esportati in: " << outputDir.getFullPathName() << "\n";
    std::cout << "===================================================================================================================================\n";

    return allPassed ? 0 : 1;
}
