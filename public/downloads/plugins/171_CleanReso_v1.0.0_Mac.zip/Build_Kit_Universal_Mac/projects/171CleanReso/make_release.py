import os, shutil, zipfile

# 1. Install to system Common Files VST3
vst3_src = r'C:\Users\171Studio\.gemini\antigravity\scratch\171CleanReso\build\171CleanReso_artefacts\Release\VST3\171CleanReso.vst3'
vst3_dst = r'C:\Program Files\Common Files\VST3\171CleanReso.vst3'

if os.path.exists(vst3_dst):
    shutil.rmtree(vst3_dst)
shutil.copytree(vst3_src, vst3_dst)
print('Installed 171CleanReso.vst3 to system VST3 directory.')

# 2. Prepare Release_Package
pkg_dir = r'C:\Users\171Studio\.gemini\antigravity\scratch\171CleanReso\Release_Package'
if os.path.exists(pkg_dir):
    shutil.rmtree(pkg_dir)
os.makedirs(pkg_dir, exist_ok=True)

shutil.copytree(vst3_src, os.path.join(pkg_dir, '171CleanReso.vst3'))
shutil.copy2(r'C:\Users\171Studio\.gemini\antigravity\scratch\171CleanReso\build\171CleanReso_artefacts\Release\Standalone\171CleanReso.exe', os.path.join(pkg_dir, '171CleanReso_Standalone.exe'))
shutil.copytree(r'C:\Users\171Studio\.gemini\antigravity\scratch\171CleanReso\rules', os.path.join(pkg_dir, 'rules'))

# Copy high-res screenshots
screen_src = r'C:\Users\171Studio\.gemini\antigravity\brain\a512c5b2-faa2-4a19-af6f-b21bbccd03db\171CleanReso_client_gui.png'
if os.path.exists(screen_src):
    shutil.copy2(screen_src, os.path.join(pkg_dir, '171CleanReso_GUI_Reference.png'))

# Copy README and docs
readme_text = """171CleanReso - Transient-Aware Dynamic Resonance Suppressor & Spectral Shaper
Version 1.0.0 PRO (Studio Innovation Edition)
171PluginInnovation - All Rights Reserved

============================================================
1. PERCHE' 171CleanReso E' RIVOLUZIONARIO:
============================================================
Nei tradizionali soppressori spettrali (come Soothe 2), gli algoritmi 
scambiano gli attacchi delle percussioni e delle consonanti vocali per picchi 
risonanti, smussando e mangiando l'energia dei colpi (time-smearing).

171CleanReso introduce il "TRANSIENT SHIELD":
- Riconosce in tempo reale con doppio inseguitore balistico se l'energia 
  appartiene a un attacco impulsivo o a una risonanza stazionaria.
- Scherma i transienti lasciandoli passare al 100% intatti (punch e snap preservati).
- Applica i notch dinamici con ponderazione psicoacustica ISO 226 (sensibilita' 
  fino a 3x sull'asprezza 2.5 kHz - 5 kHz) esclusivamente sulle risonanze fischianti.

============================================================
2. I CONTROLLI DELLA CONSOLE:
============================================================
- SOFT / HARD TOGGLE: 
  * SOFT: Intervento progressivo, organico e musicale per voci, chitarre acustiche e master bus.
  * HARD: Intervento chirurgico ad aggancio rapido per piatti metallici, sibilanti taglienti e ring di rullante.
- PRESET SELECTOR: 8 preset calibrati di fabbrica per ogni scenario di mix e mastering.
- DELTA LISTEN (Spia Jewel Ambra): Ascolto isolato delle sole frequenze aspre e risonanze rimosse.
- MASTER BYPASS (Spia LED Verde/Rosso): Dissolvenza incrociata continua a 15 ms pop-free.
- DEPTH: Intensita' globale della soppressione dinamica (0% - 100%).
- SHARPNESS: Fattore Q delle campane di soppressione (da largo a chirurgico ultra-stretto).
- SELECTIVITY: Soglia di discriminazione tra risonanza dannosa e corpo timbrico naturale dello strumento.
- TRANS SHIELD (Manopola Hero Centrale): Grado di schermatura e protezione degli attacchi impulsivi.
- ANALOG SILK: Stadio di lucidatura post-pulizia con High-Air Baxandall a 12 kHz e calore valvolare da 2a armonica.
- MIX: Bilanciamento Dry / Wet a fase lineare e coerente.
- OUTPUT: Regolazione del guadagno d'uscita finale (-18 dB a +12 dB).

============================================================
3. DISPLAY SPETTRALE E METER DE-HARSH DEDICATO (60 FPS):
============================================================
- DISPLAY SPETTRALE PRINCIPALE (Cornice Dorata Sinistra):
  * Curva Ciano / Blu con sfumatura: Spettro audio in ingresso ad alta risoluzione.
  * Curva Dips Arancio / Rosso: Attenuazione dinamica in tempo reale delle 32 bande logaritmiche.
  * Readout Digitale: Frequenza dominante della risonanza (Hz) e valore di Gain Reduction massimo (dB).
  * Badge Transient Shield: Segnala quando gli attacchi sono protetti dalla soppressione.

- METER DEDICATO DE-HARSH (Cornice Dorata Destra):
  * Colonna verticale a 20 segmenti LED con codice colore graduato (Verde -> Oro -> Arancio -> Rosso).
  * Indicatore Peak-Hold ad alta intensita' con decadimento balistico gravitazionale.
  * Scala serigrafata da 0 dB a -30 dB di riduzione.
  * Display numerico digitale dedicato alla base del meter.

============================================================
4. SPECIFICHE TECNICHE ED INGEGNERISTICHE:
============================================================
- Architettura: JUCE 8.0.4, C++20 nativo, MSVC 2022 con ottimizzazioni /fp:fast e /O2.
- Sicurezza: Analog Safety Brickwall Ceil a -0.09 dBFS (zero clipping inter-sample).
- Latenza & Threading: Coda SPSC Lock-Free cache-aligned a 64 byte, zero allocazioni sull'audio thread.
- Standard Formati: VST3 (64-bit) e Standalone Windows nativo.

============================================================
INSTALLAZIONE:
============================================================
- VST3: La cartella '171CleanReso.vst3' e' gia' installata in:
  C:\\Program Files\\Common Files\\VST3\\171CleanReso.vst3
- Standalone: Avvia '171CleanReso_Standalone.exe' per uso diretto senza DAW.
"""

with open(os.path.join(pkg_dir, 'README.txt'), 'w', encoding='utf-8') as f:
    f.write(readme_text)

# 3. Create ZIP on Desktop
zip_dst = r'C:\Users\171Studio\Desktop\171CleanReso_v1.0.0_171PluginInnovation.zip'
if os.path.exists(zip_dst):
    os.remove(zip_dst)

with zipfile.ZipFile(zip_dst, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(pkg_dir):
        for f in files:
            full_p = os.path.join(root, f)
            rel_p = os.path.relpath(full_p, pkg_dir)
            zipf.write(full_p, rel_p)

print('Successfully created Desktop ZIP archive:', zip_dst)
print('ZIP Size:', os.path.getsize(zip_dst), 'bytes')
