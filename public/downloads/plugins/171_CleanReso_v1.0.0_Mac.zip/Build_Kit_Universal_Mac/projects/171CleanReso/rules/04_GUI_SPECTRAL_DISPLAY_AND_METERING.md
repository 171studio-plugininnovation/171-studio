# Modulo 04: Display Spettrale Vettoriale & GUI
**Plugin:** 171CleanReso (Dynamic Resonance Suppressor)  
**Standard:** 60 FPS Lock-Free Architecture & Studio Visual Feedback

---

## 1. Disaccoppiamento Audio/GUI a 60 FPS

* Il thread audio (`processBlock`) e il thread grafico (`timerCallback`) sono rigorosamente disaccoppiati tramite SPSC Lock-Free FIFO.
* La struttura `ResoVisualFrame` trasferisce:
  * Array di magnitudine spettrale FFT in ingresso (32 bande logaritmiche da 20 Hz a 20 kHz);
  * Array di Gain Reduction dinamica (dB di attenuazione istantanea per banda);
  * Frequenza dominante della risonanza soppressa (Hz) e massima attenuazione di picco (dB);
  * Livelli RMS Stereo ($L$ e $R$) e Picco Stereo d'uscita.

---

## 2. Display Spettrale a Doppia Curva (Real-Time Visualizer)

Al centro dell'interfaccia risiede il monitor a cristallo dorato protetto da cornice metallica:

1. **Curva Spettrale Superiore (Spettro Audio):**
   * Curva fluida a gradiente ciano/ambra dorata che rappresenta la distribuzione spettrale del segnale in ingresso.
   * Decadimento esponenziale analogico a 60 FPS per evitare sfarfallii.
2. **Curva Dinamica di Gain Reduction (Curve Dips verso il basso):**
   * Curva al neon rosso incandescente / arancione che si deflette verso il basso esattamente sulle frequenze in cui le risonanze vengono catturate e soppresse.
   * Consente all'ingegnere di vedere immediatamente quale frequenza (es. $3.2\text{ kHz}$) sta risonando e con quanti dB di intensità viene attenuata.
3. **Display Readout Digitale con LED:**
   * Box LCD vintage che riporta con precisione millimetrica:
     - `PEAK RESO`: Frequenza del picco principale (es. `3420 Hz`);
     - `MAX GR`: Massimo abbattimento istantaneo (es. `-6.5 dB`).

---

## 3. Disposizione Controlli della Console (Faceplate 1024x571)

* **Barra Superiore (Console Header):**
  * Logo metallico 3D `171CLEANRESO` sulla sinistra;
  * Sottotitolo `DYNAMIC RESONANCE SUPPRESSOR & SPECTRAL SHAPER` al centro;
  * **Selettore Preset** centrato direttamente sotto il sottotitolo ($Y = 88, H = 26$);
  * **Tasto Delta Listen** con lampada Jewel ambra per isolare le risonanze rimosse;
  * **Tasto Master Bypass** con LED bicolore Verde Smeraldo / Rosso Neon sotto la scritta *171PLUGIN INNOVATION* ($Y = 88, H = 26$).
* **Riga Inferiore (Le Manopole Analogiche Master):**
  1. `DEPTH` (Hero knob centrale neon arancio/rosso per intensità soppressione);
  2. `SHARPNESS` (Larghezza banda Q notch);
  3. `SELECTIVITY` (Soglia discriminazione risonanza);
  4. `TRANSIENT SHIELD` (Protezione attacchi percussivi);
  5. `ATTACK` (Velocità intervento soppressore);
  6. `RELEASE` (Tempo di recupero);
  7. `ANALOG SILK` (Lucidatura valvolare e aria 12 kHz);
  8. `MIX` (Bilanciamento Dry/Wet parallelo);
  9. `OUTPUT TRIM` (Compensazione livello d'uscita).
