# Modulo 05: Ciclo di Vita DAW & Versioning Preset
**Plugin:** 171CleanReso (Dynamic Resonance Suppressor)  
**Standard:** VST3 / AU Standard Architecture

---

## 1. Gestione del Cambio di Sample Rate a Caldo

Le DAW possono variare la frequenza di campionamento ($44.1$, $48$, $88.2$, $96$, $192\text{ kHz}$) o la dimensione del buffer in qualsiasi istante.

### Procedura Obbligatoria in `prepareToPlay(double sampleRate, int samplesPerBlock)`:
1. Validazione sample rate ($f_s \ge 22050.0$).
2. Ricalcolo di tutte le frequenze centrali delle bande notch, costanti di tempo dei filtri envelope follower e coefficienti del filtro shelf a 12 kHz.
3. Riconfigurazione di tutte le rampe di smoothing dei parametri:
   * Rampe di smoothing a $20\text{ ms}$ su tutte le manopole continue (`juce::SmoothedValue`).
   * Rampa di crossfade a $15\text{ ms}$ sul tasto Master Bypass e sul Delta Listen per azzerare click acustici.
4. Azzeramento (`reset()`) di tutte le memorie interne dei filtri biquad ed envelope detector per evitare burst acustici o transitori fantasma.

---

## 2. Versioning e Retrocompatibilità dello Stato APVTS

I metodi `getStateInformation()` e `setStateInformation()` devono impiegare la serializzazione XML dell'albero `juce::AudioProcessorValueTreeState` con marcatura di versione:

```cpp
void AudioPluginAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    auto state = apvts.copyState();
    state.setProperty("version", 1, nullptr);
    state.setProperty("currentPreset", currentProgramIndex, nullptr);
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void AudioPluginAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType())) {
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
        currentProgramIndex = apvts.state.getProperty("currentPreset", 0);
    }
}
```
