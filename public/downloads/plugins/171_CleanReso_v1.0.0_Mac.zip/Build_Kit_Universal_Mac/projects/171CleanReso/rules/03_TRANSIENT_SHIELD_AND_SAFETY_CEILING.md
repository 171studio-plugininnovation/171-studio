# Modulo 03: Transient Shield & True-Peak ISP Limiter
**Plugin:** 171CleanReso (Dynamic Resonance Suppressor)  
**Standard:** Pro Audio Dynamics & Inter-Sample Peak Compliance (ITU-R BS.1770-4)

---

## 1. Tecnologia Proprietaria "Stereo-Coupled Transient Shield"

Il difetto principale dei soppressori spettrali commerciali (come Soothe 2 o i dynamic EQ non guidati) è l'uccisione involontaria dei transienti. Quando una cassa, un rullante o una consonante vocale picchia, la sua energia istantanea supera la soglia spettrale media. Il plugin crede erroneamente che si tratti di una risonanza e ne attenua l'attacco, rendendo il mix moscio e privo di mordente.

### Meccanismo Stereo-Coupled a Soundstage Protetto:
1. Il modulo d'ingresso elabora i canali L e R in maniera accoppiata mediante `TransientSplitter::processStereo(inL, inR)`.
2. L'inviluppo congiunto $W_{\text{trans}}[n] = \max(W_L, W_R)$ garantisce identica schermatura su entrambi i canali:
   $$G_{\text{effective}}[k] = G_{\text{target}}[k] \cdot \max\left(0.0, 1.0 - \text{TransientShield} \cdot W_{\text{trans}}[n] \cdot 1.25\right)$$
3. **Risultato Acustico:** L'attacco percussivo e le consonanti esplosive rimangono al 100% nitidi e incisivi. Zero sbandamento del centro fantasma (phantom center yaw) e soundstage tridimensionale preservato.

---

## 2. Stadio di Lucidatura Analogica "Neve Silk Red & Air"

Dopo aver rimosso le asprezze da una voce o da una chitarra, la traccia può talvolta suonare asciutta.

* **Baxandall / Neve Air Shelf a 12 kHz (2° Ordine ZDF):**
  Filtro a variabili di stato Cytomic del secondo ordine ($Q = 0.58$) che confina l'apertura armonica sopra i 10 kHz, mantenendo completamente piatta la risposta nella zona 1-5 kHz.
* **Neve Silk Red (Class-A 2nd-Harmonic Generation):**
  Generazione pura di armoniche pari morbide ($k_2 \cdot x|x|$) tipiche dello stadio d'uscita a trasformatore Class-A con feedback ridotto, accompagnata da DC-Blocker ZDF a 5 Hz. Niente clipping a diodi anti-paralleli né distorsione dispari ruvida.

---

## 3. True-Peak Lookahead Limiter ITU-R BS.1770-4 (-0.10 dBTP)

171CleanReso implementa la protezione rigorosa True-Peak di livello mastering:

* **Interpolazione Polifase 4x (Filtri Sinc Kaiser $\beta=7.0$):**
  Ricostruisce fedelmente la forma d'onda analogica inter-sample continua, individuando sovraelongazioni fino a $+3\text{ dBTP}$ che sfuggono ai normali campionatori digitali.
* **Lookahead Deterministico (4 campioni):**
  Latenza di 4 campioni comunicata regolarmente alla DAW tramite `setLatencySamples(4)`.
* **Master Bypass a Compensazione di Fase Bit-Exact (`LatencyCompensatedBypass`):**
  Il canale Dry originale viene ritardato di esattamente 4 campioni prima del crossfade con il segnale processato, eliminando qualsiasi cancellazione di fase pettine (comb filtering/flanging) durante l'automazione del bypass o l'ascolto in modalità Delta.
