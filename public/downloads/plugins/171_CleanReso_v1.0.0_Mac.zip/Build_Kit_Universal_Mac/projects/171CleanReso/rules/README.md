# 171CleanReso – Regole & Linee Guida di Ingegneria DSP
**Target:** Agente di Sviluppo Software, Architettura DSP e Ingegneria Grafica  
**Progetto:** 171CleanReso (Dynamic Resonance Suppressor & Spectral Shaper) VST3 / Standalone  
**Standard Tecnico:** Pro Audio Studio Grade (Oeksound Soothe 2, FabFilter Pro-Q 3, Gullfoss, Soundtoys)

---

## Indice dei Moduli di Regola nella Cartella `rules/`

L'agente al lavoro su questo plugin **DEVE verificare e rispettare rigorosamente** i seguenti moduli di specifica:

1. [01_REALTIME_THREAD_SAFETY.md](file:///C:/Users/171Studio/.gemini/antigravity/scratch/171CleanReso/rules/01_REALTIME_THREAD_SAFETY.md)
   * Regole ferree del thread audio (`processBlock`): zero allocazioni heap, assenza di lock/mutex, guardia `juce::ScopedNoDenormals`, disaccoppiamento Lock-Free SPSC FIFO a 512 frame, protezione da `NaN`/divisioni per zero e rampa di dissolvenza Bypass pop-free a 15 ms.
2. [02_SPECTRAL_RESONANCE_DSP.md](file:///C:/Users/171Studio/.gemini/antigravity/scratch/171CleanReso/rules/02_SPECTRAL_RESONANCE_DSP.md)
   * Motore di rilevamento ed eliminazione dinamica delle risonanze: stima spettrale STFT multi-banda a bassa latenza, curve psicoacustiche ISO 226 (sensibilità auricolare 2-5 kHz), array di filtri notch dinamici a campanatura variabile ($Q$) e modalità di ascolto Delta Solo (`DELTA` Listen).
3. [03_TRANSIENT_SHIELD_AND_SAFETY_CEILING.md](file:///C:/Users/171Studio/.gemini/antigravity/scratch/171CleanReso/rules/03_TRANSIENT_SHIELD_AND_SAFETY_CEILING.md)
   * Tecnologia proprietaria **Transient Shield**: protezione dinamica dei fronti d'attacco percussivi (evita lo smearing e la perdita di punch sui transienti), stadio di lucidatura analogica **Silk & Warmth** a 12 kHz, e **Analog Safety Brickwall Soft-Ceiling a $-0.09\text{ dBFS}$ ($0.9900$)** per azzerare qualsiasi digital clipping inter-sample.
4. [04_GUI_SPECTRAL_DISPLAY_AND_METERING.md](file:///C:/Users/171Studio/.gemini/antigravity/scratch/171CleanReso/rules/04_GUI_SPECTRAL_DISPLAY_AND_METERING.md)
   * Display spettrale a 60 FPS vettoriale: curva spettrale FFT in ingresso (Ciano/Oro) e curva dinamica di Gain Reduction verso il basso (Arancio/Rosso neon), Readout LCD per frequenza risonante dominante e dB GR massimi, manopole metalliche spazzolate con notch dorati e tasto Bypass con LED Verde/Rosso.
5. [05_DAW_LIFECYCLE_AND_VERSIONING.md](file:///C:/Users/171Studio/.gemini/antigravity/scratch/171CleanReso/rules/05_DAW_LIFECYCLE_AND_VERSIONING.md)
   * Ciclo di vita della DAW, ricalcolo costanti al cambio a caldo di sample rate in `prepareToPlay()`, smoothing a 20 ms anti-zipper su tutti i controlli continui e versioning XML APVTS con retrocompatibilità garantita.

---

## Tabella dei Vincoli Fondamentali di Progetto

| Vincolo | Requisito Assoluto | Implementazione Verificata nel Codice |
| :--- | :--- | :--- |
| **Allocazioni Heap** | `0` byte in `processBlock()` | Tutti i buffer dimensionati in `prepareToPlay()` |
| **Denormali (FTZ/DAZ)** | `ScopedNoDenormals` attivo | Presente all'inizio di `processBlock()` |
| **Smoothing Parametri** | $20\text{ ms}$ rampa continua | `juce::SmoothedValue` su tutte le manopole |
| **Bypass Pop-Free** | Dissolvenza incrociata $15\text{ ms}$ | `smoothedBypass` sample-by-sample linear crossfade |
| **Rilevamento Risonanze**| Multi-banda reattivo con ISO 226 | Rilevamento differenziale dei picchi stazionari |
| **Protezione Transienti**| Transient Shield dinamico | Bypass delle finestre di attacco ($W_{\text{trans}} > 0$) |
| **Ascolto Delta** | Delta Solo ($x_{\text{in}} - x_{\text{out}}$) | Modalità di verifica chirurgica delle frequenze rimosse |
| **Tetto Massimo Picco** | $\le -0.09\text{ dBFS}$ ($0.9900$) | Analog Safety Soft-Ceiling asintotico su $x > 0.85$ |
| **Display Spettrale** | 60 FPS Disaccoppiato | Curva FFT + Curva dinamica di Gain Reduction |
