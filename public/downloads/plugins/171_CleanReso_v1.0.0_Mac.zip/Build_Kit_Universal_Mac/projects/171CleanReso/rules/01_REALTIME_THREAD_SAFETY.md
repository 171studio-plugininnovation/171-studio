# Modulo 01: Sicurezza Real-Time e Threading
**Plugin:** 171CleanReso (Dynamic Resonance Suppressor)  
**Standard:** Ross Bencina Real-Time Audio Programming Standards (VST3 / AU)

---

## 1. Regole Ferree per il Thread Audio (`processBlock`)

Nel metodo `processBlock()` e in tutti i moduli DSP chiamati per-sample:

1. **DIVIETO ASSOLUTO DI ALLOCAZIONI MEMORIA SULL'HEAP:**
   - È tassativamente vietato l'uso di `new`, `delete`, `malloc`, `free`.
   - È vietato l'uso di `std::vector::push_back`, `std::vector::resize`, `std::string` o qualsiasi contenitore dinamico che possa provocare riallocazione o page faults.
   - Tutti i buffer FFT, array di stato dei filtri notch e tabelle di contorno spettrale devono essere pre-allocati e dimensionati in `prepareToPlay(sampleRate, samplesPerBlock)`.

2. **DIVIETO DI MUTEX E PRIMITIVE BLOCCANTI:**
   - Mai usare `std::mutex`, `std::unique_lock`, `std::condition_variable` nel thread audio.
   - Il thread audio non deve MAI attendere il thread GUI (*Priority Inversion Protection*).

3. **DISACCOPPIAMENTO TRAMITE LOCK-FREE FIFO:**
   - Lo scambio dati spettrali (spettro FFT e curva di riduzione per banda) verso la GUI deve avvenire unicamente tramite la struttura `dsp171::LockFreeVisualFIFO<512>` (SPSC Lock-Free Ring Buffer a 512 frame con semantica acquire/release).
   - Se la coda è piena, il thread audio sovrascrive o scarta il frame senza bloccare.

4. **PROTEZIONE DAI NUMERI DENORMALI (FTZ/DAZ):**
   - Inserire all'inizio di `processBlock()` la guardia RAII:
     ```cpp
     juce::ScopedNoDenormals noDenormals;
     ```
   - Tutti i filtri IIR di soppressione non devono decadere all'infinito sotto la soglia di denormale ($1.0 \times 10^{-15}$).

5. **PROTEZIONE TOTALE DA NAN E DIVISIONI PER ZERO:**
   - Tutte le conversioni logaritmiche di guadagno ($20 \log_{10}$) e i calcoli differenziali spettrali devono possedere un epsilon di salvaguardia ($\epsilon \ge 1.0 \times 10^{-5}$):
     ```cpp
     const float db = 20.0f * std::log10(std::max(magnitude, 1.0e-5f));
     ```

6. **DISSOLVENZA INCROCIATA BYPASS POP-FREE (15 ms):**
   - L'attivazione/disattivazione del Bypass Master o del Delta Listen deve avvenire tramite crossfade lineare continuo a campione singolo governato da `juce::SmoothedValue<float>` con tempo di rampa a $15\text{ ms}$.
