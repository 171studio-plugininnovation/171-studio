# Modulo 02: Rilevamento ed Eliminazione Dinamica delle Risonanze
**Plugin:** 171CleanReso (Dynamic Resonance Suppressor)  
**Standard:** Pro Audio Spectral Processing & Mastering-Grade Fidelity

---

## 1. La Catena di Elaborazione Spettrale (Signal Flow)

```
[Audio In L/R] ----------------------------------------------+
      |                                                      |
      v                                                      |
[1. Stereo-Coupled Transient Splitter]                       |
      | (Inviluppo massimo condiviso L/R: zero stereo yaw)   |
      v                                                      |
[2. Spectral Analysis Engine (32 Bande Logaritmiche)]        |
      | (Integratori trapezoidali a 64-bit ZDF)              |
      v                                                      |
[3. Gaussian-Smoothed Spectral Baseline Engine]              |
      | (Kernel d'inviluppo macro +-3 bande: cattura sia     |
      |  sibilanti estese 4-8 kHz che risonanze strette)     |
      v                                                      |
[4. Psychoacoustic ISO 226 Sensitivity Curve]                |
      | (Ponderazione acustica del canale auricolare 2.5-6k) |
      v                                                      |
[5. Dynamic Notch ZDF SVF Array (Andy Simper / Cytomic)] <---+ (Audio Path)
      | (Calibrazione esatta: y = in + (A - 1) * (2*R*bp))
      v
[6. Delta / Difference Processor] ---> Segnale Delta: (In_aligned - Out)
      |
      v
[7. Neve Silk Red & High-Air Baxandall 2nd-Order Shelf]
      | (Armonica pari 2ª per velluto analogico + shelf 12 kHz a fase pulita)
      v
[8. True-Peak Limiter (ITU-R BS.1770-4 4x Polyphase Lookahead)]
      | (Protezione ISP deterministica a -0.10 dBTP e latency compensation)
      v
[9. Master Bypass Bit-Exact Latency-Aligned]
      | (Crossfade 15 ms pop-free su dry ritardato di 4 campioni)
      v
[Audio Out L/R]
```

---

## 2. Metodologia Scientifica di Rilevamento

### Il Problema del Confronto a 3 Punti Locali e la Soluzione
Un difetto classico dei rilevatori ingenui è il calcolo `baseline = 0.5 * (band[k-1] + band[k+1])`. Tale operatore agisce come derivata seconda discreta, azzerandosi completamente su plateaux ampi di sibilanza vocale (4-8 kHz) o di piatti aspri.

In **171CleanReso**, l'inviluppo di riferimento è calcolato mediante **lisciamento gaussiano ad ampia finestra ($\pm 3$ bande logaritmiche, oltre 1.5 ottave)**:
$$B[k] = \frac{\sum_{m=-3}^{3} w_m \cdot M[\text{clamp}(k+m, 0, N-1)]}{\sum_{m=-3}^{3} w_m}$$
dove $w_m = \exp\left(-\frac{m^2}{2 \sigma^2}\right)$, modulato dal parametro `Selectivity`.
* **Selectivity Bassa:** La finestra si allarga ($\sigma \approx 2.4$), identificando le ampie stridenze vocali e la sibilanza diffusa.
* **Selectivity Alta:** La finestra si stringe ($\sigma \approx 1.6$), isolando fischi singoli e risonanze acustiche a $Q$ elevato.

### Calibrazione ZDF Bell/Cut Esatta
Per evitare sovra-tagli causati dal guadagno di risonanza del bandpass ($Q = 1/(2R)$), ogni stadio applica l'equazione canonica Cytomic ZDF:
$$y[n] = x[n] + (A - 1.0) \cdot (2 R \cdot bp[n])$$
dove $A = 10^{-\text{GR}_{\text{dB}} / 20}$. A risonanza, $|2 R \cdot bp| = 1.0$, garantendo un'attenuazione perfettamente calibrata al decimo di dB senza distorsione di fase o inversioni.
