#pragma once
#include <cmath>
#include <algorithm>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>

namespace dsp171 {

// =============================================================================
// Stadio di Lucidatura Analogica "Silk & Air"
// 1. High-Air Shelf ZDF a 64-bit del 2° ordine (12 kHz, Q = 0.58, ultra-trasparente).
//    Garantisce una risposta piatta e intatta nella fascia di presenza 1-5 kHz,
//    evitando qualsiasi rigonfiamento di quadratura o contaminazione del lavoro di de-harshing.
// 2. Saturazione Armonica Ispirata al Circuito "Neve Silk Red":
//    Emulazione Class-A discreta a singolo stadio con generazione dominante di armoniche pari
//    (2ª armonica di calore e lucentezza valvolare/trasformatore) e soft compressione di 3ª armonica.
//    Filtro DC-Blocker ZDF a 5 Hz per eliminare qualsiasi offset continuo dall'asimmetria pari.
// =============================================================================
class AnalogSilkStage {
public:
    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);
        updateCoefficients();
        reset();
    }

    void reset() noexcept {
        s1 = 0.0;
        s2 = 0.0;
        dcState = 0.0f;
    }

    // silk varia da 0.0 a 1.0
    inline float processSample(float in, float silk) noexcept {
        if (!std::isfinite(in)) in = 0.0f;
        if (silk < 0.005f) return in;

        // 1. Neve/Baxandall 2nd-order High-Air Shelf a 12 kHz (Q = 0.58, pendenza vellutata)
        const float shelfGainDb = silk * 3.0f; // fino a +3.0 dB di aria analogica naturale
        const double G_lin = static_cast<double>(dsp171::fastDbToLinear(shelfGainDb));
        const double A = std::sqrt(G_lin);

        // Pre-warping frequenziale e compensazione di forma dello shelf Cytomic
        const double g_shelf = baseG / std::sqrt(A);
        constexpr double Q_shelf = 0.58;
        const double R_shelf = 1.0 / (2.0 * Q_shelf);
        const double denom = 1.0 + 2.0 * R_shelf * g_shelf + g_shelf * g_shelf;
        const double invDenom = 1.0 / denom;

        const double inD = static_cast<double>(in);
        const double hp = (inD - (2.0 * R_shelf + g_shelf) * s1 - s2) * invDenom;
        const double bp = g_shelf * hp + s1;
        const double lp = g_shelf * bp + s2;
        s1 = 2.0 * bp - s1;
        s2 = 2.0 * lp - s2;
        if (std::abs(s1) < 1.0e-25) s1 = 0.0;
        if (std::abs(s2) < 1.0e-25) s2 = 0.0;

        // High shelf: lp + 2*R*A*bp + A^2*hp
        const double shelvedD = lp + (2.0 * R_shelf * A) * bp + (A * A) * hp;
        const float shelved = static_cast<float>(shelvedD);

        // 2. Neve Silk Red: Generazione armonica Class-A pura
        // 2ª armonica dominante (sheen / velluto) + lieve 3ª compressione con protezione foldover
        const float k2 = 0.18f * silk;
        const float k3 = 0.05f * silk;
        const float sBounded = std::clamp(shelved, -2.5f, 2.5f);
        const float sat = sBounded + k2 * (sBounded * sBounded) - k3 * (sBounded * sBounded * sBounded);

        // DC-Blocker ZDF a ~5 Hz per rimozione dell'offset generato dall'asimmetria pari
        dcState += alphaDC * (sat - dcState);
        if (std::abs(dcState) < 1.0e-25f) dcState = 0.0f;
        const float outSat = sat - dcState;

        const float blend = silk * 0.45f;
        return (1.0f - blend) * shelved + blend * outSat;
    }

private:
    void updateCoefficients() noexcept {
        if (sr <= 0.0f) sr = 44100.0f;
        const double fc = std::min(12000.0, static_cast<double>(sr) * 0.45);
        const double wd = 2.0 * 3.14159265358979323846 * fc;
        const double T = 1.0 / static_cast<double>(sr);
        baseG = (2.0 / T) * std::tan(wd * T * 0.5) * T * 0.5;

        // DC blocker a ~5 Hz
        alphaDC = 1.0f - std::exp(-2.0f * 3.14159265358979323846f * 5.0f / sr);
    }

    float sr = 44100.0f;
    double baseG = 0.5;
    double s1 = 0.0;
    double s2 = 0.0;
    float dcState = 0.0f;
    float alphaDC = 0.001f;
};

} // namespace dsp171
