#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <dsp171/LockFreeFIFO.h>
#include <BinaryData.h>

namespace gui171 {

// Visualizzatore Spettrale Vettoriale 60 FPS con Doppia Curva (Input FFT & Gain Reduction Dips)
class SpectralResoVisualizer : public juce::Component {
public:
    SpectralResoVisualizer() {
        setOpaque(false);
        smoothedInSpectrum.fill(0.0f);
        smoothedGRSpectrum.fill(0.0f);
    }

    ~SpectralResoVisualizer() override = default;

    void updateFrame(const dsp171::ResoVisualFrame& frame, bool hasData) noexcept {
        if (hasData) {
            for (size_t k = 0; k < dsp171::ResoVisualFrame::NumBands; ++k) {
                smoothedInSpectrum[k] += 0.35f * (frame.inSpectrum[k] - smoothedInSpectrum[k]);
                smoothedGRSpectrum[k] += 0.40f * (frame.grSpectrum[k] - smoothedGRSpectrum[k]);
            }
            peakResoHz = frame.peakResoHz;
            maxReductionDb = frame.maxReductionDb;
            transActivity += 0.30f * (frame.transientActivity - transActivity);
        } else {
            for (size_t k = 0; k < dsp171::ResoVisualFrame::NumBands; ++k) {
                smoothedInSpectrum[k] *= 0.92f;
                smoothedGRSpectrum[k] *= 0.88f;
            }
            maxReductionDb *= 0.88f;
            transActivity *= 0.85f;
        }

        repaint();
    }

    void paint(juce::Graphics& g) override {
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());

        // 1. Sfondo scuro CRT con riflesso satinato
        g.setColour(juce::Colour(0xd40c0e12));
        g.fillRoundedRectangle(0.0f, 0.0f, w, h, 6.0f);

        // 1b. Translucent 171 Studio Logo Watermark in background behind CRT display
        auto logoWatermark = juce::ImageCache::getFromMemory(BinaryData::logo_171_gold_png, BinaryData::logo_171_gold_pngSize);
        if (logoWatermark.isValid()) {
            const float logoW = juce::jmin(w * 0.28f, 190.0f);
            const float logoH = logoW * (static_cast<float>(logoWatermark.getHeight()) / static_cast<float>(logoWatermark.getWidth()));
            auto logoRect = juce::Rectangle<float>((w - logoW) * 0.5f, (h - logoH) * 0.5f, logoW, logoH);
            g.setOpacity(0.09f); // Translucent watermark strictly behind grid and curves
            g.drawImage(logoWatermark, logoRect, juce::RectanglePlacement::centred);
            g.setOpacity(1.0f);
        }

        // 2. Griglia di misura spettrale a linee sottili
        g.setColour(juce::Colour(0x1ec59c52));
        constexpr int numGridLines = 5;
        for (int i = 1; i <= numGridLines; ++i) {
            const float y = h * (static_cast<float>(i) / static_cast<float>(numGridLines + 1));
            g.drawHorizontalLine(static_cast<int>(y), 8.0f, w - 8.0f);
        }

        // Griglia verticale logaritmica (frequenze chiave: 100 Hz, 500 Hz, 1 kHz, 2.5 kHz, 5 kHz, 10 kHz)
        constexpr float freqs[] = { 100.0f, 500.0f, 1000.0f, 2500.0f, 5000.0f, 10000.0f };
        constexpr float fMin = 40.0f;
        constexpr float fMax = 16000.0f;
        g.setFont(juce::FontOptions(9.5f, juce::Font::plain));

        for (float f : freqs) {
            const float normX = std::log(f / fMin) / std::log(fMax / fMin);
            const float x = 16.0f + normX * (w - 32.0f);

            g.setColour(juce::Colour(0x18c59c52));
            g.drawVerticalLine(static_cast<int>(x), 8.0f, h - 14.0f);

            g.setColour(juce::Colour(0x55ffe099));
            juce::String label = (f >= 1000.0f) ? juce::String(f / 1000.0f, 1) + "k" : juce::String(static_cast<int>(f));
            g.drawText(label, static_cast<int>(x - 16.0f), static_cast<int>(h - 15.0f), 32, 12, juce::Justification::centred, false);
        }

        // 3. CURVA 1: Spettro Audio in Ingresso (FFT Spectrum)
        juce::Path inPath;
        const float baseY = h * 0.85f;
        const size_t nBands = dsp171::ResoVisualFrame::NumBands;

        for (size_t k = 0; k < nBands; ++k) {
            const float normX = static_cast<float>(k) / static_cast<float>(nBands - 1);
            const float x = 16.0f + normX * (w - 32.0f);
            const float y = baseY - smoothedInSpectrum[k] * (h * 0.65f);

            if (k == 0) inPath.startNewSubPath(x, y);
            else inPath.lineTo(x, y);
        }

        // Sfumatura di riempimento sottostante lo spettro
        juce::Path fillPath = inPath;
        fillPath.lineTo(w - 16.0f, baseY);
        fillPath.lineTo(16.0f, baseY);
        fillPath.closeSubPath();

        juce::ColourGradient fillGrad(juce::Colour(0x3800d2ff), 0.0f, h * 0.2f,
                                     juce::Colour(0x0400d2ff), 0.0f, baseY, false);
        g.setGradientFill(fillGrad);
        g.fillPath(fillPath);

        // Traccia neon azzurro ciano dello spettro
        g.setColour(juce::Colour(0x4000d2ff));
        g.strokePath(inPath, juce::PathStrokeType(5.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        g.setColour(juce::Colour(0xff80e5ff));
        g.strokePath(inPath, juce::PathStrokeType(1.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // 4. CURVA 2: Curva Dinamica di Gain Reduction (Curve Dips verso il basso)
        juce::Path grPath;
        const float grBaselineY = h * 0.14f;

        for (size_t k = 0; k < nBands; ++k) {
            const float normX = static_cast<float>(k) / static_cast<float>(nBands - 1);
            const float x = 16.0f + normX * (w - 32.0f);
            // I dip scendono verso il basso proporzionalmente alla riduzione in dB
            const float dip = smoothedGRSpectrum[k] * (h * 0.52f);
            const float y = grBaselineY + dip;

            if (k == 0) grPath.startNewSubPath(x, y);
            else grPath.lineTo(x, y);
        }

        // Linea base orizzontale a 0 dB GR
        g.setColour(juce::Colour(0x30ff453a));
        g.drawHorizontalLine(static_cast<int>(grBaselineY), 16.0f, w - 16.0f);

        // Alone al neon rosso/arancione per la Gain Reduction
        g.setColour(juce::Colour(0x30ff453a));
        g.strokePath(grPath, juce::PathStrokeType(7.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        g.setColour(juce::Colour(0xb0ff5e3a));
        g.strokePath(grPath, juce::PathStrokeType(3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        g.setColour(juce::Colour(0xffffffff));
        g.strokePath(grPath, juce::PathStrokeType(1.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // 5. BOX READOUT DIGITALE IN ALTO A DESTRA
        const float boxW = 160.0f;
        const float boxH = 42.0f;
        const float boxX = w - boxW - 14.0f;
        const float boxY = 10.0f;

        g.setColour(juce::Colour(0xee0e1014));
        g.fillRoundedRectangle(boxX, boxY, boxW, boxH, 4.0f);
        g.setColour(juce::Colour(0x70c59c52));
        g.drawRoundedRectangle(boxX, boxY, boxW, boxH, 4.0f, 1.0f);

        // Testo Readout
        g.setFont(juce::FontOptions(9.5f, juce::Font::bold));
        g.setColour(juce::Colour(0xff8e96a0));
        g.drawText("PEAK RESO:", static_cast<int>(boxX + 8.0f), static_cast<int>(boxY + 4.0f), 74, 16, juce::Justification::left, false);
        g.drawText("MAX GR:",    static_cast<int>(boxX + 8.0f), static_cast<int>(boxY + 22.0f), 74, 16, juce::Justification::left, false);

        g.setFont(juce::FontOptions(10.5f, juce::Font::bold));
        juce::String hzStr = (peakResoHz >= 1000.0f) ? juce::String(peakResoHz / 1000.0f, 2) + " kHz" : juce::String(static_cast<int>(peakResoHz)) + " Hz";
        g.setColour(juce::Colour(0xffff9f0a));
        g.drawText(hzStr, static_cast<int>(boxX + 78.0f), static_cast<int>(boxY + 4.0f), 74, 16, juce::Justification::right, false);

        juce::String grStr = "-" + juce::String(maxReductionDb, 1) + " dB";
        g.setColour(juce::Colour(0xffff453a));
        g.drawText(grStr, static_cast<int>(boxX + 78.0f), static_cast<int>(boxY + 22.0f), 74, 16, juce::Justification::right, false);

        // 6. BADGE "TRANSIENT SHIELD ACTIVE" IN ALTO A SINISTRA
        if (transActivity > 0.08f) {
            const float badgeW = 142.0f;
            const float badgeH = 20.0f;
            const float badgeX = 14.0f;
            const float badgeY = 10.0f;

            const float glowAlpha = std::min(1.0f, transActivity * 1.8f);
            g.setColour(juce::Colour(0x00e676).withAlpha(glowAlpha * 0.25f));
            g.fillRoundedRectangle(badgeX, badgeY, badgeW, badgeH, 4.0f);
            g.setColour(juce::Colour(0x00e676).withAlpha(glowAlpha));
            g.drawRoundedRectangle(badgeX, badgeY, badgeW, badgeH, 4.0f, 1.2f);

            // LED dot verde
            g.fillEllipse(badgeX + 7.0f, badgeY + 5.0f, 9.0f, 9.0f);

            g.setFont(juce::FontOptions(9.0f, juce::Font::bold));
            g.setColour(juce::Colour(0xffe0ffed));
            g.drawText("TRANSIENT SHIELD", static_cast<int>(badgeX + 20.0f), static_cast<int>(badgeY), static_cast<int>(badgeW - 22.0f), static_cast<int>(badgeH), juce::Justification::centredLeft, false);
        }
    }

private:
    std::array<float, dsp171::ResoVisualFrame::NumBands> smoothedInSpectrum{};
    std::array<float, dsp171::ResoVisualFrame::NumBands> smoothedGRSpectrum{};

    float peakResoHz = 1000.0f;
    float maxReductionDb = 0.0f;
    float transActivity = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SpectralResoVisualizer)
};

} // namespace gui171
