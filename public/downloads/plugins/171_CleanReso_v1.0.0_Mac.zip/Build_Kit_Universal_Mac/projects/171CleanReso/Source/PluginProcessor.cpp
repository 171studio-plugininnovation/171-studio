#include "PluginProcessor.h"
#include "PluginEditor.h"

const std::vector<PluginPreset>& AudioPluginAudioProcessor::getFactoryPresets() {
    static const std::vector<PluginPreset> presets = {
        { "01 | Vocal De-Harsh & Sibilance", 0.55f, 6500.0f, 0.60f, 0.65f, 0.35f, 1.00f,  0.0f },
        { "02 | Snare Ring & Harsh Kill",    0.65f, 3200.0f, 0.65f, 0.85f, 0.15f, 1.00f, -0.2f },
        { "03 | Acoustic Guitar Resonance",  0.50f, 2800.0f, 0.55f, 0.60f, 0.30f, 1.00f,  0.0f },
        { "04 | Harsh Hi-Hats & Cymbals",    0.60f, 8500.0f, 0.50f, 0.75f, 0.20f, 0.85f, -0.4f },
        { "05 | Master Bus Harshness Tamer", 0.35f, 4200.0f, 0.45f, 0.70f, 0.20f, 1.00f,  0.0f },
        { "06 | Electric Guitar Fizz Cut",   0.55f, 3800.0f, 0.55f, 0.50f, 0.10f, 1.00f, -0.2f },
        { "07 | Sibilance Clamp (De-Esser)", 0.70f, 7200.0f, 0.70f, 0.60f, 0.25f, 1.00f,  0.0f },
        { "08 | Surgical Resonance Hunter",  0.75f, 5000.0f, 0.85f, 0.65f, 0.00f, 1.00f, -0.5f }
    };
    return presets;
}

AudioPluginAudioProcessor::AudioPluginAudioProcessor()
    : AudioProcessor(BusesProperties()
                     .withInput("Input", juce::AudioChannelSet::stereo(), true)
                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "Parameters", createParameterLayout())
{
    depthParam       = apvts.getRawParameterValue("depth");
    sharpnessParam   = apvts.getRawParameterValue("sharpness");
    selectivityParam = apvts.getRawParameterValue("selectivity");
    transShieldParam = apvts.getRawParameterValue("trans_shield");
    silkParam        = apvts.getRawParameterValue("silk");
    mixParam         = apvts.getRawParameterValue("mix");
    outGainParam     = apvts.getRawParameterValue("out_gain");
    deltaParam       = apvts.getRawParameterValue("delta_listen");
    bypassParam      = apvts.getRawParameterValue("bypass");
    modeHardParam    = apvts.getRawParameterValue("mode_hard");
}

AudioPluginAudioProcessor::~AudioPluginAudioProcessor() = default;

juce::AudioProcessorValueTreeState::ParameterLayout AudioPluginAudioProcessor::createParameterLayout() {
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"depth", 1}, "De-Harsh Depth",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.50f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"sharpness", 1}, "Target Freq",
        juce::NormalisableRange<float>(1000.0f, 12000.0f, 10.0f, 0.45f), 4500.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"selectivity", 1}, "Selectivity",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.50f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"trans_shield", 1}, "Transient Shield",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.65f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"silk", 1}, "Analog Silk",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.25f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"mix", 1}, "Mix",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 1.00f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"out_gain", 1}, "Output",
        juce::NormalisableRange<float>(-18.0f, 12.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"delta_listen", 1}, "Delta Listen", false));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"bypass", 1}, "Bypass", false));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"mode_hard", 1}, "Mode Hard", false));

    return { params.begin(), params.end() };
}

int AudioPluginAudioProcessor::getNumPrograms() {
    return static_cast<int>(getFactoryPresets().size());
}

int AudioPluginAudioProcessor::getCurrentProgram() {
    return currentProgramIndex;
}

void AudioPluginAudioProcessor::setCurrentProgram(int index) {
    const auto& presets = getFactoryPresets();
    if (index >= 0 && index < static_cast<int>(presets.size())) {
        currentProgramIndex = index;
        const auto& p = presets[static_cast<size_t>(index)];

        if (auto* param = apvts.getParameter("depth"))        param->setValueNotifyingHost(param->convertTo0to1(p.depth));
        if (auto* param = apvts.getParameter("sharpness"))    param->setValueNotifyingHost(param->convertTo0to1(p.sharpness));
        if (auto* param = apvts.getParameter("selectivity"))  param->setValueNotifyingHost(param->convertTo0to1(p.selectivity));
        if (auto* param = apvts.getParameter("trans_shield")) param->setValueNotifyingHost(param->convertTo0to1(p.transShield));
        if (auto* param = apvts.getParameter("silk"))         param->setValueNotifyingHost(param->convertTo0to1(p.silk));
        if (auto* param = apvts.getParameter("mix"))          param->setValueNotifyingHost(param->convertTo0to1(p.mix));
        if (auto* param = apvts.getParameter("out_gain"))     param->setValueNotifyingHost(param->convertTo0to1(p.outGain));
    }
}

const juce::String AudioPluginAudioProcessor::getProgramName(int index) {
    const auto& presets = getFactoryPresets();
    if (index >= 0 && index < static_cast<int>(presets.size())) {
        return presets[static_cast<size_t>(index)].name;
    }
    return {};
}

void AudioPluginAudioProcessor::changeProgramName(int, const juce::String&) {}

void AudioPluginAudioProcessor::prepareToPlay(double sampleRate, int /*samplesPerBlock*/) {
    setLatencySamples(static_cast<int>(dsp171::TruePeakLimiter::LookaheadLatency));
    for (size_t ch = 0; ch < MaxChannels; ++ch) {
        resoEngines[ch].prepare(sampleRate);
        silkStages[ch].prepare(sampleRate);
        truePeakLimiters[ch].prepare(sampleRate);
    }
    latencyBypass.reset();

    constexpr double rampTimeSec = 0.020;
    smoothedDepth.reset(sampleRate, rampTimeSec);
    smoothedSharpness.reset(sampleRate, rampTimeSec);
    smoothedSelectivity.reset(sampleRate, rampTimeSec);
    smoothedTransShield.reset(sampleRate, rampTimeSec);
    smoothedSilk.reset(sampleRate, rampTimeSec);
    smoothedMix.reset(sampleRate, rampTimeSec);
    smoothedOutGain.reset(sampleRate, rampTimeSec);
    smoothedDelta.reset(sampleRate, 0.015);
    smoothedBypass.reset(sampleRate, 0.015);
}

void AudioPluginAudioProcessor::releaseResources() {
    for (size_t ch = 0; ch < MaxChannels; ++ch) {
        resoEngines[ch].reset();
        silkStages[ch].reset();
        truePeakLimiters[ch].reset();
    }
    latencyBypass.reset();
}

bool AudioPluginAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const {
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo()) {
        return false;
    }
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet()) {
        return false;
    }
    return true;
}

void AudioPluginAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& /*midiMessages*/) {
    juce::ScopedNoDenormals noDenormals;

    const int numSamples = buffer.getNumSamples();
    const int numChannels = buffer.getNumChannels();

    if (numSamples == 0 || numChannels == 0) return;

    // Aggiornamento target dei parametri
    smoothedDepth.setTargetValue(depthParam->load(std::memory_order_relaxed));
    smoothedSharpness.setTargetValue(sharpnessParam->load(std::memory_order_relaxed));
    smoothedSelectivity.setTargetValue(selectivityParam->load(std::memory_order_relaxed));
    smoothedTransShield.setTargetValue(transShieldParam->load(std::memory_order_relaxed));
    smoothedSilk.setTargetValue(silkParam->load(std::memory_order_relaxed));
    smoothedMix.setTargetValue(mixParam->load(std::memory_order_relaxed));

    const float outGainLin = dsp171::fastDbToLinear(outGainParam->load(std::memory_order_relaxed));
    smoothedOutGain.setTargetValue(outGainLin);

    const bool isDeltaOn = deltaParam->load(std::memory_order_relaxed) > 0.5f;
    smoothedDelta.setTargetValue(isDeltaOn ? 1.0f : 0.0f);

    const bool isBypassed = bypassParam->load(std::memory_order_relaxed) > 0.5f;
    smoothedBypass.setTargetValue(isBypassed ? 1.0f : 0.0f);

    const bool isHardMode = modeHardParam != nullptr && modeHardParam->load(std::memory_order_relaxed) > 0.5f;

    std::array<float, 2> outSumSq = { 0.0f, 0.0f };
    std::array<float, 2> peakOut  = { 0.0f, 0.0f };

    if (numChannels >= 2) {
        float* channelDataL = buffer.getWritePointer(0);
        float* channelDataR = buffer.getWritePointer(1);

        for (int i = 0; i < numSamples; ++i) {
            const float curDepth       = smoothedDepth.getNextValue();
            const float curSharpness   = smoothedSharpness.getNextValue();
            const float curSelectivity = smoothedSelectivity.getNextValue();
            const float curTransShield = smoothedTransShield.getNextValue();
            const float curSilk        = smoothedSilk.getNextValue();
            const float curMix         = smoothedMix.getNextValue();
            const float curOutGain     = smoothedOutGain.getNextValue();
            const float curDeltaSmooth = smoothedDelta.getNextValue();
            const float curBypass      = smoothedBypass.getNextValue();

            const float dryL = channelDataL[i];
            const float dryR = channelDataR[i];

            // Memorizzazione campione dry per compensazione bit-exact della latenza
            latencyBypass.pushDrySample(0, dryL);
            latencyBypass.pushDrySample(1, dryR);
            latencyBypass.advanceWriteIndex();

            const float alignedDryL = latencyBypass.getAlignedDrySample(0, dsp171::TruePeakLimiter::LookaheadLatency);
            const float alignedDryR = latencyBypass.getAlignedDrySample(1, dsp171::TruePeakLimiter::LookaheadLatency);

            // 1. Motore Spettrale Dinamico Stereo-Linked (Zero Phantom-Center Yawing)
            float cleanedL = dryL;
            float cleanedR = dryR;
            dsp171::DynamicResonanceEngine::processStereoPair(
                resoEngines[0], resoEngines[1],
                dryL, dryR, cleanedL, cleanedR,
                curDepth, curSharpness, curSelectivity, curTransShield, curDeltaSmooth, isHardMode, 1.0f);

            // 2. Stadio di Lucidatura Analogica "Silk & Air" (Bypassato in Delta Listen puro)
            const float effSilk = curSilk * (1.0f - curDeltaSmooth);
            const float polishedL = silkStages[0].processSample(cleanedL, effSilk);
            const float polishedR = silkStages[1].processSample(cleanedR, effSilk);

            // 3. Blending Dry / Wet e Gain Trim (se Delta attivo, mix 100% per ascolto puro)
            const float effMix = curDeltaSmooth > 0.01f ? 1.0f : curMix;
            const float wetRawL = ((dryL * (1.0f - effMix)) + (polishedL * effMix)) * curOutGain;
            const float wetRawR = ((dryR * (1.0f - effMix)) + (polishedR * effMix)) * curOutGain;

            // 4. True-Peak Lookahead Limiter Conforme a ITU-R BS.1770-4 (-0.10 dBTP)
            float safeL = wetRawL;
            float safeR = wetRawR;
            dsp171::TruePeakLimiter::processStereoPair(
                truePeakLimiters[0], truePeakLimiters[1],
                wetRawL, wetRawR, safeL, safeR, -0.10f);

            // 5. Crossfade continuo con Master Bypass a latenza allineata bit-exact (zero sfasamenti flanger)
            const float finalL = (safeL * (1.0f - curBypass)) + (alignedDryL * curBypass);
            const float finalR = (safeR * (1.0f - curBypass)) + (alignedDryR * curBypass);

            channelDataL[i] = finalL;
            channelDataR[i] = finalR;

            outSumSq[0] += finalL * finalL;
            outSumSq[1] += finalR * finalR;
            const float aL = std::abs(finalL);
            const float aR = std::abs(finalR);
            if (aL > peakOut[0]) peakOut[0] = aL;
            if (aR > peakOut[1]) peakOut[1] = aR;
        }
    } else {
        float* channelData = buffer.getWritePointer(0);

        for (int i = 0; i < numSamples; ++i) {
            const float curDepth       = smoothedDepth.getNextValue();
            const float curSharpness   = smoothedSharpness.getNextValue();
            const float curSelectivity = smoothedSelectivity.getNextValue();
            const float curTransShield = smoothedTransShield.getNextValue();
            const float curSilk        = smoothedSilk.getNextValue();
            const float curMix         = smoothedMix.getNextValue();
            const float curOutGain     = smoothedOutGain.getNextValue();
            const float curDeltaSmooth = smoothedDelta.getNextValue();
            const float curBypass      = smoothedBypass.getNextValue();

            const float dry = channelData[i];

            latencyBypass.pushDrySample(0, dry);
            latencyBypass.advanceWriteIndex();
            const float alignedDry = latencyBypass.getAlignedDrySample(0, dsp171::TruePeakLimiter::LookaheadLatency);

            // 1. Motore Mono
            const float cleaned = resoEngines[0].processSample(
                dry, curDepth, curSharpness, curSelectivity, curTransShield, curDeltaSmooth, isHardMode);

            // 2. Silk Stage (Bypassato in Delta Listen puro)
            const float effSilk = curSilk * (1.0f - curDeltaSmooth);
            const float polished = silkStages[0].processSample(cleaned, effSilk);

            // 3. Dry/Wet
            const float effMix = curDeltaSmooth > 0.01f ? 1.0f : curMix;
            const float wetRaw = ((dry * (1.0f - effMix)) + (polished * effMix)) * curOutGain;

            // 4. True-Peak Limiter Conforme ITU-R BS.1770-4
            const float safe = truePeakLimiters[0].processSample(wetRaw, -0.10f);

            // 5. Bypass a latenza allineata
            const float finalSample = (safe * (1.0f - curBypass)) + (alignedDry * curBypass);
            channelData[i] = finalSample;

            outSumSq[0] += finalSample * finalSample;
            const float a = std::abs(finalSample);
            if (a > peakOut[0]) peakOut[0] = a;
        }
    }

    // Preparazione e invio frame visuale alla GUI
    dsp171::ResoVisualFrame frame;
    dsp171::DynamicResonanceEngine::FrameStats stats;
    resoEngines[0].fillVisualStats(stats);

    frame.inSpectrum        = stats.inSpectrum;
    frame.grSpectrum        = stats.grSpectrum;
    frame.peakResoHz        = stats.peakResoHz;
    frame.maxReductionDb    = stats.maxGRDb;
    frame.transientActivity = stats.transientActivity;

    frame.outRMS_L = std::sqrt(outSumSq[0] / static_cast<float>(numSamples));
    frame.outRMS_R = numChannels > 1 ? std::sqrt(outSumSq[1] / static_cast<float>(numSamples)) : frame.outRMS_L;
    frame.peak_L   = peakOut[0];
    frame.peak_R   = numChannels > 1 ? peakOut[1] : frame.peak_L;

    visualFIFO.push(frame);
}

juce::AudioProcessorEditor* AudioPluginAudioProcessor::createEditor() {
    return new AudioPluginAudioProcessorEditor(*this);
}

void AudioPluginAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    auto state = apvts.copyState();
    state.setProperty("version", 1, nullptr);
    state.setProperty("currentPreset", currentProgramIndex, nullptr);
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void AudioPluginAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType())) {
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
        currentProgramIndex = apvts.state.getProperty("currentPreset", 0);
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new AudioPluginAudioProcessor();
}
