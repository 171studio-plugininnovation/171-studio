#pragma once
#include <juce_gui_basics/juce_gui_basics.h>

namespace gui171 {

class PhotorealisticNeonKnobLookAndFeel : public juce::LookAndFeel_V4 {
public:
    PhotorealisticNeonKnobLookAndFeel(juce::Colour neonCol, juce::Image knobCapImg)
        : neonColor(neonCol), knobCap(knobCapImg) {}

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPosProportional, float rotaryStartAngle,
                          float rotaryEndAngle, juce::Slider&) override
    {
        const float radius = static_cast<float>(juce::jmin(width / 2, height / 2)) - 9.0f;
        const float centreX = static_cast<float>(x + width / 2);
        const float centreY = static_cast<float>(y + height / 2);
        const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

        const float arcRadius = radius + 4.5f;

        // 1. Traccia scura circolare incassata
        juce::Path trackBg;
        trackBg.addCentredArc(centreX, centreY, arcRadius, arcRadius, 0.0f,
                              rotaryStartAngle, rotaryEndAngle, true);
        g.setColour(juce::Colour(0x600b0c0e));
        g.strokePath(trackBg, juce::PathStrokeType(6.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // 2. EFFETTO NEON MULTI-PASS AD ALTA LUMINOSITÀ
        if (sliderPosProportional > 0.005f) {
            juce::Path activeArc;
            activeArc.addCentredArc(centreX, centreY, arcRadius, arcRadius, 0.0f,
                                    rotaryStartAngle, angle, true);

            // Pass 1: Diffusione soffusa esterna
            g.setColour(neonColor.withAlpha(0.20f));
            g.strokePath(activeArc, juce::PathStrokeType(16.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Pass 2: Alone intermedio strutturale
            g.setColour(neonColor.withAlpha(0.50f));
            g.strokePath(activeArc, juce::PathStrokeType(9.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Pass 3: Tubo neon saturo primario
            g.setColour(neonColor.withAlpha(0.95f));
            g.strokePath(activeArc, juce::PathStrokeType(4.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // Pass 4: Nucleo incandescente bianco/hot core
            g.setColour(juce::Colour(0xffffffff).withAlpha(0.85f));
            g.strokePath(activeArc, juce::PathStrokeType(1.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }

        // 3. Ombra cadente del pomello metallico
        const float capRadius = radius - 1.5f;
        g.setColour(juce::Colour(0xd0000000));
        g.fillEllipse(centreX - capRadius + 2.0f, centreY - capRadius + 3.0f, capRadius * 2.0f, capRadius * 2.0f);

        // 4. Rendering del Pomello Fotorealistico Ruotato (esattamente identico al Drive di CleanDrive)
        if (knobCap.isValid()) {
            const float scale = (capRadius * 2.0f) / static_cast<float>(knobCap.getWidth());
            auto xform = juce::AffineTransform::translation(-knobCap.getWidth() * 0.5f, -knobCap.getHeight() * 0.5f)
                            .scaled(scale)
                            .rotated(angle)
                            .translated(centreX, centreY);
            g.drawImageTransformed(knobCap, xform);
        } else {
            // Fallback vettoriale in caso di assenza immagine
            g.setColour(juce::Colour(0xff2d3035));
            g.fillEllipse(centreX - capRadius, centreY - capRadius, capRadius * 2.0f, capRadius * 2.0f);
        }
    }

private:
    juce::Colour neonColor;
    juce::Image knobCap;
};

class AnalogStyledKnob : public juce::Component {
public:
    enum class ValueFormat {
        Multiplier, // "1.30x"
        Decimal,    // "0.36"
        Percentage, // "100%"
        Decibels,   // "-1.4 dB"
        Hertz       // "4.5 kHz"
    };

    AnalogStyledKnob(const juce::String& title, juce::Colour neonColor,
                     juce::Image capImage, ValueFormat formatType,
                     float minVal = 0.0f, float maxVal = 1.0f, float defaultVal = 0.5f)
        : lookAndFeel(neonColor, capImage),
          knobTitle(title),
          titleColor(neonColor),
          valFormat(formatType)
    {
        setOpaque(false); // Trasparente

        slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        slider.setLookAndFeel(&lookAndFeel);
        slider.setRange(minVal, maxVal, 0.01);
        slider.setValue(defaultVal, juce::dontSendNotification);
        slider.setDoubleClickReturnValue(true, defaultVal);

        slider.onValueChange = [this]() {
            updateValueString();
            repaint();
        };

        addAndMakeVisible(slider);
        updateValueString();
    }

    ~AnalogStyledKnob() override {
        slider.setLookAndFeel(nullptr);
    }

    void resized() override {
        const int w = getWidth();
        const int h = getHeight();
        // Titolo in alto: 20px, Valore in basso: 22px
        slider.setBounds(0, 20, w, h - 42);
    }

    void paint(juce::Graphics& g) override {
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());

        // 1. Titolo superiore (con bagliore neon in tinta)
        g.setFont(juce::FontOptions(12.5f, juce::Font::bold));

        // Alone di testo soft
        g.setColour(titleColor.withAlpha(0.35f));
        g.drawText(knobTitle, 0, 1, static_cast<int>(w), 20, juce::Justification::centred, false);

        // Testo nitido
        g.setColour(titleColor);
        g.drawText(knobTitle, 0, 0, static_cast<int>(w), 20, juce::Justification::centred, false);

        // 2. Valore numerico inferiore (grande e luminoso)
        g.setFont(juce::FontOptions(14.0f, juce::Font::bold));

        // Alone valore soft
        g.setColour(titleColor.withAlpha(0.35f));
        g.drawText(displayValueStr, 0, static_cast<int>(h - 21), static_cast<int>(w), 22, juce::Justification::centred, false);

        // Valore nitido
        g.setColour(titleColor.brighter(0.15f));
        g.drawText(displayValueStr, 0, static_cast<int>(h - 22), static_cast<int>(w), 22, juce::Justification::centred, false);
    }

    juce::Slider& getSlider() noexcept { return slider; }

private:
    void updateValueString() {
        const double val = slider.getValue();
        switch (valFormat) {
            case ValueFormat::Multiplier:
                displayValueStr = juce::String(val, 2) + "x";
                break;
            case ValueFormat::Percentage:
                displayValueStr = juce::String(static_cast<int>(std::round(val * 100.0))) + "%";
                break;
            case ValueFormat::Decibels:
                displayValueStr = (val > 0.0 ? "+" : "") + juce::String(val, 1) + " dB";
                break;
            case ValueFormat::Hertz:
                if (val >= 1000.0)
                    displayValueStr = juce::String(val * 0.001, 1) + " kHz";
                else
                    displayValueStr = juce::String(static_cast<int>(std::round(val))) + " Hz";
                break;
            case ValueFormat::Decimal:
            default:
                displayValueStr = juce::String(val, 2);
                break;
        }
    }

    PhotorealisticNeonKnobLookAndFeel lookAndFeel;
    juce::Slider slider;
    juce::String knobTitle;
    juce::Colour titleColor;
    ValueFormat valFormat;
    juce::String displayValueStr;
};

} // namespace gui171
