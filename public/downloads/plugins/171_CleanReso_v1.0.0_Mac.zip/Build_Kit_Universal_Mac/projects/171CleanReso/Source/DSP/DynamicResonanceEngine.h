#pragma once
#include <cmath>
#include <array>
#include <algorithm>
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include <dsp171/TransientSplitter.h>

namespace dsp171 {

// =============================================================================
// Motore Spettrale Dinamico di Soppressione delle Risonanze ad Alta Risoluzione
// Topologia ZDF SVF Cytomic a 64-bit, baseline spettrale a smoothing gaussiano
// psicoacustico, ponderazione ISO 226 equal-loudness del canale auricolare,
// TransientShield sub-millisecond stereo-coupled coerente dei transienti
// e zero chiamate trascendenti pesanti nel ciclo di elaborazione audio.
// =============================================================================
class DynamicResonanceEngine {
public:
    static constexpr size_t NumBands = 32;

    void prepare(double sampleRate) noexcept {
        sr = static_cast<float>(sampleRate > 0.0 ? sampleRate : 44100.0);

        transSplitter.prepare(sampleRate);

        // Calcolo delle 32 frequenze centrali logaritmiche (da 40 Hz a 16 kHz)
        constexpr float fMin = 40.0f;
        constexpr float fMax = 16000.0f;
        const float logRatio = std::log(fMax / fMin) / static_cast<float>(NumBands - 1);

        const double T = 1.0 / static_cast<double>(sr);
        firstProcessBand = NumBands;

        for (size_t k = 0; k < NumBands; ++k) {
            centerFreqs[k] = fMin * std::exp(static_cast<float>(k) * logRatio);
            logCenterFreqs[k] = std::log(centerFreqs[k]);

            const double fc = static_cast<double>(centerFreqs[k]);
            const double wd = 2.0 * 3.14159265358979323846 * fc;
            const double wa = (2.0 / T) * std::tan(wd * T * 0.5);
            baseG[k] = wa * T * 0.5;

            // Individua la prima banda di de-harshing/risonanza (>= 800 Hz)
            if (centerFreqs[k] >= 800.0f && firstProcessBand == NumBands) {
                firstProcessBand = k;
            }

            // =================================================================
            // Curva Continua di Ponderazione Psicoacustica ISO 226 (Equal-Loudness)
            // Canale uditivo umano: picco di risonanza acustica a 2.5-5.0 kHz
            // (f_c ~3.7 kHz, prominenza auricolare fino a ~1.33x),
            // attenuazione graduale verso le basse frequenze (< 1.2 kHz a ~0.80x)
            // e convergenza a 1.0x sopra 8 kHz.
            // =================================================================
            const float logFc = std::log10(std::clamp(centerFreqs[k], 40.0f, 16000.0f));
            const float dLogCanal = (logFc - 3.5682f) / 0.16f;
            const float earCanalReso = 0.33f * std::exp(-0.5f * dLogCanal * dLogCanal);

            const float lowMidAtten = 1.0f / (1.0f + std::pow(1200.0f / std::max(centerFreqs[k], 40.0f), 2.0f));
            const float baseIso = 0.80f + 0.20f * lowMidAtten;

            isoWeights[k] = baseIso + earCanalReso;
        }

        if (firstProcessBand == NumBands) {
            firstProcessBand = 16; // Fallback di sicurezza
        }

        updateBallistics(0.003f, 0.050f);
        lastTargetFreqHz = -1.0f;
        updateTargetWeights(4500.0f);
        reset();
    }

    void reset() noexcept {
        transSplitter.reset();
        for (size_t k = 0; k < NumBands; ++k) {
            fastEnv[k] = 0.0f;
            currentGRDb[k] = 0.0f;
            s1[k] = 0.0;
            s2[k] = 0.0;
            detS1[k] = 0.0;
            detS2[k] = 0.0;
        }
        peakResoHz = 4500.0f;
        maxGRDb = 0.0f;
    }

    void updateBallistics(float attackSec, float releaseSec) noexcept {
        alphaAttSoft = 1.0f - std::exp(-1.0f / (std::max(0.0005f, attackSec) * sr));
        alphaRelSoft = 1.0f - std::exp(-1.0f / (std::max(0.0050f, releaseSec) * sr));

        alphaAttHard = 1.0f - std::exp(-1.0f / (0.0015f * sr));
        alphaRelHard = 1.0f - std::exp(-1.0f / (0.0300f * sr));

        // Smoothing normalizzato al sample rate (invariante da 44.1 kHz a 192 kHz)
        grSmoothSoft = 1.0f - std::exp(-1.0f / (0.00025f * sr));
        grSmoothHard = 1.0f - std::exp(-1.0f / (0.00012f * sr));
    }

    struct FrameStats {
        std::array<float, NumBands> inSpectrum;
        std::array<float, NumBands> grSpectrum;
        float peakResoHz;
        float maxGRDb;
        float transientActivity;
    };

    // Conversione ultra-rapida da guadagno a dB (< 0.12 dB errore, zero chiamate libm std::log10, safe per NaNs)
    static inline float fastGainToDb(float g) noexcept {
        if (!std::isfinite(g) || g <= 1.0e-6f) return -120.0f;
        union { float f; uint32_t i; } u = { g };
        const int exp = static_cast<int>((u.i >> 23) & 0xFF) - 127;
        u.i = (u.i & 0x007FFFFF) | 0x3F800000; // normalizzato in [1.0, 2.0)
        const float m = u.f - 1.0f;
        const float log2Val = static_cast<float>(exp) + m * (1.442695f - 0.442695f * m);
        return log2Val * 6.020599913279624f; // 20 * log10(2)
    }

    // Processamento Mono Singolo Canale
    inline float processSample(float in, float depth, float targetFreqHz, float selectivity,
                                float transShield, float curDeltaSmooth, bool hardMode = false) noexcept
    {
        if (!std::isfinite(in)) in = 0.0f;
        updateTargetWeights(targetFreqHz);

        auto split = transSplitter.processSample(in);
        const float transRatio = split.transientRatio;

        const float effAlphaAtt = hardMode ? alphaAttHard : alphaAttSoft;
        const float effAlphaRel = hardMode ? alphaRelHard : alphaRelSoft;
        const float grSmoothingSpeed = hardMode ? grSmoothHard : grSmoothSoft;
        const float maxCutDb    = hardMode ? 16.0f : 10.0f;
        const float depthFactor = hardMode ? 2.8f  : 2.2f;

        const double qFactor = static_cast<double>(2.0f + selectivity * 4.5f);
        const double R = 1.0 / (2.0 * qFactor); // Cytomic ZDF Damping Factor R = 1 / (2Q)

        // 1. Rilevamento energia su tutte le bande con integratori a 64-bit
        std::array<float, NumBands> logMags{};
        const double inD = static_cast<double>(in);

        for (size_t k = 0; k < NumBands; ++k) {
            const double g = baseG[k];
            const double denom = 1.0 + 2.0 * R * g + g * g;
            const double invDenom = 1.0 / denom;
            const double detHp = (inD - (2.0 * R + g) * detS1[k] - detS2[k]) * invDenom;
            const double detBp = g * detHp + detS1[k];
            const double detLp = g * detBp + detS2[k];
            detS1[k] = 2.0 * detBp - detS1[k];
            detS2[k] = 2.0 * detLp - detS2[k];

            // Anti-denormal hardware
            if (std::abs(detS1[k]) < 1.0e-25) detS1[k] = 0.0;
            if (std::abs(detS2[k]) < 1.0e-25) detS2[k] = 0.0;

            const float bandMag = static_cast<float>(std::abs(detBp));
            if (bandMag > fastEnv[k]) {
                fastEnv[k] += effAlphaAtt * (bandMag - fastEnv[k]);
            } else {
                fastEnv[k] += effAlphaRel * (bandMag - fastEnv[k]);
            }
            fastEnv[k] = std::max(fastEnv[k], 1.0e-6f);
            logMags[k] = fastGainToDb(fastEnv[k]);
        }

        // 2. Rilevamento risonanze a contrasto spettrale su baseline d'inviluppo smoothed (+-3 bande, >1.5 ottave)
        // Ponderazione Gaussiana precalcolata sui 7 tap kernel (zero chiamate std::exp ridondanti nel ciclo)
        const float thresholdDb = 1.2f + (1.0f - selectivity) * 1.5f;
        const float sigma = 2.4f - selectivity * 0.8f;
        const float invTwoSigmaSq = 1.0f / (2.0f * sigma * sigma);

        std::array<float, 7> kernelW{};
        for (int m = -3; m <= 3; ++m) {
            kernelW[m + 3] = std::exp(-static_cast<float>(m * m) * invTwoSigmaSq);
        }

        std::array<float, NumBands> baseline{};
        for (size_t k = 0; k < NumBands; ++k) {
            float wSum = 0.0f;
            float vSum = 0.0f;
            for (int m = -3; m <= 3; ++m) {
                const int idx = std::clamp(static_cast<int>(k) + m, 0, static_cast<int>(NumBands) - 1);
                const float w = kernelW[m + 3];
                vSum += logMags[idx] * w;
                wSum += w;
            }
            baseline[k] = vSum / wSum;
        }

        float currentMaxGR = 0.0f;
        float currentPeakHz = targetFreqHz;
        const float shieldFactor = std::max(0.0f, 1.0f - (transShield * transRatio * 1.25f));

        for (size_t k = 0; k < NumBands; ++k) {
            const float fc = centerFreqs[k];
            float targetAttenDb = 0.0f;

            if (k >= firstProcessBand && depth > 0.005f) {
                // ISO 226 ear sensitivity prominence weighting precalcolata
                const float isoWeight = isoWeights[k];
                const float prominenceDb = std::max(0.0f, logMags[k] - baseline[k]) * isoWeight;

                if (prominenceDb > thresholdDb) {
                    const float proxWeight = cachedProxWeights[k];
                    const float rawCutDb = (prominenceDb - thresholdDb) * (depth * depthFactor) * proxWeight;
                    targetAttenDb = std::min(maxCutDb, rawCutDb * shieldFactor);
                }
            }

            currentGRDb[k] += grSmoothingSpeed * (targetAttenDb - currentGRDb[k]);
            if (currentGRDb[k] < 1.0e-15f) currentGRDb[k] = 0.0f;

            if (currentGRDb[k] > currentMaxGR) {
                currentMaxGR = currentGRDb[k];
                currentPeakHz = fc;
            }
        }

        peakResoHz = currentPeakHz;
        maxGRDb = currentMaxGR;

        // 3. Applicazione filtri notch Cytomic ZDF a 64-bit calibrati esattamente: y = in + (A - 1) * (2*R*bp)
        double sampleProcD = inD;
        for (size_t k = firstProcessBand; k < NumBands; ++k) {
            const double g = baseG[k];
            const double denom = 1.0 + 2.0 * R * g + g * g;
            const double invDenom = 1.0 / denom;
            const double hp = (sampleProcD - (2.0 * R + g) * s1[k] - s2[k]) * invDenom;
            const double bp = g * hp + s1[k];
            const double lp = g * bp + s2[k];
            s1[k] = 2.0 * bp - s1[k];
            s2[k] = 2.0 * lp - s2[k];

            if (std::abs(s1[k]) < 1.0e-25) s1[k] = 0.0;
            if (std::abs(s2[k]) < 1.0e-25) s2[k] = 0.0;

            if (currentGRDb[k] > 0.001f) {
                const float gainLin = dsp171::fastDbToLinear(-currentGRDb[k]);
                // Taglio ZDF esatto: alla frequenza di risonanza (2*R*bp) = 1.0, garantendo guadagno esatto A
                sampleProcD += static_cast<double>(gainLin - 1.0f) * (2.0 * R * bp);
            }
        }

        const float sampleProcessed = static_cast<float>(sampleProcD);
        const float deltaSample = in - sampleProcessed;
        return (sampleProcessed * (1.0f - curDeltaSmooth)) + (deltaSample * curDeltaSmooth);
    }

    // Processamento Stereo Coerente con Stereo Linking (Zero Phantom-Center Yawing)
    static inline void processStereoPair(DynamicResonanceEngine& left, DynamicResonanceEngine& right,
                                         float inL, float inR, float& outL, float& outR,
                                         float depth, float targetFreqHz, float selectivity,
                                         float transShield, float curDeltaSmooth, bool hardMode,
                                         float stereoLink01 = 1.0f) noexcept
    {
        if (!std::isfinite(inL)) inL = 0.0f;
        if (!std::isfinite(inR)) inR = 0.0f;

        left.updateTargetWeights(targetFreqHz);
        right.updateTargetWeights(targetFreqHz);

        // Rilevamento transienti STEREO-COUPLED a inviluppo unificato per entrambi i canali
        auto split = left.transSplitter.processStereo(inL, inR);
        const float sharedTransRatio = split.transientRatio;

        const float effAlphaAtt = hardMode ? left.alphaAttHard : left.alphaAttSoft;
        const float effAlphaRel = hardMode ? left.alphaRelHard : left.alphaRelSoft;
        const float grSmoothingSpeed = hardMode ? left.grSmoothHard : left.grSmoothSoft;
        const float maxCutDb    = hardMode ? 16.0f : 10.0f;
        const float depthFactor = hardMode ? 2.8f  : 2.2f;

        const double qFactor = static_cast<double>(2.0f + selectivity * 4.5f);
        const double R = 1.0 / (2.0 * qFactor); // Cytomic ZDF Damping Factor R = 1 / (2Q)

        std::array<float, NumBands> logMagsL{};
        std::array<float, NumBands> logMagsR{};
        const double inDL = static_cast<double>(inL);
        const double inDR = static_cast<double>(inR);

        // Rilevamento per entrambi i canali con reciproco del denominatore condiviso
        for (size_t k = 0; k < NumBands; ++k) {
            const double g = left.baseG[k];
            const double denom = 1.0 + 2.0 * R * g + g * g;
            const double invDenom = 1.0 / denom;

            // Left detector
            const double detHpL = (inDL - (2.0 * R + g) * left.detS1[k] - left.detS2[k]) * invDenom;
            const double detBpL = g * detHpL + left.detS1[k];
            const double detLpL = g * detBpL + left.detS2[k];
            left.detS1[k] = 2.0 * detBpL - left.detS1[k];
            left.detS2[k] = 2.0 * detLpL - left.detS2[k];
            if (std::abs(left.detS1[k]) < 1.0e-25) left.detS1[k] = 0.0;
            if (std::abs(left.detS2[k]) < 1.0e-25) left.detS2[k] = 0.0;

            const float bandMagL = static_cast<float>(std::abs(detBpL));
            if (bandMagL > left.fastEnv[k]) {
                left.fastEnv[k] += effAlphaAtt * (bandMagL - left.fastEnv[k]);
            } else {
                left.fastEnv[k] += effAlphaRel * (bandMagL - left.fastEnv[k]);
            }
            left.fastEnv[k] = std::max(left.fastEnv[k], 1.0e-6f);
            logMagsL[k] = fastGainToDb(left.fastEnv[k]);

            // Right detector
            const double detHpR = (inDR - (2.0 * R + g) * right.detS1[k] - right.detS2[k]) * invDenom;
            const double detBpR = g * detHpR + right.detS1[k];
            const double detLpR = g * detBpR + right.detS2[k];
            right.detS1[k] = 2.0 * detBpR - right.detS1[k];
            right.detS2[k] = 2.0 * detLpR - right.detS2[k];
            if (std::abs(right.detS1[k]) < 1.0e-25) right.detS1[k] = 0.0;
            if (std::abs(right.detS2[k]) < 1.0e-25) right.detS2[k] = 0.0;

            const float bandMagR = static_cast<float>(std::abs(detBpR));
            if (bandMagR > right.fastEnv[k]) {
                right.fastEnv[k] += effAlphaAtt * (bandMagR - right.fastEnv[k]);
            } else {
                right.fastEnv[k] += effAlphaRel * (bandMagR - right.fastEnv[k]);
            }
            right.fastEnv[k] = std::max(right.fastEnv[k], 1.0e-6f);
            logMagsR[k] = fastGainToDb(right.fastEnv[k]);
        }

        const float thresholdDb = 1.2f + (1.0f - selectivity) * 1.5f;
        const float sigma = 2.4f - selectivity * 0.8f;
        const float invTwoSigmaSq = 1.0f / (2.0f * sigma * sigma);

        std::array<float, 7> kernelW{};
        for (int m = -3; m <= 3; ++m) {
            kernelW[m + 3] = std::exp(-static_cast<float>(m * m) * invTwoSigmaSq);
        }

        std::array<float, NumBands> baselineL{};
        std::array<float, NumBands> baselineR{};
        for (size_t k = 0; k < NumBands; ++k) {
            float wSum = 0.0f;
            float vSumL = 0.0f;
            float vSumR = 0.0f;
            for (int m = -3; m <= 3; ++m) {
                const int idx = std::clamp(static_cast<int>(k) + m, 0, static_cast<int>(NumBands) - 1);
                const float w = kernelW[m + 3];
                vSumL += logMagsL[idx] * w;
                vSumR += logMagsR[idx] * w;
                wSum += w;
            }
            const float invWSum = 1.0f / wSum;
            baselineL[k] = vSumL * invWSum;
            baselineR[k] = vSumR * invWSum;
        }

        float currentMaxGRL = 0.0f;
        float currentPeakHzL = targetFreqHz;

        // Transient Shield calcolato sull'inviluppo sub-millisecond stereo-coupled
        const float shieldFactor = std::max(0.0f, 1.0f - (transShield * sharedTransRatio * 1.25f));

        for (size_t k = 0; k < NumBands; ++k) {
            const float fc = left.centerFreqs[k];
            float targetAttenDbL = 0.0f;
            float targetAttenDbR = 0.0f;

            if (k >= left.firstProcessBand && depth > 0.005f) {
                const float isoWeight = left.isoWeights[k];

                const float promL = std::max(0.0f, logMagsL[k] - baselineL[k]) * isoWeight;
                const float promR = std::max(0.0f, logMagsR[k] - baselineR[k]) * isoWeight;

                const float proxWeight = left.cachedProxWeights[k];

                if (promL > thresholdDb) {
                    const float rawCut = (promL - thresholdDb) * (depth * depthFactor) * proxWeight;
                    targetAttenDbL = std::min(maxCutDb, rawCut * shieldFactor);
                }

                if (promR > thresholdDb) {
                    const float rawCut = (promR - thresholdDb) * (depth * depthFactor) * proxWeight;
                    targetAttenDbR = std::min(maxCutDb, rawCut * shieldFactor);
                }

                // =============================================================
                // STEREO LINKING: Attenuazione coordinata per preservare l'imaging
                // =============================================================
                const float linkedCut = std::max(targetAttenDbL, targetAttenDbR);
                targetAttenDbL = (1.0f - stereoLink01) * targetAttenDbL + stereoLink01 * linkedCut;
                targetAttenDbR = (1.0f - stereoLink01) * targetAttenDbR + stereoLink01 * linkedCut;
            }

            left.currentGRDb[k] += grSmoothingSpeed * (targetAttenDbL - left.currentGRDb[k]);
            right.currentGRDb[k] += grSmoothingSpeed * (targetAttenDbR - right.currentGRDb[k]);

            if (left.currentGRDb[k] < 1.0e-15f) left.currentGRDb[k] = 0.0f;
            if (right.currentGRDb[k] < 1.0e-15f) right.currentGRDb[k] = 0.0f;

            if (left.currentGRDb[k] > currentMaxGRL) {
                currentMaxGRL = left.currentGRDb[k];
                currentPeakHzL = fc;
            }
        }

        left.peakResoHz = currentPeakHzL;
        left.maxGRDb = currentMaxGRL;
        right.peakResoHz = left.peakResoHz;
        right.maxGRDb = left.maxGRDb;

        // Applicazione filtri notch Cytomic ZDF a 64-bit con calibrazione (2*R*bp)
        double procDL = inDL;
        double procDR = inDR;

        for (size_t k = left.firstProcessBand; k < NumBands; ++k) {
            const double g = left.baseG[k];
            const double denom = 1.0 + 2.0 * R * g + g * g;
            const double invDenom = 1.0 / denom;

            // Left Notch
            const double hpL = (procDL - (2.0 * R + g) * left.s1[k] - left.s2[k]) * invDenom;
            const double bpL = g * hpL + left.s1[k];
            const double lpL = g * bpL + left.s2[k];
            left.s1[k] = 2.0 * bpL - left.s1[k];
            left.s2[k] = 2.0 * lpL - left.s2[k];
            if (std::abs(left.s1[k]) < 1.0e-25) left.s1[k] = 0.0;
            if (std::abs(left.s2[k]) < 1.0e-25) left.s2[k] = 0.0;

            if (left.currentGRDb[k] > 0.001f) {
                const float gainLinL = dsp171::fastDbToLinear(-left.currentGRDb[k]);
                procDL += static_cast<double>(gainLinL - 1.0f) * (2.0 * R * bpL);
            }

            // Right Notch
            const double hpR = (procDR - (2.0 * R + g) * right.s1[k] - right.s2[k]) * invDenom;
            const double bpR = g * hpR + right.s1[k];
            const double lpR = g * bpR + right.s2[k];
            right.s1[k] = 2.0 * bpR - right.s1[k];
            right.s2[k] = 2.0 * lpR - right.s2[k];
            if (std::abs(right.s1[k]) < 1.0e-25) right.s1[k] = 0.0;
            if (std::abs(right.s2[k]) < 1.0e-25) right.s2[k] = 0.0;

            if (right.currentGRDb[k] > 0.001f) {
                const float gainLinR = dsp171::fastDbToLinear(-right.currentGRDb[k]);
                procDR += static_cast<double>(gainLinR - 1.0f) * (2.0 * R * bpR);
            }
        }

        const float procL = static_cast<float>(procDL);
        const float procR = static_cast<float>(procDR);
        const float deltaL = inL - procL;
        const float deltaR = inR - procR;

        outL = (procL * (1.0f - curDeltaSmooth)) + (deltaL * curDeltaSmooth);
        outR = (procR * (1.0f - curDeltaSmooth)) + (deltaR * curDeltaSmooth);
    }

    void fillVisualStats(FrameStats& stats) const noexcept {
        for (size_t k = 0; k < NumBands; ++k) {
            const float dbIn = fastGainToDb(fastEnv[k]);
            stats.inSpectrum[k] = std::clamp((dbIn + 60.0f) / 60.0f, 0.0f, 1.0f);
            stats.grSpectrum[k] = std::clamp(currentGRDb[k] / 15.0f, 0.0f, 1.0f);
        }
        stats.peakResoHz = peakResoHz;
        stats.maxGRDb = maxGRDb;
        stats.transientActivity = transSplitter.getTransientRatio();
    }

private:
    void updateTargetWeights(float targetFreqHz) noexcept {
        if (std::abs(targetFreqHz - lastTargetFreqHz) < 1.0f) return;
        lastTargetFreqHz = targetFreqHz;

        const float clampedTarget = std::clamp(targetFreqHz, 1000.0f, 12000.0f);
        const float logTarget = std::log(clampedTarget);
        constexpr float sigma = 0.85f;

        for (size_t k = 0; k < NumBands; ++k) {
            const float diffLog = (logCenterFreqs[k] - logTarget) / sigma;
            cachedProxWeights[k] = 0.35f + 0.65f * std::exp(-0.5f * diffLog * diffLog);
        }
    }

    float sr = 44100.0f;
    TransientSplitter transSplitter;

    std::array<float, NumBands> centerFreqs{};
    std::array<float, NumBands> logCenterFreqs{};
    std::array<double, NumBands> baseG{};
    std::array<float, NumBands> isoWeights{};
    std::array<float, NumBands> cachedProxWeights{};
    float lastTargetFreqHz = -1.0f;
    size_t firstProcessBand = 16;

    std::array<float, NumBands> fastEnv{};
    std::array<float, NumBands> currentGRDb{};

    // Memorie dei filtri SVF a 64-bit
    std::array<double, NumBands> s1{};
    std::array<double, NumBands> s2{};
    std::array<double, NumBands> detS1{};
    std::array<double, NumBands> detS2{};

    float alphaAttSoft = 0.01f;
    float alphaRelSoft = 0.001f;
    float alphaAttHard = 0.015f;
    float alphaRelHard = 0.002f;
    float grSmoothSoft = 0.08f;
    float grSmoothHard = 0.15f;

    float peakResoHz = 4500.0f;
    float maxGRDb = 0.0f;
};

} // namespace dsp171
