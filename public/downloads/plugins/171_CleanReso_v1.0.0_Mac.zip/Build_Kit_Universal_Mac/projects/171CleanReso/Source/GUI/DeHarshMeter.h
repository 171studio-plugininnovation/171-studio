#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <cmath>
#include <algorithm>

namespace gui171 {

// Meter Verticale Dedicato DE-HARSH ad Alta Precisione - Profilo Stretto (Slim LED Ladder + Peak Hold)
class DeHarshMeter : public juce::Component {
public:
    DeHarshMeter() {
        setOpaque(false);
    }

    ~DeHarshMeter() override = default;

    void updateReduction(float maxRedDb, bool hasData) noexcept {
        if (hasData) {
            // Inseguimento rapido dell'attenuazione di asprezza a 60 FPS
            if (maxRedDb > smoothedRedDb) {
                smoothedRedDb += 0.50f * (maxRedDb - smoothedRedDb);
            } else {
                smoothedRedDb += 0.20f * (maxRedDb - smoothedRedDb);
            }

            // Gestione del Peak Hold
            if (smoothedRedDb >= peakRedDb) {
                peakRedDb = smoothedRedDb;
                peakHoldCounter = 45; // ~750 ms di tenuta picco a 60 FPS
            } else {
                if (peakHoldCounter > 0) {
                    --peakHoldCounter;
                } else {
                    peakRedDb = std::max(0.0f, peakRedDb - 0.38f); // Decadimento gravitazionale
                }
            }
        } else {
            smoothedRedDb *= 0.88f;
            if (peakHoldCounter > 0) {
                --peakHoldCounter;
            } else {
                peakRedDb = std::max(0.0f, peakRedDb - 0.45f);
            }
        }

        repaint();
    }

    void paint(juce::Graphics& g) override {
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());

        // 1. Sfondo trasparente/scuro della cavità interna
        g.setColour(juce::Colour(0x90080a0e));
        g.fillRoundedRectangle(0.0f, 0.0f, w, h, 3.0f);

        // Scala proporzionale in base alle dimensioni nominali (68 x 186)
        const float scaleX = w / 68.0f;
        const float scaleY = h / 186.0f;

        // 2. Colonna LED Stretta
        const float barX = 7.0f * scaleX;
        const float barW = 15.0f * scaleX;
        const float barTopY = 6.0f * scaleY;
        const float barHeight = 152.0f * scaleY;
        const float barBottomY = barTopY + barHeight;

        // Traccia scura incassata della barra LED
        g.setColour(juce::Colour(0xd006080a));
        g.fillRoundedRectangle(barX - 1.5f * scaleX, barTopY - 1.5f * scaleY, barW + 3.0f * scaleX, barHeight + 3.0f * scaleY, 2.5f * scaleX);
        g.setColour(juce::Colour(0x30c59c52));
        g.drawRoundedRectangle(barX - 1.5f * scaleX, barTopY - 1.5f * scaleY, barW + 3.0f * scaleX, barHeight + 3.0f * scaleY, 2.5f * scaleX, 0.8f);

        // 3. Rendering dei 20 Segmenti LED
        constexpr int numSegments = 20;
        const float segGap = 1.8f * scaleY;
        const float segHeight = (barHeight - (numSegments - 1) * segGap) / static_cast<float>(numSegments);

        for (int i = 0; i < numSegments; ++i) {
            // Segmento 0 è la base (0 dB), Segmento 19 è la cima (-30 dB)
            const float segDbThreshold = (static_cast<float>(i + 1) / static_cast<float>(numSegments)) * 30.0f;
            const float segY = barBottomY - (i + 1) * segHeight - i * segGap;

            // Scala colori continua: Verde -> Oro -> Arancio -> Rosso fuoco
            juce::Colour segCol;
            if (i < 5) {
                segCol = juce::Colour(0xff00e676); // Verde brillante
            } else if (i < 11) {
                segCol = juce::Colour(0xffffcc00); // Oro caldo
            } else if (i < 16) {
                segCol = juce::Colour(0xffff9500); // Arancio neon
            } else {
                segCol = juce::Colour(0xffff2030); // Rosso rubino
            }

            const bool isLit = smoothedRedDb >= (segDbThreshold - 1.2f);

            if (isLit) {
                // Pass 1: Diffusione soffusa
                g.setColour(segCol.withAlpha(0.35f));
                g.fillRoundedRectangle(barX - 1.5f, segY - 1.0f, barW + 3.0f, segHeight + 2.0f, 2.0f);

                // Pass 2: Corpo del segmento saturo
                g.setColour(segCol);
                g.fillRoundedRectangle(barX, segY, barW, segHeight, 1.2f);

                // Pass 3: Riflesso speculare superiore
                g.setColour(juce::Colours::white.withAlpha(0.70f));
                g.fillRoundedRectangle(barX + 1.5f, segY + 0.6f, barW - 3.0f, segHeight * 0.40f, 0.6f);
            } else {
                // Segmento spento: vetro fumé scuro
                g.setColour(juce::Colour(0x3012151c));
                g.fillRoundedRectangle(barX, segY, barW, segHeight, 1.2f);
                g.setColour(segCol.withAlpha(0.12f));
                g.drawRoundedRectangle(barX, segY, barW, segHeight, 1.2f, 0.6f);
            }
        }

        // 4. Indicatore Peak-Hold (Ago orizzontale al neon sulla colonna)
        if (peakRedDb > 0.6f) {
            const float normPeak = std::clamp(peakRedDb / 30.0f, 0.0f, 1.0f);
            const float peakY = barBottomY - normPeak * barHeight;

            g.setColour(juce::Colour(0xffffcc00).withAlpha(0.70f));
            g.fillRoundedRectangle(barX - 1.5f, peakY - 1.5f, barW + 3.0f, 3.0f, 1.0f);

            g.setColour(juce::Colours::white);
            g.fillRoundedRectangle(barX, peakY - 0.75f, barW, 1.5f, 0.8f);
        }

        // 5. Scala Serigrafata in dB (Ticks e Numeri)
        static const struct TickDef { float db; const char* label; } ticks[] = {
            { 0.0f,  "0" },
            { 6.0f,  "-6" },
            { 12.0f, "-12" },
            { 18.0f, "-18" },
            { 24.0f, "-24" },
            { 30.0f, "-30" }
        };

        g.setFont(juce::FontOptions(8.5f * scaleY, juce::Font::bold));

        for (const auto& t : ticks) {
            const float norm = t.db / 30.0f;
            const float ty = barBottomY - norm * barHeight;

            // Tick orizzontale
            g.setColour(juce::Colour(0x60c59c52));
            g.drawHorizontalLine(static_cast<int>(ty), barX + barW + 2.0f * scaleX, barX + barW + 6.0f * scaleX);

            // Testo dB
            g.setColour(juce::Colour(0x95ffe099));
            g.drawText(t.label, static_cast<int>(barX + barW + 8.0f * scaleX), static_cast<int>(ty - 6.0f * scaleY), static_cast<int>(30.0f * scaleX), static_cast<int>(12.0f * scaleY), juce::Justification::centredLeft, false);
        }

        // 6. Readout Digitale GR in basso (Badge compatto stretto)
        const float badgeW = 54.0f * scaleX;
        const float badgeH = 16.0f * scaleY;
        const float badgeX = (w - badgeW) * 0.5f;
        const float badgeY = barBottomY + 5.0f * scaleY;

        g.setColour(juce::Colour(0xee0e1014));
        g.fillRoundedRectangle(badgeX, badgeY, badgeW, badgeH, 2.5f * scaleX);
        g.setColour(juce::Colour(0x55c59c52));
        g.drawRoundedRectangle(badgeX, badgeY, badgeW, badgeH, 2.5f * scaleX, 0.9f);

        juce::String grText = (smoothedRedDb < 0.2f) ? "0.0 dB" : ("-" + juce::String(smoothedRedDb, 1) + " dB");
        juce::Colour textCol = (smoothedRedDb > 18.0f) ? juce::Colour(0xffff453a)
                             : (smoothedRedDb > 8.0f)  ? juce::Colour(0xffffcc00)
                             : juce::Colour(0xff00e676);

        g.setFont(juce::FontOptions(9.0f * scaleY, juce::Font::bold));
        g.setColour(textCol);
        g.drawText(grText, static_cast<int>(badgeX), static_cast<int>(badgeY), static_cast<int>(badgeW), static_cast<int>(badgeH), juce::Justification::centred, false);
    }

private:
    float smoothedRedDb = 0.0f;
    float peakRedDb = 0.0f;
    int peakHoldCounter = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DeHarshMeter)
};

} // namespace gui171
