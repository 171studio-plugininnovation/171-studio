#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include "GUI/WingedChickenKnob.h"
#include "GUI/BoutiqueVerticalFader.h"
#include "GUI/BoutiqueJewelLampButton.h"
#include "GUI/BoutiqueSoftHardSwitch.h"
#include "GUI/SpectralResoVisualizer.h"
#include "GUI/DeHarshMeter.h"
#include <dsp171/BoutiqueStepperButton.h>

// ==============================================================================
// 171CleanReso Boutique Studio Editor (JUCE 8 - 60 FPS Hardware CMF Pipeline)
// 171 Studio Winged Chicken-Head Knobs, Slim Master Fader & Dual 171 Gold Logos
// ==============================================================================
class AudioPluginAudioProcessorEditor : public juce::AudioProcessorEditor,
                                        public juce::ComboBox::Listener,
                                        private juce::Timer {
public:
    explicit AudioPluginAudioProcessorEditor(AudioPluginAudioProcessor&);
    ~AudioPluginAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;
    void comboBoxChanged(juce::ComboBox*) override;
    void timerCallback() override;

private:
    void drawHeaderConsole(juce::Graphics& g, const juce::Rectangle<float>& bounds);
    void drawMasterSectionDividers(juce::Graphics& g);

    AudioPluginAudioProcessor& processorRef;

    // Visualizzatore spettrale vettoriale 60 FPS con logo filigranato
    gui171::SpectralResoVisualizer visualizer;

    // Meter Verticale Dedicato DE-HARSH
    gui171::DeHarshMeter deHarshMeter;

    // Switch Boutique Soft / Hard
    gui171::BoutiqueSoftHardSwitch softHardSwitch;

    // Tasti Jewel Lamp Boutique (Delta Listen Ambra & Master Bypass Rubino)
    gui171::BoutiqueJewelLampButton deltaButton;
    gui171::BoutiqueJewelLampButton bypassButton;

    // Manopole Chicken-Head Alate (171 PerfectPre Style)
    std::unique_ptr<gui171::WingedChickenKnobComponent> depthKnob;
    std::unique_ptr<gui171::WingedChickenKnobComponent> sharpnessKnob;
    std::unique_ptr<gui171::WingedChickenKnobComponent> selectivityKnob;
    std::unique_ptr<gui171::WingedChickenKnobComponent> transShieldKnob;
    std::unique_ptr<gui171::WingedChickenKnobComponent> silkKnob;

    // Fader Verticale Slim Boutique Master Mix (Solid Gunmetal Cap + Amber LED)
    std::unique_ptr<gui171::BoutiqueVerticalFaderComponent> mixFader;

    // Output Gain Chicken-Head Knob (Light Steel)
    std::unique_ptr<gui171::WingedChickenKnobComponent> outputKnob;

    // Sincronizzazione APVTS
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;

    std::unique_ptr<SliderAttachment> depthAttach;
    std::unique_ptr<SliderAttachment> sharpnessAttach;
    std::unique_ptr<SliderAttachment> selectivityAttach;
    std::unique_ptr<SliderAttachment> transShieldAttach;
    std::unique_ptr<SliderAttachment> silkAttach;
    std::unique_ptr<SliderAttachment> mixAttach;
    std::unique_ptr<SliderAttachment> outputAttach;

    std::unique_ptr<ButtonAttachment> modeHardAttach;
    std::unique_ptr<ButtonAttachment> deltaAttach;
    std::unique_ptr<ButtonAttachment> bypassAttach;

    // Selettore Preset Boutique & Stepper
    juce::ComboBox presetComboBox;
    std::unique_ptr<gui171::BoutiqueStepperButton> prevPresetBtn;
    std::unique_ptr<gui171::BoutiqueStepperButton> nextPresetBtn;

    // Immagini di background e logo 171 Studio
    juce::Image backgroundImage;
    juce::Image logo171Gold;

    // Ultimo frame visuale
    dsp171::ResoVisualFrame latestFrame;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AudioPluginAudioProcessorEditor)
};
