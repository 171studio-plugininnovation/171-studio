#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <array>
#include <dsp171/Common.h>
#include <dsp171/SafetyCeiling.h>
#include <dsp171/LatencyBypass.h>
#include <dsp171/LockFreeFIFO.h>
#include "DSP/DynamicResonanceEngine.h"
#include "DSP/AnalogSilkStage.h"

struct PluginPreset {
    const char* name;
    float depth;
    float sharpness;
    float selectivity;
    float transShield;
    float silk;
    float mix;
    float outGain;
};

class AudioPluginAudioProcessor : public juce::AudioProcessor {
public:
    AudioPluginAudioProcessor();
    ~AudioPluginAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "171CleanReso"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    // Gestione Preset
    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int index, const juce::String& newName) override;

    juce::AudioProcessorParameter* getBypassParameter() const override {
        return apvts.getParameter("bypass");
    }

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }
    dsp171::LockFreeResoFIFO<512>& getVisualFIFO() noexcept { return visualFIFO; }

    static const std::vector<PluginPreset>& getFactoryPresets();

private:
    juce::AudioProcessorValueTreeState apvts;
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    static constexpr size_t MaxChannels = 2;
    std::array<dsp171::DynamicResonanceEngine, MaxChannels> resoEngines;
    std::array<dsp171::AnalogSilkStage, MaxChannels> silkStages;
    std::array<dsp171::TruePeakLimiter, MaxChannels> truePeakLimiters;
    dsp171::LatencyCompensatedBypass<MaxChannels, 64> latencyBypass;

    dsp171::LockFreeResoFIFO<512> visualFIFO;

    // Parametri APVTS atomici
    std::atomic<float>* depthParam       = nullptr;
    std::atomic<float>* sharpnessParam   = nullptr;
    std::atomic<float>* selectivityParam = nullptr;
    std::atomic<float>* transShieldParam = nullptr;
    std::atomic<float>* silkParam        = nullptr;
    std::atomic<float>* mixParam         = nullptr;
    std::atomic<float>* outGainParam     = nullptr;
    std::atomic<float>* deltaParam       = nullptr;
    std::atomic<float>* bypassParam      = nullptr;
    std::atomic<float>* modeHardParam    = nullptr;

    // Smoothing a livello di campione (anti-zipper e zero-click)
    juce::SmoothedValue<float> smoothedDepth;
    juce::SmoothedValue<float> smoothedSharpness;
    juce::SmoothedValue<float> smoothedSelectivity;
    juce::SmoothedValue<float> smoothedTransShield;
    juce::SmoothedValue<float> smoothedSilk;
    juce::SmoothedValue<float> smoothedMix;
    juce::SmoothedValue<float> smoothedOutGain;
    juce::SmoothedValue<float> smoothedDelta;
    juce::SmoothedValue<float> smoothedBypass;

    int currentProgramIndex = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AudioPluginAudioProcessor)
};
