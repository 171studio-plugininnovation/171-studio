#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <BinaryData.h>

AudioPluginAudioProcessorEditor::AudioPluginAudioProcessorEditor(AudioPluginAudioProcessor& p)
    : AudioProcessorEditor(&p),
      processorRef(p),
      deltaButton(gui171::BoutiqueJewelLampButton::LampType::Amber, "DELTA"),
      bypassButton(gui171::BoutiqueJewelLampButton::LampType::Ruby, "BYPASS")
{
    // 1. Carica il backplate in alta definizione e il logo dorato 171 Studio
    backgroundImage = juce::ImageCache::getFromMemory(BinaryData::clean_background_png,
                                                       BinaryData::clean_background_pngSize);
    logo171Gold     = juce::ImageCache::getFromMemory(BinaryData::logo_171_gold_png,
                                                       BinaryData::logo_171_gold_pngSize);

    // 2. Creazione delle 5 Manopole Chicken-Head Alate (171 PerfectPre Style)
    depthKnob = std::make_unique<gui171::WingedChickenKnobComponent>(
        "DEPTH",
        gui171::WingedChickenKnobLookAndFeel::KnobColor::CobaltBlue,
        gui171::WingedChickenKnobComponent::DisplayFormat::Percentage,
        false, 0.5f, true);

    sharpnessKnob = std::make_unique<gui171::WingedChickenKnobComponent>(
        "TARGET FREQ",
        gui171::WingedChickenKnobLookAndFeel::KnobColor::WarmBronze,
        gui171::WingedChickenKnobComponent::DisplayFormat::Hertz,
        false, 0.5f, false);

    selectivityKnob = std::make_unique<gui171::WingedChickenKnobComponent>(
        "SELECTIVITY",
        gui171::WingedChickenKnobLookAndFeel::KnobColor::NeveRed,
        gui171::WingedChickenKnobComponent::DisplayFormat::Percentage,
        false, 0.5f, true);

    transShieldKnob = std::make_unique<gui171::WingedChickenKnobComponent>(
        "TRANS SHIELD",
        gui171::WingedChickenKnobLookAndFeel::KnobColor::EmeraldJade,
        gui171::WingedChickenKnobComponent::DisplayFormat::Percentage,
        false, 0.5f, true);

    silkKnob = std::make_unique<gui171::WingedChickenKnobComponent>(
        "ANALOG SILK",
        gui171::WingedChickenKnobLookAndFeel::KnobColor::AmberGold,
        gui171::WingedChickenKnobComponent::DisplayFormat::Percentage,
        false, 0.5f, true);

    // 3. Fader Verticale Slim Boutique Master Mix (Solid Gunmetal Cap + Amber LED)
    mixFader = std::make_unique<gui171::BoutiqueVerticalFaderComponent>("MASTER MIX");

    // 4. Manopola Output Trim Chicken-Head (White Porcelain / Light Steel)
    outputKnob = std::make_unique<gui171::WingedChickenKnobComponent>(
        "OUTPUT",
        gui171::WingedChickenKnobLookAndFeel::KnobColor::LightSteel,
        gui171::WingedChickenKnobComponent::DisplayFormat::Decibels,
        true, 18.0f / 30.0f, false);

    // 5. Aggiunta componenti a schermo
    addAndMakeVisible(visualizer);
    addAndMakeVisible(deHarshMeter);

    addAndMakeVisible(*depthKnob);
    addAndMakeVisible(*sharpnessKnob);
    addAndMakeVisible(*selectivityKnob);
    addAndMakeVisible(*transShieldKnob);
    addAndMakeVisible(*silkKnob);
    addAndMakeVisible(*mixFader);
    addAndMakeVisible(*outputKnob);

    // 6. Collegamento con l'albero parametri APVTS
    auto& apvts = processorRef.getAPVTS();
    depthAttach       = std::make_unique<SliderAttachment>(apvts, "depth", depthKnob->slider);
    sharpnessAttach   = std::make_unique<SliderAttachment>(apvts, "sharpness", sharpnessKnob->slider);
    selectivityAttach = std::make_unique<SliderAttachment>(apvts, "selectivity", selectivityKnob->slider);
    transShieldAttach = std::make_unique<SliderAttachment>(apvts, "trans_shield", transShieldKnob->slider);
    silkAttach        = std::make_unique<SliderAttachment>(apvts, "silk", silkKnob->slider);
    mixAttach         = std::make_unique<SliderAttachment>(apvts, "mix", mixFader->slider);
    outputAttach      = std::make_unique<SliderAttachment>(apvts, "out_gain", outputKnob->slider);

    // 7. Switch SOFT / HARD Boutique
    modeHardAttach = std::make_unique<ButtonAttachment>(apvts, "mode_hard", softHardSwitch);
    addAndMakeVisible(softHardSwitch);

    // 8. Selettore Preset Boutique
    const auto& presets = AudioPluginAudioProcessor::getFactoryPresets();
    for (size_t i = 0; i < presets.size(); ++i) {
        presetComboBox.addItem(presets[i].name, static_cast<int>(i + 1));
    }
    presetComboBox.setSelectedId(processorRef.getCurrentProgram() + 1, juce::dontSendNotification);
    presetComboBox.addListener(this);

    presetComboBox.setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xd0101115));
    presetComboBox.setColour(juce::ComboBox::outlineColourId, juce::Colour(0xffc59c52));
    presetComboBox.setColour(juce::ComboBox::textColourId, juce::Colour(0xffffe099));
    presetComboBox.setColour(juce::ComboBox::arrowColourId, juce::Colour(0xffffe099));
    addAndMakeVisible(presetComboBox);

    // Stepper Button Boutique dorati per preset (< e >)
    prevPresetBtn = std::make_unique<gui171::BoutiqueStepperButton>(gui171::BoutiqueStepperButton::Direction::Previous);
    prevPresetBtn->setOnClick([this]() {
        int cur = presetComboBox.getSelectedId() - 1;
        int num = processorRef.getNumPrograms();
        if (num > 0) {
            int prev = (cur - 1 + num) % num;
            presetComboBox.setSelectedId(prev + 1, juce::sendNotification);
        }
    });
    addAndMakeVisible(*prevPresetBtn);

    nextPresetBtn = std::make_unique<gui171::BoutiqueStepperButton>(gui171::BoutiqueStepperButton::Direction::Next);
    nextPresetBtn->setOnClick([this]() {
        int cur = presetComboBox.getSelectedId() - 1;
        int num = processorRef.getNumPrograms();
        if (num > 0) {
            int next = (cur + 1) % num;
            presetComboBox.setSelectedId(next + 1, juce::sendNotification);
        }
    });
    addAndMakeVisible(*nextPresetBtn);

    // 9. Jewel Lamps (Delta Listen Ambra & Master Bypass Rubino)
    deltaAttach = std::make_unique<ButtonAttachment>(apvts, "delta_listen", deltaButton);
    addAndMakeVisible(deltaButton);

    bypassAttach = std::make_unique<ButtonAttachment>(apvts, "bypass", bypassButton);
    addAndMakeVisible(bypassButton);

    // Avvio del timer 60 FPS per telemetria fluida
    startTimerHz(60);

    // Supporto al resizing proporzionale a 1024 x 571
    setResizable(true, true);
    setResizeLimits(768, 428, 2048, 1142);
    getConstrainer()->setFixedAspectRatio(1024.0 / 571.0);
    setSize(1024, 571);
}

AudioPluginAudioProcessorEditor::~AudioPluginAudioProcessorEditor() {
    stopTimer();
    presetComboBox.removeListener(this);
}

void AudioPluginAudioProcessorEditor::timerCallback() {
    dsp171::ResoVisualFrame frame;
    bool hasData = false;

    // Svuota la FIFO SPSC e cattura l'ultimo frame
    while (processorRef.getVisualFIFO().pop(frame)) {
        hasData = true;
        latestFrame = frame;
    }

    // Distribuzione sincronizzata al monitor spettrale e al meter DE-HARSH
    visualizer.updateFrame(latestFrame, hasData);
    deHarshMeter.updateReduction(latestFrame.maxReductionDb, hasData);
}

void AudioPluginAudioProcessorEditor::comboBoxChanged(juce::ComboBox* box) {
    if (box == &presetComboBox) {
        const int selectedIdx = presetComboBox.getSelectedId() - 1;
        if (selectedIdx >= 0) {
            processorRef.setCurrentProgram(selectedIdx);
        }
    }
}

void AudioPluginAudioProcessorEditor::drawHeaderConsole(juce::Graphics& g, const juce::Rectangle<float>& /*bounds*/) {
    const float scaleX = (float)getWidth()  / 1024.0f;
    const float scaleY = (float)getHeight() / 571.0f;

    // 1. Logo piccolo in alto a sinistra prima di 171 STUDIO (da 171PerfectPre)
    if (logo171Gold.isValid()) {
        auto logoRect = juce::Rectangle<float>(24.0f * scaleX, 14.0f * scaleY, 22.0f * scaleX, 26.0f * scaleY);
        g.drawImage(logo171Gold, logoRect, juce::RectanglePlacement::centred);
    }

    // 2. Serigrafia "171 STUDIO" in oro satinato
    g.setFont(juce::FontOptions(14.0f * scaleY, juce::Font::bold));
    g.setColour(juce::Colour(0xffffe082)); // Oro satinato 171 Studio
    g.drawText("171 STUDIO", 52.0f * scaleX, 16.0f * scaleY, 94.0f * scaleX, 22.0f * scaleY, juce::Justification::left);

    // Separatore verticale sottile in ottone
    g.setColour(juce::Colour(0x60c5a059));
    g.drawVerticalLine(juce::roundToInt(148.0f * scaleX), 16.0f * scaleY, 38.0f * scaleY);

    // 3. Titolo: "CLEAN" sempre BIANCO, "RESO" sempre ORO
    g.setFont(juce::FontOptions(15.0f * scaleY, juce::Font::bold));
    g.setColour(juce::Colour(0xfff1f5f9)); // Bianco titanio
    g.drawText("CLEAN", 158.0f * scaleX, 16.0f * scaleY, 56.0f * scaleX, 22.0f * scaleY, juce::Justification::left);

    g.setColour(juce::Colour(0xffffe082)); // Oro caldo (#FFE082 / #D4AF37)
    g.drawText("RESO", 216.0f * scaleX, 16.0f * scaleY, 52.0f * scaleX, 22.0f * scaleY, juce::Justification::left);

    // Filetto orizzontale in ottone caldo sotto la testata
    juce::ColourGradient lineGrad(juce::Colour(0x60c5a059), 20.0f * scaleX, 52.0f * scaleY,
                                  juce::Colour(0x60ffe082), (1024.0f - 20.0f) * scaleX, 52.0f * scaleY, false);
    g.setGradientFill(lineGrad);
    g.drawHorizontalLine(juce::roundToInt(52.0f * scaleY), 20.0f * scaleX, (1024.0f - 20.0f) * scaleX);
}

void AudioPluginAudioProcessorEditor::drawMasterSectionDividers(juce::Graphics& g) {
    const float scaleX = (float)getWidth()  / 1024.0f;
    const float scaleY = (float)getHeight() / 571.0f;

    // Divisorio verticale tra Sezione Risonanze e Sezione Master
    const float divX = 672.0f * scaleX;
    const float topY = 372.0f * scaleY;
    const float botY = 525.0f * scaleY;

    g.setColour(juce::Colour(0x40000000));
    g.drawVerticalLine(juce::roundToInt(divX), topY, botY);
    g.setColour(juce::Colour(0x35c5a059));
    g.drawVerticalLine(juce::roundToInt(divX + 1.0f), topY, botY);
}

void AudioPluginAudioProcessorEditor::paint(juce::Graphics& g) {
    if (backgroundImage.isValid()) {
        g.drawImage(backgroundImage, getLocalBounds().toFloat());
    } else {
        g.fillAll(juce::Colour(0xff121316));
    }

    drawHeaderConsole(g, getLocalBounds().toFloat());
    drawMasterSectionDividers(g);
}

void AudioPluginAudioProcessorEditor::resized() {
    const float scaleX = (float)getWidth()  / 1024.0f;
    const float scaleY = (float)getHeight() / 571.0f;
    auto S = [scaleX, scaleY](int x, int y, int w, int h) -> juce::Rectangle<int> {
        return { juce::roundToInt(x * scaleX),
                 juce::roundToInt(y * scaleY),
                 juce::roundToInt(w * scaleX),
                 juce::roundToInt(h * scaleY) };
    };

    // 1. Controlli Console Superiore
    softHardSwitch.setBounds(S(110, 80, 68, 26));
    if (prevPresetBtn != nullptr) prevPresetBtn->setBounds(S(390, 80, 24, 26));
    presetComboBox.setBounds(S(420, 80, 210, 26));
    if (nextPresetBtn != nullptr) nextPresetBtn->setBounds(S(634, 80, 24, 26));
    deltaButton.setBounds   (S(668, 74, 56, 40));
    bypassButton.setBounds  (S(750, 74, 56, 40));

    // 2. Monitor Spettrale Vettoriale incassato nella cornice dorata
    visualizer.setBounds(S(70, 129, 768, 222));

    // 3. Meter Verticale Dedicato DE-HARSH
    deHarshMeter.setBounds(S(878, 156, 68, 186));

    // 4. Sezione Dinamica: 5 Manopole Chicken-Head Alate (PerfectPre style)
    depthKnob->setBounds      (S(48,  372, 114, 154)); // Cobalt Blue (#00b4ff)
    sharpnessKnob->setBounds  (S(172, 372, 114, 154)); // Warm Bronze (#d4af37)
    selectivityKnob->setBounds(S(296, 372, 114, 154)); // Neve Red (#ff3344)
    transShieldKnob->setBounds(S(422, 372, 118, 154)); // Emerald Jade (#00ff88) Hero Knob
    silkKnob->setBounds       (S(550, 372, 114, 154)); // Amber Gold (#ffaa00)

    // 5. Sezione Master: Boutique Slim Vertical Fader & Output Trim Knob
    mixFader->setBounds  (S(690, 366, 120, 160)); // Slim Aged Brass Fader (0-100%, solid cap, no transparency)
    outputKnob->setBounds(S(844, 372, 114, 154)); // White Porcelain / Light Steel Chicken Knob
}
