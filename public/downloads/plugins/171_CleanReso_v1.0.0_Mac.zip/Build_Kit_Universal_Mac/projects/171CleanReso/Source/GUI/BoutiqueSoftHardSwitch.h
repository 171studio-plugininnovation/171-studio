#pragma once
#include <juce_gui_basics/juce_gui_basics.h>

namespace gui171 {

// ==============================================================================
// BOUTIQUE SOFT / HARD MODE SELECTOR SWITCH (171 STUDIO CONSOLE)
// Selettore a capsula in alluminio tornito e ottone con glow neon ciano / ambra
// ==============================================================================
class BoutiqueSoftHardSwitch : public juce::ToggleButton {
public:
    BoutiqueSoftHardSwitch() {
        setOpaque(false);
        setMouseCursor(juce::MouseCursor::PointingHandCursor);
        setTooltip("Selettore Modalita': Soft (musicale e progressivo) / Hard (chirurgico ad aggancio rapido)");
    }

    void paintButton(juce::Graphics& g, bool shouldDrawButtonAsHighlighted, bool /*shouldDrawButtonAsDown*/) override
    {
        auto bounds = getLocalBounds().toFloat().reduced(1.0f);
        if (bounds.isEmpty()) return;

        const bool isHard = getToggleState();

        // 1. Binario a capsula incassato nel telaio in ottone
        g.setColour(juce::Colour(0xef090b0e));
        g.fillRoundedRectangle(bounds, bounds.getHeight() * 0.5f);

        // Bordo in ottone satinato 171 Studio
        juce::Colour outlineCol = isHard ? juce::Colour(0xffff9500) : juce::Colour(0xffc5a059);
        g.setColour(outlineCol.withAlpha(shouldDrawButtonAsHighlighted ? 0.95f : 0.65f));
        g.drawRoundedRectangle(bounds, bounds.getHeight() * 0.5f, 1.0f);

        // Luce diffusa al neon attiva sul lato selezionato
        if (isHard) {
            juce::ColourGradient neonGrad(juce::Colour(0x35ff453a), bounds.getRight() - bounds.getWidth() * 0.45f, bounds.getCentreY(),
                                         juce::Colour(0x00ff453a), bounds.getRight(), bounds.getCentreY(), false);
            g.setGradientFill(neonGrad);
            g.fillRoundedRectangle(bounds.withTrimmedLeft(bounds.getWidth() * 0.45f), bounds.getHeight() * 0.5f);
        } else {
            juce::ColourGradient neonGrad(juce::Colour(0x3000e5ff), bounds.getX(), bounds.getCentreY(),
                                         juce::Colour(0x0000e5ff), bounds.getX() + bounds.getWidth() * 0.45f, bounds.getCentreY(), false);
            g.setGradientFill(neonGrad);
            g.fillRoundedRectangle(bounds.withTrimmedRight(bounds.getWidth() * 0.45f), bounds.getHeight() * 0.5f);
        }

        // Serigrafia etichette "SOFT" e "HARD" all'interno del binario
        const float halfW = bounds.getWidth() * 0.5f;
        auto softRect = bounds.withWidth(halfW);
        auto hardRect = bounds.withTrimmedLeft(halfW);

        g.setFont(juce::FontOptions(8.5f, juce::Font::bold));
        g.setColour(isHard ? juce::Colour(0x608c7042) : juce::Colour(0xff00f0ff));
        g.drawText("SOFT", softRect.translated(0.0f, -0.5f), juce::Justification::centred);

        g.setColour(isHard ? juce::Colour(0xffffa020) : juce::Colour(0x608c7042));
        g.drawText("HARD", hardRect.translated(0.0f, -0.5f), juce::Justification::centred);

        // 2. Leva / Slitta del selettore in alluminio tornito
        const float thumbW = bounds.getWidth() * 0.44f;
        const float thumbH = bounds.getHeight() - 2.5f;
        const float thumbY = bounds.getY() + 1.25f;
        const float thumbX = isHard ? (bounds.getRight() - thumbW - 1.25f) : (bounds.getX() + 1.25f);

        juce::Rectangle<float> thumbRect(thumbX, thumbY, thumbW, thumbH);

        // Ombra portata della slitta
        g.setColour(juce::Colour(0x95000000));
        g.fillRoundedRectangle(thumbRect.translated(0.0f, 1.2f), 3.5f);

        // Gradiente alluminio tornito spazzolato
        juce::ColourGradient grad(shouldDrawButtonAsHighlighted ? juce::Colour(0xff6e727c) : juce::Colour(0xff555860),
                                  thumbX, thumbY,
                                  shouldDrawButtonAsHighlighted ? juce::Colour(0xff2d3138) : juce::Colour(0xff22252a),
                                  thumbX, thumbY + thumbH, false);
        g.setGradientFill(grad);
        g.fillRoundedRectangle(thumbRect, 3.5f);

        // Bordo metallico cesellato
        g.setColour(juce::Colour(0xff9aa0aa));
        g.drawRoundedRectangle(thumbRect, 3.5f, 0.9f);

        // Linee di grip zigrinate centrali per presa fisica tattile
        const float midX = thumbRect.getCentreX();
        g.setColour(juce::Colour(0x800a0b0e));
        g.drawVerticalLine(static_cast<int>(midX - 3.0f), thumbY + 3.0f, thumbY + thumbH - 3.0f);
        g.drawVerticalLine(static_cast<int>(midX),        thumbY + 3.0f, thumbY + thumbH - 3.0f);
        g.drawVerticalLine(static_cast<int>(midX + 3.0f), thumbY + 3.0f, thumbY + thumbH - 3.0f);

        g.setColour(juce::Colour(0x50ffffff));
        g.drawVerticalLine(static_cast<int>(midX - 2.0f), thumbY + 3.0f, thumbY + thumbH - 3.0f);
        g.drawVerticalLine(static_cast<int>(midX + 1.0f), thumbY + 3.0f, thumbY + thumbH - 3.0f);
        g.drawVerticalLine(static_cast<int>(midX + 4.0f), thumbY + 3.0f, thumbY + thumbH - 3.0f);

        // LED dot di stato al centro della slitta con bloom
        const float ledRadius = 1.6f;
        const float ledY = thumbRect.getCentreY();
        juce::Colour ledCol = isHard ? juce::Colour(0xffff9500) : juce::Colour(0xff00f0ff);
        g.setColour(ledCol.withAlpha(0.40f));
        g.fillEllipse(midX - ledRadius - 2.0f, ledY - ledRadius - 2.0f, (ledRadius + 2.0f) * 2.0f, (ledRadius + 2.0f) * 2.0f);
        g.setColour(ledCol);
        g.fillEllipse(midX - ledRadius, ledY - ledRadius, ledRadius * 2.0f, ledRadius * 2.0f);
    }
};

} // namespace gui171
