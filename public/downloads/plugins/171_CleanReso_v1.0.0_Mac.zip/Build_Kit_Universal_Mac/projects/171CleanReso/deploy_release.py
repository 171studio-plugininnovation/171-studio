import os
import shutil
import zipfile

vst3_build_dir = r"C:\Users\171Studio\.gemini\antigravity\scratch\171CleanReso\build\171CleanReso_artefacts\Release\VST3\171CleanReso.vst3"
exe_build_path = r"C:\Users\171Studio\.gemini\antigravity\scratch\171CleanReso\build\171CleanReso_artefacts\Release\Standalone\171CleanReso.exe"
snap_path = r"C:\Users\171Studio\.gemini\antigravity\brain\947230ff-c9a3-4709-a320-b596b6ee2c5f\171CleanReso_Final_GUI.png"

system_vst3_dst = r"C:\Program Files\Common Files\VST3\171CleanReso.vst3"
desktop_pkg_dir = r"C:\Users\171Studio\Desktop\171PluginInnovation - CleanReso"
desktop_zip_dst = r"C:\Users\171Studio\Desktop\171CleanReso_v1.0.0_171PluginInnovation.zip"

# 1. Deploy atomically to System VST3 Directory
system_vst3_parent = r"C:\Program Files\Common Files\VST3"
os.makedirs(system_vst3_parent, exist_ok=True)
stage_dir = os.path.join(system_vst3_parent, "171CleanReso.vst3.tmp")
backup_dir = os.path.join(system_vst3_parent, "171CleanReso.vst3.bak")

if os.path.exists(stage_dir):
    shutil.rmtree(stage_dir)
if os.path.exists(backup_dir):
    shutil.rmtree(backup_dir)

shutil.copytree(vst3_build_dir, stage_dir)

if os.path.exists(system_vst3_dst):
    os.rename(system_vst3_dst, backup_dir)

os.rename(stage_dir, system_vst3_dst)

if os.path.exists(backup_dir):
    shutil.rmtree(backup_dir)
print("[+] Atomically deployed 171CleanReso.vst3 to system VST3 directory:", system_vst3_dst)

# 2. Update Desktop package directory
os.makedirs(desktop_pkg_dir, exist_ok=True)
desktop_vst3 = os.path.join(desktop_pkg_dir, "171CleanReso.vst3")
if os.path.exists(desktop_vst3):
    shutil.rmtree(desktop_vst3)
shutil.copytree(vst3_build_dir, desktop_vst3)

desktop_exe = os.path.join(desktop_pkg_dir, "171CleanReso.exe")
shutil.copy2(exe_build_path, desktop_exe)

desktop_snap = os.path.join(desktop_pkg_dir, "171CleanReso_Final_GUI.png")
shutil.copy2(snap_path, desktop_snap)

readme_content = """======================================================================
  171PluginInnovation - CleanReso (v1.0.0 Studio Edition)
  Transient-Aware Dynamic Resonance Suppressor & Spectral Shaper
======================================================================

CONTENUTO DEL PACCHETTO:
  - 171CleanReso.vst3/        -> Plugin VST3 a 64-bit per tutte le DAW
                                 (Cubase, Ableton, FL Studio, Reaper, Studio One, Pro Tools via VST3, ecc.)
  - 171CleanReso.exe          -> Applicazione Standalone Windows nativa (64-bit)
  - 171CleanReso_Final_GUI.png-> Snapshot fotorealistico dell'interfaccia grafica
  - README.txt                -> Manuale tecnico e guida all'uso

======================================================================
ARCHITETTURA DSP & INNOVAZIONI:
======================================================================
1. TRANSIENT SHIELD (HERO PROTECTION):
   - A differenza dei tradizionali soppressori spettrali che scambiano
     l'attacco dei colpi per risonanze dannose e smussano i transienti (time-smearing),
     171CleanReso isola la componente impulsiva tramite inseguitore balistico a doppio inviluppo.
   - I transienti di batteria, consonanti vocali e plettrate passano intatti al 100%,
     mantenendo intatto il punch e la definizione della traccia.

2. FILTRI ZERO-DELAY FEEDBACK (ZDF) A 64-BIT:
   - 32 bande logaritmiche SVF Cytomic a topologia ZDF con risoluzione a 64-bit.
   - Ponderazione psicoacustica ISO 226 focalizzata sull'asprezza del canale uditivo (2.5 kHz - 6.5 kHz).
   - Zero chiamate trascendenti pesanti nel realtime audio thread con look-up matematico ad alta efficienza.

3. STADIO ANALOG SILK & AIR:
   - Post-equalizzazione Baxandall High-Air a 12 kHz abbinata a saturazione a seconda armonica valvolare,
     per lucidare ed addolcire le alte frequenze ripulite.

4. TRUE-PEAK LIMITER CONFORME A ITU-R BS.1770-4:
   - Limiter di sicurezza a lookahead deterministico con ricostruzione inter-sample sinc 4x (32 tap Kaiser beta=7.0).
   - Ceiling rigorosamente vincolato a -0.10 dBTP (garanzia assoluta contro inter-sample peaks e clip da conversione D/A).
   - Stereo Linking coerente al 100% per preservare il centro fantasma (zero stereo yawing).

======================================================================
CONTROLLI E FUNZIONALITA':
======================================================================
- SOFT / HARD TOGGLE: 
  * SOFT: Intervento morbido, organico e trasparente per voci e master bus.
  * HARD: Intervento chirurgico rapido per piatti metallici e sibilanti sgradevoli.
- PRESET SELECTOR: 8 preset calibrati di laboratorio:
  * 01 | Vocal De-Harsh & Sibilance
  * 02 | Snare Ring & Boxiness Kill
  * 03 | Acoustic Guitar Resonance Tamer
  * 04 | Harsh Cymbals & Overhead Soother
  * 05 | Master Bus Harshness Tamer
  * 06 | Electric Guitar Fizz Eliminator
  * 07 | Synth Resonance Shaper
  * 08 | Surgical Resonance Hunter
- DELTA LISTEN: Ascolto isolato delle sole frequenze aspre e risonanze rimosse.
- MASTER BYPASS: Crossfade continuo a 15 ms pop-free con compensazione di latenza dry/wet bit-exact.
- DE-HARSH (0% - 100%): Intensità della soppressione dinamica.
- TARGET FREQ (1.0 kHz - 12.0 kHz): Frequenza centrale della risonanza da domare.
- SELECTIVITY (0% - 100%): Fattore Q selettivo tra armoniche musicali e risonanze dannose.
- TRANS SHIELD (0% - 100%): Manopola Hero centrale per proteggere il punch dai filtri notch.
- ANALOG SILK (0% - 100%): Lucidatura e setosità analogica sulle alte frequenze.
- MIX (0% - 100%): Controllo Dry/Wet coerente.
- OUTPUT (-18 dB a +12 dB): Trim di guadagno d'uscita.

======================================================================
GUIDA ALL'INSTALLAZIONE:
======================================================================
- VST3 (DAW):
  Il plugin e' gia' installato e pronto all'uso in:
  C:\\Program Files\\Common Files\\VST3\\171CleanReso.vst3
  Riavvia o effettua il rescan VST3 nella tua DAW (Ableton, FL Studio, Cubase, Studio One, Reaper).

- STANDALONE:
  Avvia direttamente '171CleanReso.exe' per il funzionamento autonomo senza DAW.

(C) 2026 171PluginInnovation - 171 Studio. Tutti i diritti riservati.
"""

readme_path = os.path.join(desktop_pkg_dir, "README.txt")
with open(readme_path, "w", encoding="utf-8") as f:
    f.write(readme_content)

print("[+] Updated README.txt in desktop package.")

# 3. Create Deliverable ZIP Archive on Desktop
if os.path.exists(desktop_zip_dst):
    os.remove(desktop_zip_dst)

with zipfile.ZipFile(desktop_zip_dst, "w", zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(desktop_pkg_dir):
        for f in files:
            full_p = os.path.join(root, f)
            rel_p = os.path.relpath(full_p, desktop_pkg_dir)
            zipf.write(full_p, rel_p)

zip_size = os.path.getsize(desktop_zip_dst)
print(f"[+] Deliverable ZIP created successfully: {desktop_zip_dst}")
print(f"[+] ZIP Archive Size: {zip_size:,} bytes")
