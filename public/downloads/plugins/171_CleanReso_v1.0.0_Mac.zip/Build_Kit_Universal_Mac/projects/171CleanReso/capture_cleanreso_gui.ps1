Add-Type -AssemblyName System.Windows.Forms, System.Drawing

$exePath = "C:\Users\171Studio\.gemini\antigravity\scratch\171CleanReso\build\171CleanReso_artefacts\Release\Standalone\171CleanReso.exe"
$proc = Start-Process $exePath -PassThru
Start-Sleep -Seconds 3

Add-Type @'
using System;
using System.Runtime.InteropServices;
public class WinAPIReso {
    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    [DllImport("user32.dll")]
    public static extern bool PrintWindow(IntPtr hWnd, IntPtr hdcBlt, int nFlags);
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }
}
'@

$rect = New-Object WinAPIReso+RECT
[WinAPIReso]::GetWindowRect($proc.MainWindowHandle, [ref]$rect)
$w = $rect.Right - $rect.Left
$h = $rect.Bottom - $rect.Top
Write-Host "Window bounds: $w x $h at ($($rect.Left), $($rect.Top))"

if ($w -gt 0 -and $h -gt 0) {
    $bmp = New-Object System.Drawing.Bitmap($w, $h)
    $gfx = [System.Drawing.Graphics]::FromImage($bmp)
    $hdc = $gfx.GetHdc()
    [WinAPIReso]::PrintWindow($proc.MainWindowHandle, $hdc, 2)
    $gfx.ReleaseHdc($hdc)
    $gfx.Dispose()
    $outPath = "C:\Users\171Studio\.gemini\antigravity\brain\a512c5b2-faa2-4a19-af6f-b21bbccd03db\171CleanReso_screenshot.png"
    $bmp.Save($outPath, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    Write-Host "SAVED: $outPath"
}

Stop-Process -Id $proc.Id -Force
