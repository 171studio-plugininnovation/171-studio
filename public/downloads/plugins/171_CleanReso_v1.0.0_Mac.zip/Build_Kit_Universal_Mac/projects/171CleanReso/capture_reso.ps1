Add-Type -AssemblyName System.Windows.Forms, System.Drawing

$proc = Start-Process 'C:\Users\171Studio\.gemini\antigravity\scratch\171CleanReso\build\171CleanReso_artefacts\Release\Standalone\171CleanReso.exe' -PassThru
Start-Sleep -Seconds 3

Add-Type @'
using System;
using System.Runtime.InteropServices;
public class WinSnap {
    [DllImport("user32.dll")]
    public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    [DllImport("user32.dll")]
    public static extern bool PrintWindow(IntPtr hWnd, IntPtr hdcBlt, int nFlags);
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }
}
'@

$targetHwnd = [IntPtr]::Zero
$targetRect = New-Object WinSnap+RECT

[WinSnap]::EnumWindows({
    param($hWnd, $lParam)
    $wpid = 0
    [WinSnap]::GetWindowThreadProcessId($hWnd, [ref]$wpid)
    if ($wpid -eq $proc.Id) {
        $r = New-Object WinSnap+RECT
        [WinSnap]::GetWindowRect($hWnd, [ref]$r)
        $w = $r.Right - $r.Left
        $h = $r.Bottom - $r.Top
        if ($w -gt 500 -and $h -gt 300) {
            $script:targetHwnd = $hWnd
            $script:targetRect = $r
            return $false
        }
    }
    return $true
}, [IntPtr]::Zero)

Write-Host "Target Hwnd: $targetHwnd"
if ($targetHwnd -ne [IntPtr]::Zero) {
    $w = $targetRect.Right - $targetRect.Left
    $h = $targetRect.Bottom - $targetRect.Top
    Write-Host "Target Rect: $w x $h"
    $bmp = New-Object System.Drawing.Bitmap($w, $h)
    $gfx = [System.Drawing.Graphics]::FromImage($bmp)
    $hdc = $gfx.GetHdc()
    [WinSnap]::PrintWindow($targetHwnd, $hdc, 2)
    $gfx.ReleaseHdc($hdc)
    $gfx.Dispose()
    $outPath = 'C:\Users\171Studio\.gemini\antigravity\brain\a512c5b2-faa2-4a19-af6f-b21bbccd03db\171CleanReso_screenshot.png'
    $bmp.Save($outPath, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    Write-Host "CAPTURED: $outPath"
}

Stop-Process -Id $proc.Id -Force
