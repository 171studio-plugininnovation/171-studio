# 🎚️ DOSSIER TECNICO DI TRASPOSIZIONE — 171 CLEANRESO
### Dynamic Resonance Suppressor & Anti-Harshness Engine per Apple macOS

**Progetto:** 171 CleanReso (`v1.0.0`)  
**Architettura:** Universal Binary Fat (`arm64` Apple Silicon M1-M4 + `x86_64` Intel)  
**Deployment Target Minimo:** macOS 11.0 Big Sur  
**Approvato da:** Il Direttore  
**Coordinamento:** `dsp-hire-manager`, `maag-air-resonance-specialist` & `apple-macos-engineer`  

---

## 1. SPECIFICHE FORMATI & METADATI APPLE AUDIOUNIT

| Parametro | Valore Configurato | Specifiche per DAW macOS |
|---|---|---|
| **AudioUnit Type** | `kAudioUnitType_Effect` (`'aufx'`) | Inseribile come soppressore di risonanze in **Logic Pro** e GarageBand |
| **Manufacturer Code** | `'171P'` | Conforme alle specifiche Apple (include almeno una maiuscola) |
| **Plugin Code / Subtype** | `'171S'` | Identificativo univoco a 4 caratteri per scansione AU |
| **Target Formati Mac** | **AU (`.component`)**, **VST3 (`.vst3`)**, **Standalone (`.app`)** | AU per Logic Pro; VST3 per Ableton, Cubase, Studio One, Reaper, FL |
| **Sicurezza Gatekeeper** | Hardened Runtime attivo | Flag `--options runtime` + entitlements JIT e Unsigned Memory |

---

## 2. MODELLAZIONE ALGORITMICA SU APPLE SILICON (M1–M4)

171 CleanReso implementa la retroingegneria scientifica di soppressione spettrale dinamica (standard Soothe2 / Spiff):

1. **Auto-Tracking Risonanze Dinamiche**:
   - Analisi a 64 bande dinamiche con rilevamento automatico delle frequenze risonanti parassite nel range vocale e strumentale (200 Hz - 14 kHz).
2. **Filtri Notch Adattivi a Fase Minima (ZDF)**:
   - I filtri a intaglio Zero-Delay Feedback si adattano in tempo reale senza introdurre distorsioni di fase o dispersione transiente.
3. **Modalità Soft / Hard e Silk Stage**:
   - Lo stadio `AnalogSilkStage` ammorbidisce le alte frequenze aggressive ripristinando la setosità analogica del segnale trattato.
4. **Vettorizzazione SIMD ARM64 NEON**:
   - I banchi di filtri paralleli operano tramite vettori SIMD a 128 bit, garantendo un'elaborazione in tempo reale a **zero latenza percepita**.

---

## 3. INTERFACCIA RETINA A 60 FPS (BOUTIQUE LUXURY)

- **Spectral Reso Visualizer a 60 FPS**: Spettrogramma con curve di attenuazione dinamica disegnate con rendering Metal/CoreGraphics nativo.
- **De-Harsh Reduction Meter**: Indicatore fotorealistico di attenuazione della durezza acustica.
- **Fader Verticali & Manopole Chicken Head**: Componenti serigrafati con finiture metalliche PBR.

---

## 4. COMANDO DI COMPILAZIONE RAPIDA

```bash
# Esegui da terminale Mac:
./scripts/build_171cleanreso_mac.sh

# Validazione Apple auval per Logic Pro:
auval -v aufx 171S 171P
```
