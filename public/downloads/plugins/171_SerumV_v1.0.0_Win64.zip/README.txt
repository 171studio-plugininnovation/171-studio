================================================================================
 171 STUDIO INNOVATIO - SCHEDA TECNICA & VERSIONE
================================================================================
PLUGIN:          171 SerumV (SerumV)
CATEGORIA:       OTT / Vintage Multiband Synth Dynamics & Color
VERSIONE:        1.0.0
DATA RILASCIO:   2026-10-27
ORA RILASCIO:    21:44:16 (CET)
TIMESTAMP:       2026-10-27T21:44:16+01:00
SVILUPPATORE:    171 Studio Innovatio
STATO:           Ufficiale di Produzione (v1.0.0)
FORMATI:         VST3, Standalone .EXE

DESCRIZIONE:
Processore di dinamica e colore armonico per synth e strumenti moderni, compressione upward/downward multibanda stile OTT e stadio saturazione analogica.

MODULO DSP ENGINE:
dsp171::MultibandDynamics

STORICO MODIFICHE & CHANGELOG:
[1.0.0] - 2026-10-27 21:44:16
- Rilascio ufficiale v1.0.0 unificato nella Master Suite 171 Studio Innovatio.
- Architettura a 64-bit zero-latency e antialiasing di precisione.
================================================================================
