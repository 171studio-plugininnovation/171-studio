======================================================================
  171PluginInnovation - CleanReso (v1.0.0 Studio Edition)
======================================================================

CONTENUTO DEL PACCHETTO:
  - 171CleanReso.exe          -> Applicazione Standalone per Windows (64-bit)
  - 171CleanReso.vst3/        -> Plugin VST3 a 64-bit per tutte le DAW
                                 (Cubase, Ableton, FL Studio, Reaper, Studio One, ecc.)
  - README.txt                -> Questo file informativo

CARATTERISTICHE DSP & ARCHITETTURA DI LABORATORIO:
  1. SOPPRESSIONE DINAMICA DELLE RISONANZE & ANTI-HARSHNESS:
     - Motore avanzato di rilevamento spettrale per picchi risonanti sgradevoli e asprezze vocali.
     - Mascheramento psicoacustico in tempo reale con preservazione assoluta dei transienti naturali.
     - Calibrazione armonica intelligente per ripulire tracce vocali, piatti, chitarre e synth.

  2. FILTRI NOTCH & BELL ZDF AD ALTA PRECISIONE:
     - Filtri Zero-Delay Feedback (ZDF) con fattore Q dinamico adattivo al contenuto sonoro.
     - Controlli Target, Depth, Speed, Q-Sharpness, Harshness ed Air per un controllo chirurgico.
     - Modalità Delta Listen per isolare e ascoltare esclusivamente le risonanze attenuate.

  3. ANALIZZATORE CRT DUAL-LAYER IN TEMPO REALE A 60 FPS:
     - Display a schermo incassato dorato con visualizzazione spettrale Pre/Post a contrasto cromatico.
     - Overlay delle curve di attenuazione dinamica con vetro antiriflesso.

  4. INTERFACCIA FOTOREALISTICA BOUTIQUE & RESIZE BAR:
     - 7 Manopole Neon rifinite con ghiere zigrinate in metallo scuro e badge anodizzati.
     - Angoli attivi per il ridimensionamento della finestra (Resizable Bar) fluido in proporzione.
     - Preset ComboBox metallico con freccia chevron dorata e pulsante Master Bypass con indicatore LED.

  5. SICUREZZA AUDIO & LATENZA:
     - True-Peak Limiter BS.1770-4 calibrato a -0.10 dBTP (nessun rischio di clipping inter-sample).
     - Architettura a bassissima latenza e calcolo a 64-bit in virgola mobile a doppia precisione.

GUIDA ALL'INSTALLAZIONE VST3:
  1. Copia l'intera cartella '171CleanReso.vst3' nella directory standard dei plugin VST3:
     C:\Program Files\Common Files\VST3\
  2. Apri la tua DAW ed effettua la scansione dei nuovi plugin VST3.
  3. L'applicazione '171CleanReso.exe' puo' essere utilizzata direttamente in modalita' Standalone.

(C) 2026 171PluginInnovation - 171 Studio. Tutti i diritti riservati.
======================================================================
