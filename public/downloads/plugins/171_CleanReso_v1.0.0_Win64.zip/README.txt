======================================================================
  171PluginInnovation - CleanReso (v1.0.0 Studio Edition)
  Transient-Aware Dynamic Resonance Suppressor & Spectral Shaper
======================================================================

CONTENUTO DEL PACCHETTO:
  - 171CleanReso.vst3/        -> Plugin VST3 a 64-bit per tutte le DAW
                                 (Cubase, Ableton, FL Studio, Reaper, Studio One, Pro Tools via VST3, ecc.)
  - 171CleanReso.exe          -> Applicazione Standalone Windows nativa (64-bit)
  - 171CleanReso_Final_GUI.png-> Snapshot fotorealistico dell'interfaccia grafica
  - README.txt                -> Manuale tecnico e guida all'uso

======================================================================
ARCHITETTURA DSP & INNOVAZIONI:
======================================================================
1. TRANSIENT SHIELD (HERO PROTECTION):
   - A differenza dei tradizionali soppressori spettrali che scambiano
     l'attacco dei colpi per risonanze dannose e smussano i transienti (time-smearing),
     171CleanReso isola la componente impulsiva tramite inseguitore balistico a doppio inviluppo.
   - I transienti di batteria, consonanti vocali e plettrate passano intatti al 100%,
     mantenendo intatto il punch e la definizione della traccia.

2. FILTRI ZERO-DELAY FEEDBACK (ZDF) A 64-BIT:
   - 32 bande logaritmiche SVF Cytomic a topologia ZDF con risoluzione a 64-bit.
   - Ponderazione psicoacustica ISO 226 focalizzata sull'asprezza del canale uditivo (2.5 kHz - 6.5 kHz).
   - Zero chiamate trascendenti pesanti nel realtime audio thread con look-up matematico ad alta efficienza.

3. STADIO ANALOG SILK & AIR:
   - Post-equalizzazione Baxandall High-Air a 12 kHz abbinata a saturazione a seconda armonica valvolare,
     per lucidare ed addolcire le alte frequenze ripulite.

4. TRUE-PEAK LIMITER CONFORME A ITU-R BS.1770-4:
   - Limiter di sicurezza a lookahead deterministico con ricostruzione inter-sample sinc 4x (32 tap Kaiser beta=7.0).
   - Ceiling rigorosamente vincolato a -0.10 dBTP (garanzia assoluta contro inter-sample peaks e clip da conversione D/A).
   - Stereo Linking coerente al 100% per preservare il centro fantasma (zero stereo yawing).

======================================================================
CONTROLLI E FUNZIONALITA':
======================================================================
- SOFT / HARD TOGGLE: 
  * SOFT: Intervento morbido, organico e trasparente per voci e master bus.
  * HARD: Intervento chirurgico rapido per piatti metallici e sibilanti sgradevoli.
- PRESET SELECTOR: 8 preset calibrati di laboratorio:
  * 01 | Vocal De-Harsh & Sibilance
  * 02 | Snare Ring & Boxiness Kill
  * 03 | Acoustic Guitar Resonance Tamer
  * 04 | Harsh Cymbals & Overhead Soother
  * 05 | Master Bus Harshness Tamer
  * 06 | Electric Guitar Fizz Eliminator
  * 07 | Synth Resonance Shaper
  * 08 | Surgical Resonance Hunter
- DELTA LISTEN: Ascolto isolato delle sole frequenze aspre e risonanze rimosse.
- MASTER BYPASS: Crossfade continuo a 15 ms pop-free con compensazione di latenza dry/wet bit-exact.
- DE-HARSH (0% - 100%): Intensità della soppressione dinamica.
- TARGET FREQ (1.0 kHz - 12.0 kHz): Frequenza centrale della risonanza da domare.
- SELECTIVITY (0% - 100%): Fattore Q selettivo tra armoniche musicali e risonanze dannose.
- TRANS SHIELD (0% - 100%): Manopola Hero centrale per proteggere il punch dai filtri notch.
- ANALOG SILK (0% - 100%): Lucidatura e setosità analogica sulle alte frequenze.
- MIX (0% - 100%): Controllo Dry/Wet coerente.
- OUTPUT (-18 dB a +12 dB): Trim di guadagno d'uscita.

======================================================================
GUIDA ALL'INSTALLAZIONE:
======================================================================
- VST3 (DAW):
  Il plugin e' gia' installato e pronto all'uso in:
  C:\Program Files\Common Files\VST3\171CleanReso.vst3
  Riavvia o effettua il rescan VST3 nella tua DAW (Ableton, FL Studio, Cubase, Studio One, Reaper).

- STANDALONE:
  Avvia direttamente '171CleanReso.exe' per il funzionamento autonomo senza DAW.

(C) 2026 171PluginInnovation - 171 Studio. Tutti i diritti riservati.
