======================================================================
  171PluginInnovation - PerfectPre (v1.0.0 Flagship Edition)
======================================================================

CONTENUTO DEL PACCHETTO:
  - PerfectPre.exe            -> Applicazione Standalone per Windows (64-bit)
  - PerfectPre.vst3/          -> Plugin VST3 a 64-bit per tutte le DAW
                                 (Cubase, Ableton, FL Studio, Reaper, Studio One, ecc.)
  - PerfectPre_GUI_Preview.png-> Snapshot ufficiale interfaccia utente hardware
  - README.txt                -> Questo file informativo

CARATTERISTICHE DSP & ARCHITETTURA DI LABORATORIO:
  1. PREAMP A 4 CARATTERI ANALOGICI:
     - 01: British Vintage (Neve 1073 Class-A)
     - 02: American Tube (Valvole 6L6 / Triodo ad alta dinamica)
     - 03: Vintage Germanium (Fuzz e saturazione armonica ricca)
     - 04: Clean Studio (Trasparente wire-with-gain a bassissima distorsione)

  2. STADIO DIODI ASIMMETRICO INDIPENDENTE:
     - Clipping analogico a diodi asimmetrici ADAA a doppio ordine con spia Ruby Jewel Lamp.

  3. EQUALIZZATORE NEVE 1073 CONCENTRIC:
     - HPF a 5 frequenze (Off, 50, 80, 160, 300 Hz) con manopola Marconi Blue.
     - Low Shelf concentric a doppio potenziometro (35, 60, 110, 220 Hz + Boost/Cut -16/+16 dB).
     - Mid Peak concentric (360, 700, 1.6k, 3.2k, 4.8k, 7.2k Hz + Boost/Cut -18/+18 dB).
     - High Shelf fisso a 12 kHz (+/- 16 dB).
     - Tasto Neve quadrato a due stati EQ IN/OUT.

  4. SPL DIFFERENTIAL PHASE DE-ESSER:
     - Cancellazione di fase differenziale per sibilanti naturali e trasparenti.
     - Ladder Meter a 12 segmenti LED e telemetria CRT dinamica in tempo reale a 60 FPS.
     - Selettore Maschile/Femminile (6.4 kHz / 7.6 kHz) e modalità Delta Listen.

  5. INTERFACCIA GRAFICA FOTOREALISTICA & RESIZE BAR:
     - GUI ad alta definizione con angoli di ridimensionamento fluidi (Resizable Bar).
     - Componenti vettoriali 3D cesellati in metallo e vetro studio antiriflesso.

  6. SICUREZZA AUDIO & LATENZA:
     - BS.1770-4 True-Peak Limiter a -0.10 dBTP (zero clipping inter-sample).
     - Zero-Latency 64-bit Dual-Precision.
     - Spia Jewel Lamp Smeraldo / Rubino per monitorare lo stato operativo.

GUIDA ALL'INSTALLAZIONE VST3:
  1. Copia l'intera cartella 'PerfectPre.vst3' nella directory standard dei plugin VST3:
     C:\Program Files\Common Files\VST3\
  2. Apri la tua DAW ed effettua la scansione dei nuovi plugin VST3.
  3. L'applicazione 'PerfectPre.exe' puo' essere lanciata direttamente senza DAW.

(C) 2026 171PluginInnovation - 171 Studio. Tutti i diritti riservati.
======================================================================
