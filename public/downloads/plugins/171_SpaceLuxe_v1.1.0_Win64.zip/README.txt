======================================================================
  171PluginInnovation - 171SpaceLuxe (v1.0.0 Gold Master Edition)
======================================================================

CONTENUTO DEL PACCHETTO:
  - 171SpaceLuxe.exe           -> Applicazione Standalone per Windows (64-bit)
  - 171SpaceLuxe.vst3/         -> Plugin VST3 a 64-bit per tutte le DAW
                                  (Cubase, Ableton, FL Studio, Reaper, Studio One, Bitwig, ecc.)
  - 171SpaceLuxe_GUI_Preview.png-> Snapshot ufficiale interfaccia utente hardware (1100x680)
  - README.txt                 -> Questo file informativo
  - README_VERSIONE.txt        -> Registro tecnico di versione
  - VERSION.json               -> Metadati macchina per DAW e Suite Manager

CARATTERISTICHE DSP & ARCHITETTURA DI LABORATORIO:
  1. REVERB CORE FDN-16 LOSSLESS:
     - 16 linee di ritardo mutualmente prime per una densita modale priva di risonanze metalliche.
     - Matrice Householder esatta: preservazione matematica dell'energia, linearita e stabilita assoluta.
     - Pre-Delay sincronizzabile e 6-tap Early Reflections stereo-allargate.

  2. SMART DUCKING DINAMICO:
     - Analizzatore di inviluppo integrato che attenua la coda wet durante il fraseggio solista.
     - Ripristina automaticamente lo spazio durante le pause e i silenzi, eliminando il mud nel mix.

  3. HARMONIC SHIMMER & HIGH AIR:
     - Pitch-shifter +1 ottava con soft-clipping analogico per riverberi eterei celestiali.
     - Low Warmth shelf e High Damping ZDF per modellare il calore vintage analogico.

  4. MONO-MAKER ZDF SVF:
     - State Variable Filter a zero ritardo (12 dB/oct) sul canale Side del mix stereo.
     - Garantisce sub-bass 100% mono e centrato (mono compatibility da vinile e club).

  5. HARDWARE LOOK & FEEL BOUTIQUE:
     - Telaio in alluminio anodizzato blu cobalto scuro con finitura spazzolata a mano.
     - Display CRT isometrico Waterfall 3D a 60 FPS con fosfori reattivi.
     - Jewel lamps Diamond-Cut con volumetric bloom (POWER Rubino, SMART DUCK Ambra).
     - Manopole tornite in metallo scanalato con serigrafia DIN 1451 Mittelschrift.

GUIDA ALL'INSTALLAZIONE VST3:
  1. La suite include lo script 'scripts/deploy_all.ps1' che registra automaticamente
     il plugin creando le giunzioni di sistema in C:\Program Files\Common Files\VST3\
  2. Apri la tua DAW ed effettua la scansione dei nuovi plugin VST3.
  3. L'applicazione '171SpaceLuxe.exe' puo' essere lanciata direttamente senza DAW.

(C) 2026 171PluginInnovation - 171 Studio. Tutti i diritti riservati.
======================================================================
