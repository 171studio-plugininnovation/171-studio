================================================================================
 171 STUDIO INNOVATIO - SCHEDA TECNICA & VERSIONE
================================================================================
PLUGIN:          171 EasyVoice (171EasyVoice)
CATEGORIA:       All-in-One Vocal Channel Strip
VERSIONE:        1.0.1
DATA RILASCIO:   2026-10-28
ORA RILASCIO:    18:41:14 (CET)
TIMESTAMP:       2026-10-28T18:41:14+01:00
SVILUPPATORE:    171 Studio Innovatio
STATO:           Ufficiale di Produzione (v1.0.1)
FORMATI:         VST3, Standalone .EXE

DESCRIZIONE:
Channel strip vocale integrato con De-Esser intelligente, Compressore Ottico/VCA, Equalizzatore Air/Baxandall e Limiter con visualizzazione real-time 60 FPS.

MODULO DSP ENGINE:
dsp171::VocalStrip

STORICO MODIFICHE & CHANGELOG:
[1.0.1] - 2026-10-28 18:41:14
- Overhaul SSL G-Series EQ Cytomic ZDF SVF, fix NLS preamp console coloration and smooth THD, fix LA-2A HF/Flat sidechain and T4B optical release, add visible De-Esser Freq knob, fix bypass button black overlay, calibrate Preamp and Air Gain serigraphs, and ensure bit-exact 0.00 dB unity gain on insertion

[1.0.0] - 2026-10-27 21:44:16
- Rilascio ufficiale unificato Suite 171 Studio Innovatio v1.0 con standard DSP & GUI professionali.

================================================================================
