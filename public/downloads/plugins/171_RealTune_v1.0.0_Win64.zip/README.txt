======================================================================
  171PluginInnovation - 171RealTune (v1.0.0 Gold Master Edition)
======================================================================

CONTENUTO DEL PACCHETTO:
  - 171RealTune.exe           -> Applicazione Standalone per Windows (64-bit)
  - 171RealTune.vst3/         -> Plugin VST3 a 64-bit per tutte le DAW
                                 (Cubase, Ableton, FL Studio, Reaper, Studio One, ecc.)
  - 171RealTune_GUI_Preview.png-> Snapshot ufficiale interfaccia utente hardware (1180x720)
  - README.txt                -> Questo file informativo

CARATTERISTICHE DSP & ARCHITETTURA DI LABORATORIO:
  1. DUAL REVERSE-ENGINEERED PITCH ENGINES (Auto-Tune Pro & Waves Tune RT):
     - Classic Mode DSP (Auto-Tune 5): snap istantaneo della frequenza fondamentale a 0 ms.
     - Modern ZDF Mode: transizione continua con curva polinomiale quintica C^2 (Smootherstep).
     - Antares Flex-Tune: attenuazione ad arco di coseno (Von Hann) per proteggere note espressive.
     - Antares Throat Length: modellazione fisica del tratto vocale (50%-150%) con catena allpass bilineare.
     - Waves Tune RT Note Transition: glide temporale regolabile indipendente (0-800 ms).
     - Waves Tune RT Deadband Tolerance: finestra di tolleranza di centesimi (0-40 cents).
     - Dual-Path Natural Vibrato: estrazione a 5.8 Hz con controllo depth 0-200% (soppressione o retention).
     - 3-Stage DPLL con Isteresi SNR: tracking ultra-stabile senza salti d'ottava anche su consonanti.

  2. SEZIONE HARDWARE BOUTIQUE & SELEZIONE SCALE:
     - Keyboard Matrix interattiva a 12 tasti (Bypass / Block note individuali).
     - 8 Preset d'artista di fabbrica integrati.
     - Formant Shift (-12 a +12 semitoni) con conservazione naturale del timbro vocale.
     - Stereo Width (0% mono a 200% super-wide con decorrelatore psicoacustico 100% mono cancellation-free).

  3. TELEMETRIA LOCK-FREE & DISPLAY A 60 FPS:
     - Pitch visualizer CRT a scorrimento temporale continuo.
     - Jewel Lamp DPLL a tre stati (Grigio = Unlocked, Ambra = Acquiring, Smeraldo = Locked).
     - Cents Deviation meter galvanometrico a risposta balistica rapida.

  4. SICUREZZA AUDIO & LATENZA:
     - True-Peak Limiter BS.1770-4 calibrato a -0.10 dBTP (zero inter-sample clipping).
     - Zero allocazioni sull'audio thread (hard real-time deterministic safety).

GUIDA ALL'INSTALLAZIONE VST3:
  1. Copia l'intera cartella '171RealTune.vst3' nella directory standard dei plugin VST3:
     C:\Program Files\Common Files\VST3\
  2. Apri la tua DAW ed effettua la scansione dei nuovi plugin VST3.
  3. L'applicazione '171RealTune.exe' puo' essere lanciata direttamente senza DAW.

(C) 2026 171PluginInnovation - 171 Studio. Tutti i diritti riservati.
======================================================================
