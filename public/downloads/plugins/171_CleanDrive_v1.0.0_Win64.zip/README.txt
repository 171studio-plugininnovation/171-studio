======================================================================
  171PluginInnovation - CleanDrive (v1.0.0 Studio Edition)
======================================================================

CONTENUTO DEL PACCHETTO:
  - 171CleanDrive.exe         -> Applicazione Standalone per Windows (64-bit)
  - 171CleanDrive.vst3/       -> Plugin VST3 a 64-bit per tutte le DAW
                                 (Cubase, Ableton, FL Studio, Reaper, Studio One, ecc.)
  - README.txt                -> Questo file informativo

CARATTERISTICHE DSP & ARCHITETTURA DI LABORATORIO:
  1. TRANSIENT-AWARE DUAL SATURATOR:
     - Splitting dinamico adattivo tra transiente e corpo del segnale sonoro.
     - Controllo indipendente del Punch per preservare l'impatto ritmico e la definizione.
     - Saturazione calda e musicale su valvole e nastro senza impastare il mix.

  2. CROSSOVER E CONTROLLI TIMBRICI LINEAR-PHASE:
     - Filtri Linkwitz-Riley LR-4 a fase lineare per eliminare qualsiasi cancellazione di fase.
     - Stadio Warmth & Tilt EQ per scolpire il bilanciamento frequenziale analogico.
     - Controllo Sensibilità (Sensitivity) dinamico per calibrare l'innesco della distorsione.

  3. VISUALIZZATORE SPETTRALE CRT RETROILLUMINATO A 60 FPS:
     - Display a fosfori dorati con tracciamento istantaneo dell'energia e del ducking.
     - Analizzatore spettrale hardware ad alta risoluzione con vetro polarizzato.

  4. INTERFACCIA FOTOREALISTICA BOUTIQUE & RESIZE BAR:
     - 7 Manopole Neon con ghiera in alluminio tornito CNC, alone multi-stadio e badge numerici anodizzati.
     - Supporto nativo al ridimensionamento fluido (Resizable Bar) con aspect ratio bloccato.
     - LookAndFeel metallico dorato con pulsante Master Bypass analogico e LED reattivo.

  5. SICUREZZA AUDIO & LATENZA:
     - True-Peak Limiter BS.1770-4 tarato a -0.10 dBTP (zero inter-sample clipping).
     - Zero-Latency pura (0 campioni di latenza introdotti) a doppia precisione 64-bit.

GUIDA ALL'INSTALLAZIONE VST3:
  1. Copia l'intera cartella '171CleanDrive.vst3' nella directory standard dei plugin VST3:
     C:\Program Files\Common Files\VST3\
  2. Apri la tua DAW ed effettua la scansione dei nuovi plugin VST3.
  3. L'applicazione '171CleanDrive.exe' puo' essere avviata direttamente senza DAW.

(C) 2026 171PluginInnovation - 171 Studio. Tutti i diritti riservati.
======================================================================
