# Modulo 05: Ciclo di Vita DAW & Versioning Preset
**Plugin:** 171CleanDrive (Transient-Aware Dual Saturator)  
**Standard:** VST3 / AU Standard Architecture

---

## 1. Gestione del Cambio di Sample Rate a Caldo

Le DAW (Reaper, Pro Tools, Logic Pro, Cubase, Studio One, Ableton Live, FL Studio) possono variare la frequenza di campionamento ($44.1$, $48$, $88.2$, $96$, $192\text{ kHz}$) o la dimensione del buffer in qualsiasi istante.

### Procedura Obbligatoria in `prepareToPlay(double sampleRate, int samplesPerBlock)`:
1. Validazione sample rate ($f_s \ge 22050.0$).
2. Ricalcolo di tutti i coefficienti dipendenti da $f_s$:
   * Costanti di tempo dei doppi inviluppi: $\alpha = 1.0 - \exp\left(-\frac{1.0}{\tau \cdot f_s}\right)$
   * Costante di tempo del bias drift del trasformatore ($\tau = 80\text{ ms}$)
   * Coefficiente del filtro DC-Blocker a 10 Hz
   * Perno bilanciato ZDF Tilt Filter a 850 Hz con pre-warping
3. Riconfigurazione di tutte le rampe di smoothing dei parametri:
   * 7 manopole con rampa a $20\text{ ms}$ (`smoothedDrive`, `smoothedPunch`, ecc.)
   * Rampa di crossfade del Bypass a $15\text{ ms}$ (`smoothedBypass`)
4. Azzeramento (`reset()`) di tutte le memorie interne degli integratori per evitare burst acustici o transitori fantasma.

---

## 2. Versioning e Retrocompatibilità dello Stato APVTS

I metodi `getStateInformation()` e `setStateInformation()` devono impiegare la serializzazione XML dell'albero `juce::AudioProcessorValueTreeState` con marcatura di versione:

### Codice Obbligatorio in `PluginProcessor.cpp`:
```cpp
void AudioPluginAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    auto state = apvts.copyState();
    state.setProperty("version", 2, nullptr);
    state.setProperty("currentPreset", currentProgramIndex, nullptr);
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void AudioPluginAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType())) {
        const int version = xmlState->getIntAttribute("version", 1);
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
        currentProgramIndex = apvts.state.getProperty("currentPreset", 0);
        
        // Se si caricano vecchi progetti creati prima del parametro bypass
        if (version < 2) {
            if (auto* param = apvts.getParameter("bypass")) {
                param->setValueNotifyingHost(0.0f); // Default attivo
            }
        }
    }
}
```
* **Garanzia:** I progetti utente salvati con versioni precedenti si aprono perfettamente senza perdita di impostazioni o reset indesiderati.
