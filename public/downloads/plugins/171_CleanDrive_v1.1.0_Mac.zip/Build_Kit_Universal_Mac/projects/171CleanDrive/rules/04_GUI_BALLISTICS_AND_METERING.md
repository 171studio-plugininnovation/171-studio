# Modulo 04: Balistica Grafica & Metering
**Plugin:** 171CleanDrive (Transient-Aware Dual Saturator)  
**Standard:** IEC 60268-17 (Analog VU-Meter) & 60 FPS Lock-Free Architecture

---

## 1. Disaccoppiamento Audio/GUI a 60 FPS

* Il thread audio (`processBlock`) e il thread grafico (`timerCallback`) sono rigorosamente disaccoppiati.
* La struttura `dsp171::VisualFrame` veicola:
  * Forme d'onda audio d'ingresso e d'uscita (decimate);
  * Livelli RMS Stereo ($L$ e $R$) e Picco Stereo;
  * Rapporti istantanei di energia Transient Ratio e Tonal Body Ratio.
* Il timer della GUI gira a $60\text{ Hz}$ e svuota la FIFO senza mai imporre attese al DSP.

---

## 2. Balistica Meccanica Reale dell'Ago VU Meter (IEC 60268-17)

L'ago del visualizzatore VU Meter riproduce la fisica del galvanometro a bobina mobile (massa inerziale, costante elastica di richiamo e smorzamento viscoso).

### Equazione del 2° Ordine con Smorzamento Controllato:
$$\frac{d^2 \theta}{dt^2} + 2 \zeta \omega_n \frac{d\theta}{dt} + \omega_n^2 (\theta - \theta_{\text{target}}) = 0$$

* **Costanti di Calibrazione:**
  * Coefficiente di smorzamento: $\zeta = 0.707$
  * Frequenza propria naturale: $\omega_n \approx 11.5\text{ rad/s}$
  * Tempo di salita: $300\text{ ms}$ per raggiungere il $99\%$ della deflessione
  * Calibrazione standard: $0\text{ VU} = -18\text{ dBFS}$

---

## 3. Tripla Modalità di Visualizzazione (Click-to-Switch)

Cliccando sullo schermo del plugin si cicla istantaneamente tra:
1. **CRT Golden Oscilloscope:** Visualizzazione in tempo reale a doppio tracciato (ingresso azzurro ciano / uscita ambra dorata) con decadimento fosforico continuo.
2. **Stereo Analog VU Meter:** Doppia scala analogica IEC con aghi reattivi indipendenti per canale sinistro e destro.
3. **Stereo LED Peak/RMS Meter:** Doppia colonna LED a 12 segmenti (Verde, Giallo, Rosso) con Peak Decay di $22\text{ dB/s}$ e Peak Hold a $1.6\text{ s}$.

---

## 4. Meter Continuo Transient Punch & Tonal Body (Attivo in Tutte le Pagine)

In basso al display centrale, è sempre visibile e attivo in **tutte e tre le modalità**:
* Barra orizzontale superiore: **TRANSIENT PUNCH** (indicatore al neon rosso/arancione per l'attività dei transienti);
* Barra orizzontale inferiore: **TONAL BODY** (indicatore al neon ambra/oro per la corposità delle armoniche tonali).

---

## 5. Pulsante Master Bypass con Indicatore LED

* Collocato nella console superiore centrato direttamente sotto la scritta serigrafata `171PLUGIN INNOVATION` (Centro $X=780$, $X=732..828$), alla **stessa altezza del selettore Preset** ($Y=88$, $H=26$).
* **Stato Attivo:** LED verde smeraldo acceso con doppio bloom al neon; testo `BYPASS` argentato zincato.
* **Stato Bypass:** LED rosso neon incandescente di allerta; bordo rosso vivo; testo `BYPASS` illuminato in rosso vivo; audio crossfaded in modo totalmente trasparente.
