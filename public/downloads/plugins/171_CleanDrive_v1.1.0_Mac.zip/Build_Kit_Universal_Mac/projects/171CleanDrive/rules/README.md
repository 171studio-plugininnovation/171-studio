# 171CleanDrive – Regole & Linee Guida di Ingegneria DSP
**Target:** Agente di Sviluppo Software, Architettura DSP e Ingegneria Grafica  
**Progetto:** 171CleanDrive (Transient-Aware Dual Saturator) VST3 / Standalone  
**Standard Tecnico:** Pro Audio Studio Grade (FabFilter, Soundtoys, UAD, Plugin Alliance, Waves)

---

## Indice dei Moduli di Regola nella Cartella `rules/`

L'agente al lavoro su questo plugin **DEVE verificare e rispettare rigorosamente** i seguenti moduli di specifica:

1. [01_REALTIME_THREAD_SAFETY.md](file:///C:/Users/171Studio/.gemini/antigravity/scratch/171CleanDrive/rules/01_REALTIME_THREAD_SAFETY.md)
   * Le regole ferree del thread audio (`processBlock`): zero allocazioni heap, lock-free FIFO a 512 frame, protezione da numeri denormali (`juce::ScopedNoDenormals`), immunità a `NaN`/divisioni per zero e rampa di dissolvenza Bypass a 15 ms senza pop/click.
2. [02_TRANSIENT_TONAL_DSP.md](file:///C:/Users/171Studio/.gemini/antigravity/scratch/171CleanDrive/rules/02_TRANSIENT_TONAL_DSP.md)
   * Separazione dinamica a fase zero transiente/corpo tonale ($x_{\text{trans}} + x_{\text{tonal}} \equiv x$), doppio inviluppo veloce/lento con costante di tempo adattiva alla frequenza di campionamento e perno ZDF a 850 Hz.
3. [03_ADAA2_AND_SAFETY_CEILING.md](file:///C:/Users/171Studio/.gemini/antigravity/scratch/171CleanDrive/rules/03_ADAA2_AND_SAFETY_CEILING.md)
   * Saturatore ADAA-2 a 64-bit con antiderivata analitica di 2° ordine sui transienti, simulazione di saturatore a trasformatore con armoniche pari $x \cdot |x|$ e bias drift magnetico sul canale tonale, e **Analog Safety Brickwall Soft-Ceiling a $-0.09\text{ dBFS}$ ($0.9900$)** per azzerare qualsiasi inter-sample over e digital clipping.
4. [04_GUI_BALLISTICS_AND_METERING.md](file:///C:/Users/171Studio/.gemini/antigravity/scratch/171CleanDrive/rules/04_GUI_BALLISTICS_AND_METERING.md)
   * Rendering grafico a 60 FPS disaccoppiato da Lock-Free SPSC FIFO, triplo visualizzatore (CRT Gold Oscilloscope, Analog VU Meter IEC 60268-17 al 2° ordine smorzato $\zeta=0.707$, Stereo Peak/RMS LED Meter), Meter continuo di bilanciamento Transient Punch & Tonal Body attivo in ogni pagina, e Tasto Master Bypass con indicatore LED reattivo (Verde/Rosso).
5. [05_DAW_LIFECYCLE_AND_VERSIONING.md](file:///C:/Users/171Studio/.gemini/antigravity/scratch/171CleanDrive/rules/05_DAW_LIFECYCLE_AND_VERSIONING.md)
   * Gestione del ciclo di vita della DAW, ricalcolo costanti al cambio a caldo di sample rate in `prepareToPlay()`, smoothing a 20 ms anti-zipper su tutte le 7 manopole e versioning dello stato APVTS in formato XML per retrocompatibilità assicurata.

---

## Tabella dei Vincoli Fondamentali di Progetto

| Vincolo | Requisito Assoluto | Implementazione Verificata nel Codice |
| :--- | :--- | :--- |
| **Allocazioni Heap** | `0` byte in `processBlock()` | Tutti i buffer dimensionati in `prepareToPlay()` |
| **Denormali (FTZ/DAZ)** | `ScopedNoDenormals` attivo | Presente all'inizio di `processBlock()` |
| **Smoothing Parametri** | $20\text{ ms}$ rampa continua | `juce::SmoothedValue` su tutte le 7 manopole |
| **Bypass Pop-Free** | Dissolvenza incrociata $15\text{ ms}$ | `smoothedBypass` sample-by-sample linear crossfade |
| **Separazione Fase** | Somma coerente $1.000$ | $x_{\text{trans}} + x_{\text{tonal}} = x \cdot w + x \cdot (1-w) \equiv x$ |
| **Anti-Aliasing Transienti** | ADAA-2 a 64-bit | $F_1(x)$ e $F_2(x)$ antiderivative continue con fallback $\epsilon=10^{-4}$ |
| **Saturazione Tonale** | 2ª armonica + Bias Drift | Modulazione $x \cdot \|x\|$, bias drift $80\text{ ms}$ e DC-Blocker $10\text{ Hz}$ |
| **Tetto Massimo Picco** | $\le -0.09\text{ dBFS}$ ($0.9900$) | Analog Safety Soft-Ceiling asintotico su $x > 0.85$ |
| **Balistica VU Meter** | Standard IEC 60268-17 | Equazione differenziale 2° ordine smorzata ($300\text{ ms}$, $\zeta=0.707$) |
| **Metering Continuo** | Transient & Tonal su tutti i display | Disegnato ed elaborato a 60 FPS in Scope, VU e LED |
