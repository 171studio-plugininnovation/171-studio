# Modulo 03: Doppia Saturazione ADAA-2 & Safety Soft-Ceiling
**Plugin:** 171CleanDrive (Transient-Aware Dual Saturator)  
**Standard:** Pro Audio Saturation & Inter-Sample Peak Prevention

---

## 1. Canale Transiente: ADAA-2 a 64-bit (Anti-Derivative Anti-Aliasing)

La saturazione non lineare sui picchi transitori genera armoniche ad altissima frequenza che, se ripiegate indietro (aliasing), creano una timbrica metallica e artificiale.
Per azzerare l'aliasing in banda udibile senza introdurre la latenza e lo sfasamento dei filtri di oversampling FIR:

* **Funzione di Soft-Clipping Cubico:**
  $$f(x) = \begin{cases}
  \frac{2}{3} & \text{se } x > 1 \\
  -\frac{2}{3} & \text{se } x < -1 \\
  x - \frac{x^3}{3} & \text{se } |x| \le 1
  \end{cases}$$

* **Prima Antiderivata $F_1(x) = \int f(x) dx$:**
  $$F_1(x) = \frac{x^2}{2} - \frac{x^4}{12} \quad (\text{per } |x| \le 1)$$

* **Seconda Antiderivata $F_2(x) = \iint f(x) dx^2$:**
  $$F_2(x) = \frac{x^3}{6} - \frac{x^5}{60} \quad (\text{per } |x| \le 1)$$

* **Formulazione ADAA-2 a Doppia Differenza:**
  $$y[n] = \frac{2}{x_0 - x_2} \left[ \frac{F_2(x_0) - F_2(x_1)}{x_0 - x_1} - \frac{F_2(x_1) - F_2(x_2)}{x_1 - x_2} \right]$$

* **Fallback Epsilon $\epsilon = 1.0 \times 10^{-4}$:**
  * Se $|x_0 - x_2| < \epsilon$, si effettua il fallback continuo su ADAA-1 $\frac{F_1(x_0) - F_1(x_1)}{x_0 - x_1}$ o sulla media analitica $f\left(\frac{x_0 + x_1}{2}\right)$, eliminando le instabilità numeriche a basse frequenze.

---

## 2. Canale Tonale: Saturatore a Trasformatore con Bias Drift Magnetico

Per conferire corpo analogico, calore valvolare e spessore armonico alle code tonali:

1. **Iniezione di Armonica Pari (Calore Morbido):**
   * Generazione di 2ª armonica pulita senza offset DC:
     $$\text{evenHarmonic} = \text{warmth} \cdot 0.45 \cdot (x \cdot |x|)$$
2. **Polarizzazione Dinamica del Nucleo (Magnetic Core Hysteresis):**
   * Simulazione della densità di flusso magnetico residuo del ferro tramite costante di tempo di drift $\tau \approx 80\text{ ms}$:
     $$\text{dynamicBias} \leftarrow \text{dynamicBias} + \alpha_{\text{drift}} \cdot (\text{targetBias} - \text{dynamicBias})$$
3. **Curva di Saturazione Iperbolica:**
   $$\text{saturated} = \tanh(x_{\text{driven}} + \text{evenHarmonic} + \text{dynamicBias})$$
4. **Filtro DC-Blocker IIR (10 Hz):**
   * Rimozione di qualsiasi deriva continua residua a frequenza sub-udibile:
     $$y[n] = x[n] - x[n-1] + r_{\text{DC}} \cdot y[n-1]$$

---

## 3. Analog Safety Brickwall Soft-Ceiling (-0.09 dBFS)

Per garantire che il plugin non clippi MAI digitalmente né superi lo $0\text{ dBFS}$ inter-sample, anche con tutti i controlli al massimo ($100\%$ Drive, $+2\text{ dB}$ Punch, $+12\text{ dB}$ Output Gain):

* **Soglia di Intervento:** Lineare per segnali nominali fino a $|x| \le 0.85$ ($-1.41\text{ dBFS}$).
* **Curva a Gomito Morbido:** Asintotica al tetto rigoroso di **$0.9900$ ($-0.09\text{ dBFS}$)**:
  $$\text{se } |x| > 0.85 \implies y = \operatorname{sgn}(x) \cdot \left[ 0.85 + 0.14 \cdot \tanh\left(\frac{|x| - 0.85}{0.14}\right) \right]$$
* **Risultato:** Nessun campione a $1.000$ o superiore; assenza totale di clip digitale, preservando il carattere rotondo delle macchine analogiche di mastering.
