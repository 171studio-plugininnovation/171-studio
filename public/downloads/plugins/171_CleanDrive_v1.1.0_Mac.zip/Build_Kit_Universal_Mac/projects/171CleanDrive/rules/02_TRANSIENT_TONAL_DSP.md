# Modulo 02: Separazione Dinamica Transiente / Corpo Tonale
**Plugin:** 171CleanDrive (Transient-Aware Dual Saturator)  
**Standard:** Pro Audio DSP

---

## 1. La Catena di Elaborazione (Signal Flow)

```
[Audio In L/R]
      |
      v
[1. Transient Splitter] ----------> Doppio inviluppo veloce (~1.2 ms) e lento (~30 ms)
      |                    |
      v                    v
 [Transient Path]     [Tonal Body Path]
 (ADAA-2 64-bit Soft) (Transformer Tube Sat + Bias Drift)
      \                    /
       \                  /
        v                v
[2. Coherent Phase Recombination] ---> Somma lineare identica all'originale (Fase 0 dB)
      |
      v
[3. ZDF Tilt Filter] --------------> Filtro Zero-Delay Feedback a perno 850 Hz (+/- 6 dB)
      |
      v
[4. Mix & Safety Soft-Ceiling] ------> Blending Dry/Wet e Brickwall asintotico a -0.09 dBFS
      |
      v
[5. Smoothed Bypass Crossfade] ------> Dissolvenza lineare a 15 ms verso il segnale Dry
      |
      v
[Audio Out L/R]
```

---

## 2. Conservazione Rigorosa di Fase ed Energia (Zero Comb-Filtering)

Per scongiurare qualsiasi fenomeno di comb-filtering o cancellazione di fase quando il segnale viene ricombinato o mixato Dry/Wet:
* Il segnale d'ingresso $x[n]$ è moltiplicato per una coppia di pesi complementari:
  $$x_{\text{trans}}[n] = x[n] \cdot W_{\text{trans}}[n]$$
  $$x_{\text{tonal}}[n] = x[n] \cdot (1.0 - W_{\text{trans}}[n])$$
* Poiché $W_{\text{trans}} + (1.0 - W_{\text{trans}}) \equiv 1.000$, la somma $x_{\text{trans}} + x_{\text{tonal}}$ equivale esattamente al segnale grezzo originale in assenza di saturazione.

---

## 3. Calcolo dell'Inviluppo e Risposta alle Basse Frequenze

* **Inviluppo Veloce:**
  * Attacco: $\tau_{\text{att}} = 1.2\text{ ms}$
  * Rilascio: $\tau_{\text{rel}} = 22\text{ ms}$
* **Inviluppo Lento:**
  * Attacco: $\tau_{\text{att}} = 30\text{ ms}$
  * Rilascio: $\tau_{\text{rel}} = 180\text{ ms}$
* **Rapporto di Transienza:**
  $$\text{Ratio}[n] = \frac{\text{fastEnv}[n]}{\text{slowEnv}[n] + 1.0 \times 10^{-5}}$$
* **Smoothing Adattivo Anti-Flutter:**
  * Per evitare flutter distorsivo o pop su note basse continue (come bassi 808 o sinusoide di cassa), $W_{\text{trans}}$ subisce uno smoothing passa-basso asimmetrico:
    * Attacco rampa: $\tau \approx 3.5\text{ ms}$
    * Rilascio rampa: $\tau \approx 12\text{ ms}$
