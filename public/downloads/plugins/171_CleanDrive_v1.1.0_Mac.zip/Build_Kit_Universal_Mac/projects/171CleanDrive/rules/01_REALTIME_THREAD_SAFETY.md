# Modulo 01: Sicurezza Real-Time e Threading
**Plugin:** 171CleanDrive (Transient-Aware Dual Saturator)  
**Standard:** Ross Bencina Real-Time Audio Programming Standards (VST3 / AU)

---

## 1. Regole Ferree per il Thread Audio (`processBlock`)

Nel metodo `processBlock()` e in tutti i moduli DSP chiamati per-sample:

1. **DIVIETO ASSOLUTO DI ALLOCAZIONI MEMORIA SULL'HEAP:**
   - È tassativamente vietato l'uso di `new`, `delete`, `malloc`, `free`.
   - È vietato l'uso di `std::vector::push_back`, `std::vector::resize`, `std::string` o qualsiasi contenitore dinamico che possa provocare riallocazione o page faults.
   - Tutti i buffer audio, array di stato e strutture sono istanziati come membri fissi e dimensionati durante `prepareToPlay(sampleRate, samplesPerBlock)`.

2. **DIVIETO DI MUTEX E PRIMITIVE BLOCCANTI:**
   - Mai usare `std::mutex`, `std::unique_lock`, `std::condition_variable` o `std::thread::join` nel thread audio.
   - Il thread audio non deve MAI attendere il thread GUI o il message thread della DAW (*Priority Inversion Protection*).

3. **DISACCOPPIAMENTO TRAMITE LOCK-FREE FIFO:**
   - Lo scambio dati verso la GUI deve avvenire unicamente tramite la struttura `dsp171::LockFreeVisualFIFO<512>` (SPSC Lock-Free Ring Buffer a 512 frame).
   - Se la coda è satura, il thread audio scrive senza bloccare scartando il frame in eccesso (`push()` restituisce bool senza lock).

4. **PROTEZIONE DAI NUMERI DENORMALI (FTZ/DAZ):**
   - Inserire all'inizio di `processBlock()` la guardia RAII:
     ```cpp
     juce::ScopedNoDenormals noDenormals;
     ```
   - Tutti i filtri ricorsivi IIR (ZDF, DC-Blocker, inviluppi esponenziali) non devono decadere all'infinito sotto la soglia di denormale ($1.0 \times 10^{-15}$).

5. **PROTEZIONE TOTALE DA NAN E DIVISIONI PER ZERO:**
   - Tutte le conversioni logaritmiche di guadagno ($20 \log_{10}$) e i calcoli differenziali (ADAA, rapporto di transienza) devono possedere un epsilon di salvaguardia ($\epsilon \ge 1.0 \times 10^{-5}$):
     ```cpp
     const float ratio = fastEnv / (slowEnv + 1.0e-5f);
     ```

6. **DISSOLVENZA INCROCIATA BYPASS POP-FREE (15 ms):**
   - L'attivazione/disattivazione del Bypass non deve mai essere uno switch istantaneo (che provocherebbe clic e discontinuità d'onda acustiche a $0\text{ dBFS}$).
   - È obbligatorio un crossfade lineare a campione singolo governato da `juce::SmoothedValue<float>` con tempo di rampa a $15\text{ ms}$:
     ```cpp
     const float curBypass = smoothedBypass.getNextValue();
     channelData[i] = (processedSample * (1.0f - curBypass)) + (drySample * curBypass);
     ```
