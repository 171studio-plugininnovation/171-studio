@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
cd /d "C:\Users\171Studio\Desktop\171 dsp and gui engine"
cl /std:c++20 /EHsc /O2 /I"engine\dsp171-core\include" /Fe:"projects\171CleanDrive\Tests\verify_dsp171_modules.exe" "projects\171CleanDrive\Tests\verify_dsp171_modules.cpp"
if %ERRORLEVEL% EQU 0 (
    "projects\171CleanDrive\Tests\verify_dsp171_modules.exe"
)
cl /std:c++20 /EHsc /O2 /I"engine\dsp171-core\include" /Fe:"projects\171CleanDrive\Tests\verify_easyvoice_math.exe" "projects\171CleanDrive\Tests\verify_easyvoice_math.cpp"
if %ERRORLEVEL% EQU 0 (
    "projects\171CleanDrive\Tests\verify_easyvoice_math.exe"
)
