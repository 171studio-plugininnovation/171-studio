// ==============================================================================
//  171CleanDrive - Test Runner: Collaudo DSP su Audio Reale
//  Adattato da 171CleanReso/Tests/test_runner.cpp
// ==============================================================================
#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <chrono>
#include <juce_core/juce_core.h>
#include <juce_events/juce_events.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "../Source/PluginProcessor.h"

struct TestResult {
    juce::String testName;
    juce::String inputFileName;
    double durationSec     = 0.0;
    float peakInDb         = -100.0f;
    float peakOutDb        = -100.0f;
    float rmsInDb          = -100.0f;
    float rmsOutDb         = -100.0f;
    float maxGRDb          = 0.0f;   // max transientRatio from VisualFrame (misura indiretta saturazione)
    int   safetyCeilingClips = 0;
    int   nanOrInfCount    = 0;
    juce::File outputFile;
};

// ==============================================================================
//  Helper: imposta parametro APVTS tramite convertTo0to1
// ==============================================================================
static void setParam(juce::AudioProcessorValueTreeState& apvts,
                     const juce::String& id, float realValue)
{
    if (auto* p = apvts.getParameter(id))
        p->setValueNotifyingHost(p->convertTo0to1(realValue));
}

static void setParamRaw(juce::AudioProcessorValueTreeState& apvts,
                        const juce::String& id, float normalised)
{
    if (auto* p = apvts.getParameter(id))
        p->setValueNotifyingHost(normalised);
}

// ==============================================================================
//  Core test function
// ==============================================================================
TestResult runAudioTest(const juce::File& inputFile,
                        const juce::File& outputDir,
                        const juce::String& testName,
                        int   presetIndex      = -1,
                        float drive            = -1.0f,   // -1 = lascia preset
                        float transPunch       = -1.0f,
                        float warmth           = -1.0f,
                        float mix              = -1.0f,
                        bool  deltaListen      = false)
{
    TestResult res;
    res.testName      = testName;
    res.inputFileName = inputFile.getFileName();

    juce::AudioFormatManager formatManager;
    formatManager.registerBasicFormats();

    std::unique_ptr<juce::AudioFormatReader> reader(formatManager.createReaderFor(inputFile));
    if (!reader) {
        std::cerr << "[-] ERRORE: Impossibile leggere: " << inputFile.getFullPathName() << "\n";
        return res;
    }

    const double sampleRate  = reader->sampleRate;
    const int    numChannels = static_cast<int>(reader->numChannels);
    const int    totalLength = static_cast<int>(reader->lengthInSamples);
    res.durationSec          = static_cast<double>(totalLength) / sampleRate;

    // Leggi file in un buffer
    juce::AudioBuffer<float> inBuffer(numChannels, totalLength);
    reader->read(&inBuffer, 0, totalLength, 0, true, true);

    // Istanza processor
    AudioPluginAudioProcessor processor;
    constexpr int blockSize = 512;
    processor.prepareToPlay(sampleRate, blockSize);

    auto& apvts = processor.getAPVTS();

    // Imposta preset di fabbrica
    if (presetIndex >= 0)
        processor.setCurrentProgram(presetIndex);

    // Override singoli parametri (se specificati)
    if (drive       >= 0.0f) setParam(apvts, "drive",       drive);
    if (transPunch  >= 0.0f) setParam(apvts, "trans_punch",  transPunch);
    if (warmth      >= 0.0f) setParam(apvts, "warmth",       warmth);
    if (mix         >= 0.0f) setParam(apvts, "mix",          mix);

    // Delta Listen non è un parametro di CleanDrive — stampa avviso se richiesto
    if (deltaListen) {
        std::cout << "    [i] Delta Listen non disponibile in CleanDrive (ignorato)\n";
    }

    // Metriche
    double sumSqIn  = 0.0;
    double sumSqOut = 0.0;
    float  peakIn   = 0.0f;
    float  peakOut  = 0.0f;
    float  maxTransientRatio = 0.0f;

    juce::AudioBuffer<float> outBuffer(numChannels, totalLength);
    juce::MidiBuffer         midi;

    int numBlocks = (totalLength + blockSize - 1) / blockSize;

    for (int b = 0; b < numBlocks; ++b) {
        const int startSample    = b * blockSize;
        const int curBlockSize   = std::min(blockSize, totalLength - startSample);

        // Espandiamo sempre a stereo (come CleanReso)
        juce::AudioBuffer<float> blockBuffer(2, curBlockSize);
        for (int ch = 0; ch < 2; ++ch) {
            const int inCh = std::min(ch, numChannels - 1);
            blockBuffer.copyFrom(ch, 0, inBuffer, inCh, startSample, curBlockSize);
        }

        // Misura ingresso
        for (int ch = 0; ch < 2; ++ch)
            for (int i = 0; i < curBlockSize; ++i) {
                float s = blockBuffer.getSample(ch, i);
                float a = std::abs(s);
                if (a > peakIn) peakIn = a;
                sumSqIn += static_cast<double>(s) * s;
            }

        // ---- ELABORAZIONE 171CleanDrive ----
        processor.processBlock(blockBuffer, midi);

        // Drain VisualFIFO: raccogliamo transientRatio come proxy di "GR/saturazione"
        dsp171::VisualFrame frame;
        while (processor.getVisualFIFO().pop(frame)) {
            if (frame.transientRatio > maxTransientRatio)
                maxTransientRatio = frame.transientRatio;
        }

        // Misura uscita
        for (int ch = 0; ch < 2; ++ch)
            for (int i = 0; i < curBlockSize; ++i) {
                float s = blockBuffer.getSample(ch, i);
                if (std::isnan(s) || std::isinf(s))  { res.nanOrInfCount++; continue; }
                float a = std::abs(s);
                if (a > 0.990001f) res.safetyCeilingClips++;
                if (a > peakOut)   peakOut = a;
                sumSqOut += static_cast<double>(s) * s;
            }

        // Copia in buffer output
        for (int ch = 0; ch < std::min(2, numChannels); ++ch)
            outBuffer.copyFrom(ch, startSample, blockBuffer, ch, 0, curBlockSize);
    }

    const double totalSamples = static_cast<double>(totalLength * 2);
    res.peakInDb  = peakIn  > 1.0e-5f ? 20.0f * std::log10(peakIn)  : -100.0f;
    res.peakOutDb = peakOut > 1.0e-5f ? 20.0f * std::log10(peakOut) : -100.0f;
    res.rmsInDb   = sumSqIn  > 0.0 ? 20.0f * std::log10(std::sqrt(sumSqIn  / totalSamples)) : -100.0f;
    res.rmsOutDb  = sumSqOut > 0.0 ? 20.0f * std::log10(std::sqrt(sumSqOut / totalSamples)) : -100.0f;
    res.maxGRDb   = maxTransientRatio;  // transientRatio (0…1) usato come indicatore di saturazione

    // Salvataggio WAV per ascolto
    outputDir.createDirectory();
    juce::File outFile = outputDir.getChildFile(testName + ".wav");
    outFile.deleteFile();

    juce::WavAudioFormat wavFormat;
    std::unique_ptr<juce::AudioFormatWriter> writer(
        wavFormat.createWriterFor(new juce::FileOutputStream(outFile),
                                  sampleRate,
                                  static_cast<unsigned int>(numChannels),
                                  24, {}, 0));
    if (writer) {
        writer->writeFromAudioSampleBuffer(outBuffer, 0, totalLength);
        writer.reset();
        res.outputFile = outFile;
    }

    return res;
}

// ==============================================================================
//  main
// ==============================================================================
int main(int /*argc*/, char* /*argv*/[]) {
    juce::ScopedJuceInitialiser_GUI guiInit;

    // --- GUI Snapshot ---
    {
        AudioPluginAudioProcessor proc;
        std::unique_ptr<juce::AudioProcessorEditor> ed(proc.createEditorIfNeeded());
        if (ed) {
            ed->setSize(1024, 576);
            auto snap = ed->createComponentSnapshot(ed->getLocalBounds());
            juce::File snapFile(R"(C:\Users\171Studio\.gemini\antigravity\brain\91066049-3545-4aaa-b4f8-ac9c47343e8c\171CleanDrive_Live_Snapshot.png)");
            snapFile.deleteFile();
            juce::FileOutputStream stream(snapFile);
            if (stream.openedOk()) {
                juce::PNGImageFormat png;
                png.writeImageToStream(snap, stream);
                std::cout << "[+] Screenshot GUI salvato: " << snapFile.getFullPathName() << "\n";
            }
        }
    }

    std::cout << "====================================================================\n";
    std::cout << " 171CleanDrive - COLLAUDO DINAMICO SU AUDIO REALE\n";
    std::cout << "====================================================================\n\n";

    const juce::File beatMixtapeDir(R"(C:\Users\171Studio\Desktop\beat mixtape)");
    const juce::File outputDir     (R"(C:\Users\171Studio\Desktop\beat mixtape\171CleanDrive_Test_Outputs)");

    std::vector<TestResult> results;

    // ------------------------------------------------------------------
    // 1. BEAT COMPLETO (Brother.wav)
    // ------------------------------------------------------------------
    juce::File beatFile = beatMixtapeDir.getChildFile("brother").getChildFile("Brother.wav");
    if (beatFile.existsAsFile()) {
        std::cout << "[*] Test 1: BEAT COMPLETO (" << beatFile.getFileName() << ")\n";

        // 1A: Drive leggero (warmth basso)
        std::cout << "    -> 1A: Drive leggero (Preset 01 Default Punch, warmth=0.15)...\n";
        results.push_back(runAudioTest(beatFile, outputDir,
            "01A_Brother_DriveLeggero_WarmthBasso",
            0,       // preset 01
            -1.0f,   // drive dal preset
            -1.0f,   // transPunch dal preset
            0.15f)); // warmth override basso

        // 1B: Drive massimo (Preset 08 Vintage Germanium)
        std::cout << "    -> 1B: Drive massimo (Preset 08 Vintage Germanium)...\n";
        results.push_back(runAudioTest(beatFile, outputDir,
            "01B_Brother_DriveMassimo_VintageGermanium",
            7));  // preset index 7 = "08 | Vintage Germanium"
    } else {
        std::cout << "[-] File beat non trovato: " << beatFile.getFullPathName() << "\n";
    }

    // ------------------------------------------------------------------
    // 2. DRUMS STEM (0 Drums.wav) — TransientSplitter + Drive (modo Punch)
    // ------------------------------------------------------------------
    juce::File drumsFile = beatMixtapeDir.getChildFile("brother").getChildFile("0 Drums.wav");
    if (drumsFile.existsAsFile()) {
        std::cout << "\n[*] Test 2: STEM DRUMS - TransientSplitter + Drive Punch (" << drumsFile.getFileName() << ")\n";

        // 2A: Preset Snare Crack & Bite (03) — alto transPunch
        std::cout << "    -> 2A: Snare Crack & Bite (Preset 03, transPunch max)...\n";
        results.push_back(runAudioTest(drumsFile, outputDir,
            "02A_Drums_SnareCrack_TransPunchMax",
            2,        // preset 03 "Snare Crack & Bite"
            -1.0f,
            1.8f));   // transPunch max

        // 2B: Parallel Drum Smasher (Preset 07) — drive estremo, mix 50%
        std::cout << "    -> 2B: Parallel Drum Smasher (Preset 07)...\n";
        results.push_back(runAudioTest(drumsFile, outputDir,
            "02B_Drums_ParallelSmasher",
            6));  // preset index 6 = "07 | Parallel Drum Smasher"
    } else {
        std::cout << "[-] File drums non trovato: " << drumsFile.getFullPathName() << "\n";
    }

    // ------------------------------------------------------------------
    // 3. VOCE — Drive vocale warm, Delta listen (ignorato, non disponibile)
    // ------------------------------------------------------------------
    juce::File vocalFile = beatMixtapeDir
        .getChildFile("REC ALBUM")
        .getChildFile("REC BROTHER")
        .getChildFile("Media")
        .getChildFile("04-251202_1939.wav");
    if (vocalFile.existsAsFile()) {
        std::cout << "\n[*] Test 3: VOCE REC ALBUM (" << vocalFile.getFileName() << ")\n";

        // 3A: Vocal Presence & Air (Preset 06) — warmth warm
        std::cout << "    -> 3A: Vocal Presence & Air (Preset 06)...\n";
        results.push_back(runAudioTest(vocalFile, outputDir,
            "03A_Vocal_Presence_Air_Warm",
            5));  // preset index 5 = "06 | Vocal Presence & Air"

        // 3B: Analog Tape Saturator (Preset 05) — Delta Listen (non disponibile)
        std::cout << "    -> 3B: Vocal Drive Warm (Preset 05, Delta Listen N/A)...\n";
        results.push_back(runAudioTest(vocalFile, outputDir,
            "03B_Vocal_Warm_DeltaListenNA",
            4, -1.0f, -1.0f, -1.0f, -1.0f, true));
    } else {
        std::cout << "[-] File voce non trovato: " << vocalFile.getFullPathName() << "\n";
    }

    // ------------------------------------------------------------------
    // 4. BEAT NICARAGUA
    // ------------------------------------------------------------------
    juce::File nicaraguaFile(R"(C:\Users\171Studio\Desktop\beat mixtape\nicaragua BEAT.wav)");
    if (!nicaraguaFile.existsAsFile()) {
        // Prova path alternativo
        nicaraguaFile = juce::File(R"(C:\Users\171Studio\Desktop\eugenio\171 STUDIO\ADRIANO\nicaragua BEAT.wav)");
    }
    if (nicaraguaFile.existsAsFile()) {
        std::cout << "\n[*] Test 4: BEAT NICARAGUA (" << nicaraguaFile.getFileName() << ")\n";
        std::cout << "    -> 4A: Golden Master Glue (Preset 02)...\n";
        results.push_back(runAudioTest(nicaraguaFile, outputDir,
            "04A_Nicaragua_GoldenMasterGlue",
            1));  // preset index 1 = "02 | Golden Master Glue"
    } else {
        std::cout << "[-] File nicaragua non trovato (saltato)\n";
    }

    // ==================================================================
    //  STAMPA TABELLA RISULTATI
    // ==================================================================
    std::cout << "\n========================================================================================================================\n";
    std::cout << " TABELLA RISULTATI COLLAUDO E VERIFICA INGEGNERISTICA 171CleanDrive\n";
    std::cout << "========================================================================================================================\n";
    std::cout << std::left
              << std::setw(38) << "Test ID / Modalita"
              << std::setw(10) << "Dur(s)"
              << std::setw(12) << "Peak In"
              << std::setw(12) << "Peak Out"
              << std::setw(12) << "RMS In"
              << std::setw(12) << "RMS Out"
              << std::setw(12) << "TransRatio"
              << std::setw(12) << "SafetyCeil"
              << std::setw(8)  << "NaN/Inf"
              << "Esito\n";
    std::cout << "------------------------------------------------------------------------------------------------------------------------\n";

    bool allPassed = true;

    for (const auto& r : results) {
        bool pass = (r.nanOrInfCount == 0) &&
                    (r.safetyCeilingClips == 0) &&
                    (r.peakOutDb <= 0.0f);
        if (!pass) allPassed = false;

        std::cout << std::left
                  << std::setw(38) << r.testName.substring(0, 37).toStdString()
                  << std::setw(10) << std::fixed << std::setprecision(1) << r.durationSec
                  << std::setw(12) << (juce::String(r.peakInDb,  1) + " dB").toStdString()
                  << std::setw(12) << (juce::String(r.peakOutDb, 1) + " dB").toStdString()
                  << std::setw(12) << (juce::String(r.rmsInDb,   1) + " dB").toStdString()
                  << std::setw(12) << (juce::String(r.rmsOutDb,  1) + " dB").toStdString()
                  << std::setw(12) << (juce::String(r.maxGRDb,   3)).toStdString()
                  << std::setw(12) << (r.safetyCeilingClips == 0 ? "SICURO" : "CLIPPED")
                  << std::setw(8)  << r.nanOrInfCount
                  << (pass ? "[SUPERATO]" : "[FALLITO]")
                  << "\n";
    }

    std::cout << "------------------------------------------------------------------------------------------------------------------------\n";
    std::cout << "\nEsito complessivo: "
              << (allPassed
                  ? "TUTTI I TEST SUPERATI CON SUCCESSO (100% PASS)"
                  : "ATTENZIONE: ALCUNI TEST HANNO SEGNALATO ANOMALIE")
              << "\n";
    std::cout << "File audio esportati in: " << outputDir.getFullPathName() << "\n";
    std::cout << "========================================================================================================================\n";

    return allPassed ? 0 : 1;
}
