#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>
#include <cassert>
#include <string>

// Include all DSP171 core headers to test
#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include <dsp171/SafetyCeiling.h>
#include <dsp171/DCBlocker.h>
#include <dsp171/ZDFSVF.h>
#include <dsp171/ZDFTiltFilter.h>
#include <dsp171/ADAA2Clipper.h>
#include <dsp171/TransformerSaturator.h>
#include <dsp171/DecapitatorDSP.h>
#include <dsp171/CultureVultureDSP.h>
#include <dsp171/APIDiscreteSaturator.h>
#include <dsp171/FocusriteISAPreamp.h>
#include <dsp171/NevePreampStrip.h>
#include <dsp171/VariMuCompressor.h>
#include <dsp171/StereoWidth.h>
#include <dsp171/StereoWidthEnhancer.h>
#include <dsp171/TransientSplitter.h>
#include <dsp171/GlottalClosureDetector.h>
#include <dsp171/LPCVocalTract.h>
#include <dsp171/LockFreeFIFO.h>
#include <dsp171/LatencyBypass.h>
#include <dsp171/SmoothBypass.h>
#include <dsp171/Oversampler.h>
#include <dsp171/DSPHireManager.h>

#define TEST_ASSERT(cond, msg) \
    do { \
        if (!(cond)) { \
            std::cerr << "[-] FAILED: " << msg << " (" #cond ") at line " << __LINE__ << std::endl; \
            return false; \
        } \
    } while(0)

bool testCommonMath() {
    std::cout << "[*] Testing Common.h and FastMath.h..." << std::endl;

    // dbToGain extremes
    TEST_ASSERT(std::isfinite(dsp171::dbToGain(0.0f)), "0 dB must be finite");
    TEST_ASSERT(std::abs(dsp171::dbToGain(0.0f) - 1.0f) < 1e-5f, "0 dB must be 1.0");
    TEST_ASSERT(dsp171::dbToGain(-200.0f) == 0.0f, "-200 dB must return 0");
    TEST_ASSERT(dsp171::dbToGain(std::numeric_limits<float>::quiet_NaN()) == 0.0f, "NaN dB must return 0");
    TEST_ASSERT(dsp171::dbToGain(1000.0f) <= 1000.0f, "+1000 dB must clamp to safe upper limit");

    // gainToDb extremes
    TEST_ASSERT(dsp171::gainToDb(0.0f) == -120.0f, "gain 0 must return -120 dB");
    TEST_ASSERT(dsp171::gainToDb(-5.0f) == -120.0f, "negative gain must return -120 dB");
    TEST_ASSERT(dsp171::gainToDb(std::numeric_limits<float>::quiet_NaN()) == -120.0f, "NaN gain must return -120 dB");
    TEST_ASSERT(std::abs(dsp171::gainToDb(1.0f)) < 1e-4f, "gain 1.0 must be 0 dB");

    // fastTanh
    TEST_ASSERT(dsp171::fastTanh(3.0f) == 1.0f, "fastTanh(3.0) must be 1.0");
    TEST_ASSERT(dsp171::fastTanh(-3.0f) == -1.0f, "fastTanh(-3.0) must be -1.0");
    TEST_ASSERT(dsp171::fastTanh(0.0f) == 0.0f, "fastTanh(0.0) must be 0.0");

    // FastDbToGainTable
    const auto& table = dsp171::getGlobalDbToGainTable();
    TEST_ASSERT(table.lookup(-100.0f) > 0.0f, "table lookup below -60 dB should return table[0], not 0.0 pop");
    TEST_ASSERT(std::isfinite(table.lookup(std::numeric_limits<float>::quiet_NaN())), "table lookup NaN must be finite");
    TEST_ASSERT(std::abs(table.lookup(0.0f) - 1.0f) < 0.02f, "table lookup 0 dB should be ~1.0");

    return true;
}

bool testSafetyCeiling() {
    std::cout << "[*] Testing SafetyCeiling.h..." << std::endl;

    // Immunity against NaN and Inf
    TEST_ASSERT(dsp171::applySafetyCeiling(std::numeric_limits<float>::quiet_NaN()) == 0.0f, "NaN must yield 0.0");
    TEST_ASSERT(dsp171::applySafetyCeiling(std::numeric_limits<float>::infinity()) <= 0.9900f, "Inf must be clamped");
    TEST_ASSERT(dsp171::applySafetyCeiling(-std::numeric_limits<float>::infinity()) >= -0.9900f, "-Inf must be clamped");

    // Standard signal
    TEST_ASSERT(std::abs(dsp171::applySafetyCeiling(0.5f) - 0.5f) < 1e-6f, "0.5 must be perfectly linear");
    TEST_ASSERT(std::abs(dsp171::applySafetyCeiling(-0.5f) - (-0.5f)) < 1e-6f, "-0.5 must be linear");

    // High overshoots
    for (float peak = 1.0f; peak <= 100.0f; peak += 2.5f) {
        float outPos = dsp171::applySafetyCeiling(peak);
        float outNeg = dsp171::applySafetyCeiling(-peak);
        TEST_ASSERT(outPos <= 0.9900f && outPos > 0.85f, "Over-threshold positive peak must be safely capped");
        TEST_ASSERT(outNeg >= -0.9900f && outNeg < -0.85f, "Over-threshold negative peak must be safely capped");
    }

    return true;
}

bool testTransformerSaturator() {
    std::cout << "[*] Testing TransformerSaturator.h..." << std::endl;
    dsp171::TransformerSaturator ts;
    ts.prepare(48000.0);

    // Negative drive singularity protection
    float outDivZero = ts.processSample(0.5f, -2.125f, 0.5f);
    TEST_ASSERT(std::isfinite(outDivZero), "Singularity at drive = -2.125f must be eliminated");

    float outZeroDrive = ts.processSample(0.5f, 0.0f, 0.5f);
    TEST_ASSERT(std::isfinite(outZeroDrive), "drive = 0.0f must be finite");

    // Foldback protection on high negative excursion
    ts.reset();
    for (float in = 0.0f; in >= -10.0f; in -= 0.1f) {
        float out = ts.processSample(in, 2.0f, 1.0f);
        TEST_ASSERT(std::isfinite(out), "High negative excursion must be finite");
        TEST_ASSERT(out <= 0.05f, "Negative input must NOT fold back to positive output in steady state");
    }

    // NaN input check
    float outNaN = ts.processSample(std::numeric_limits<float>::quiet_NaN(), 1.0f, 0.5f);
    TEST_ASSERT(outNaN == 0.0f, "NaN input must return 0.0");

    return true;
}

bool testDecapitatorDSP() {
    std::cout << "[*] Testing DecapitatorDSP.h..." << std::endl;
    dsp171::DecapitatorDSP decap;
    decap.prepare(48000.0);

    // Style E Continuity Test across x = 1.2f
    decap.setStyle(dsp171::DecapitatorDSP::SatStyle::StyleE);
    decap.setDrive(0.0f); // 0 dB drive
    decap.setToneDb(0.0f);

    decap.reset();
    float s1L = 1.199f, s1R = 1.199f;
    decap.process(&s1L, &s1R, 1);
    float prevOut = s1L;

    decap.reset();
    float s2L = 1.201f, s2R = 1.201f;
    decap.process(&s2L, &s2R, 1);
    float nextOut = s2L;

    float delta = std::abs(nextOut - prevOut);
    TEST_ASSERT(delta < 0.01f, "Style E must NOT have a 0.232 jump discontinuity at x = 1.2f");

    // Continuous monotonic sweep for Style E
    float lastVal = -2.0f;
    for (float x = 0.0f; x <= 5.0f; x += 0.01f) {
        decap.reset();
        float inL = x, inR = x;
        decap.process(&inL, &inR, 1);
        TEST_ASSERT(std::isfinite(inL), "Style E output must be finite");
        TEST_ASSERT(inL >= lastVal - 1e-4f, "Style E output must be monotonically non-decreasing");
        lastVal = inL;
    }

    // Style T Foldback Test
    decap.setStyle(dsp171::DecapitatorDSP::SatStyle::StyleT);
    for (float x = -0.1f; x >= -8.0f; x -= 0.2f) {
        decap.reset();
        float inL = x, inR = x;
        decap.process(&inL, &inR, 1);
        TEST_ASSERT(std::isfinite(inL), "Style T output must be finite");
        TEST_ASSERT(inL <= 0.05f, "Style T negative input must not fold back to positive");
    }

    return true;
}

bool testCultureVultureDSP() {
    std::cout << "[*] Testing CultureVultureDSP.h..." << std::endl;
    dsp171::CultureVultureDSP cv;
    cv.prepare(48000.0);

    // Tone mapping test: check tone = 1 and tone = 8 are distinguishable
    cv.setParameters(dsp171::VultureMode::Triode, 1.0f, 0.0f, 1.0f, false);
    float outTone1 = cv.processSample(0.5f);
    cv.setParameters(dsp171::VultureMode::Triode, 1.0f, 0.0f, 8.0f, false);
    float outTone8 = cv.processSample(0.5f);
    TEST_ASSERT(outTone1 != outTone8, "Tone parameter mapping must be active across the full range");

    // P2 Starve Mode: Check threshold continuity
    cv.setParameters(dsp171::VultureMode::P2_Starve, 1.0f, 0.5f, 0.0f, false);
    for (float x = 0.0f; x <= 1.0f; x += 0.005f) {
        float y = cv.processSample(x);
        TEST_ASSERT(std::isfinite(y), "P2 Starve output must be finite");
    }

    // Triode Mode: Verify no foldback
    cv.reset();
    cv.setParameters(dsp171::VultureMode::Triode, 2.0f, 0.8f, 0.0f, false);
    for (float x = -0.1f; x >= -6.0f; x -= 0.1f) {
        float y = cv.processSample(x);
        TEST_ASSERT(std::isfinite(y), "Triode output must be finite");
        TEST_ASSERT(y <= 0.05f, "Triode negative input must not fold back to positive");
    }

    return true;
}

bool testPreampsPolynomialFoldback() {
    std::cout << "[*] Testing Preamps Polynomial Foldback Clamping..." << std::endl;

    // API 2520
    dsp171::APIDiscreteSaturator api;
    api.prepare(48000.0);
    for (float x = 0.1f; x <= 10.0f; x += 0.2f) {
        float y = api.processSample(x, 0.0f);
        TEST_ASSERT(std::isfinite(y), "API output must be finite");
        TEST_ASSERT(y > 0.0f, "API positive input must never invert sign to negative");
    }
    api.reset();
    for (float x = -0.1f; x >= -10.0f; x -= 0.2f) {
        float y = api.processSample(x, 0.0f);
        TEST_ASSERT(std::isfinite(y), "API output must be finite");
        TEST_ASSERT(y < 0.0f, "API negative input must never invert sign to positive");
    }

    // Focusrite ISA
    dsp171::FocusriteISAPreamp isa;
    isa.prepare(48000.0);
    for (float x = 0.1f; x <= 10.0f; x += 0.2f) {
        float y = isa.processSample(x, 0.0f);
        TEST_ASSERT(std::isfinite(y), "ISA output must be finite");
        TEST_ASSERT(y > 0.0f, "ISA positive input must never invert sign");
    }
    isa.reset();
    for (float x = -0.1f; x >= -10.0f; x -= 0.2f) {
        float y = isa.processSample(x, 0.0f);
        TEST_ASSERT(std::isfinite(y), "ISA output must be finite");
        TEST_ASSERT(y < 0.0f, "ISA negative input must never invert sign");
    }

    // Neve Preamp Strip
    dsp171::NevePreampStrip neve;
    neve.prepare(48000.0);
    for (float x = 0.1f; x <= 10.0f; x += 0.2f) {
        float y = neve.processSample(x);
        TEST_ASSERT(std::isfinite(y), "Neve output must be finite");
        TEST_ASSERT(y > 0.0f, "Neve positive input must never invert sign");
    }

    return true;
}

bool testVariMuCompressor() {
    std::cout << "[*] Testing VariMuCompressor.h..." << std::endl;
    dsp171::VariMuCompressor vm;
    vm.prepare(48000.0);

    // Extreme peak input test: tube saturator must not blow up
    for (float x = 1.0f; x <= 50.0f; x += 3.0f) {
        float outL = x, outR = x;
        vm.process(&outL, &outR, 1);
        TEST_ASSERT(std::isfinite(outL) && std::isfinite(outR), "VariMu output must remain finite");
        TEST_ASSERT(std::abs(outL) < 10.0f, "VariMu tube saturator must not expand quadratically beyond bounds");
    }

    return true;
}

bool testStereoWidthMonoCancellation() {
    std::cout << "[*] Testing StereoWidth Mono Cancellation..." << std::endl;
    dsp171::StereoWidth sw;
    sw.prepare(48000.0);
    sw.setWidth(1.8f); // 180% super-wide
    sw.setDecorrelationMode(dsp171::StereoWidth::DecorrelationMode::AlwaysOn);

    // Feed stereo audio and verify sum mono (L + R) * 0.5 == original Mid
    for (int i = 0; i < 1000; ++i) {
        float inL = std::sin(static_cast<float>(i) * 0.05f) * 0.7f;
        float inR = std::cos(static_cast<float>(i) * 0.03f) * 0.6f;
        float midExpected = 0.5f * (inL + inR);

        float outL = 0.0f, outR = 0.0f;
        sw.processSample(inL, inR, outL, outR);

        float monoSum = 0.5f * (outL + outR);
        TEST_ASSERT(std::abs(monoSum - midExpected) < 1e-5f, "StereoWidth mono sum must identically equal Mid");
    }

    // Test StereoWidthEnhancer mono cancellation
    dsp171::StereoWidthEnhancer swe;
    swe.prepare(48000.0);
    swe.setWidth(200.0f); // 200% wide
    for (int i = 0; i < 1000; ++i) {
        float inL = std::sin(static_cast<float>(i) * 0.07f) * 0.8f;
        float inR = inL; // mono track
        float outL = 0.0f, outR = 0.0f;
        swe.processSample(inL, inR, outL, outR);

        float monoSum = 0.5f * (outL + outR);
        TEST_ASSERT(std::abs(monoSum - inL) < 1e-5f, "StereoWidthEnhancer mono track sum must equal original input");
    }

    return true;
}

bool testFiltersStability() {
    std::cout << "[*] Testing ZDFSVF and ZDFTiltFilter across sample rates (44.1k - 192k)..." << std::endl;
    const double sampleRates[] = { 44100.0, 48000.0, 88200.0, 96000.0, 176400.0, 192000.0 };

    for (double sr : sampleRates) {
        // ZDFSVF64
        dsp171::ZDFSVF64 svf;
        svf.setParameters(static_cast<float>(sr * 0.45), 20.0f, static_cast<float>(sr)); // high resonance near Nyquist
        for (int i = 0; i < 500; ++i) {
            float in = (i == 0) ? 1.0f : 0.0f; // Dirac impulse
            auto out = svf.process(in);
            TEST_ASSERT(std::isfinite(out.lp) && std::isfinite(out.bp) && std::isfinite(out.hp),
                        "ZDFSVF64 impulse response must be unconditionally finite");
        }

        // Long silent decay (anti-denormal verification)
        for (int i = 0; i < 50000; ++i) {
            auto out = svf.process(0.0f);
            TEST_ASSERT(std::isfinite(out.lp) && std::isfinite(out.bp) && std::isfinite(out.hp), "Decay must remain finite");
            if (i > 5000) {
                TEST_ASSERT(std::abs(out.lp) < 1e-4f, "Decay must be fully settled after 5000 samples");
            }
        }

        // ZDFTiltFilter
        dsp171::ZDFTiltFilter tilt;
        tilt.prepare(sr);
        tilt.setTilt(1.0f);
        for (int i = 0; i < 500; ++i) {
            float in = (i == 0) ? 1.0f : 0.0f;
            float out = tilt.processSample(in);
            TEST_ASSERT(std::isfinite(out), "Tilt impulse response must be finite");
        }
        for (int i = 0; i < 50000; ++i) {
            float out = tilt.processSample(0.0f);
            TEST_ASSERT(std::abs(out) < 1e-4f, "Tilt decay must be stable");
        }
    }

    return true;
}

bool testLPCVocalTract() {
    std::cout << "[*] Testing LPCVocalTract.h Levinson-Durbin stability..." << std::endl;
    dsp171::LPCVocalTract<20> lpc;
    lpc.prepare(48000.0, 20);

    // Feed synthetic vocal formant signal
    for (int i = 0; i < 1024; ++i) {
        float sample = 0.5f * std::sin(i * 0.05f) + 0.3f * std::sin(i * 0.12f) + 0.2f * std::sin(i * 0.25f);
        lpc.pushSampleForAnalysis(sample, true);
    }

    // Verify reflection coefficients are strictly inside unit circle
    auto kCoeffs = lpc.getReflectionCoefficients();
    for (size_t i = 1; i < kCoeffs.size(); ++i) {
        TEST_ASSERT(std::abs(kCoeffs[i]) < 1.0f, "PARCOR reflection coefficient must be strictly |k| < 1.0");
    }

    // Synthesis test with white noise excitation
    for (int i = 0; i < 512; ++i) {
        float synth = lpc.synthesizeSample(0.1f);
        TEST_ASSERT(std::isfinite(synth), "Synthesized vocal sample must be finite");
    }

    return true;
}

bool testGlottalClosureLongTermPrecision() {
    std::cout << "[*] Testing GlottalClosureDetector 64-bit Timestamp precision..." << std::endl;
    dsp171::GlottalClosureDetector gcd;
    gcd.prepare(48000.0);

    // Simulate 1 hour of continuous playback at 48 kHz (172,800,000 samples)
    int64_t sampleIndex = 172800000LL;
    float currentT0 = 120.0f; // 400 Hz note
    std::vector<float> fakeBuf(2048, 0.0f);

    for (int i = 0; i < 500; ++i) {
        sampleIndex++;
        float sample = std::sin(static_cast<float>(sampleIndex) * 0.1f);
        gcd.processSample(sample, sampleIndex, currentT0, true, fakeBuf.data(), 2047);
    }

    double lastGci = gcd.getLastGCITimestamp();
    TEST_ASSERT(lastGci > 172800000.0, "Last GCI must retain 64-bit precision beyond 1 hour of streaming");
    TEST_ASSERT(gcd.getHistoryCount() > 0, "History must register GCI epochs without stalling");

    return true;
}

int main() {
    std::cout << "================================================================" << std::endl;
    std::cout << "  171 MUSIC INNOVATION - DSP171 MATHEMATICAL SAFETY TEST SUITE  " << std::endl;
    std::cout << "================================================================" << std::endl;

    bool allPassed = true;
    allPassed &= testCommonMath();
    allPassed &= testSafetyCeiling();
    allPassed &= testTransformerSaturator();
    allPassed &= testDecapitatorDSP();
    allPassed &= testCultureVultureDSP();
    allPassed &= testPreampsPolynomialFoldback();
    allPassed &= testVariMuCompressor();
    allPassed &= testStereoWidthMonoCancellation();
    allPassed &= testFiltersStability();
    allPassed &= testLPCVocalTract();
    allPassed &= testGlottalClosureLongTermPrecision();

    std::cout << "================================================================" << std::endl;
    if (allPassed) {
        std::cout << "  ALL 11 TEST BATTERIES PASSED (100% SUCCESS)                   " << std::endl;
        std::cout << "================================================================" << std::endl;
        return 0;
    } else {
        std::cerr << "  FAILED ONE OR MORE TESTS!                                     " << std::endl;
        std::cout << "================================================================" << std::endl;
        return 1;
    }
}
