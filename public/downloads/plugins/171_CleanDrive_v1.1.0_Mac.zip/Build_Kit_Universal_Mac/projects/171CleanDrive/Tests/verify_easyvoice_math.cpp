#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>
#include <cassert>
#include <string>

#include <dsp171/Common.h>
#include <dsp171/FastMath.h>
#include <dsp171/VocalNoiseExpander.h>
#include <dsp171/RenaissanceDeEsser.h>
#include <dsp171/MaagAirResonance.h>
#include <dsp171/CLA2ACompressor.h>
#include <dsp171/CLA76Compressor.h>
#include <dsp171/EasyVoiceChannelStrip.h>

#define TEST_ASSERT(cond, msg) \
    do { \
        if (!(cond)) { \
            std::cerr << "[-] FAILED: " << msg << " (" #cond ") at line " << __LINE__ << std::endl; \
            return false; \
        } \
    } while(0)

bool testVocalNoiseExpander() {
    std::cout << "[*] Testing VocalNoiseExpander (Schmitt-Trigger & Denormals)..." << std::endl;
    dsp171::VocalNoiseExpander gate;
    gate.prepare(48000.0);
    gate.setThreshold(-40.0f);
    gate.setHysteresis(6.0f); // Open at -40 dB, Close at -46 dB
    gate.setHoldMs(20.0f);
    gate.setReleaseMs(50.0f);
    gate.setMode(dsp171::VocalNoiseExpander::Mode::DownwardExpander);

    // 1. Verify Schmitt-trigger hysteresis: signal oscillating between -42 dB and -44 dB should not chatter
    float sigOpen = dsp171::dbToGain(-38.0f);  // Above open threshold
    float sigBetween = dsp171::dbToGain(-43.0f); // Between open and close
    float sigClose = dsp171::dbToGain(-48.0f); // Below close threshold

    // Process burst to open gate
    for (int i = 0; i < 200; ++i) {
        float* ch[1] = { &sigOpen };
        gate.process(ch, 1, 1);
    }
    TEST_ASSERT(gate.getGainReductionL() < 0.5f, "Gate must be open for signals above open threshold");

    // Process signal between thresholds: gate must stay open (no chatter)
    for (int i = 0; i < 200; ++i) {
        float* ch[1] = { &sigBetween };
        gate.process(ch, 1, 1);
    }
    TEST_ASSERT(gate.getGainReductionL() < 1.0f, "Gate must remain open in hysteresis band");

    // 2. Long silent decay (Anti-denormal verification)
    gate.reset();
    for (int i = 0; i < 50000; ++i) {
        float zero = 0.0f;
        float* ch[1] = { &zero };
        gate.process(ch, 1, 1);
        TEST_ASSERT(std::isfinite(zero), "Output must be finite");
    }

    // 3. Finite checks on NaN and Inf
    float nanVal = std::numeric_limits<float>::quiet_NaN();
    float* chNan[1] = { &nanVal };
    gate.process(chNan, 1, 1);
    TEST_ASSERT(std::isfinite(nanVal) && nanVal == 0.0f, "NaN must be flushed to zero");

    return true;
}

bool testRenaissanceDeEsserBitExact() {
    std::cout << "[*] Testing RenaissanceDeEsser (Bit-Exact Subtractive Crossover)..." << std::endl;
    dsp171::RenaissanceDeEsser deEsser;
    deEsser.prepare(48000.0);
    deEsser.setMode(dsp171::RenaissanceDeEsser::DeEsserMode::SplitBand);
    deEsser.setThresholdDb(-20.0f);
    deEsser.setRangeDb(12.0f);
    deEsser.setFrequency(6000.0f);

    // Below threshold test: signal at -30 dBFS must pass through bit-exact
    for (int i = 0; i < 1000; ++i) {
        float inL = std::sin(i * 0.1f) * dsp171::dbToGain(-30.0f);
        float inR = inL;
        float outL = 0.0f, outR = 0.0f;
        deEsser.processSample(inL, inR, outL, outR);

        TEST_ASSERT(deEsser.getGainReductionL() == 0.0f, "No GR below threshold");
        TEST_ASSERT(std::abs(outL - inL) < 1e-6f, "Split-band crossover must be 100% bit-exact below threshold");
    }

    // Above threshold test: strong 6 kHz sibilance burst
    for (int i = 0; i < 1000; ++i) {
        float inL = std::sin(i * 0.785f) * dsp171::dbToGain(-6.0f); // ~6 kHz at 48k
        float inR = inL;
        float outL = 0.0f, outR = 0.0f;
        deEsser.processSample(inL, inR, outL, outR);
    }
    TEST_ASSERT(deEsser.getGainReductionL() > 2.0f, "GR must be engaged for strong sibilance");
    TEST_ASSERT(deEsser.getGainReductionL() <= 12.05f, "GR must not exceed range clamp (12 dB)");

    return true;
}

bool testMaagAirAndDeHarsh() {
    std::cout << "[*] Testing MaagAirResonance (Air Band & De-Harsh across Sample Rates)..." << std::endl;
    const double srs[] = { 44100.0, 48000.0, 88200.0, 96000.0, 176400.0, 192000.0 };
    const dsp171::MaagAirResonance::AirFreq freqs[] = {
        dsp171::MaagAirResonance::AirFreq::Freq_2k5,
        dsp171::MaagAirResonance::AirFreq::Freq_5k,
        dsp171::MaagAirResonance::AirFreq::Freq_10k,
        dsp171::MaagAirResonance::AirFreq::Freq_20k,
        dsp171::MaagAirResonance::AirFreq::Freq_40k
    };

    for (double sr : srs) {
        dsp171::MaagAirResonance maag;
        maag.prepare(sr);
        maag.setAirGain(10.0f); // High +10 dB Air boost
        maag.setDeHarshDepth(6.0f);
        maag.setDeHarshThreshold(-24.0f);

        for (auto f : freqs) {
            maag.setAirFrequency(f);
            for (int i = 0; i < 200; ++i) {
                float sample = (i == 0) ? 1.0f : 0.0f;
                float* ch[1] = { &sample };
                maag.process(ch, 1, 1);
                TEST_ASSERT(std::isfinite(sample), "Maag Air impulse response must be strictly finite");
            }
        }

        // Silent decay
        for (int i = 0; i < 10000; ++i) {
            float sample = 0.0f;
            float* ch[1] = { &sample };
            maag.process(ch, 1, 1);
            TEST_ASSERT(std::abs(sample) < 1e-4f, "Maag decay must be stable");
        }
    }

    return true;
}

bool testDualDynamicsLA2AAnd1176() {
    std::cout << "[*] Testing Dual Dynamics Stage (LA-2A Opto + 1176 FET)..." << std::endl;
    dsp171::CLA2ACompressor la2a;
    dsp171::CLA76Compressor fet1176;

    la2a.prepare(48000.0);
    la2a.setPeakReduction(45.0f); // 2-4 dB leveling
    la2a.setGain(40.0f);

    fet1176.prepare(48000.0);
    fet1176.setInputDb(18.0f);
    fet1176.setOutputDb(18.0f);
    fet1176.setRatio(dsp171::CLA76Compressor::Ratio::Ratio4);
    fet1176.setAttackKnob(3.0f);
    fet1176.setReleaseKnob(5.0f);

    // Process vocal dynamic swings
    for (int i = 0; i < 2000; ++i) {
        float inL = std::sin(i * 0.02f) * 1.5f; // Dynamic swing
        float inR = inL;

        // Stage 6A: LA-2A
        la2a.process(&inL, &inR, 1);
        TEST_ASSERT(std::isfinite(inL) && std::isfinite(inR), "LA-2A output must be finite");

        // Stage 6B: 1176
        fet1176.process(&inL, &inR, 1);
        TEST_ASSERT(std::isfinite(inL) && std::isfinite(inR), "1176 output must be finite");
        TEST_ASSERT(std::abs(inL) < 2.5f, "Dual-stage dynamics must control peak excursions");
    }

    TEST_ASSERT(la2a.getGainReductionL() > 0.1f, "LA-2A must register gain reduction");
    TEST_ASSERT(fet1176.getGainReductionL() > 0.1f, "1176 must register gain reduction");

    return true;
}

bool testEasyVoiceFullChain() {
    std::cout << "[*] Testing EasyVoiceChannelStrip (Complete 8-Stage Series Chain)..." << std::endl;
    const double srs[] = { 44100.0, 48000.0, 96000.0, 192000.0 };

    for (double sr : srs) {
        dsp171::EasyVoiceChannelStrip strip;
        strip.prepare(sr);

        // Turn on all modules
        strip.setExpanderEnabled(true);
        strip.setPreampEnabled(true);
        strip.setDeEsserEnabled(true);
        strip.setEQEnabled(true);
        strip.setAirEnabled(true);
        strip.setDeHarshEnabled(true);
        strip.setOptoEnabled(true);
        strip.setCompressorEnabled(true);
        strip.setDoublerEnabled(true);

        constexpr int blockSize = 256;
        std::vector<float> bufL(blockSize, 0.0f);
        std::vector<float> bufR(blockSize, 0.0f);

        // Run with synthetic vocal phrase
        for (int b = 0; b < 10; ++b) {
            for (int i = 0; i < blockSize; ++i) {
                float t = static_cast<float>(b * blockSize + i) / static_cast<float>(sr);
                bufL[i] = 0.4f * std::sin(2.0f * 3.14159f * 220.0f * t) +
                          0.2f * std::sin(2.0f * 3.14159f * 5500.0f * t); // Fundamental + Sibilance
                bufR[i] = bufL[i];
            }

            float* chs[2] = { bufL.data(), bufR.data() };
            strip.process(chs, 2, blockSize);

            for (int i = 0; i < blockSize; ++i) {
                TEST_ASSERT(std::isfinite(bufL[i]) && std::isfinite(bufR[i]), "Chain output must be strictly finite");
                TEST_ASSERT(std::abs(bufL[i]) < 5.0f, "Safety ceiling and dynamics must bound amplitude");
            }
        }
    }

    return true;
}

int main() {
    std::cout << "================================================================" << std::endl;
    std::cout << "  171 EASYVOICE PRO - MATHEMATICAL & PHYSICS VALIDATION SUITE   " << std::endl;
    std::cout << "================================================================" << std::endl;

    bool allPassed = true;
    allPassed &= testVocalNoiseExpander();
    allPassed &= testRenaissanceDeEsserBitExact();
    allPassed &= testMaagAirAndDeHarsh();
    allPassed &= testDualDynamicsLA2AAnd1176();
    allPassed &= testEasyVoiceFullChain();

    std::cout << "================================================================" << std::endl;
    if (allPassed) {
        std::cout << "  ALL 5 EASYVOICE PRO VALIDATION BATTERIES PASSED (100% SUCCESS)" << std::endl;
        std::cout << "================================================================" << std::endl;
        return 0;
    } else {
        std::cerr << "  FAILED ONE OR MORE TESTS!                                     " << std::endl;
        std::cout << "================================================================" << std::endl;
        return 1;
    }
}
