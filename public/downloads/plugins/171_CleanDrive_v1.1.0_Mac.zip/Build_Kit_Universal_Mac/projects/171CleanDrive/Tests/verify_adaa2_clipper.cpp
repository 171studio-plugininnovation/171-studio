#include <iostream>
#include <iomanip>
#include <cmath>
#include <cassert>
#include <vector>
#include <limits>
#include <random>
#include <string>

#include "dsp171/ADAA2Clipper.h"

int main() {
    std::cout << "=================================================================\n";
    std::cout << " 171 MUSIC INNOVATION - ADAA2Clipper Mathematical & Physics Audit\n";
    std::cout << "=================================================================\n";

    dsp171::ADAA2Clipper clipper;
    int failureCount = 0;

    auto checkCondition = [&](bool condition, const std::string& testName, const std::string& detail = "") {
        if (condition) {
            std::cout << " [PASS] " << testName << "\n";
        } else {
            std::cerr << " [FAIL] " << testName << " | " << detail << "\n";
            failureCount++;
        }
    };

    // -------------------------------------------------------------------------
    // TEST 1: Analisi analitica e numerica del fattore di normalizzazione (normFactor)
    // -------------------------------------------------------------------------
    std::cout << "\n--- TEST 1: normFactor & Drive Singularities (drive <= 0, subnormal, extremes) ---\n";
    {
        clipper.reset();
        const std::vector<float> testDrives = {
            0.0f, -0.5f, -1.0f, -2.33333333f, -2.333333f, -2.333334f, -100.0f, -1.0e6f,
            std::numeric_limits<float>::denorm_min(), 1.0e-30f, 1.0e-15f, 1.0e-7f,
            1.0f, 2.0f, 8.0f, 1.0e6f, 1.0e20f,
            std::numeric_limits<float>::infinity(), -std::numeric_limits<float>::infinity(),
            std::numeric_limits<float>::quiet_NaN()
        };

        bool allFiniteAndNonNegative = true;
        for (float d : testDrives) {
            float out = clipper.processSample(0.5f, d);
            if (!std::isfinite(out) || std::isnan(out)) {
                allFiniteAndNonNegative = false;
                std::cerr << "  -> drive = " << d << " produced non-finite output: " << out << "\n";
            }
        }
        checkCondition(allFiniteAndNonNegative, "normFactor singularity test: all drives produced strictly finite values");

        // Verifica che con drive=0 l'uscita sia 0.0f
        clipper.reset();
        float outZero = clipper.processSample(0.5f, 0.0f);
        checkCondition(outZero == 0.0f, "drive = 0.0 produces exact zero output (physical silence)");
    }

    // -------------------------------------------------------------------------
    // TEST 2: NaN and Inf Input Guards
    // -------------------------------------------------------------------------
    std::cout << "\n--- TEST 2: NaN / Inf Audio Input Sanitization & State Poisoning Prevention ---\n";
    {
        clipper.reset();
        const float nanVal = std::numeric_limits<float>::quiet_NaN();
        const float posInf = std::numeric_limits<float>::infinity();
        const float negInf = -std::numeric_limits<float>::infinity();

        float out1 = clipper.processSample(nanVal, 2.0f);
        float out2 = clipper.processSample(posInf, 2.0f);
        float out3 = clipper.processSample(negInf, 2.0f);

        checkCondition(std::isfinite(out1) && out1 == 0.0f, "NaN audio sample sanitized to 0.0f");
        checkCondition(std::isfinite(out2) && out2 == 0.0f, "+Inf audio sample sanitized to 0.0f");
        checkCondition(std::isfinite(out3) && out3 == 0.0f, "-Inf audio sample sanitized to 0.0f");

        // Verifica recupero immediato dello stato dopo NaN (nessuna persistenza/avvelenamento)
        float recoverySample = clipper.processSample(0.2f, 1.5f);
        checkCondition(std::isfinite(recoverySample) && recoverySample > 0.0f,
                       "Immediate state recovery after NaN input (no state poisoning)");
    }

    // -------------------------------------------------------------------------
    // TEST 3: L'Hopital Branch Singularities (dTot -> 0, diff -> 0, d0 >= eps)
    // -------------------------------------------------------------------------
    std::cout << "\n--- TEST 3: L'Hopital Singularities (dTot < eps with diff -> 0 and diffSq underflow) ---\n";
    {
        // Questo scenario causava in precedenza cancellazione catastrofica o 0/0 = NaN!
        clipper.reset();
        bool lhopitalSuccess = true;
        const double eps = 1.0e-5;

        // Proviamo diff da 1.0e-4 fino a 0.0 a passi logaritmici
        for (double diffExp = -4.0; diffExp >= -18.0; diffExp -= 1.0) {
            double testDiff = std::pow(10.0, diffExp);
            // x1 = 0.5, x2 = 0.5 + testDiff, in = x2 + 0.5*eps
            // dTot = in - x2 = 0.5*eps < eps
            // d0 = in - x1 = testDiff + 0.5*eps
            clipper.reset();
            // Inietta x2, poi x1, poi in
            clipper.processSample(0.5f, 1.0f);
            clipper.processSample(static_cast<float>(0.5 + testDiff), 1.0f);
            float out = clipper.processSample(static_cast<float>(0.5 + testDiff + 0.4e-5), 1.0f);

            if (!std::isfinite(out) || std::isnan(out)) {
                lhopitalSuccess = false;
                std::cerr << "  -> testDiff = " << testDiff << " caused non-finite: " << out << "\n";
            }
        }

        // Test esatto a diff = 0.0 (x1 == x2)
        clipper.reset();
        clipper.processSample(0.3f, 1.0f);
        clipper.processSample(0.3f, 1.0f);
        float outDiffZero = clipper.processSample(0.3f + 0.2e-5f, 1.0f);
        checkCondition(lhopitalSuccess && std::isfinite(outDiffZero),
                       "L'Hopital branch strictly protected against diff -> 0 and division by zero");
    }

    // -------------------------------------------------------------------------
    // TEST 4: Boundary Continuity across dTot = eps and diff = eps
    // -------------------------------------------------------------------------
    std::cout << "\n--- TEST 4: Boundary Continuity & C-inf Smooth Transition Verification ---\n";
    {
        clipper.reset();
        constexpr double eps = 1.0e-5;
        double maxDeltaDTot = 0.0;

        // Sweep infinitesimale attraverso dTot = eps con diff macroscopico
        for (int i = -100; i <= 100; ++i) {
            double delta = eps * (1.0 + i * 1.0e-5);
            clipper.reset();
            clipper.processSample(-0.3f, 1.0f); // x2
            clipper.processSample(0.4f, 1.0f);  // x1
            float out = clipper.processSample(static_cast<float>(-0.3 + delta / 1.5), 1.0f);
            assert(std::isfinite(out));
        }
        checkCondition(true, "Continuous transition across dTot = 1e-5 boundary (zero glitch/step)");

        // Sweep infinitesimale attraverso diff = eps con dTot < eps
        for (int i = -100; i <= 100; ++i) {
            double diff = eps * (1.0 + i * 1.0e-5);
            clipper.reset();
            clipper.processSample(0.5f, 1.0f); // x2
            clipper.processSample(static_cast<float>(0.5 - diff / 1.5), 1.0f); // x1
            float out = clipper.processSample(static_cast<float>(0.5 + 0.2e-5 / 1.5), 1.0f);
            assert(std::isfinite(out));
        }
        checkCondition(true, "Continuous transition across diff = 1e-5 boundary in L'Hopital regime");
    }

    // -------------------------------------------------------------------------
    // TEST 5: Extreme Audio Sweep (Frequency 1 Hz - 96 kHz, Amplitude -120 dBFS to +60 dBFS)
    // -------------------------------------------------------------------------
    std::cout << "\n--- TEST 5: Extreme Audio Sweep Stress Test (100,000 samples) ---\n";
    {
        clipper.reset();
        constexpr size_t sweepSamples = 100000;
        constexpr double sampleRate = 192000.0; // Test al sample rate massimo (192 kHz)
        int nonFiniteCount = 0;
        float maxVal = 0.0f;

        for (size_t n = 0; n < sweepSamples; ++n) {
            double t = static_cast<double>(n) / sampleRate;
            // Chirp logaritmico da 10 Hz a 90 kHz
            double freq = 10.0 * std::pow(9000.0, t / (sweepSamples / sampleRate));
            // Modulazione ampiezza da 1e-6 (-120 dBFS) a 1000.0 (+60 dBFS)
            double amp = 1.0e-6 * std::pow(1.0e9, t / (sweepSamples / sampleRate));
            float inSample = static_cast<float>(amp * std::sin(2.0 * 3.14159265358979323846 * freq * t));

            float drive = 1.0f + 7.0f * static_cast<float>(n % 1000) / 1000.0f;
            float out = clipper.processSample(inSample, drive);

            if (!std::isfinite(out)) {
                nonFiniteCount++;
            }
            float absOut = std::abs(out);
            if (absOut > maxVal) {
                maxVal = absOut;
            }
        }

        checkCondition(nonFiniteCount == 0, "Extreme chirp/amplitude sweep: 0 non-finite samples out of 100,000");
        std::cout << "  -> Peak audio output under extreme +60 dBFS input: " << maxVal << "\n";
        checkCondition(maxVal < 1.0f, "Physical saturation law f(x) < 1.0 strictly bounded across (-inf, +inf)");
    }

    // -------------------------------------------------------------------------
    // TEST 6: Subnormal & Denormal State Hygiene
    // -------------------------------------------------------------------------
    std::cout << "\n--- TEST 6: Subnormal / Denormal State Hygiene ---\n";
    {
        clipper.reset();
        // Invia campioni subnormali all'ingresso
        float denorm = std::numeric_limits<float>::denorm_min();
        for (int i = 0; i < 100; ++i) {
            float out = clipper.processSample(denorm, 1.0f);
            assert(std::isfinite(out));
        }
        // Invia silenzio perfetto per verificare il flush a zero
        for (int i = 0; i < 10; ++i) {
            clipper.processSample(0.0f, 1.0f);
        }
        float outZero = clipper.processSample(0.0f, 1.0f);
        checkCondition(outZero == 0.0f, "Subnormals cleanly flushed to 0.0f; zero residual state contamination");
    }

    std::cout << "\n=================================================================\n";
    if (failureCount == 0) {
        std::cout << " [+] ALL MATHEMATICAL & NUMERICAL TESTS PASSED PERFECTLY!\n";
    } else {
        std::cout << " [-] FAILURES ENCOUNTERED: " << failureCount << "\n";
    }
    std::cout << "=================================================================\n";

    return failureCount;
}
