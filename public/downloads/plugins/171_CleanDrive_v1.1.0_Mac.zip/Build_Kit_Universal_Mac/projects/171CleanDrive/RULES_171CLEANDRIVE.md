# 171CleanDrive – Master Engineering & DSP Directives
**Version:** 2.0-PRO  
**Author:** 171PluginInnovation Core Architecture Team  
**Standard:** Pro Audio VST3/AU Standard (Derived from FabFilter, Soundtoys, UAD, Plugin Alliance & Waves)

---

## 1. Regole Ferree di Sicurezza Real-Time (Audio Thread)
Nel metodo `processBlock()` e in tutti i metodi richiamati dal thread audio:

1. **DIVIETO ASSOLUTO DI ALLOCAZIONI SULL'HEAP:**
   - Mai usare `new`, `malloc`, `std::vector::push_back`, `std::string` o qualsiasi operazione che possa ridimensionare buffer dinamici.
   - Tutti i buffer, array e stati interni devono essere pre-allocati e dimensionati in `prepareToPlay()`.

2. **LOCK-FREE DISACCOPPIATO DALLA GUI:**
   - Mai usare `std::mutex`, `std::condition_variable` o primitive di blocco nel thread audio (rischio fatale di *Priority Inversion*).
   - Qualsiasi comunicazione verso la GUI (forme d'onda, valori RMS, VU meter) deve transitare esclusivamente tramite `LockFreeFIFO` (SPSC Lock-Free Ring Buffer con atomici memory-order acquire/release).

3. **PROTEZIONE DAI DENORMALI (FTZ/DAZ):**
   - Inserire tassativamente all'inizio di ogni blocco audio la guardia RAII:
     ```cpp
     juce::ScopedNoDenormals noDenormals;
     ```
   - Impedire che i filtri ricorsivi IIR decadano al di sotto di $1.0 \times 10^{-15}$.

4. **IMMUNITÀ A NAN E DIVISIONI PER ZERO:**
   - Nei calcoli non lineari e differenziali (ADAA, logaritmi, radici, divisioni di inviluppo), applicare sempre un epsilon di guardia ($\epsilon \ge 1.0 \times 10^{-5}$).
   - In caso di $\Delta x \to 0$, attivare il fallback numerico basato sullo sviluppo in serie di Taylor per evitare singolarità.

---

## 2. Direttive Algoritmiche e Matematiche del DSP

### A. Separazione Dinamica Transiente / Corpo (Zero Sfasamento)
* Il segnale in ingresso $x[n]$ deve essere scisso in due flussi a conservazione perfetta di fase ed energia:
  $$x_{\text{trans}}[n] = x[n] \cdot W_{\text{trans}}[n]$$
  $$x_{\text{tonal}}[n] = x[n] \cdot (1.0 - W_{\text{trans}}[n])$$
* $W_{\text{trans}}[n]$ deve essere pilotato dal rapporto tra inviluppo rapido ($\tau_{\text{att}} \approx 1.2\text{ ms}$) e inviluppo lento ($\tau_{\text{att}} \approx 30\text{ ms}$), con smoothing dipendente dalla frequenza di campionamento per eliminare ogni flutter sui bassi.

### B. Canale Transiente: ADAA-2 a 64-bit (Anti-Aliasing Matematico)
* Il transiente deve essere processato tramite soft-clipper cubico $f(x) = x - \frac{x^3}{3}$ con Antiderivative Antialiasing di 2° Ordine (ADAA-2) a doppia precisione (`double` 64-bit):
  $$y[n] = \frac{2}{x_0 - x_2} \left[ \frac{F_2(x_0) - F_2(x_1)}{x_0 - x_1} - \frac{F_2(x_1) - F_2(x_2)}{x_1 - x_2} \right]$$
* Quando $|x_0 - x_1| < 10^{-4}$, eseguire il fallback analitico su $F_1$ o $f(\bar{x})$ per azzerare il rumore numerico.

### C. Canale Tonale: Saturazione del Trasformatore con Bias Drift Dinamico
* Iniezione di 2ª armonica pulita a valore nullo a zero: $x \cdot |x|$.
* Modulazione del bias magnetico asimmetrico con costante di tempo $\tau \approx 80\text{ ms}$ (simula il flusso magnetico residuo del ferro).
* Filtro DC-Blocker a perno $10\text{ Hz}$ per rimuovere qualsiasi componente continua senza sfasare il sub-basso.

### D. Analog Safety Brickwall Soft-Ceiling (-0.09 dBFS)
* Anche con tutte le manopole al massimo ($100\%$ Drive, $+2\text{ dB}$ Punch, $+12\text{ dB}$ Output), il segnale in uscita deve essere **rigorosamente limitato sotto $-0.09\text{ dBFS}$ (0.9900 di picco max)**:
  $$\text{se } |x| > 0.85 \implies y = \operatorname{sgn}(x) \cdot \left( 0.85 + 0.14 \cdot \tanh\left(\frac{|x| - 0.85}{0.14}\right) \right)$$
* Nessun campione a $1.000$ o oltre: zero clipping digitale duro nei convertitori.

### E. Smoothing Continuo dei Parametri (Anti-Zipper)
* Tutti i potenziometri devono essere interpolati campione per campione tramite rampe continue a 20 ms (`juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear>` o `Multiplicative`). Zero scalini, zero click all'automazione.

---

## 3. Direttive Stereo e Tolleranze Analogiche (Stile TMT & Soundtoys)

1. **Micro-Tolleranze Canali L/R (TMT Spirit):**
   * Per evitare la sensazione "statica e finta" del digitale perfettamente simmetrico, applicare una leggera variazione di tolleranza ($\pm 0.3\%$) tra il canale sinistro e il canale destro sui filtri di cutoff e sul bias di saturazione.
2. **Coerenza Monocompatibile ($\rho \ge 0.3$):**
   * Verificare costantemente che il coefficiente di correlazione:
     $$\rho = \frac{\sum (L \cdot R)}{\sqrt{\sum L^2 \cdot \sum R^2}}$$
     non scenda sotto zero, evitando cancellazioni di fase quando il brano viene ascoltato su smartphone.

---

## 4. Direttive Grafiche e UI (Stile FabFilter / Analog Hardware)

1. **Disaccoppiamento Totale a 60 FPS:**
   * La GUI viene ridisegnata tramite timer a 60 Hz leggendo solo l'ultimo frame dalla `LockFreeFIFO`.
2. **Balistica Reale per gli Strumenti:**
   * **VU Meter:** Discretizzazione dell'equazione differenziale del 2° ordine IEC 60268-17 ($\zeta = 0.707$, tempo al $99\% = 300\text{ ms}$, overshoot controllato all'$1\%$).
   * **Oscilloscopio:** Persistenza a decadimento fosforico progressivo per un look CRT dorato.
3. **Integrazione Bitmap 1:1 Pixel-Perfect:**
   * Tutte le 7 manopole fotorealistiche e gli switch devono essere posizionati millimetricamente sul backplate $1024 \times 571$, con anelli neon a gradiente cromatico coerente.

---

## 5. Compatibilità DAW e Versioning dei Preset

1. **Cambio a Caldo di Sample Rate:**
   * In `prepareToPlay(sampleRate, samplesPerBlock)` ricalcolare obbligatoriamente tutti i coefficienti esponenziali $\alpha = 1 - e^{-1 / (\tau f_s)}$ e azzerare le memorie di stato con `reset()`.
2. **Versioning dello Stato nei Progetti:**
   * I salvataggi in `getStateInformation` devono includere un attributo intero `version="2"` all'interno dell'albero `juce::ValueTree`, garantendo la retrocompatibilità totale con i vecchi progetti degli utenti.
