#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include <dsp171/Common.h>
#include <dsp171/Oversampler.h>
#include <dsp171/TransientSplitter.h>
#include <dsp171/ADAA2Clipper.h>
#include <dsp171/TransformerSaturator.h>
#include <dsp171/ZDFTiltFilter.h>
#include <dsp171/LockFreeFIFO.h>
#include <dsp171/SafetyCeiling.h>

struct PluginPreset {
    const char* name;
    float drive;
    float transPunch;
    float warmth;
    float tilt;
    float splitSens;
    float mix;
    float outGain;
};

class AudioPluginAudioProcessor : public juce::AudioProcessor {
public:
    AudioPluginAudioProcessor();
    ~AudioPluginAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    void reset() override;

    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;

    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "171CleanDrive"; }

    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    // Gestione Preset di fabbrica
    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int index, const juce::String& newName) override;

    juce::AudioProcessorParameter* getBypassParameter() const override {
        return apvts.getParameter("bypass");
    }

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }
    dsp171::LockFreeVisualFIFO<512>& getVisualFIFO() noexcept { return visualFIFO; }
    float getCorrelation() const noexcept;

    static const std::vector<PluginPreset>& getFactoryPresets();

private:
    juce::AudioProcessorValueTreeState apvts;
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    static constexpr size_t MaxChannels = 2;
    dsp171::TransientSplitter transientSplitter;
    std::array<dsp171::ADAA2Clipper, MaxChannels> adaaClippers;
    std::array<dsp171::TransformerSaturator, MaxChannels> transformerSaturators;
    std::array<dsp171::ZDFTiltFilter, MaxChannels> tiltFilters;

    // Limiter True-Peak Conforme a ITU-R BS.1770-4 al Sample-Rate Nativo Post-Decimazione
    dsp171::TruePeakLimiter truePeakLimiterL;
    dsp171::TruePeakLimiter truePeakLimiterR;

    // Buffer di ritardo per allineamento campioni dell'oscilloscopio
    static constexpr size_t MaxVisualDelay = 256;
    std::array<float, MaxVisualDelay> visualInDelayBuffer{};
    size_t visualDelayWriteIdx = 0;

    // Motore Oversampling 4x da Studio con filtri half-band FIR ad alta pendenza
    dsp171::Oversampler oversampler;

    dsp171::LockFreeVisualFIFO<512> visualFIFO;

    std::atomic<float>* driveParam       = nullptr;
    std::atomic<float>* transPunchParam  = nullptr;
    std::atomic<float>* warmthParam      = nullptr;
    std::atomic<float>* tiltParam        = nullptr;
    std::atomic<float>* splitSensParam   = nullptr;
    std::atomic<float>* mixParam         = nullptr;
    std::atomic<float>* outGainParam     = nullptr;
    std::atomic<float>* bypassParam      = nullptr;

    // Smoothing dei parametri a livello di campione (anti-zipper noise e zero pop)
    juce::SmoothedValue<float> smoothedDrive;
    juce::SmoothedValue<float> smoothedPunch;
    juce::SmoothedValue<float> smoothedWarmth;
    juce::SmoothedValue<float> smoothedTilt;
    juce::SmoothedValue<float> smoothedSens;
    juce::SmoothedValue<float> smoothedMix;
    juce::SmoothedValue<float> smoothedOutGain;
    juce::SmoothedValue<float> smoothedBypass;

    int currentProgramIndex = 0;
    double currentBaseSampleRate = 44100.0;
    std::atomic<float> currentCorrelation{1.0f};

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AudioPluginAudioProcessor)
};
