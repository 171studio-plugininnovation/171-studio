#include <juce_gui_basics/juce_gui_basics.h>
#include "PluginProcessor.h"
#include "PluginEditor.h"

int main()
{
    juce::ScopedJuceInitialiser_GUI juceInit;

    AudioPluginAudioProcessor processor;
    processor.prepareToPlay(48000.0, 512);

    std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
    if (editor == nullptr)
        return 1;

    editor->setSize(1024, 571);

    // Imposta parametri musicali d'esempio per mostrare l'escursione delle manopole e i glow neon
    if (auto* p = processor.getAPVTS().getParameter("drive"))
        p->setValueNotifyingHost(processor.getAPVTS().getParameter("drive")->convertTo0to1(2.80f));
    if (auto* p = processor.getAPVTS().getParameter("trans_punch"))
        p->setValueNotifyingHost(processor.getAPVTS().getParameter("trans_punch")->convertTo0to1(1.45f));
    if (auto* p = processor.getAPVTS().getParameter("warmth"))
        p->setValueNotifyingHost(processor.getAPVTS().getParameter("warmth")->convertTo0to1(0.65f));
    if (auto* p = processor.getAPVTS().getParameter("tilt"))
        p->setValueNotifyingHost(processor.getAPVTS().getParameter("tilt")->convertTo0to1(0.35f));
    if (auto* p = processor.getAPVTS().getParameter("split_sens"))
        p->setValueNotifyingHost(processor.getAPVTS().getParameter("split_sens")->convertTo0to1(2.50f));
    if (auto* p = processor.getAPVTS().getParameter("mix"))
        p->setValueNotifyingHost(processor.getAPVTS().getParameter("mix")->convertTo0to1(0.85f));
    if (auto* p = processor.getAPVTS().getParameter("out_gain"))
        p->setValueNotifyingHost(processor.getAPVTS().getParameter("out_gain")->convertTo0to1(-1.5f));

    // Alimenta l'audio simulato per animare l'oscilloscopio
    juce::AudioBuffer<float> testBuffer(2, 512);
    for (int ch = 0; ch < 2; ++ch) {
        float* w = testBuffer.getWritePointer(ch);
        for (int i = 0; i < 512; ++i) {
            w[i] = std::sin(i * 0.05f) * 0.70f + std::sin(i * 0.15f) * 0.25f;
        }
    }
    juce::MidiBuffer midi;
    processor.processBlock(testBuffer, midi);

    editor->resized();

    // Snapshot dell'editor pixel-perfect
    juce::Image snapshot = editor->createComponentSnapshot(editor->getLocalBounds());

    const char* p1 = R"(C:\Users\171Studio\.gemini\antigravity\brain\32c5fb98-1154-4e19-9e35-7c8d33782be0\171CleanDrive_v2_Snapshot.png)";
    const char* p2 = R"(C:\Users\171Studio\.gemini\antigravity\scratch\171CleanDrive\171CleanDrive_v2_Snapshot.png)";
    for (const char* p : { p1, p2 }) {
        juce::File outFile(p);
        outFile.getParentDirectory().createDirectory();
        outFile.deleteFile();
        juce::FileOutputStream stream(outFile);
        if (stream.openedOk()) {
            juce::PNGImageFormat png;
            png.writeImageToStream(snapshot, stream);
        }
    }

    return 0;
}
