#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include "GUI/CustomKnob.h"
#include "GUI/SpectralVisualizer.h"
#include "GUI/HardwareSwitch.h"
#include "GUI/RapidGUI.h"

// ==============================================================================
// LookAndFeel per il Selettore Preset Master (in stile 171 Studio Boutique)
// ==============================================================================
class Studio171ComboBoxLookAndFeel : public juce::LookAndFeel_V4 {
public:
    Studio171ComboBoxLookAndFeel() {
        setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff16181f));
        setColour(juce::ComboBox::textColourId, juce::Colour(0xfff1f5f9));
        setColour(juce::ComboBox::outlineColourId, juce::Colour(0xffc5a059));
        setColour(juce::ComboBox::arrowColourId, juce::Colour(0xffd4af37));

        setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xf40f1116));
        setColour(juce::PopupMenu::textColourId, juce::Colour(0xfff1f5f9));
        setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xff2a2418));
        setColour(juce::PopupMenu::highlightedTextColourId, juce::Colour(0xffffe082));
    }

    void drawComboBox(juce::Graphics& g, int width, int height, bool isButtonDown,
                      int buttonX, int buttonY, int buttonW, int buttonH, juce::ComboBox& box) override
    {
        juce::ignoreUnused(isButtonDown);
        auto bounds = juce::Rectangle<float>(0.0f, 0.0f, static_cast<float>(width), static_cast<float>(height)).reduced(1.0f);

        // 1. Ombra portata incassata
        g.setColour(juce::Colours::black.withAlpha(0.50f));
        g.fillRoundedRectangle(bounds.translated(1.0f, 2.0f), 4.0f);

        // 2. Corpo metallico in titanio scuro spazzolato
        juce::ColourGradient grad(juce::Colour(0xff222630), bounds.getX(), bounds.getY(),
                                  juce::Colour(0xff101217), bounds.getX(), bounds.getBottom(), false);
        g.setGradientFill(grad);
        g.fillRoundedRectangle(bounds, 4.0f);

        // 3. Bordo satinato in oro/bronzo cesellato
        g.setColour(box.hasKeyboardFocus(true) ? juce::Colour(0xffffe082) : juce::Colour(0xffc5a059));
        g.drawRoundedRectangle(bounds, 4.0f, 1.3f);

        // Micro-riflesso speculare sul bordo superiore
        g.setColour(juce::Colour(0x33ffffff));
        g.drawHorizontalLine(juce::roundToInt(bounds.getY() + 1.0f), bounds.getX() + 4.0f, bounds.getRight() - 4.0f);

        // Divisore verticale tra testo e freccia
        float divX = static_cast<float>(buttonX);
        g.setColour(juce::Colour(0x35c5a059));
        g.drawVerticalLine(juce::roundToInt(divX), bounds.getY() + 4.0f, bounds.getBottom() - 4.0f);

        // Freccia chevron dorata
        float arrowCx = static_cast<float>(buttonX) + static_cast<float>(buttonW) * 0.5f;
        float arrowCy = static_cast<float>(buttonY) + static_cast<float>(buttonH) * 0.5f;
        float arrowW = 8.0f;
        float arrowH = 5.0f;

        juce::Path arrow;
        arrow.startNewSubPath(arrowCx - arrowW * 0.5f, arrowCy - arrowH * 0.5f);
        arrow.lineTo(arrowCx, arrowCy + arrowH * 0.5f);
        arrow.lineTo(arrowCx + arrowW * 0.5f, arrowCy - arrowH * 0.5f);

        g.setColour(juce::Colour(0xffd4af37));
        g.strokePath(arrow, juce::PathStrokeType(2.0f, juce::PathStrokeType::mitered, juce::PathStrokeType::rounded));
    }

    juce::Font getComboBoxFont(juce::ComboBox&) override {
        return juce::FontOptions(11.5f, juce::Font::bold);
    }

    void positionComboBoxText(juce::ComboBox& box, juce::Label& label) override {
        label.setBounds(8, 1, box.getWidth() - 30, box.getHeight() - 2);
        label.setFont(getComboBoxFont(box));
    }
};

class AudioPluginAudioProcessorEditor : public juce::AudioProcessorEditor,
                                        public juce::ComboBox::Listener {
public:
    explicit AudioPluginAudioProcessorEditor(AudioPluginAudioProcessor&);
    ~AudioPluginAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;
    void comboBoxChanged(juce::ComboBox*) override;

private:
    AudioPluginAudioProcessor& processorRef;

    // Visualizzatore spettrale dorato 60 FPS
    gui171::SpectralVisualizer visualizer;

    // Le 7 manopole fotorealistiche con effetto neon (knob_171_machined)
    std::unique_ptr<gui171::AnalogStyledKnob> driveKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> punchKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> warmthKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> tiltKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> sensKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> mixKnob;
    std::unique_ptr<gui171::AnalogStyledKnob> outputKnob;

    // Sincronizzazione APVTS
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;

    std::unique_ptr<SliderAttachment> driveAttach;
    std::unique_ptr<SliderAttachment> punchAttach;
    std::unique_ptr<SliderAttachment> warmthAttach;
    std::unique_ptr<SliderAttachment> tiltAttach;
    std::unique_ptr<SliderAttachment> sensAttach;
    std::unique_ptr<SliderAttachment> mixAttach;
    std::unique_ptr<SliderAttachment> outputAttach;

    // Selettore dei Preset e Stepper Boutique
    Studio171ComboBoxLookAndFeel presetLookAndFeel;
    juce::ComboBox presetComboBox;
    std::unique_ptr<gui171::BoutiqueStepperButton> prevPresetBtn;
    std::unique_ptr<gui171::BoutiqueStepperButton> nextPresetBtn;

    // Modulo Master Bypass Heavy-Duty con piastra metallica, 4 viti Allen e spia rubino
    std::unique_ptr<gui171::HeavyDutyBypassModule> bypassSwitch;
    std::unique_ptr<ButtonAttachment> bypassAttach;

    // Immagine di sfondo ad altissima definizione
    juce::Image backgroundImage;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AudioPluginAudioProcessorEditor)
};
