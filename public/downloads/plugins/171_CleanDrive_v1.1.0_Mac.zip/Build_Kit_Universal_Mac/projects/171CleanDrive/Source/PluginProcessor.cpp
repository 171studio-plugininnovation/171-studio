#include "PluginProcessor.h"
#include "PluginEditor.h"

const std::vector<PluginPreset>& AudioPluginAudioProcessor::getFactoryPresets() {
    static const std::vector<PluginPreset> presets = {
        { "01 | Default Punch",         1.30f, 1.00f, 0.36f,  0.38f, 2.85f, 1.00f, -1.4f },
        { "02 | Golden Master Glue",    1.15f, 0.70f, 0.45f,  0.15f, 1.80f, 1.00f, -0.5f },
        { "03 | Snare Crack & Bite",    2.20f, 1.60f, 0.20f,  0.35f, 2.40f, 1.00f, -1.2f },
        { "04 | Heavy Tube Bass",       2.80f, 0.40f, 0.85f, -0.40f, 1.00f, 1.00f, -2.0f },
        { "05 | Analog Tape Saturator", 1.80f, 0.90f, 0.65f, -0.10f, 1.60f, 1.00f, -0.8f },
        { "06 | Vocal Presence & Air",  1.40f, 1.20f, 0.25f,  0.50f, 2.00f, 0.85f, -1.0f },
        { "07 | Parallel Drum Smasher", 4.50f, 1.80f, 0.50f,  0.20f, 2.80f, 0.50f, -3.0f },
        { "08 | Vintage Germanium",     3.50f, 1.40f, 0.75f,  0.30f, 2.20f, 0.90f, -2.5f }
    };
    return presets;
}

AudioPluginAudioProcessor::AudioPluginAudioProcessor()
    : AudioProcessor(BusesProperties()
                     .withInput("Input", juce::AudioChannelSet::stereo(), true)
                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "Parameters", createParameterLayout())
{
    driveParam      = apvts.getRawParameterValue("drive");
    transPunchParam = apvts.getRawParameterValue("trans_punch");
    warmthParam     = apvts.getRawParameterValue("warmth");
    tiltParam       = apvts.getRawParameterValue("tilt");
    splitSensParam  = apvts.getRawParameterValue("split_sens");
    mixParam        = apvts.getRawParameterValue("mix");
    outGainParam    = apvts.getRawParameterValue("out_gain");
    bypassParam     = apvts.getRawParameterValue("bypass");
}

AudioPluginAudioProcessor::~AudioPluginAudioProcessor() = default;

juce::AudioProcessorValueTreeState::ParameterLayout AudioPluginAudioProcessor::createParameterLayout() {
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"drive", 1}, "Drive",
        juce::NormalisableRange<float>(1.0f, 8.0f, 0.01f, 0.5f), 1.30f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"trans_punch", 1}, "Punch",
        juce::NormalisableRange<float>(0.0f, 2.0f, 0.01f), 1.00f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"warmth", 1}, "Warmth",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 0.36f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"tilt", 1}, "Tone Tilt",
        juce::NormalisableRange<float>(-1.0f, 1.0f, 0.01f), 0.38f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"split_sens", 1}, "Sens",
        juce::NormalisableRange<float>(0.5f, 4.0f, 0.01f), 2.85f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"mix", 1}, "Mix",
        juce::NormalisableRange<float>(0.0f, 1.0f, 0.01f), 1.00f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"out_gain", 1}, "Output",
        juce::NormalisableRange<float>(-18.0f, 12.0f, 0.1f), -1.4f));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"bypass", 1}, "Bypass", false));

    return { params.begin(), params.end() };
}

int AudioPluginAudioProcessor::getNumPrograms() {
    return static_cast<int>(getFactoryPresets().size());
}

int AudioPluginAudioProcessor::getCurrentProgram() {
    return currentProgramIndex;
}

void AudioPluginAudioProcessor::setCurrentProgram(int index) {
    const auto& presets = getFactoryPresets();
    if (index >= 0 && index < static_cast<int>(presets.size())) {
        currentProgramIndex = index;
        const auto& p = presets[static_cast<size_t>(index)];

        if (auto* param = apvts.getParameter("drive"))       param->setValueNotifyingHost(param->convertTo0to1(p.drive));
        if (auto* param = apvts.getParameter("trans_punch")) param->setValueNotifyingHost(param->convertTo0to1(p.transPunch));
        if (auto* param = apvts.getParameter("warmth"))      param->setValueNotifyingHost(param->convertTo0to1(p.warmth));
        if (auto* param = apvts.getParameter("tilt"))        param->setValueNotifyingHost(param->convertTo0to1(p.tilt));
        if (auto* param = apvts.getParameter("split_sens"))  param->setValueNotifyingHost(param->convertTo0to1(p.splitSens));
        if (auto* param = apvts.getParameter("mix"))         param->setValueNotifyingHost(param->convertTo0to1(p.mix));
        if (auto* param = apvts.getParameter("out_gain"))    param->setValueNotifyingHost(param->convertTo0to1(p.outGain));
    }
}

const juce::String AudioPluginAudioProcessor::getProgramName(int index) {
    const auto& presets = getFactoryPresets();
    if (index >= 0 && index < static_cast<int>(presets.size())) {
        return presets[static_cast<size_t>(index)].name;
    }
    return {};
}

void AudioPluginAudioProcessor::changeProgramName(int, const juce::String&) {}

void AudioPluginAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock) {
    currentBaseSampleRate = sampleRate;

    // Configurazione dell'Oversampling a 4x (o 2x sopra 88.2 kHz per massima efficienza)
    const auto oversampleFactor = (sampleRate >= 88200.0)
        ? dsp171::Oversampler::Factor::x2
        : dsp171::Oversampler::Factor::x4;

    oversampler.prepare(MaxChannels, static_cast<size_t>(samplesPerBlock), sampleRate, oversampleFactor, true);

    const double multiplier = static_cast<double>(1 << static_cast<int>(oversampleFactor));
    const double effectiveRate = sampleRate * multiplier;

    transientSplitter.prepare(effectiveRate);
    for (size_t ch = 0; ch < MaxChannels; ++ch) {
        adaaClippers[ch].reset();
        transformerSaturators[ch].prepare(effectiveRate);
        tiltFilters[ch].prepare(effectiveRate);
    }

    truePeakLimiterL.prepare(sampleRate);
    truePeakLimiterR.prepare(sampleRate);

    // Inizializza lo smoothing dei parametri (20 ms di rampa anti-zipper nel dominio sovracampionato)
    constexpr double rampTimeSec = 0.020;
    smoothedDrive.reset(effectiveRate, rampTimeSec);
    smoothedPunch.reset(effectiveRate, rampTimeSec);
    smoothedWarmth.reset(effectiveRate, rampTimeSec);
    smoothedTilt.reset(effectiveRate, rampTimeSec);
    smoothedSens.reset(effectiveRate, rampTimeSec);
    smoothedMix.reset(effectiveRate, rampTimeSec);
    smoothedOutGain.reset(effectiveRate, rampTimeSec);
    smoothedBypass.reset(effectiveRate, 0.015); // 15 ms rampa di crossfade bypass

    // Azzeramento deterministico di tutti gli stati interni per cambio a caldo del sample rate
    reset();

    // Notifica la DAW dell'esatta compensazione di latenza: Oversampler + True-Peak Lookahead
    const int totalLatency = static_cast<int>(oversampler.getLatencyInSamples() + dsp171::TruePeakLimiter::LookaheadLatency);
    setLatencySamples(totalLatency);
}

void AudioPluginAudioProcessor::releaseResources() {
    reset();
}

void AudioPluginAudioProcessor::reset() {
    oversampler.reset();
    transientSplitter.reset();
    for (size_t ch = 0; ch < MaxChannels; ++ch) {
        adaaClippers[ch].reset();
        transformerSaturators[ch].reset();
        tiltFilters[ch].reset();
    }
    truePeakLimiterL.reset();
    truePeakLimiterR.reset();

    visualInDelayBuffer.fill(0.0f);
    visualDelayWriteIdx = 0;
    visualFIFO.reset();
    currentCorrelation.store(1.0f, std::memory_order_relaxed);
}

bool AudioPluginAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const {
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo()) {
        return false;
    }
    return layouts.getMainInputChannelSet() == layouts.getMainOutputChannelSet();
}

void AudioPluginAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) {
    juce::ScopedNoDenormals noDenormals;

    const int numChannels = buffer.getNumChannels();
    const int numSamples  = buffer.getNumSamples();

    if (numChannels == 0 || numSamples == 0) return;

    // Imposta i target per l'interpolatore continuo
    smoothedDrive.setTargetValue(driveParam->load(std::memory_order_relaxed));
    smoothedPunch.setTargetValue(transPunchParam->load(std::memory_order_relaxed));
    smoothedWarmth.setTargetValue(warmthParam->load(std::memory_order_relaxed));
    smoothedTilt.setTargetValue(tiltParam->load(std::memory_order_relaxed));
    smoothedSens.setTargetValue(splitSensParam->load(std::memory_order_relaxed));
    smoothedMix.setTargetValue(mixParam->load(std::memory_order_relaxed));
    smoothedOutGain.setTargetValue(juce::Decibels::decibelsToGain(outGainParam->load(std::memory_order_relaxed)));
    smoothedBypass.setTargetValue(bypassParam->load(std::memory_order_relaxed) > 0.5f ? 1.0f : 0.0f);

    dsp171::CleanDriveVisualFrame frame;
    const int sampleDecimate = std::max(1, numSamples / static_cast<int>(dsp171::CleanDriveVisualFrame::FrameSamples));
    int frameWriteIdx = 0;
    float inSumSq = 0.0f;

    const size_t totalLatency = static_cast<size_t>(getLatencySamples());

    // Memorizza i campioni di input nel delay buffer per allineare temporalmente l'oscilloscopio
    for (int i = 0; i < numSamples; ++i) {
        const float inSample = buffer.getSample(0, i);
        inSumSq += inSample * inSample;

        visualInDelayBuffer[visualDelayWriteIdx] = inSample;
        const size_t readIdx = (visualDelayWriteIdx + MaxVisualDelay - totalLatency) % MaxVisualDelay;
        const float delayedInSample = visualInDelayBuffer[readIdx];
        visualDelayWriteIdx = (visualDelayWriteIdx + 1) % MaxVisualDelay;

        if (i % sampleDecimate == 0 && frameWriteIdx < static_cast<int>(dsp171::CleanDriveVisualFrame::FrameSamples)) {
            frame.samplesIn[static_cast<size_t>(frameWriteIdx)] = delayedInSample;
            frameWriteIdx++;
        }
    }

    float blockTransEnergy = 0.0f;
    size_t totalOversampledSamples = 0;

    // 1. ELABORAZIONE SOVRACAMPIONATA 4x AD ALTA DEFINIZIONE
    oversampler.process(buffer, [&](juce::dsp::AudioBlock<float>& block, float /*rate*/) {
        const int oversampledSamples = static_cast<int>(block.getNumSamples());
        const int oversampledChannels = static_cast<int>(block.getNumChannels());
        totalOversampledSamples = static_cast<size_t>(oversampledSamples);

        float* ch0 = block.getChannelPointer(0);
        float* ch1 = oversampledChannels > 1 ? block.getChannelPointer(1) : ch0;
        const bool isStereo = (oversampledChannels > 1);

        for (int i = 0; i < oversampledSamples; ++i) {
            const float curDrive   = smoothedDrive.getNextValue();
            const float curPunch   = smoothedPunch.getNextValue();
            const float curWarmth  = smoothedWarmth.getNextValue();
            const float curTilt    = smoothedTilt.getNextValue();
            const float curSens    = smoothedSens.getNextValue();
            const float curMix     = smoothedMix.getNextValue();
            const float curOutGain = smoothedOutGain.getNextValue();
            const float curBypass  = smoothedBypass.getNextValue();

            const float punchGain = curPunch >= 1.0f 
                ? 1.0f + (curPunch - 1.0f) * 0.75f 
                : (0.35f + 0.65f * curPunch);

            transientSplitter.setSensitivity(curSens);

            // Stereo Micro-Tolerances (TMT Analog Spirit +/- 0.3%)
            // Channel L: drive * 0.9985f, warmth * 0.9970f, tilt * 0.9970f
            // Channel R: drive * 1.0015f, warmth * 1.0030f, tilt * 1.0030f
            const float driveL  = isStereo ? (curDrive  * 0.9985f) : curDrive;
            const float driveR  = curDrive  * 1.0015f;
            const float warmthL = isStereo ? (curWarmth * 0.9970f) : curWarmth;
            const float warmthR = curWarmth * 1.0030f;
            const float tiltL   = isStereo ? (curTilt   * 0.9970f) : curTilt;
            const float tiltR   = curTilt   * 1.0030f;

            tiltFilters[0].setTilt(tiltL);
            if (isStereo) {
                tiltFilters[1].setTilt(tiltR);
            }

            const float dryL = ch0[i];
            const float dryR = ch1[i];

            // 1. Separazione Transiente / Tonale Stereo-Linked (preserva al 100% il centro stereo)
            auto split = transientSplitter.processStereo(dryL, dryR);

            // 2. Canale Transiente: ADAA-2 Diode Clipper con tolleranze analogiche indipendenti
            const float satTransL = adaaClippers[0].processSample(split.transL, driveL) * punchGain;
            const float satTransR = isStereo ? (adaaClippers[1].processSample(split.transR, driveR) * punchGain) : satTransL;

            // 3. Canale Tonale: Saturatore a Trasformatore con Integrazione Faraday e saturazione analogica TMT
            const float satTonalL = transformerSaturators[0].processSample(split.tonalL, driveL, warmthL);
            const float satTonalR = isStereo ? transformerSaturators[1].processSample(split.tonalR, driveR, warmthR) : satTonalL;

            // 4. Ricombinazione coerente a conservazione di fase
            const float wetBeforeTiltL = satTransL + satTonalL;
            const float wetBeforeTiltR = satTransR + satTonalR;

            // 5. Filtro Invariante ZDF Baxandall Tilt (Pivot 850 Hz rigoroso a 0.00 dB)
            const float wetProcessedL = tiltFilters[0].processSample(wetBeforeTiltL);
            const float wetProcessedR = isStereo ? tiltFilters[1].processSample(wetBeforeTiltR) : wetProcessedL;

            // 6. Blending Dry / Wet a volume calibrato e Trim Output
            const float wetRawL = ((dryL * (1.0f - curMix)) + (wetProcessedL * curMix)) * curOutGain;
            const float wetRawR = ((dryR * (1.0f - curMix)) + (wetProcessedR * curMix)) * curOutGain;

            // 7. Crossfade continuo con il Bypass nel dominio sovracampionato
            ch0[i] = (wetRawL * (1.0f - curBypass)) + (dryL * curBypass);
            if (isStereo) {
                ch1[i] = (wetRawR * (1.0f - curBypass)) + (dryR * curBypass);
            }

            blockTransEnergy += split.transientRatio;
        }
    });

    // 2. POST-DECIMAZIONE AL SAMPLE-RATE NATIVO:
    // Applicazione del Limiter True-Peak Conforme a ITU-R BS.1770-4
    // seguito dal Brickwall Soft-Ceiling analogico a -0.09 dBFS (0.9900 max peak)
    // Eseguito DOPO il downsampling FIR per eliminare al 100% l'overshoot di Gibbs!
    for (int i = 0; i < numSamples; ++i) {
        float sL = buffer.getSample(0, i);
        float sR = numChannels > 1 ? buffer.getSample(1, i) : sL;
        float outL = 0.0f;
        float outR = 0.0f;

        dsp171::TruePeakLimiter::processStereoPair(truePeakLimiterL, truePeakLimiterR,
                                                  sL, sR, outL, outR, -0.09f);

        // Analog Safety Brickwall Soft-Ceiling (-0.09 dBFS / 0.9900 max peak)
        outL = dsp171::applySafetyCeiling(outL);
        outR = dsp171::applySafetyCeiling(outR);

        buffer.setSample(0, i, outL);
        if (numChannels > 1) {
            buffer.setSample(1, i, outR);
        }
    }

    // Misurazioni post-oversampling all'uscita standard della DAW
    std::array<float, MaxChannels> outSumSq{0.0f, 0.0f};
    std::array<float, MaxChannels> peakOut{0.0f, 0.0f};
    float outDotProductLR = 0.0f;
    int outDecimateIdx = 0;

    for (int i = 0; i < numSamples; ++i) {
        if (numChannels > 1) {
            outDotProductLR += buffer.getSample(0, i) * buffer.getSample(1, i);
        }
        for (int ch = 0; ch < numChannels; ++ch) {
            const size_t chIdx = static_cast<size_t>(ch < 2 ? ch : 0);
            const float sample = buffer.getSample(ch, i);
            const float absVal = std::abs(sample);
            outSumSq[chIdx] += sample * sample;
            if (absVal > peakOut[chIdx]) {
                peakOut[chIdx] = absVal;
            }

            if (ch == 0 && (i % sampleDecimate == 0) && outDecimateIdx < static_cast<int>(dsp171::CleanDriveVisualFrame::FrameSamples)) {
                frame.samplesOut[static_cast<size_t>(outDecimateIdx)] = sample;
                outDecimateIdx++;
            }
        }
    }

    // Monitoraggio e verifica mono-compatibilità (rho >= 0.3)
    if (numChannels > 1) {
        const float energyProd = outSumSq[0] * outSumSq[1];
        if (energyProd > 1.0e-9f) {
            const float rho = outDotProductLR / std::sqrt(energyProd);
            currentCorrelation.store(std::clamp(rho, -1.0f, 1.0f), std::memory_order_relaxed);
        } else {
            currentCorrelation.store(1.0f, std::memory_order_relaxed);
        }
    } else {
        currentCorrelation.store(1.0f, std::memory_order_relaxed);
    }

    frame.inRMS     = std::sqrt(inSumSq / static_cast<float>(numSamples));
    frame.outRMS_L  = std::sqrt(outSumSq[0] / static_cast<float>(numSamples));
    frame.outRMS_R  = numChannels > 1 ? std::sqrt(outSumSq[1] / static_cast<float>(numSamples)) : frame.outRMS_L;
    frame.peak_L    = peakOut[0];
    frame.peak_R    = numChannels > 1 ? peakOut[1] : frame.peak_L;

    const float denom = static_cast<float>(totalOversampledSamples > 0 ? totalOversampledSamples : 1);
    const float rawTransRatio = blockTransEnergy / denom;
    const float signalActivity = std::min(1.0f, frame.outRMS_L * 4.0f);
    frame.transientRatio = std::clamp(rawTransRatio * 2.2f * signalActivity, 0.0f, 1.0f);
    frame.tonalRatio     = std::clamp((1.0f - rawTransRatio * 0.7f) * signalActivity, 0.0f, 1.0f);

    visualFIFO.push(frame);
}

juce::AudioProcessorEditor* AudioPluginAudioProcessor::createEditor() {
    return new AudioPluginAudioProcessorEditor(*this);
}

void AudioPluginAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    auto state = apvts.copyState();
    state.setProperty("version", 2, nullptr);
    state.setProperty("currentPreset", currentProgramIndex, nullptr);
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void AudioPluginAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType())) {
        const int version = xmlState->getIntAttribute("version", 1);
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
        currentProgramIndex = apvts.state.getProperty("currentPreset", 0);

        if (version < 2) {
            if (auto* param = apvts.getParameter("bypass")) {
                param->setValueNotifyingHost(0.0f);
            }
        }
    }
}

float AudioPluginAudioProcessor::getCorrelation() const noexcept {
    return currentCorrelation.load(std::memory_order_relaxed);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new AudioPluginAudioProcessor();
}
