#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_graphics/juce_graphics.h>
#include <vector>
#include <memory>
#include <functional>
#include <cmath>

namespace plugin_171
{
    // ==============================================================================
    // ENUMS & STYLES
    // ==============================================================================
    enum class ChassisTheme
    {
        VintageDarkBronze,
        BrushedGunmetal,
        MasteringObsidian,
        ClassicBritishMaroon
    };

    enum class KnobStyle
    {
        TeardropBronze,
        NeveMarconiRed,
        NeveMarconiBlue,
        APIAirconKnurled,
        LA2ABakeliteScalloped,
        ChickenHeadSelector,
        PrecisionGunmetalKnurled
    };

    enum class ScaleDialType
    {
        None,
        Percent0To100,
        Frequency20To20k,
        DecibelsMinusInfPlus12,
        Detented11Positions,
        DetentedCenterZero
    };

    enum class VUDialStyle
    {
        VU_Gain,
        GainReduction
    };

    enum class PointerStyle
    {
        ClassicNeedle,
        RadioSweeperWand
    };

    enum class SwitchStyle
    {
        HeavyDutyChromeBaton,
        BoutiqueBrassToggle,
        RockerPowerNeonRuby,
        SquareConsoleSoloAmber
    };

    // ==============================================================================
    // 1. RAPID KNOB COMPONENT
    // ==============================================================================
    class RapidKnob : public juce::Slider
    {
    public:
        RapidKnob(const juce::String& labelText = "", 
                  KnobStyle kStyle = KnobStyle::TeardropBronze,
                  ScaleDialType sStyle = ScaleDialType::Percent0To100)
            : label(labelText), knobStyle(kStyle), scaleStyle(sStyle)
        {
            setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
            setAngleRange(-145.0f, 145.0f);
            setColour(juce::Slider::rotarySliderFillColourId, juce::Colour(0xffd89f3c));
        }

        void setAngleRange(float minDegrees, float maxDegrees)
        {
            minAngleRad = juce::degreesToRadians(minDegrees);
            maxAngleRad = juce::degreesToRadians(maxDegrees);
        }

        void setCustomImages(const juce::Image& knob, const juce::Image& scale = juce::Image())
        {
            knobImg = knob;
            scaleImg = scale;
            repaint();
        }

        void setLabel(const juce::String& newLabel) { label = newLabel; repaint(); }
        void setScaleType(ScaleDialType type) { scaleStyle = type; repaint(); }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float labelHeight = 20.0f;
            const float valueHeight = 14.0f;
            auto knobArea = bounds.withTrimmedBottom(labelHeight + valueHeight).reduced(4.0f);

            const float size = juce::jmin(knobArea.getWidth(), knobArea.getHeight());
            const float cx = knobArea.getCentreX();
            const float cy = knobArea.getCentreY();
            auto dialRect = knobArea.withSizeKeepingCentre(size, size);

            const float norm = (float)(getValue() - getMinimum()) / (float)(getMaximum() - getMinimum());
            const float angle = minAngleRad + norm * (maxAngleRad - minAngleRad);

            // 1. Draw Scale Ring (Stationary background dial)
            if (scaleImg.isValid())
            {
                g.drawImage(scaleImg, dialRect, juce::RectanglePlacement::centred);
            }
            else if (scaleStyle != ScaleDialType::None)
            {
                drawProceduralScale(g, cx, cy, size * 0.48f);
            }

            // 2. Draw Knob Body (Rotated by angle)
            const float knobSize = size * 0.72f;
            auto knobRect = knobArea.withSizeKeepingCentre(knobSize, knobSize);

            // Subtle drop shadow under knob body
            g.setColour(juce::Colours::black.withAlpha(0.55f));
            g.fillEllipse(knobRect.translated(2.0f, 3.5f));

            if (knobImg.isValid())
            {
                juce::Graphics::ScopedSaveState state(g);
                g.addTransform(juce::AffineTransform::rotation(angle, cx, cy));
                g.drawImage(knobImg, knobRect, juce::RectanglePlacement::centred);
            }
            else
            {
                drawProceduralKnob(g, cx, cy, knobSize * 0.5f, angle);
            }

            // 3. Draw Serigraphic Parameter Label
            if (label.isNotEmpty())
            {
                auto labelRect = juce::Rectangle<float>(bounds.getX(), bounds.getBottom() - labelHeight - valueHeight, bounds.getWidth(), labelHeight);
                g.setColour(juce::Colour(0xffd89f3c));
                g.setFont(juce::FontOptions(11.5f, juce::Font::bold));
                g.drawText(label, labelRect, juce::Justification::centred, false);
            }

            // 4. Draw Parameter Value readout
            auto valueRect = juce::Rectangle<float>(bounds.getX(), bounds.getBottom() - valueHeight, bounds.getWidth(), valueHeight);
            g.setColour(juce::Colour(0xff8e94a4));
            g.setFont(juce::FontOptions(10.5f));
            g.drawText(getTextFromValue(getValue()), valueRect, juce::Justification::centred, false);
        }

    private:
        void drawProceduralScale(juce::Graphics& g, float cx, float cy, float radius)
        {
            const int numTicks = (scaleStyle == ScaleDialType::Detented11Positions) ? 11 : 21;
            for (int i = 0; i < numTicks; ++i)
            {
                float tNorm = (float)i / (float)(numTicks - 1);
                float a = minAngleRad + tNorm * (maxAngleRad - minAngleRad) - juce::MathConstants<float>::halfPi;
                float rInner = (i % 2 == 0) ? radius - 6.0f : radius - 3.5f;
                float rOuter = radius;

                float x1 = cx + std::cos(a) * rInner;
                float y1 = cy + std::sin(a) * rInner;
                float x2 = cx + std::cos(a) * rOuter;
                float y2 = cy + std::sin(a) * rOuter;

                bool isMajor = (i % 2 == 0);
                g.setColour(isMajor ? juce::Colour(0xffc59c52) : juce::Colour(0x88735c3a));
                g.drawLine(x1, y1, x2, y2, isMajor ? 1.4f : 1.0f);
            }
        }

        void drawProceduralKnob(juce::Graphics& g, float cx, float cy, float radius, float angle)
        {
            // Machined Bronze/Gunmetal cylindrical base
            juce::ColourGradient grad(juce::Colour(0xff3a352d), cx - radius, cy - radius,
                                     juce::Colour(0xff161411), cx + radius, cy + radius, true);
            g.setGradientFill(grad);
            g.fillEllipse(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f);

            // Beveled brass rim
            g.setColour(juce::Colour(0xffd89f3c).withAlpha(0.7f));
            g.drawEllipse(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f, 1.5f);

            // Top cap
            float innerR = radius * 0.78f;
            g.setColour(juce::Colour(0xff121214));
            g.fillEllipse(cx - innerR, cy - innerR, innerR * 2.0f, innerR * 2.0f);

            // Indicator notch
            juce::Graphics::ScopedSaveState state(g);
            g.addTransform(juce::AffineTransform::rotation(angle, cx, cy));
            g.setColour(juce::Colour(0xffffa726));
            g.drawLine(cx, cy - innerR, cx, cy - radius * 0.35f, 2.4f);
        }

        juce::String label;
        KnobStyle knobStyle;
        ScaleDialType scaleStyle;
        float minAngleRad = -juce::MathConstants<float>::pi * 0.80f;
        float maxAngleRad =  juce::MathConstants<float>::pi * 0.80f;
        juce::Image knobImg;
        juce::Image scaleImg;
    };

    // ==============================================================================
    // 2. RAPID CALIBRATED SVG VU METER COMPONENT
    // ==============================================================================
    class RapidVUMeter : public juce::Component, private juce::Timer
    {
    public:
        RapidVUMeter(VUDialStyle dStyle = VUDialStyle::VU_Gain,
                    PointerStyle pStyle = PointerStyle::ClassicNeedle)
            : dialStyle(dStyle), pointerStyle(pStyle)
        {
            setOpaque(false);
            setInterceptsMouseClicks(false, true);
            startTimerHz(60); // 60 FPS ultra-smooth physical movement
        }

        ~RapidVUMeter() override { stopTimer(); }

        void setAssets(const juce::Image& bezel, const juce::Image& dial, 
                       const juce::Image& needle, const juce::Image& sweeper = juce::Image(),
                       const juce::Image& glass = juce::Image())
        {
            bezelImg = bezel;
            dialImg = dial;
            needleImg = needle;
            sweeperImg = sweeper;
            glassImg = glass;
            repaint();
        }

        void bindLevel(std::function<float()> provider) { levelSource = provider; }

        void setDialStyle(VUDialStyle style) { dialStyle = style; repaint(); }
        void setPointerStyle(PointerStyle style) { pointerStyle = style; repaint(); }

        void timerCallback() override
        {
            float targetValue = 0.0f;
            if (levelSource)
                targetValue = juce::jlimit(0.0f, 1.0f, levelSource());

            // Authentic Analog Ballistics (300ms integration & smooth damping)
            const float attackCoeff = 0.28f;
            const float releaseCoeff = 0.08f;
            const float coeff = (targetValue > currentNorm) ? attackCoeff : releaseCoeff;
            currentNorm += (targetValue - currentNorm) * coeff;

            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float w = bounds.getWidth();
            const float h = bounds.getHeight();

            // Calibrated Geometry Constants (from user SVG project)
            const float NORM_PIVOT_X = 541.83f / 1024.0f; // 0.52913
            const float NORM_PIVOT_Y = 510.78f / 765.0f;  // 0.66769
            const float NORM_TIP_LEN = 318.94f / 1024.0f; // 0.31146

            const float pivotX = bounds.getX() + w * NORM_PIVOT_X;
            const float pivotY = bounds.getY() + h * NORM_PIVOT_Y;

            // 1. Dial Face Card (Clean SVG art inside bezel window)
            if (dialImg.isValid())
            {
                g.drawImage(dialImg, bounds, juce::RectanglePlacement::stretchToFit);
            }
            else
            {
                // Procedural vintage meter card
                g.setColour(juce::Colour(0xff221d15));
                g.fillRoundedRectangle(bounds.reduced(10.0f), 8.0f);
            }

            // 2. Pointer Movement (Needle or Radio Sweeper Wand)
            float angleDeg = 0.0f;
            if (dialStyle == VUDialStyle::VU_Gain)
            {
                // VU Scale: 0 (-20 VU) = -29.60 deg, 70% (0 VU) = +12.50 deg, 100% (+3 VU) = +28.20 deg
                if (currentNorm <= 0.70f)
                {
                    float sub = currentNorm / 0.70f;
                    angleDeg = -29.60f + sub * (12.50f - (-29.60f));
                }
                else
                {
                    float sub = (currentNorm - 0.70f) / 0.30f;
                    angleDeg = 12.50f + sub * (28.20f - 12.50f);
                }
            }
            else
            {
                // Gain Reduction Scale: 0 dB Rest = +34.50 deg, -20 dB GR = -26.10 deg
                angleDeg = 34.50f - currentNorm * (34.50f - (-26.10f));
            }

            const float angleRad = juce::degreesToRadians(angleDeg);

            // Draw Pointer (Needle or Radio Sweeper)
            const bool useSweeper = (pointerStyle == PointerStyle::RadioSweeperWand);
            const juce::Image& activePointer = useSweeper ? (sweeperImg.isValid() ? sweeperImg : needleImg) : needleImg;

            if (activePointer.isValid())
            {
                juce::Graphics::ScopedSaveState state(g);
                g.addTransform(juce::AffineTransform::rotation(angleRad, pivotX, pivotY));
                g.drawImage(activePointer, bounds, juce::RectanglePlacement::stretchToFit);
            }
            else
            {
                // Procedural needle fallback
                float tipLen = w * NORM_TIP_LEN;
                float tipX = pivotX + std::sin(angleRad) * tipLen;
                float tipY = pivotY - std::cos(angleRad) * tipLen;

                g.setColour(juce::Colours::black.withAlpha(0.4f));
                g.drawLine(pivotX + 2.0f, pivotY + 2.0f, tipX + 2.0f, tipY + 2.0f, 2.0f);

                g.setColour(useSweeper ? juce::Colour(0xffff2d55) : juce::Colour(0xffe63946));
                g.drawLine(pivotX, pivotY, tipX, tipY, useSweeper ? 3.0f : 1.8f);

                // Brass hub cap
                g.setColour(juce::Colour(0xffc59c52));
                g.fillEllipse(pivotX - 5.0f, pivotY - 5.0f, 10.0f, 10.0f);
            }

            // 3. Bezel Frame Overlay (With exact window cutout)
            if (bezelImg.isValid())
            {
                g.drawImage(bezelImg, bounds, juce::RectanglePlacement::stretchToFit);
            }

            // 4. Glass Reflection Overlay
            if (glassImg.isValid())
            {
                g.drawImage(glassImg, bounds, juce::RectanglePlacement::stretchToFit);
            }
        }

    private:
        VUDialStyle dialStyle;
        PointerStyle pointerStyle;
        float currentNorm = 0.0f;
        std::function<float()> levelSource;

        juce::Image bezelImg;
        juce::Image dialImg;
        juce::Image needleImg;
        juce::Image sweeperImg;
        juce::Image glassImg;
    };

    // ==============================================================================
    // 3. RAPID TOGGLE SWITCH COMPONENT
    // ==============================================================================
    class RapidToggleSwitch : public juce::ToggleButton
    {
    public:
        RapidToggleSwitch(const juce::String& text = "BYPASS", SwitchStyle sStyle = SwitchStyle::HeavyDutyChromeBaton)
            : switchLabel(text), switchStyle(sStyle)
        {
            setClickingTogglesState(true);
        }

        void setCustomImages(const juce::Image& onImg, const juce::Image& offImg)
        {
            upImg = onImg;
            downImg = offImg;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            const auto bounds = getLocalBounds().toFloat();
            const float labelH = 18.0f;
            auto switchArea = bounds.withTrimmedBottom(labelH).reduced(2.0f);
            const bool isEngaged = getToggleState();

            // 1. Draw 3D Baton Switch Image
            const juce::Image& activeImg = isEngaged ? upImg : downImg;
            if (activeImg.isValid())
            {
                g.drawImage(activeImg, switchArea, juce::RectanglePlacement::centred);
            }
            else
            {
                // Procedural toggle switch
                const float cx = switchArea.getCentreX();
                const float cy = switchArea.getCentreY();
                
                // Hex mounting nut
                g.setColour(juce::Colour(0xff3a3d45));
                g.fillEllipse(cx - 16.0f, cy - 16.0f, 32.0f, 32.0f);
                g.setColour(juce::Colour(0xffc59c52));
                g.drawEllipse(cx - 16.0f, cy - 16.0f, 32.0f, 32.0f, 1.5f);

                // Baton lever
                float leverAngle = isEngaged ? -0.4f : 0.4f;
                float lx = cx + std::sin(leverAngle) * 22.0f;
                float ly = cy - std::cos(leverAngle) * 22.0f;

                g.setColour(juce::Colour(0xffe0e4ea));
                g.drawLine(cx, cy, lx, ly, 4.5f);
                g.fillEllipse(lx - 4.5f, ly - 4.5f, 9.0f, 9.0f);
            }

            // 2. Serigraphic Label
            if (switchLabel.isNotEmpty())
            {
                auto labelRect = bounds.withTop(bounds.getBottom() - labelH);
                g.setColour(isEngaged ? juce::Colour(0xffff4d4d) : juce::Colour(0xffd89f3c));
                g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
                g.drawText(switchLabel, labelRect, juce::Justification::centred, false);
            }
        }

    private:
        juce::String switchLabel;
        SwitchStyle switchStyle;
        juce::Image upImg;
        juce::Image downImg;
    };

    // ==============================================================================
    // 4. RAPID MASTER GUI CONTROLLER
    // ==============================================================================
    class RapidGUI
    {
    public:
        RapidGUI(juce::AudioProcessorEditor& editor, juce::AudioProcessorValueTreeState& vts)
            : ownerEditor(editor), apvts(vts)
        {
        }

        void setChassis(ChassisTheme theme, int w, int h, const juce::String& pTitle = "171 STUDIO", const juce::String& pSubtitle = "ANALOG MASTERING CONSOLE")
        {
            currentTheme = theme;
            chassisWidth = w;
            chassisHeight = h;
            title = pTitle;
            subtitle = pSubtitle;
            ownerEditor.setSize(w, h);
        }

        // Add a photorealistic analog knob with 1 line of code!
        RapidKnob& addKnob(const juce::String& paramId, 
                           const juce::String& label,
                           KnobStyle kStyle = KnobStyle::TeardropBronze,
                           ScaleDialType sStyle = ScaleDialType::Percent0To100)
        {
            auto knob = std::make_unique<RapidKnob>(label, kStyle, sStyle);
            ownerEditor.addAndMakeVisible(*knob);

            // Connect APVTS attachment automatically!
            if (apvts.getParameter(paramId) != nullptr)
            {
                sliderAttachments.push_back(
                    std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, paramId, *knob)
                );
            }

            RapidKnob* ptr = knob.get();
            knobs.push_back(std::move(knob));
            return *ptr;
        }

        // Add calibrated SVG VU Meter with 1 line of code!
        RapidVUMeter& addVUMeter(const juce::String& meterName,
                                VUDialStyle dialStyle = VUDialStyle::VU_Gain,
                                PointerStyle pointerStyle = PointerStyle::ClassicNeedle)
        {
            juce::ignoreUnused(meterName);
            auto meter = std::make_unique<RapidVUMeter>(dialStyle, pointerStyle);
            ownerEditor.addAndMakeVisible(*meter);

            RapidVUMeter* ptr = meter.get();
            vuMeters.push_back(std::move(meter));
            return *ptr;
        }

        // Add heavy duty toggle switch with 1 line of code!
        RapidToggleSwitch& addToggleSwitch(const juce::String& paramId,
                                           const juce::String& label = "BYPASS",
                                           SwitchStyle sStyle = SwitchStyle::HeavyDutyChromeBaton)
        {
            auto sw = std::make_unique<RapidToggleSwitch>(label, sStyle);
            ownerEditor.addAndMakeVisible(*sw);

            // Connect APVTS attachment
            if (apvts.getParameter(paramId) != nullptr)
            {
                buttonAttachments.push_back(
                    std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(apvts, paramId, *sw)
                );
            }

            RapidToggleSwitch* ptr = sw.get();
            switches.push_back(std::move(sw));
            return *ptr;
        }

        // Render the boutique hardware chassis backplate
        void paintChassis(juce::Graphics& g)
        {
            const auto bounds = ownerEditor.getLocalBounds().toFloat();

            // 1. Brushed Gunmetal / Dark Bronze Faceplate
            juce::Colour cTop = (currentTheme == ChassisTheme::VintageDarkBronze) ? juce::Colour(0xff1f1b16) : juce::Colour(0xff16171a);
            juce::Colour cBot = (currentTheme == ChassisTheme::VintageDarkBronze) ? juce::Colour(0xff0d0c0a) : juce::Colour(0xff0b0b0d);
            
            juce::ColourGradient grad(cTop, 0.0f, 0.0f, cBot, 0.0f, bounds.getHeight(), false);
            g.setGradientFill(grad);
            g.fillRoundedRectangle(bounds, 6.0f);

            // 2. Precision Chamfer & Anodized Border
            g.setColour(juce::Colour(0xffd89f3c).withAlpha(0.6f));
            g.drawRoundedRectangle(bounds.reduced(1.5f), 5.0f, 1.5f);

            // 3. Corner Allen Screws (Boutique rackmount style)
            const float screwInset = 16.0f;
            drawCornerScrew(g, screwInset, screwInset);
            drawCornerScrew(g, bounds.getRight() - screwInset, screwInset);
            drawCornerScrew(g, screwInset, bounds.getBottom() - screwInset);
            drawCornerScrew(g, bounds.getRight() - screwInset, bounds.getBottom() - screwInset);

            // 4. Serigraphic Title Header
            if (title.isNotEmpty())
            {
                auto titleArea = juce::Rectangle<float>(40.0f, 14.0f, 240.0f, 22.0f);
                g.setColour(juce::Colour(0xffd89f3c));
                g.setFont(juce::FontOptions(15.0f, juce::Font::bold));
                g.drawText(title, titleArea, juce::Justification::left, false);

                auto subArea = juce::Rectangle<float>(40.0f, 34.0f, 240.0f, 14.0f);
                g.setColour(juce::Colour(0xff8e94a4));
                g.setFont(juce::FontOptions(9.5f));
                g.drawText(subtitle, subArea, juce::Justification::left, false);
            }
        }

    private:
        void drawCornerScrew(juce::Graphics& g, float cx, float cy)
        {
            const float r = 5.5f;
            g.setColour(juce::Colour(0xff0d0e10));
            g.fillEllipse(cx - r, cy - r, r * 2.0f, r * 2.0f);
            g.setColour(juce::Colour(0xff3a3d45));
            g.drawEllipse(cx - r, cy - r, r * 2.0f, r * 2.0f, 1.0f);
            // Hex Allen hole
            g.setColour(juce::Colour(0xff050506));
            g.fillEllipse(cx - 2.2f, cy - 2.2f, 4.4f, 4.4f);
        }

        juce::AudioProcessorEditor& ownerEditor;
        juce::AudioProcessorValueTreeState& apvts;

        ChassisTheme currentTheme = ChassisTheme::VintageDarkBronze;
        int chassisWidth = 960;
        int chassisHeight = 480;
        juce::String title;
        juce::String subtitle;

        std::vector<std::unique_ptr<RapidKnob>> knobs;
        std::vector<std::unique_ptr<RapidVUMeter>> vuMeters;
        std::vector<std::unique_ptr<RapidToggleSwitch>> switches;

        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAttachments;
        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAttachments;
    };
}
