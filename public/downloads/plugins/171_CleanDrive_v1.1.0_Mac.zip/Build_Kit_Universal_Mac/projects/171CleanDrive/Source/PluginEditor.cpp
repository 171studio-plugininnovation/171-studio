#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <BinaryData.h>

AudioPluginAudioProcessorEditor::AudioPluginAudioProcessorEditor(AudioPluginAudioProcessor& p)
    : AudioProcessorEditor(&p),
      processorRef(p),
      visualizer(p.getVisualFIFO())
{
    // 1. Carica il backplate pulito originale
    backgroundImage = juce::ImageCache::getFromMemory(BinaryData::clean_background_png,
                                                       BinaryData::clean_background_pngSize);

    // 2. Carica la manopola lavorata in ottone godronato (256x256) e le immagini dello switch di bypass
    auto knobMachinedImg    = juce::ImageCache::getFromMemory(BinaryData::knob_171_machined_png,
                                                              BinaryData::knob_171_machined_pngSize);
    auto swBypassActiveImg  = juce::ImageCache::getFromMemory(BinaryData::sw_bypass_active_png,
                                                              BinaryData::sw_bypass_active_pngSize);
    auto swBypassEngagedImg = juce::ImageCache::getFromMemory(BinaryData::sw_bypass_engaged_png,
                                                              BinaryData::sw_bypass_engaged_pngSize);

    // 3. Creazione delle 7 manopole fotorealistiche godronate con rispettivo tema colore neon
    // DRIVE: Crimson neon (0xffff2030)
    driveKnob  = std::make_unique<gui171::AnalogStyledKnob>("DRIVE",     juce::Colour(0xffff2030), knobMachinedImg, gui171::AnalogStyledKnob::ValueFormat::Multiplier, 1.0f, 8.0f, 1.30f);
    // PUNCH: Crimson-Orange neon (0xffff3520)
    punchKnob  = std::make_unique<gui171::AnalogStyledKnob>("PUNCH",     juce::Colour(0xffff3520), knobMachinedImg, gui171::AnalogStyledKnob::ValueFormat::Multiplier, 0.0f, 2.0f, 1.00f);
    // WARMTH: Amber neon (0xffff9500)
    warmthKnob = std::make_unique<gui171::AnalogStyledKnob>("WARMTH",    juce::Colour(0xffff9500), knobMachinedImg, gui171::AnalogStyledKnob::ValueFormat::Decimal,    0.0f, 1.0f, 0.36f);
    // TONE TILT: Golden Yellow neon (0xffffe600)
    tiltKnob   = std::make_unique<gui171::AnalogStyledKnob>("TONE TILT", juce::Colour(0xffffe600), knobMachinedImg, gui171::AnalogStyledKnob::ValueFormat::Decimal,   -1.0f, 1.0f, 0.38f);
    // SENS: Bright Orange neon (0xffff6600)
    sensKnob   = std::make_unique<gui171::AnalogStyledKnob>("SENS",      juce::Colour(0xffff6600), knobMachinedImg, gui171::AnalogStyledKnob::ValueFormat::Decimal,    0.5f, 4.0f, 2.85f);
    // MIX: Crimson neon (0xffff2030)
    mixKnob    = std::make_unique<gui171::AnalogStyledKnob>("MIX",       juce::Colour(0xffff2030), knobMachinedImg, gui171::AnalogStyledKnob::ValueFormat::Percentage, 0.0f, 1.0f, 1.00f);
    // OUTPUT: Gold neon (0xffd4af37)
    outputKnob = std::make_unique<gui171::AnalogStyledKnob>("OUTPUT",    juce::Colour(0xffd4af37), knobMachinedImg, gui171::AnalogStyledKnob::ValueFormat::Decibels,   -18.0f, 12.0f, -1.4f);

    // 4. Modulo Master Bypass Heavy-Duty con piastra metallica, 4 viti Allen e spia rubino
    bypassSwitch = std::make_unique<gui171::HeavyDutyBypassModule>(swBypassActiveImg, swBypassEngagedImg);

    // 5. Aggiunta dei componenti a schermo
    addAndMakeVisible(visualizer);

    addAndMakeVisible(*driveKnob);
    addAndMakeVisible(*punchKnob);
    addAndMakeVisible(*warmthKnob);
    addAndMakeVisible(*tiltKnob);
    addAndMakeVisible(*sensKnob);
    addAndMakeVisible(*mixKnob);
    addAndMakeVisible(*outputKnob);

    addAndMakeVisible(*bypassSwitch);

    // 6. Collegamento con l'albero parametri APVTS
    auto& apvts = processorRef.getAPVTS();
    driveAttach  = std::make_unique<SliderAttachment>(apvts, "drive",       driveKnob->getSlider());
    punchAttach  = std::make_unique<SliderAttachment>(apvts, "trans_punch", punchKnob->getSlider());
    warmthAttach = std::make_unique<SliderAttachment>(apvts, "warmth",      warmthKnob->getSlider());
    tiltAttach   = std::make_unique<SliderAttachment>(apvts, "tilt",        tiltKnob->getSlider());
    sensAttach   = std::make_unique<SliderAttachment>(apvts, "split_sens",  sensKnob->getSlider());
    mixAttach    = std::make_unique<SliderAttachment>(apvts, "mix",         mixKnob->getSlider());
    outputAttach = std::make_unique<SliderAttachment>(apvts, "out_gain",    outputKnob->getSlider());
    bypassAttach = std::make_unique<ButtonAttachment>(apvts, "bypass",      bypassSwitch->getButton());

    // 7. Selettore Preset elegante con LookAndFeel 171 Studio
    const auto& presets = AudioPluginAudioProcessor::getFactoryPresets();
    for (size_t i = 0; i < presets.size(); ++i) {
        presetComboBox.addItem(presets[i].name, static_cast<int>(i + 1));
    }
    presetComboBox.setLookAndFeel(&presetLookAndFeel);
    presetComboBox.setSelectedId(processorRef.getCurrentProgram() + 1, juce::dontSendNotification);
    presetComboBox.addListener(this);
    addAndMakeVisible(presetComboBox);

    // Stepper Button Boutique dorati per preset (< e >)
    prevPresetBtn = std::make_unique<gui171::BoutiqueStepperButton>(gui171::BoutiqueStepperButton::Direction::Previous);
    prevPresetBtn->setOnClick([this]() {
        int cur = presetComboBox.getSelectedId() - 1;
        int num = processorRef.getNumPrograms();
        if (num > 0) {
            int prev = (cur - 1 + num) % num;
            presetComboBox.setSelectedId(prev + 1, juce::sendNotification);
        }
    });
    addAndMakeVisible(*prevPresetBtn);

    nextPresetBtn = std::make_unique<gui171::BoutiqueStepperButton>(gui171::BoutiqueStepperButton::Direction::Next);
    nextPresetBtn->setOnClick([this]() {
        int cur = presetComboBox.getSelectedId() - 1;
        int num = processorRef.getNumPrograms();
        if (num > 0) {
            int next = (cur + 1) % num;
            presetComboBox.setSelectedId(next + 1, juce::sendNotification);
        }
    });
    addAndMakeVisible(*nextPresetBtn);

    // 8. Supporto completo al resizing con mantenimento proporzioni e barra angolare di ridimensionamento
    setResizable(true, true);
    setResizeLimits(768, 428, 2048, 1142);
    getConstrainer()->setFixedAspectRatio(1024.0 / 571.0);
    setSize(1024, 571);
}

AudioPluginAudioProcessorEditor::~AudioPluginAudioProcessorEditor() {
    presetComboBox.setLookAndFeel(nullptr);
    presetComboBox.removeListener(this);
}

void AudioPluginAudioProcessorEditor::comboBoxChanged(juce::ComboBox* box) {
    if (box == &presetComboBox) {
        const int selectedIdx = presetComboBox.getSelectedId() - 1;
        if (selectedIdx >= 0) {
            processorRef.setCurrentProgram(selectedIdx);
        }
    }
}

void AudioPluginAudioProcessorEditor::paint(juce::Graphics& g) {
    if (backgroundImage.isValid()) {
        g.drawImage(backgroundImage, getLocalBounds().toFloat());
    } else {
        g.fillAll(juce::Colour(0xff121316));
    }
}

void AudioPluginAudioProcessorEditor::resized() {
    const float scaleX = (float)getWidth()  / 1024.0f;
    const float scaleY = (float)getHeight() / 571.0f;
    auto S = [scaleX, scaleY](int x, int y, int w, int h) -> juce::Rectangle<int> {
        return { juce::roundToInt(x * scaleX),
                 juce::roundToInt(y * scaleY),
                 juce::roundToInt(w * scaleX),
                 juce::roundToInt(h * scaleY) };
    };

    // 1. Oscilloscopio dorato CRT incassato nel frame
    // Coordinate esatte nominali: X=58, Y=134, Larghezza=908, Altezza=256
    visualizer.setBounds(S(58, 134, 908, 256));

    // 2. Selettore Preset centrato con stepper buttons boutique
    if (prevPresetBtn != nullptr) prevPresetBtn->setBounds(S(368, 88, 24, 26));
    presetComboBox.setBounds(S(398, 88, 240, 26));
    if (nextPresetBtn != nullptr) nextPresetBtn->setBounds(S(642, 88, 24, 26));

    // 3. Modulo Heavy-Duty Bypass con 4 viti a brugola e spia rubino
    bypassSwitch->setBounds(S(752, 73, 56, 56));

    // 4. Posizionamento micrometrico proporzionale delle 7 Manopole Neon sulla riga inferiore
    driveKnob->setBounds(S(115 - 55, 404, 110, 136));
    punchKnob->setBounds(S(247 - 55, 404, 110, 136));
    warmthKnob->setBounds(S(379 - 55, 404, 110, 136));
    tiltKnob->setBounds(S(512 - 58, 404, 116, 136));
    sensKnob->setBounds(S(645 - 55, 404, 110, 136));
    mixKnob->setBounds(S(777 - 55, 404, 110, 136));
    outputKnob->setBounds(S(909 - 55, 404, 110, 136));
}
