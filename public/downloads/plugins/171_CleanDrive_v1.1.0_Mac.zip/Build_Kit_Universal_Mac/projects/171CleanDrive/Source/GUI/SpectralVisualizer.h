#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <dsp171/LockFreeFIFO.h>
#include <BinaryData.h>

namespace gui171 {

enum class DisplayMode {
    Scope,    // 0: Oscilloscopio Dorato + Barra Transienti/Tonale
    VUMeter,  // 1: Dual Analog VU Meters (L/R con fisica IEC 60268-17)
    LEDMeter  // 2: Stereo RMS / Peak LED Bar Meter
};

class SpectralVisualizer : public juce::Component, public juce::Timer {
public:
    explicit SpectralVisualizer(dsp171::LockFreeVisualFIFO<512>& fifoToUse)
        : fifo(fifoToUse)
    {
        setOpaque(false);
        waveformHistory.fill(0.0f);

        // Carica le texture dei meter dai dati binari
        vuDialImg = juce::ImageCache::getFromMemory(BinaryData::vu_dial_clean_png, BinaryData::vu_dial_clean_pngSize);
        ledBoxImg = juce::ImageCache::getFromMemory(BinaryData::led_meter_clean_png, BinaryData::led_meter_clean_pngSize);

        startTimerHz(60); // 60 FPS
    }

    ~SpectralVisualizer() override {
        stopTimer();
    }

    void setDisplayMode(DisplayMode newMode) {
        currentMode = newMode;
        repaint();
    }

    DisplayMode getDisplayMode() const noexcept {
        return currentMode;
    }

    void mouseDown(const juce::MouseEvent&) override {
        // Cliccando sullo schermo si cicla tra i 3 display: Scope -> VU Meter -> LED Meter -> Scope
        int next = (static_cast<int>(currentMode) + 1) % 3;
        currentMode = static_cast<DisplayMode>(next);
        repaint();
    }

    void timerCallback() override {
        dsp171::VisualFrame frame;
        bool hasData = false;

        while (fifo.pop(frame)) {
            hasData = true;
            for (size_t s = 0; s < dsp171::VisualFrame::FrameSamples; s += 2) {
                waveformHistory[historyWriteIdx] = frame.samplesOut[s];
                historyWriteIdx = (historyWriteIdx + 1) % HistorySize;
            }

            smoothedTrans += 0.25f * (frame.transientRatio - smoothedTrans);
            smoothedTonal += 0.15f * (frame.tonalRatio - smoothedTonal);
            smoothedRMS   += 0.20f * (frame.outRMS_L - smoothedRMS);

            targetRMS_L = frame.outRMS_L;
            targetRMS_R = frame.outRMS_R;
            targetPeak_L = frame.peak_L;
            targetPeak_R = frame.peak_R;
        }

        if (!hasData) {
            smoothedTrans *= 0.90f;
            smoothedTonal *= 0.92f;
            smoothedRMS   *= 0.90f;
            targetRMS_L   *= 0.90f;
            targetRMS_R   *= 0.90f;
            targetPeak_L  *= 0.88f;
            targetPeak_R  *= 0.88f;
        }

        constexpr float dt = 1.0f / 60.0f;

        // 1. FISICA DEL GALVANOMETRO VU METER (IEC 60268-17)
        // 0 VU = -18 dBFS. Range: -20 VU a +3 VU
        auto toVUAngle = [](float linearRMS) noexcept -> float {
            float db = 20.0f * std::log10(std::max(linearRMS, 1.0e-5f));
            float vu = db + 18.0f; // Calibrazione 0 VU = -18 dBFS
            // Mappatura angolare logaritmica (da -42° a +36°)
            return std::clamp(juce::jmap(vu, -20.0f, 3.0f, -0.73f, 0.62f), -0.78f, 0.72f);
        };

        const float targetAngleL = toVUAngle(targetRMS_L);
        const float targetAngleR = toVUAngle(targetRMS_R);

        // Simulazione sistema massa-molla-smorzatore del 2° ordine
        constexpr float kSpring = 42.0f;
        constexpr float cDamping = 8.2f;

        float forceL = -kSpring * (needleAngleL - targetAngleL) - cDamping * needleVelL;
        needleVelL += forceL * dt;
        needleAngleL += needleVelL * dt;

        float forceR = -kSpring * (needleAngleR - targetAngleR) - cDamping * needleVelR;
        needleVelR += forceR * dt;
        needleAngleR += needleVelR * dt;

        // 2. BALISTICA STEREO LED METER (Peak Decay & Peak Hold)
        float dbPeakL = 20.0f * std::log10(std::max(targetPeak_L, 1.0e-5f));
        float dbPeakR = 20.0f * std::log10(std::max(targetPeak_R, 1.0e-5f));
        float dbRmsL  = 20.0f * std::log10(std::max(targetRMS_L, 1.0e-5f));
        float dbRmsR  = 20.0f * std::log10(std::max(targetRMS_R, 1.0e-5f));

        dispRmsL += 0.25f * (dbRmsL - dispRmsL);
        dispRmsR += 0.25f * (dbRmsR - dispRmsR);

        dispPeakL = std::max(dispPeakL - 22.0f * dt, dbPeakL);
        dispPeakR = std::max(dispPeakR - 22.0f * dt, dbPeakR);

        if (dbPeakL >= peakHoldL) { peakHoldL = dbPeakL; holdTimerL = 1.6f; }
        else { holdTimerL -= dt; if (holdTimerL <= 0.0f) peakHoldL -= 28.0f * dt; }

        if (dbPeakR >= peakHoldR) { peakHoldR = dbPeakR; holdTimerR = 1.6f; }
        else { holdTimerR -= dt; if (holdTimerR <= 0.0f) peakHoldR -= 28.0f * dt; }

        repaint();
    }

    void paint(juce::Graphics& g) override {
        const float w = static_cast<float>(getWidth());
        const float h = static_cast<float>(getHeight());

        if (currentMode == DisplayMode::Scope) {
            paintScopeView(g, w, h);
        } else if (currentMode == DisplayMode::VUMeter) {
            paintVUMeterView(g, w, h);
        } else if (currentMode == DisplayMode::LEDMeter) {
            paintLEDMeterView(g, w, h);
        }

        // Meter di livello Transient Punch e Tonal Body attivo e visibile in OGNI pagina!
        drawTransientTonalBalanceMeter(g, w, h);

        // Selettore compatto di modalità in alto a destra
        drawModePill(g, w);
    }

private:
    DisplayMode currentMode = DisplayMode::Scope;

    // --- 1. MODALITÀ SCOPE (Forma d'Onda Dorata) ---
    void paintScopeView(juce::Graphics& g, float w, float h) {
        juce::ignoreUnused(h);
        const float midY = 106.0f;
        const float maxAmp = 86.0f;
        const size_t numPoints = 220;
        const float stepX = w / static_cast<float>(numPoints);

        for (size_t i = 0; i < numPoints; ++i) {
            const size_t idx = (historyWriteIdx + (i * (HistorySize / numPoints))) % HistorySize;
            float val = std::abs(waveformHistory[idx]);

            if (smoothedRMS < 0.001f) {
                val = 0.02f * std::sin(static_cast<float>(i) * 0.12f);
            }

            const float barH = std::clamp(val * maxAmp, 1.2f, maxAmp);
            const float x = static_cast<float>(i) * stepX;

            g.setColour(juce::Colour(0x35ffaa00));
            g.drawLine(x, midY - barH * 1.35f, x, midY + barH * 1.35f, 5.5f);

            g.setColour(juce::Colour(0x75ffd020));
            g.drawLine(x, midY - barH * 1.15f, x, midY + barH * 1.15f, 3.2f);

            g.setColour(juce::Colour(0xfffffb99));
            g.drawLine(x, midY - barH, x, midY + barH, 1.6f);
        }
    }

    // --- 2. MODALITÀ DUAL ANALOG VU METER (L / R) ---
    void paintVUMeterView(juce::Graphics& g, float w, float h) {
        juce::ignoreUnused(h);
        // Dimensione calibrata per alloggiare perfettamente sopra la barra dei meter
        const float meterSize = 206.0f;
        const float spacing = 90.0f;
        const float leftX = (w * 0.5f) - meterSize - (spacing * 0.5f);
        const float rightX = (w * 0.5f) + (spacing * 0.5f);
        const float meterY = 6.0f;

        drawSingleVUMeter(g, leftX, meterY, meterSize, needleAngleL, "L");
        drawSingleVUMeter(g, rightX, meterY, meterSize, needleAngleR, "R");
    }

    void drawSingleVUMeter(juce::Graphics& g, float x, float y, float size, float angle, const char* label) {
        // Disegna il quadrante pergamena vintage (pre-scaled cache ad alta resa a 60 FPS)
        if (cachedVuDial.isNull() || cachedVuDial.getWidth() != juce::roundToInt(size)) {
            if (vuDialImg.isValid()) {
                cachedVuDial = vuDialImg.rescaled(juce::roundToInt(size), juce::roundToInt(size), juce::Graphics::highResamplingQuality);
            }
        }
        if (cachedVuDial.isValid()) {
            g.drawImageAt(cachedVuDial, juce::roundToInt(x), juce::roundToInt(y));
        }

        const float pivotX = x + size * 0.50f;
        const float pivotY = y + size * 0.665f;
        const float needleLength = size * 0.38f;

        const float tipX = pivotX + std::sin(angle) * needleLength;
        const float tipY = pivotY - std::cos(angle) * needleLength;

        // Ombra della lancetta (Zero allocazioni heap in paint: rendering diretto a linea hardware)
        g.setColour(juce::Colour(0x40000000));
        g.drawLine(pivotX + 1.5f, pivotY + 2.0f, tipX + 1.5f, tipY + 2.0f, 2.5f);

        // Lancetta nera affusolata calibrata (Zero allocazioni heap)
        g.setColour(juce::Colour(0xff181818));
        g.drawLine(pivotX, pivotY, tipX, tipY, 2.0f);

        // Perno centrale analogico (Dome Hub)
        g.setColour(juce::Colour(0xff222226));
        g.fillEllipse(pivotX - 9.0f, pivotY - 9.0f, 18.0f, 18.0f);
        g.setColour(juce::Colour(0xff4a4a52));
        g.drawEllipse(pivotX - 9.0f, pivotY - 9.0f, 18.0f, 18.0f, 1.2f);
        g.setColour(juce::Colour(0xff111113));
        g.fillEllipse(pivotX - 4.0f, pivotY - 4.0f, 8.0f, 8.0f);

        // Canale L/R in elegante badge dorato incassato
        const float badgeW = 28.0f;
        const float badgeH = 18.0f;
        const float badgeX = x + (size - badgeW) * 0.5f;
        const float badgeY = y + size * 0.74f;
        g.setColour(juce::Colour(0xdd121316));
        g.fillRoundedRectangle(badgeX, badgeY, badgeW, badgeH, 4.0f);
        g.setColour(juce::Colour(0x80c59c52));
        g.drawRoundedRectangle(badgeX, badgeY, badgeW, badgeH, 4.0f, 1.0f);
        g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xffffe099));
        g.drawText(label, static_cast<int>(badgeX), static_cast<int>(badgeY), static_cast<int>(badgeW), static_cast<int>(badgeH), juce::Justification::centred, false);
    }

    // --- 3. MODALITÀ STEREO LEVEL METER (RMS / PEAK LED) ---
    void paintLEDMeterView(juce::Graphics& g, float w, float h) {
        juce::ignoreUnused(h);
        const float boxH = 208.0f;
        const float boxW = boxH * (347.0f / 482.0f);
        const float boxX = (w - boxW) * 0.5f;
        const float boxY = 6.0f;

        if (cachedLedBox.isNull() || cachedLedBox.getWidth() != juce::roundToInt(boxW)) {
            if (ledBoxImg.isValid()) {
                cachedLedBox = ledBoxImg.rescaled(juce::roundToInt(boxW), juce::roundToInt(boxH), juce::Graphics::highResamplingQuality);
            }
        }
        if (cachedLedBox.isValid()) {
            g.drawImageAt(cachedLedBox, juce::roundToInt(boxX), juce::roundToInt(boxY));
        }

        const float scaleX = boxW / 347.0f;
        const float scaleY = boxH / 482.0f;

        const float colX_L_RMS  = boxX + 32.0f * scaleX;
        const float colX_L_PEAK = boxX + 66.0f * scaleX;
        const float colX_R_RMS  = boxX + 254.0f * scaleX;
        const float colX_R_PEAK = boxX + 288.0f * scaleX;
        const float segW = 27.0f * scaleX;
        const float segH = 11.0f * scaleY;
        const float segStepY = 16.0f * scaleY;
        const float startY = boxY + 86.0f * scaleY;

        auto drawLEDColumn = [&](float colX, float curDB, float holdDB, bool isPeakCol) {
            for (int i = 0; i < 22; ++i) {
                float segThreshold = juce::jmap(static_cast<float>(i), 0.0f, 21.0f, 0.0f, -54.0f);
                float sy = startY + static_cast<float>(i) * segStepY;

                bool isLit = curDB >= segThreshold;
                bool isHold = isPeakCol && (std::abs(holdDB - segThreshold) < 2.0f);

                if (isLit || isHold) {
                    juce::Colour ledCol = juce::Colour(0xffffffff);
                    if (segThreshold >= -1.0f)      ledCol = juce::Colour(0xffff2030);
                    else if (segThreshold >= -6.0f) ledCol = juce::Colour(0xffffaa00);

                    g.setColour(ledCol.withAlpha(0.45f));
                    g.fillRoundedRectangle(colX - 1.5f, sy - 1.0f, segW + 3.0f, segH + 2.0f, 2.5f);

                    g.setColour(ledCol);
                    g.fillRoundedRectangle(colX, sy, segW, segH, 2.0f);
                }
            }
        };

        drawLEDColumn(colX_L_RMS, dispRmsL, -100.0f, false);
        drawLEDColumn(colX_L_PEAK, dispPeakL, peakHoldL, true);
        drawLEDColumn(colX_R_RMS, dispRmsR, -100.0f, false);
        drawLEDColumn(colX_R_PEAK, dispPeakR, peakHoldR, true);
    }

    // --- 4. METER COMUNE A TUTTE LE PAGINE: TRANSIENT PUNCH & TONAL BODY ---
    void drawTransientTonalBalanceMeter(juce::Graphics& g, float w, float h) {
        const float barY = h - 34.0f;
        const float barH = 26.0f;
        auto meterRect = juce::Rectangle<float>(12.0f, barY, w - 24.0f, barH);

        // Chassis scuro incassato con finitura oro
        g.setColour(juce::Colour(0xee0a0b0e));
        g.fillRoundedRectangle(meterRect, 6.0f);
        g.setColour(juce::Colour(0x66c59c52));
        g.drawRoundedRectangle(meterRect, 6.0f, 1.0f);

        // 1. Canale TRANSIENT PUNCH (Sinistra)
        g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xffff6644));
        g.drawText("TRANSIENT PUNCH", 24, static_cast<int>(barY), 130, static_cast<int>(barH), juce::Justification::centredLeft, false);

        const float transBarX = 158.0f;
        const float transBarW = 150.0f;
        const float transBarY = barY + 7.0f;
        const float transBarH = 12.0f;

        g.setColour(juce::Colour(0x40200808));
        g.fillRoundedRectangle(transBarX, transBarY, transBarW, transBarH, 3.0f);
        g.setColour(juce::Colour(0x30ff4422));
        g.drawRoundedRectangle(transBarX, transBarY, transBarW, transBarH, 3.0f, 1.0f);

        const float fillW_Trans = transBarW * std::clamp(smoothedTrans, 0.0f, 1.0f);
        if (fillW_Trans > 2.0f) {
            juce::ColourGradient gradTrans(juce::Colour(0xffff2200), transBarX, transBarY,
                                           juce::Colour(0xffff8800), transBarX + fillW_Trans, transBarY, false);
            g.setGradientFill(gradTrans);
            g.fillRoundedRectangle(transBarX, transBarY, fillW_Trans, transBarH, 3.0f);
        }

        // Valore numerico percentuale Transiente
        g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xffffaa88));
        juce::String transStr = juce::String(static_cast<int>(smoothedTrans * 100.0f)) + "%";
        g.drawText(transStr, static_cast<int>(transBarX + transBarW + 6.0f), static_cast<int>(barY), 38, static_cast<int>(barH), juce::Justification::centredLeft, false);

        // 2. Canale TONAL BODY (Destra)
        const float tonalBarW = 150.0f;
        const float tonalBarX = w - 158.0f - tonalBarW;
        const float tonalBarY = barY + 7.0f;
        const float tonalBarH = 12.0f;

        g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xffffcc44));
        g.drawText("TONAL BODY", static_cast<int>(w) - 150, static_cast<int>(barY), 130, static_cast<int>(barH), juce::Justification::centredLeft, false);

        g.setColour(juce::Colour(0x40251c08));
        g.fillRoundedRectangle(tonalBarX, tonalBarY, tonalBarW, tonalBarH, 3.0f);
        g.setColour(juce::Colour(0x30ffbb22));
        g.drawRoundedRectangle(tonalBarX, tonalBarY, tonalBarW, tonalBarH, 3.0f, 1.0f);

        const float fillW_Tonal = tonalBarW * std::clamp(smoothedTonal, 0.0f, 1.0f);
        if (fillW_Tonal > 2.0f) {
            juce::ColourGradient gradTonal(juce::Colour(0xffff9900), tonalBarX, tonalBarY,
                                           juce::Colour(0xffffe055), tonalBarX + fillW_Tonal, tonalBarY, false);
            g.setGradientFill(gradTonal);
            g.fillRoundedRectangle(tonalBarX, tonalBarY, fillW_Tonal, tonalBarH, 3.0f);
        }

        // Valore numerico percentuale Tonale
        g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xffffe699));
        juce::String tonalStr = juce::String(static_cast<int>(smoothedTonal * 100.0f)) + "%";
        g.drawText(tonalStr, static_cast<int>(tonalBarX - 44.0f), static_cast<int>(barY), 38, static_cast<int>(barH), juce::Justification::centredRight, false);

        // 3. Cursore Centrale di Bilanciamento Dinamico
        const float balanceDelta = std::clamp(smoothedTonal - smoothedTrans, -1.0f, 1.0f);
        const float badgeW = 38.0f;
        const float badgeH = 18.0f;
        const float badgeCenterX = (w * 0.5f) + (balanceDelta * 48.0f);
        const float badgeX = badgeCenterX - badgeW * 0.5f;
        const float badgeY = barY + (barH - badgeH) * 0.5f;

        g.setColour(juce::Colour(0x60ff7700));
        g.fillRoundedRectangle(badgeX - 3.0f, badgeY - 2.0f, badgeW + 6.0f, badgeH + 4.0f, 5.0f);

        juce::ColourGradient badgeGrad(
            juce::Colour(0xffff9900), badgeX, badgeY,
            juce::Colour(0xffe65100), badgeX, badgeY + badgeH, false);
        g.setGradientFill(badgeGrad);
        g.fillRoundedRectangle(badgeX, badgeY, badgeW, badgeH, 4.0f);

        g.setColour(juce::Colour(0xffffdd66));
        g.drawRoundedRectangle(badgeX, badgeY, badgeW, badgeH, 4.0f, 1.0f);

        g.setColour(juce::Colour(0xffffffff));
        g.drawLine(badgeCenterX, badgeY + 3.0f, badgeCenterX, badgeY + badgeH - 3.0f, 1.5f);
    }

    void drawModePill(juce::Graphics& g, float w) {
        // Badge interattivo che indica la modalità e permette di cliccare per cambiare
        const float pillW = 104.0f;
        const float pillH = 22.0f;
        const float pillX = w - pillW - 14.0f;
        const float pillY = 10.0f;

        g.setColour(juce::Colour(0xd50d0e12));
        g.fillRoundedRectangle(pillX, pillY, pillW, pillH, 5.0f);
        g.setColour(juce::Colour(0x80c59c52));
        g.drawRoundedRectangle(pillX, pillY, pillW, pillH, 5.0f, 1.0f);

        juce::String modeName;
        juce::Colour dotCol;
        switch (currentMode) {
            case DisplayMode::Scope:
                modeName = "SCOPE";
                dotCol = juce::Colour(0xffffcc00);
                break;
            case DisplayMode::VUMeter:
                modeName = "VU METER";
                dotCol = juce::Colour(0xffff9900);
                break;
            case DisplayMode::LEDMeter:
                modeName = "LED PEAK";
                dotCol = juce::Colour(0xffff3344);
                break;
        }

        // Indicatore LED acceso
        g.setColour(dotCol.withAlpha(0.35f));
        g.fillEllipse(pillX + 8.0f, pillY + 5.0f, 12.0f, 12.0f);
        g.setColour(dotCol);
        g.fillEllipse(pillX + 10.0f, pillY + 7.0f, 8.0f, 8.0f);

        g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        g.setColour(juce::Colour(0xffffe099));
        g.drawText(modeName, static_cast<int>(pillX + 22.0f), static_cast<int>(pillY), static_cast<int>(pillW - 24.0f), static_cast<int>(pillH), juce::Justification::centredLeft, false);
    }

    static constexpr size_t HistorySize = 256;
    std::array<float, HistorySize> waveformHistory{};
    size_t historyWriteIdx = 0;

    dsp171::LockFreeVisualFIFO<512>& fifo;

    float smoothedTrans = 0.0f;
    float smoothedTonal = 0.0f;
    float smoothedRMS   = 0.0f;

    // Dati per i VU Meter
    float targetRMS_L = 0.0f;
    float targetRMS_R = 0.0f;
    float targetPeak_L = 0.0f;
    float targetPeak_R = 0.0f;

    float needleAngleL = -0.73f;
    float needleVelL = 0.0f;
    float needleAngleR = -0.73f;
    float needleVelR = 0.0f;

    // Dati per il LED Meter
    float dispRmsL = -60.0f;
    float dispRmsR = -60.0f;
    float dispPeakL = -60.0f;
    float dispPeakR = -60.0f;
    float peakHoldL = -60.0f;
    float peakHoldR = -60.0f;
    float holdTimerL = 0.0f;
    float holdTimerR = 0.0f;

    juce::Image vuDialImg;
    juce::Image ledBoxImg;
    juce::Image cachedVuDial;
    juce::Image cachedLedBox;
};

} // namespace gui171
