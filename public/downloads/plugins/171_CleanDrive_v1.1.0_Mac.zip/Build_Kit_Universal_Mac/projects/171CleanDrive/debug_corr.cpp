#include <iostream>
#include <cmath>
#include <juce_core/juce_core.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "Source/PluginProcessor.h"

int main() {
    juce::ScopedJuceInitialiser_GUI guiInit;
    AudioPluginAudioProcessor proc;
    proc.prepareToPlay(48000.0, 512);
    proc.setCurrentProgram(0);

    constexpr int blockSize = 512;
    juce::AudioBuffer<float> monoIn(2, blockSize);
    juce::MidiBuffer midi;

    for (int b = 0; b < 10; ++b) {
        for (int i = 0; i < blockSize; ++i) {
            float s = 0.7f * std::sin(2.0f * 3.14159265f * 300.0f * (b * blockSize + i) / 48000.0f);
            monoIn.setSample(0, i, s);
            monoIn.setSample(1, i, s);
        }
        proc.processBlock(monoIn, midi);
        float s0 = monoIn.getSample(0, 0);
        float s1 = monoIn.getSample(1, 0);
        float rho = proc.getCorrelation();
        std::cout << "Block " << b << ": s0=" << s0 << ", s1=" << s1 << ", rho=" << rho << std::endl;
    }
    return 0;
}
